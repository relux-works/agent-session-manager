package sshtransport
import("encoding/json";"bytes";"context";"io";"os";"os/exec";"path/filepath";"strings";"testing")
func init(){
 if os.Getenv("AX_REVIEW_FIXTURE")!="pressure"{return}
 done:=make(chan struct{});go func(){defer close(done);for i:=0;i<64;i++{if _,err:=os.Stderr.Write(bytes.Repeat([]byte{'e'},1024));err!=nil{os.Exit(71)}}}()
 for i:=0;i<16;i++{for j:=0;j<64;j++{if _,err:=os.Stdout.Write(bytes.Repeat([]byte{byte('a'+i)},4096));err!=nil{os.Exit(72)}};if _,err:=os.Stdout.Write([]byte{'\n'});err!=nil{os.Exit(73)}}
 <-done;os.Exit(0)
}
func TestReviewSimultaneousPressureAndPartialWrites(t *testing.T){
 c:=client(t,"unused","");c.env=append(c.env,"AX_REVIEW_FIXTURE=pressure");s:=open(t,c)
 for i:=0;i<16;i++{line,err:=s.Receive();if err!=nil||!bytes.Equal(line,bytes.Repeat([]byte{byte('a'+i)},64*4096)){t.Fatalf("frame %d length %d err %v",i,len(line),err)}}
 if _,err:=s.Receive();err!=io.EOF{t.Fatal(err)};if err:=s.Wait();err!=nil{t.Fatal(err)}
}
func TestReviewNativeConfiguredDestination(t *testing.T){
 ssh,err:=exec.LookPath("ssh");if err!=nil{t.Fatal(err)}
 c:=client(t,"config",`ssh_args = ["-p", "3333", "-o", "Port=4444", "-o", "StrictHostKeyChecking=yes", "-i", "/fixture/no-key"]`)
 file:=filepath.Join(t.TempDir(),"config");if err:=os.WriteFile(file,[]byte("Host *\n User fixture\n IdentityFile none\n Hostname ::1\n Port 5555\n"),0600);err!=nil{t.Fatal(err)}
 c.env=append(c.env,"AX_SSH_CONFIG="+file,"AX_SSH_BINARY="+ssh);s:=open(t,c);lines,err:=drain(s);if err!=io.EOF{t.Fatal(err)}
 values:=map[string]string{};for _,line:=range lines{k,v,_:=strings.Cut(string(line)," ");values[k]=v}
 for k,w:=range map[string]string{"hostname":"::1","port":"2222","user":"alice","stricthostkeychecking":"true"}{if values[k]!=w{t.Fatalf("%s=%s want %s",k,values[k],w)}}
}
func TestReviewRetryAfterRefusalAndCancel(t *testing.T){
 c:=client(t,"empty","");if _,err:=c.Open(context.Background(),"unconfigured");err==nil{t.Fatal("unknown peer admitted")}
 ctx,cancel:=context.WithCancel(context.Background());cancel();if _,err:=c.Open(ctx,"peer");err==nil{t.Fatal("cancel admitted")}
 for i:=0;i<10;i++{s:=open(t,c);if _,err:=s.Receive();err!=io.EOF{t.Fatalf("retry %d: %v",i,err)};if err:=s.Wait();err!=nil{t.Fatal(err)}}
}

func TestReviewDefaultNewOpenUsesPATHSSH(t *testing.T){
 executable,err:=os.Executable();if err!=nil{t.Fatal(err)}
 folder:=t.TempDir();if err:=os.Symlink(executable,filepath.Join(folder,"ssh"));err!=nil{t.Fatal(err)}
 t.Setenv("PATH",folder);t.Setenv("AX_SSH_FIXTURE","argv");t.Setenv("GOCOVERDIR",t.TempDir());t.Setenv("GORACE","atexit_sleep_ms=0")
 c,err:=New(snapshot(t,document("")));if err!=nil{t.Fatal(err)}
 s:=open(t,c);lines,err:=drain(s);if err!=io.EOF||len(lines)!=1{t.Fatalf("lines=%d err=%v",len(lines),err)}
 var argv []string;if err:=json.Unmarshal(lines[0],&argv);err!=nil{t.Fatal(err)}
 if strings.Join(argv[len(argv)-5:],"|")!="alice@::1|ax|rpc|serve|--stdio"{t.Fatalf("argv=%q",argv)}
}
