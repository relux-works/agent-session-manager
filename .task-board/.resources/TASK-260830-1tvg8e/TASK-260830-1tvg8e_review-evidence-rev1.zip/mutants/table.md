| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent size accumulator | none | 0 | neutral passed:  |
| known-bad | Adds a remote command token | TestOpenStructuredCommand | 1 | killed:  |
| argv-plus-one | Admits exactly 65537 composed bytes | TestOpenComposedArgvBound/65537 | 1 | killed:  |
| send-plus-one | Admits exactly one excess outbound byte | TestDuplexAndSendBoundaries/oversize | 1 | killed:  |
| read-plus-one | Admits exactly one excess inbound byte | TestReceiveFailureAndLimits/oversize | 1 | killed:  |
| stderr-plus-one | Admits exactly one excess stderr byte | TestReceiveFailureAndLimits/stderr-over | 1 | killed:  |
| exit255 | Treats SSH exit 255 alone as successful EOF | TestReceiveFailureAndLimits/exit255 | 1 | killed:  |
| cancel-as-success | Suppresses explicit cancellation but keeps other failures | TestCancellationAndCleanup/stall | 1 | killed:  |
| drain-as-success | Suppresses inherited-pipe failure only | TestInheritedPipeCleanup/descendant | 1 | killed:  |
| read-as-absence | Suppresses OS stream errors only | TestReadFailureAndRecovery | 1 | killed:  |
| direct-child-only | Kills direct child but admits inherited pipe descendants | TestInheritedPipeCleanup/descendant | 1 | killed:  |
| policy-StrictHostKeyChecking | Admits StrictHostKeyChecking=accept-new while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ClearAllForwardings | Admits ClearAllForwardings=no while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-Tunnel | Admits Tunnel=point-to-point while preserving all other SSH policy | none | 0 | survived: Native ClearAllForwardings=yes suppresses tunnels too; the ClearAllForwardings mutant is killed. No independent Tunnel-policy kill claimed. |
| policy-RequestTTY | Admits RequestTTY=force while preserving all other SSH policy | none | 0 | survived: The fixed trailing -T from peeridentity overrides RequestTTY; no independent RequestTTY-policy kill claimed. |
