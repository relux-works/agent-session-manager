| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| send-empty | Admits a non-nil empty outbound line | TestDuplexAndSendBoundaries/empty | 1 | killed:  |
| send-two-lines | Admits the two-frame outbound fixture | TestDuplexAndSendBoundaries/newline | 1 | killed:  |
| read-empty | Admits the initial empty inbound frame | TestReceiveFailureAndLimits/blank | 1 | killed:  |
| read-partial | Treats one unterminated success-shaped frame as EOF | TestReceiveFailureAndLimits/partial | 1 | killed:  |
| connect-timeout | Allows one extra second before connection timeout | TestOpenNativeSSHPolicy | 1 | killed:  |
| rpc-timeout | Allows one extra second of process lifetime | TestCancellationAndCleanup/deadline | 1 | killed:  |
| policy-NoHostAuthenticationForLocalhost | Admits NoHostAuthenticationForLocalhost=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-VerifyHostKeyDNS | Admits VerifyHostKeyDNS=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-UpdateHostKeys | Admits UpdateHostKeys=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-BatchMode | Admits BatchMode=no while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-NumberOfPasswordPrompts | Admits NumberOfPasswordPrompts=1 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlMaster | Admits ControlMaster=auto while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlPath | Admits ControlPath=/fixture/control while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlPersist | Admits ControlPersist=1 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForwardAgent | Admits ForwardAgent=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForwardX11 | Admits ForwardX11=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-PermitLocalCommand | Admits PermitLocalCommand=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-RemoteCommand | Admits RemoteCommand=false while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-SessionType | Admits SessionType=none while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForkAfterAuthentication | Admits ForkAfterAuthentication=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-StdinNull | Admits StdinNull=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ConnectionAttempts | Admits ConnectionAttempts=2 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
