| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| connect-timeout | Allows one extra second before connection timeout | TestOpenNativeSSHPolicy | 1 | killed:  |
| rpc-timeout | Allows one extra second of process lifetime | TestCancellationAndCleanup/deadline | 1 | killed:  |
