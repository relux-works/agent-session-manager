import json, subprocess, sys, time
from pathlib import Path
out=Path('.temp/TASK-260830-1tvg8e')
groups={
 'core':['go build ./...', 'go vet ./...', 'go test ./... -v', 'go test ./... -cover'],
 'race':['go test ./... -race -count=1'],
 'metadata':['go run ./internal/traceability/cmd/tracecheck', 'go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.5.0.json -contracts internal/specpin/v0.5.0.lock.json -output internal/catalog/catalog_gen.go -check', 'GOOS=linux GOARCH=amd64 go build ./...', 'GOOS=windows GOARCH=amd64 go build ./...', "git ls-files -z '*.json' | xargs -0 -n1 python3 -c 'import json,sys;json.load(open(sys.argv[1]))'", 'git diff --check'],
}
config=json.loads(Path('task-board.config.json').read_text())
commands=config['spawn']['worktree_isolation']['validation']['commands']
groups['tests']=['go test ./... -v', 'go test ./... -cover']
groups['fuzz']=[c for c in commands if ' -fuzz=' in c]
groups['format']=[commands[0]]
for index,command in enumerate(groups[sys.argv[1]],1):
 log=out/f'{sys.argv[1]}-{index:02d}.log'
 start=time.time()
 with log.open('w') as stream:
  try:
   result=subprocess.run(['zsh','-o','pipefail','-c',command],stdout=stream,stderr=subprocess.STDOUT,timeout=540)
   code=result.returncode
  except subprocess.TimeoutExpired: code=124
 row={'command':command,'exit_code':code,'seconds':round(time.time()-start,3),'log':str(log)}
 with (out/'gate-exits.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
 print(json.dumps(row),flush=True)
 if code:sys.exit(code)
