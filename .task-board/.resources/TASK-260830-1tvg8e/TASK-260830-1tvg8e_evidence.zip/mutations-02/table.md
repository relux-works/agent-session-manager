| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent size accumulator | none | 0 | neutral passed:  |
| known-bad | Adds a remote command token | TestOpenStructuredCommand | 1 | killed:  |
| argv-plus-one | Admits exactly 65537 composed bytes | TestOpenComposedArgvBound/65537 | 1 | killed:  |
| send-plus-one | Admits exactly one excess outbound byte | TestDuplexAndSendBoundaries/oversize | 1 | killed:  |
| read-plus-one | Admits exactly one excess inbound byte | TestReceiveFailureAndLimits/oversize | 1 | killed:  |
| send-empty | Admits a non-nil empty outbound line | TestDuplexAndSendBoundaries/empty | 1 | killed:  |
| send-two-lines | Admits the two-frame outbound fixture | TestDuplexAndSendBoundaries/newline | 1 | killed:  |
| read-empty | Admits the initial empty inbound frame | TestReceiveFailureAndLimits/blank | 1 | killed:  |
| read-partial | Treats one unterminated success-shaped frame as EOF | TestReceiveFailureAndLimits/partial | 1 | killed:  |
| stderr-plus-one | Admits exactly one excess stderr byte | TestReceiveFailureAndLimits/stderr-over | 1 | killed:  |
| exit255 | Treats SSH exit 255 alone as successful EOF | TestReceiveFailureAndLimits/exit255 | 1 | killed:  |
| cancel-as-success | Suppresses explicit cancellation but keeps other failures | TestCancellationAndCleanup/stall | 1 | killed:  |
| drain-as-success | Suppresses inherited-pipe failure only | TestInheritedPipeCleanup/descendant | 1 | killed:  |
| read-as-absence | Suppresses OS stream errors only | TestReadFailureAndRecovery | 1 | killed:  |
| direct-child-only | Kills direct child but admits inherited pipe descendants | TestInheritedPipeCleanup/descendant | 1 | killed:  |
| policy-StrictHostKeyChecking | Admits StrictHostKeyChecking=accept-new while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-NoHostAuthenticationForLocalhost | Admits NoHostAuthenticationForLocalhost=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-VerifyHostKeyDNS | Admits VerifyHostKeyDNS=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-UpdateHostKeys | Admits UpdateHostKeys=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-BatchMode | Admits BatchMode=no while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-NumberOfPasswordPrompts | Admits NumberOfPasswordPrompts=1 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlMaster | Admits ControlMaster=auto while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlPath | Admits ControlPath=/fixture/control while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ControlPersist | Admits ControlPersist=1 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ClearAllForwardings | Admits ClearAllForwardings=no while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForwardAgent | Admits ForwardAgent=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForwardX11 | Admits ForwardX11=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-Tunnel | Admits Tunnel=point-to-point while preserving all other SSH policy | none | 0 | survived: No named failing test established; this gate member is unproven. |
| policy-PermitLocalCommand | Admits PermitLocalCommand=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-RemoteCommand | Admits RemoteCommand=false while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-RequestTTY | Admits RequestTTY=force while preserving all other SSH policy | none | 0 | survived: No named failing test established; this gate member is unproven. |
| policy-SessionType | Admits SessionType=none while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ForkAfterAuthentication | Admits ForkAfterAuthentication=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-StdinNull | Admits StdinNull=yes while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
| policy-ConnectionAttempts | Admits ConnectionAttempts=2 while preserving all other SSH policy | TestOpenNativeSSHPolicy | 1 | killed:  |
