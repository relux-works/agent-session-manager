#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants (iso copy only)."""
import os, subprocess, sys, json

ROOT = "/tmp/ckiso"
LOG = "/tmp/rev1/iso-review-mutants"
os.makedirs(LOG, exist_ok=True)

PLANTS = [
    {"name": "R1-foreign-lease", "file": "internal/sessckpt/capture.go",
     "old": "\t\tif summary.LeaseEpoch == inputs.LeaseEpoch && summary.LeaseID != lease.String() {",
     "new": "\t\tif summary.LeaseEpoch == inputs.LeaseEpoch && summary.LeaseID != summary.LeaseID {",
     "run": "TestCaptureRefusesLaterLeaseHead", "expect": "killed"},
    {"name": "R2-kind-replica", "file": "internal/sessckpt/capture.go",
     "old": '\tcase SessionKindDirect, SessionKindTaskBoard:',
     "new": '\tcase SessionKindDirect, SessionKindTaskBoard, "replica":',
     "run": "TestCaptureRefusesMalformedClosureMembers/bad_kind", "expect": "killed"},
    {"name": "R3-length-only", "file": "internal/sessckpt/store.go",
     "old": "\tif string(existing) != string(data) {",
     "new": "\tif len(existing) != len(data) {",
     "run": "TestReviewKillerSameLengthDisagreement", "expect": "killed"},
    {"name": "R4-swallow-idle", "file": "internal/sessckpt/capture.go",
     "old": "\tif !boundary.InputBlocked {",
     "new": "\tif !boundary.InputBlocked && !boundary.ForegroundIdle {",
     "run": "TestCaptureRefusesNonQuiescentBoundary/input_blocked_false", "expect": "killed"},
    {"name": "R5-swap-variant", "file": "internal/sessckpt/capture.go",
     "old": '\t\t\treturn invalid("checkpoint carries a task-board persistence variant for direct session")',
     "new": '\t\t\treturn invalid("checkpoint carries a provider persistence variant for direct session")',
     "run": "TestCaptureRefusesBadPersistenceVariant/swapped_direct_takes_bundle", "expect": "killed"},
    {"name": "R6-delete-default", "file": "internal/sessckpt/capture.go",
     "old": '\tdefault:\n\t\treturn invalid("session kind %q selects no checkpoint persistence variant", kind)',
     "new": '\tdefault:\n\t\treturn nil',
     "run": "TestCaptureRefusesBadPersistenceVariant", "expect": "survived-note"},
    {"name": "C2-harmless-comment", "file": "internal/sessckpt/store.go",
     "old": "// Store durably installs Checkpoint Records and their operation",
     "new": "// Store durably installs Checkpoint Records and their operation (review control)",
     "run": "TestCaptureDirectInstallsAttestedRecord", "expect": "survived"},
]

results = []
for p in PLANTS:
    path = os.path.join(ROOT, p["file"])
    src = open(path).read()
    n = src.count(p["old"])
    rec = {"name": p["name"], "expect": p["expect"], "run": p["run"]}
    logp = os.path.join(LOG, p["name"] + ".log")
    if n != 1:
        rec["verdict"] = "NOT_APPLIED"
        rec["detail"] = "anchor x%d" % n
        open(logp, "w").write("NOT_APPLIED anchor x%d\n" % n)
        results.append(rec)
        continue
    open(path, "w").write(src.replace(p["old"], p["new"], 1))
    try:
        c = subprocess.run(["go", "test", "./internal/sessckpt/", "-run", p["run"], "-count=1"],
                           cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, timeout=300)
        open(logp, "w").write("$ go test ./internal/sessckpt/ -run %s -count=1\nreturncode: %d\n%s" % (p["run"], c.returncode, c.stdout))
        rec["returncode"] = c.returncode
        if "no tests to run" in c.stdout:
            rec["verdict"] = "COMPILE_OR_HARNESS_FAILURE"
        elif c.returncode != 0:
            rec["verdict"] = "KILLED"
        else:
            rec["verdict"] = "SURVIVED"
    finally:
        open(path, "w").write(src)
    results.append(rec)

for r in results:
    print("%-20s %-28s expect=%-13s rc=%s" % (r["name"], r["verdict"], r["expect"], r.get("returncode", "-")))
json.dump(results, open(os.path.join(LOG, "summary.json"), "w"), indent=2)
