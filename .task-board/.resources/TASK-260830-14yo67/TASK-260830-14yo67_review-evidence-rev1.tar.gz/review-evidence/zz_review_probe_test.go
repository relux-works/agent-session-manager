package sessckpt

// Independent reviewer probes (THROWAWAY - iso copy only, never committed).

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/canonicaljson"
	"github.com/relux-works/agent-session-manager/internal/sessquery"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

func reviewOp(tag string) string { return "0198f4c8-0a" + tag + "-7aaa-8aaa-1234567890ab" }

func TestReviewProbeAdmissionVectors(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)
	_, raw := mustCapture(t, store, chain, testInputs([]string{created}, reviewOp("01")))

	second := appendChainEvent(t, chain, "lease.transferred", 2, testLeaseB, 1, created, map[string]any{
		"operation_id": testHostB, "from_host_id": testHostA, "to_host_id": testHostA,
		"predecessor_lease_id": testLease, "new_lease_id": testLeaseB,
	})
	_, _, err := store.Capture(chain, testInputs([]string{second}, reviewOp("02")))
	t.Logf("V1 later-epoch head via Capture: err=%v isInvalid=%v", err, errors.Is(err, ErrInvalidCheckpoint))
	if err == nil || !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("V1 must refuse with the invalid-closure class")
	}

	chain2, created2 := chainFixture(t)
	inputs := testInputs([]string{created2}, reviewOp("03"))
	inputs.CreatorHostID = testHostB
	_, wrongCreatorRaw := mustCapture(t, store, chain2, inputs)
	reader := &sessquery.Reader{Local: chain2, LocalHostID: testHostA}
	reader.CheckpointRecords = append(reader.CheckpointRecords, wrongCreatorRaw)
	reader.LeaseRecords = append(reader.LeaseRecords, leaseRecordBytes(t, testLease, testHostA, checkpointIDOf(t, wrongCreatorRaw)))
	_, err = reader.BuildPlan(sessquery.PlanArgs{Selector: "alpha", Action: sessquery.ActionStatus})
	t.Logf("V2 wrong creator via consumer: err=%v obsUnavailable=%v", err, errors.Is(err, sessquery.ErrObservationUnavailable))
	if !errors.Is(err, sessquery.ErrObservationUnavailable) {
		t.Fatalf("V2 must refuse with selector_observation_unavailable")
	}

	tbInputs := testInputs([]string{created}, reviewOp("04"))
	tbInputs.SessionKind = SessionKindTaskBoard
	tbInputs.ProviderManifestID = ""
	tbInputs.TaskBoardBundleID = testBoardBundle
	_, tbRaw := mustCapture(t, store, chain, tbInputs)
	_, err = store.Admit(chain, tbRaw, reviewOp("05"), SessionKindDirect)
	t.Logf("V3 bundle-leg record admitted as direct: err=%v isInvalid=%v", err, errors.Is(err, ErrInvalidCheckpoint))
	if err == nil || !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("V3 must refuse with the invalid-closure class")
	}

	tampered := mutateRaw(t, raw, func(value map[string]any) {
		value["task_board_bundle_id"] = testBoardBundle
		value["provider_manifest_id"] = nil
	})
	_, err = store.Admit(chain, tampered, reviewOp("06"), SessionKindTaskBoard)
	t.Logf("V4 moved bundle digest via Admit: err=%v isInvalid=%v", err, errors.Is(err, ErrInvalidCheckpoint))
	if err == nil || !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("V4 must refuse with the invalid-closure class")
	}

	wrongType := mutateRaw(t, raw, func(value map[string]any) {
		value["safe_boundary"].(map[string]any)["open_processes"] = "zero"
	})
	_, err = store.Admit(chain, wrongType, reviewOp("07"), SessionKindDirect)
	t.Logf("V5 evidence wrong-type member via Admit: err=%v isInvalid=%v", err, errors.Is(err, ErrInvalidCheckpoint))
	if err == nil || !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("V5 must refuse with the invalid-closure class")
	}

	extra := mutateRaw(t, raw, func(value map[string]any) {
		value["future_member"] = "nope"
	})
	_, err = store.Admit(chain, extra, reviewOp("08"), SessionKindDirect)
	t.Logf("V6 unknown extra member via Admit: err=%v isInvalid=%v", err, errors.Is(err, ErrInvalidCheckpoint))
	if err == nil || !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("V6 must refuse with the invalid-closure class")
	}
}

func TestReviewProbeDurabilityStates(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)

	interrupted := errors.New("review probe crash after blob")
	store.AfterBlob = func() error { return interrupted }
	_, _, err := store.Capture(chain, testInputs([]string{created}, reviewOp("11")))
	if !errors.Is(err, interrupted) {
		t.Fatalf("fault = %v, want interior fault", err)
	}
	store.AfterBlob = nil
	blobs, _ := filepath.Glob(filepath.Join(store.root, "*.json"))
	if len(blobs) != 1 {
		t.Fatalf("state(a) blobs = %d, want 1", len(blobs))
	}
	raw, err := os.ReadFile(blobs[0])
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := sessrepo.AttestCheckpointRecord(raw); err != nil {
		t.Fatalf("state(a) blob does not attest: %v", err)
	}
	ref, _, err := store.Capture(chain, testInputs([]string{created}, reviewOp("11")))
	if err != nil {
		t.Fatalf("state(a) retry = %v", err)
	}
	t.Logf("state(a) blob-without-receipt resumes under %s", ref.CheckpointID)

	store2 := openTestStore(t)
	opB := reviewOp("12")
	fakeReceipt := `{"operation_id":"` + opB + `","checkpoint_id":"` + testOtherManifest +
		`","input_digest":"` + testOtherManifest + `","session_id":"` + testSessionID + `"}`
	if err := os.WriteFile(filepath.Join(store2.root, "operations", opB+".json"), []byte(fakeReceipt), 0o600); err != nil {
		t.Fatal(err)
	}
	_, _, err = store2.Capture(chain, testInputs([]string{created}, opB))
	if err == nil {
		t.Fatalf("state(b) capture over orphan receipt admitted")
	}
	t.Logf("state(b) receipt-without-blob retry: err=%v", err)
	if _, err := store2.Get(testOtherManifest); err == nil {
		t.Fatalf("state(b) Get(absent blob) admitted")
	} else if errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("state(b) Get(absent) = %v, want operational error", err)
	} else {
		t.Logf("state(b) Get(absent blob): operational err=%v", err)
	}

	store3 := openTestStore(t)
	ref3, _ := mustCapture(t, store3, chain, testInputs([]string{created}, reviewOp("13")))
	if err := os.WriteFile(store3.blobPath(ref3.CheckpointID), []byte(`{"torn":true}`), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := store3.Get(ref3.CheckpointID); err == nil {
		t.Fatalf("state(c) Get(torn) admitted")
	} else if !errors.Is(err, canonicaljson.ErrInvalidIdentity) {
		t.Fatalf("state(c) Get(torn) = %v, want incompatible_schema class", err)
	} else {
		t.Logf("state(c) torn blob refuses with incompatible_schema")
	}
}

func TestReviewProbeIdempotencyNoWrite(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)
	inputs := testInputs([]string{created}, reviewOp("21"))
	first, _ := mustCapture(t, store, chain, inputs)

	receiptBefore, _ := os.Stat(store.receiptPath(reviewOp("21")))
	second, _ := mustCapture(t, store, chain, inputs)
	if first != second {
		t.Fatalf("replay ref diverged")
	}
	receiptAfter, _ := os.Stat(store.receiptPath(reviewOp("21")))
	if !receiptBefore.ModTime().Equal(receiptAfter.ModTime()) {
		t.Fatalf("replay rewrote the receipt")
	}
	t.Logf("replay leaves receipt mtime unchanged")

	moved := testInputs([]string{created}, reviewOp("21"))
	moved.WorkspaceManifestID = testOtherManifest
	blobsBefore, _ := filepath.Glob(filepath.Join(store.root, "*.json"))
	if _, _, err := store.Capture(chain, moved); !errors.Is(err, ErrCheckpointConflict) {
		t.Fatalf("moved inputs = %v, want conflict", err)
	}
	blobsAfter, _ := filepath.Glob(filepath.Join(store.root, "*.json"))
	if len(blobsBefore) != len(blobsAfter) {
		t.Fatalf("refused retry wrote blobs")
	}
	t.Logf("moved-inputs retry refuses conflict with no write")

	third, _ := mustCapture(t, store, chain, testInputs([]string{created}, reviewOp("22")))
	if third.CheckpointID != first.CheckpointID {
		t.Fatalf("identical closure new op: %q vs %q", third.CheckpointID, first.CheckpointID)
	}
	t.Logf("different-op identical-inputs shares checkpoint identity per pure-digest clause")

	again, err := Open(store.root[:len(store.root)-len("/checkpoints")])
	if err != nil {
		t.Fatal(err)
	}
	a, err := store.Get(first.CheckpointID)
	if err != nil {
		t.Fatal(err)
	}
	b, err := again.Get(first.CheckpointID)
	if err != nil {
		t.Fatal(err)
	}
	if string(a) != string(b) {
		t.Fatalf("cross-handle reads differ")
	}
	t.Logf("byte-identical reads across handles")
}

func TestReviewKillerSameLengthDisagreement(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)
	ref, _ := mustCapture(t, store, chain, testInputs([]string{created}, reviewOp("31")))
	raw, err := os.ReadFile(store.blobPath(ref.CheckpointID))
	if err != nil {
		t.Fatal(err)
	}
	forged := make([]byte, len(raw))
	copy(forged, raw)
	forged[len(forged)-2] ^= 0x01
	if string(forged) == string(raw) {
		t.Fatalf("forge failed")
	}
	if err := os.WriteFile(store.blobPath(ref.CheckpointID), forged, 0o600); err != nil {
		t.Fatal(err)
	}
	_, _, err = store.Capture(chain, testInputs([]string{created}, reviewOp("32")))
	if !errors.Is(err, ErrCheckpointConflict) {
		t.Fatalf("same-length disagreement = %v, want ErrCheckpointConflict", err)
	}
}

func TestReviewProbeAdmitUnknownSession(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)
	_, raw := mustCapture(t, store, chain, testInputs([]string{created}, reviewOp("41")))
	fresh, err := sessrepo.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	_, err = store.Admit(fresh, raw, reviewOp("42"), SessionKindDirect)
	if !errors.Is(err, sessrepo.ErrUnknownSession) {
		t.Fatalf("Admit(unknown session) = %v, want ErrUnknownSession", err)
	}
	t.Logf("Admit unknown session propagates owner ErrUnknownSession")
}

func TestReviewProbeAdmitLaterHead(t *testing.T) {
	chain, created := chainFixture(t)
	store := openTestStore(t)
	second := appendChainEvent(t, chain, "lease.transferred", 2, testLeaseB, 1, created, map[string]any{
		"operation_id": testHostB, "from_host_id": testHostA, "to_host_id": testHostA,
		"predecessor_lease_id": testLease, "new_lease_id": testLeaseB,
	})
	_, raw := mustCapture(t, store, chain, testInputs([]string{created}, reviewOp("51")))
	forged := mutateRaw(t, raw, func(value map[string]any) {
		value["event_heads"] = []any{second}
	})
	var framed map[string]any
	if err := json.Unmarshal(forged, &framed); err != nil {
		t.Fatal(err)
	}
	if _, err := store.Admit(chain, identify(t, framed, "checkpoint_id"), reviewOp("52"), SessionKindDirect); err == nil {
		t.Fatalf("Admit(later-epoch head) admitted")
	} else if !errors.Is(err, ErrInvalidCheckpoint) {
		t.Fatalf("Admit(later-epoch head) = %v, want invalid-closure class", err)
	} else {
		t.Logf("Admit later-epoch head refuses: %v", err)
	}
}
