# TASK-260830-8x76g1 — pinned constraint enumeration

Normative source: `relux-works/agent-session-manager-spec` v0.5.0, commit
`28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c`, Sections 1.6, 10.1–10.4,
and 17.3. The composed production path is:

`CalculateObjectIdentity|VerifyObjectIdentity -> prepareObjectIdentity -> validateImmutableObjectShape`

“Enforced” below means both public identity entries refuse the malformed value
before calculating or attesting its identity. “External” means the rule needs
bytes or records that are not members of the one identity candidate; inferring
those facts from this JSON would be a forced fit.

## Section 1.6 common rules reachable at this boundary

| Constraint | Disposition |
| --- | --- |
| UTF-8 JSON text, string map keys, unique keys, no duplicate decoded names, no lone surrogates | Enforced by `decodeStrict` recursively before schema selection. |
| No floats, NaN, Infinity; every JSON number is an integral safe integer | Enforced by strict decode plus `validateAXNumbers`. |
| `uint53`, UUIDv7, digest, timestamp, path, and closed enum values | Enforced through production `internal/scalar` validators at each declared Section 10.2/10.4 member. |
| `git-oid`, `git-ref`, and `sanitized-git-URL` embedded scalar grammars | Enforced through production `internal/scalar` validators added by this task; object-format context is supplied by the containing Git shape. |
| `string[n..m]` versus bare `string` | Character bounds use Unicode character counts. Bare strings remain valid UTF-8 strings and do not acquire an undeclared non-empty bound; this is proven for exclusion classes, Git filter names, and migration `schema_id`. |
| JCS UTF-16 property ordering, escaping and number rendering | Enforced by `Canonicalize` and the omit-self calculation; published vectors, Unicode ordering and cross-representation golden tests drive the public entries. |
| Immutable-object self field chosen by exact schema/version; callers cannot select the omitted field | Enforced by generated catalog lookup in `resolveSelfField`. |
| Encoded identity-addressed object maximum 5,242,880 bytes | Enforced in `prepareObjectIdentity` before decode. |
| Extension keys and values | Enforced for every object carrying `extensions`: lowercase reverse-DNS keys, at most 64 members, depth at most 4, canonical size at most 65,536 bytes. |
| Section 17.3 `works.relux.ax.migrated-from` | Enforced as an exact three-member object containing a UTF-8 `schema_id` string, canonical semver and digest object ID. No undeclared non-empty constraint is added. Publication, atomic-reference advancement and retention are not claimed. |

## Section 10.1 record envelope

Section 10.1 adds common members to several schema-specific records but does
not declare one common closed member set: each record also has schema-specific
fields. The public identity boundary therefore separates catalog recognition
from shape support. A registry-derived completeness check requires every
registered schema/version to resolve to an explicit shape validator; there is
no default or extension-only fall-through.

Session Record `1.0.0` has a complete validator at this boundary. It enforces
the exact top-level member set, digest, UUIDv7 subject/session equality,
timestamp, host/workspace identifiers, provider/profile/kind enums, and the
closed Launch Plan, Task-board Reference, Board Identity, Board Goal, and Fork
Provenance nested objects. Missing common members, malformed UUIDs, impossible
dates, unknown top-level members, and unknown nested members refuse through
both public entries.

The other Section 10.1 record schema/version rows first validate the common
`subject_id`, `created_by_host_id`, `created_at`, and optional namespaced
`extensions` grammar, then explicitly refuse because their complete
schema-specific validator is outside this task. Every other registered
self-identity schema/version likewise has an explicit unsupported-shape
validator. Catalog membership still selects the correct self field for
internal contract resolution, but it cannot make an opaque object attestable.
This is the narrow, fail-closed alternative required when a complete negotiated
shape is unavailable.

## Section 10.2 Blob Descriptor and BlobChunk

| Object/member | Declared constraint | Disposition |
| --- | --- | --- |
| Blob Descriptor | Exact seven-member closed shape; exact schema/version | Enforced. |
| `descriptor_id`, `blob_id` | digest | Enforced through `scalar.ParseDigest`. |
| `size` | uint53 | Enforced. |
| `media_type` | 1–255 characters, lowercase ASCII type/subtype, no parameters | Enforced; exact 255 and over-bound cases drive both identity entries. |
| `chunks` | 0–32,768 BlobChunks | Enforced. |
| BlobChunk | Exact four-member closed shape | Enforced recursively. |
| `index` | uint32, starts at zero, increases by one | Enforced. |
| `offset` | uint53, starts at zero and is contiguous | Enforced. |
| `size` | uint53 in 1–4,194,304; non-final chunks exactly 4 MiB | Enforced. |
| `chunk_id` | digest | Enforced through `scalar.ParseDigest`. |
| Empty/non-empty and exact whole-size coverage rules | Empty means no chunks; non-empty means at least one; no gap, overlap, overflow or short coverage | Enforced. |
| Descriptor and raw blob bytes agree | Needs raw blob/chunk bytes | External to one descriptor identity candidate. |

## Section 10.3 Transfer Chunk Descriptor

The Transfer Chunk Descriptor is closed transfer metadata but is not an
identity-addressed JCS object: `chunk_id` is the digest of raw chunk bytes, not
a self field for the descriptor. The generated identity catalog therefore
refuses `urn:ax:schema:chunk` at both public object-identity entries. Its shared
index/offset/size/digest rules are enforced when the same data appears as a
BlobChunk under Section 10.2. Validating raw chunk bytes and complete blob
assembly belongs to the transfer receiver, not object identity calculation.

## Section 10.4 Transfer Manifest — top level and entries

| Object/member | Declared constraint | Disposition |
| --- | --- | --- |
| Transfer Manifest | Exact 15-member closed shape; exact schema/version | Enforced. |
| `manifest_id` | digest | Enforced. |
| `kind` | exact five-member enum | Enforced. |
| `subject_id`, `created_by_host_id` | UUIDv7 | Enforced through `scalar.ParseUUIDv7`. |
| `base_checkpoint_id` | digest or null | Enforced. |
| `entries` | 0–65,536; strict bytewise path order | Enforced. Duplicate and destination-case-colliding paths are refused. |
| `child_manifest_ids` | 0–1,024 sorted unique digests | Enforced. Path disjointness needs child manifests and is external. |
| three tagged nullable fields | Snapshot only for workspace group; provider ID only for provider; bundle ID only for task board; all null for composite | Enforced together with empty/non-empty entry/child rules. |
| `excluded_classes` | 0–128 sorted unique strings | Enforced. Whether every applicable exclusion was diagnosed requires capture evidence and is external. |
| `created_at` | real UTC RFC3339 timestamp with millisecond precision | Enforced through `scalar.ParseTimestamp`, including impossible-date refusal. |
| `extensions` | Section 1.6 object rules | Enforced. |
| ManifestEntry union | Exact directory/file/symlink/hardlink member sets | Enforced. Unknown tags or variant leakage refuse. |
| Entry `path` | platform-neutral relative path | Enforced through `scalar.ParseRelativePath`. |
| Entry `mode` | uint32 in 0–4095 | Enforced. |
| File `size`, blob IDs | uint53 and two digests | Enforced. Equality with a referenced Blob Descriptor needs that descriptor and is external. |
| Symlink `target` | 1–4096 Unicode characters; lexically remains in materialization root | Enforced. Filesystem/symlink resolution beneath the allowed root is external to immutable identity. |
| Hardlink `target_path` | path naming an earlier file with the same mode | Enforced in entry order. |
| Unsupported special-file tags | Not members of the entry enum | Refused. |

## Section 10.4 — WorkspaceSnapshot and Git embedded shapes

| Object/member | Declared constraint | Disposition |
| --- | --- | --- |
| WorkspaceSnapshot | Exact `workspace_group_id,members`; group UUID equals manifest subject | Enforced. |
| `members` | 1–256, strict workspace-ID order | Enforced; duplicate/case-colliding group-relative paths refused. One-for-one equality with the separately referenced Workspace Group Record is external. |
| managed-tree member | Exact eight-member union arm | Enforced. |
| managed `group_relative_path`, `tree_identity`, `tree_manifest_id`, cwd, config paths, policy | path; 1–256 Unicode chars; digest; `.` or path; 0–256 sorted unique paths; exact two-value enum | Enforced. |
| Git member | Exact 15-member union arm | Enforced. |
| Git member identity/path/policy fields | path; repository identity 1–256 Unicode chars; digest; cwd; sorted unique config paths; exact policy enum | Enforced. |
| `remotes` | 1–16 GitRemote objects sorted uniquely by name | Enforced. |
| GitRemote | Exact three members; name 1–128 Unicode chars; sanitized fetch URL; nullable sanitized push URL | Enforced through scalar URL validation; password/token, query, fragment, local/file and unsupported schemes refuse. Absolute HTTPS/SSH/git forms require a host but do not acquire an undeclared path bound. |
| GitHead | Exact tagged union: branch has oid+ref, detached only oid, unborn only `refs/heads/` ref | Enforced; OID and ref use production scalar grammars and OID format matches GitFeatures. |
| GitObjectPack | Exact seven members; literal format; sha1/sha256 object format; four digests; uint53 count | Enforced. Pack/inventory bytes, object membership and line count require referenced blobs/Git object database and are external. |
| GitIndex | Exact six members; literal format; version 2/3/4; two digests; 0–65,536 entries; uint53 count equal to length | Enforced. Raw index blob equality and required-extension interpretation require the blob/Git index parser and are external. |
| GitIndexEntry | Exact eight members; path; stage 0–3; uint32 mode; git-oid; four booleans | Enforced. Entries are strictly sorted by path then stage; OID format matches GitFeatures. This includes normative TM-GIT-N2 stage-4 refusal. |
| GitFeatures | Exact ten members; object format enum; six booleans; nullable sparse digest pair; 0–64 sorted unique filter names | Enforced. Sparse IDs are both non-null exactly when sparse checkout is true. |
| GitSubmodule | Exact 14-member recursive shape; path, identity 1–256 Unicode chars, sanitized URL, gitlink OID, boolean state | Enforced. |
| Submodule state union | Initialized: every state member except optional upstream ref is non-null and head is not unborn. Uninitialized: every state member is null. | Enforced recursively. |
| Submodule recursion | At most depth 16, at most 256 total, acyclic | Enforced; logical repository identities cannot repeat along an ancestor chain. Sibling paths cannot duplicate/case-collide. |
| Submodule pointer relation | `gitlink_oid` equals containing stage-0 mode-160000 index entry | Enforced recursively. Resolving parent HEAD-tree A and child HEAD commit in isolated object databases needs pack bytes and is external. |
| Object-format consistency | Head/index/pack/features OIDs use the containing repository format | Enforced recursively. |
| Referenced manifest/config/cwd closure | IDs and paths occur in transitive child closure | Needs child manifests | External to one manifest identity candidate. |
| Pack isolation, HEAD resolution, raw-index/logical-index equality | Needs blob bytes and isolated Git object databases | External to one manifest identity candidate. |

## Tests and fuzz mapping

- `TestImmutableObjectShapeValidatorCompletenessRejectsDeletedRegisteredSchema`
  derives the expected schema/version set from `catalog.Current().SelfIdentities`
  and proves that deleting one explicit validator row fails completeness.
- `TestSessionRecordV1ClosedShapeReachesBothIdentityEntries` starts from the
  normative complete Session Record fixture and attacks the common envelope,
  top-level closure, and nested Launch Plan closure through calculation and
  verification.
- `TestSessionRecordV1NestedTaggedShapesReachBothIdentityEntries` proves valid
  direct, task-board, primary-goal, and fork variants and attacks their nested
  tagged rules.
- `TestUnsupportedSection10RecordSchemasValidateCommonEnvelopeBeforeRefusal`
  proves every remaining Section 10.1 registry row checks its common scalar
  grammar before returning the explicit unsupported-shape refusal.
- `TestTransferManifestNestedValueConstraintsReachBothIdentityEntries` attacks
  every nested value class named by CR revision 3 and additional derived
  common types through both public entries.
- `TestTransferManifestReachableOrderingAndCrossFieldRules` attacks ordering,
  case collision, hardlink/symlink, object-format and parent-index relations.
- `TestTransferManifestSubmoduleStateDepthAndCycleRules` covers recursive
  positive depth, over-depth, missing initialized state and logical cycles.
- `TestTransferManifestNestedUnicodeBoundsAcceptExactMultibyteLimits` proves
  exact valid multibyte boundaries for every Section 10.4 `string[n..m]`.
- `TestUnboundedStringMembersDoNotGainAnUndeclaredNonEmptyConstraint` and
  `TestTransferManifestSanitizedGitURLsAllowHostOnlyAbsoluteFormsAtBothIdentityEntries`
  prove that the gate does not over-refuse valid bare strings or host-only
  absolute remote URLs.
- `FuzzClosedIdentityShapeRefusal` includes deterministic seeds/mutations for
  Session Record missing/malformed common fields and unknown top/nested
  members, plus Blob/Manifest unknown members, BlobChunk rules, nested bounds,
  malformed digest/ref/URL, TM-GIT-N2, submodule state, sparse-pair,
  symlink/hardlink and count rules.
- `task-board.config.json` invokes every repository fuzz target exactly once
  with `-fuzztime=100x -parallel=1`; a test derives this mapping from Go AST.
