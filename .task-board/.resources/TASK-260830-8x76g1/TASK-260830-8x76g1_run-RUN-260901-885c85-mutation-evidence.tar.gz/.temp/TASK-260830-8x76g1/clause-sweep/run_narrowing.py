import hashlib
import pathlib
import subprocess


source = pathlib.Path("internal/canonicaljson/closed_shapes.go")
original_path = pathlib.Path(".temp/TASK-260830-8x76g1/clause-sweep/closed_shapes.go.orig")
output_path = pathlib.Path(".temp/TASK-260830-8x76g1/clause-sweep/narrowing-result.txt")
expected_sha256 = "3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"
original = original_path.read_text()
assert hashlib.sha256(original.encode()).hexdigest() == expected_sha256
old = "\t\t\tif strings.EqualFold(pathValue, previous) {"
new = "\t\t\tif pathValue == previous {"
assert original.count(old) == 1


try:
    source.write_text(original.replace(old, new))
    result = subprocess.run(
        ["go", "test", "./internal/canonicaljson/", "-count=1"],
        capture_output=True,
        text=True,
    )
    combined = result.stdout + result.stderr
    expected_test = "TestSpecDerivedRefusalClausesReachBothIdentityEntries/submodule_sibling_path_case_collision"
    status = "KILLED" if result.returncode != 0 and expected_test in combined else "NOT_KILLED_BY_EXPECTED_TEST"
    report = (
        "mutant: strings.EqualFold(pathValue, previous) -> pathValue == previous\n"
        f"go test exit: {result.returncode}\n"
        f"status: {status}\n"
        f"expected failing test observed: {expected_test in combined}\n"
    )
    output_path.write_text(report + "\n" + combined)
    print(report, end="")
    if status != "KILLED":
        raise SystemExit(1)
finally:
    source.write_text(original)
    assert hashlib.sha256(source.read_text().encode()).hexdigest() == expected_sha256
