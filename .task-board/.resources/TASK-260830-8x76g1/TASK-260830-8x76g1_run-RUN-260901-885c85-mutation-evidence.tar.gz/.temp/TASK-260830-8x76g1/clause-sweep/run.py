import hashlib
import json
import pathlib
import subprocess
import sys


SOURCE = pathlib.Path("internal/canonicaljson/closed_shapes.go")
ROOT = pathlib.Path(".temp/TASK-260830-8x76g1/clause-sweep")
ORIGINAL = ROOT / "closed_shapes.go.orig"
MUTANTS = ROOT / "refusal-clauses.json"
EXPECTED_SHA256 = "3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"


def digest(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


original = ORIGINAL.read_text()
assert digest(original) == EXPECTED_SHA256
lines = original.split("\n")
mutants = json.loads(MUTANTS.read_text())
indices = [int(value) for value in sys.argv[1].split(",")]
output_path = pathlib.Path(sys.argv[2])


def restore() -> None:
    SOURCE.write_text(original)
    assert digest(SOURCE.read_text()) == EXPECTED_SHA256


try:
    with output_path.open("a") as output:
        for index in indices:
            mutant = mutants[index]
            changed = list(lines)
            assert changed[mutant["line"] - 1] == mutant["orig"]
            changed[mutant["line"] - 1] = mutant["new"]
            SOURCE.write_text("\n".join(changed))
            result = subprocess.run(
                ["go", "test", "./internal/canonicaljson/", "-count=1"],
                capture_output=True,
                text=True,
            )
            combined = result.stdout + result.stderr
            if "build failed" in combined or "syntax error" in combined or "[build failed]" in combined:
                status = "COMPILEFAIL"
            elif result.returncode == 0:
                status = "SURVIVED"
            else:
                status = "KILLED"
            row = f"{index}\tline{mutant['line']}\t{status}\texit={result.returncode}\t{mutant['cond']}"
            print(row, flush=True)
            print(row, file=output, flush=True)
            restore()
finally:
    restore()
