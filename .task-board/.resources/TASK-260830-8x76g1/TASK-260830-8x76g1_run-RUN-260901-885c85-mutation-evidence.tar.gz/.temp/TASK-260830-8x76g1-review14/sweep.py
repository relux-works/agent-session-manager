import json, subprocess, sys, hashlib, os

PATH="internal/canonicaljson/closed_shapes.go"
ORIG=".temp/TASK-260830-8x76g1-review14/closed_shapes.go.orig"
orig=open(ORIG).read()
assert hashlib.sha256(orig.encode()).hexdigest()=="3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"

mutants=json.load(open(sys.argv[1]))
lo=int(sys.argv[2]); hi=int(sys.argv[3])
out=open(sys.argv[4],"a")

def restore():
    open(PATH,"w").write(orig)
    assert hashlib.sha256(open(PATH).read().encode()).hexdigest()=="3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"

for i,m in enumerate(mutants):
    if i<lo or i>=hi: continue
    lines=orig.split("\n")
    idx=m["line"]-1
    if m["old"] not in lines[idx]:
        print(f"{i}\tSETUPFAIL\t{m['desc']}", file=out, flush=True); continue
    lines[idx]=lines[idx].replace(m["old"], m["new"], 1)
    try:
        open(PATH,"w").write("\n".join(lines))
        r=subprocess.run(["go","test","./internal/canonicaljson/","-count=1"],capture_output=True,text=True)
        if r.returncode==0:
            status="SURVIVED"
        elif "build failed" in r.stderr or "[build failed]" in r.stdout or "cannot use" in r.stdout+r.stderr or "syntax error" in r.stdout+r.stderr:
            status="COMPILEFAIL"
        else:
            status="KILLED"
        print(f"{i}\t{status}\t{m['desc']}", file=out, flush=True)
        print(f"{i}\t{status}\t{m['desc']}", flush=True)
    finally:
        restore()
restore()
