# Tool readiness

- `task-board`: `/Users/iv/.local/bin/task-board` (status mutation exited 0)
- `git`: `/usr/bin/git`, version 2.50.1 (Apple Git-155)
- `go`: `/Users/iv/.goenv/shims/go`, go1.25.5 darwin/arm64
- `rg`: Codex standalone ripgrep 15.2.0
- `curator`: `/Users/iv/.local/bin/curator`, v0.14.0-rc.3-106-g665dd13f
- `jq`: `/opt/homebrew/bin/jq`, jq-1.8.1
- `python3`: `/opt/homebrew/bin/python3`, Python 3.14.7 (read-only rollout recovery parsing)

Readiness probe exit code: 0.
