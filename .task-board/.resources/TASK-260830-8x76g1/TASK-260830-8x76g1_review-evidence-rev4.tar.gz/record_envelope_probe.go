package main

import (
	"encoding/json"
	"fmt"

	"github.com/relux-works/agent-session-manager/internal/canonicaljson"
)

const zeroDigest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"

func baseline() map[string]any {
	return map[string]any{
		"schema":             "urn:ax:schema:session-record",
		"schema_version":     "1.0.0",
		"record_id":          zeroDigest,
		"subject_id":         "0198f4c8-3e70-7a11-8a2b-1234567890ab",
		"session_id":         "0198f4c8-3e70-7a11-8a2b-1234567890ab",
		"name":               "payments-api",
		"kind":               "direct",
		"created_at":         "2026-08-19T04:00:00.000Z",
		"created_by_host_id": "0198f4c8-4a10-7b22-8b3c-1234567890ab",
		"provider_id":        "codex",
		"workspace_group_id": "0198f4c8-5b20-7c33-8c4d-1234567890ab",
		"execution_profile":  "yolo",
		"launch_plan": map[string]any{
			"argv":                       []any{"codex"},
			"cwd_workspace_id":           "0198f4c8-6c30-7d44-8d5e-1234567890ab",
			"cwd_relative":               "src",
			"env_names":                  []any{"OPENAI_API_KEY"},
			"env_literals":               map[string]any{},
			"contains_secrets":           false,
			"extensions":                 map[string]any{},
		},
		"task_board":      nil,
		"fork_provenance": nil,
		"extensions":      map[string]any{},
	}
}

func clone(value map[string]any) map[string]any {
	encoded, _ := json.Marshal(value)
	var copied map[string]any
	_ = json.Unmarshal(encoded, &copied)
	return copied
}

func probe(name string, object map[string]any) {
	encoded, _ := json.Marshal(object)
	digest, field, calculateErr := canonicaljson.CalculateObjectIdentity(encoded)
	verifyErr := fmt.Errorf("calculation refused")
	if calculateErr == nil {
		object[string(field)] = digest.String()
		claimed, _ := json.Marshal(object)
		_, _, verifyErr = canonicaljson.VerifyObjectIdentity(claimed)
	}
	fmt.Printf("%s calculate_accepted=%t verify_accepted=%t calculate_error=%v verify_error=%v\n",
		name, calculateErr == nil, verifyErr == nil, calculateErr, verifyErr)
}

func main() {
	valid := baseline()
	probe("valid_baseline", clone(valid))

	invalidTimestamp := clone(valid)
	invalidTimestamp["created_at"] = "2023-02-29T12:00:00.000Z"
	probe("invalid_common_timestamp", invalidTimestamp)

	invalidSubject := clone(valid)
	invalidSubject["subject_id"] = "not-a-uuid"
	probe("invalid_common_subject_uuid", invalidSubject)

	missingHost := clone(valid)
	delete(missingHost, "created_by_host_id")
	probe("missing_common_created_by_host_id", missingHost)

	unknownTopLevel := clone(valid)
	unknownTopLevel["unexpected_security_control"] = true
	probe("unknown_top_level_member", unknownTopLevel)
}
