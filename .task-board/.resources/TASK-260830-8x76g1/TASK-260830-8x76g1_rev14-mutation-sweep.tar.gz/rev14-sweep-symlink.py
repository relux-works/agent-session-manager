import subprocess, sys, hashlib, os, json
ROOT="/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2wdm5e/worktree"
os.chdir(ROOT)
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
def run_mutant(m, pkg="./internal/canonicaljson/"):
    path=m["file"]; src=open(path).read(); lines=src.split("\n"); idx=m["line"]-1
    if m["old"] not in lines[idx]:
        return ("SETUP-FAIL", m["desc"], "old %r not on line %d: %r"%(m["old"],m["line"],lines[idx][:100]))
    before=sha(path)
    lines[idx]=lines[idx].replace(m["old"],m["new"],1)
    open(path,"w").write("\n".join(lines))
    try:
        r=subprocess.run(["go","test",pkg,"-count=1"],capture_output=True,text=True,timeout=900)
        if r.returncode==0: st,det="SURVIVED","suite still ok"
        else:
            fails=[l for l in r.stdout.split("\n") if l.strip().startswith("--- FAIL")]
            if not fails and ("build failed" in r.stdout+r.stderr or "cannot use" in r.stdout+r.stderr or "syntax error" in r.stdout+r.stderr):
                st,det="COMPILE-FAIL",(r.stderr or r.stdout)[-200:]
            else:
                st,det="KILLED","; ".join(fails[:3]) or (r.stdout or r.stderr)[-200:]
    finally:
        open(path,"w").write(src)
        assert sha(path)==before, "restore failed "+path
    return (st,m["desc"],det)
ms=json.load(open(".temp/TASK-260830-8x76g1/rev14-mutants-symlink.json"))
lo,hi=int(sys.argv[1]),int(sys.argv[2])
for m in ms[lo:hi]:
    st,d,det=run_mutant(m)
    print("%-12s | %-52s | %s"%(st,d,det[:150]),flush=True)
