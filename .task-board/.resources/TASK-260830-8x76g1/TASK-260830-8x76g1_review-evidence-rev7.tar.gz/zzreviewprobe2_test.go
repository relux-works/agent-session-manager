package canonicaljson

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

// PROBE B2: worst case at the declared array maximum, inside the 5 MiB input cap.
func TestProbeManifestEntryQuadraticMax(t *testing.T) {
	const n = 65536
	entries := make([]any, 0, n)
	for i := 0; i < n; i++ {
		entries = append(entries, map[string]any{
			"path": pad(i),
			"type": "directory",
			"mode": json.Number("493"),
		})
	}
	object := validTransferManifestObject("workspace_tree")
	object["entries"] = entries
	encoded := mustJSON(t, object)
	if len(encoded) > 5_242_880 {
		t.Fatalf("PROBE-B2 payload %d bytes exceeds the 5242880 identity cap", len(encoded))
	}
	start := time.Now()
	_, _, err := CalculateObjectIdentity(encoded)
	t.Logf("PROBE-B2 n=%d bytes=%d elapsed=%s err=%v", n, len(encoded), time.Since(start), err)
}

// PROBE M: GitIndex entries case-collision / submodule scans at their maxima.
func TestProbeGitIndexScale(t *testing.T) {
	object := validGitWorkspaceGroupObject()
	member := gitWorkspaceMember(object)
	index := member["index"].(map[string]any)
	existing := index["entries"].([]any)
	const n = 60000
	entries := make([]any, 0, n+len(existing))
	for i := 0; i < n; i++ {
		entries = append(entries, map[string]any{
			"path":             "a/" + pad(i),
			"stage":            json.Number("0"),
			"mode":             json.Number("33188"),
			"oid":              "sha1:" + strings.Repeat("a", 40),
			"intent_to_add":    false,
			"skip_worktree":    false,
			"assume_unchanged": false,
			"fsmonitor_valid":  false,
		})
	}
	entries = append(entries, existing...)
	index["entries"] = entries
	index["entry_count"] = json.Number(itoa(len(entries)))
	encoded := mustJSON(t, object)
	t.Logf("PROBE-M bytes=%d", len(encoded))
	if len(encoded) > 5_242_880 {
		t.Skip("payload exceeds identity cap")
	}
	start := time.Now()
	_, _, err := CalculateObjectIdentity(encoded)
	t.Logf("PROBE-M elapsed=%s err=%v", time.Since(start), err)
}

func itoa(v int) string {
	if v == 0 {
		return "0"
	}
	digits := ""
	for v > 0 {
		digits = string(rune('0'+v%10)) + digits
		v /= 10
	}
	return digits
}
