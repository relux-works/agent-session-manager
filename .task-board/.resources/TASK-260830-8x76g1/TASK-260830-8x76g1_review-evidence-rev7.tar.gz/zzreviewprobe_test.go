package canonicaljson

import (
	"encoding/json"
	"strings"
	"testing"
	"time"
)

// PROBE A: Session Record `name` — Section 5.1 declares "Section 2.3 grammar",
// which Section 2.1 defines as 1-64 characters matching [A-Za-z0-9][A-Za-z0-9._-]{0,63}.
func TestProbeSessionRecordNameGrammar(t *testing.T) {
	cases := []struct {
		label string
		name  any
	}{
		{"leading hyphen", "-payments"},
		{"space", "payments api"},
		{"slash traversal", "../../etc/passwd"},
		{"newline control", "payments\napi"},
		{"tab control", "a\tb"},
		{"non-ascii", "платежи"},
		{"emoji", "\U0001F4A5\U0001F4A5"},
		{"1024 chars", strings.Repeat("a", 1024)},
		{"65 chars", strings.Repeat("a", 65)},
		{"shell fragment", "$(rm -rf /)"},
	}
	for _, c := range cases {
		object := validSessionRecordV1Object()
		object["name"] = c.name
		encoded := mustJSON(t, object)
		digest, field, err := CalculateObjectIdentity(encoded)
		if err == nil {
			t.Errorf("PROBE-A ATTESTED name=%s -> %s=%s", c.label, field, digest)
		} else {
			t.Logf("PROBE-A refused name=%s: %v", c.label, err)
		}
	}
}

// PROBE A2: prove it through VerifyObjectIdentity too.
func TestProbeSessionRecordNameGrammarVerify(t *testing.T) {
	object := validSessionRecordV1Object()
	object["name"] = strings.Repeat("a", 1024) + "/../escape"
	encoded := mustJSON(t, object)
	claimed := withCorrectIdentityClaimForTest(t, encoded, SelfRecordID)
	digest, field, err := VerifyObjectIdentity(claimed)
	if err == nil {
		t.Errorf("PROBE-A2 VERIFIED out-of-grammar name -> %s=%s", field, digest)
	} else {
		t.Logf("PROBE-A2 refused: %v", err)
	}
}

// PROBE B: quadratic case-collision scan over attacker-controlled entries.
func TestProbeManifestEntryQuadraticScan(t *testing.T) {
	for _, n := range []int{2000, 8000, 20000} {
		entries := make([]any, 0, n)
		for i := 0; i < n; i++ {
			entries = append(entries, map[string]any{
				"path": "d/" + pad(i),
				"type": "directory",
				"mode": json.Number("493"),
			})
		}
		object := validTransferManifestObject("workspace_tree")
		object["entries"] = entries
		encoded := mustJSON(t, object)
		start := time.Now()
		_, _, err := CalculateObjectIdentity(encoded)
		t.Logf("PROBE-B n=%d bytes=%d elapsed=%s err=%v", n, len(encoded), time.Since(start), err)
	}
}

func pad(i int) string {
	s := ""
	for _, d := range []int{1000000, 100000, 10000, 1000, 100, 10, 1} {
		s += string(rune('0' + (i/d)%10))
	}
	return s
}

// PROBE C: extensions key length bound in both directions.
func TestProbeExtensionKeyBoundary(t *testing.T) {
	mk := func(n int) string {
		key := "a" + strings.Repeat("b", 61)
		for len(key) < n-1 {
			remaining := n - len(key) - 1
			seg := 62
			if remaining < seg {
				seg = remaining
			}
			key += "." + "a" + strings.Repeat("b", seg-1)
		}
		return key
	}
	for _, n := range []int{3, 253, 254} {
		key := mk(n)
		if len(key) != n {
			t.Logf("PROBE-C skip n=%d built len=%d", n, len(key))
			continue
		}
		object := genericExtensionIdentityObject(map[string]any{key: true})
		_, _, err := CalculateObjectIdentity(mustJSON(t, object))
		t.Logf("PROBE-C key len=%d accepted=%v err=%v", n, err == nil, err)
	}
}

// PROBE D: multibyte value exactly at each character bound must be ACCEPTED.
func TestProbeCharacterBoundPositive(t *testing.T) {
	object := validGitWorkspaceGroupObject()
	gitWorkspaceMember(object)["repository_identity"] = strings.Repeat("界", 256)
	if _, _, err := CalculateObjectIdentity(mustJSON(t, object)); err != nil {
		t.Errorf("PROBE-D repository_identity 256 chars refused: %v", err)
	}
	object = validGitWorkspaceGroupObject()
	gitWorkspaceMember(object)["remotes"].([]any)[0].(map[string]any)["name"] = strings.Repeat("界", 128)
	if _, _, err := CalculateObjectIdentity(mustJSON(t, object)); err != nil {
		t.Errorf("PROBE-D remote name 128 chars refused: %v", err)
	}
}

// PROBE E: symlink target 4096 characters multibyte accepted, 4097 refused.
func TestProbeSymlinkTargetBound(t *testing.T) {
	for _, n := range []int{4096, 4097} {
		object := validTransferManifestObject("workspace_tree")
		object["entries"] = []any{map[string]any{
			"path": "link", "type": "symlink", "mode": json.Number("511"),
			"target": strings.Repeat("界", n),
		}}
		_, _, err := CalculateObjectIdentity(mustJSON(t, object))
		t.Logf("PROBE-E target chars=%d accepted=%v err=%v", n, err == nil, err)
	}
}

// PROBE F: manifest entry element type confusion.
func TestProbeManifestEntryNonObject(t *testing.T) {
	object := validTransferManifestObject("workspace_tree")
	object["entries"] = []any{"not-an-object"}
	if _, _, err := CalculateObjectIdentity(mustJSON(t, object)); err == nil {
		t.Error("PROBE-F ATTESTED a non-object manifest entry")
	}
}

// PROBE G: launch plan argv byte bound (spec says BYTES) both directions.
func TestProbeArgvByteBound(t *testing.T) {
	for _, n := range []int{4096, 4097} {
		object := validSessionRecordV1Object()
		object["launch_plan"].(map[string]any)["argv"] = []any{strings.Repeat("a", n)}
		_, _, err := CalculateObjectIdentity(mustJSON(t, object))
		t.Logf("PROBE-G argv bytes=%d accepted=%v err=%v", n, err == nil, err)
	}
	object := validSessionRecordV1Object()
	object["launch_plan"].(map[string]any)["argv"] = []any{strings.Repeat("界", 2048)}
	_, _, err := CalculateObjectIdentity(mustJSON(t, object))
	t.Logf("PROBE-G argv 2048 multibyte chars (6144 bytes) accepted=%v err=%v", err == nil, err)
}

// PROBE H: workspace_tree with EMPTY entries; spec says workspace_tree
// "contains entries and optional path-partition children".
func TestProbeWorkspaceTreeEmptyEntries(t *testing.T) {
	object := validTransferManifestObject("workspace_tree")
	_, _, err := CalculateObjectIdentity(mustJSON(t, object))
	t.Logf("PROBE-H workspace_tree with zero entries accepted=%v err=%v", err == nil, err)
}

// PROBE I: migration provenance schema_id empty string.
func TestProbeMigrationSchemaIDEmpty(t *testing.T) {
	object := genericExtensionIdentityObject(map[string]any{
		"works.relux.ax.migrated-from": map[string]any{
			"schema_id":      "",
			"schema_version": "0.9.0",
			"object_id":      digestWithDigit('6'),
		},
	})
	_, _, err := CalculateObjectIdentity(mustJSON(t, object))
	t.Logf("PROBE-I empty schema_id accepted=%v err=%v", err == nil, err)
}

// PROBE J: provider_id grammar at the boundary.
func TestProbeProviderID(t *testing.T) {
	for _, v := range []string{"Codex", "codex_x", "0codex", strings.Repeat("c", 33)} {
		object := validSessionRecordV1Object()
		object["provider_id"] = v
		_, _, err := CalculateObjectIdentity(mustJSON(t, object))
		if err == nil {
			t.Errorf("PROBE-J ATTESTED provider_id=%q", v)
		}
	}
}

// PROBE K: env_names sorted-unique and env_literals key/value rules.
func TestProbeLaunchPlanEnv(t *testing.T) {
	object := validSessionRecordV1Object()
	object["launch_plan"].(map[string]any)["env_names"] = []any{"B", "A"}
	if _, _, err := CalculateObjectIdentity(mustJSON(t, object)); err == nil {
		t.Error("PROBE-K ATTESTED unsorted env_names")
	}
	object = validSessionRecordV1Object()
	object["launch_plan"].(map[string]any)["env_literals"] = map[string]any{"OPENAI_API_KEY": "x"}
	if _, _, err := CalculateObjectIdentity(mustJSON(t, object)); err == nil {
		t.Error("PROBE-K ATTESTED env_literals key colliding with env_names")
	}
}

// PROBE L: Section 10.1 record envelope schemas now refuse entirely.
func TestProbeUnsupportedSchemaRefusal(t *testing.T) {
	object := map[string]any{
		"schema":             "urn:ax:schema:tombstone",
		"schema_version":     "1.0.0",
		"tombstone_id":       zeroDigest,
		"subject_id":         "0198f4c8-3e70-7a11-8a2b-1234567890ab",
		"created_by_host_id": "0198f4c8-4a10-7b22-8b3c-1234567890ab",
		"created_at":         "2026-08-19T04:00:00.000Z",
		"extensions":         map[string]any{},
	}
	_, _, err := CalculateObjectIdentity(mustJSON(t, object))
	t.Logf("PROBE-L tombstone identity accepted=%v err=%v", err == nil, err)
}
