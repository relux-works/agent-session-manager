import json, subprocess, sys, hashlib, os
W=os.environ["W"]; R=os.environ["R"]
P=os.path.join(W,"internal/canonicaljson/closed_shapes.go")
ORIG=os.path.join(R,"sweep/closed_shapes.go.orig")
SHA="3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"
orig=open(ORIG).read()
assert hashlib.sha256(orig.encode()).hexdigest()==SHA
lines=orig.split("\n")
muts=json.load(open(os.path.join(R,"sweep/refusal-clauses.json")))
lo,hi=int(sys.argv[1]),int(sys.argv[2])
out=open(os.path.join(R,"sweep/clause-results.tsv"),"a")
def restore():
    open(P,"w").write(orig)
    assert hashlib.sha256(open(P).read().encode()).hexdigest()==SHA
try:
    for n,m in enumerate(muts):
        if n<lo or n>=hi: continue
        mut=list(lines)
        assert mut[m["line"]-1]==m["orig"], (n,m["line"])
        mut[m["line"]-1]=m["new"]
        open(P,"w").write("\n".join(mut))
        r=subprocess.run(["go","test","./internal/canonicaljson/","-count=1"],capture_output=True,text=True,cwd=W)
        blob=r.stdout+r.stderr
        st="COMPILEFAIL" if ("build failed" in blob or "syntax error" in blob or "[build failed]" in blob) else ("SURVIVED" if r.returncode==0 else "KILLED")
        line=f"{n}\tline{m['line']}\t{st}\t{m['cond']}"
        print(line, flush=True); print(line, file=out, flush=True)
finally:
    restore()
