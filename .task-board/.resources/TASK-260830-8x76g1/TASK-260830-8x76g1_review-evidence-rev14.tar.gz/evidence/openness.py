import re, subprocess, hashlib, sys
PATH="internal/canonicaljson/closed_shapes.go"
ORIG=".temp/TASK-260830-8x76g1-review14/closed_shapes.go.orig"
SHA="3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"
orig=open(ORIG).read()
assert hashlib.sha256(orig.encode()).hexdigest()==SHA
lines=orig.split("\n")
sites=[(i,l) for i,l in enumerate(lines) if "requireExactMembers(" in l and not l.strip().startswith("func requireExactMembers")]
HELPER = '''
func requireOpenMembers(name string, object map[string]any, members ...string) error {
	for _, member := range members {
		if _, ok := object[member]; !ok {
			return invalidIdentity("%s is missing required member %q", name, member)
		}
	}
	return nil
}
'''
def restore():
    open(PATH,"w").write(orig)
    assert hashlib.sha256(open(PATH).read().encode()).hexdigest()==SHA
try:
    for i,l in sites:
        mut=list(lines)
        mut[i]=l.replace("requireExactMembers(","requireOpenMembers(",1)
        src="\n".join(mut)+HELPER
        open(PATH,"w").write(src)
        r=subprocess.run(["go","test","./internal/canonicaljson/","-count=1","-skip","TestConstraintEnumerationMatchesRequireExactMembers"],capture_output=True,text=True)
        blob=r.stdout+r.stderr
        if "build failed" in blob or "syntax error" in blob:
            st="COMPILEFAIL"
        elif r.returncode==0:
            st="SURVIVED"
        else:
            st="KILLED"
        tag=l.strip()[:80]
        print(f"line{i+1}\t{st}\t{tag}", flush=True)
finally:
    restore()
