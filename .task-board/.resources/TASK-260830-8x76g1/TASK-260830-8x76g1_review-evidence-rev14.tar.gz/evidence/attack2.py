import subprocess, hashlib
P="internal/canonicaljson/closed_shapes.go"
ORIG=".temp/TASK-260830-8x76g1-review14/closed_shapes.go.orig"
SHA="3d34cb52cb483e513a8ba398ed351993a02c46c01d5f4086af083f038304b307"
orig=open(ORIG).read()
muts=[
 ("simpleFoldKey -> identity",
  "func simpleFoldKey(value string) string {\n\tvar folded strings.Builder",
  "func simpleFoldKey(value string) string {\n\tif true { return value }\n\tvar folded strings.Builder"),
 ("line888 EqualFold -> ==",
  'if strings.EqualFold(groupPath, previousPath) {',
  'if groupPath == previousPath {'),
 ("line1231 EqualFold -> ==",
  'if strings.EqualFold(pathValue, previous) {',
  'if pathValue == previous {'),
 ("symlinkTargetEscapes -> always false",
  "func symlinkTargetEscapes(entryPath, target string) bool {\n\tif strings.ContainsRune",
  "func symlinkTargetEscapes(entryPath, target string) bool {\n\tif true { return false }\n\tif strings.ContainsRune"),
 ("drop dotdot-escape resolution clause",
  'return resolved == ".." || strings.HasPrefix(resolved, "../")',
  'return false && (resolved == ".." || strings.HasPrefix(resolved, "../"))'),
 ("requireExactString -> accept any string",
  None, None),
]
def restore():
    open(P,"w").write(orig)
    assert hashlib.sha256(open(P).read().encode()).hexdigest()==SHA
try:
    for desc,old,new in muts:
        if old is None: continue
        assert orig.count(old)==1, (desc, orig.count(old))
        open(P,"w").write(orig.replace(old,new,1))
        r=subprocess.run(["go","test","./internal/canonicaljson/","-count=1"],capture_output=True,text=True)
        blob=r.stdout+r.stderr
        st="COMPILEFAIL" if ("build failed" in blob or "syntax error" in blob) else ("SURVIVED" if r.returncode==0 else "KILLED")
        print(f"{st}\t{desc}", flush=True)
finally:
    restore()
