import subprocess, sys, hashlib, os, json
ROOT = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2wdm5e/worktree"
os.chdir(ROOT)
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
for m in json.load(open(sys.argv[1])):
    edits = m["edits"]; files = sorted({e["file"] for e in edits})
    orig = {f: open(f).read() for f in files}
    before = {f: sha(f) for f in files}
    ok = True; msg = ""
    cur = {f: orig[f].split("\n") for f in files}
    for e in edits:
        L = cur[e["file"]]; i = e["line"]-1
        if e["old"] not in L[i]:
            ok = False; msg = "old not on %s:%d -> %r" % (e["file"], e["line"], L[i][:100]); break
        L[i] = L[i].replace(e["old"], e["new"], 1)
    if not ok:
        print("%-9s | %-52s | %s" % ("SETUP-FAIL", m["desc"], msg), flush=True); continue
    for f in files: open(f,"w").write("\n".join(cur[f]))
    try:
        r = subprocess.run(["go","test",m.get("pkg","./internal/canonicaljson/"),"-count=1"], capture_output=True, text=True, timeout=600)
        if r.returncode == 0: status, detail = "SURVIVED", "suite still ok"
        else:
            fails=[l for l in r.stdout.split("\n") if l.strip().startswith("--- FAIL")]
            status, detail = "KILLED", "; ".join(fails[:3]) or (r.stdout[-250:] or r.stderr[-250:])
    finally:
        for f in files:
            open(f,"w").write(orig[f]); assert sha(f)==before[f]
    print("%-9s | %-52s | %s" % (status, m["desc"], detail[:165]), flush=True)
