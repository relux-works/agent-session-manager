import subprocess, sys, hashlib, os, json

ROOT = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2wdm5e/worktree"
os.chdir(ROOT)

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()

def run_mutant(path, line, old, new, desc, pkg="./internal/canonicaljson/"):
    src = open(path).read()
    lines = src.split("\n")
    idx = line-1
    if old not in lines[idx]:
        return (desc, "SETUP-FAIL", "old text not on line %d: %r" % (line, lines[idx][:120]))
    before = sha(path)
    lines[idx] = lines[idx].replace(old, new, 1)
    open(path,"w").write("\n".join(lines))
    try:
        r = subprocess.run(["go","test",pkg,"-count=1"], capture_output=True, text=True, timeout=600)
        if r.returncode == 0:
            status = "SURVIVED"
            detail = "suite still ok"
        else:
            # capture which tests failed
            fails = [l for l in r.stdout.split("\n") if l.strip().startswith("--- FAIL")]
            status = "KILLED"
            detail = "; ".join(fails[:4]) or (r.stdout[-300:] if r.stdout else r.stderr[-300:])
    finally:
        open(path,"w").write(src)
        assert sha(path) == before, "restore failed for "+path
    return (desc, status, detail)

MUTANTS = json.load(open(sys.argv[1]))
for m in MUTANTS:
    d,s,det = run_mutant(m["file"], m["line"], m["old"], m["new"], m["desc"], m.get("pkg","./internal/canonicaljson/"))
    print("%-9s | %-52s | %s" % (s, d, det[:170]), flush=True)
