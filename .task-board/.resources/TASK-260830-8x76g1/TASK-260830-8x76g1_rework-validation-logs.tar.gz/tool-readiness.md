# Tool readiness

- `task-board --version`: exit 0; version `0.24.3-174-g3998c779`.
- `go version`: exit 0; `go1.25.5 darwin/arm64`.
- `rg --version`: exit 0; ripgrep `15.2.0` with PCRE2.
- `git status --short --branch`: exit 0; Story workspace contains inherited uncommitted work, including the prior candidate for this task. No existing changes were reset or discarded.
- Initial compact board projection used an unsupported `acceptanceCriteria` field and exited 1; the corrected task-specific projection using `ac` exited 0.

This file records readiness only. Gate results are captured separately from standalone commands.
