import re, json
path="internal/canonicaljson/closed_shapes.go"
lines=open(path).read().split("\n")
mutants=[]
def add(line, old, new, desc):
    mutants.append({"file":path,"line":line,"old":old,"new":new,"desc":desc})

# 1. regex quantifier upper bounds {0,N} -> {0,N+1}
for i,l in enumerate(lines,1):
    for m in re.finditer(r'\{0,(\d+)\}', l):
        n=int(m.group(1))
        add(i, "{0,%d}"%n, "{0,%d}"%(n+1), "line%d regex {0,%d}->{0,%d}"%(i,n,n+1))

# 2. numeric comparison bounds:  > N  -> > N+1 ;  < N -> < N-1 ; >= N -> >= N+1 ; <= N -> <= N+1
for i,l in enumerate(lines,1):
    s=l.strip()
    if s.startswith("//"): continue
    for m in re.finditer(r'([<>]=?)\s*([0-9][0-9_]*)\b', l):
        op,num=m.group(1),m.group(2)
        val=int(num.replace("_",""))
        if op==">":  nv=val+1
        elif op==">=": nv=val+1
        elif op=="<": nv=val-1
        elif op=="<=": nv=val-1
        else: continue
        # preserve underscore formatting roughly
        newnum=str(nv)
        if "_" in num:
            newnum="{:_}".format(nv)
        add(i, m.group(0), m.group(0).replace(num,newnum), "line%d %s -> %s%s"%(i, m.group(0).strip(), op, newnum))

# 3. helper-call bounds: requireArray(x,"k",N) requireBoundedString(x,"k",lo,hi) requireUint(x,"k",N) requireSortedUniquePaths(x,"k",N) requirePrintableByteBoundedString
for i,l in enumerate(lines,1):
    s=l.strip()
    if s.startswith("//"): continue
    m=re.search(r'require(Array|Uint|SortedUniquePaths)\([^,]+,\s*"([a-z_]+)"\s*,\s*([0-9][0-9_]*|1<<32-1|4095)\s*\)', l)
    if m:
        num=m.group(3)
        if num in ("1<<32-1",):
            add(i, "1<<32-1", "1<<32", "line%d %s %s uint32 max -> 1<<32"%(i,m.group(1),m.group(2)))
        else:
            val=int(num.replace("_",""))
            newnum="{:_}".format(val+1) if "_" in num else str(val+1)
            add(i, '"%s", %s'%(m.group(2),num), '"%s", %s'%(m.group(2),newnum), "line%d %s %s %s->%s"%(i,m.group(1),m.group(2),num,newnum))
    m2=re.search(r'require(?:Printable)?(?:Byte)?BoundedString\([^,]+,\s*"([a-z_]+)"\s*,\s*(\d+)\s*,\s*([0-9][0-9_]*)\s*\)', l)
    if m2:
        lo,hi=m2.group(2),m2.group(3)
        hval=int(hi.replace("_",""))
        newhi="{:_}".format(hval+1) if "_" in hi else str(hval+1)
        add(i, '"%s", %s, %s'%(m2.group(1),lo,hi), '"%s", %s, %s'%(m2.group(1),lo,newhi), "line%d bounded %s max %s->%s"%(i,m2.group(1),hi,newhi))
        if lo!="0":
            add(i, '"%s", %s, %s'%(m2.group(1),lo,hi), '"%s", %s, %s'%(m2.group(1),int(lo)-1,hi), "line%d bounded %s min %s->%s"%(i,m2.group(1),lo,int(lo)-1))

# 4. constants
for i,l in enumerate(lines,1):
    m=re.match(r'\s*(maxBlobChunks|maxChunkSize)\s*=\s*([0-9_]+)', l)
    if m:
        val=int(m.group(2).replace("_",""))
        add(i, m.group(2), "{:_}".format(val+1), "const %s %s -> +1"%(m.group(1), m.group(2)))

# 5. equality/zero guards -> disable (widening by removing the refusal)
for i,l in enumerate(lines,1):
    s=l.strip()
    if s.startswith("//"): continue
    for pat,desc in [(r'if len\(([a-zA-Z]+)\) == 0 \{', "drop non-empty guard"),
                     (r'if size == 0 \{', "drop chunk zero-size guard"),
                     (r'if revision == 0 \{', "drop revision zero guard")]:
        m=re.search(pat,l)
        if m:
            add(i, "if ", "if false && ", "line%d %s: %s"%(i,desc,s[:60]))
            break

seen=set(); out=[]
for m in mutants:
    k=(m["line"],m["old"],m["new"])
    if k in seen: continue
    seen.add(k); out.append(m)
json.dump(out, open("/tmp/mutants-all.json","w"), indent=0)
print("generated", len(out))
for m in out: print(m["line"], "|", m["desc"])
