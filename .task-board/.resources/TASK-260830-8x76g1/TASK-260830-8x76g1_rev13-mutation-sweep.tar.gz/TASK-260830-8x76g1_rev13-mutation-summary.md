# TASK-260830-8x76g1 rev13 mutation summary

## Harness

- Generator: CR revision 12 `genmutants.py`
- Production source: `internal/canonicaljson/closed_shapes.go`
- Generated core mutants: 71
- Reviewer symlink mutants: 4
- Total: 75
- Test command per mutant: `go test ./internal/canonicaljson/ -count=1`

## Result

| Classification | Count |
| --- | ---: |
| Killed | 59 |
| Raw survived | 16 |
| Actionable survived | 0 |

The newly required mutants all changed from survived to killed:

1. `maxBlobChunks` declaration `32768 -> 32769`
2. absolute-target symlink refusal removal
3. NUL-target symlink refusal removal
4. drive-root guard `>= 2 -> >= 3`
5. ManifestEntry sortedness `index > 0 -> index > 1`
6. WorkspaceSnapshot sortedness `index > 0 -> index > 1`

The raw survivor lines are retained verbatim in the attached batch logs. They
match the non-actionable set independently classified in the CR revision 12
verdict: error-message-only mutation, stricter-regex and traversal-cap
subsumption, BlobChunk positional/coverage subsumption, and broad mechanical
mutants whose independent public-entry boundary mutant is killed. No setup or
compile failure occurred, and no new actionable survivor appeared.
