package canonicaljson

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"math"
	"strconv"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/catalog"
)

const zeroDigest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"

func TestCanonicalizeMatchesPublishedRFC8785PrimitiveAndStringVector(t *testing.T) {
	input := []byte(`{
  "numbers": [333333333.33333329, 1E30, 4.50, 2e-3, 0.000000000000000000000000001],
  "string": "\u20ac$\u000F\u000aA'\u0042\u0022\u005c\\\"\/",
  "literals": [null, true, false]
}`)
	want := `{"literals":[null,true,false],"numbers":[333333333.3333333,1e+30,4.5,0.002,1e-27],"string":"€$\u000f\nA'B\"\\\\\"/"}`

	got, err := Canonicalize(input)
	if err != nil {
		t.Fatalf("Canonicalize(RFC 8785 Section 3.2.2 vector) error = %v", err)
	}
	if string(got) != want {
		t.Fatalf("Canonicalize(RFC 8785 Section 3.2.2 vector) = %q, want %q", got, want)
	}

	again, err := Canonicalize(got)
	if err != nil || string(again) != want {
		t.Fatalf("Canonicalize(canonical vector) = %q, %v; want identical %q", again, err, want)
	}

	primitive, err := Canonicalize([]byte(" \n -0 \t"))
	if err != nil || string(primitive) != "0" {
		t.Fatalf("Canonicalize(whitespace-wrapped minus zero) = %q, %v; want RFC value 0", primitive, err)
	}
}

func TestCanonicalizeMatchesEveryFiniteRFC8785AppendixBNumberSample(t *testing.T) {
	vectors := []struct {
		bits uint64
		want string
	}{
		{0x0000000000000000, "0"},
		{0x8000000000000000, "0"},
		{0x0000000000000001, "5e-324"},
		{0x8000000000000001, "-5e-324"},
		{0x7fefffffffffffff, "1.7976931348623157e+308"},
		{0xffefffffffffffff, "-1.7976931348623157e+308"},
		{0x4340000000000000, "9007199254740992"},
		{0xc340000000000000, "-9007199254740992"},
		{0x4430000000000000, "295147905179352830000"},
		{0x44b52d02c7e14af5, "9.999999999999997e+22"},
		{0x44b52d02c7e14af6, "1e+23"},
		{0x44b52d02c7e14af7, "1.0000000000000001e+23"},
		{0x444b1ae4d6e2ef4e, "999999999999999700000"},
		{0x444b1ae4d6e2ef4f, "999999999999999900000"},
		{0x444b1ae4d6e2ef50, "1e+21"},
		{0x3eb0c6f7a0b5ed8c, "9.999999999999997e-7"},
		{0x3eb0c6f7a0b5ed8d, "0.000001"},
		{0x41b3de4355555553, "333333333.3333332"},
		{0x41b3de4355555554, "333333333.33333325"},
		{0x41b3de4355555555, "333333333.3333333"},
		{0x41b3de4355555556, "333333333.3333334"},
		{0x41b3de4355555557, "333333333.33333343"},
		{0xbecbf647612f3696, "-0.0000033333333333333333"},
		{0x43143ff3c1cb0959, "1424953923781206.2"},
	}

	for _, vector := range vectors {
		name := fmt.Sprintf("%016x", vector.bits)
		t.Run(name, func(t *testing.T) {
			value := math.Float64frombits(vector.bits)
			input := strconv.FormatFloat(value, 'g', -1, 64)
			got, err := Canonicalize([]byte(input))
			if err != nil {
				t.Fatalf("Canonicalize(%q) error = %v", input, err)
			}
			if string(got) != vector.want {
				t.Fatalf("Canonicalize(%q) = %q, want RFC Appendix B %q", input, got, vector.want)
			}
		})
	}

	if _, err := Canonicalize([]byte("1e999")); err == nil {
		t.Fatal("Canonicalize(out-of-range number) error = nil, want I-JSON refusal")
	}
}

func TestCanonicalizeUsesRFC8785UTF16PropertyOrdering(t *testing.T) {
	input := []byte(`{
  "\u20ac": "Euro Sign",
  "\r": "Carriage Return",
  "\ufb33": "Hebrew Letter Dalet With Dagesh",
  "1": "One",
  "\ud83d\ude00": "Emoji: Grinning Face",
  "\u0080": "Control",
  "\u00f6": "Latin Small Letter O With Diaeresis"
}`)
	want := `{"\r":"Carriage Return","1":"One","":"Control","ö":"Latin Small Letter O With Diaeresis","€":"Euro Sign","😀":"Emoji: Grinning Face","דּ":"Hebrew Letter Dalet With Dagesh"}`

	got, err := Canonicalize(input)
	if err != nil {
		t.Fatalf("Canonicalize(RFC 8785 Section 3.2.3 vector) error = %v", err)
	}
	if string(got) != want {
		t.Fatalf("Canonicalize(RFC 8785 Section 3.2.3 vector) = %q, want %q", got, want)
	}
}

func TestCalculateObjectIdentityOmitsEveryGeneratedV050SelfIdentityContract(t *testing.T) {
	definitions := catalog.Current().SelfIdentities
	if len(definitions) == 0 {
		t.Fatal("generated v0.5.0 self-identity catalog is empty")
	}
	rows := 0
	for _, definition := range definitions {
		for _, version := range definition.ContractVersions {
			rows++
			testName := string(definition.ContractID) + "@" + version
			t.Run(testName, func(t *testing.T) {
				extra := ""
				if definition.DiscriminatorName != "" {
					extra = fmt.Sprintf("%q:%q,", definition.DiscriminatorName, definition.DiscriminatorValue)
				}
				selfField := SelfField(definition.SelfField)
				input := []byte(fmt.Sprintf(
					`{"schema":%q,"schema_version":%q,%s"%s":"%s","a":1}`,
					definition.ContractID,
					version,
					extra,
					selfField,
					zeroDigest,
				))
				got, gotField, err := CalculateObjectIdentity(input)
				if err != nil {
					t.Fatalf("CalculateObjectIdentity(%s) error = %v", testName, err)
				}
				omitted := fmt.Sprintf(`{"a":1,%s"schema":%q,"schema_version":%q}`, extra, definition.ContractID, version)
				want := digestHex(omitted)
				if gotField != selfField || got.String() != want {
					t.Fatalf("CalculateObjectIdentity(%s) = %q, %q; want %q, %q", testName, got, gotField, want, selfField)
				}
			})
		}
	}
	if rows != len(schemaIdentityContracts) {
		t.Fatalf("production self-identity table has %d rows, generated catalog defines %d", len(schemaIdentityContracts), rows)
	}
}

func TestCalculateObjectIdentitySupportsAdditionalTerminalCloneAndRegistryContracts(t *testing.T) {
	tests := []struct {
		schema    string
		selfField SelfField
	}{
		{"urn:ax:schema:terminal-backend-probe", SelfProbeID},
		{"urn:ax:schema:terminal-instance-binding", SelfBindingID},
		{"urn:ax:schema:terminal-capability-evidence", SelfEvidenceID},
		{"urn:ax:schema:clone-raw-object-manifest", SelfRawObjectManifestID},
		{"urn:ax:schema:clone-capture-manifest", SelfCaptureManifestID},
		{"urn:ax:schema:canonical-session", SelfCanonicalSessionID},
		{"urn:ax:schema:fidelity-report", SelfFidelityReportID},
		{"urn:ax:schema:projection-plan", SelfProjectionPlanID},
		{"urn:ax:schema:clone-projected-object-manifest", SelfProjectedObjectManifestID},
		{"urn:ax:schema:clone-read-back-evidence-manifest", SelfReadBackEvidenceManifestID},
		{"urn:ax:schema:clone-validation-report", SelfValidationReportID},
		{"urn:ax:schema:migration-checkpoint", SelfMigrationCheckpointID},
		{"urn:ax:schema:clone-lineage-receipt", SelfLineageReceiptID},
		{"urn:ax:schema:supported-environment-tuples", SelfRegistryDigest},
	}
	for _, test := range tests {
		t.Run(test.schema, func(t *testing.T) {
			input := []byte(fmt.Sprintf(
				`{"schema":%q,"schema_version":"1.0.0","%s":"%s","referenced_id":"%s"}`,
				test.schema,
				test.selfField,
				zeroDigest,
				"sha256:1111111111111111111111111111111111111111111111111111111111111111",
			))
			if _, gotField, err := CalculateObjectIdentity(input); err != nil || gotField != test.selfField {
				t.Fatalf("CalculateObjectIdentity(%s) field = %q, error = %v; want %q", test.schema, gotField, err, test.selfField)
			}
		})
	}
}

func TestSelfIdentityCompletenessRejectsDeletedImplementationContract(t *testing.T) {
	definitions := catalog.Current().SelfIdentities
	narrowed := make(map[schemaIdentityKey]schemaIdentityContract, len(schemaIdentityContracts))
	for key, contract := range schemaIdentityContracts {
		narrowed[key] = contract
	}
	deleted := schemaIdentityKey{schema: "urn:ax:schema:canonical-session", version: "1.0.0"}
	delete(narrowed, deleted)

	err := validateSchemaIdentityContracts(narrowed, definitions)
	if err == nil || !strings.Contains(err.Error(), "missing self-identity contract for urn:ax:schema:canonical-session@1.0.0") {
		t.Fatalf("validateSchemaIdentityContracts(deleted canonical-session row) error = %v, want exact missing-row refusal", err)
	}
}

func TestCalculateObjectIdentityAcceptsEveryRegisteredVersionForMultiVersionSchemas(t *testing.T) {
	tests := []struct {
		schema    string
		versions  []string
		selfField SelfField
	}{
		{"urn:ax:schema:session-record", []string{"1.0.0", "2.0.0", "3.0.0"}, SelfRecordID},
		{"urn:ax:schema:session-event", []string{"1.0.0", "2.0.0", "3.0.0", "4.0.0"}, SelfEventID},
		{"urn:ax:schema:materialization-plan", []string{"1.0.0", "2.0.0"}, SelfPlanID},
	}
	for _, test := range tests {
		for _, version := range test.versions {
			name := test.schema + "@" + version
			t.Run(name, func(t *testing.T) {
				input := []byte(fmt.Sprintf(
					`{"schema":%q,"schema_version":%q,"%s":"%s"}`,
					test.schema,
					version,
					test.selfField,
					zeroDigest,
				))
				if _, gotField, err := CalculateObjectIdentity(input); err != nil || gotField != test.selfField {
					t.Fatalf("CalculateObjectIdentity(%s) field = %q, error = %v; want %q", name, gotField, err, test.selfField)
				}
			})
		}
	}
}

func TestCalculateObjectIdentityUsesSchemaDefinedSelfFieldWithRegisteredReferences(t *testing.T) {
	referenceA := "sha256:1111111111111111111111111111111111111111111111111111111111111111"
	referenceB := "sha256:2222222222222222222222222222222222222222222222222222222222222222"
	tests := []struct {
		name      string
		selfField SelfField
		input     string
		omitted   string
	}{
		{
			"Session Annotation",
			SelfAnnotationID,
			`{"schema":"urn:ax:schema:session-annotation","schema_version":"1.0.0","annotation_id":"` + zeroDigest + `","profile_id":"` + referenceA + `"}`,
			`{"profile_id":"` + referenceA + `","schema":"urn:ax:schema:session-annotation","schema_version":"1.0.0"}`,
		},
		{
			"Enrichment Job Request",
			SelfJobRequestID,
			`{"schema":"urn:ax:schema:session-enrichment-job-request","schema_version":"1.0.0","job_request_id":"` + zeroDigest + `","profile_id":"` + referenceA + `"}`,
			`{"profile_id":"` + referenceA + `","schema":"urn:ax:schema:session-enrichment-job-request","schema_version":"1.0.0"}`,
		},
		{
			"Enrichment Job Receipt",
			SelfJobReceiptID,
			`{"schema":"urn:ax:schema:session-enrichment-job-receipt","schema_version":"1.0.0","job_receipt_id":"` + zeroDigest + `","job_request_id":"` + referenceA + `","profile_id":"` + referenceB + `"}`,
			`{"job_request_id":"` + referenceA + `","profile_id":"` + referenceB + `","schema":"urn:ax:schema:session-enrichment-job-receipt","schema_version":"1.0.0"}`,
		},
		{
			"Directory Operation Receipt",
			SelfDirectoryReceiptID,
			`{"schema":"urn:ax:schema:session-directory-operation-receipt","schema_version":"1.0.0","directory_receipt_id":"` + zeroDigest + `","plan_id":"` + referenceA + `"}`,
			`{"plan_id":"` + referenceA + `","schema":"urn:ax:schema:session-directory-operation-receipt","schema_version":"1.0.0"}`,
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			calculated, gotField, err := CalculateObjectIdentity([]byte(test.input))
			if err != nil {
				t.Fatalf("CalculateObjectIdentity(%s with registered references) error = %v", test.name, err)
			}
			want := digestHex(test.omitted)
			if gotField != test.selfField || calculated.String() != want {
				t.Fatalf("CalculateObjectIdentity(%s) = %q, %q; want schema self field %q and %q", test.name, calculated, gotField, test.selfField, want)
			}

			claimed := strings.Replace(test.input, zeroDigest, calculated.String(), 1)
			verified, verifiedField, err := VerifyObjectIdentity([]byte(claimed))
			if err != nil || verified != calculated || verifiedField != test.selfField {
				t.Fatalf("VerifyObjectIdentity(%s with registered references) = %q, %q, %v", test.name, verified, verifiedField, err)
			}
		})
	}
}

func TestCalculateObjectIdentityMatchesAXPublishedFixtures(t *testing.T) {
	t.Run("safe integer maximum", func(t *testing.T) {
		input := []byte(`{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","record_id":"` + zeroDigest + `","n":9007199254740991}`)
		got, _, err := CalculateObjectIdentity(input)
		want := digestHex(`{"n":9007199254740991,"schema":"urn:ax:schema:session-record","schema_version":"1.0.0"}`)
		if err != nil || got.String() != want {
			t.Fatalf("CalculateObjectIdentity(NUM-SAFE-MAX) = %q, %v", got, err)
		}
	})

	t.Run("UTF-16 order", func(t *testing.T) {
		input := []byte(`{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","record_id":"` + zeroDigest + `","\uE000":1,"\uD800\uDC00":2}`)
		got, _, err := CalculateObjectIdentity(input)
		want := digestHex(`{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","𐀀":2,"":1}`)
		if err != nil || got.String() != want {
			t.Fatalf("CalculateObjectIdentity(JCS-UTF16-ORDER) = %q, %v", got, err)
		}
	})

	t.Run("Blob Descriptor", func(t *testing.T) {
		input := []byte(`{
  "schema": "urn:ax:schema:blob",
  "schema_version": "1.0.0",
  "descriptor_id": "sha256:390c8f21900483a010c1cbc3f9be01afebcf6e4da87263ba09fc5776dd6503ee",
  "blob_id": "sha256:9c21bad65c1b3d0403ac85d7d5bd134bb8d894432702a396a77b0477b8eb3b50",
  "size": 11,
  "media_type": "application/octet-stream",
  "chunks": [{
    "index": 0,
    "offset": 0,
    "size": 11,
    "chunk_id": "sha256:9c21bad65c1b3d0403ac85d7d5bd134bb8d894432702a396a77b0477b8eb3b50"
  }]
}`)
		got, field, err := VerifyObjectIdentity(input)
		if err != nil || field != SelfDescriptorID || got.Hex() != "390c8f21900483a010c1cbc3f9be01afebcf6e4da87263ba09fc5776dd6503ee" {
			t.Fatalf("VerifyObjectIdentity(Blob Descriptor) = %q, %q, %v", got, field, err)
		}
	})
}

func TestObjectIdentityIsStableAcrossRepresentationAndClaimChanges(t *testing.T) {
	first := []byte(`{"z":[{"b":2,"a":1}],"record_id":"` + zeroDigest + `","schema":"urn:ax:schema:session-record","schema_version":"1.0.0"}`)
	calculated, field, err := CalculateObjectIdentity(first)
	if err != nil {
		t.Fatalf("CalculateObjectIdentity(first) error = %v", err)
	}
	second := []byte(" { \n  \"schema_version\" : \"1.0.0\", \"schema\" : \"urn:ax:schema:session-record\", \"record_id\" : \"" + calculated.String() + "\", \"z\" : [ { \"a\" : 1, \"b\" : 2 } ] } \n")
	recalculated, secondField, err := CalculateObjectIdentity(second)
	if err != nil || recalculated != calculated || secondField != field {
		t.Fatalf("CalculateObjectIdentity(reordered) = %q, %q, %v; want %q, %q", recalculated, secondField, err, calculated, field)
	}
	verified, verifiedField, err := VerifyObjectIdentity(second)
	if err != nil || verified != calculated || verifiedField != SelfRecordID {
		t.Fatalf("VerifyObjectIdentity(reordered) = %q, %q, %v", verified, verifiedField, err)
	}
	for attempt := 0; attempt < 3; attempt++ {
		again, _, err := CalculateObjectIdentity(second)
		if err != nil || again != calculated {
			t.Fatalf("CalculateObjectIdentity idempotent attempt %d = %q, %v; want %q", attempt, again, err, calculated)
		}
	}
}

func TestObjectIdentityRefusesSelfInclusionAndAmbiguousNamespaces(t *testing.T) {
	placeholder := []byte(`{"record_id":"` + zeroDigest + `","schema":"urn:ax:schema:session-record","schema_version":"1.0.0","value":1}`)
	fullCanonical, err := Canonicalize(placeholder)
	if err != nil {
		t.Fatalf("Canonicalize(self-inclusion setup) error = %v", err)
	}
	selfIncludedClaim := digestHex(string(fullCanonical))
	selfIncluded := []byte(strings.Replace(string(placeholder), zeroDigest, selfIncludedClaim, 1))
	if _, _, err := VerifyObjectIdentity(selfIncluded); err == nil || !errors.Is(err, ErrInvalidIdentity) {
		t.Fatalf("VerifyObjectIdentity(self-included claim) error = %v, want identity refusal", err)
	}

	cases := []struct {
		name  string
		input string
	}{
		{"absent schema", `{"schema_version":"1.0.0","record_id":"` + zeroDigest + `"}`},
		{"absent schema version", `{"schema":"urn:ax:schema:session-record","record_id":"` + zeroDigest + `"}`},
		{"unsupported schema", `{"schema":"urn:ax:schema:unknown","schema_version":"1.0.0","record_id":"` + zeroDigest + `"}`},
		{"unsupported schema version", `{"schema":"urn:ax:schema:session-record","schema_version":"999.0.0","record_id":"` + zeroDigest + `"}`},
		{"absent schema-defined self field", `{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","event_id":"` + zeroDigest + `"}`},
		{"raw chunk identity", `{"schema":"urn:ax:schema:chunk","schema_version":"1.0.0","chunk_id":"` + zeroDigest + `","size":1}`},
		{"mutable journal variant", `{"schema":"urn:ax:schema:materialization-journal","schema_version":"2.0.0","document_kind":"journal","marker_id":"` + zeroDigest + `"}`},
		{"non-digest claim", `{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","record_id":"not-a-digest","value":1}`},
	}
	for _, test := range cases {
		t.Run(test.name, func(t *testing.T) {
			if _, _, err := CalculateObjectIdentity([]byte(test.input)); err == nil || !errors.Is(err, ErrInvalidIdentity) {
				t.Fatalf("CalculateObjectIdentity(%s) error = %v, want identity refusal", test.name, err)
			}
		})
	}
}

func TestProductionEntriesRejectAmbiguousOrInvalidInput(t *testing.T) {
	canonicalCases := []struct {
		name  string
		input []byte
	}{
		{"duplicate member", []byte(`{"a":1,"\u0061":2}`)},
		{"lone high surrogate", []byte(`{"a":"\ud800"}`)},
		{"lone low surrogate", []byte(`{"a":"\udc00"}`)},
		{"mismatched surrogate", []byte(`{"a":"\ud800\u0041"}`)},
		{"invalid UTF-8", []byte{'{', '"', 'a', '"', ':', '"', 0xff, '"', '}'}},
	}
	for _, test := range canonicalCases {
		t.Run(test.name, func(t *testing.T) {
			if _, err := Canonicalize(test.input); err == nil || !errors.Is(err, ErrInvalidJSON) {
				t.Fatalf("Canonicalize(%s) error = %v, want invalid JSON refusal", test.name, err)
			}
		})
	}

	identityCases := []struct {
		name   string
		number string
	}{
		{"unsafe positive boundary", "9007199254740992"},
		{"unsafe negative boundary", "-9007199254740992"},
		{"rounded unsafe integer", "9007199254740993"},
		{"floating point", "1.0"},
		{"exponent", "1e3"},
	}
	for _, test := range identityCases {
		t.Run(test.name, func(t *testing.T) {
			input := []byte(`{"schema":"urn:ax:schema:session-record","schema_version":"1.0.0","record_id":"` + zeroDigest + `","n":` + test.number + `}`)
			if _, _, err := CalculateObjectIdentity(input); err == nil || !errors.Is(err, ErrInvalidIdentity) {
				t.Fatalf("CalculateObjectIdentity(%s) error = %v, want common-model refusal", test.name, err)
			}
		})
	}
}

func digestHex(value string) string {
	digest := sha256.Sum256([]byte(value))
	return "sha256:" + hex.EncodeToString(digest[:])
}
