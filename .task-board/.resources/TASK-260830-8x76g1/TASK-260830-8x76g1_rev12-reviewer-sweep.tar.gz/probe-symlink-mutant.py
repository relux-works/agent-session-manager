import subprocess, hashlib, os
ROOT="/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2wdm5e/worktree"
os.chdir(ROOT)
P="internal/canonicaljson/closed_shapes.go"
T="internal/canonicaljson/zz_probe_test.go"
src=open(P).read(); before=hashlib.sha256(src.encode()).hexdigest()
probe=r'''package canonicaljson

import (
	"encoding/json"
	"testing"
)

func TestReviewerProbeSymlinkEscapeClauses(t *testing.T) {
	targets := []string{"/etc/passwd", "no" + string(rune(0)) + "ol", "C:"}
	for _, target := range targets {
		object := validTransferManifestObject("workspace_tree")
		object["entries"] = []any{map[string]any{
			"path": "link", "type": "symlink", "mode": json.Number("511"), "target": target,
		}}
		encoded, err := json.Marshal(object)
		if err != nil {
			t.Fatalf("marshal: %v", err)
		}
		_, _, calcErr := CalculateObjectIdentity(encoded)
		t.Logf("target=%q calculate_err=%v", target, calcErr)
	}
}
'''
open(T,"w").write(probe)
lines=src.split("\n")
lines[844]=lines[844].replace('strings.ContainsRune(target, 0)','strings.ContainsRune(target, 1)').replace('strings.HasPrefix(target, "/")','strings.HasPrefix(target, "\\u0001")')
lines[845]=lines[845].replace('len(target) >= 2','len(target) >= 3')
open(P,"w").write("\n".join(lines))
r=subprocess.run(["go","test","./internal/canonicaljson/","-run","TestReviewerProbeSymlinkEscapeClauses","-count=1","-v"],capture_output=True,text=True)
print("### MUTANT: NUL clause -> rune(1); absolute '/' -> U+0001 prefix; drive guard >=2 -> >=3")
print("rc=%d"%r.returncode); print((r.stdout or "")[-2000:]); print((r.stderr or "")[:600])
print("### SAME MUTANT, WHOLE REPOSITORY SUITE")
os.remove(T)
r2=subprocess.run(["go","test","./...","-count=1"],capture_output=True,text=True)
print("rc=%d"%r2.returncode); print(r2.stdout[-700:])
open(P,"w").write(src)
assert hashlib.sha256(open(P,'rb').read()).hexdigest()==before
print("restored ok")
