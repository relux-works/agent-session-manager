package canonicaljson

import (
	"strings"
	"testing"
)

func TestReviewerAttackNestedStringBoundsAtProductionEntries(t *testing.T) {
	tests := []struct {
		name   string
		object func() map[string]any
		mutate func(map[string]any)
	}{
		{
			name:   "managed tree identity over 256 Unicode characters",
			object: func() map[string]any { return validTransferManifestObject("workspace_group") },
			mutate: func(object map[string]any) {
				snapshot := object["workspace_snapshot"].(map[string]any)
				member := snapshot["members"].([]any)[0].(map[string]any)
				member["tree_identity"] = strings.Repeat("界", 257)
			},
		},
		{
			name:   "git repository identity over 256 Unicode characters",
			object: validGitWorkspaceGroupObject,
			mutate: func(object map[string]any) {
				gitWorkspaceMember(object)["repository_identity"] = strings.Repeat("界", 257)
			},
		},
		{
			name:   "git remote name over 128 Unicode characters",
			object: validGitWorkspaceGroupObject,
			mutate: func(object map[string]any) {
				member := gitWorkspaceMember(object)
				remote := member["remotes"].([]any)[0].(map[string]any)
				remote["name"] = strings.Repeat("界", 129)
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			object := test.object()
			test.mutate(object)
			input := mustJSON(t, object)
			digest, _, calculateErr := CalculateObjectIdentity(input)
			claimed := withCorrectIdentityClaimForTest(t, input, SelfManifestID)
			_, _, verifyErr := VerifyObjectIdentity(claimed)
			if calculateErr == nil || verifyErr == nil {
				t.Fatalf("malformed nested bound admitted: CalculateObjectIdentity digest=%s err=%v; VerifyObjectIdentity err=%v", digest, calculateErr, verifyErr)
			}
		})
	}
}

func TestReviewerAttackValidMultibyteNestedStringBoundary(t *testing.T) {
	object := validGitWorkspaceGroupObject()
	gitWorkspaceMember(object)["repository_identity"] = strings.Repeat("界", 256)
	assertIdentityEntriesAcceptShape(t, mustJSON(t, object), SelfManifestID)
}

func TestReviewerAttackNestedCommonTypesAtProductionEntries(t *testing.T) {
	tests := []struct {
		name   string
		object func() map[string]any
		mutate func(map[string]any)
	}{
		{
			name:   "managed tree malformed manifest digest",
			object: func() map[string]any { return validTransferManifestObject("workspace_group") },
			mutate: func(object map[string]any) {
				snapshot := object["workspace_snapshot"].(map[string]any)
				member := snapshot["members"].([]any)[0].(map[string]any)
				member["tree_manifest_id"] = "not-a-digest"
			},
		},
		{
			name:   "git object pack malformed blob digest",
			object: validGitWorkspaceGroupObject,
			mutate: func(object map[string]any) {
				member := gitWorkspaceMember(object)
				pack := member["object_pack"].(map[string]any)
				pack["blob_id"] = "not-a-digest"
			},
		},
		{
			name:   "git index forbidden stage four",
			object: validGitWorkspaceGroupObject,
			mutate: func(object map[string]any) {
				member := gitWorkspaceMember(object)
				index := member["index"].(map[string]any)
				entry := index["entries"].([]any)[0].(map[string]any)
				entry["stage"] = 4
			},
		},
		{
			name:   "uninitialized submodule with live head",
			object: validGitWorkspaceGroupObject,
			mutate: func(object map[string]any) {
				member := gitWorkspaceMember(object)
				submodule := member["submodules"].([]any)[0].(map[string]any)
				submodule["head"] = map[string]any{"mode": "detached", "oid": "sha1:" + strings.Repeat("3", 40), "ref": nil}
			},
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			object := test.object()
			test.mutate(object)
			input := mustJSON(t, object)
			digest, _, calculateErr := CalculateObjectIdentity(input)
			claimed := withCorrectIdentityClaimForTest(t, input, SelfManifestID)
			_, _, verifyErr := VerifyObjectIdentity(claimed)
			if calculateErr == nil || verifyErr == nil {
				t.Fatalf("malformed nested common type admitted: CalculateObjectIdentity digest=%s err=%v; VerifyObjectIdentity err=%v", digest, calculateErr, verifyErr)
			}
		})
	}
}
