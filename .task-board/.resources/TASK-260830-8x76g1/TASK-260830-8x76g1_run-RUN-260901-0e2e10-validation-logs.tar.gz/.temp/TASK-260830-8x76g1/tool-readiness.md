# Tool readiness

Checked before archive restoration and Go validation on 2026-09-01.

- `task-board`: `/Users/iv/.local/bin/task-board`, version `0.24.3-176-g38c65862`
- `rg`: Codex standalone path, version `15.2.0`
- `git`: `/usr/bin/git`, version `2.50.1`
- `tar`: `/usr/bin/tar`, bsdtar `3.5.3`
- `go`: `/Users/iv/.goenv/shims/go`, version `go1.25.5 darwin/arm64`
- `python`: unavailable (`command not found`, readiness exit 127); no workflow assumes it works
- `python3`: `/opt/homebrew/bin/python3`, version `3.14.7`; used for the attached mutation harnesses

All tools used for project work exited 0 during readiness. The unavailable
`python` alias is recorded above and was replaced explicitly with `python3`.
