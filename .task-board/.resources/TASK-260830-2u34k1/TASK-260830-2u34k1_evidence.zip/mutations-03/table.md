| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| composed-argv-bound | Admits exactly 65537 composed SSH argv bytes | TestSSHTotalArgvByteBound | 1 | killed:  |
| neutral | Equivalent expression | none | 0 | neutral passed:  |
| known-bad | Fixed command changed, code still compiles | TestLoadPeerIdentityVersions | 1 | killed:  |
| local-duplicate | Peer-peer uniqueness retained; admits the local identity as a remote peer | TestLoadRefusesLocalHostAsPeer | 1 | killed:  |
| peer-duplicate | Admits duplicate identity with the different-alias fixture | TestLoadIdentityRefusals/duplicate_identity | 1 | killed:  |
| alias-duplicate | Admits duplicate alias for one peer ID | TestLoadIdentityRefusals/duplicate_alias | 1 | killed:  |
| local-id-grammar | Admits one malformed local host ID | TestLoadIdentityRefusals/malformed_local_UUID | 1 | killed:  |
| peer-id-grammar | Admits explicitly empty peer ID | TestLoadIdentityRefusals/empty_peer_ID | 1 | killed:  |
| alias-bound | Admits 65-character aliases | TestLoadIdentityRefusals/long_alias | 1 | killed:  |
| endpoint-grammar | Admits one option-shaped endpoint | TestLoadIdentityRefusals/option_endpoint | 1 | killed:  |
| ssh-auth-policy | Admits one grouped host-key bypass | TestLoadIdentityRefusals/grouped_host_key_bypass | 1 | killed:  |
| selector-allowlist | Admits one discovery candidate | TestResolveAllowlistAndAliasAmbiguity | 1 | killed:  |
| alias-ambiguity | Admits one ID/alias collision | TestResolveAllowlistAndAliasAmbiguity | 1 | killed:  |
| protocol-grammar | Allows one malformed protocol ID through grammar only; exact identity gate subsumes it | none | 0 | survived: Grammar alone is subsumed by exact target-ID equality; malformed IDs still fail equality. No independent grammar kill claimed. |
| protocol-id | Admits one other allowlisted peer ID | TestProtocolIdentityRefusal | 1 | killed:  |
| disclosure-class | Admits raw excerpts to the policy class registry | TestDisclosurePolicyRefusals | 1 | killed:  |
| disclosure-unset | Admits unset summary choice for one peer | TestDisclosurePolicyRefusals/unset_summary_choice | 1 | killed:  |
| disclosure-local | Admits local-only manual metadata | TestDisclosurePolicyRefusals/default_local_only | 1 | killed:  |
| disclosure-binding | Allows one peer override to affect another peer | TestSnapshotIsolationAndDisclosureBinding | 1 | killed:  |
| read-error | Admits full-looking bytes returned together with a failed read | TestLoadAbsenceReadFailureAndRecovery/partial_read | 1 | killed:  |
