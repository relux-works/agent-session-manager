import json,hashlib,re
p='internal/traceability/ownership.v0.5.0.json'
r=json.load(open(p))
rows=[('peer-host-identity','Load',['TestLoadPeerIdentityVersions','TestLoadIdentityRefusals']),('peer-alias-resolution','Resolve',['TestResolveAllowlistAndAliasAmbiguity']),('peer-ssh-target','RPCArgv',['TestSSHTargetAtomicArgv']),('peer-key-provenance','KeyProvenance',['TestLoadAbsenceReadFailureAndRecovery']),('peer-allowlist-identity','CheckProtocolHost',['TestProtocolIdentityRefusal']),('peer-disclosure-policy','DisclosurePolicy',['TestDisclosurePolicyRefusals','TestSnapshotIsolationAndDisclosureBinding']),('peer-identity-read-recovery','Load',['TestLoadAbsenceReadFailureAndRecovery'])]
for name,entry,tests in rows:
 r['acceptance_cases'].append({'id':name,'production':{'path':'internal/peeridentity/identity.go','declaration':entry},'tests':[{'path':'internal/peeridentity/identity_test.go','declaration':t} for t in tests]})
for row in r['ownership']:
 if row['kind']=='section_binding' and row['keys']==['section:6.3']:
  row['acceptance_cases'] += [name for name,_,_ in rows if name!='peer-disclosure-policy']
  row['gap'] += ' internal/peeridentity composes Load, exact alias/host-ID resolution, SSH argv planning and protocol-ID comparison; SSH authentication and runtime mesh transport remain outside this configuration slice.'
 if row['kind']=='section_binding' and row['keys']==['section:6.4']:
  row['acceptance_cases'].append('peer-disclosure-policy')
  row['gap'] += ' internal/peeridentity resolves per-peer metadata policy and denies local-only or unchosen generated disclosure; payload sanitization and directory publication remain outside this slice.'
open(p,'w').write(json.dumps(r,indent=2,ensure_ascii=False)+'\n')
# Go encoding/json escapes HTML and line separators, while maintaining struct field order.
s=json.dumps(r,separators=(',',':'),ensure_ascii=False)
for a,b in [('&','\\u0026'),('<','\\u003c'),('>','\\u003e'),('\u2028','\\u2028'),('\u2029','\\u2029')]:s=s.replace(a,b)
digest=hashlib.sha256(s.encode()).hexdigest()
p='internal/traceability/traceability.go';s=open(p).read();s=re.sub(r'reviewedOwnershipCanonicalSHA256 = "[a-f0-9]+"',f'reviewedOwnershipCanonicalSHA256 = "{digest}"',s);open(p,'w').write(s)
p='internal/traceability/traceability_test.go';s=open(p).read().replace('AcceptanceCases:        98,','AcceptanceCases:        105,');open(p,'w').write(s)
p='README.md';s=open(p).read().replace('normative section keys, 98\n','normative section keys, 105\n');open(p,'w').write(s)
