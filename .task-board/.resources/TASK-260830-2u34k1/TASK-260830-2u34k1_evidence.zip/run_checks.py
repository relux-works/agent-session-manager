import json,os,subprocess
from pathlib import Path
out=Path('.temp/TASK-260830-2u34k1')
config=json.load(open('task-board.config.json'))
commands=config['spawn']['worktree_isolation']['validation']['commands']
# Full test, race, and coverage runs are driven separately, with their exact
# process exit codes recorded in the outcome. Run all remaining configured gates.
commands=[c for c in commands if not c.startswith('go test ./...')]
commands.append('GOOS=windows go vet ./...')
results=[]
for n,cmd in enumerate(commands,1):
 log=out/f'gate-{n:02d}.log'
 with log.open('wb') as f:
  p=subprocess.run(['/bin/zsh','-c',cmd],stdout=f,stderr=subprocess.STDOUT,timeout=300)
 results.append({'command':cmd,'exit_code':p.returncode,'log':str(log)})
 print(f'{n}: exit={p.returncode} {cmd}',flush=True)
 (out/'gates.json').write_text(json.dumps(results,indent=2)+'\n')
 if p.returncode: raise SystemExit(p.returncode)
