package peeridentity_test

import (
 "errors"
 "fmt"
 "io/fs"
 "os/exec"
 "strings"
 "testing"

 "github.com/relux-works/agent-session-manager/internal/config"
 "github.com/relux-works/agent-session-manager/internal/peeridentity"
)

func TestReviewerSSHNativeInterpretation(t *testing.T) {
 for _, tc := range []struct{endpoint,host,port string}{
  {"u@[::1]:00222", "::1", "222"},
  {"u@[2001:db8::ffff]:65535", "2001:db8::ffff", "65535"},
  {"u@target.example:2201", "target.example", "2201"},
  {"u@target.example", "target.example", "44"},
 } {
  t.Run(tc.endpoint,func(t *testing.T){
   doc := strings.Replace(document(config.CurrentVersion),"ivan@workstation.example",tc.endpoint,1)+`ssh_args = ["-o", "Port=44", "-p", "55", "-o", "StrictHostKeyChecking=yes", "-i", "/fixture/nonexistent-key"]`
   target:=requireTarget(t,requireLoad(t,doc),peerID)
   argv,err:=target.RPCArgv(); if err!=nil {t.Fatal(err)}
   args:=append([]string{"-G","-F","/dev/null"},argv...)
   out,err:=exec.Command("ssh",args...).Output(); if err!=nil {t.Fatalf("ssh config-only parse failed: %v",err)}
   fields:=map[string]string{}
   for _,line:=range strings.Split(string(out),"\n") { p:=strings.SplitN(line," ",2); if len(p)==2 {fields[p[0]]=p[1]} }
   if fields["hostname"]!=tc.host || fields["port"]!=tc.port || fields["user"]!="u" || fields["requesttty"]!="false" || fields["stricthostkeychecking"]!="true" {t.Fatalf("native interpretation: host=%q port=%q user=%q tty=%q strict=%q",fields["hostname"],fields["port"],fields["user"],fields["requesttty"],fields["stricthostkeychecking"])}
  })
 }
}

func TestReviewerNeighbors(t *testing.T) {
 t.Run("unicode aliases stay exact",func(t *testing.T){
  a,b:="é","e\u0301"
  doc:=strings.Replace(document(config.CurrentVersion),`name = "workstation"`,fmt.Sprintf("name = %q",a),1)+peer(otherID,b,"other.example")
  d:=requireLoad(t,doc)
  if requireTarget(t,d,a).Host().ID!=peerID || requireTarget(t,d,b).Host().ID!=otherID {t.Fatal("aliases normalized into collision")}
 })
 t.Run("later invalid member cannot use earlier allowlist",func(t *testing.T){
  for _,tail:=range []string{peer(otherID,"third","host.example")+`ssh_args = ["-o", "StrictHostKeyChecking=yes", "-o", "StrictHostKeyChecking=off"]`,peer(otherID,"third","u@[::1]:00000"),peer(peerID,"third","other.example")} {
   d,err:=load(document(config.CurrentVersion)+tail)
   if err==nil {t.Fatal("later invalid peer admitted")}
   if _,err=d.Resolve(peerID);!errors.Is(err,peeridentity.ErrNotAllowlisted){t.Fatal("partial allowlist escaped")}
  }
 })
 t.Run("read disappears after successful stat",func(t *testing.T){
  in:=inputs(document(config.CurrentVersion)); in.ReadFile=func(string)([]byte,error){return nil,fs.ErrNotExist}
  d,err:=peeridentity.Load(in,config.Overrides{config.ConfigFile:"/config.toml"})
  if err==nil || errors.Is(err,peeridentity.ErrConfigurationRequired){t.Fatal("failed read became normal absence")}
  if _,err=d.Resolve(peerID);!errors.Is(err,peeridentity.ErrNotAllowlisted){t.Fatal("failed read authorized")}
 })
 t.Run("malformed policy cannot use permissive default",func(t *testing.T){
  base:=document(config.CurrentVersion)+"\n[directory]\ndefault_metadata_policy = \"mesh_sanitized\"\ngenerated_summary_upgrade_choice = \"mesh_sanitized\"\n"
  for _,entry:=range []string{strings.Replace(disclosure(peerID,"local_only"),`manual_metadata = "local_only"`,`manual_metadata = ""`,1),strings.Replace(disclosure(peerID,"local_only"),`host_id = "`+peerID+`"`,`host_id = ""`,1),strings.Replace(disclosure(peerID,"local_only"),`native_observations = "local_only"`,`native_observations = false`,1)} {
   d,err:=load(base+entry); if err==nil {t.Fatal("malformed override admitted")}
   if p,err:=d.DisclosurePolicy(peerID,"manual_metadata");err==nil || p!="" {t.Fatal("default replaced broken override")}
  }
 })
 t.Run("unknown class under alias collision",func(t *testing.T){
  d:=requireLoad(t,document(config.CurrentVersion)+peer(otherID,peerID,"other.example")+"\n[directory]\ndefault_metadata_policy = \"mesh_sanitized\"\n")
  if p,err:=d.DisclosurePolicy(peerID,"manual_metadata");!errors.Is(err,peeridentity.ErrAmbiguousAlias)||p!="" {t.Fatal("policy bypassed alias ambiguity")}
  for _,class:=range []string{"Manual_Metadata","manual_metadata ","auth_status","path_facts","raw_excerpts"}{if p,err:=d.DisclosurePolicy("workstation",class);!errors.Is(err,peeridentity.ErrDisclosureDenied)||p!=""{t.Fatal("unknown class admitted")}}
 })
 t.Run("invalid snapshot gives no provenance",func(t *testing.T){
  d,err:=peeridentity.FromSnapshot(config.Snapshot{});if err==nil {t.Fatal("empty snapshot accepted")}
  target,err:=d.Resolve(peerID);if err==nil || target.KeyProvenance()!="" {t.Fatal("minted empty evidence authorized")}
 })
}
