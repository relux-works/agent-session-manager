#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants for TASK-260830-2x16gz rev1 (isolated overlay, sources untouched)."""
import json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[0]
# ROOT override: worktree
import os
ROOT = Path(os.environ.get("REV_ROOT", str(Path.cwd())))
OUT = Path("/tmp/rev-2x16gz/own-mutants")
OUT.mkdir(parents=True, exist_ok=True)
PROBES = [
  ("own-authz-stale-plus1", "internal/hosttrust/authorize.go",
   '\tif request.SnapshotGeneration != snapshot.Generation {\n\t\treturn trustError(TrustError{Operation: "authorize generation", Err: ErrStaleGeneration})',
   '\tif request.SnapshotGeneration != snapshot.Generation && request.SnapshotGeneration+1 != snapshot.Generation {\n\t\treturn trustError(TrustError{Operation: "authorize generation", Err: ErrStaleGeneration})',
   "Admits exactly one stale generation at dispatch authorization",
   "TestAuthorizeDispatchRefusals/refreshed_number_on_old_snapshot"),
  ("own-disconnect-misclass", "internal/hostchannel/server.go",
   '\t\trequest, err := rpcwire.DecodeRequest(line)\n\t\tif err != nil {\n\t\t\t_ = stream.Close()\n\t\t\treturn fmt.Errorf("%w: %w", ErrUnframeableInput, err)\n\t\t}',
   '\t\trequest, err := rpcwire.DecodeRequest(line)\n\t\tif err != nil {\n\t\t\t_ = stream.Close()\n\t\t\treturn fmt.Errorf("%w: %w", ErrAuthenticationFailed, err)\n\t\t}',
   "Misclassifies exactly one truncated dispatch as authentication_failed instead of unframeable/transport_failure",
   "TestHostileDisconnectPhases/mid_request_close"),
  ("own-unknown-zero-match", "internal/hostchannel/channel.go",
   '\t\tif len(matched) != 1 {',
   '\t\tif len(matched) > 1 {',
   "Admits exactly the zero-match member (unknown peer) while still refusing double matches",
   "TestVerifyPeerRefusals/unknown-leaf"),
  ("own-mutation-stale-plus1", "internal/hosttrust/authorize.go",
   '\tif request.SnapshotGeneration != current.Generation {\n\t\treturn trustError(TrustError{Operation: "authorize mutation", Err: ErrStaleGeneration})',
   '\tif request.SnapshotGeneration != current.Generation && request.SnapshotGeneration+1 != current.Generation {\n\t\treturn trustError(TrustError{Operation: "authorize mutation", Err: ErrStaleGeneration})',
   "Admits exactly one stale generation at the mutation boundary",
   "TestStaleGenerationAtMutation"),
  ("own-control-comment", "internal/hostchannel/channel.go",
   '// Package hostchannel implements AX Section 11.10 Host Channel 1.0.0 over',
   '// Package hostchannel implements AX Section 11.10 Host Channel 1.0.0 over // reviewer control: no behavior change',
   "Harmless comment-only control (must SURVIVE)",
   None),
]
results = []
unexpected = False
for name, rel, old, new, narrows, expected in PROBES:
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    src = ROOT / rel
    orig = src.read_bytes()
    text = orig.decode()
    if text.count(old) != 1:
        print(f"{name}: PLANT-FAILED count={text.count(old)} in {rel}")
        results.append({"mutant": name, "result": "plant-failed"})
        unexpected = True
        continue
    mutated = text.replace(old, new, 1)
    repl = folder / src.name
    repl.write_text(mutated)
    overlay = folder / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {str(src): str(repl)}}))
    # FULL behavioral suite for hostchannel + hosttrust (both packages exercise the gates)
    cmd = ["go", "test", "-overlay", str(overlay), "./internal/hostchannel", "./internal/hosttrust", "-count=1", "-json", "-timeout=300s"]
    proc = subprocess.run(cmd, cwd=str(ROOT), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=420)
    (folder / "test.log").write_bytes(proc.stdout)
    (folder / "exit.txt").write_text(str(proc.returncode))
    failed, passed = [], []
    for line in proc.stdout.decode(errors="replace").splitlines():
        try: e = json.loads(line)
        except Exception: continue
        if e.get("Action") == "fail" and "Test" in e: failed.append(e["Test"])
        if e.get("Action") == "pass" and "Test" in e: passed.append(e["Test"])
    if src.read_bytes() != orig:
        print(f"{name}: SOURCE-CHANGED-DURING-RUN")
        unexpected = True
    if expected is None:
        ok = proc.returncode == 0 and bool(passed)
        state = "survived-expected" if ok else "unexpected"
    else:
        ok = proc.returncode != 0 and expected in failed
        state = "killed" if ok else ("survived-UNEXPECTED" if proc.returncode == 0 else "wrong-test")
    if not ok: unexpected = True
    print(f"{name}: {state} exit={proc.returncode} expected={expected} failed_has_expected={expected in failed if expected else '-'} nfailed={len(failed)}", flush=True)
    results.append({"mutant": name, "narrowing": narrows, "exit_code": proc.returncode, "result": state, "expected_test": expected, "named_failing_tests": sorted(set(failed))[:12]})
(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
sys.exit(1 if unexpected else 0)
