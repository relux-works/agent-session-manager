| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| non-hello | Admits health.get before hello | TestRefusesNonHelloBeforeHello | 1 | killed:  |
| stale-dispatch | Admits exactly one generation past the binding | TestStaleGenerationAtDispatch/server_closes | 1 | killed:  |
| stale-mutation | Refreshes the stale binding to the current generation before the boundary | TestStaleGenerationAtMutation | 1 | killed:  |
| handshake-cap | Admits exactly cap+1 handshake bytes | TestHandshakeLimiterBounds | 1 | killed:  |
| ca-bound | Admits exactly a 65536-byte authority list | TestAuthorityListOverflow | 1 | killed:  |
| tls-min | Admits TLS 1.2 in both roles | TestRefusesTLS12Offer/server | 1 | killed:  |
| tls-min-client | Admits TLS 1.2 in both roles | TestRefusesTLS12Offer/client | 1 | killed:  |
| tickets | Issues session tickets for resumption | TestRefusesResumption | 1 | killed:  |
| census-evasion | Writes a temp file through tokens the static census does not list | TestRuntimeWriteCensus | 1 | killed:  |
