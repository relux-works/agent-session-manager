| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent authority size | none | 0 | neutral passed:  |
| client-cache | Caches client sessions while the server issues no tickets | none | 0 | survived: One-sided weakening is harmless: a caching client cannot resume against a server that issues no tickets, so the resumption suite still passes. |
| alpn-same-family | Admits exactly the same-family ax-host/2 ALPN | TestVerifyPeerRefusals/alpn-same-family | 1 | killed:  |
| oversize-dispatch | Admits exactly an 8 MiB+10 line at framing and decode | TestHostileOversizedFrames/dispatch_line_8mib_plus_one | 1 | killed:  |
| stale-client-rebind | Admits exactly one generation past the client binding | TestHostileRecoveryBypass/stale_binding_never_rebinds | 1 | killed:  |
| rpc-contracts | Admits any contracts.rpc disclosure | TestHostileDisclosureMismatch/responder_contracts_drift | 1 | killed:  |
| error-version-drift | Honors exactly a 1.2.0 error as 1.3.0 | TestHostileDisclosureMismatch/error_version_drift | 1 | killed:  |
| truncated-dispatch-ignored | Ignores one truncated dispatch frame instead of closing unframeable | TestHostileDisconnectPhases/mid_request_close | 1 | killed:  |
| snapshot-integrity | Reads a corrupt store as an empty store | TestHostileStaleReadsAreIntegrityFailures/corrupt_store | 1 | killed:  |
| correlation-health | Accepts a miscorrelated health.get answer | TestHostileRecoveryBypass/response_id_mismatch_refused | 1 | killed:  |
| nonce-static | Mints one constant hello nonce | TestHostileReplayNonceFreshness | 1 | killed:  |
