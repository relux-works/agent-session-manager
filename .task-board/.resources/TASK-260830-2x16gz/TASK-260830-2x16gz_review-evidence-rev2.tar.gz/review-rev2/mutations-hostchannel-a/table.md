| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent authority size | none | 0 | neutral passed:  |
| client-cache | Caches client sessions while the server issues no tickets | none | 0 | survived: One-sided weakening is harmless: a caching client cannot resume against a server that issues no tickets, so the resumption suite still passes. |
| alpn-same-family | Admits exactly the same-family ax-host/2 ALPN | TestVerifyPeerRefusals/alpn-same-family | 1 | killed:  |
| oversize-dispatch | Admits exactly an 8 MiB+10 line at framing and decode | TestHostileOversizedFrames/dispatch_line_8mib_plus_one | 1 | killed:  |
| stale-client-rebind | Admits exactly one generation past the client binding | TestHostileRecoveryBypass/stale_binding_never_rebinds | 1 | killed:  |
| rpc-contracts | Admits any contracts.rpc disclosure | TestHostileDisclosureMismatch/responder_contracts_drift | 1 | killed:  |
