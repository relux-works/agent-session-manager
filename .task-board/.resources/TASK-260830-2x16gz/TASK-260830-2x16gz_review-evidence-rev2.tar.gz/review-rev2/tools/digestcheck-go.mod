module digestcheck

go 1.22
