package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
)

// Verbatim projection structs copied from internal/traceability/traceability.go
// (candidate tree 1ecd6439), so the digest is recomputed independently of the
// package under review.
type ownershipKind string
type coverageLevel string

type ownershipRegistry struct {
	Format          string           `json:"format"`
	FormatVersion   int              `json:"format_version"`
	Source          registrySource   `json:"source"`
	AcceptanceCases []acceptanceCase `json:"acceptance_cases"`
	Ownership       []ownershipGroup `json:"ownership"`
	UnownedSections []unownedSection `json:"unowned_sections"`
}
type unownedSection struct {
	Key      string `json:"key"`
	Gap      string `json:"gap"`
	Evidence string `json:"evidence"`
}
type registrySource struct {
	Repository     string `json:"repository"`
	Release        string `json:"release"`
	Commit         string `json:"commit"`
	DocumentPath   string `json:"document_path"`
	DocumentSHA256 string `json:"document_sha256"`
}
type acceptanceCase struct {
	ID         string          `json:"id"`
	Production codeReference   `json:"production"`
	Tests      []codeReference `json:"tests"`
}
type ownershipGroup struct {
	Kind            ownershipKind      `json:"kind"`
	Keys            []string           `json:"keys"`
	Production      codeReference      `json:"production"`
	AcceptanceCases []string           `json:"acceptance_cases"`
	Coverage        coverageLevel      `json:"coverage,omitempty"`
	Gap             string             `json:"gap,omitempty"`
	Clauses         []dischargedClause `json:"clauses,omitempty"`
}
type dischargedClause struct {
	ID              string   `json:"id"`
	Line            int      `json:"line"`
	Excerpt         string   `json:"excerpt"`
	AcceptanceCases []string `json:"acceptance_cases"`
}
type codeReference struct {
	Path        string `json:"path"`
	Declaration string `json:"declaration"`
}

func decode(candidate []byte) (ownershipRegistry, error) {
	var decoded ownershipRegistry
	decoder := json.NewDecoder(bytes.NewReader(candidate))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&decoded); err != nil {
		return ownershipRegistry{}, err
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		if err == nil {
			return ownershipRegistry{}, errors.New("multiple JSON values")
		}
		return ownershipRegistry{}, err
	}
	return decoded, nil
}

func main() {
	for _, path := range os.Args[1:] {
		raw, err := os.ReadFile(path)
		if err != nil {
			fmt.Println(path, "READ-ERR", err)
			continue
		}
		reg, err := decode(raw)
		if err != nil {
			fmt.Println(path, "DECODE-ERR", err)
			continue
		}
		canonical, err := json.Marshal(reg)
		if err != nil {
			fmt.Println(path, "MARSHAL-ERR", err)
			continue
		}
		sum := sha256.Sum256(canonical)
		fmt.Printf("%s cases=%d ownership=%d unowned=%d digest=%s\n", path, len(reg.AcceptanceCases), len(reg.Ownership), len(reg.UnownedSections), hex.EncodeToString(sum[:]))
	}
}
