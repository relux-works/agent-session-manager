| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| error-version-drift | Honors exactly a 1.2.0 error as 1.3.0 | TestHostileDisclosureMismatch/error_version_drift | 1 | killed:  |
| truncated-dispatch-ignored | Ignores one truncated dispatch frame instead of closing unframeable | TestHostileDisconnectPhases/mid_request_close | 1 | killed:  |
| snapshot-integrity | Reads a corrupt store as an empty store | TestHostileStaleReadsAreIntegrityFailures/corrupt_store | 1 | killed:  |
| correlation-health | Accepts a miscorrelated health.get answer | TestHostileRecoveryBypass/response_id_mismatch_refused | 1 | killed:  |
| nonce-static | Mints one constant hello nonce | TestHostileReplayNonceFreshness | 1 | killed:  |
| census-evasion | Writes a temp file through tokens the static census does not list | TestRuntimeWriteCensus | 1 | killed:  |
