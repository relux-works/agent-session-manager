| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent size accumulator | none | 0 | neutral passed:  |
| known-bad | Adds a remote command token | TestOpenStructuredCommand | 1 | killed:  |
| send-plus-one | Admits exactly one excess outbound byte | TestDuplexAndSendBoundaries/oversize | 1 | killed:  |
| read-plus-one | Admits exactly one excess inbound byte | TestReceiveFailureAndLimits/oversize | 1 | killed:  |
| exit255 | Treats SSH exit 255 alone as successful EOF | TestReceiveFailureAndLimits/exit255 | 1 | killed:  |
