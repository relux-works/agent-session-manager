# Review evidence index — CR-TASK-260830-2x16gz-3 rev3 (RUN-260917-f6f23d)

All commands ran from the Story worktree `.temp/STORY-260830-1kiyj6/worktree`
(HEAD 9636508, candidate UNCOMMITTED) unless noted. Live index/HEAD untouched;
candidate tree reproduced via a temporary `GIT_INDEX_FILE`.

| File | What it is | Exit |
|---|---|---|
| tracecheck-01.log | `go run ./internal/traceability/cmd/tracecheck` on the candidate | 0 |
| tool-line.txt / readme-3152.txt | the tool's `section coverage:` line and README.md:3152; `cmp` identical | 0 |
| sections-01.log | `tracecheck -section X` for 6.2 2.4 13.13 14.2 5.3 15.1 15.3 7.7 10.3 5.5 8 2.2 7.3 13.12 13.14.5 15.2 11.10.1-4 16.1 6.6 11.10 11.10.5 (ratios/refusals quoted in the verdict) | 0/1 as expected |
| patch-apply-01.log | CR3 patch sha256 = baac3456…; `git apply` onto `git archive fc67abd` (tree da44e4d3…) yields tree 65dc05ea… | 0 |
| gate-01-gofmt.log / gate-02-build.log / gate-03-vet.log | gofmt -l / go build ./... / go vet ./... | 0 |
| gate-04-hostile-v.log | `go test ./internal/hostchannel -run TestHostile -count=1 -v` (54 PASS, 0 FAIL, 1 SKIP; OpenSSH lane executed) | 0 |
| gate-05-story-pkgs-v.log | Story packages + cigate `-count=1 -v` (10 ok, 1749 PASS) | 0 |
| gate-06-batchA.log / gate-07-batchB.log | remaining 27 packages `-count=1` (15 + 12 ok) | 0 |
| gate-08-race.log | `-race -count=1` on 9 Story packages, 0 DATA RACE | 0 |
| gate-09-misc.log | cataloggen -check, GOOS=linux/windows builds, JSON parse, git diff --check (worktree and fc67abd..65dc05ea) | 0 |
| gate-10-fuzz.log | 14 configured fuzz smokes `-fuzztime=100x` | 0 ×14 |
| gate-11-cover.log | `-cover` on hostchannel/rpcwire/hosttrust/traceability/... | 0 |
| own-plants/R0-baseline.log | unmutated isolated copy, README gates | 0 |
| own-plants/R1-paragraph-66.log | measured paragraph "65 exact section bindings"→"66": KILLED | 1 |
| own-plants/R2-subsection-unowned8.log | subsection `unowned=7`→`8` + "Seven"→"Eight": SURVIVED (unmeasured subsection, F1 P3) | 0 |
| own-plants/R3-control.log | trailing-newline harmless control: SURVIVED | 0 |

Plants ran in `/tmp/rev3-2x16gz` (= `git archive 65dc05ea`), README gates =
`go test ./internal/traceability ./internal/cigate -run 'TestREADMEOwnershipFiguresAreDerivedFromTheMeasuredReport|TestRealREADMECarriesNoPositiveClaim|README' -count=1`.
Copy deleted after the run. Accepted from producer rev4 evidence: `-race` on
the 32 non-Story packages, full-tree `-cover`, `task-board validate`.
