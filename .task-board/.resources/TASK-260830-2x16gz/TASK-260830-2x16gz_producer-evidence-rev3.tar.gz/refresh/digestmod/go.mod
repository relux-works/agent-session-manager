module rev3digest

go 1.21
