package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
)

type ownershipKind string
type coverageLevel string

type ownershipRegistry struct {
	Format          string           `json:"format"`
	FormatVersion   int              `json:"format_version"`
	Source          registrySource   `json:"source"`
	AcceptanceCases []acceptanceCase `json:"acceptance_cases"`
	Ownership       []ownershipGroup `json:"ownership"`
	UnownedSections []unownedSection `json:"unowned_sections"`
}

type unownedSection struct {
	Key      string `json:"key"`
	Gap      string `json:"gap"`
	Evidence string `json:"evidence"`
}

type registrySource struct {
	Repository     string `json:"repository"`
	Release        string `json:"release"`
	Commit         string `json:"commit"`
	DocumentPath   string `json:"document_path"`
	DocumentSHA256 string `json:"document_sha256"`
}

type acceptanceCase struct {
	ID         string          `json:"id"`
	Production codeReference   `json:"production"`
	Tests      []codeReference `json:"tests"`
}

type ownershipGroup struct {
	Kind            ownershipKind      `json:"kind"`
	Keys            []string           `json:"keys"`
	Production      codeReference      `json:"production"`
	AcceptanceCases []string           `json:"acceptance_cases"`
	Coverage        coverageLevel      `json:"coverage,omitempty"`
	Gap             string             `json:"gap,omitempty"`
	Clauses         []dischargedClause `json:"clauses,omitempty"`
}

type dischargedClause struct {
	ID              string   `json:"id"`
	Line            int      `json:"line"`
	Excerpt         string   `json:"excerpt"`
	AcceptanceCases []string `json:"acceptance_cases"`
}

type codeReference struct {
	Path        string `json:"path"`
	Declaration string `json:"declaration"`
}

func decodeOwnershipRegistry(candidate []byte) (ownershipRegistry, error) {
	var decoded ownershipRegistry
	decoder := json.NewDecoder(bytes.NewReader(candidate))
	decoder.DisallowUnknownFields()
	if err := decoder.Decode(&decoded); err != nil {
		return ownershipRegistry{}, fmt.Errorf("decode ownership registry: %v", err)
	}
	var trailing any
	if err := decoder.Decode(&trailing); !errors.Is(err, io.EOF) {
		if err == nil {
			return ownershipRegistry{}, fmt.Errorf("decode ownership registry: multiple JSON values")
		}
		return ownershipRegistry{}, fmt.Errorf("decode ownership registry trailing data: %v", err)
	}
	return decoded, nil
}

func main() {
	for _, path := range os.Args[1:] {
		raw, err := os.ReadFile(path)
		if err != nil {
			panic(err)
		}
		registry, err := decodeOwnershipRegistry(raw)
		if err != nil {
			panic(err)
		}
		canonical, err := json.Marshal(registry)
		if err != nil {
			panic(err)
		}
		digest := sha256.Sum256(canonical)
		fmt.Printf("%s %s\n", hex.EncodeToString(digest[:]), path)
	}
}
