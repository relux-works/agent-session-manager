| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| handshake-cap | Admits exactly cap+1 handshake bytes | TestHandshakeLimiterBounds | 1 | killed:  |
| ca-bound | Admits exactly a 65536-byte authority list | TestAuthorityListOverflow | 1 | killed:  |
| tls-min | Admits TLS 1.2 in both roles | TestRefusesTLS12Offer/server | 1 | killed:  |
| tls-min-client | Admits TLS 1.2 in both roles | TestRefusesTLS12Offer/client | 1 | killed:  |
| tickets | Issues session tickets for resumption | TestRefusesResumption | 1 | killed:  |
| client-cache | Caches client sessions while the server issues no tickets | none | 0 | survived: One-sided weakening is harmless: a caching client cannot resume against a server that issues no tickets, so the resumption suite still passes. |
| census-evasion | Writes a temp file through tokens the static census does not list | TestRuntimeWriteCensus | 1 | killed:  |
