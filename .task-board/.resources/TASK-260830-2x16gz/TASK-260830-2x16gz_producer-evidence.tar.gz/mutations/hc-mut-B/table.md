| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| state-revoked | Admits revoked entries while refusing other states | TestVerifyPeerRefusals/revoked | 1 | killed:  |
| state-retiring | Admits entries up to one hour past retire_at | TestVerifyPeerRefusals/retiring-past | 1 | killed:  |
| profile | Admits profile-invalid active entries | TestVerifyPeerRefusals/expired | 1 | killed:  |
| hello-id-server | Substitutes the verified UUID for the received hello ID | TestRefusesHelloUUIDMismatch | 1 | killed:  |
| hello-id-client | Substitutes the expected destination for the received hello ID | TestRefusesServerHelloUUIDMismatch | 1 | killed:  |
| non-hello | Admits health.get before hello | TestRefusesNonHelloBeforeHello | 1 | killed:  |
| stale-dispatch | Admits exactly one generation past the binding | TestStaleGenerationAtDispatch/server_closes | 1 | killed:  |
| stale-mutation | Refreshes the stale binding to the current generation before the boundary | TestStaleGenerationAtMutation | 1 | killed:  |
