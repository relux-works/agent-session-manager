| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent authority size | none | 0 | neutral passed:  |
| known-bad | Wrong server name | TestServerNameMatchesIssuedLeaf | 1 | killed:  |
| alpn-supplement | Admits exactly rogue-alpn | TestVerifyPeerRefusals/alpn | 1 | killed:  |
| didresume | Admits resumed connections with chains | TestVerifyPeerRefusals/resumed | 1 | killed:  |
| chains | Admits empty chains with a presented peer certificate | TestVerifyPeerRefusals/no-chains | 1 | killed:  |
| match-leaf | Admits a leaf differing only in its last byte | TestVerifyPeerRefusals/leaf-flipped | 1 | killed:  |
| match-root | Admits a root differing only in its last byte | TestVerifyPeerRefusals/root-flipped | 1 | killed:  |
| match-spki | Admits exactly the zero SPKI | TestVerifyPeerRefusals/spki-zero | 1 | killed:  |
| match-count | Admits exactly a double match | TestVerifyPeerRefusals/double-match | 1 | killed:  |
