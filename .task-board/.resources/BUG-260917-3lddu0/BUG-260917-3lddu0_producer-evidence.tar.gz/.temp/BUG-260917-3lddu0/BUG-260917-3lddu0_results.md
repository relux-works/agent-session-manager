# BUG-260917-3lddu0 results

Status: ready for developer handoff; the Story worktree is deliberately
UNCOMMITTED.

## Outcome

`internal/sessrepo.Repository.AppendEvent` now checks the durable winning
lease before normal chain admission. A lower-epoch event returns
`ErrStaleLease`; a same-epoch event from a lease other than the winner
returns `ErrDivergentBranch`. Both refusal arms preserve the event blob
without adding it to the authoritative chain. Historical chain replay
does not apply this new-event gate, so existing authoritative history
remains readable after takeover.

The production entry is composed unchanged by `sessprofile.SetProfile`,
`axpane.Emit`, and `axpane.EmitParked`. `TestLosingLeaseProfileEventIgnored`
drives the append refusal, derives the effective profile, and runs the
launch path. The losing `profile.changed` cannot become the source and
cannot produce the old yolo/
`--dangerously-bypass-approvals-and-sandbox` outcome.

Acceptance ratio: **2 of 2 AC rows driven**. Gate-entry census:
**8 of 8 cells driven**, symmetric at 4 lower-epoch and 4 same-epoch
loser cells. Every cell has a named production entry and committed test;
the full table is in `BUG-260917-3lddu0_conformance-matrix.md` and is
mirrored in `internal/sessrepo/TRACEABILITY.md`.

## Before/after evidence

The exact trunk baseline direct production reproduction is
`.temp/BUG-260917-3lddu0/baseline-probe-9-direct.log`: with successor B
already winning while tail A remained, the old implementation returned
`err=<nil>` and failed the expected stale refusal. The archived review
probe-15 log records the old blast radius as
`profile={Profile:yolo ... HasSource:true}` with mapping
`--dangerously-bypass-approvals-and-sandbox`.

The API-adapted baseline production reproduction is also direct and
executable: `baseline-probe-15-direct.log` logs `profile=yolo`,
`has_source=true`, and the exact
`--dangerously-bypass-approvals-and-sandbox` mapping after the losing
append is accepted. This makes the before-state outcome explicit even
though the archived wrapper probe is no longer a literal current-API
test.

The archived probe wrapper is not claimed as a literal current-tree rerun:
its API shape predates the candidate. The candidate's adapted production
tests are the committed evidence after the fix:

- `TestAppendEventRefusesSupersededLeaseWhileTailStillMatches`
- `TestAppendEventRefusesSameEpochLosingLeaseWhileTailStillMatches`
- `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches`
- `TestEmitReachesAppendAdmissionGateAfterStaleObservation`
- `TestEmitParkedReachesAppendAdmissionGateAfterStaleObservation`
- `TestEmitReachesSameEpochAppendAdmissionGate`
- `TestEmitParkedReachesSameEpochAppendAdmissionGate`
- `TestLosingLeaseProfileEventIgnored`

## Mutants

Final harness command:

```bash
PYTHONDONTWRITEBYTECODE=1 python3 internal/sessrepo/testdata/mutate_append_admission.py .temp/BUG-260917-3lddu0/mutants-append-03
```

`N-stale-winning-admission` and `N-same-epoch-winning-admission` are
narrowing mutants, not deletes; both are KILLED through direct and
composing production entries. The harmless comment control SURVIVED,
the missing-token control is NOT_APPLIED, and the syntax control is
COMPILE_OR_HARNESS_FAILURE. Control-before and control-after suites both
exit 0. No token-preserving source-text mutant applies because this gate
does not inspect source text. Raw logs, subprocess exits, and
`mutants.json` are in `mutants-append-03/`; no `__pycache__` artifacts
were produced.

## Importer comparison

Complete importer mask:

```text
./internal/axpane ./internal/crashgate ./internal/fencing ./internal/sessckpt ./internal/sessprofile ./internal/sessquery ./internal/sessstate ./internal/termbind ./internal/terminstance
```

`go test -json -count=1` passes all 9 package summaries before and after.
The outcome-key comparison is 2,018 before / 2,025 after: 7 additions
(the four wrapper tests, SetProfile parent, and its two arm subtests),
0 removals, and 0 changed existing outcomes. This is an OUTCOME-keyed
comparison over the complete importer set, not a name-keyed single-package
diff. JSONL and normalized summary are under `importer-outcomes/`.

## Registry and traceability

The v0.7.0 registry adds:

- `story-260917-losing-lease-profile-source`, owned by
  `internal/sessprofile/profile.go:Derive` and
  `TestLosingLeaseProfileEventIgnored`.
- `story-260917-append-winning-lease-admission`, owned by
  `internal/sessrepo/sessrepo.go:AppendEvent` and the seven append/gateway
  tests listed in the conformance matrix.

The canonical registry projection digest was re-derived from the candidate
registry as:

```text
ed6f016f73e390071743b09aded229e781d95408b0b9eeb3f134fcb87bb9a893
```

Exact-tree tracecheck:

```text
traceability ok: contracts=64 normative_sections=36 acceptance_cases=154 fixtures=33 compatibility_contracts=55 assigned_scopes=0
section coverage: bindings=69 full=4 partial=9 sliver=9 unevidenced=43 unmeasured=4 unowned=7 clauses_discharged=70/574
```

The README measured-coverage subsection has the exact printed coverage
line. Section 2.4 scoped tracecheck admits; Section 5.3 scoped tracecheck
refuses as the expected 7/8 partial binding. The precise logs are under
`traceability/`.

## Carried P3 notes

- `internal/axpane/decide.go` doc-comment qualifier remains untouched and
  is explicitly scoped to local ownership.
- `observeRemoteWinner` redundancy is recorded only; no simplification is
  made.
- The no-grant remote interactive-owner step-4 product question remains
  unresolved; this leaf does not decide it.
- Evidence hygiene records both the pre-logbook candidate tree OID
  `276c515c90665327b991fe1cdf78ef8086cd409c` and the final candidate tree
  OID `8042bcc231a9fe7ddca50969cc69c7866797996a`. Test masks are beside
  every census and importer count.

## Validation

All 30 commands from `spawn.worktree_isolation.validation.commands` exited
0. This includes `go test ./... -count=1 -v`,
`go test ./... -race -count=1 -timeout 25m`, coverage, all configured fuzz
commands, tracecheck, catalog freshness, Linux and Windows builds, JSON
parse, `task-board validate`, and `git diff --check`. The additional
required `GOOS=windows GOARCH=amd64 go vet ./...` also exited 0.

`task-board validate` printed existing board-wide `MISSING_ACTIVITY`
diagnostics but exited 0; no diagnostic named this task. Full logs are
under `.temp/BUG-260917-3lddu0/validation/`, with exact command and exit
files for each numbered gate.

The implementation/test/documentation delta is intentionally uncommitted
in the managed Story worktree for the orchestrator's snapshot handoff.
