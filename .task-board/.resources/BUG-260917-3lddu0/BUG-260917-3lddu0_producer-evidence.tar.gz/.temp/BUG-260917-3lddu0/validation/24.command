go run ./internal/traceability/cmd/tracecheck
