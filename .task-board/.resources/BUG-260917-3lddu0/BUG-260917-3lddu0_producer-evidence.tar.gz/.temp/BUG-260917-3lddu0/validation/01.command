test -z "$(gofmt -l $(git ls-files --cached --others --exclude-standard -- '*.go'))"
