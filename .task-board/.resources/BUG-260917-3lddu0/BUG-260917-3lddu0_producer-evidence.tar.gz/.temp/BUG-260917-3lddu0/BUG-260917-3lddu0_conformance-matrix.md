# BUG-260917-3lddu0 conformance matrix

Candidate: `8042bcc231a9fe7ddca50969cc69c7866797996a` (candidate tree
OID after the logbook entry; the implementation tree before that
evidence-only append was `276c515c90665327b991fe1cdf78ef8086cd409c`).
Working tree remains uncommitted by contract.

## Acceptance rows

| Row | Production call site | Named test | Result |
| --- | --- | --- | --- |
| Superseded lease append is refused while the tail still names the old lease | `sessrepo.Repository.AppendEvent` → `checkWinningLease` | `internal/sessrepo/sessrepo_test.go:TestAppendEventRefusesSupersededLeaseWhileTailStillMatches`; composing entries `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches`, `TestEmitReachesAppendAdmissionGateAfterStaleObservation`, `TestEmitParkedReachesAppendAdmissionGateAfterStaleObservation` | Lower epoch returns literal `ErrStaleLease`; same-epoch loser returns literal `ErrDivergentBranch`; event bytes are preserved and the authoritative chain is unchanged. **Driven: 1 of 1.** |
| Losing-lease `profile.changed` cannot become the effective profile source | `axpane.Run` → `sessrepo.Repository.AppendEvent` → `sessprofile.LoadProfile`/`Derive` | `internal/axpane/rework_test.go:TestLosingLeaseProfileEventIgnored` | Production append refuses the losing event; `Derive` remains standard with no source; `Run` cannot launch yolo or use the losing event source. **Driven: 1 of 1.** |

Task AC ratio: **2 of 2 AC rows driven** through named production call
sites. The archived probe-15 before-state is retained as historical
evidence, and an API-adapted direct baseline reproduction logs
`profile=yolo` and mapping
`--dangerously-bypass-approvals-and-sandbox`. The current candidate
uses an API-adapted direct production probe for probe 9; the old wrapper
archive itself cannot be claimed as a literal current-tree rerun because
the API has since evolved.

## Gate × entry census

The new gate is `checkWinningLease`, called by the production
`Repository.AppendEvent` entry. Existing `checkAppend` continuity logic
is unchanged and remains covered by its existing sessrepo census.

| Gate arm | Direct `AppendEvent` | `Transactor.SetProfile` | `axpane.Emit` | `axpane.EmitParked` |
| --- | --- | --- | --- | --- |
| Lower epoch, `ErrStaleLease` | `TestAppendEventRefusesSupersededLeaseWhileTailStillMatches` | `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches/lower_epoch` | `TestEmitReachesAppendAdmissionGateAfterStaleObservation` | `TestEmitParkedReachesAppendAdmissionGateAfterStaleObservation` |
| Same epoch, losing lease, `ErrDivergentBranch` | `TestAppendEventRefusesSameEpochLosingLeaseWhileTailStillMatches` | `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches/same_epoch_loser` | `TestEmitReachesSameEpochAppendAdmissionGate` | `TestEmitParkedReachesSameEpochAppendAdmissionGate` |

Gate-entry ratio: **8 of 8 cells driven**. Symmetry: lower-epoch
**4 of 4**, same-epoch loser **4 of 4**, total **8 of 8**. No cell is
unreachable and no stated-bound cell is substituted for a test.

## Narrowing evidence

Harness: `PYTHONDONTWRITEBYTECODE=1 python3
internal/sessrepo/testdata/mutate_append_admission.py
<evidence-dir>`; final run is under
`.temp/BUG-260917-3lddu0/mutants-append-03/`.

| Plant | Narrowing | Behavioral mask | Classification |
| --- | --- | --- | --- |
| `N-stale-winning-admission` | Keeps `checkWinningLease` present but makes the lower-epoch arm admit the tested stale class | `TestAppendEventRefusesSupersededLeaseWhileTailStillMatches`, `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches`, `TestEmitReachesAppendAdmissionGateAfterStaleObservation`, `TestEmitParkedReachesAppendAdmissionGateAfterStaleObservation` | **KILLED**, subprocess exit 1; control-before/after exit 0 |
| `N-same-epoch-winning-admission` | Keeps the lower-epoch arm but makes the same-epoch losing arm admit the tested loser class | `TestAppendEventRefusesSameEpochLosingLeaseWhileTailStillMatches`, `TestSetProfileRefusesSupersededLeaseWhileTailStillMatches`, `TestEmitReachesSameEpochAppendAdmissionGate`, `TestEmitParkedReachesSameEpochAppendAdmissionGate` | **KILLED**, subprocess exit 1; control-before/after exit 0 |
| `C-harmless-comment` | Comment-only change | `TestAppendEventChainInOrder` | **SURVIVED**, expected control |
| `C-not-applied` | Replacement token absent | no plant run | **NOT_APPLIED**, not counted as a kill |
| `C-compile-failure` | Deliberate syntax failure | `TestAppendEventChainInOrder` | **COMPILE_OR_HARNESS_FAILURE**, not counted as a behavioral kill |

The gate does not inspect source text, so a token-preserving source-text
mutant is not applicable. Both real gates have narrowing mutants; neither
is delete-only.

## Complete importer comparison

Command mask (used for both before and after):

```text
go test -json -count=1 ./internal/axpane ./internal/crashgate ./internal/fencing ./internal/sessckpt ./internal/sessprofile ./internal/sessquery ./internal/sessstate ./internal/termbind ./internal/terminstance
```

| Measurement | Before | Candidate after |
| --- | ---: | ---: |
| Package summaries | 9 PASS | 9 PASS |
| Outcome keys | 2,018 | 2,025 |
| Added outcomes | — | 7 named new negative-test outcomes |
| Removed outcomes | — | 0 |
| Changed existing outcomes | — | 0 |

The seven additions are the four `Emit`/`EmitParked` gate-entry tests,
the `SetProfile` parent, and its `lower_epoch` and `same_epoch_loser`
subtests. No existing importer input moved from PASS to FAIL or changed
arms. The direct sessrepo tests are intentionally outside this importer
mask and are named in the gate census above. Raw JSONL and the normalized
comparison are in `.temp/BUG-260917-3lddu0/importer-outcomes/`.

## Story-final traceability and README pin

The candidate registry contains the two Story acceptance cases and lists
all seven append-admission test declarations. The canonical projection
digest was re-derived from the registry as it stands in the candidate:

```text
ed6f016f73e390071743b09aded229e781d95408b0b9eeb3f134fcb87bb9a893
```

Exact-tree `go run ./internal/traceability/cmd/tracecheck` output:

```text
traceability ok: contracts=64 normative_sections=36 acceptance_cases=154 fixtures=33 compatibility_contracts=55 assigned_scopes=0
section coverage: bindings=69 full=4 partial=9 sliver=9 unevidenced=43 unmeasured=4 unowned=7 clauses_discharged=70/574
```

The README measured-coverage code block is byte-equal to the second line.
`-section 2.4` exits 0; `-section 5.3` exits 1 as required because its
binding is partial at 7/8, and the refusal names that measured ratio.

## Carried P3 dispositions

- The axpane `decide.go` doc-comment qualifier “lapsed grants refuse” is
  unchanged and is scoped to the local-owner path; no misleading source
  edit was made in this leaf.
- `observeRemoteWinner` structural redundancy is recorded only. It was
  not simplified because the outer `StaleRelativeToWinner` fallback is
  the measured composition boundary.
- The remote interactive owner with no grant at step 4 remains an
  unresolved product question. This leaf records it and makes no
  product decision.
- Evidence hygiene is explicit: candidate tree OIDs are recorded above,
  and every row count has its exact command/test mask beside it.

## Validation and evidence paths

All 30 commands from `spawn.worktree_isolation.validation.commands`
exited 0. This includes the full uncached suite, race suite, coverage,
all configured fuzz lanes, tracecheck, catalog freshness, Linux and
Windows builds, JSON parsing, `task-board validate`, and `git diff --check`.
The additional required `GOOS=windows GOARCH=amd64 go vet ./...` exited 0.
`task-board validate` printed pre-existing board-wide `MISSING_ACTIVITY`
diagnostics but exited 0; none named this task.

Key evidence:

- `.temp/BUG-260917-3lddu0/baseline-probe-9-direct.log`
- `.temp/BUG-260917-3lddu0/baseline-probe-15-direct.log`
- `.temp/BUG-260917-3lddu0/source-evidence/rev1/evidence/logs/11-review-probe-15.log`
- `.temp/BUG-260917-3lddu0/final-tests/`
- `.temp/BUG-260917-3lddu0/mutants-append-03/`
- `.temp/BUG-260917-3lddu0/importer-outcomes/`
- `.temp/BUG-260917-3lddu0/traceability/`
- `.temp/BUG-260917-3lddu0/validation/`

The candidate is intentionally UNCOMMITTED for Story snapshot handoff.
