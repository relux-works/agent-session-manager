#!/bin/zsh
REV=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/BUG-260917-3lddu0/review-rev1
PKGS="./internal/axpane ./internal/crashgate ./internal/fencing ./internal/sessckpt ./internal/sessprofile ./internal/sessquery ./internal/sessstate ./internal/termbind ./internal/terminstance"
mkdir -p $REV/grids
for tree in trunk ckpt cand; do
  cd $REV/$tree || exit 99
  rm -f internal/axpane/zz_review_probe_test.go
  echo "=== grid $tree start $(date -u) load:$(uptime | sed 's/.*load averages://')" >> $REV/logs/40-grids.log
  go test -json -count=1 ${=PKGS} > $REV/grids/$tree.jsonl 2> $REV/grids/$tree.stderr
  echo "grid $tree exit=$? end $(date -u)" >> $REV/logs/40-grids.log
done
echo DONE >> $REV/logs/40-grids.log
