#!/bin/zsh
REV=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/BUG-260917-3lddu0/review-rev1
SUITE=$REV/suite
WT=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree
run() { # num, dir, command...
  local n=$1; local dir=$2; shift 2
  local start=$(date +%s)
  echo "=== cmd $n in $dir: $* | start $(date -u +%H:%M:%S) load:$(uptime | sed 's/.*load averages://')" >> $SUITE/summary.log
  (cd "$dir" && eval "$*") > $SUITE/cmd-$n.log 2>&1
  local rc=$?
  echo "$rc" > $SUITE/cmd-$n.exit
  echo "cmd $n rc=$rc elapsed=$(( $(date +%s) - start ))s" >> $SUITE/summary.log
}
C=$REV/cand-suite
run 01 $WT 'test -z "$(gofmt -l $(git ls-files --cached --others --exclude-standard -- "*.go"))"'
run 02 $C 'go build ./...'
run 03 $C 'go vet ./...'
run 04 $C 'go test ./... -count=1 -v'
run 05 $C 'go test ./... -race -count=1 -timeout 25m'
run 06 $C 'go test ./... -cover -count=1'
run 07 $C 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUntrustedEnvelopes$ -fuzztime=100x -parallel=1'
run 08 $C 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzClosedOperationBodies$ -fuzztime=100x -parallel=1'
run 09 $C 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1'
run 10 $C 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUnknownFields$ -fuzztime=100x -parallel=1'
run 11 $C 'go test ./internal/scalar -run=^$ -fuzz=^FuzzScalarProductionEntries$ -fuzztime=100x -parallel=1'
run 12 $C 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzCanonicalizeRoundTrip$ -fuzztime=100x -parallel=1'
run 13 $C 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObjectIdentityRepresentationInvariant$ -fuzztime=100x -parallel=1'
run 14 $C 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzClosedIdentityShapeRefusal$ -fuzztime=100x -parallel=1'
run 15 $C 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObservationEventRefusal$ -fuzztime=100x -parallel=1'
run 16 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckArgv$ -fuzztime=100x -parallel=1'
run 17 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckMemberPath$ -fuzztime=100x -parallel=1'
run 18 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzIsEnvName$ -fuzztime=100x -parallel=1'
run 19 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRedactCorpus$ -fuzztime=100x -parallel=1'
run 20 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzEscapeForTerminal$ -fuzztime=100x -parallel=1'
run 21 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRenderForTerminal$ -fuzztime=100x -parallel=1'
run 22 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzGuardResolve$ -fuzztime=100x -parallel=1'
run 23 $C 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzDetectCaseCollision$ -fuzztime=100x -parallel=1'
run 24 $C 'go run ./internal/traceability/cmd/tracecheck'
run 25 $C 'go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check'
run 26 $C 'GOOS=linux GOARCH=amd64 go build ./...'
run 27 $C 'GOOS=windows GOARCH=amd64 go build ./...'
run 28 $WT "git ls-files -z '*.json' | xargs -0 -n1 python3 -c 'import json,sys;json.load(open(sys.argv[1]))'"
run 29 $WT 'task-board validate'
run 30 $WT 'git diff --check'
run 31 $C 'GOOS=windows GOARCH=amd64 go vet ./...'
echo "SUITE DONE $(date -u)" >> $SUITE/summary.log
