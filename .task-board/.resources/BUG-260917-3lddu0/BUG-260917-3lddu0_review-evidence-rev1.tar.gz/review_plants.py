#!/usr/bin/env python3
"""Reviewer plants for BUG-260917-3lddu0 CR rev1 (RUN-260921-f25edb).

Each plant is applied to an isolated copy of the candidate tree by exact
single-occurrence replacement, the behavioral suite of the three packages that
reach the gate is executed (full packages, not a -run mask), the raw log and
subprocess exit are kept per plant per pass, and the source bytes are restored
and verified after every plant.
"""
import hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path

REV = Path(__file__).resolve().parent
SRC = REV / "cand"
OUT = Path(sys.argv[1]).resolve()
PASSES = int(sys.argv[2]) if len(sys.argv) > 2 else 2
OUT.mkdir(parents=True, exist_ok=True)
COPY = OUT / "plants-source"
if COPY.exists():
    raise SystemExit("refusing to overwrite an existing plants source")
shutil.copytree(SRC, COPY, symlinks=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
SUITE = ["go", "test", "./internal/sessrepo", "./internal/sessprofile", "./internal/axpane", "-count=1", "-v"]

PLANTS = [
  # name, file, old, new, kind, expectation note
  ("R1-wrong-winner-oldest-lease", "internal/sessrepo/sessrepo.go",
   "if err := checkWinningLease(leases[len(leases)-1], event); err != nil {",
   "if err := checkWinningLease(leases[0], event); err != nil {",
   "narrowing (call site)", "gate compares against the OLDEST lease instead of the winner; admits every stale/same-epoch member once >=2 leases exist"),
  ("R2-one-epoch-behind-admitted", "internal/sessrepo/chain.go",
   "if event.leaseEpoch < winner.Epoch {",
   "if event.leaseEpoch+1 < winner.Epoch {",
   "narrowing", "admits exactly the class one epoch behind the winner (the tested 1-vs-2 member)"),
  ("R3-gate-skipped-below-three-leases", "internal/sessrepo/sessrepo.go",
   "if len(leases) > 0 {\n\t\tif err := checkWinningLease(",
   "if len(leases) > 2 {\n\t\tif err := checkWinningLease(",
   "narrowing (call site)", "gate wired only for sessions with >=3 leases; every tested world has exactly 2"),
  ("R4a-same-epoch-admit-smaller-id", "internal/sessrepo/chain.go",
   "if event.leaseEpoch == winner.Epoch && event.leaseID != winner.LeaseID {",
   "if event.leaseEpoch == winner.Epoch && event.leaseID > winner.LeaseID {",
   "narrowing", "admits a same-epoch lease whose ID is bytewise smaller than the winner's (the axpane members ...0005/...0007)"),
  ("R4b-same-epoch-admit-greater-id", "internal/sessrepo/chain.go",
   "if event.leaseEpoch == winner.Epoch && event.leaseID != winner.LeaseID {",
   "if event.leaseEpoch == winner.Epoch && event.leaseID < winner.LeaseID {",
   "narrowing", "admits a same-epoch lease whose ID is bytewise greater than the winner's (the sessrepo/sessprofile member C > B)"),
  ("R5-no-preserve-on-stale", "internal/sessrepo/sessrepo.go",
   "\t\t\t// untouched, including when the old lease is still the tail.\n\t\t\tif errors.Is(err, ErrDivergentBranch) || errors.Is(err, ErrStaleLease) {",
   "\t\t\t// untouched, including when the old lease is still the tail.\n\t\t\tif errors.Is(err, ErrDivergentBranch) {",
   "narrowing (preservation arm)", "a lower-epoch refusal no longer preserves the losing blob (5.3 'MUST be preserved')"),
  ("R6-no-preserve-on-same-epoch", "internal/sessrepo/sessrepo.go",
   "\t\t\t// untouched, including when the old lease is still the tail.\n\t\t\tif errors.Is(err, ErrDivergentBranch) || errors.Is(err, ErrStaleLease) {",
   "\t\t\t// untouched, including when the old lease is still the tail.\n\t\t\tif errors.Is(err, ErrStaleLease) {",
   "narrowing (preservation arm)", "a same-epoch-loser refusal no longer preserves the losing blob"),
  ("R7-setprofile-mints-successor-epoch", "internal/sessprofile/setprofile.go",
   "\t\tLeaseEpoch:      request.LeaseEpoch,\n\t\tLeaseID:         request.LeaseID,\n\t\tSequence:        sequence,",
   "\t\tLeaseEpoch:      request.LeaseEpoch + 1,\n\t\tLeaseID:         request.LeaseID,\n\t\tSequence:        sequence,",
   "wrong-arm (composing entry)", "SetProfile mints the event one epoch up: the stale member now trips the same-epoch arm instead of ErrStaleLease"),
  ("R8-stale-arm-collapsed-into-divergent", "internal/sessrepo/chain.go",
   "return refuse(ErrStaleLease, \"event lease epoch %d precedes winning lease epoch %d\", event.leaseEpoch, winner.Epoch)",
   "return refuse(ErrDivergentBranch, \"event lease epoch %d precedes winning lease epoch %d\", event.leaseEpoch, winner.Epoch)",
   "code swap (same exit)", "the lower-epoch refusal reports the sibling sentinel; tests must assert the literal ErrStaleLease"),
  ("C-harmless-comment-sessrepo", "internal/sessrepo/sessrepo.go",
   "// AppendEvent validates eventJSON through the canonical owner and links it",
   "// AppendEvent validates eventJSON through the canonical owner and then links it",
   "control", "comment-only change must SURVIVE"),
]

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

results = []
for n in range(1, PASSES + 1):
    for name, rel, old, new, kind, note in PLANTS:
        path = COPY / rel
        original = path.read_bytes()
        text = original.decode()
        count = text.count(old)
        row = {"pass": n, "plant": name, "file": rel, "kind": kind, "note": note, "occurrences": count}
        if count != 1:
            row["classification"] = "NOT_APPLIED"
            results.append(row); print(n, name, "NOT_APPLIED", count, flush=True); continue
        path.write_text(text.replace(old, new, 1))
        row["planted_sha256"] = sha(path)
        log = OUT / f"pass{n}-{name}.log"
        started = time.time()
        try:
            with log.open("w") as fh:
                fh.write(f"# plant {name} pass {n} {kind}\n# {rel}: {old!r} -> {new!r}\n# command: {' '.join(SUITE)}\n# started {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} load {os.getloadavg()}\n")
                fh.flush()
                proc = subprocess.run(SUITE, cwd=COPY, env=env, stdout=fh, stderr=subprocess.STDOUT, timeout=1500)
            body = log.read_text()
            fails = re.findall(r"^\s*--- FAIL: (\S+)", body, re.M)
            ran = bool(re.search(r"^=== RUN ", body, re.M))
            pkg_fail = re.findall(r"^FAIL\s+(\S+)", body, re.M)
            if not ran or proc.returncode not in (0, 1):
                cls = "COMPILE_OR_HARNESS_FAILURE"
            elif proc.returncode == 0:
                cls = "SURVIVED"
            elif fails:
                cls = "KILLED"
            else:
                cls = "COMPILE_OR_HARNESS_FAILURE"
            row.update({"classification": cls, "exit": proc.returncode, "failed_tests": fails, "failed_packages": pkg_fail, "elapsed_s": round(time.time() - started, 1)})
            with log.open("a") as fh:
                fh.write(f"# exit={proc.returncode} classification={cls} elapsed={row['elapsed_s']}s\n")
        finally:
            path.write_bytes(original)
            if path.read_bytes() != original:
                raise SystemExit(f"restore failed for {rel}")
        results.append(row)
        print(n, name, row["classification"], row.get("exit"), ", ".join(fails), flush=True)

(OUT / "plants.json").write_text(json.dumps(results, indent=2) + "\n")
# restore census: every file in COPY/internal must equal SRC/internal
diff = subprocess.run(["diff", "-rq", str(SRC / "internal"), str(COPY / "internal")], capture_output=True, text=True)
(OUT / "restore-census.txt").write_text(diff.stdout + diff.stderr)
print("restore census diff exit", diff.returncode, flush=True)
