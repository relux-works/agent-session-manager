package axpane

// Reviewer probes, part 2 (BUG-260917-3lddu0 CR rev1): composing writers on
// the happy path after a takeover, the never-minted higher-epoch class, and
// the no-lease-store bound. Outcomes are logged; FINDING lines are t.Errorf.

import (
	"errors"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessprofile"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

func reviewObservationFor(now time.Time, epoch uint64, leaseID string) fencing.Observation {
	observation := fixtureObservation(now)
	observation.Winner.Epoch = epoch
	observation.Winner.LeaseID = leaseID
	observation.Winner.Reason = "graceful_takeover"
	observation.Grant.Token.Epoch = epoch
	observation.Grant.Token.LeaseID = leaseID
	return observation
}

// COMPOSING WRITERS — the successor (the durable winner) must keep working:
// Emit, EmitParked and SetProfile under the winning lease succeed, and a
// second SetProfile under the winner replays/advances as before.
func TestReviewComposingWritersUnderTheWinner(t *testing.T) {
	world := buildRunWorld(t)
	successor := "cccccccc-dddd-4eee-8fff-000000000009"
	reviewSuccessor(t, world, successor, fixtureLocalHost)
	observation := reviewObservationFor(fixtureNow(), 2, successor)
	presented := fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: successor}
	resumedRef, _, err := Emit(world.repo, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 2, LeaseID: successor, LeaseSequence: 1,
		Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
		EventType: "session.idle", SchemaVersion: "1.0.0",
		Payload:   map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true},
		Presented: presented, Observation: observation,
	})
	t.Logf("WRITERS/Emit under winner (2,%s) seq 1: ref=%+v err=%v", successor[:8], resumedRef, err)
	if err != nil {
		t.Errorf("FINDING: Emit under the durable winner was refused: %v", err)
	}
	sp, err := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(sessprofile.SetProfileRequest{
		SessionID: fixtureSession, To: "yolo", Confirmed: true, LeaseEpoch: 2, LeaseID: successor,
		CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("WRITERS/SetProfile under winner -> yolo: previous=%q new=%q ref=%+v err=%v", sp.PreviousProfile, sp.NewProfile, sp.Ref, err)
	if err != nil {
		t.Errorf("FINDING: SetProfile under the durable winner was refused: %v", err)
	}
	head, perr := (&sessprofile.Projector{Repo: world.repo}).Project(fixtureSession)
	t.Logf("WRITERS/session-head derivation after winner set-profile: pair=%+v err=%v", head, perr)
	if perr != nil || head.Profile != "yolo" || !head.HasSource || head.Source != sp.EventID {
		t.Errorf("FINDING: the winner's confirmed profile.changed did not become the effective source")
	}
	replay, err := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(sessprofile.SetProfileRequest{
		SessionID: fixtureSession, To: "yolo", Confirmed: true, LeaseEpoch: 2, LeaseID: successor,
		CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("WRITERS/SetProfile identical retry: eventID equal=%v err=%v", replay.EventID == sp.EventID, err)
	if err != nil || replay.EventID != sp.EventID {
		t.Errorf("FINDING: identical set-profile retry under the winner did not replay")
	}
	// A parked emission under the winner: the epoch-1 winner A parks after
	// created -> failed (the same foldable shape the candidate's own EmitParked
	// test uses), with no successor, so the gate sees the winner itself.
	parkedWorld := buildRunWorld(t)
	failedID := appendChainEvent(t, parkedWorld.repo, "session.failed", 1, fixtureLeaseA, 2, parkedWorld.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	parkedRef, _, err := EmitParked(parkedWorld.repo, Decision{Action: ActionParked, ParkReason: fencing.ParkStaleOwner, WinningLeaseID: fixtureLeaseA}, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{failedID}, CreatedAt: fixtureCreatedAt,
		Presented: fixturePresented(), Observation: fixtureObservation(fixtureNow()),
	})
	t.Logf("WRITERS/EmitParked under the epoch-1 winner (created -> failed -> parked): ref=%+v err=%v", parkedRef, err)
	if err != nil {
		t.Errorf("FINDING: EmitParked under the durable winner was refused: %v", err)
	}
	events, _ := world.repo.ListEvents(fixtureSession)
	t.Logf("WRITERS/chain length (first world) = %d (created, idle, profile.changed expected = 3)", len(events))
}

// NEVER-MINTED HIGHER EPOCH — an event claiming (epoch 3, lease X) when the
// lease store's winner is (2, B) and X was never minted: is it "ambiguous"
// per §2.4 line 666, and does it become the effective profile source?
func TestReviewNeverMintedHigherEpochProfileChanged(t *testing.T) {
	world := buildRunWorld(t)
	reviewSuccessor(t, world, fixtureLeaseB, fixtureRemoteHost)
	phantom := "dddddddd-eeee-4fff-8aaa-000000000000"
	changed := reviewEvent(t, "profile.changed", 3, phantom, 1, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	ref, err := world.repo.AppendEvent(fixtureSession, changed)
	t.Logf("PHANTOM/append: profile.changed under never-minted (3,%s) with winner (2,B): ref=%+v err=%v", phantom[:8], ref, err)
	head, perr := (&sessprofile.Projector{Repo: world.repo}).Project(fixtureSession)
	t.Logf("PHANTOM/session-head derivation: pair=%+v err=%v", head, perr)
	winner, werr := world.repo.WinningLease(fixtureSession)
	t.Logf("PHANTOM/lease store winner after append: epoch=%d lease=%s err=%v", winner.Epoch, winner.LeaseID, werr)
	if err == nil && perr == nil && head.Profile == "yolo" {
		t.Errorf("OBSERVATION: a profile.changed under a never-minted higher-epoch lease was chained and became the effective source (stated bound in sessrepo/TRACEABILITY.md, no owner named)")
	}
	// Through the composing writers the same phantom is stopped earlier?
	sp, serr := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(sessprofile.SetProfileRequest{
		SessionID: fixtureSession, To: "standard", Confirmed: false, LeaseEpoch: 4, LeaseID: phantom,
		CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("PHANTOM/SetProfile under (4,phantom): new=%q err=%v", sp.NewProfile, serr)
}

// NO LEASE STORE — the gate is skipped when a session has no leases at all;
// record the bound: an append under any (epoch, lease) is admitted by
// checkAppend alone.
func TestReviewNoLeaseStoreBound(t *testing.T) {
	repository, recordID := chainFixture(t)
	// chainFixture mints the epoch-1 lease; build a lease-less session by
	// copying its record into a fresh repository.
	fresh, err := sessrepo.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	recordBytes, err := repository.GetRecord(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := fresh.CreateSession(recordBytes); err != nil {
		t.Fatal(err)
	}
	first, err := fresh.AppendEvent(fixtureSession, reviewEvent(t, "session.created", 7, fixtureLeaseB, 1, recordID, map[string]any{
		"session_record_id": recordID, "bootstrap_operation_id": fixtureBootstrap, "first_checkpoint_operation_id": fixtureOtherOp,
	}))
	t.Logf("NOLEASE/append (7,B) seq 1 with no lease store: ref=%+v err=%v", first, err)
	leases, _ := fresh.ListLeases(fixtureSession)
	t.Logf("NOLEASE/lease count = %d", len(leases))
	if err != nil && !errors.Is(err, sessrepo.ErrStaleLease) {
		t.Logf("NOLEASE/refused for another reason: %v", err)
	}
}
