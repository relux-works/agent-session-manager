package traceability

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"testing"
)

// Reviewer re-derivation of reviewedOwnershipCanonicalSHA256 from the
// registry bytes as they stand in the candidate tree, through the same
// decode + json.Marshal projection VerifyRepository uses.
func TestReviewRederiveRegistryDigest(t *testing.T) {
	raw, err := os.ReadFile("ownership.v0.7.0.json")
	if err != nil {
		t.Fatal(err)
	}
	registry, err := decodeOwnershipRegistry(raw)
	if err != nil {
		t.Fatal(err)
	}
	canonical, err := json.Marshal(registry)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(canonical)
	got := hex.EncodeToString(sum[:])
	t.Logf("re-derived registry projection digest = %s", got)
	t.Logf("pinned reviewedOwnershipCanonicalSHA256  = %s", reviewedOwnershipCanonicalSHA256)
	t.Logf("raw file sha256 = %x (bytes=%d) acceptance_cases=%d ownership_groups=%d", sha256.Sum256(raw), len(raw), len(registry.AcceptanceCases), len(registry.Ownership))
	if got != reviewedOwnershipCanonicalSHA256 {
		t.Fatalf("digest mismatch")
	}
}
