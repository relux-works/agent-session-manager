package axpane

// Reviewer probes for BUG-260917-3lddu0 CR rev1 (RUN-260921-f25edb).
// Adapted from TASK-260830-1geqhj_review-evidence-rev1 probes 9 and 15 to
// the current Emit/EmitParked API (Presented + Observation are required by
// fencing.AuthorizeMutation; the observation is a caller snapshot and may be
// stale). Every probe LOGS outcomes and marks findings; it never t.Fatal()s
// on the behaviour under measurement so both trees report every step.

import (
	"errors"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessprofile"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

func reviewSuccessor(t *testing.T, world *runWorld, leaseID, host string) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[len(leases)-1].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: leaseID, HolderHostID: host, IssuedByHostID: host, CreatedAt: fixtureCreatedAt},
		Reason:           "graceful_takeover",
		CheckpointID:     world.ckptID,
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

func reviewEvent(t *testing.T, eventType string, epoch uint64, leaseID string, sequence int, predecessor string, payload map[string]any) []byte {
	t.Helper()
	return identifyObject(t, map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureSession, "session_id": fixtureSession, "event_type": eventType, "created_by_host_id": fixtureLocalHost,
		"lease_epoch": epoch, "lease_id": leaseID, "lease_sequence": sequence, "predecessors": []string{predecessor},
		"created_at": fixtureCreatedAt, "payload": payload, "extensions": map[string]any{},
	}, "event_id")
}

// PROBE 9 (adapted) — append under a superseded lease while the tail still
// sits on it, through the three production entries that reach AppendEvent.
func TestReviewProbe9StaleLeaseAppendWhileTailMatches(t *testing.T) {
	t.Run("direct AppendEvent", func(t *testing.T) {
		world := buildRunWorld(t)
		reviewSuccessor(t, world, fixtureLeaseB, fixtureRemoteHost)
		ref, err := world.repo.AppendEvent(fixtureSession, reviewEvent(t, "session.idle", 1, fixtureLeaseA, 2, world.headID, map[string]any{
			"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true,
		}))
		t.Logf("PROBE9/direct: AppendEvent under A epoch 1 (winner B epoch 2, tail at A): ref=%+v err=%v stale=%v", ref, err, errors.Is(err, sessrepo.ErrStaleLease))
		events, _ := world.repo.ListEvents(fixtureSession)
		t.Logf("PROBE9/direct: chain length after = %d", len(events))
		if err == nil {
			t.Errorf("FINDING: direct AppendEvent admitted a superseded-lease event while the tail still matched")
		}
	})
	t.Run("EmitParked stale observation", func(t *testing.T) {
		world := buildRunWorld(t)
		failedID := appendChainEvent(t, world.repo, "session.failed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
			"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
		})
		reviewSuccessor(t, world, fixtureLeaseB, fixtureRemoteHost)
		decision := Decision{Action: ActionParked, ParkReason: fencing.ParkStaleOwner, WinningLeaseID: fixtureLeaseA}
		ref, _, err := EmitParked(world.repo, decision, EmitParams{
			SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
			LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
			Predecessors: []string{failedID}, CreatedAt: fixtureCreatedAt,
			Presented: fixturePresented(), Observation: fixtureObservation(fixtureNow()),
		})
		t.Logf("PROBE9/EmitParked: under A epoch 1 (winner B epoch 2, tail at A, stale observation): ref=%+v err=%v stale=%v", ref, err, errors.Is(err, sessrepo.ErrStaleLease))
		if err == nil {
			t.Errorf("FINDING: EmitParked admitted a superseded-lease parked event while the tail still matched")
		}
	})
	t.Run("Emit stale observation", func(t *testing.T) {
		world := buildRunWorld(t)
		reviewSuccessor(t, world, fixtureLeaseB, fixtureRemoteHost)
		ref, _, err := Emit(world.repo, EmitParams{
			SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
			LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 2,
			Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
			EventType: "profile.changed", SchemaVersion: "1.0.0",
			Payload:   map[string]any{"from": "standard", "to": "yolo", "confirmed": true},
			Presented: fixturePresented(), Observation: fixtureObservation(fixtureNow()),
		})
		t.Logf("PROBE9/Emit: profile.changed under A epoch 1 (winner B epoch 2, tail at A, stale observation): ref=%+v err=%v stale=%v", ref, err, errors.Is(err, sessrepo.ErrStaleLease))
		if err == nil {
			t.Errorf("FINDING: Emit admitted a superseded-lease profile.changed while the tail still matched")
		}
	})
	t.Run("SetProfile under superseded lease", func(t *testing.T) {
		world := buildRunWorld(t)
		reviewSuccessor(t, world, fixtureLeaseB, fixtureRemoteHost)
		result, err := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(sessprofile.SetProfileRequest{
			SessionID: fixtureSession, To: "yolo", Confirmed: true, LeaseEpoch: 1, LeaseID: fixtureLeaseA,
			CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
		})
		t.Logf("PROBE9/SetProfile: to=yolo under A epoch 1 (winner B epoch 2, tail at A): result.NewProfile=%q err=%v stale=%v", result.NewProfile, err, errors.Is(err, sessrepo.ErrStaleLease))
		if err == nil {
			t.Errorf("FINDING: SetProfile admitted a superseded-lease profile change while the tail still matched")
		}
	})
}

// PROBE 15 (adapted) — §2.4: a profile.changed under losing lease A after
// local successor A2 (epoch 2) won; observe the append outcome, the
// session-head derivation (Projector.Project == what `ax profile get` and
// SetProfile's from-end read), and the Run launch profile/mapping.
func TestReviewProbe15LosingLeaseProfileChanged(t *testing.T) {
	world := buildRunWorld(t)
	successor := "cccccccc-dddd-4eee-8fff-000000000002"
	reviewSuccessor(t, world, successor, fixtureLocalHost)
	changed := reviewEvent(t, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	ref, err := world.repo.AppendEvent(fixtureSession, changed)
	t.Logf("PROBE15/append: profile.changed under losing A epoch 1 after A2 epoch 2 won (tail at A): ref=%+v err=%v stale=%v", ref, err, errors.Is(err, sessrepo.ErrStaleLease))
	head, perr := (&sessprofile.Projector{Repo: world.repo}).Project(fixtureSession)
	t.Logf("PROBE15/session-head derivation (Projector.Project -> Derive): pair=%+v err=%v", head, perr)
	if perr == nil && head.Profile == "yolo" {
		t.Errorf("FINDING: session-head effective profile is yolo sourced from the losing-lease event %s", head.Source)
	}
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: successor}
	outcome, rerr := Run(world.stores(), request)
	if rerr != nil {
		t.Logf("PROBE15/Run: error = %v", rerr)
	} else {
		t.Logf("PROBE15/Run: action=%s class=%q profile=%+v mapping=%q", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Profile, outcome.Decision.Mapping)
		if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Profile == "yolo" {
			t.Errorf("FINDING: Run launched with the losing-lease yolo profile, mapping %q", outcome.Decision.Mapping)
		}
	}
	// SetProfile's from-end reads the session-head derivation: a successor
	// changing to standard after the losing yolo shows what SetProfile
	// believes the current profile is.
	sp, serr := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(sessprofile.SetProfileRequest{
		SessionID: fixtureSession, To: "standard", Confirmed: false, LeaseEpoch: 2, LeaseID: successor,
		CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("PROBE15/SetProfile(successor A2 -> standard): previous=%q new=%q err=%v", sp.PreviousProfile, sp.NewProfile, serr)
}
