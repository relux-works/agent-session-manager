package sessrepo

import (
	"encoding/json"
	"errors"
	"os"
	"testing"
)

// Reviewer probe: the refusal path's durable write (blob preservation) must
// be idempotent — refusing the identical losing event twice returns the same
// refusal and leaves one preserved blob; the chain stays untouched.
func TestReviewRefusedLosingEventRetryIsIdempotent(t *testing.T) {
	repository := openTestRepository(t)
	reference := createTestSession(t, repository)
	firstLease := mustCreateLease(t, repository, testSessionID, createLeaseFixture())
	first, _ := appendTestEvent(t, repository, testSessionID, []string{reference.RecordID}, firstLease.Epoch, firstLease.LeaseID, 1, "session.created", createdPayload(reference.RecordID))
	mustCompareAndSwap(t, repository, testSessionID, LeaseExpectation{RecordID: firstLease.RecordID}, successorLeaseFixture())
	losing := buildEvent(t, eventOptions{
		sessionID: testSessionID, predecessors: []string{first.EventID}, epoch: firstLease.Epoch, leaseID: firstLease.LeaseID,
		sequence: 2, eventType: "profile.changed", payload: map[string]any{"from": "standard", "to": "yolo", "confirmed": true},
	})
	_, err1 := repository.AppendEvent(testSessionID, losing)
	_, err2 := repository.AppendEvent(testSessionID, losing)
	t.Logf("IDEMP/refusal 1: %v", err1)
	t.Logf("IDEMP/refusal 2 (identical bytes): %v", err2)
	if !errors.Is(err1, ErrStaleLease) || !errors.Is(err2, ErrStaleLease) {
		t.Errorf("FINDING: retried refusal is not the same stale refusal")
	}
	events, _ := repository.ListEvents(testSessionID)
	entries, _ := os.ReadDir(blobPathFor(t, repository, testSessionID, first.EventID) + "/..")
	t.Logf("IDEMP/chain length=%d event blobs on disk=%d (created + preserved losing = 2 expected)", len(events), len(entries))
	if len(events) != 1 {
		t.Errorf("FINDING: chain changed under a refused retry")
	}
	// same-epoch loser twice
	repository2 := openTestRepository(t)
	reference2 := createTestSession(t, repository2)
	tail, _ := appendTestEvent(t, repository2, testSessionID, []string{reference2.RecordID}, 2, testLeaseIDC, 1, "session.created", createdPayload(reference2.RecordID))
	firstLease2 := mustCreateLease(t, repository2, testSessionID, createLeaseFixture())
	mustCompareAndSwap(t, repository2, testSessionID, LeaseExpectation{RecordID: firstLease2.RecordID}, successorLeaseFixture())
	losing2 := buildEvent(t, eventOptions{sessionID: testSessionID, predecessors: []string{tail.EventID}, epoch: 2, leaseID: testLeaseIDC, sequence: 2, eventType: "session.idle", payload: idlePayload()})
	_, e1 := repository2.AppendEvent(testSessionID, losing2)
	_, e2 := repository2.AppendEvent(testSessionID, losing2)
	t.Logf("IDEMP/same-epoch refusal 1: %v", e1)
	t.Logf("IDEMP/same-epoch refusal 2: %v", e2)
	if !errors.Is(e1, ErrDivergentBranch) || !errors.Is(e2, ErrDivergentBranch) {
		t.Errorf("FINDING: retried same-epoch refusal is not the same divergent refusal")
	}
	var id struct{ EventID string `json:"event_id"` }
	_ = json.Unmarshal(losing2, &id)
	if _, err := os.Stat(blobPathFor(t, repository2, testSessionID, id.EventID)); err != nil {
		t.Errorf("OBSERVATION: same-epoch losing blob not preserved on disk: %v", err)
	} else {
		t.Logf("IDEMP/same-epoch losing blob preserved on disk")
	}
}
