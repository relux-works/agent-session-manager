#!/usr/bin/env python3
"""Normalize `go test -json` output into an OUTCOME grid: pkg|test -> pass/fail/skip.
Package-level rows are keyed pkg|<package>. Prints a summary and writes a TSV."""
import json, sys
from collections import OrderedDict
src, dst = sys.argv[1], sys.argv[2]
grid = OrderedDict()
pkg_status = OrderedDict()
with open(src) as fh:
    for line in fh:
        line = line.strip()
        if not line: continue
        try: ev = json.loads(line)
        except json.JSONDecodeError: continue
        act = ev.get("Action"); pkg = ev.get("Package", "").replace("github.com/relux-works/agent-session-manager/", "")
        test = ev.get("Test")
        if act in ("pass", "fail", "skip"):
            if test: grid[f"{pkg}|{test}"] = act
            else: pkg_status[pkg] = act
with open(dst, "w") as out:
    for k, v in sorted(grid.items()): out.write(f"{k}\t{v}\n")
    for k, v in sorted(pkg_status.items()): out.write(f"{k}|<package>\t{v}\n")
from collections import Counter
c = Counter(grid.values())
print(f"{src}: tests={len(grid)} pass={c['pass']} fail={c['fail']} skip={c['skip']} packages={dict(pkg_status)}")
