#!/bin/zsh
REV=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/BUG-260917-3lddu0/review-rev1
cd $REV/cand || exit 99
export PYTHONDONTWRITEBYTECODE=1
for n in 1 2; do
  echo "=== shipped harness pass $n: $(date -u) load: $(uptime | sed 's/.*load averages://')" >> $REV/logs/20-harness-passes.log
  rm -rf $REV/harness-run$n
  python3 internal/sessrepo/testdata/mutate_append_admission.py $REV/harness-run$n > $REV/logs/20-harness-pass$n.console.log 2>&1
  echo "pass $n exit=$?  $(date -u)" >> $REV/logs/20-harness-passes.log
done
echo "pycache census: $(find $REV/cand $REV/harness-run1 $REV/harness-run2 -name '__pycache__' -o -name '*.pyc' | wc -l)" >> $REV/logs/20-harness-passes.log
echo DONE >> $REV/logs/20-harness-passes.log
