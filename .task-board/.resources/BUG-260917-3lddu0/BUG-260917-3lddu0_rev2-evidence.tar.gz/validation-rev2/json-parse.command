git ls-files -z "*.json" | xargs -0 -n1 python3 -c 'import json,sys;json.load(open(sys.argv[1]))'
