go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check
