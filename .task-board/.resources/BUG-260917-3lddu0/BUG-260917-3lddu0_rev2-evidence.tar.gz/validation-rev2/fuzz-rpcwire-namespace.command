go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1
