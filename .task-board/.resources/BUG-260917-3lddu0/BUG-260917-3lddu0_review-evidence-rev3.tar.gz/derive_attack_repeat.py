from pathlib import Path
import subprocess,time,json,os
r=Path(__file__).resolve().parent; root=r/'candidate-probes'
rows=[]
def run(name,rel,old,new,cmd):
 name += '-repeat'; p=root/rel; original=p.read_bytes(); text=original.decode(); count=text.count(old)
 if count!=1: raise Exception((name,count))
 p.write_text(text.replace(old,new)); start=time.time()
 try:
  with (r/'logs'/(name+'.log')).open('w') as f:
   f.write(repr(cmd)+'\n'); f.flush(); q=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  row=dict(name=name,exit=q.returncode,elapsed=time.time()-start,command=cmd,old=old,new=new); rows.append(row); print(row,flush=True)
 finally:p.write_bytes(original)
run('derive-only-stale-profile','internal/sessprofile/profile.go','return nil, refuse(ErrStaleLease, "event %s lease epoch %d precedes chain head epoch %d", event.ID, lease.Epoch, current.Epoch)','if event.Type != "profile.changed" { return nil, refuse(ErrStaleLease, "event %s lease epoch %d precedes chain head epoch %d", event.ID, lease.Epoch, current.Epoch) }',['go','test','./internal/sessprofile','./internal/axpane','-count=1','-v','-run','TestDeriveRefusesLosingLeaseAndAmbiguity|TestLosingLeaseProfileEventIgnored'])
(r/'logs/derive-only-attack-repeat.json').write_text(json.dumps(rows,indent=2))
