import pathlib,json,subprocess,sys,os,time
r=pathlib.Path(__file__).resolve().parent; cwd=r/'candidate'; cmds=json.loads((r/'suite-config.json').read_text())
for i in map(int,sys.argv[1:]):
 cmd=cmds[i-1]
 if i==1:cmd="python3 -c 'import pathlib,subprocess,sys; p=subprocess.run([\"gofmt\",\"-l\"]+[str(p) for p in pathlib.Path(\".\").rglob(\"*.go\")],capture_output=True,text=True); print(p.stdout,end=\"\"); sys.exit(p.returncode or bool(p.stdout))'"
 if i==28:cmd="python3 -c 'import pathlib,json; [json.loads(p.read_text()) for p in pathlib.Path(\".\").rglob(\"*.json\")]; print(\"all archived JSON parsed\")'"
 start=time.time(); before=os.getloadavg(); log=r/'logs'/f'suite-{i:02}.log'
 with log.open('w') as f:
  f.write(cmd+'\n'); f.flush(); p=subprocess.run(cmd,shell=True,executable='/bin/zsh',cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
 row=dict(index=i,configured=cmds[i-1],executed=cmd,exit=p.returncode,elapsed=time.time()-start,start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),load_before=before,load_after=os.getloadavg())
 (r/'logs'/f'suite-{i:02}.json').write_text(json.dumps(row,indent=2)); print(json.dumps(row),flush=True)
