# Review evidence, CR revision 2

Candidate tree afb776578e26979c7c2da474116dfc1c95f8eafa; trunk/base 799c338e401fca0b24859c0b870cd665927209f2.

See the verdict for the interpretation and bounds. logs/ contains every raw output plus real command exits/timings/load. harness-pass*/ contains the two shipped batteries and raw per-plant outputs; reviewer-plants/ contains eight reviewer plants plus control, with the intentionally retained incomplete R12 mask; confirmation-plants/ contains R12's corrected two kills. probes/ contains current-API Go probes and the corrected blob-count instrument. instrumentation/ contains the two whole sessrepo source files used to log actual outcomes; *-runtime-grid.patch shows that instrumentation's exact delta. runtime-outcome-comparison.md reports all moved tuples.

Reproduce by exporting the given Git objects to sibling candidate/ and trunk/ folders. For grid runs, make candidate-grid/ and trunk-grid/ copies and replace only internal/sessrepo/sessrepo.go with the corresponding instrumentation file. Run grid.py from this folder. For the standalone probes, copy each file into the package its package declaration names. Shipped and reviewer mutation scripts create their own isolated copies. All source copies used during review were temporary; none was applied to the live Story worktree.

references/ records input resource identities and relevant producer claims. Prior sibling mutation evidence is referenced by its exact accepted resource, not represented as a new run. MANIFEST.sha256 covers every regular archive payload except itself. No runtime source tree or unrelated board-state archive is bundled.
