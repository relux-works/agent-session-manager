from pathlib import Path
import subprocess,time,json,os
r=Path(__file__).resolve().parent; root=r/'candidate-probes'
rows=[]
def run(name,rel,old,new,cmd):
 p=root/rel; original=p.read_bytes(); text=original.decode(); count=text.count(old)
 if count!=1: raise Exception((name,count))
 p.write_text(text.replace(old,new)); start=time.time()
 try:
  with (r/'logs'/(name+'.log')).open('w') as f:
   f.write(repr(cmd)+'\n'); f.flush(); q=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT)
  row=dict(name=name,exit=q.returncode,elapsed=time.time()-start,command=cmd,old=old,new=new); rows.append(row); print(row,flush=True)
 finally:p.write_bytes(original)
run('profile-independence','internal/sessrepo/chain.go','if event.leaseEpoch < winner.Epoch {','if event.leaseEpoch < winner.Epoch && event.eventType != "profile.changed" {',['go','test','./internal/axpane','-count=1','-v','-run','TestReviewProbe15|TestLosingLeaseProfileEventIgnored'])
run('readme-wrong-figure','README.md','clauses_discharged=70/574','clauses_discharged=71/574',['go','test','./internal/traceability/cmd/tracecheck','-count=1','-v','-run','^TestREADMEMeasuredCoverageMatchesTracecheckReport$'])
run('registry-disable-story-test','internal/axpane/rework_test.go','func TestLosingLeaseProfileEventIgnored(t *testing.T)','func DisabledLosingLeaseProfileEventIgnored(t *testing.T)',['go','run','./internal/traceability/cmd/tracecheck'])
(r/'logs/attacks.json').write_text(json.dumps(rows,indent=2))
