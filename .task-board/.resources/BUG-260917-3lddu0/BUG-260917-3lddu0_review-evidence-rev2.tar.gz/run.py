import pathlib, subprocess, time, os, json, sys
root=pathlib.Path(__file__).resolve().parent
cwd=root/sys.argv[1]; name=sys.argv[2]; command=sys.argv[3:]
log=root/'logs'/f'{name}.log'; log.parent.mkdir(exist_ok=True)
start=time.time(); before=os.getloadavg()
with log.open('w') as f:
 f.write('COMMAND '+repr(command)+'\n'); f.flush()
 p=subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
row=dict(name=name,cwd=str(cwd),command=command,exit=p.returncode,start_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime(start)),elapsed=time.time()-start,load_before=before,load_after=os.getloadavg())
(root/'logs'/f'{name}.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row),flush=True)
sys.exit(p.returncode)
