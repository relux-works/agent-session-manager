import pathlib,subprocess,json,collections,time,os,sys
r=pathlib.Path(__file__).resolve().parent; kind=sys.argv[1]; cwd=r/(kind+'-grid')
q=subprocess.run(['go','list','-f','{{.ImportPath}} {{join .Imports " "}} {{join .TestImports " "}} {{join .XTestImports " "}}','./...'],cwd=cwd,text=True,capture_output=True); assert q.returncode==0,q.stderr
owner='github.com/relux-works/agent-session-manager/internal/sessrepo'
packages=sorted(line.split()[0] for line in q.stdout.splitlines() if owner in line.split()[1:] and line.split()[0]!=owner)
(r/'logs'/f'grid-{kind}-importers.json').write_text(json.dumps(packages,indent=2))
cmd=['go','test','-json','-count=1']+packages
start=time.time(); log=r/'logs'/f'grid-{kind}.jsonl'
with log.open('w') as f:p=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT)
grid=collections.Counter(); status={}
for line in log.read_text().splitlines():
 try:x=json.loads(line)
 except ValueError:continue
 out=x.get('Output','').strip()
 if out.startswith('REVIEW_OUTCOME|'):grid[x['Package']+'|'+out]+=1
 if x.get('Action') in ('pass','fail','skip') and 'Test' not in x:status[x['Package']]=x['Action']
(r/'logs'/f'grid-{kind}-outcomes.json').write_text(json.dumps(dict(sorted(grid.items())),indent=2))
row=dict(exit=p.returncode,command=cmd,elapsed=time.time()-start,status=status,outcome_keys=len(grid),observations=sum(grid.values()))
(r/'logs'/f'grid-{kind}-summary.json').write_text(json.dumps(row,indent=2)); print(json.dumps(row),flush=True)
