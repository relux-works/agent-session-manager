import subprocess

def show(path):
    return subprocess.run(
        ["git", "show", f"HEAD:{path}"],
        check=True, capture_output=True, text=True).stdout

# --- 1. LOGBOOK: insert 3lt2xv block between 2zvo8m entry and 3uzfyn entry ---
head_lb = show("LOGBOOK.md").splitlines(keepends=True)
block = head_lb[7:12]  # header ### TASK-260917-3lt2xv + 4 bullets (0-based)
assert block[0].startswith("### TASK-260917-3lt2xv"), block[0]
assert block[4].startswith("- DOCS:"), block[4][:20]
assert head_lb[12].startswith("### TASK-260830-3uzfyn"), head_lb[12]

cur = open("LOGBOOK.md").read().splitlines(keepends=True)
anchor = "### TASK-260830-3uzfyn"
idx = next(i for i, l in enumerate(cur) if l.startswith(anchor))
assert cur[idx - 1].strip() == "", repr(cur[idx-1])
assert "candidate left uncommitted" in cur[idx - 3] + cur[idx - 2], cur[idx-3:idx]
# HEAD has the DOCS bullet immediately followed by the 3uzfyn header (no blank).
new = cur[:idx] + block + cur[idx:]
open("LOGBOOK.md", "w").write("".join(new))
print("LOGBOOK: inserted", len(block), "lines at", idx)

# --- 2. README regen block: restore -adopted hunk ---
head_rm = show("README.md")
cur_rm = open("README.md").read()
old_regen = """```bash
go generate ./internal/catalog
go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.6.0.json -contracts internal/specpin/v0.6.0.lock.json -output internal/catalog/catalog_gen.go -check
go test ./internal/catalog ./internal/cataloggen ./internal/catalog/cmd/cataloggen -count=1
```
"""
new_regen = """```bash
go generate ./internal/catalog
go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check
go test ./internal/catalog ./internal/cataloggen ./internal/catalog/cmd/cataloggen -count=1
```

The `-adopted` form derives the metadata and lock inputs from the code-level
adopted release, so the check stays valid when the adopted release changes.
The explicit equivalent pins the same inputs by path:

```bash
go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.6.0.json -contracts internal/specpin/v0.6.0.lock.json -output internal/catalog/catalog_gen.go -check
```
"""
assert new_regen in head_rm, "HEAD regen block mismatch"
assert cur_rm.count(old_regen) == 1, cur_rm.count(old_regen)
cur_rm = cur_rm.replace(old_regen, new_regen)

# --- 3. README tool row: restore -adopted command segment ---
old_seg = "`go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.6.0.json -contracts internal/specpin/v0.6.0.lock.json -output internal/catalog/catalog_gen.go -check`"
new_seg = "`go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check` (`-metadata`/`-contracts` select the same inputs explicitly)"
assert new_seg in head_rm, "HEAD tool-row segment mismatch"
# old_seg now occurs twice (restored explicit block + tool row); fix only the tool row.
tool_marker = "| Go toolchain |"
ti = cur_rm.index(tool_marker)
row_end = cur_rm.index("\n", ti)
row = cur_rm[ti:row_end]
assert row.count(old_seg) == 1, row.count(old_seg)
row = row.replace(old_seg, new_seg)
cur_rm = cur_rm[:ti] + row + cur_rm[row_end:]
open("README.md", "w").write(cur_rm)
print("README: regen block + tool row restored")
