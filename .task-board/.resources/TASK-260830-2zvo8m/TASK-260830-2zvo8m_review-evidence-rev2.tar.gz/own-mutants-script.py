import subprocess, shutil, os, sys
ROOT = os.getcwd()
cases = [
  {"name":"own-m1-matrix-gemini-wsl2-C-as-A","file":"internal/resumesmoke/matrix.go",
   "find":'return platformCell(platform, "gemini", CellAvailable, CellAvailable, CellConditional, CellAvailable)',
   "replace":'return platformCell(platform, "gemini", CellAvailable, CellAvailable, CellAvailable, CellAvailable)',
   "mask":"TestResumeMatrixCoversEverySpecRow","survive":False},
  {"name":"own-m2-probe-version-prefix","file":"internal/resumesmoke/smoke.go",
   "find":'if probed != run.params.Tuple {',
   "replace":'if probed.ProviderID != run.params.Tuple.ProviderID || probed.Platform != run.params.Tuple.Platform || probed.Architecture != run.params.Tuple.Architecture || (len(probed.ProviderVersion) >= 2 && len(run.params.Tuple.ProviderVersion) >= 2 && probed.ProviderVersion[:2] != run.params.Tuple.ProviderVersion[:2]) == false && probed.ProviderVersion != run.params.Tuple.ProviderVersion && probed.ProviderVersion[:2] == run.params.Tuple.ProviderVersion[:2] {',
   # Simpler prefix logic: only fail when prefix differs; 0.147 vs 0.148 share "0." so passes (admits drift)
   "mask":"TestSmokeProbeMismatchFails","survive":False},
  {"name":"own-m3-confidence-strong-for-codex","file":"internal/resumesmoke/smoke.go",
   "find":'if outcome.Confidence != "exact" {',
   "replace":'if outcome.Confidence != "exact" && !(outcome.Confidence == "strong" && run.params.Tuple.ProviderID == "codex") {',
   "mask":"TestSmokeStrongConfidenceFails","survive":False},
  {"name":"own-m4-digest-admits-gated","file":"internal/resumesmoke/record.go",
   "find":'if "sha256:"+hex.EncodeToString(sum[:]) != record.RecordID {',
   "replace":'if "sha256:"+hex.EncodeToString(sum[:]) != record.RecordID && record.Verdict != VerdictGated {',
   "mask":"TestSmokeTamperedRecordRefuses","survive":False},
  {"name":"own-c0-harmless-control","file":"internal/resumesmoke/smoke.go",
   "find":'// Check names in execution order.',
   "replace":'// Check names in execution order. Own-control: no behavior change.',
   "mask":"TestSmokeRowVerdicts/codex-0.147.0-macos-amd64","survive":True},
]
# fix m2 to simpler correct prefix logic
cases[1]["replace"] = 'if probed.ProviderID != run.params.Tuple.ProviderID || probed.Platform != run.params.Tuple.Platform || probed.Architecture != run.params.Tuple.Architecture || (len(probed.ProviderVersion) >= 2 && len(run.params.Tuple.ProviderVersion) >= 2 && probed.ProviderVersion[:2] != run.params.Tuple.ProviderVersion[:2]) {'
print("NOTE m2 admits drift when first 2 chars equal (0.147 vs 0.148 share '0.')")
for c in cases:
    work = subprocess.check_output(['mktemp','-d']).decode().strip()
    # copy go.mod go.sum internal
    for name in ['go.mod','go.sum']:
        shutil.copy(os.path.join(ROOT,name), os.path.join(work,name))
    shutil.copytree(os.path.join(ROOT,'internal'), os.path.join(work,'internal'))
    p = os.path.join(work, c["file"])
    data = open(p).read()
    n = data.count(c["find"])
    print(f"{c['name']}: find-count={n}")
    if n != 1:
        print(f"  SKIP: find occurs {n} times")
        continue
    open(p,'w').write(data.replace(c["find"], c["replace"]))
    env = dict(os.environ); env['PYTHONDONTWRITEBYTECODE']='1'
    proc = subprocess.run(['go','test','./internal/resumesmoke/','-run',c["mask"],'-count=1'], cwd=work, capture_output=True, text=True, env=env)
    failed = proc.returncode != 0
    has_fail = 'FAIL' in (proc.stdout + proc.stderr)
    print(f"  mask={c['mask']} rc={proc.returncode} failed={failed} hasFAIL={has_fail} survive_expected={c['survive']}")
    out = (proc.stdout + proc.stderr)[-1500:]
    print(out[-800:])
    ok = (c["survive"] and not failed) or ((not c["survive"]) and failed and has_fail)
    print(f"  => {'OK' if ok else 'UNEXPECTED'}")
    shutil.rmtree(work, ignore_errors=True)
