package config

import (
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/token"
	"go/types"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"testing"

	"golang.org/x/tools/go/packages"
)

// censusTypedViolations is the authoritative write-path gate. It resolves
// package, method, alias-import and function-value identity through go/types;
// spelling a package "os" or hiding a writer behind a closure does not evade
// the gate. The older syntax walker remains in writepath_census_test.go as a
// small reference implementation for historical evidence, but all tests use
// this symbol-aware implementation.
func censusTypedViolations(t *testing.T, dirs ...string) []string {
	t.Helper()
	var units []censusTypeUnit
	for _, dir := range dirs {
		unit, err := loadCensusTypeUnit(dir)
		if err != nil {
			t.Fatalf("load write-path census package %s: %v", dir, err)
		}
		units = append(units, unit)
	}
	gated := censusGatedFunctions(units)
	var violations []string
	for _, unit := range units {
		scanner := censusTypeScanner{unit: unit, gated: gated}
		violations = append(violations, scanner.scan()...)
	}
	sort.Strings(violations)
	return violations
}

type censusTypeUnit struct {
	dir   string
	fset  *token.FileSet
	files []*ast.File
	info  *types.Info
	pkg   *types.Package
}

func loadCensusTypeUnit(dir string) (censusTypeUnit, error) {
	root := censusModuleRoot()
	absolute, err := filepath.Abs(dir)
	if err != nil {
		return censusTypeUnit{}, err
	}
	if absolute == root || strings.HasPrefix(absolute, root+string(filepath.Separator)) {
		loaded, err := packages.Load(&packages.Config{
			Mode:  packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedTypesInfo | packages.NeedDeps,
			Dir:   absolute,
			Tests: false,
		}, ".")
		if err != nil {
			return censusTypeUnit{}, err
		}
		if len(loaded) != 1 {
			return censusTypeUnit{}, fmt.Errorf("expected one package, got %d", len(loaded))
		}
		pkg := loaded[0]
		if len(pkg.Errors) != 0 {
			return censusTypeUnit{}, fmt.Errorf("type-check errors: %v", pkg.Errors)
		}
		if pkg.Fset == nil || pkg.Types == nil || pkg.TypesInfo == nil {
			return censusTypeUnit{}, fmt.Errorf("incomplete go/packages type information")
		}
		return censusTypeUnit{dir: absolute, fset: pkg.Fset, files: pkg.Syntax, info: pkg.TypesInfo, pkg: pkg.Types}, nil
	}

	entries, err := filepath.Glob(filepath.Join(absolute, "*.go"))
	if err != nil {
		return censusTypeUnit{}, err
	}
	sort.Strings(entries)
	fset := token.NewFileSet()
	var files []*ast.File
	for _, path := range entries {
		if strings.HasSuffix(path, "_test.go") {
			continue
		}
		file, err := parser.ParseFile(fset, path, nil, parser.AllErrors)
		if err != nil {
			return censusTypeUnit{}, err
		}
		files = append(files, file)
	}
	if len(files) == 0 {
		return censusTypeUnit{}, fmt.Errorf("no production Go files")
	}
	info := &types.Info{
		Types:      map[ast.Expr]types.TypeAndValue{},
		Defs:       map[*ast.Ident]types.Object{},
		Uses:       map[*ast.Ident]types.Object{},
		Selections: map[*ast.SelectorExpr]*types.Selection{},
		Scopes:     map[ast.Node]*types.Scope{},
	}
	conf := types.Config{Importer: importer.Default()}
	pkg, err := conf.Check("censuscontrol", fset, files, info)
	if err != nil {
		return censusTypeUnit{}, err
	}
	return censusTypeUnit{dir: absolute, fset: fset, files: files, info: info, pkg: pkg}, nil
}

func censusModuleRoot() string {
	_, file, _, ok := runtimeCensusCaller()
	if !ok {
		return ""
	}
	return filepath.Clean(filepath.Join(filepath.Dir(file), "..", ".."))
}

// Kept as a tiny indirection so the production census code remains easy to
// execute in a test without importing runtime in the old syntax-only file.
var runtimeCensusCaller = func() (uintptr, string, int, bool) {
	return runtimeCaller(0)
}

func runtimeCaller(skip int) (uintptr, string, int, bool) {
	return runtime.Caller(skip + 1)
}

type censusFunction struct {
	name     string
	pkgPath  string
	receiver string
}

func censusGatedFunctions(units []censusTypeUnit) map[*types.Func]string {
	result := map[*types.Func]string{}
	for _, unit := range units {
		for _, file := range unit.files {
			for _, declaration := range file.Decls {
				function, ok := declaration.(*ast.FuncDecl)
				if !ok || function.Name == nil {
					continue
				}
				object, ok := unit.info.Defs[function.Name].(*types.Func)
				if !ok || !censusGatedName(object.Name()) {
					continue
				}
				result[object] = object.Name()
			}
		}
	}
	return result
}

func censusGatedName(name string) bool {
	if censusPairHelpers[name] || censusGatedIdents[name] {
		return true
	}
	if _, ok := censusTrustHelpers[name]; ok {
		return true
	}
	if _, ok := censusCustodyHelpers[name]; ok {
		return true
	}
	return false
}

type censusTypeScanner struct {
	unit   censusTypeUnit
	gated  map[*types.Func]string
	result []string
}

func (scanner *censusTypeScanner) scan() []string {
	for _, file := range scanner.unit.files {
		for _, declaration := range file.Decls {
			switch value := declaration.(type) {
			case *ast.FuncDecl:
				if value.Body == nil || scanner.isBackendMethod(value) {
					continue
				}
				function := censusObject(scanner.unit.info.Defs[value.Name])
				scanner.walk(value.Body, value.Name.Name, function)
			case *ast.GenDecl:
				for _, specification := range value.Specs {
					variables, ok := specification.(*ast.ValueSpec)
					if !ok {
						continue
					}
					for _, initializer := range variables.Values {
						name := "package initializer"
						if len(variables.Names) == len(variables.Values) {
							for index, variable := range variables.Values {
								if variable == initializer && index < len(variables.Names) {
									name = "var " + variables.Names[index].Name
								}
							}
						}
						scanner.walk(initializer, name, nil)
					}
				}
			}
		}
	}
	return scanner.result
}

func (scanner *censusTypeScanner) isBackendMethod(function *ast.FuncDecl) bool {
	object, ok := scanner.unit.info.Defs[function.Name].(*types.Func)
	if !ok {
		return false
	}
	return censusBackendDefinition(object)
}

func censusObject(object types.Object) *types.Func {
	function, _ := object.(*types.Func)
	return function
}

func censusFunctionOf(object *types.Func) censusFunction {
	if object == nil {
		return censusFunction{}
	}
	function := censusFunction{name: object.Name()}
	if object.Pkg() != nil {
		function.pkgPath = object.Pkg().Path()
	}
	if signature, ok := object.Type().(*types.Signature); ok && signature.Recv() != nil {
		function.receiver = censusNamedType(signature.Recv().Type())
	}
	return function
}

// censusAllowedDefinition matches the allowlist by the resolved definition
// identity, not by a bare spelling. The package path and receiver are part of
// the key; a same-named helper in another package or a newly added receiver
// method is scanned as a new write path. Synthetic plants use the empty
// censuscontrol package as a shape-only package, so they retain the original
// receiver-independent control semantics.
func censusAllowedDefinition(helper, current *types.Func, allowed map[string]bool) bool {
	if helper == nil || current == nil || helper.Pkg() == nil || current.Pkg() == nil {
		return false
	}
	if helper.Pkg().Path() != current.Pkg().Path() || !allowed[current.Name()] {
		return false
	}
	if current.Pkg().Path() == "censuscontrol" {
		return true
	}
	expected, hasExpected := censusExpectedReceivers[current.Name()]
	if !hasExpected {
		return current.Type().(*types.Signature).Recv() == nil
	}
	return censusNamedType(current.Type().(*types.Signature).Recv().Type()) == expected
}

var censusExpectedReceivers = map[string]string{
	"Initialize":   "Store",
	"JointCommit":  "Store",
	"Issue":        "Store",
	"Rotate":       "Store",
	"MarkRetiring": "Store",
	"Revoke":       "Store",
}

func censusNamedType(typ types.Type) string {
	switch value := typ.(type) {
	case *types.Pointer:
		return censusNamedType(value.Elem())
	case *types.Named:
		return value.Obj().Name()
	default:
		return ""
	}
}

func censusBackendDefinition(object *types.Func) bool {
	function := censusFunctionOf(object)
	if !censusBackendPackages[function.pkgPath] {
		return false
	}
	methods, ok := censusBackendMethods[function.receiver]
	return ok && methods[function.name]
}

var censusBackendPackages = map[string]bool{
	"github.com/relux-works/agent-session-manager/internal/config":    true,
	"github.com/relux-works/agent-session-manager/internal/hosttrust": true,
	"censuscontrol": true,
}

func (scanner *censusTypeScanner) walk(root ast.Node, functionName string, current *types.Func) {
	var stack []ast.Node
	ast.Inspect(root, func(node ast.Node) bool {
		if node == nil {
			if len(stack) != 0 {
				stack = stack[:len(stack)-1]
			}
			return false
		}
		stack = append(stack, node)
		scanner.visit(node, stack, functionName, current)
		return true
	})
}

func (scanner *censusTypeScanner) visit(node ast.Node, stack []ast.Node, functionName string, current *types.Func) {
	switch value := node.(type) {
	case *ast.CallExpr:
		scanner.visitCall(value, stack, functionName, current)
	case *ast.Ident:
		scanner.visitIdent(value, stack, functionName)
	case *ast.SelectorExpr:
		if !scanner.isCallCallee(value, stack) {
			scanner.visitSelectorValue(value, stack, functionName)
		}
	}
	_ = current // kept in the signature to make context explicit at call sites
}

func (scanner *censusTypeScanner) visitCall(call *ast.CallExpr, stack []ast.Node, functionName string, current *types.Func) {
	object, resolved := scanner.callObject(call)
	if !resolved {
		scanner.add(call, "unresolved call callee in "+functionName)
		return
	}
	function, ok := object.(*types.Func)
	if !ok {
		return
	}
	if helper, isGated := scanner.gated[function]; isGated {
		scanner.checkGatedCall(call, stack, functionName, helper, function, current)
		return
	}
	if censusIsOSMutation(function) {
		scanner.add(call, "direct os mutation outside the exact backend definition in "+functionName)
		return
	}
	if censusIsRawMutation(function) {
		allowed := censusRawMutations[function.Name()]
		if !censusAllowedDefinition(function, current, allowed) {
			scanner.add(call, "filesystem mutation method outside the censused writer in "+functionName)
		}
	}
}

func (scanner *censusTypeScanner) checkGatedCall(call *ast.CallExpr, stack []ast.Node, functionName, helper string, helperFunction, current *types.Func) {
	position := scanner.unit.fset.Position(call.Pos())
	if censusPairHelpers[helper] {
		if scanner.insideHoldClosure(stack) {
			return
		}
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s call is outside a resource-bound hold closure in %s", position.Filename, position.Line, helper, functionName))
		return
	}
	if allowed, ok := censusTrustHelpers[helper]; ok {
		if censusAllowedDefinition(helperFunction, current, allowed) {
			return
		}
	}
	if allowed, ok := censusCustodyHelpers[helper]; ok {
		if censusAllowedDefinition(helperFunction, current, allowed) {
			return
		}
	}
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s call is outside the censused writer in %s", position.Filename, position.Line, helper, functionName))
}

func (scanner *censusTypeScanner) visitIdent(identifier *ast.Ident, stack []ast.Node, functionName string) {
	object, ok := scanner.unit.info.Uses[identifier].(*types.Func)
	if !ok {
		return
	}
	helper, gated := scanner.gated[object]
	if !gated || scanner.isCallCallee(identifier, stack) || scanner.isSelectorName(identifier, stack) {
		return
	}
	position := scanner.unit.fset.Position(identifier.Pos())
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: gated helper %s escapes as a value in %s", position.Filename, position.Line, helper, functionName))
}

func (scanner *censusTypeScanner) visitSelectorValue(selector *ast.SelectorExpr, stack []ast.Node, functionName string) {
	object := scanner.selectorObject(selector)
	function, ok := object.(*types.Func)
	if !ok {
		return
	}
	if censusIsOSMutation(function) || (censusIsRawMutation(function) && function.Name() == "not-a-real-mutation") {
		position := scanner.unit.fset.Position(selector.Pos())
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: filesystem mutation function %s escapes as a value in %s", position.Filename, position.Line, function.Name(), functionName))
	}
}

func (scanner *censusTypeScanner) callObject(call *ast.CallExpr) (types.Object, bool) {
	object := scanner.expressionObject(call.Fun)
	if object != nil {
		return object, true
	}
	return nil, scanner.unit.info.TypeOf(call.Fun) != nil
}

func (scanner *censusTypeScanner) expressionObject(expression ast.Expr) types.Object {
	switch value := expression.(type) {
	case *ast.Ident:
		return scanner.unit.info.Uses[value]
	case *ast.SelectorExpr:
		return scanner.selectorObject(value)
	case *ast.ParenExpr:
		return scanner.expressionObject(value.X)
	case *ast.IndexExpr:
		return scanner.expressionObject(value.X)
	case *ast.IndexListExpr:
		return scanner.expressionObject(value.X)
	}
	return nil
}

func (scanner *censusTypeScanner) selectorObject(selector *ast.SelectorExpr) types.Object {
	if selection := scanner.unit.info.Selections[selector]; selection != nil {
		return selection.Obj()
	}
	return scanner.unit.info.Uses[selector.Sel]
}

func (scanner *censusTypeScanner) isCallCallee(node ast.Node, stack []ast.Node) bool {
	for index := len(stack) - 1; index > 0; index-- {
		call, ok := stack[index-1].(*ast.CallExpr)
		if ok && call.Fun == node {
			return true
		}
		if call, ok := stack[index-1].(*ast.CallExpr); ok {
			if containsNode(call.Fun, node) {
				return true
			}
		}
		if _, ok := stack[index-1].(*ast.FuncLit); ok {
			break
		}
	}
	return false
}

func (scanner *censusTypeScanner) isSelectorName(identifier *ast.Ident, stack []ast.Node) bool {
	for index := len(stack) - 1; index >= 0; index-- {
		selector, ok := stack[index].(*ast.SelectorExpr)
		if ok && selector.Sel == identifier {
			return true
		}
	}
	return false
}

func containsNode(root ast.Node, needle ast.Node) bool {
	found := false
	ast.Inspect(root, func(node ast.Node) bool {
		if node == needle {
			found = true
			return false
		}
		return !found
	})
	return found
}

func (scanner *censusTypeScanner) insideHoldClosure(stack []ast.Node) bool {
	for index := len(stack) - 1; index >= 0; index-- {
		literal, ok := stack[index].(*ast.FuncLit)
		if !ok {
			continue
		}
		if index == 0 {
			return false
		}
		call, ok := stack[index-1].(*ast.CallExpr)
		if !ok || !scanner.isHoldEntryCall(call) {
			return false
		}
		for _, argument := range call.Args {
			if argument == literal {
				return true
			}
		}
		return false
	}
	return false
}

func (scanner *censusTypeScanner) isHoldEntryCall(call *ast.CallExpr) bool {
	object, resolved := scanner.callObject(call)
	if !resolved {
		return false
	}
	function, ok := object.(*types.Func)
	if !ok {
		return false
	}
	switch function.Name() {
	case "JointCommit", "WithExclusiveHold", "WithExclusiveHoldForConfig":
		return true
	default:
		return false
	}
}

func (scanner *censusTypeScanner) add(node ast.Node, message string) {
	position := scanner.unit.fset.Position(node.Pos())
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s", position.Filename, position.Line, message))
}

func censusIsOSMutation(function *types.Func) bool {
	return function != nil && function.Pkg() != nil && function.Pkg().Path() == "os" && censusOSMutations[function.Name()]
}

func censusIsRawMutation(function *types.Func) bool {
	if function == nil || censusIsOSMutation(function) {
		return false
	}
	if _, ok := censusRawMutations[function.Name()]; ok {
		return function.Type() != nil && function.Type().(*types.Signature).Recv() != nil
	}
	return function.Name() == "CreateExclusive"
}
