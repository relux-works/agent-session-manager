package config
import (
 "os"
 "path/filepath"
 "testing"
 "time"
 "github.com/relux-works/agent-session-manager/internal/hosttrust"
)
func TestReviewerForeignHoldCannotWriteLockedPair(t *testing.T) {
 fixture:=setupV4Fixture(t,testPeerID)
 other,err:=hosttrust.Open(filepath.Join(t.TempDir(),"other-state"));if err!=nil{t.Fatal(err)}
 before,err:=os.ReadFile(fixture.filename);if err!=nil{t.Fatal(err)}
 replacement:=append(append([]byte{},before...),[]byte("\n# foreign lock write\n")...)
 entered,release:=make(chan struct{}),make(chan struct{})
 done:=make(chan error,1)
 go func(){done<-fixture.store.WithExclusiveHold(func(hosttrust.HeldExclusive)error{close(entered);<-release;return nil})}()
 select{case <-entered:case <-time.After(5*time.Second):t.Fatal("target hold not acquired")}
 defer func(){close(release);if e:=<-done;e!=nil{t.Error(e)}}()
 // This goroutine receives only the unrelated store. The target's holder
 // remains blocked in a separate goroutine and never lends its token.
 writeErr:=reviewerForeignWrite(other,fixture.filename,replacement)
 if writeErr==nil{
  after,e:=os.ReadFile(fixture.filename);if e!=nil{t.Fatal(e)}
  if string(after)!=string(replacement){t.Fatal("witness failed")}
  t.Fatal("foreign store token replaced target configuration while another goroutine exclusively held target store")
 }
}
