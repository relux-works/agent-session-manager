# TASK-260909-2ez769 rev8 handoff evidence

## Source and preservation

- Managed refresh command: `task-board worktree refresh-candidate TASK-260909-2ez769`.
- Refresh result: `refresh_advanced`; protected trunk and reviewed trunk were `8626fb361c1d6b62d5f95c7be4cb33c85d4aadf3`.
- Candidate Story head after replay: `305875134f8d344eb86ef926c7fbca3fed85c49d`.
- Merge base with `origin/main`: `8626fb361c1d6b62d5f95c7be4cb33c85d4aadf3`.
- RPC backup manifest/parked delta and checkpointed SSH/peer work were preserved. Pre/post refresh manifests and byte-hash comparison are under `.temp/TASK-260909-2ez769/{pre-refresh,post-refresh}/`; no RPC implementation path was absorbed.
- `task-board.config.json` is byte-equal to refreshed HEAD after the managed refresh; current catalogue/specpin/ownership configuration was not selectively vendored.

## CR7 repairs

### Resource-bound capability (F2)

`internal/hosttrust/hold.go` now binds a live capability to the exact trust-store root/lock identity and, for pair writes, the exact absolute configuration path. `requireHoldForRoot` protects hosttrust durable mutations; `ValidateConfigPath` protects Config4/legacy replacement and restore helpers; `JointCommit` binds the pending marker path before invoking replace/restore; legacy migration uses `WithExclusiveHoldForConfig`.

Production call sites and negative coverage:

- `hosttrust.Store.JointCommit` -> `config.replaceDurably` / `config.writeTempReplace` receives the marker-bound token.
- `hosttrust.Store.WithExclusiveHoldForConfig` -> `config.migrate` receives the explicit config-bound token.
- `TestWriteTempReplaceRefusesForeignStoreHold` holds the target Store lock while a different Store presents a genuine live token; the target bytes and staging directory remain unchanged.
- `TestHeldExclusiveRejectsUnboundConfigPath` rejects a live generic hold at the resource-binding gate.
- Existing zero/released tests remain green; `TestReplaceDurablyRefusesZeroHold` and `TestWriteTempReplaceRefusesZeroHold` attack the config writer boundary.

### Typed write-path census (F1)

`internal/config/writepath_census_types_test.go` loads production packages with `golang.org/x/tools/go/packages` and resolves `go/types` objects. It checks OS mutation identities (`Rename`, `Remove`, `RemoveAll`, `Create`, `CreateTemp`, `OpenFile`, `WriteFile`, `MkdirTemp`, `Link`, `Symlink`, `Truncate`), backend/interface methods, aliases, function/method values, map/struct fields, package initializers/IIFEs, closures, interface implementations, generic helpers, and unresolved callees (fail closed). Allowlisted definitions are matched by package path plus receiver/method identity.

`TestWritePathCensusGate`, `TestWritePathCensusFailsClosedOnUnresolvedCallee`, and `TestWritePathGateFlagsExecutableRogues` cover the direct controls, five CR7 evasion shapes, interface/generic additions, preserved-token source plants, and real-file behavioral witnesses.

## Validation

All commands below ran on the refreshed candidate and exited 0 unless stated otherwise:

- `go test ./... -count=1` — `.temp/TASK-260909-2ez769/go-test-all-01.log`.
- `go test ./... -cover` — `.temp/TASK-260909-2ez769/go-test-cover-01.log`; Config 93.5%, Host Trust Store 77.5%.
- `go vet ./...` — `.temp/TASK-260909-2ez769/go-vet-01.log`.
- `go build ./...` — `.temp/TASK-260909-2ez769/go-build-01.log`.
- `GOOS=windows go build ./...` — `.temp/TASK-260909-2ez769/go-build-windows-01.log`.
- `GOOS=windows go vet ./...` — `.temp/TASK-260909-2ez769/go-vet-windows-01.log`.
- `go test ./internal/config -run 'TestWritePath' -count=1` — `.temp/TASK-260909-2ez769/writepath-census-02.log`.
- `git diff --check` and `gofmt -l internal/config internal/hosttrust` — clean.

## Narrowing mutation evidence

- `hold-resource-skip`: killed, exit 1, named failing test `TestHeldExclusiveRejectsUnboundConfigPath`; raw results under `.temp/TASK-260909-2ez769/mutations-hold-resource-01/`.
- `replace-require-skip`: killed, exit 1, named failing tests `TestReplaceDurablyRefusesZeroHold` and `TestWriteTempReplaceRefusesZeroHold`; raw results under `.temp/TASK-260909-2ez769/mutations-config-hold-01/`.
- `writepath-method-value-skip`: token-preserving narrowing killed, exit 1, named failing test `TestWritePathGateFlagsExecutableRogues/backend_method_value`; raw results under `.temp/TASK-260909-2ez769/mutations-writepath-02/`.

## Coverage ratio and bounds

19 of 21 previously enumerated production acceptance rows are driven by named entry-point tests. Two rows remain explicit stated bounds: Windows runtime DACL execution is not available in this environment, and this repository has no export/replication consumer surface to drive. Prior crash-recovery, custody, migration, credential, peer-enrollment, and Config4 evidence remains attached from the earlier candidate rounds; this rev8 handoff does not invent guarantees for the two bounds.

Worktree is intentionally uncommitted for the managed Story handoff snapshot.
