package hosttrust

import (
 "errors"
 "os"
 "path/filepath"
 "testing"
)

func TestReviewerAdditionalResourceBindings(t *testing.T) {
 store:=setupStoreForTest(t)
 other:=setupStoreForTest(t)
 path:=filepath.Join(t.TempDir(),"config.toml")
 before,err:=os.ReadFile(filepath.Join(other.root,trustFileName));if err!=nil{t.Fatal(err)}
 reopened,err:=Open(filepath.Dir(store.root));if err!=nil{t.Fatal(err)}
 var released HeldExclusive
 err=store.WithExclusiveHoldForConfig(path,func(hold HeldExclusive)error{
  released=hold
  if err:=hold.ValidateConfigPath(path+".different");!errors.Is(err,ErrExclusiveHoldResourceMismatch){t.Fatalf("different config path: %v",err)}
  if reopened.root!=store.root{t.Fatalf("reopened wrong root: %s vs %s",reopened.root,store.root)}
  if err:=requireHoldForRoot(hold,reopened.root);err!=nil{t.Fatalf("same-root reopened handle refused: %v",err)}
  document,err:=EncodeTrust(TrustStore{Generation:99});if err!=nil{return err}
  if err:=commitDocument(hold,other.fs,other.root,filepath.Join(other.root,trustFileName),document);!errors.Is(err,ErrExclusiveHoldResourceMismatch){t.Fatalf("foreign trust root: %v",err)}
  return nil
 });if err!=nil{t.Fatal(err)}
 if err:=released.ValidateConfigPath(path);!errors.Is(err,ErrExclusiveHoldRequired){t.Fatalf("released scoped token: %v",err)}
 after,err:=os.ReadFile(filepath.Join(other.root,trustFileName));if err!=nil{t.Fatal(err)}
 if string(after)!=string(before){t.Fatal("foreign trust root mutated")}
}
