package config
import "github.com/relux-works/agent-session-manager/internal/hosttrust"
func reviewerForeignWrite(other *hosttrust.Store, filename string, replacement []byte) error {
 return other.WithExclusiveHoldForConfig(filename, func(hold hosttrust.HeldExclusive) error {
  _, err := writeTempReplace(hold, osMigrationFileSystem{}, filename, replacement)
  return err
 })
}
