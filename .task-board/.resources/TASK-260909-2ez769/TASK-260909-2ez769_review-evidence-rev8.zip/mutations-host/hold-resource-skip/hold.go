package hosttrust

import (
	"errors"
	"path/filepath"
	"sync/atomic"
)

// HeldExclusive is the unforgeable capability proving the holder acquired
// the exclusive authorization lock and that the hold is still live. Only
// the lock acquisition path (exclusiveHold) constructs a genuine value;
// every other package sees an opaque struct it can pass along but never
// forge: the zero value and any use-after-release refuse wherever a hold
// is required.
//
// A hold proves serialization, not protocol: helpers that mutate the
// config-plus-trust pair require a live hold (fail closed without one),
// while the write-path census gate statically restricts which call sites
// may perform pair mutations at all.
type HeldExclusive struct {
	hold       *exclusiveHold
	configPath string
}

// exclusiveHold is the liveness cell behind one HeldExclusive. The unlock
// wrapper marks it released, so a token stashed past its hold refuses
// instead of authorizing a write outside the exclusion window.
type exclusiveHold struct {
	released atomic.Bool
	root     string
}

// Valid reports a genuine live hold: constructed by the lock acquisition
// path and not yet released.
func (held HeldExclusive) Valid() bool {
	return held.hold != nil && !held.hold.released.Load()
}

// IsZero reports the zero value, which never authorizes a write. It lets
// narrowing tests distinguish a forged/absent token from a released one.
func (held HeldExclusive) IsZero() bool {
	return held.hold == nil
}

// requireHold refuses a pair mutation attempted without a live exclusive
// hold. It is the single enforcement point behind every token-gated
// helper; weakening it admits exactly the ungated writes the narrowing
// plants cover.
func requireHold(hold HeldExclusive) error {
	if !hold.Valid() {
		return trustError(TrustError{Operation: "require exclusive hold", Err: ErrExclusiveHoldRequired})
	}
	return nil
}

// requireHoldForRoot proves both liveness and the exact machine-local trust
// resource that the helper is about to mutate. A live capability from a
// different Store is not interchangeable, even when both stores happen to
// be held by the same goroutine.
func requireHoldForRoot(hold HeldExclusive, root string) error {
	if err := requireHold(hold); err != nil {
		return err
	}
	canonical, err := absoluteClean(root)
	if err != nil || hold.hold.root != canonical {
		return trustError(TrustError{Operation: "require exclusive hold resource", Err: ErrExclusiveHoldResourceMismatch})
	}
	return nil
}

// ValidateConfigPath proves that a live capability was explicitly bound to
// the exact configuration path it is about to replace. Generic
// WithExclusiveHold tokens intentionally carry no configuration binding, so
// a token from an unrelated store cannot authorize a pair write by accident.
func (held HeldExclusive) ValidateConfigPath(path string) error {
	if err := requireHold(held); err != nil {
		return err
	}
	canonical, err := absoluteClean(path)
	if err != nil || (held.configPath != "" && held.configPath != canonical) {
		return trustError(TrustError{Operation: "require configuration hold resource", Err: ErrExclusiveHoldResourceMismatch})
	}
	return nil
}

func absoluteClean(path string) (string, error) {
	if path == "" || !filepath.IsAbs(path) {
		return "", ErrInvalidStoreContext
	}
	return filepath.Clean(path), nil
}

func (held HeldExclusive) bindConfigPath(path string) (HeldExclusive, error) {
	if err := requireHold(held); err != nil {
		return HeldExclusive{}, err
	}
	canonical, err := absoluteClean(path)
	if err != nil {
		return HeldExclusive{}, trustError(TrustError{Operation: "bind configuration hold resource", Err: ErrExclusiveHoldResourceMismatch})
	}
	if held.configPath != "" && held.configPath != canonical {
		return HeldExclusive{}, trustError(TrustError{Operation: "bind configuration hold resource", Err: ErrExclusiveHoldResourceMismatch})
	}
	return HeldExclusive{hold: held.hold, configPath: canonical}, nil
}

// exclusiveHold acquires the exclusive authorization lock and returns the
// capability proving the hold plus its release function. The release marks
// the capability expired before unlocking, so no write can slip outside
// the exclusion window it was authorized under.
func (lock *fileLock) exclusiveHold() (HeldExclusive, func(), error) {
	unlock, err := lock.exclusive()
	if err != nil {
		return HeldExclusive{}, nil, err
	}
	state := &exclusiveHold{root: filepath.Clean(filepath.Dir(lock.path))}
	return HeldExclusive{hold: state}, func() {
		state.released.Store(true)
		unlock()
	}, nil
}

// WithExclusiveHold runs fn under the exclusive authorization lock with
// the capability proving the hold. Pending joint intent converges first,
// so fn never runs beside unresolved intent; fn receives the live hold to
// pass to token-gated pair writers. Legacy configuration migration uses
// this to serialize with joint commits; credential lifecycle and joint
// commits take their holds through their own entries.
func (store *Store) WithExclusiveHold(fn func(HeldExclusive) error) error {
	return store.withExclusiveHold("", fn)
}

// WithExclusiveHoldForConfig runs fn under an exclusive hold explicitly
// paired with one absolute configuration path. Only the returned scoped
// token can cross config pair writers; a generic hold deliberately has no
// config path and refuses there.
func (store *Store) WithExclusiveHoldForConfig(configPath string, fn func(HeldExclusive) error) error {
	return store.withExclusiveHold(configPath, fn)
}

func (store *Store) withExclusiveHold(configPath string, fn func(HeldExclusive) error) error {
	hold, unlock, err := store.lock.exclusiveHold()
	if err != nil {
		return trustError(TrustError{Operation: "lock exclusive hold", Err: errors.Join(ErrTrustDurability, err)})
	}
	defer unlock()
	if err := convergeLocked(hold, store.fs, store.root); err != nil {
		return err
	}
	if fn == nil {
		return trustError(TrustError{Operation: "run exclusive hold", Err: ErrAuthorizationRefused})
	}
	if configPath != "" {
		hold, err = hold.bindConfigPath(configPath)
		if err != nil {
			return err
		}
	}
	return fn(hold)
}
