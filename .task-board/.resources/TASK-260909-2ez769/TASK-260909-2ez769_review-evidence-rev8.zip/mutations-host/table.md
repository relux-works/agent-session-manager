| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| hold-resource-skip | Admits exactly an unbound live hold into a configuration resource | TestHeldExclusiveRejectsUnboundConfigPath | 1 | killed:  |
