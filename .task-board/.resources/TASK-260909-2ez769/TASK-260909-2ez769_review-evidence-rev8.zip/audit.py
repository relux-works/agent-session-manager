import json,hashlib,pathlib,subprocess
root=pathlib.Path('/Users/iv/Developer/ReluxWorks/agent-session-manager')
base=pathlib.Path(__file__).resolve().parent
review=base/'candidate'
backup=root/'.temp/TASK-260830-z1yxg9/preserved-before-credentials-260910'
m=json.loads((backup/'manifest.json').read_text())
for f in m['files']:
 assert hashlib.sha256((backup/'files'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 if f['untracked']:
  assert hashlib.sha256((root/'.temp/TASK-260909-2ez769/parked-rpc-delta-260910'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
print('RPC backup',len(m['files']),'parked',sum(f['untracked'] for f in m['files']),'hashes match')
delta=subprocess.check_output(['git','diff','--name-only','305875134f8d344eb86ef926c7fbca3fed85c49d','2c81ffcae1411ac73e5c3fbc3fe8b231916cd409'],text=True).splitlines()
print('RPC manifest overlap:',sorted(set(delta)&{f['path'] for f in m['files']}))
print('Candidate paths',len(delta),'SSH/peer paths:',[p for p in delta if 'sshtransport' in p or 'peeridentity' in p])

for path in delta:
 expected=subprocess.check_output(['git','show','2c81ffcae1411ac73e5c3fbc3fe8b231916cd409:'+path])
 assert (review/path).read_bytes()==expected,path
print('All 66 candidate delta paths match immutable tree')
for folder in ['internal/sshtransport','internal/peeridentity']:
 out=subprocess.check_output(['git','diff','a89328ca85a613abde39660f4be749a8fcf57903','305875134f8d344eb86ef926c7fbca3fed85c49d','--',folder])
 assert not out,folder
print('SSH and peer checkpoint directories unchanged after replay')
pin=json.loads((review/'internal/specpin/v0.6.0.lock.json').read_text())
assert hashlib.sha256((review/'internal/specdoc/SPEC.v0.6.0.md').read_bytes()).hexdigest()==pin['source']['document']['sha256']
print('Pinned source hash verified',pin['source']['commit'])
