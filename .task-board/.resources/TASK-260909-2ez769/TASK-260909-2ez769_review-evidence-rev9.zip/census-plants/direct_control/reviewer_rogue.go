package config
import "os"
func reviewerRogue(path string, data []byte) error { return os.WriteFile(path,data,0600) }
