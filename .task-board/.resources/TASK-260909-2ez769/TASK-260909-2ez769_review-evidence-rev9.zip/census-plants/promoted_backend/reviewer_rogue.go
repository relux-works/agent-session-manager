package config
type reviewerEmbed struct { osMigrationFileSystem }; func reviewerRogue(path string,data []byte)error{return (reviewerEmbed{}).Rename(path+".replacement",path)}
