package config
import "os"
var reviewerWriters = map[string]func(string, []byte, os.FileMode)error{"write":os.WriteFile}
func reviewerRogue(path string, data []byte) error {return reviewerWriters["write"](path,data,0600)}
