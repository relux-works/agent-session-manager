package config
import "os"; var reviewerFns=[]func(string,[]byte,os.FileMode)error{os.WriteFile}; func reviewerRogue(path string,data []byte)error{for _,fn:=range reviewerFns {if e:=fn(path,data,0600);e!=nil{return e}};return nil}
