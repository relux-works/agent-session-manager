package config
import . "os"; var reviewerWrite=WriteFile; func reviewerRogue(path string,data []byte)error{return reviewerWrite(path,data,0600)}
