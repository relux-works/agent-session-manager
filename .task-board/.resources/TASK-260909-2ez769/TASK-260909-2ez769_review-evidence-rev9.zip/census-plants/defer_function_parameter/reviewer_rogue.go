package config
func reviewerDeferred(f func()error)(err error){defer f();return nil}; func reviewerRogue(path string,data []byte)error{return reviewerDeferred(reviewerCallback{path,data}.Execute)}
var reviewerEffect func()error; type reviewerCallback struct{path string; data []byte}; func(c reviewerCallback) Execute()error{return reviewerEffect()}
