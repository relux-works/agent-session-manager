package config
var reviewerRename = osMigrationFileSystem{}.Rename
func reviewerRogue(path string,data []byte)error{return reviewerRename(path+".replacement",path)}
