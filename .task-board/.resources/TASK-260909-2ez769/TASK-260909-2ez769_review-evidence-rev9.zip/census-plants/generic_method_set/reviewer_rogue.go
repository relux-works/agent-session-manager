package config
type reviewerAction interface { Execute() error }; func reviewerInvoke[T reviewerAction](f T)error{return f.Execute()}; func reviewerRogue(path string,data []byte)error{return reviewerInvoke(reviewerCallback{path,data})}
var reviewerEffect func()error; type reviewerCallback struct{path string; data []byte}; func(c reviewerCallback) Execute()error{return reviewerEffect()}
