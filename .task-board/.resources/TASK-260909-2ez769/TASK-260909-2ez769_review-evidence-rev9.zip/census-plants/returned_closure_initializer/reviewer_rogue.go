package config
import "os"
var reviewerRogue = func() func(string,[]byte)error { return func(path string,data []byte)error {return os.WriteFile(path,data,0600)} }()
