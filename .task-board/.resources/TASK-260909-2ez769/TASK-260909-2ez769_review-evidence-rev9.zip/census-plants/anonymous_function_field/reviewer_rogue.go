package config
func reviewerRogue(path string,data []byte)error {return (struct{Run func()error}{Run:reviewerCallback{path,data}.Execute}).Run()}
var reviewerEffect func()error; type reviewerCallback struct{path string; data []byte}; func(c reviewerCallback) Execute()error{return reviewerEffect()}
