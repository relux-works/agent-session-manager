package config
import("testing";"os";"path/filepath")
func TestReviewerRoguePlantExecutes(t *testing.T){
 p:=filepath.Join(t.TempDir(),"config.toml")
if e:=os.WriteFile(p,[]byte("old"),0600);e!=nil{t.Fatal(e)}
if e:=os.WriteFile(p+".replacement",[]byte("new"),0600);e!=nil{t.Fatal(e)}
reviewerEffect=func()error{return os.WriteFile(p,[]byte("new"),0600)}; if e:=reviewerRogue(p,[]byte("new"));e!=nil{t.Fatal(e)}
b,e:=os.ReadFile(p);if e!=nil||string(b)!="new"{t.Fatalf("witness %s %v",b,e)}
t.Log("production-position rogue replaced real configuration bytes without a hold")
}
