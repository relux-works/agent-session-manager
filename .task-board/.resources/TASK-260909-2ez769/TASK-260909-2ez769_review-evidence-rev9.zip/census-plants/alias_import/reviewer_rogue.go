package config
import fs "os"
func reviewerRogue(path string,data []byte)error {return fs.WriteFile(path,data,0600)}
