package config
import("os";"path/filepath";"testing";"github.com/relux-works/agent-session-manager/internal/hosttrust")
func TestReviewerSymlinkConfigIdentity(t *testing.T){
 f:=setupV4Fixture(t); alias:=filepath.Join(t.TempDir(),"config-link.toml")
 if err:=os.Symlink(f.filename,alias);err!=nil{t.Fatal(err)}
 if err:=f.store.WithExclusiveHoldForConfig(alias,func(h hosttrust.HeldExclusive)error{return h.ValidateConfigPath(f.filename)});err!=nil{t.Fatal(err)}
}
