| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation pin | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| replace-require-skip | Admits exactly the zero token into the config pair writers | TestReplaceDurablyRefusesZeroHold | 1 | killed:  |
| writepath-method-value-skip | Preserves the raw-mutation symbol check while admitting method values such as backend Rename into package variables | TestWritePathGateFlagsExecutableRogues/backend_method_value | 1 | killed:  |
