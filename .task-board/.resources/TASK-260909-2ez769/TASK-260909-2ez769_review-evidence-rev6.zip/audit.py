import json,hashlib,pathlib,subprocess
root=pathlib.Path('/Users/iv/Developer/ReluxWorks/agent-session-manager')
base=pathlib.Path(__file__).resolve().parent
review=base/'candidate'
backup=root/'.temp/TASK-260830-z1yxg9/preserved-before-credentials-260910'
m=json.loads((backup/'manifest.json').read_text())
for f in m['files']:
 assert hashlib.sha256((backup/'files'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 if f['untracked']:
  assert hashlib.sha256((root/'.temp/TASK-260909-2ez769/parked-rpc-delta-260910'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
print('RPC backup',len(m['files']),'parked',sum(f['untracked'] for f in m['files']),'hashes match')
delta=subprocess.check_output(['git','diff','--name-only','a89328ca85a613abde39660f4be749a8fcf57903','b0bb3d9d600d4c323aa12480b3285512f96167c7'],text=True).splitlines()
assert not set(delta)&{f['path'] for f in m['files']}
print('Candidate paths',len(delta),'zero RPC overlap; SSH/peer paths:',[p for p in delta if 'sshtransport' in p or 'peeridentity' in p])
for name in ['hosttrust','config']:
 folder=base/'producer'/('mutations-'+name+'-rev6')
 manifest=json.loads((folder/'manifest.json').read_text())
 for s in manifest['sources']:
  assert hashlib.sha256((review/s['path']).read_bytes()).hexdigest()==s['sha256'],s['path']
 results=json.loads((folder/'results.json').read_text())
 print(name,'source hashes match',len(manifest['sources']),'files')
 for r in results:
  log=(folder/r['mutant']/'test.log').read_text()
  ev=[]
  for line in log.splitlines():
   try: ev.append(json.loads(line))
   except ValueError: pass
  fails=[e['Test'] for e in ev if e.get('Action')=='fail' and 'Test' in e]
  passes=[e['Test'] for e in ev if e.get('Action')=='pass' and 'Test' in e]
  assert 'build failed' not in log and 'no tests to run' not in log
  assert (r['exit_code']!=0 and fails) or (r['exit_code']==0 and passes)
  print(r['mutant'],r['exit_code'],r['result'],'failures',len(fails),'passes',len(passes))
patch=root/'.task-board/.resources/TASK-260909-2ez769/TASK-260909-2ez769_change-request_rev6.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='3d8057e3c4c2eb090eb70843440a68e3b1287218a109a551b7118ce6d7c7371f'
print('CR6 patch digest matches')
import runpy
for package,script in [('hosttrust','mutations.py'),('config','mutations_v4.py')]:
 module=runpy.run_path(str(review/'internal'/package/script),run_name='review_audit')
 folder=base/'producer'/('mutations-'+package+'-rev6')
 results={r['mutant']:r for r in json.loads((folder/'results.json').read_text())}
 for name,path,old,new,description,expected in module['PROBES']:
  source=(review/path).read_text()
  assert source.count(old)==1,(name,'unapplied or ambiguous')
  assert (folder/name/pathlib.Path(path).name).read_text()==source.replace(old,new,1),name
  if expected: assert expected in results[name]['named_failing_tests'],name
 print(package,'all plants applied once to exact candidate and expected failures recorded')
pin=json.loads((review/'internal/specpin/v0.6.0.lock.json').read_text())
assert hashlib.sha256((review/'internal/specdoc/SPEC.v0.6.0.md').read_bytes()).hexdigest()==pin['source']['document']['sha256']
print('Normative v0.6.0 local source digest verified',pin['source']['commit'])
