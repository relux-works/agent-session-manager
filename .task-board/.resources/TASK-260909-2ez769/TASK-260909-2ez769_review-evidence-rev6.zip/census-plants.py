from pathlib import Path
import subprocess,json
base=Path(__file__).resolve().parent
root=base/'candidate'
prod=root/'internal/config/reviewer_rogue.go'
test=root/'internal/config/reviewer_rogue_test.go'
plants={
 'direct-control': '''package config
func reviewerRogue(path string, data []byte) error { _, err := writeTempReplace(osMigrationFileSystem{}, path, data); return err }
''',
 'package-var-closure': '''package config
var reviewerRogue = func(path string, data []byte) error { _, err := writeTempReplace(osMigrationFileSystem{}, path, data); return err }
''',
 'local-helper-alias': '''package config
func reviewerRogue(path string, data []byte) error { writer := writeTempReplace; _, err := writer(osMigrationFileSystem{}, path, data); return err }
''',
 'method-os-rename': '''package config
import "os"
type reviewerRogueWriter struct{}
func (reviewerRogueWriter) replace(path string, data []byte) error { return os.Rename(path+".replacement", path) }
func reviewerRogue(path string, data []byte) error { return (reviewerRogueWriter{}).replace(path,data) }
''',
}
testsource='''package config
import("os";"path/filepath";"testing";"bytes")
func TestReviewerRoguePlantExecutes(t *testing.T) {
 path:=filepath.Join(t.TempDir(),"config.toml")
 source:=[]byte("old configuration")
 replacement:=[]byte("unlocked replacement")
 if err:=os.WriteFile(path,source,0600);err!=nil{t.Fatal(err)}
 if err:=os.WriteFile(path+".replacement",replacement,0600);err!=nil{t.Fatal(err)}
 if err:=reviewerRogue(path,replacement);err!=nil{t.Fatal(err)}
 got,err:=os.ReadFile(path);if err!=nil{t.Fatal(err)}
 if !bytes.Equal(got,replacement){t.Fatal("plant did not change configuration")}
 t.Log("real config file replaced by unlocked production caller")
}
'''
out=base/'census-plants';out.mkdir(exist_ok=True)
results=[]
try:
 for name,source in plants.items():
  folder=out/name;folder.mkdir(exist_ok=True)
  prod.write_text(source);test.write_text(testsource)
  (folder/prod.name).write_text(source);(folder/test.name).write_text(testsource)
  command=['go','test','./internal/config','-count=1','-run','^(TestWritePathCensusGate|TestReviewerRoguePlantExecutes)$','-v','-timeout=30s']
  p=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=60)
  (folder/'test.log').write_bytes(p.stdout)
  assert b'--- PASS: TestReviewerRoguePlantExecutes' in p.stdout
  results.append({'plant':name,'exit_code':p.returncode,'gate_detected':b'--- FAIL: TestWritePathCensusGate' in p.stdout})
finally:
 prod.unlink(missing_ok=True);test.unlink(missing_ok=True)
(out/'results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
