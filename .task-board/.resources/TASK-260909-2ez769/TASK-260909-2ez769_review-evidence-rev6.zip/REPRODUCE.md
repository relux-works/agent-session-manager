# Reproduce CR6 review

Extract immutable tree b0bb3d9d600d4c323aa12480b3285512f96167c7 with git archive into an isolated candidate directory.
Copy probes/config/*.go into candidate/internal/config and probes/hosttrust/*.go into candidate/internal/hosttrust.

- go test ./internal/config -count=1 -run '^TestReviewerLegacyCannotOverwriteCommittedV4$' -v -timeout 30s (FAIL)
- go test ./internal/config -count=1 -run '^TestReviewerFailed(Replacement|Rollback)CannotLoseIntent$' -v -timeout 30s (both FAIL)
- go test ./internal/config ./internal/hosttrust -count=1 -run '^TestReviewer(Crash|Cross|Stale|Revocation|Separate|Rollback)' -v -timeout 60s (seven PASS)
- go test ./internal/config -count=1 -run '^TestReviewerRestoreCannotOverwriteConvergedCommit$' -v -timeout 5s (timeout, exclusive-lock stack; not a passing test)
- go test ./internal/config -count=1 -run '^Test(Apply|Rollback)V4Compensation' -v -race -timeout 60s (six PASS)

Place census-plants.py beside candidate/ and run python3 census-plants.py. It installs/removes only its own two scratch files, and leaves candidate production bytes unchanged. Each plant runs the census and an actual disk-write witness. One control is caught, three bypasses pass.

Remove reviewer probe files from test discovery before running full package/mutation suites, because the two failing regression probes and the deliberate synchronous timeout are diagnostic additions, not candidate tests. Baseline.log was collected before adding any reviewer files.

Producer battery archives are not duplicated. Retrieve TASK-260909-2ez769_producer-evidence-rev6.tar.gz from the board and extract under producer/ beside candidate/ for audit.py. Its RPC preservation checks additionally use the task's existing control-root backup paths. See verdict for exact hashes and evidence reuse bounds.
