package config
var reviewerRogue = func(path string, data []byte) error { _, err := writeTempReplace(osMigrationFileSystem{}, path, data); return err }
