package config
func reviewerRogue(path string, data []byte) error { writer := writeTempReplace; _, err := writer(osMigrationFileSystem{}, path, data); return err }
