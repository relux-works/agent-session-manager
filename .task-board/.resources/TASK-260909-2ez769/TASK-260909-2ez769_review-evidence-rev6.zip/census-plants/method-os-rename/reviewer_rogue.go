package config
import "os"
type reviewerRogueWriter struct{}
func (reviewerRogueWriter) replace(path string, data []byte) error { return os.Rename(path+".replacement", path) }
func reviewerRogue(path string, data []byte) error { return (reviewerRogueWriter{}).replace(path,data) }
