package config
import("os";"path/filepath";"testing";"bytes")
func TestReviewerRoguePlantExecutes(t *testing.T) {
 path:=filepath.Join(t.TempDir(),"config.toml")
 source:=[]byte("old configuration")
 replacement:=[]byte("unlocked replacement")
 if err:=os.WriteFile(path,source,0600);err!=nil{t.Fatal(err)}
 if err:=os.WriteFile(path+".replacement",replacement,0600);err!=nil{t.Fatal(err)}
 if err:=reviewerRogue(path,replacement);err!=nil{t.Fatal(err)}
 got,err:=os.ReadFile(path);if err!=nil{t.Fatal(err)}
 if !bytes.Equal(got,replacement){t.Fatal("plant did not change configuration")}
 t.Log("real config file replaced by unlocked production caller")
}
