package config
func reviewerRogue(path string, data []byte) error { _, err := writeTempReplace(osMigrationFileSystem{}, path, data); return err }
