package config
type reviewerAction interface{Execute()error}; func reviewerInvoke(f reviewerAction)error{return (func()func()error{return f.Execute})()()}
