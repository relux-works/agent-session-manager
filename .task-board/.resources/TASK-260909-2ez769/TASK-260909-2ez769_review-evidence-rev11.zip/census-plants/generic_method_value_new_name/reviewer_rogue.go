package config
type reviewerAction interface{Perform()error}; func reviewerInvoke[T reviewerAction](f T)error{run:=f.Perform;return run()}
