package hosttrust
import("testing";"os";"path/filepath";"errors")
func TestReviewerSecondResolvedPairRefused(t *testing.T){
 target:=filepath.Join(t.TempDir(),"config.toml");if e:=os.WriteFile(target,[]byte("original"),0600);e!=nil{t.Fatal(e)}
 a:=resolvedPathsForTest(t,target,t.TempDir());b:=resolvedPathsForTest(t,target,t.TempDir())
 owner,e:=Open(a);if e!=nil{t.Fatal(e)};if e=owner.EnsureConfigBinding(a);e!=nil{t.Fatal(e)}
 foreign,e:=Open(b);if e!=nil{t.Fatal(e)}
 e=owner.WithExclusiveHold(func(HeldExclusive)error{return foreign.EnsureConfigBinding(b)})
 if !errors.Is(e,ErrExclusiveHoldResourceMismatch){t.Fatalf("foreign bind: %v",e)}
 t.Log("second resolver-issued pair cannot bind target while owner's lock is held")
}
