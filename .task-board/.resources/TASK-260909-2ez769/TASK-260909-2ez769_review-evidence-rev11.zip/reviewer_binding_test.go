package hosttrust
import("testing";"os";"path/filepath";"errors")
func TestReviewerRefusedRebindLeavesTargetUnclaimed(t *testing.T){
 state:=t.TempDir(); dir:=t.TempDir(); a:=filepath.Join(dir,"a.toml"); b:=filepath.Join(dir,"b.toml")
 for _,p:=range []string{a,b}{if e:=os.WriteFile(p,[]byte("original"),0600);e!=nil{t.Fatal(e)}}
 pa:=resolvedPathsForTest(t,a,state);pb:=resolvedPathsForTest(t,b,state)
 sa,e:=Open(pa);if e!=nil{t.Fatal(e)};sb,e:=Open(pb);if e!=nil{t.Fatal(e)}
 if e=sa.EnsureConfigBinding(pa);e!=nil{t.Fatal(e)}
 e=sb.EnsureConfigBinding(pb);if !errors.Is(e,ErrExclusiveHoldResourceMismatch){t.Fatalf("rebind: %v",e)}
 canonical,e:=canonicalExistingPath(b);if e!=nil{t.Fatal(e)}
 binding,present,e:=loadTargetConfigBinding(osFileSystem{},canonical)
 if e!=nil{t.Fatal(e)}
 proper:=resolvedPathsForTest(t,b,t.TempDir()); other,e:=Open(proper);if e!=nil{t.Fatal(e)}
 reclaimErr:=other.EnsureConfigBinding(proper);t.Logf("subsequent proper binding error: %v",reclaimErr)
 if present{t.Fatalf("refused rebind durably claimed second target: %+v",binding)}
}
