| # | Acceptance row | Production call / named test evidence | Result |
|---:|---|---|---|
| 1 | Closed Config4 | `config.Decode`; `TestDecodeConfiguration4Refusals` | pass |
| 2 | Historical compatibility + explicit migration | `config.Migrate`/legacy migration; `TestMigrateRefusesV4Target`, `TestMigrateRefusesV4Downgrade`, `TestLegacyMigrateCannotOverwriteCommittedV4`, `TestLegacyMigrateConvergesUnreplacedMarkerThenCommits`, `TestLegacyMigrateRefusesAfterReplacementLanded` | pass |
| 3 | Closed trust document | `hosttrust.DecodeTrust`; `TestDecodeTrustRefusals` | pass |
| 4 | Missing/corrupt/unreadable trust | `hosttrust.ReadSnapshot`; `TestReadSnapshotMissingStore`, `TestCorruptTrustRefusedNeverEmpty`, `TestReadSnapshotRefusesUnreadableMarker` | pass |
| 5 | Fresh issuance | `hosttrust.IssueCredential`; `TestIssueCredentialProfile`, `TestIssueSelfEnrollsActive` | pass |
| 6 | Exact profile + time bounds | `hosttrust.VerifyProfile`; `TestVerifyProfileRefusals`, `TestVerifyProfileRefusesJustPastExpiry`, wrong-key-usage/EKU/SAN tests | pass |
| 7 | Explicit tuple enrollment | `hosttrust.Store.Enroll`; `TestEnrollRefusals`, `TestEnrollBoundsPerHost`; OOB human verification remains an operator act | pass within stated OOB boundary |
| 8 | Mapping uniqueness | `hosttrust.DecodeTrust` + admission; duplicate credential/root/key/digest cases in `TestDecodeTrustRefusals`, `TestEnrollBoundsPerHost`, and lifecycle tests | pass |
| 9 | Rotation/retirement bounds | `hosttrust.Rotate`, `MarkRetiring`; `TestRotateBoundedWindow`, `TestRotateCapsAtLeafExpiry`, `TestMarkRetiringCapsAtLeafExpiry` | pass |
| 10 | Revocation tombstones | `hosttrust.Revoke`, `Enroll`; `TestRevokeTombstone`, `TestRevokedLeafNeverReenrolls`, `TestRevocationClosesAuthorization` | pass |
| 11 | Old-generation mutation refusal | `hosttrust.WithMutationAuthorization`; `TestWithMutationAuthorizationRefusesStaleGeneration`, `TestMutationAuthorizationRefusesStaleAfterConvergence` | pass |
| 12 | Shared authorization serialization | `hosttrust.Open`/lock, `WithMutationAuthorization`, `Revoke`; `TestFirstOpenPreservesHeldLock`, `TestConcurrentOpenAttachesToExistingLock`, `TestMutationAuthorizationSerializesWithRevocation`, `TestMutationAuthorizationSerializesWithSeparateStoreRevocation` | pass |
| 13 | Coherent config+trust snapshot | `config.LoadCoherent`; `TestSurvivingReaderConvergesInterruptedApply`, `TestSurvivingReaderConvergesInterruptedRollback`, `TestSurvivingReaderRefusesDivergedConfig`, barrier and revalidation tests | pass |
| 14 | Unix owner custody | `hosttrust.Open`, `ValidateCustody`; `TestCustodyRefusals`, `TestValidateCustodyBindsDirectory`, `TestOpenCreatesOwnerOnlyLayout` | pass on Darwin |
| 15 | Windows equivalent ACLs | `verifyOwner`, `installOwnerOnlyACL`, `secureStaged`; `custody_windows_test.go` seven native tests | stated bound: no Windows runtime runner; cross-build, test-compile, and vet pass |
| 16 | Complete peers + selected credential | `config.PreviewV4`; `TestPreviewV4PeerEnrollment`, `TestPreviewV4CredentialGates` | pass |
| 17 | Exact preview + confirmation | `config.ApplyV4`; `TestApplyV4PreviewMismatch`, `TestApplyV4ConfirmRequiredWithDrops` | pass |
| 18 | Current source/generation apply | Config4 apply + `hosttrust.JointCommit`; `TestApplyV4StaleSource`, `TestApplyV4StaleGeneration`, revalidation and stale-marker tests | pass |
| 19 | Crash-durable config/trust pair | Config4 apply/rollback + `hosttrust.JointCommit`, `Recover`, convergence; `TestApplyV4CrashConvergesGeneration`, surviving-reader/barrier/compensation tests | pass |
| 20 | Explicit backup rollback | `config.RollbackV4`; `TestRollbackV4*`, `TestPublishedBackupNamesStayExcluded`, `TestApplyV4BackupIsClassifiedConfigCopy` | pass |
| 21 | Secret exclusion across export surfaces | `hosttrust.MatchExcludedFromReplication`, `ExcludedConfigDirName`; matcher and persisted handoff/owner-note evidence | stated bound: repository matcher only; downstream consumers and diagnostics are unowned |
