from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parent;c=r/'candidate';p=c/'internal/config/migration.go';t=c/'internal/config/reviewer_callsite_test.go';old=p.read_text();needle='func replaceDurably(hold hosttrust.HeldExclusive, filesystem migrationFileSystem, paths localstore.ResolvedPaths, backup string, original, replacement []byte) error {\n'
plant='\tif backup == "reviewer-unlisted-site" { return filesystem.Rename(string(original), string(replacement)) }\n'
witness='''package config
import("testing";"os";"path/filepath";"github.com/relux-works/agent-session-manager/internal/hosttrust";"github.com/relux-works/agent-session-manager/internal/localstore")
func TestReviewerUnlistedSiteExecutes(t *testing.T){d:=t.TempDir();a:=filepath.Join(d,"a");b:=filepath.Join(d,"b");if e:=os.WriteFile(a,[]byte("new"),0600);e!=nil{t.Fatal(e)};if e:=replaceDurably(hosttrust.HeldExclusive{},osMigrationFileSystem{},localstore.ResolvedPaths{},"reviewer-unlisted-site",[]byte(a),[]byte(b));e!=nil{t.Fatal(e)};v,e:=os.ReadFile(b);if e!=nil||string(v)!="new"{t.Fatalf("witness %s %v",v,e)};t.Log("new unlisted interface call site renamed actual file before zero hold refusal")}
'''
try:
 p.write_text(old.replace(needle,needle+plant));t.write_text(witness);(r/'callsite-plant.txt').write_text(plant);(r/'reviewer_callsite_test.go').write_text(witness)
 proc=subprocess.run(['go','test','./internal/config','-count=1','-v','-run','^(TestWritePathCensusGate|TestReviewerUnlistedSiteExecutes)$'],cwd=c,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/'callsite.log').write_bytes(proc.stdout);(r/'callsite.exit').write_text(str(proc.returncode));print(proc.stdout.decode());print('exit',proc.returncode)
finally:p.write_text(old);t.unlink(missing_ok=True)
