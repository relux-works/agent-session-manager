| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation pin | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| writepath-interface-name-heuristic | Preserves the exact-object allowlist token while admitting every interface/type-parameter method named Execute | TestWritePathGateFlagsExecutableRogues/interface_method_spelling_cannot_evade_the_boundary | 1 | killed:  |
| config-association-root-skip | Preserves target presence and exact target-path checks while admitting a foreign store whose state-root association is different | TestWriteTempReplaceRefusesForeignStoreWithTargetBinding | 1 | killed:  |
