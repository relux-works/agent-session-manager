| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation pin | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| transport-ssh | Admits exactly the legacy ssh transport as v4 | TestDecodeConfiguration4Refusals/legacy_transport | 1 | killed:  |
| preview-length | Admits same-length tampered previews at the in-lock revalidation | TestRevalidateApplyV4PreviewMismatch | 1 | killed:  |
| confirm-drops | Admits exactly unconfirmed previews that drop peers | TestApplyV4ConfirmRequiredWithDrops | 1 | killed:  |
| apply-gen-direction | Admits newer generations into the in-lock apply revalidation | TestRevalidateApplyV4StaleGeneration | 1 | killed:  |
| v4-explicit-label | LABEL-PRECISION, not a semantic admission: mislabels the explicit-preview refusal; named test pins the exact error | TestMigrateRefusesV4Target | 1 | killed:  |
| compensate-source-swap | Restores the replacement instead of the source: admits exactly the no-op apply restore | TestApplyV4CompensatesBumpFailure | 1 | killed:  |
| compensate-rollback-source-swap | Restores the backup instead of the source: admits exactly the no-op rollback restore | TestRollbackV4CompensatesBumpFailure | 1 | killed:  |
| replace-require-skip | Admits exactly the zero token into the config pair writers | TestReplaceDurablyRefusesZeroHold | 1 | killed:  |
| legacy-revalidate-skip | Drops the byte comparison while keeping the version check: admits exactly same-version source changes | TestRevalidateLegacySourceRefusesChangedBytes | 1 | killed:  |
| replace-restore-skip | Cleans the restore staging instead of reinstalling it: admits exactly unrestored post-rename sync failures | TestMigrateRecoversOriginalAfterPostReplaceDirectorySyncFailureAndRetries | 1 | killed:  |
| writepath-method-value-skip | Preserves the raw-mutation symbol check while admitting method values such as backend Rename into package variables | TestWritePathGateFlagsExecutableRogues/backend_method_value | 1 | killed:  |
