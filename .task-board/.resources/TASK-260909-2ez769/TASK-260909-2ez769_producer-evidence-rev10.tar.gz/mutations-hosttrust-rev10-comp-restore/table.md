| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| compensate-restore-ignore | Ignores a failed restore and trusts the post-verify alone: admits exactly fail-after-write restores into the clean abort | TestJointCommitCompensationFailsAfterDurableRestore | 1 | killed:  |
