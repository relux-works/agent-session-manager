| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| compensate-verify-before-restore | PRESERVE-TOKEN order swap: verifies before restoring while keeping every call, so the static call-site gate still passes and only the behavioral suite can fail | TestJointCommitCompensatesBumpFailure | 1 | killed:  |
