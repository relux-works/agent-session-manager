| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| revoke-state | Weakens the terminal state to retiring, admitting re-revocation | TestRevokeTombstone | 1 | killed:  |
| retire-bound | Admits exactly the 24-48h overlap window | TestMarkRetiringBounds/past_24h_bound | 1 | killed:  |
| stale-direction | Admits stale-older snapshots while refusing newer | TestAuthorizeDispatchRefusals/stale_generation | 1 | killed:  |
| stale-mutation-refresh | Admits older mutation bindings while refusing newer | TestWithMutationAuthorizationRefusesStaleGeneration | 1 | killed:  |
| joint-marker-stale | Admits older pinned generations into the joint commit | TestJointCommitRefusesStaleMarkerGeneration | 1 | killed:  |
| recover-diverged | Completes forward under a diverged generation | TestRecoverRefusesDivergedGeneration | 1 | killed:  |
