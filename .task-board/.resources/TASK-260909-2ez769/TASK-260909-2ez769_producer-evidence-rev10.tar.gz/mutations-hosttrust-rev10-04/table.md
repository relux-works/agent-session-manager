| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| custody-binding | Admits exactly directories named by the root digest | TestValidateCustodyBindsDirectory | 1 | killed:  |
| dance-converge-ignore | Admits exactly the refused-recovery class into converged reads | TestReadSnapshotRefusesIntervention | 1 | killed:  |
| transact-converge-ignore | Admits exactly the refused-recovery class into transactions | TestTransactionRefusesIntervention | 1 | killed:  |
| initialize-converge-ignore | Admits exactly the refused-recovery class into setup | TestInitializeRefusesIntervention | 1 | killed:  |
| joint-converge-skip | Skips leftover convergence so the staged-marker refusal fires instead of the abort path; call-site presence paired with the recover-forward-no-bump narrowing mutant | TestJointCommitConvergesAbortedLeftoverThenCommits | 1 | killed:  |
| recover-forward-no-bump | Completes forward without the generation bump, admitting replaced configuration with the old generation | TestReadSnapshotConvergesInterruptedApply | 1 | killed:  |
