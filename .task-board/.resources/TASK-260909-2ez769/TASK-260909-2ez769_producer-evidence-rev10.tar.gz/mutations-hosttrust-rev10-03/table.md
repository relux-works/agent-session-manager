| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| custody-0644 | Admits exactly world-readable 0644 files | TestCustodyRefusals/world_readable_trust_file | 1 | killed:  |
| expiry-grace | Admits exactly one second past expiry | TestVerifyProfileRefusesJustPastExpiry | 1 | killed:  |
| exhaustion | Admits the ceiling generation into the commit path | TestGenerationExhaustionRefusesMutation | 1 | killed:  |
| digest-root-swap | Admits exactly stores naming the root digest as credential_id | TestDecodeTrustRefusals/credential_id_not_leaf_digest | 1 | killed:  |
| unique-root-pair | Admits exactly the minimal two-entry root duplicate | TestDecodeTrustRefusals/duplicate_root_across_entries | 1 | killed:  |
| retire-expiry | Admits retire_at up to one hour past old leaf expiry | TestMarkRetiringCapsAtLeafExpiry | 1 | killed:  |
