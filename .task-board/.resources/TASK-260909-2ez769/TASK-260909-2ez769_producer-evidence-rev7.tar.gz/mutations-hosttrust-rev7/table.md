| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| gen-ceiling | Admits exactly generation 2^53 | TestDecodeTrustRefusals/generation_uint53_ceiling | 1 | killed:  |
| dup-credid | Admits unsorted-but-distinct entries while keeping duplicate refusal; the mapping gate now subsumes the identical-entry case | TestDecodeTrustRefusals/unsorted_entries | 1 | killed:  |
| unknown-field | Admits exactly one unknown field | TestDecodeTrustRefusals/unknown_root_field | 1 | killed:  |
| per-host-bound | Admits exactly the third non-revoked credential | TestEnrollBoundsPerHost | 1 | killed:  |
| rotation-expiry | Extends overlap one hour past old leaf expiry | TestRotateCapsAtLeafExpiry | 1 | killed:  |
| revoke-state | Weakens the terminal state to retiring, admitting re-revocation | TestRevokeTombstone | 1 | killed:  |
| retire-bound | Admits exactly the 24-48h overlap window | TestMarkRetiringBounds/past_24h_bound | 1 | killed:  |
| stale-direction | Admits stale-older snapshots while refusing newer | TestAuthorizeDispatchRefusals/stale_generation | 1 | killed:  |
| stale-mutation-refresh | Admits older mutation bindings while refusing newer | TestWithMutationAuthorizationRefusesStaleGeneration | 1 | killed:  |
| joint-marker-stale | Admits older pinned generations into the joint commit | TestJointCommitRefusesStaleMarkerGeneration | 1 | killed:  |
| recover-diverged | Completes forward under a diverged generation | TestRecoverRefusesDivergedGeneration | 1 | killed:  |
| custody-0644 | Admits exactly world-readable 0644 files | TestCustodyRefusals/world_readable_trust_file | 1 | killed:  |
| expiry-grace | Admits exactly one second past expiry | TestVerifyProfileRefusesJustPastExpiry | 1 | killed:  |
| exhaustion | Admits the ceiling generation into the commit path | TestGenerationExhaustionRefusesMutation | 1 | killed:  |
| digest-root-swap | Admits exactly stores naming the root digest as credential_id | TestDecodeTrustRefusals/credential_id_not_leaf_digest | 1 | killed:  |
| unique-root-pair | Admits exactly the minimal two-entry root duplicate | TestDecodeTrustRefusals/duplicate_root_across_entries | 1 | killed:  |
| retire-expiry | Admits retire_at up to one hour past old leaf expiry | TestMarkRetiringCapsAtLeafExpiry | 1 | killed:  |
| custody-binding | Admits exactly directories named by the root digest | TestValidateCustodyBindsDirectory | 1 | killed:  |
| dance-converge-ignore | Admits exactly the refused-recovery class into converged reads | TestReadSnapshotRefusesIntervention | 1 | killed:  |
| transact-converge-ignore | Admits exactly the refused-recovery class into transactions | TestTransactionRefusesIntervention | 1 | killed:  |
| initialize-converge-ignore | Admits exactly the refused-recovery class into setup | TestInitializeRefusesIntervention | 1 | killed:  |
| joint-converge-skip | Skips leftover convergence so the staged-marker refusal fires instead of the abort path; call-site presence paired with the recover-forward-no-bump narrowing mutant | TestJointCommitConvergesAbortedLeftoverThenCommits | 1 | killed:  |
| recover-forward-no-bump | Completes forward without the generation bump, admitting replaced configuration with the old generation | TestReadSnapshotConvergesInterruptedApply | 1 | killed:  |
| authorize-converge-ignore | Admits exactly the refused-recovery class into the mutation boundary | TestMutationAuthorizationRefusesIntervention | 1 | killed:  |
| marker-unreadable | Treats an unreadable marker as absent | TestReadSnapshotRefusesUnreadableMarker | 1 | killed:  |
| lock-replacing-init | Publishes the lock with a replacing rename, admitting the concurrent first-open race | TestFirstOpenPreservesHeldLock | 1 | killed:  |
| compensate-marker-skip | Admits markers differing only in non-generation pins | TestJointCommitCompensationRefusesTamperedMarker | 1 | killed:  |
| compensate-restore-verify-skip | Admits exactly restores that leave the replacement in place | TestJointCommitCompensationVerifiesRestore/noop_restore | 1 | killed:  |
| compensate-restore-ignore | Ignores a failed restore and trusts the post-verify alone: admits exactly fail-after-write restores into the clean abort | TestJointCommitCompensationFailsAfterDurableRestore | 1 | killed:  |
| hold-require-skip | Admits exactly the zero token into every token-gated helper | TestCommitDocumentRefusesZeroHold | 1 | killed:  |
| hold-no-lock | Runs the hold boundary with a genuine token but no lock, admitting exactly unserialized writes | TestWithExclusiveHoldSerializesWithTransaction | 1 | killed:  |
| resolve-source-skip | Treats a durable replacement as intact after a replace failure, discarding the intent | TestResolveFailedReplaceKeepsMarker | 1 | killed:  |
| compensate-verify-before-restore | PRESERVE-TOKEN order swap: verifies before restoring while keeping every call, so the static call-site gate still passes and only the behavioral suite can fail | TestJointCommitCompensatesBumpFailure | 1 | killed:  |
