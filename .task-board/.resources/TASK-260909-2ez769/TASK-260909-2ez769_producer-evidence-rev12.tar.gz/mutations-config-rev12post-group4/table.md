| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| writepath-interface-callsite-skip | Preserves the allowlisted interface-method identity while admitting the same method at every call site and before hold verification | TestWritePathCensusRejectsUnlistedInterfaceCallSite | 1 | killed:  |
| config-association-root-skip | Preserves target presence and exact target-path checks while admitting a foreign store whose state-root association is different | TestWriteTempReplaceRefusesForeignStoreWithTargetBinding | 1 | killed:  |
