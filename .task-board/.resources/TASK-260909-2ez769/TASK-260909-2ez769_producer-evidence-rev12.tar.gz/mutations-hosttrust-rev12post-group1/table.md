| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| gen-ceiling | Admits exactly generation 2^53 | TestDecodeTrustRefusals/generation_uint53_ceiling | 1 | killed:  |
| dup-credid | Admits unsorted-but-distinct entries while keeping duplicate refusal; the mapping gate now subsumes the identical-entry case | TestDecodeTrustRefusals/unsorted_entries | 1 | killed:  |
| unknown-field | Admits exactly one unknown field | TestDecodeTrustRefusals/unknown_root_field | 1 | killed:  |
| per-host-bound | Admits exactly the third non-revoked credential | TestEnrollBoundsPerHost | 1 | killed:  |
| rotation-expiry | Extends overlap one hour past old leaf expiry | TestRotateCapsAtLeafExpiry | 1 | killed:  |
| revoke-state | Weakens the terminal state to retiring, admitting re-revocation | TestRevokeTombstone | 1 | killed:  |
| retire-bound | Admits exactly the 24-48h overlap window | TestMarkRetiringBounds/past_24h_bound | 1 | killed:  |
