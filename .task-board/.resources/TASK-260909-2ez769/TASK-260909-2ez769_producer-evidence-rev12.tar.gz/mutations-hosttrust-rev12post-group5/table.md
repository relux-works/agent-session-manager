| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| hold-require-skip | Admits exactly the zero token into every token-gated helper | TestCommitDocumentRefusesZeroHold | 1 | killed:  |
| hold-state-root-skip | Admits exactly a bound token used with a foreign StateRoot while preserving the configuration-path binding | TestHeldExclusiveRejectsForeignConfigStateRoot | 1 | killed:  |
| hold-no-lock | Runs the hold boundary with a genuine token but no lock, admitting exactly unserialized writes | TestWithExclusiveHoldSerializesWithTransaction | 1 | killed:  |
| resolve-source-skip | Treats a durable replacement as intact after a replace failure, discarding the intent | TestResolveFailedReplaceKeepsMarker | 1 | killed:  |
| compensate-verify-before-restore | PRESERVE-TOKEN order swap: verifies before restoring while keeping every call, so the static call-site gate still passes and only the behavioral suite can fail | TestJointCommitCompensatesBumpFailure | 1 | killed:  |
