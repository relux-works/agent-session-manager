| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| replace-require-skip | Admits exactly the zero token into the config pair writers | TestReplaceDurablyRefusesZeroHold | 1 | killed:  |
| legacy-revalidate-skip | Drops the byte comparison while keeping the version check: admits exactly same-version source changes | TestRevalidateLegacySourceRefusesChangedBytes | 1 | killed:  |
| replace-restore-skip | Cleans the restore staging instead of reinstalling it: admits exactly unrestored post-rename sync failures | TestMigrateRecoversOriginalAfterPostReplaceDirectorySyncFailureAndRetries | 1 | killed:  |
| writepath-method-value-skip | Preserves the raw-mutation symbol check while admitting method values such as backend Rename into package variables | TestWritePathGateFlagsExecutableRogues/backend_method_value | 1 | killed:  |
