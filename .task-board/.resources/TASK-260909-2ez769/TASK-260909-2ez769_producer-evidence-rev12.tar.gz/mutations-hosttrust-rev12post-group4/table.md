| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| authorize-converge-ignore | Admits exactly the refused-recovery class into the mutation boundary | TestMutationAuthorizationRefusesIntervention | 1 | killed:  |
| marker-unreadable | Treats an unreadable marker as absent | TestReadSnapshotRefusesUnreadableMarker | 1 | killed:  |
| lock-replacing-init | Publishes the lock with a replacing rename, admitting the concurrent first-open race | TestFirstOpenPreservesHeldLock | 1 | killed:  |
| compensate-marker-skip | Admits markers differing only in non-generation pins | TestJointCommitCompensationRefusesTamperedMarker | 1 | killed:  |
| compensate-restore-verify-skip | Admits exactly restores that leave the replacement in place | TestJointCommitCompensationVerifiesRestore/noop_restore | 1 | killed:  |
| compensate-restore-ignore | Ignores a failed restore and trusts the post-verify alone: admits exactly fail-after-write restores into the clean abort | TestJointCommitCompensationFailsAfterDurableRestore | 1 | killed:  |
