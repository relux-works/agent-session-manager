| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| apply-gen-direction | Admits newer generations into the in-lock apply revalidation | TestRevalidateApplyV4StaleGeneration | 1 | killed:  |
| v4-explicit-label | LABEL-PRECISION, not a semantic admission: mislabels the explicit-preview refusal; named test pins the exact error | TestMigrateRefusesV4Target | 1 | killed:  |
| compensate-source-swap | Restores the replacement instead of the source: admits exactly the no-op apply restore | TestApplyV4CompensatesBumpFailure | 1 | killed:  |
| compensate-rollback-source-swap | Restores the backup instead of the source: admits exactly the no-op rollback restore | TestRollbackV4CompensatesBumpFailure | 1 | killed:  |
