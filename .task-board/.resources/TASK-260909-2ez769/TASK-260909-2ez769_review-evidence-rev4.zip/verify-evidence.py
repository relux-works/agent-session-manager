import json,hashlib,pathlib,subprocess
root=pathlib.Path('/Users/iv/Developer/ReluxWorks/agent-session-manager')
review=pathlib.Path(__file__).resolve().parent/'candidate'
backup=root/'.temp/TASK-260830-z1yxg9/preserved-before-credentials-260910'
manifest=json.loads((backup/'manifest.json').read_text())
for f in manifest['files']:
 assert hashlib.sha256((backup/'files'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 if f['untracked']:
  assert hashlib.sha256((root/'.temp/TASK-260909-2ez769/parked-rpc-delta-260910'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
print('RPC backup 15/15 and parked untracked 11/11 hashes match')
delta=subprocess.check_output(['git','diff','--name-only','a89328ca85a613abde39660f4be749a8fcf57903','2c8909c9c7425bb3a90c00b8db3762f43b4dbf39'],text=True).splitlines()
assert not set(delta)&{f['path'] for f in manifest['files']}
print('49-path candidate has no RPC manifest path overlap')
for name in ['hosttrust','config']:
 folder=root/('.temp/TASK-260909-2ez769/mutations-'+name+'-rework')
 m=json.loads((folder/'manifest.json').read_text())
 for s in m['sources']:
  assert hashlib.sha256((review/s['path']).read_bytes()).hexdigest()==s['sha256'],s['path']
 results=json.loads((folder/'results.json').read_text())
 print(name,'source hashes match',len(m['sources']),'files; results',[(r['mutant'],r['exit_code'],r['result']) for r in results])
patch=root/'.task-board/.resources/TASK-260909-2ez769/TASK-260909-2ez769_change-request_rev4.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='73975946c2f994f11b3434e7923c689e1eefe9439e94d5d3d0a2cc53fa9bbf28'
print('CR patch digest matches assignment')
