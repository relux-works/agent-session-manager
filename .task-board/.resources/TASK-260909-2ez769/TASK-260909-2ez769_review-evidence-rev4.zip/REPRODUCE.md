# Reproduce reviewer probes

Extract the exact tree in a scratch directory under the repository .temp:

    git archive 2c8909c9c7425bb3a90c00b8db3762f43b4dbf39 | tar -x -C <scratch>

Copy probes/reviewer_probe_test.go and probes/reviewer_lock_test.go into
<scratch>/internal/hosttrust/; copy probes/reviewer_crash_test.go into
<scratch>/internal/config/. These are fixture-only tests, not production edits.
From scratch run:

    go test ./internal/hosttrust -count=1 -run '^TestReviewer(StaleMutation|RevocationDuringBoundary|SeparateStoreRevocationDuringBoundary)$' -v
    go test ./internal/hosttrust -count=1 -run '^TestReviewerCrossProcessLockInitialization$' -v
    go test ./internal/config -count=1 -run '^TestReviewer' -v

Observed exits: 0, 1, 1 respectively. The crash parent asserts child exit 77.
The lock test pauses the child's filesystem observation until the parent holds
the first-created lock, then demonstrates replacement of that inode.

Before mutation runs, remove only these added test files from discovery:

    python3 internal/hosttrust/mutations.py --output <output> --only neutral,stale-mutation-refresh,joint-marker-stale,recover-diverged

Observed harness exit 0; neutral exit 0, three named mutant tests exit 1.
Baseline without probes: go test ./internal/hosttrust ./internal/config
./internal/peeridentity -count=1 -cover (exit 0).

All executions used Go 1.25.5 darwin/arm64. This evidence tests process crashes,
not power loss, and is not native Windows validation.
