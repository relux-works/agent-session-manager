package hosttrust

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strconv"
)

// pendingCommitFileName is the durable intent marker for one joint
// config-plus-trust commit. It lives beside trust.json under the same
// owner-only custody and crash-durable write discipline.
const pendingCommitFileName = "pending-commit.json"

// Joint operations coupled to a trust generation bump.
const (
	JointApplyV4    = "apply-v4"
	JointRollbackV4 = "rollback-v4"
)

// PendingCommit is the durable intent record for one joint commit. The
// hashes pin the exact configuration bytes the operator confirmed; the
// source generation pins the trust state they were rendered against. Only
// the confirmed replacement may complete forward; anything else aborts or
// refuses on restart.
type PendingCommit struct {
	Schema            string `json:"schema"`
	SchemaVersion     string `json:"schema_version"`
	Operation         string `json:"operation"`
	ConfigPath        string `json:"config_path"`
	SourceSHA256      string `json:"source_sha256"`
	ReplacementSHA256 string `json:"replacement_sha256"`
	SourceGeneration  uint64 `json:"source_generation"`
	BackupPath        string `json:"backup_path"`
}

// SHA256HexOf returns the lowercase hex SHA-256 of document bytes for
// marker pins. It exposes no key material: markers pin configuration bytes
// only, never credentials.
func SHA256HexOf(document []byte) string {
	digest := sha256.Sum256(document)
	return hex.EncodeToString(digest[:])
}

func encodePendingCommit(marker PendingCommit) ([]byte, error) {
	if err := checkPendingCommit(marker); err != nil {
		return nil, err
	}
	document, err := json.Marshal(marker)
	if err != nil {
		return nil, trustError(TrustError{Operation: "encode joint commit", Err: errors.Join(ErrTrustDurability, err)})
	}
	return document, nil
}

func checkPendingCommit(marker PendingCommit) error {
	const operation = "validate joint commit"
	if marker.Schema != "urn:ax:schema:host-pending-commit" || marker.SchemaVersion != "1.0.0" {
		return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
	}
	if marker.Operation != JointApplyV4 && marker.Operation != JointRollbackV4 {
		return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
	}
	if !filepath.IsAbs(marker.ConfigPath) || marker.BackupPath == "" {
		return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
	}
	for _, digest := range []string{marker.SourceSHA256, marker.ReplacementSHA256} {
		raw, err := hex.DecodeString(digest)
		if err != nil || len(raw) != sha256.Size {
			return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
		}
	}
	if marker.SourceSHA256 == marker.ReplacementSHA256 {
		return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
	}
	if marker.SourceGeneration == 0 || marker.SourceGeneration > MaxGeneration {
		return trustError(TrustError{Operation: operation, Err: ErrTrustValidation})
	}
	return nil
}

func decodePendingCommit(document []byte) (PendingCommit, error) {
	var marker PendingCommit
	if err := rejectDuplicateKeys(document); err != nil {
		return PendingCommit{}, err
	}
	// The generation must be a bare JSON number, never a quoted string:
	// validate it through the same uint53 discipline as the trust document
	// before the struct decode, so a quoted number refuses as invalid
	// state rather than as a syntax error.
	raw := map[string]json.RawMessage{}
	decoder := json.NewDecoder(bytes.NewReader(document))
	decoder.UseNumber()
	if err := decoder.Decode(&raw); err != nil {
		return PendingCommit{}, trustError(TrustError{Operation: "decode joint commit", Err: errors.Join(ErrTrustDecode, err)})
	}
	generation, err := decodeMarkerGeneration(raw)
	if err != nil {
		return PendingCommit{}, err
	}
	decoder = json.NewDecoder(bytes.NewReader(document))
	decoder.DisallowUnknownFields()
	decoder.UseNumber()
	if err := decoder.Decode(&marker); err != nil {
		return PendingCommit{}, trustError(TrustError{Operation: "decode joint commit", Err: errors.Join(ErrTrustDecode, err)})
	}
	if decoder.More() {
		return PendingCommit{}, trustError(TrustError{Operation: "decode joint commit", Err: ErrTrustDecode})
	}
	marker.SourceGeneration = generation
	if err := checkPendingCommit(marker); err != nil {
		return PendingCommit{}, err
	}
	return marker, nil
}

func parseUint53(text string) (uint64, error) {
	if text == "" {
		return 0, errors.New("empty generation number")
	}
	for _, digit := range text {
		if digit < '0' || digit > '9' {
			return 0, errors.New("non-digit generation number")
		}
	}
	parsed, err := strconv.ParseUint(text, 10, 64)
	if err != nil {
		return 0, err
	}
	if parsed == 0 || parsed > MaxGeneration {
		return 0, errors.New("generation outside uint53")
	}
	return parsed, nil
}

func decodeMarkerGeneration(shape map[string]json.RawMessage) (uint64, error) {
	raw, ok := shape["source_generation"]
	if !ok {
		return 0, trustError(TrustError{Operation: "decode joint generation", Err: ErrTrustValidation})
	}
	var value any
	if err := strictJSONDecoder(raw).Decode(&value); err != nil {
		return 0, trustError(TrustError{Operation: "decode joint generation", Err: errors.Join(ErrTrustDecode, err)})
	}
	number, ok := value.(json.Number)
	if !ok {
		return 0, trustError(TrustError{Operation: "decode joint generation", Err: ErrTrustValidation})
	}
	parsed, err := parseUint53(number.String())
	if err != nil {
		return 0, trustError(TrustError{Operation: "decode joint generation", Err: ErrTrustValidation})
	}
	return parsed, nil
}

// JointCommit runs one crash-atomic authorization-generation commit coupled
// to an external durable replacement (Configuration 4.0.0 apply or
// rollback). Under a single exclusive hold it revalidates the confirmed
// pins against committed trust, stages the durable intent marker, runs
// replace (the configuration file replacement), bumps the generation, and
// removes the marker.
//
//   - revalidate runs first, inside the lock: the preview, source and
//     generation checks it repeats there close the concurrent-change window
//     between the unlocked fast-fail checks and the commit.
//   - A replace failure aborts with no generation change; the marker is
//     removed because the configuration is untouched.
//   - A trust-commit failure after replace keeps the marker: the caller
//     must restore the source bytes, then call Recover, which observes the
//     source hash and aborts cleanly. If the restore itself fails the
//     marker stays for operator resolution and the joint error reports it.
//   - Marker-removal failure after a durable bump still returns success:
//     the joint state is already forward-complete, and the next Open
//     converges by removing the marker.
//
// Only process crashes are covered by the restart protocol below; power
// loss additionally depends on the disk honoring fsync, which no test here
// can establish. Crash tests terminate a real child process at the
// replacement seam and re-open the store in the parent.
func (store *Store) JointCommit(marker PendingCommit, revalidate func(current TrustStore) error, replace func() error) (uint64, error) {
	const operation = "joint commit"
	if revalidate == nil || replace == nil {
		return 0, trustError(TrustError{Operation: operation, Err: ErrTrustDurability})
	}
	unlock, err := store.lock.exclusive()
	if err != nil {
		return 0, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustDurability, err)})
	}
	defer unlock()
	committed, err := loadCommitted(store.fs, store.root)
	if err != nil {
		return 0, err
	}
	if err := revalidate(committed); err != nil {
		return 0, err
	}
	if marker.SourceGeneration > committed.Generation {
		return 0, trustError(TrustError{Operation: operation, Err: ErrStaleGeneration})
	}
	if err := checkPendingCommit(marker); err != nil {
		return 0, err
	}
	if _, err := store.fs.Lstat(pendingPath(store.root)); err == nil {
		return 0, trustError(TrustError{Operation: operation, Err: ErrJointIntervened})
	} else if !os.IsNotExist(err) {
		return 0, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	encoded, err := encodePendingCommit(marker)
	if err != nil {
		return 0, err
	}
	if err := commitDocument(store.fs, store.root, pendingPath(store.root), encoded); err != nil {
		return 0, err
	}
	if err := replace(); err != nil {
		_ = removeMarkerLocked(store.fs, store.root)
		return 0, err
	}
	var generation uint64
	if err := transactLocked(store.fs, store.root, func(trust *TrustStore) error {
		generation = trust.Generation + 1
		return nil
	}); err != nil {
		return 0, trustError(TrustError{Operation: "commit joint generation", Err: errors.Join(ErrJointReplacementDurable, err)})
	}
	// The replacement and the bump are both durable: converge the marker
	// removal on next open when this cleanup itself is interrupted.
	_ = removeMarkerLocked(store.fs, store.root)
	return generation, nil
}

// RecoverResult reports what one recovery pass found.
type RecoverResult struct {
	// Found reports a marker was present at all.
	Found bool
	// Completed reports the replacement had committed and the generation
	// converged forward to source plus one (or already had).
	Completed bool
	// Aborted reports the replacement had not committed: the marker was
	// removed with no generation change.
	Aborted bool
}

// Recover converges one interrupted joint commit found on disk. It runs
// automatically on Open and after a caller-restored source, and is safe to
// call directly:
//
//   - configuration equal to the replacement hash completes forward: a
//     trust at the source generation bumps to source plus one; a trust
//     already there only removes the marker.
//   - configuration equal to the source hash aborts: the marker is removed
//     with no generation change.
//   - anything else (operator edit mid-flight, unreadable state) refuses
//     and keeps the marker for operator resolution.
//
// A refused recovery fails Open, so a restart can never silently admit new
// configuration with an old generation.
func (store *Store) Recover() (RecoverResult, error) {
	unlock, err := store.lock.exclusive()
	if err != nil {
		return RecoverResult{}, trustError(TrustError{Operation: "recover joint commit", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	defer unlock()
	return recoverLocked(store.fs, store.root)
}

func recoverLocked(filesystem FileSystem, root string) (RecoverResult, error) {
	const operation = "recover joint commit"
	path := pendingPath(root)
	if _, err := filesystem.Lstat(path); err != nil {
		if os.IsNotExist(err) {
			return RecoverResult{}, nil
		}
		return RecoverResult{}, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	info, err := filesystem.Lstat(path)
	if err != nil {
		return RecoverResult{}, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	if err := verifyOwnerFile(path, info, 0o600); err != nil {
		return RecoverResult{}, err
	}
	document, err := filesystem.ReadFile(path)
	if err != nil {
		return RecoverResult{}, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	marker, err := decodePendingCommit(document)
	if err != nil {
		return RecoverResult{Found: true}, err
	}
	configuration, err := filesystem.ReadFile(marker.ConfigPath)
	if err != nil {
		return RecoverResult{Found: true}, trustError(TrustError{Operation: operation, Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	switch SHA256HexOf(configuration) {
	case marker.ReplacementSHA256:
		committed, err := loadCommitted(filesystem, root)
		if err != nil {
			return RecoverResult{Found: true}, err
		}
		switch committed.Generation {
		case marker.SourceGeneration:
			if err := transactLocked(filesystem, root, func(*TrustStore) error { return nil }); err != nil {
				return RecoverResult{Found: true}, err
			}
		case marker.SourceGeneration + 1:
		default:
			return RecoverResult{Found: true}, trustError(TrustError{Operation: operation, Err: ErrJointIntervened})
		}
		if err := removeMarkerLocked(filesystem, root); err != nil {
			return RecoverResult{Found: true}, err
		}
		return RecoverResult{Found: true, Completed: true}, nil
	case marker.SourceSHA256:
		if err := removeMarkerLocked(filesystem, root); err != nil {
			return RecoverResult{Found: true}, err
		}
		return RecoverResult{Found: true, Aborted: true}, nil
	default:
		return RecoverResult{Found: true}, trustError(TrustError{Operation: operation, Err: ErrJointIntervened})
	}
}

func pendingPath(root string) string { return filepath.Join(root, pendingCommitFileName) }

func removeMarkerLocked(filesystem FileSystem, root string) error {
	if err := filesystem.Remove(pendingPath(root)); err != nil && !os.IsNotExist(err) {
		return trustError(TrustError{Operation: "remove joint marker", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := syncDir(filesystem, root); err != nil {
		return trustError(TrustError{Operation: "sync joint marker directory", Err: errors.Join(ErrTrustDurability, err)})
	}
	return nil
}
