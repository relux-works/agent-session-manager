| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| stale-mutation-refresh | Admits older mutation bindings while refusing newer | TestWithMutationAuthorizationRefusesStaleGeneration | 1 | killed:  |
| joint-marker-stale | Admits older pinned generations into the joint commit | TestJointCommitRefusesStaleMarkerGeneration | 1 | killed:  |
| recover-diverged | Completes forward under a diverged generation | TestRecoverRefusesDivergedGeneration | 1 | killed:  |
