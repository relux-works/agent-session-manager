| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| hold-resource-skip | Admits exactly an unconfigured live store hold into a caller-selected configuration resource while preserving liveness and configured-store path checks | TestWithExclusiveHoldForConfigRefusesUnconfiguredStorePath | 1 | killed:  |
