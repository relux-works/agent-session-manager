| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| writepath-method-value-skip | Preserves the raw-mutation symbol check while admitting method values such as backend Rename into package variables | TestWritePathGateFlagsExecutableRogues/backend_method_value | 1 | killed:  |
