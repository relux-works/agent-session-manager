# TASK-260909-2ez769 rev9 producer handoff evidence

Status: ready for review. The candidate is intentionally uncommitted for the managed Story handoff.

## Candidate identity and preservation

- Worktree: `.temp/STORY-260830-1kiyj6/worktree`
- Recorded candidate checkpoint/HEAD: `305875134f8d344eb86ef926c7fbca3fed85c49d`
- Protected AX trunk used by the candidate: `8626fb361c1d6b62d5f95c7be4cb33c85d4aadf3`
- The 15-file RPC backup manifest and parked 11-file RPC delta remain preserved; no RPC implementation path was absorbed.
- Checkpointed SSH/peer work remains in the candidate and was validated by the full package suite. No commit, branch switch, rebase, merge, or main integration was performed.

## Implemented scope

- Exact closed Config 4.0.0 and Host Trust Store 1.0.0 readers refuse absent, partial, corrupt, unreadable, ambiguous, downgraded, and implicitly legacy state.
- Host credential issuance, explicit out-of-band tuple enrollment, unique credential-to-host mapping, bounded fresh-key rotation, revocation tombstones, current-generation authorization, and immediate mutation refusal are exposed through production APIs.
- Owner custody and atomic crash-durable trust/config pair writes use the hosttrust custody and joint-commit path. Apply, rollback, recovery, and marker convergence are revalidated under the owned exclusive hold.
- Config4 preview is exact and confirmation-bound; apply enrolls the complete peer set and selected local credential, while historical Config1/2/3 migration remains explicit and preserved.
- Config/Host Trust Store write-path census resolves typed function identities and rejects writer-shaped indirect calls that are not bound to a censused hold entry.

## Acceptance coverage ratio

19 of 21 enumerated production acceptance rows are driven by named production-entry tests:

| Rows | Production call site and evidence | Result |
| --- | --- | --- |
| 1–4 | `config.Decode`, `config.Migrate`, `hosttrust.DecodeTrust`, `hosttrust.ReadSnapshot`; closed-reader, compatibility, missing/corrupt/unreadable tests | pass |
| 5–10 | `hosttrust.IssueCredential`, `VerifyProfile`, `Store.Enroll`, `Rotate`, `MarkRetiring`, `Revoke`; issuance, profile, tuple, uniqueness, rotation, tombstone tests | pass |
| 11–12 | `hosttrust.WithMutationAuthorization`, `Open/openLock`, `Revoke`; stale-generation and cross-store serialization tests | pass |
| 13–14 | `config.LoadCoherent`, `hosttrust.Open/ValidateCustody`; surviving-reader/crash/compensation tests and Darwin owner-custody tests | pass |
| 16–20 | `config.PreviewV4`, `ApplyV4`, `RollbackV4`, `hosttrust.JointCommit/Recover`; peer enrollment, exact preview, revalidation, crash, rollback, and backup exclusion tests | pass |
| 15 | Windows `verifyOwner/installOwnerOnlyACL/secureStaged` runtime execution | stated bound: no Windows runner; cross-build and source/unit evidence only |
| 21 | `hosttrust.MatchExcludedFromReplication/ExcludedConfigDirName` | stated bound: no export/replication consumer surface exists in this repository |

The two bounds are not presented as passing evidence.

## Narrowing-negative evidence

- `hold-resource-skip` removes the unconfigured-store refusal while retaining other resource/path checks. It is killed with exit 1 by `TestWithExclusiveHoldForConfigRefusesUnconfiguredStorePath`.
- `writepath-method-value-skip` preserves the searched token but weakens the typed method-value gate. It is killed with exit 1 by `TestWritePathGateFlagsExecutableRogues/backend_method_value` and the enclosing behavioral suite.
- The typed census has executable witnesses for dot-imported function values, promoted embedded backend methods, package-level slice writers, function-typed struct fields, function-typed parameters, and dot-imported composite-literal function values, plus the earlier alias/map/closure/interface/generic and direct controls.
- A generic or foreign Store cannot bind an arbitrary existing Config path: refusal happens before staging or bytes mutation. A configured Store can bind only its canonical paired path.

## Validation evidence

All logs are under `.temp/TASK-260909-2ez769/`.

- Full `go test -count=1 -v`, grouped over the exact 26-package inventory in `go-packages-rev9.txt`: groups A/B/C/D all exit 0.
- Full `go test -count=1 -cover`, grouped over the same exact package inventory: groups A/B/C/D all exit 0. Key package coverage: `internal/config 93.5%`, `internal/hosttrust 77.9%`, `internal/peeridentity 97.5%`.
- Production-focused `go test ./internal/hosttrust ./internal/config ...` with migration, crash, custody, hold, Config4, and census tests: exit 0 (`go-test-targeted-rev9.log`).
- Scoped package coverage: hosttrust, config, and peeridentity exit 0; logs are `go-test-hosttrust-rev9.log`, `go-test-config-rev9.log`, and `go-test-peeridentity-rev9.log`.
- `go vet ./internal/config ./internal/hosttrust ./internal/peeridentity`, native build, Linux arm64 build, Windows amd64 build, Windows config/hosttrust test compilation, and `go mod tidy -diff`: all exit 0.
- `gofmt -l` on changed Go packages, `git diff --check`, and the debug-file guard pass.

## Handoff state

The implementation and evidence are ready for the independent reviewer. The Story worktree remains uncommitted so the task-board handoff can snapshot it against the recorded checkpoint.
