package hosttrust

import (
	"errors"
	"os"
	"path/filepath"
)

// Snapshot is one coherent committed read: trust bytes plus the generation
// that authorized them. Streams and dispatches bind this generation; any use
// must re-check currency before crossing a side-effect boundary.
type Snapshot struct {
	Generation uint64
	Trust      TrustStore
}

// TransactionFunc mutates a copy of the committed trust. Returning nil
// commits with generation+1; returning an error aborts with no durable effect.
type TransactionFunc func(trust *TrustStore) error

// ReadSnapshot obtains one coherent committed snapshot under a shared lock.
// A missing store is ErrTrustStoreMissing, never an empty store. Unreadable,
// malformed or partially read state refuses; leftover staging files from
// crashed commits are ignored and never selected.
func (store *Store) ReadSnapshot() (Snapshot, error) {
	return readSnapshot(store.fs, store.root, store.lock)
}

func readSnapshot(filesystem FileSystem, root string, lock *fileLock) (Snapshot, error) {
	unlock, err := lock.shared()
	if err != nil {
		return Snapshot{}, trustError(TrustError{Operation: "lock snapshot", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	defer unlock()
	path := filepath.Join(root, trustFileName)
	info, err := filesystem.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return Snapshot{}, trustError(TrustError{Operation: "read snapshot", Err: ErrTrustStoreMissing})
		}
		return Snapshot{}, trustError(TrustError{Operation: "read snapshot", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	if err := verifyOwnerFile(path, info, 0o600); err != nil {
		return Snapshot{}, err
	}
	document, err := filesystem.ReadFile(path)
	if err != nil {
		return Snapshot{}, trustError(TrustError{Operation: "read snapshot", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	store, err := DecodeTrust(document)
	if err != nil {
		return Snapshot{}, err
	}
	return Snapshot{Generation: store.Generation, Trust: store}, nil
}

// Initialize creates the explicit empty generation-1 store. It refuses when
// trust.json already exists: setup never overwrites committed authority.
func (store *Store) Initialize() (Snapshot, error) {
	unlock, err := store.lock.exclusive()
	if err != nil {
		return Snapshot{}, trustError(TrustError{Operation: "lock initialize", Err: errors.Join(ErrTrustDurability, err)})
	}
	defer unlock()
	path := filepath.Join(store.root, trustFileName)
	if _, err := store.fs.Lstat(path); err == nil {
		return Snapshot{}, trustError(TrustError{Operation: "initialize store", Err: ErrTrustDurability})
	} else if !os.IsNotExist(err) {
		return Snapshot{}, trustError(TrustError{Operation: "initialize store", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	document, err := EncodeTrust(TrustStore{Generation: 1})
	if err != nil {
		return Snapshot{}, err
	}
	if err := commitDocument(store.fs, store.root, path, document); err != nil {
		return Snapshot{}, err
	}
	return store.ReadSnapshot()
}

// CommitConfigChange shares the machine-local cross-process authorization
// lock and crash-durable generation transaction with Configuration 4.0.0
// peer/credential changes. It holds the exclusive lock while fn performs the
// durable config replacement, then commits a generation bump for the config
// authorization change. A fn failure aborts with no generation change; the
// caller owns config-side recovery when the later trust commit fails.
func (store *Store) CommitConfigChange(fn func() error) (uint64, error) {
	var generation uint64
	err := store.transact(func(trust *TrustStore) error {
		if err := fn(); err != nil {
			return err
		}
		generation = trust.Generation + 1
		return nil
	})
	if err != nil {
		return 0, err
	}
	return generation, nil
}

// transact runs one crash-durable generation transaction under the exclusive
// cross-process lock: load committed state, apply fn, encode, stage with
// fsync, atomic rename, directory fsync. A missing store refuses with
// ErrTrustStoreMissing: only explicit Initialize commits generation 1. Any
// other malformed state refuses before fn runs.
func (store *Store) transact(fn TransactionFunc) error {
	return transact(store.fs, store.root, store.lock, fn)
}

func transact(filesystem FileSystem, root string, lock *fileLock, fn TransactionFunc) error {
	unlock, err := lock.exclusive()
	if err != nil {
		return trustError(TrustError{Operation: "lock transaction", Err: errors.Join(ErrTrustDurability, err)})
	}
	defer unlock()
	path := filepath.Join(root, trustFileName)
	var committed TrustStore
	info, err := filesystem.Lstat(path)
	if err != nil {
		if os.IsNotExist(err) {
			return trustError(TrustError{Operation: "read committed trust", Err: ErrTrustStoreMissing})
		}
		return trustError(TrustError{Operation: "read committed trust", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	if err := verifyOwnerFile(path, info, 0o600); err != nil {
		return err
	}
	document, err := filesystem.ReadFile(path)
	if err != nil {
		return trustError(TrustError{Operation: "read committed trust", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	var decoded TrustStore
	decoded, err = DecodeTrust(document)
	if err != nil {
		return err
	}
	committed = decoded
	next := committed
	next.Entries = append([]CredentialEntry(nil), committed.Entries...)
	if err := fn(&next); err != nil {
		return err
	}
	if next.Generation != committed.Generation {
		return trustError(TrustError{Operation: "commit generation", Err: ErrTrustDurability})
	}
	if committed.Generation >= MaxGeneration {
		return trustError(TrustError{Operation: "commit generation", Err: ErrGenerationExhausted})
	}
	next.Generation = committed.Generation + 1 + 0
	encoded, err := EncodeTrust(next)
	if err != nil {
		return err
	}
	document = encoded
	if err := commitDocument(filesystem, root, path, document); err != nil {
		return err
	}
	return nil
}

// commitDocument stages bytes in a temp file with fsync, atomically renames
// over the target, and fsyncs the directory. On restart only the last fully
// committed file is selected; staged files are ignored by every reader.
func commitDocument(filesystem FileSystem, root, path string, document []byte) error {
	staged, err := filesystem.CreateTemp(root, stagePrefix+"*", 0o600)
	if err != nil {
		return trustError(TrustError{Operation: "stage trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	name := staged.Name()
	failed := true
	defer func() {
		if failed {
			_ = filesystem.Remove(name)
		}
	}()
	if err := writeAll(staged, document); err != nil {
		return trustError(TrustError{Operation: "stage trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := staged.Sync(); err != nil {
		_ = staged.Close()
		return trustError(TrustError{Operation: "sync trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := staged.Close(); err != nil {
		return trustError(TrustError{Operation: "sync trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := filesystem.Chmod(name, 0o600); err != nil {
		return trustError(TrustError{Operation: "stage trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := filesystem.Rename(name, path); err != nil {
		return trustError(TrustError{Operation: "replace trust", Err: errors.Join(ErrTrustDurability, err)})
	}
	if err := syncDir(filesystem, root); err != nil {
		return trustError(TrustError{Operation: "sync trust directory", Err: errors.Join(ErrTrustDurability, err)})
	}
	failed = false
	return nil
}

func writeAll(writer interface{ Write([]byte) (int, error) }, document []byte) error {
	for len(document) > 0 {
		written, err := writer.Write(document)
		if err != nil {
			return err
		}
		if written == 0 {
			return errors.New("short trust write")
		}
		document = document[written:]
	}
	return nil
}

func syncDir(filesystem FileSystem, root string) error {
	handle, err := filesystem.OpenDirectory(root)
	if err != nil {
		return err
	}
	if err := handle.Sync(); err != nil {
		_ = handle.Close()
		return err
	}
	return handle.Close()
}
