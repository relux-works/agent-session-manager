| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| stale-direction | Admits stale-older snapshots while refusing newer | TestAuthorizeDispatchRefusals/stale_generation | 1 | killed:  |
| custody-0644 | Admits exactly world-readable 0644 files | TestCustodyRefusals/world_readable_trust_file | 1 | killed:  |
