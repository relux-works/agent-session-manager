package hosttrust

import (
	"errors"
	"io"
	"io/fs"
	"os"
	"path/filepath"
)

const (
	hostChannelDir  = "host-channel"
	trustFileName   = "trust.json"
	lockFileName    = "lock"
	credentialsDir  = "credentials"
	certificateFile = "certificate.pem"
	privateKeyFile  = "private-key.pem"
	rootFile        = "root.pem"
	stagePrefix     = ".trust-stage-"
)

// FileSystem abstracts durable writes so crash and fault paths are testable
// without touching the operator disk. The OS implementation is the only
// production backend.
type FileSystem interface {
	CreateTemp(dir, pattern string, mode fs.FileMode) (StagedFile, error)
	ReadFile(name string) ([]byte, error)
	Lstat(name string) (fs.FileInfo, error)
	Stat(name string) (fs.FileInfo, error)
	Remove(name string) error
	Rename(oldname, newname string) error
	MkdirAll(path string, mode fs.FileMode) error
	Chmod(name string, mode fs.FileMode) error
	OpenDirectory(name string) (SyncedDirectory, error)
	ReadDir(name string) ([]fs.DirEntry, error)
}

// StagedFile is one temp staging file awaiting fsync and atomic rename.
type StagedFile interface {
	io.Writer
	Name() string
	Chmod(fs.FileMode) error
	Sync() error
	Close() error
}

// SyncedDirectory fsyncs a directory entry after renames.
type SyncedDirectory interface {
	Sync() error
	Close() error
}

type osFileSystem struct{}

func (osFileSystem) CreateTemp(dir, pattern string, mode fs.FileMode) (StagedFile, error) {
	file, err := os.CreateTemp(dir, pattern)
	if err != nil {
		return nil, err
	}
	if err := file.Chmod(mode); err != nil {
		_ = file.Close()
		_ = os.Remove(file.Name())
		return nil, err
	}
	return file, nil
}

func (osFileSystem) ReadFile(name string) ([]byte, error)   { return os.ReadFile(name) }
func (osFileSystem) Lstat(name string) (fs.FileInfo, error) { return os.Lstat(name) }
func (osFileSystem) Stat(name string) (fs.FileInfo, error)  { return os.Stat(name) }
func (osFileSystem) Remove(name string) error               { return os.Remove(name) }
func (osFileSystem) Rename(oldname, newname string) error   { return os.Rename(oldname, newname) }

func (osFileSystem) MkdirAll(path string, mode fs.FileMode) error { return os.MkdirAll(path, mode) }
func (osFileSystem) Chmod(name string, mode fs.FileMode) error    { return os.Chmod(name, mode) }

func (osFileSystem) OpenDirectory(name string) (SyncedDirectory, error) { return os.Open(name) }
func (osFileSystem) ReadDir(name string) ([]fs.DirEntry, error)         { return os.ReadDir(name) }

// Store is machine-local Host Channel authority rooted at
// STATE_DIR/host-channel. The zero value is unusable; construct with Open.
type Store struct {
	root string
	fs   FileSystem
	lock *fileLock
}

// Open validates owner-only custody of STATE_DIR/host-channel, creating the
// directory skeleton with exact 0700/0600 modes when absent. Every open
// re-verifies custody: symlink escapes, foreign ownership and group/world
// access refuse with ErrTrustUnsafeCustody.
func Open(stateDir string) (*Store, error) { return openStore(stateDir, osFileSystem{}) }

func openStore(stateDir string, filesystem FileSystem) (*Store, error) {
	if filesystem == nil {
		return nil, trustError(TrustError{Operation: "open store", Err: ErrInvalidStoreContext})
	}
	if !filepath.IsAbs(stateDir) {
		return nil, trustError(TrustError{Operation: "open store", Err: ErrInvalidStoreContext})
	}
	root := filepath.Join(stateDir, hostChannelDir)
	if err := ensureOwnerDir(filesystem, root, 0o700); err != nil {
		return nil, err
	}
	if err := ensureOwnerDir(filesystem, filepath.Join(root, credentialsDir), 0o700); err != nil {
		return nil, err
	}
	lock, err := openLock(filesystem, filepath.Join(root, lockFileName))
	if err != nil {
		return nil, err
	}
	return &Store{root: root, fs: filesystem, lock: lock}, nil
}

// Root reports the validated host-channel directory. It carries no secrets.
func (store *Store) Root() string { return store.root }

// TrustPath reports the trust.json path for operator diagnostics. Reading or
// writing it directly bypasses the authorization lock; use transactions.
func (store *Store) TrustPath() string { return filepath.Join(store.root, trustFileName) }

// CredentialDir reports the custody directory for one credential ID hex. It
// carries no key material.
func (store *Store) CredentialDir(credentialHex string) (string, error) {
	if len(credentialHex) != 64 {
		return "", trustError(TrustError{Operation: "resolve credential directory", Err: ErrCredentialCustody})
	}
	for _, unit := range credentialHex {
		if (unit < '0' || unit > '9') && (unit < 'a' || unit > 'f') {
			return "", trustError(TrustError{Operation: "resolve credential directory", Err: ErrCredentialCustody})
		}
	}
	return filepath.Join(store.root, credentialsDir, credentialHex), nil
}

func ensureOwnerDir(filesystem FileSystem, path string, mode fs.FileMode) error {
	info, err := filesystem.Lstat(path)
	if err != nil && !os.IsNotExist(err) {
		return trustError(TrustError{Operation: "inspect directory", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	if err == nil {
		// An existing directory is verified, never repaired: silently
		// narrowing a widened directory would mask the custody violation.
		return verifyOwnerDir(path, info, mode)
	}
	if err := filesystem.MkdirAll(path, mode); err != nil {
		return trustError(TrustError{Operation: "create directory", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	// MkdirAll honors umask, so the exact owner-only mode is enforced
	// explicitly after creation.
	if err := filesystem.Chmod(path, mode); err != nil {
		return trustError(TrustError{Operation: "create directory", Err: errors.Join(ErrTrustUnsafeCustody, err)})
	}
	info, err = filesystem.Lstat(path)
	if err != nil {
		return trustError(TrustError{Operation: "inspect directory", Err: errors.Join(ErrTrustStoreUnreadable, err)})
	}
	return verifyOwnerDir(path, info, mode)
}

func verifyOwnerDir(path string, info fs.FileInfo, mode fs.FileMode) error {
	if !info.IsDir() {
		return trustError(TrustError{Operation: "inspect directory", Err: ErrTrustUnsafeCustody})
	}
	if info.Mode()&fs.ModeSymlink != 0 {
		return trustError(TrustError{Operation: "inspect directory", Err: ErrTrustUnsafeCustody})
	}
	if info.Mode().Perm() != mode {
		return trustError(TrustError{Operation: "inspect directory", Err: ErrTrustUnsafeCustody})
	}
	return verifyOwner(path, info)
}

func verifyOwnerFile(path string, info fs.FileInfo, mode fs.FileMode) error {
	if !info.Mode().IsRegular() {
		return trustError(TrustError{Operation: "inspect file", Err: ErrTrustUnsafeCustody})
	}
	if info.Mode()&fs.ModeSymlink != 0 {
		return trustError(TrustError{Operation: "inspect file", Err: ErrTrustUnsafeCustody})
	}
	if info.Mode().Perm() != mode && info.Mode().Perm() != 0o644 {
		return trustError(TrustError{Operation: "inspect file", Err: ErrTrustUnsafeCustody})
	}
	return verifyOwner(path, info)
}
