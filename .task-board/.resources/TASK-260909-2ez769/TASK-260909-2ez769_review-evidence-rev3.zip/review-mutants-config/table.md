| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation pin | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| preview-length | Admits same-length tampered previews | TestApplyV4PreviewMismatch | 1 | killed:  |
| confirm-drops | Admits exactly unconfirmed previews that drop peers | TestApplyV4ConfirmRequiredWithDrops | 1 | killed:  |
