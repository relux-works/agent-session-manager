package config

import (
	"bytes"
	"errors"
	"time"

	"github.com/relux-works/agent-session-manager/internal/hosttrust"
	"github.com/relux-works/agent-session-manager/internal/scalar"
)

// ApplyV4OS captures real process inputs and performs one explicit durable
// Configuration 4.0.0 migration. The caller supplies the exact confirmed
// preview from PreviewV4; confirm must be true.
func ApplyV4OS(platform scalar.Platform, overrides Overrides, preview V4Preview, confirm bool, now time.Time) (V4ApplyResult, error) {
	inputs, err := OSInputs(platform)
	if err != nil {
		return V4ApplyResult{}, err
	}
	return applyV4(inputs, overrides, preview, confirm, now, osMigrationFileSystem{}, hosttrust.Open)
}

// ApplyV4 is the dependency-injected production entry point. It writes only
// the selected configuration file, a deterministic source-version backup in
// the same directory, and one trust generation bump under the shared
// authorization lock.
func ApplyV4(inputs Inputs, overrides Overrides, preview V4Preview, confirm bool, now time.Time) (V4ApplyResult, error) {
	return applyV4(inputs, overrides, preview, confirm, now, osMigrationFileSystem{}, hosttrust.Open)
}

func applyV4(inputs Inputs, overrides Overrides, preview V4Preview, confirm bool, now time.Time,
	filesystem migrationFileSystem, openStore func(string) (*hosttrust.Store, error)) (V4ApplyResult, error) {
	if !confirm && len(preview.DroppedPeers) == 0 {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "confirm preview", Err: ErrMigrationV4ConfirmRequired})
	}
	if preview.SourceVersion != CurrentVersion || len(preview.SourceDocument) == 0 || len(preview.Replacement) == 0 {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate preview", Err: ErrMigrationV4PreviewMismatch})
	}
	snapshot, err := Load(inputs, overrides)
	if err != nil {
		return V4ApplyResult{}, err
	}
	loaded, decoded := snapshot.Configuration()
	if !snapshot.ConfigPresent() || !decoded {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "load source", Err: ErrMigrationSourceAbsent})
	}
	if loaded.SourceVersion != CurrentVersion {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "select source", Err: ErrMigrationV4Source})
	}
	if !bytes.Equal(snapshot.Document(), preview.SourceDocument) {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate preview source", Err: ErrMigrationV4StaleSource})
	}
	selected, _ := snapshot.Paths().Path(ConfigFile)
	filename := selected.Value.String()
	stateDir := stateDirOf(snapshot)
	store, err := openStore(stateDir)
	if err != nil {
		return V4ApplyResult{}, err
	}
	current, err := store.ReadSnapshot()
	if err != nil {
		return V4ApplyResult{}, err
	}
	if current.Generation != preview.SourceGeneration {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate preview generation", Err: ErrMigrationV4StaleGeneration})
	}
	rendered, err := renderV4Preview(snapshot.Document(), loaded.Value, current, preview.CredentialID, preview.DroppedPeers, now, inputs)
	if err != nil {
		return V4ApplyResult{}, err
	}
	if !bytes.Equal(rendered.Replacement, preview.Replacement) {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate preview bytes", Err: ErrMigrationV4PreviewMismatch})
	}
	// The custody files behind the selected credential must validate before
	// use, exactly as Section 11.10.2 requires for local identity.
	credentialHex := previewCredentialHex(preview.CredentialID)
	if err := store.ValidateCustody(credentialHex, loaded.Value.HostID, now); err != nil {
		return V4ApplyResult{}, err
	}
	backup := filename + ".bak." + loaded.SourceVersion
	replaced := false
	generation, err := store.CommitConfigChange(func() error {
		if err := replaceDurably(filesystem, filename, backup, snapshot.Document(), preview.Replacement); err != nil {
			return err
		}
		replaced = true
		return nil
	})
	if err != nil {
		if replaced {
			recovery, rollbackErr := writeTempReplace(filesystem, filename, snapshot.Document())
			if rollbackErr != nil {
				return V4ApplyResult{}, migrationError(MigrationError{Operation: "recover source after trust commit", Err: errors.Join(ErrMigrationSync, ErrMigrationRecovery, err, rollbackErr)})
			}
			_ = recovery
		}
		return V4ApplyResult{}, err
	}
	return V4ApplyResult{
		Migration:  MigrationResult{SourceVersion: loaded.SourceVersion, TargetVersion: Version4, BackupPath: backup, Changed: true},
		Generation: generation,
	}, nil
}

// RollbackV4OS captures real process inputs and performs one explicit
// operator rollback: stopping every host channel is the operator's act, and
// this call replaces configuration from the preserved backup and bumps the
// trust generation so stale-generation streams cannot survive.
func RollbackV4OS(platform scalar.Platform, overrides Overrides, options RollbackV4Options) (V4ApplyResult, error) {
	inputs, err := OSInputs(platform)
	if err != nil {
		return V4ApplyResult{}, err
	}
	return rollbackV4(inputs, overrides, options, osMigrationFileSystem{}, hosttrust.Open)
}

// RollbackV4 is the dependency-injected production entry point.
func RollbackV4(inputs Inputs, overrides Overrides, options RollbackV4Options) (V4ApplyResult, error) {
	return rollbackV4(inputs, overrides, options, osMigrationFileSystem{}, hosttrust.Open)
}

func rollbackV4(inputs Inputs, overrides Overrides, options RollbackV4Options,
	filesystem migrationFileSystem, openStore func(string) (*hosttrust.Store, error)) (V4ApplyResult, error) {
	if !options.AcknowledgeNoHostChannelAssurance {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "acknowledge rollback", Err: ErrRollbackV4AckRequired})
	}
	snapshot, err := Load(inputs, overrides)
	if err != nil {
		return V4ApplyResult{}, err
	}
	loaded, decoded := snapshot.Configuration()
	if !snapshot.ConfigPresent() || !decoded {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "load source", Err: ErrMigrationSourceAbsent})
	}
	selected, _ := snapshot.Paths().Path(ConfigFile)
	filename := selected.Value.String()
	backup := options.BackupPath
	if backup == "" {
		backup = filename + ".bak." + CurrentVersion
	}
	backupBytes, err := filesystem.ReadFile(backup)
	if err != nil {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "read backup", Err: errors.Join(ErrRollbackV4Backup, err)})
	}
	context := DecodeContext{RuntimePlatform: inputs.Platform, BackendSettings: inputs.BackendSettings}
	backupLoaded, err := Decode(backupBytes, context)
	if err != nil {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate backup", Err: errors.Join(ErrRollbackV4Backup, err)})
	}
	if backupLoaded.SourceVersion == Version4 {
		return V4ApplyResult{}, migrationError(MigrationError{Operation: "validate backup", Err: ErrRollbackV4Backup})
	}
	if bytes.Equal(snapshot.Document(), backupBytes) {
		return V4ApplyResult{Migration: MigrationResult{SourceVersion: loaded.SourceVersion, TargetVersion: backupLoaded.SourceVersion, BackupPath: backup}}, nil
	}
	store, err := openStore(stateDirOf(snapshot))
	if err != nil {
		return V4ApplyResult{}, err
	}
	preRollback := filename + ".pre-rollback." + loaded.SourceVersion
	replaced := false
	generation, err := store.CommitConfigChange(func() error {
		if err := replaceDurably(filesystem, filename, preRollback, snapshot.Document(), backupBytes); err != nil {
			return err
		}
		replaced = true
		return nil
	})
	if err != nil {
		if replaced {
			_, rollbackErr := writeTempReplace(filesystem, filename, snapshot.Document())
			if rollbackErr != nil {
				return V4ApplyResult{}, migrationError(MigrationError{Operation: "recover source after trust commit", Err: errors.Join(ErrMigrationSync, ErrMigrationRecovery, err, rollbackErr)})
			}
		}
		return V4ApplyResult{}, err
	}
	return V4ApplyResult{
		Migration:  MigrationResult{SourceVersion: loaded.SourceVersion, TargetVersion: backupLoaded.SourceVersion, BackupPath: preRollback, Changed: true},
		Generation: generation,
	}, nil
}
