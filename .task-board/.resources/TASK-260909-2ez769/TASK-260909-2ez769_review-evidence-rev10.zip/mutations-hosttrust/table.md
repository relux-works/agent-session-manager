| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| hold-state-root-skip | Admits exactly a bound token used with a foreign StateRoot while preserving the configuration-path binding | TestHeldExclusiveRejectsForeignConfigStateRoot | 1 | killed:  |
