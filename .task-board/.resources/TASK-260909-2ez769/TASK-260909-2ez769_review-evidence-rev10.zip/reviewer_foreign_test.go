package config
import("bytes";"errors";"os";"path/filepath";"strings";"testing";"time";"github.com/relux-works/agent-session-manager/internal/hosttrust")
func TestReviewerConfiguredForeignStore(t *testing.T) {
	fixture := setupV4Fixture(t)
	original, err := os.ReadFile(fixture.filename)
	if err != nil {
		t.Fatal(err)
	}

	entered := make(chan struct{})
	release := make(chan struct{})
	holderDone := make(chan error, 1)
	go func() {
		holderDone <- fixture.store.WithExclusiveHold(func(hosttrust.HeldExclusive) error {
			close(entered)
			<-release
			return nil
		})
	}()
	select {
	case <-entered:
	case <-time.After(2 * time.Second):
		close(release)
		t.Fatal("target store did not acquire its exclusive hold")
	}

	other, err := hosttrust.Open(filepath.Join(t.TempDir(), "other-state"))
	if err != nil {
		close(release)
		t.Fatal(err)
	}
	if err := other.EnsureConfigBinding(fixture.filename, filepath.Dir(other.Root())); err != nil { close(release); t.Fatal(err) }; if _, err := other.Initialize(); err != nil {
		close(release)
		t.Fatal(err)
	}
	writeErr := other.WithExclusiveHold( func(hold hosttrust.HeldExclusive) error {
		_, err := writeTempReplace(hold, filepath.Dir(other.Root()), osMigrationFileSystem{}, fixture.filename, []byte("foreign replacement\n"))
		return err
	})
	close(release)
	if err := <-holderDone; err != nil {
		t.Fatalf("target holder error = %v", err)
	}
	observed, readErr := os.ReadFile(fixture.filename)
 t.Logf("writer returned %v; target read error %v; target contains foreign replacement: %v", writeErr, readErr, string(observed)=="foreign replacement\n")
 if !errors.Is(writeErr, hosttrust.ErrExclusiveHoldResourceMismatch) {
		t.Fatalf("foreign-store write error = %v, want %v", writeErr, hosttrust.ErrExclusiveHoldResourceMismatch)
	}
	after, err := os.ReadFile(fixture.filename)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(after, original) {
		t.Fatal("foreign-store hold changed the target configuration")
	}
	entries, err := os.ReadDir(filepath.Dir(fixture.filename))
	if err != nil {
		t.Fatal(err)
	}
	for _, entry := range entries {
		if strings.HasPrefix(entry.Name(), ".ax-config-restore-") {
			t.Fatalf("foreign-store refusal left staging file %q", entry.Name())
		}
	}
}

