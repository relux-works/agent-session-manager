package config
type reviewerAction interface{Execute()error}; func reviewerInvoke[T reviewerAction](f T)error{return f.Execute()}
