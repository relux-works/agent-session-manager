package config
import("testing";"os";"path/filepath")
type reviewerCallback struct{path string}
func(c reviewerCallback)Execute()error{return os.WriteFile(c.path,[]byte("new"),0600)}
func TestReviewerRoguePlantExecutes(t *testing.T){p:=filepath.Join(t.TempDir(),"config.toml");if e:=os.WriteFile(p,[]byte("old"),0600);e!=nil{t.Fatal(e)}; ch:=make(chan func()error,1);ch<-reviewerCallback{p}.Execute;if e:=reviewerInvoke(ch);e!=nil{t.Fatal(e)}; b,e:=os.ReadFile(p);if e!=nil||string(b)!="new"{t.Fatalf("witness %s %v",b,e)};t.Log("production indirect boundary wrote real bytes without a hold")}
