package config
func reviewerInvoke(ch chan func()error)error{return (<-ch)()}
