package config
type reviewerAction interface{Execute()error}; func reviewerInvoke(f reviewerAction)error{return f.Execute()}
