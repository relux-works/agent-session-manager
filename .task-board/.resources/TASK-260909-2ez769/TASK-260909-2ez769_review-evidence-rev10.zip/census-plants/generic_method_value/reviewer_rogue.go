package config
type reviewerAction interface{Execute()error}; func reviewerInvoke[T reviewerAction](f T)error{run:=f.Execute;return run()}
