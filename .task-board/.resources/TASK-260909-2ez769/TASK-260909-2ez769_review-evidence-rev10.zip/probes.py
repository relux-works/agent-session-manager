from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
candidate=root/'candidate'
prior=root/'prior/census-plants'
results=[]
prod=candidate/'internal/config/reviewer_rogue.go'
test=candidate/'internal/config/reviewer_rogue_test.go'
extra={
'generic_direct_boundary':'type reviewerAction interface{Execute()error}; func reviewerInvoke[T reviewerAction](f T)error{return f.Execute()}',
'interface_direct_boundary':'type reviewerAction interface{Execute()error}; func reviewerInvoke(f reviewerAction)error{return f.Execute()}',
'generic_method_value':'type reviewerAction interface{Execute()error}; func reviewerInvoke[T reviewerAction](f T)error{run:=f.Execute;return run()}',
'channel_callback':'func reviewerInvoke(ch chan func()error)error{return (<-ch)()}',
}
witness='''package config
import("testing";"os";"path/filepath")
type reviewerCallback struct{path string}
func(c reviewerCallback)Execute()error{return os.WriteFile(c.path,[]byte("new"),0600)}
func TestReviewerRoguePlantExecutes(t *testing.T){p:=filepath.Join(t.TempDir(),"config.toml");if e:=os.WriteFile(p,[]byte("old"),0600);e!=nil{t.Fatal(e)}; CALL; b,e:=os.ReadFile(p);if e!=nil||string(b)!="new"{t.Fatalf("witness %s %v",b,e)};t.Log("production indirect boundary wrote real bytes without a hold")}
'''
try:
 shapes=[(d.name,(d/'reviewer_rogue.go').read_text(),(d/'reviewer_rogue_test.go').read_text()) for d in sorted(prior.iterdir()) if d.is_dir()]
 for name,body in extra.items():
  call='if e:=reviewerInvoke(reviewerCallback{p});e!=nil{t.Fatal(e)}'
  if name=='channel_callback':call='ch:=make(chan func()error,1);ch<-reviewerCallback{p}.Execute;if e:=reviewerInvoke(ch);e!=nil{t.Fatal(e)}'
  shapes.append((name,'package config\n'+body+'\n',witness.replace('CALL',call)))
 for name,source,testing in shapes:
  folder=root/'census-plants'/name;folder.mkdir(parents=True,exist_ok=True)
  prod.write_text(source);test.write_text(testing)
  (folder/prod.name).write_text(source);(folder/test.name).write_text(testing)
  p=subprocess.run(['go','test','./internal/config','-count=1','-v','-run','^(TestWritePathCensusGate|TestReviewerRoguePlantExecutes)$'],cwd=candidate,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (folder/'test.log').write_bytes(p.stdout)
  row={'plant':name,'exit':p.returncode,'witness_pass':b'--- PASS: TestReviewerRoguePlantExecutes' in p.stdout,'gate_pass':b'--- PASS: TestWritePathCensusGate' in p.stdout};results.append(row);print(json.dumps(row),flush=True)
finally:
 prod.unlink(missing_ok=True);test.unlink(missing_ok=True)
(root/'census-results.json').write_text(json.dumps(results,indent=2))
