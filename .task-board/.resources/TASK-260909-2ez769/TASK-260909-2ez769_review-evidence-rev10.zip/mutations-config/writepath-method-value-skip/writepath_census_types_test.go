package config

import (
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/token"
	"go/types"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"testing"

	"golang.org/x/tools/go/packages"
)

// censusTypedViolations is the authoritative write-path gate. It resolves
// package, method, alias-import and function-value identity through go/types;
// spelling a package "os" or hiding a writer behind a closure does not evade
// the gate. The loader evaluates the current Go build context; build-tagged
// or platform-specific sources require a separate invocation under that
// context. Unknown indirect callees fail closed unless they are inside one of
// the exact censused definitions. The older syntax walker remains in
// writepath_census_test.go as a small reference implementation for historical
// evidence, but all tests use this symbol-aware implementation.
func censusTypedViolations(t *testing.T, dirs ...string) []string {
	t.Helper()
	var units []censusTypeUnit
	for _, dir := range dirs {
		unit, err := loadCensusTypeUnit(dir)
		if err != nil {
			t.Fatalf("load write-path census package %s: %v", dir, err)
		}
		units = append(units, unit)
	}
	gated := censusGatedFunctions(units)
	var violations []string
	for _, unit := range units {
		scanner := newCensusTypeScanner(unit, gated)
		violations = append(violations, scanner.scan()...)
	}
	sort.Strings(violations)
	return violations
}

type censusTypeUnit struct {
	dir   string
	fset  *token.FileSet
	files []*ast.File
	info  *types.Info
	pkg   *types.Package
}

func loadCensusTypeUnit(dir string) (censusTypeUnit, error) {
	root := censusModuleRoot()
	absolute, err := filepath.Abs(dir)
	if err != nil {
		return censusTypeUnit{}, err
	}
	if absolute == root || strings.HasPrefix(absolute, root+string(filepath.Separator)) {
		loaded, err := packages.Load(&packages.Config{
			Mode:  packages.NeedName | packages.NeedFiles | packages.NeedSyntax | packages.NeedTypes | packages.NeedTypesInfo | packages.NeedDeps,
			Dir:   absolute,
			Tests: false,
		}, ".")
		if err != nil {
			return censusTypeUnit{}, err
		}
		if len(loaded) != 1 {
			return censusTypeUnit{}, fmt.Errorf("expected one package, got %d", len(loaded))
		}
		pkg := loaded[0]
		if len(pkg.Errors) != 0 {
			return censusTypeUnit{}, fmt.Errorf("type-check errors: %v", pkg.Errors)
		}
		if pkg.Fset == nil || pkg.Types == nil || pkg.TypesInfo == nil {
			return censusTypeUnit{}, fmt.Errorf("incomplete go/packages type information")
		}
		return censusTypeUnit{dir: absolute, fset: pkg.Fset, files: pkg.Syntax, info: pkg.TypesInfo, pkg: pkg.Types}, nil
	}

	entries, err := filepath.Glob(filepath.Join(absolute, "*.go"))
	if err != nil {
		return censusTypeUnit{}, err
	}
	sort.Strings(entries)
	fset := token.NewFileSet()
	var files []*ast.File
	for _, path := range entries {
		if strings.HasSuffix(path, "_test.go") {
			continue
		}
		file, err := parser.ParseFile(fset, path, nil, parser.AllErrors)
		if err != nil {
			return censusTypeUnit{}, err
		}
		files = append(files, file)
	}
	if len(files) == 0 {
		return censusTypeUnit{}, fmt.Errorf("no production Go files")
	}
	info := &types.Info{
		Types:      map[ast.Expr]types.TypeAndValue{},
		Defs:       map[*ast.Ident]types.Object{},
		Uses:       map[*ast.Ident]types.Object{},
		Selections: map[*ast.SelectorExpr]*types.Selection{},
		Scopes:     map[ast.Node]*types.Scope{},
	}
	conf := types.Config{Importer: importer.Default()}
	pkg, err := conf.Check("censuscontrol", fset, files, info)
	if err != nil {
		return censusTypeUnit{}, err
	}
	return censusTypeUnit{dir: absolute, fset: fset, files: files, info: info, pkg: pkg}, nil
}

func censusModuleRoot() string {
	_, file, _, ok := runtimeCensusCaller()
	if !ok {
		return ""
	}
	return filepath.Clean(filepath.Join(filepath.Dir(file), "..", ".."))
}

// Kept as a tiny indirection so the production census code remains easy to
// execute in a test without importing runtime in the old syntax-only file.
var runtimeCensusCaller = func() (uintptr, string, int, bool) {
	return runtimeCaller(0)
}

func runtimeCaller(skip int) (uintptr, string, int, bool) {
	return runtime.Caller(skip + 1)
}

type censusFunction struct {
	name     string
	pkgPath  string
	receiver string
}

func censusGatedFunctions(units []censusTypeUnit) map[*types.Func]string {
	result := map[*types.Func]string{}
	for _, unit := range units {
		for _, file := range unit.files {
			for _, declaration := range file.Decls {
				function, ok := declaration.(*ast.FuncDecl)
				if !ok || function.Name == nil {
					continue
				}
				object, ok := unit.info.Defs[function.Name].(*types.Func)
				if !ok || !censusGatedName(object.Name()) {
					continue
				}
				result[object] = object.Name()
			}
		}
	}
	return result
}

func censusGatedName(name string) bool {
	if censusPairHelpers[name] || censusGatedIdents[name] {
		return true
	}
	if _, ok := censusTrustHelpers[name]; ok {
		return true
	}
	if _, ok := censusCustodyHelpers[name]; ok {
		return true
	}
	return false
}

type censusTypeScanner struct {
	unit                    censusTypeUnit
	gated                   map[*types.Func]string
	allowedIndirectObjects  map[*types.Func]map[types.Object]bool
	allowedInterfaceMethods map[*types.Func]bool
	allowedFunctionValues   map[types.Object]bool
	allowedInitializers     map[string]bool
	result                  []string
}

type censusIndirectPolicy struct {
	parameters      map[string]bool
	locals          map[string]bool
	interfaceMethod bool
}

// These are the only production indirect edges that the scanner may admit.
// The descriptor is used only while loading the package; the scanner stores
// and compares the resulting *types.Func/*types.Var objects, so a same-named
// function, receiver, parameter or interface in another package cannot inherit
// an exemption. Every other unresolved/function-value/type-parameter edge is
// a violation.
var censusIndirectPolicies = map[censusFunction]censusIndirectPolicy{
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "writeAll"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "replaceDurably"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "writeTempFile"}: {
		locals:          map[string]bool{"clean": true},
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "writeTempReplace"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "applyV4"}: {
		parameters: map[string]bool{"openStore": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "rollbackV4"}: {
		parameters: map[string]bool{"openStore": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "validateRootKinds"}: {
		parameters: map[string]bool{"stat": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "admitSSHArguments"}: {
		locals: map[string]bool{"rule": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "admitSSHOption"}: {
		locals: map[string]bool{"rule": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", name: "sshFlagValueRule"}: {
		parameters: map[string]bool{"permits": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "writeAll"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "withExclusiveHold"}: {
		parameters: map[string]bool{"fn": true},
		locals:     map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "fileLock", name: "exclusiveHold"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "WithExclusiveHold"}: {
		parameters: map[string]bool{"fn": true},
		locals:     map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "WithSharedSnapshot"}: {
		parameters: map[string]bool{"fn": true},
		locals:     map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "JointCommit"}: {
		parameters: map[string]bool{"revalidate": true, "replace": true, "restore": true},
		locals:     map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "transactLocked"}: {
		parameters: map[string]bool{"fn": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "WithMutationAuthorization"}: {
		parameters: map[string]bool{"boundary": true},
		locals:     map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "AuthorizeDispatch"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "EnsureConfigBinding"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "ValidateBoundConfigPath"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "readSnapshot"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "lockForConvergedRead"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "transact"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "Initialize"}: {
		locals:          map[string]bool{"unlock": true},
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "Recover"}: {
		locals: map[string]bool{"unlock": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "decodeEntryString"}: {
		parameters: map[string]bool{"accept": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "compensateLocked"}: {
		parameters: map[string]bool{"restore": true},
		locals:     map[string]bool{"failed": true},
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "openLock"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "removeMarkerLocked"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "commitDocument"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "writeCustodyFile"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "Issue"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "Rotate"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "cleanupStagedFile"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", name: "cleanupCredentialDirectory"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "TrustStore", name: "Format"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "CredentialEntry", name: "Format"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "AuthRequest", name: "Format"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Snapshot", name: "Format"}: {
		interfaceMethod: true,
	},
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "EnrollmentMaterial", name: "Format"}: {
		interfaceMethod: true,
	},
}

// These package variables are test seams or immutable error constructors,
// not filesystem writers. Their declaration objects are admitted explicitly;
// arbitrary function-valued variables remain rejected at call sites.
var censusAllowedFunctionValues = map[string]map[string]bool{
	"github.com/relux-works/agent-session-manager/internal/config": {
		"tomlDecode": true, "migrationError": true, "configError": true, "loaderError": true,
		"terminalCapabilitySet": true,
	},
	"github.com/relux-works/agent-session-manager/internal/hosttrust": {
		"trustError": true,
	},
}

// These standard-library function variables are immutable constructors or
// curve selectors, not mutation entry points. They are admitted by the exact
// declaration object resolved from the loaded package, never by a signature.
var censusAllowedExternalFunctionValues = map[string]map[string]bool{
	"crypto/elliptic": {"P256": true},
}

// The terminal capability set is an immutable package initializer whose
// expression is an immediately-invoked function literal. Keep that one
// initializer explicit; arbitrary immediate function calls remain rejected.
var censusAllowedFunctionInitializers = map[string]map[string]bool{
	"github.com/relux-works/agent-session-manager/internal/config": {"var terminalCapabilitySet": true},
}

type censusFunctionField struct {
	pkgPath  string
	typeName string
	name     string
}

// sshValueRule.permits is a pure validator callback. The scanner records its
// resolved field object below; an unrelated function-valued field remains
// rejected even if it has the same shape elsewhere.
var censusAllowedFunctionFields = map[censusFunctionField]bool{
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", typeName: "sshOptionRule", name: "permits"}: true,
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", typeName: "Inputs", name: "LookupEnv"}:      true,
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", typeName: "Inputs", name: "Stat"}:           true,
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/config", typeName: "Inputs", name: "ReadFile"}:       true,
}

func newCensusTypeScanner(unit censusTypeUnit, gated map[*types.Func]string) censusTypeScanner {
	scanner := censusTypeScanner{
		unit: unit, gated: gated,
		allowedIndirectObjects:  map[*types.Func]map[types.Object]bool{},
		allowedInterfaceMethods: map[*types.Func]bool{},
		allowedFunctionValues:   map[types.Object]bool{},
		allowedInitializers:     map[string]bool{},
	}
	for name := range censusAllowedFunctionInitializers[unit.pkg.Path()] {
		scanner.allowedInitializers[name] = true
	}
	if unit.pkg != nil && unit.pkg.Scope() != nil {
		for name := range censusAllowedFunctionValues[unit.pkg.Path()] {
			if object := unit.pkg.Scope().Lookup(name); object != nil {
				scanner.allowedFunctionValues[object] = true
			}
		}
	}
	for _, object := range unit.info.Uses {
		variable, ok := object.(*types.Var)
		if !ok || variable.Pkg() == nil {
			continue
		}
		if censusAllowedExternalFunctionValues[variable.Pkg().Path()][variable.Name()] {
			scanner.allowedFunctionValues[variable] = true
		}
	}
	for _, file := range unit.files {
		for _, declaration := range file.Decls {
			if general, ok := declaration.(*ast.GenDecl); ok && general.Tok == token.TYPE {
				for _, specification := range general.Specs {
					typeSpec, ok := specification.(*ast.TypeSpec)
					if !ok {
						continue
					}
					structure, ok := typeSpec.Type.(*ast.StructType)
					if !ok {
						continue
					}
					for _, field := range structure.Fields.List {
						for _, identifier := range field.Names {
							object := unit.info.Defs[identifier]
							if censusAllowedFunctionFields[censusFunctionField{pkgPath: unit.pkg.Path(), typeName: typeSpec.Name.Name, name: identifier.Name}] {
								scanner.allowedFunctionValues[object] = true
							}
						}
					}
				}
			}
			functionDecl, ok := declaration.(*ast.FuncDecl)
			if !ok || functionDecl.Name == nil {
				continue
			}
			function, ok := unit.info.Defs[functionDecl.Name].(*types.Func)
			if !ok {
				continue
			}
			policy, ok := censusIndirectPolicies[censusFunctionOf(function)]
			if !ok {
				continue
			}
			if policy.interfaceMethod {
				scanner.allowedInterfaceMethods[function] = true
			}
			signature, ok := function.Type().(*types.Signature)
			if !ok {
				continue
			}
			allowed := map[types.Object]bool{}
			for index := 0; index < signature.Params().Len(); index++ {
				parameter := signature.Params().At(index)
				if policy.parameters[parameter.Name()] {
					allowed[parameter] = true
				}
			}
			if len(policy.locals) != 0 && functionDecl.Body != nil {
				ast.Inspect(functionDecl.Body, func(node ast.Node) bool {
					identifier, ok := node.(*ast.Ident)
					if !ok || !policy.locals[identifier.Name] {
						return true
					}
					if variable, ok := unit.info.Uses[identifier].(*types.Var); ok {
						allowed[variable] = true
					}
					return true
				})
			}
			if len(allowed) != 0 {
				scanner.allowedIndirectObjects[function] = allowed
			}
		}
	}
	return scanner
}

func (scanner *censusTypeScanner) scan() []string {
	for _, file := range scanner.unit.files {
		for _, declaration := range file.Decls {
			switch value := declaration.(type) {
			case *ast.FuncDecl:
				if value.Body == nil || scanner.isBackendMethod(value) {
					continue
				}
				function := censusObject(scanner.unit.info.Defs[value.Name])
				scanner.walk(value.Body, value.Name.Name, function)
			case *ast.GenDecl:
				for _, specification := range value.Specs {
					variables, ok := specification.(*ast.ValueSpec)
					if !ok {
						continue
					}
					for _, initializer := range variables.Values {
						name := "package initializer"
						if len(variables.Names) == len(variables.Values) {
							for index, variable := range variables.Values {
								if variable == initializer && index < len(variables.Names) {
									name = "var " + variables.Names[index].Name
								}
							}
						}
						scanner.walk(initializer, name, nil)
					}
				}
			}
		}
	}
	return scanner.result
}

func (scanner *censusTypeScanner) isBackendMethod(function *ast.FuncDecl) bool {
	object, ok := scanner.unit.info.Defs[function.Name].(*types.Func)
	if !ok {
		return false
	}
	return censusBackendDefinition(object)
}

func censusObject(object types.Object) *types.Func {
	function, _ := object.(*types.Func)
	return function
}

func censusFunctionOf(object *types.Func) censusFunction {
	if object == nil {
		return censusFunction{}
	}
	function := censusFunction{name: object.Name()}
	if object.Pkg() != nil {
		function.pkgPath = object.Pkg().Path()
	}
	if signature, ok := object.Type().(*types.Signature); ok && signature.Recv() != nil {
		function.receiver = censusNamedType(signature.Recv().Type())
	}
	return function
}

// censusAllowedDefinition matches the allowlist by the resolved definition
// identity, not by a bare spelling. The package path and receiver are part of
// the key; a same-named helper in another package or a newly added receiver
// method is scanned as a new write path. Synthetic plants use the empty
// censuscontrol package as a shape-only package, so they retain the original
// receiver-independent control semantics.
func censusAllowedDefinition(helper, current *types.Func, allowed map[string]bool) bool {
	if helper == nil || current == nil || helper.Pkg() == nil || current.Pkg() == nil {
		return false
	}
	if helper.Pkg().Path() != current.Pkg().Path() || !allowed[current.Name()] {
		return false
	}
	if current.Pkg().Path() == "censuscontrol" {
		return true
	}
	expected, hasExpected := censusExpectedReceivers[current.Name()]
	if !hasExpected {
		return current.Type().(*types.Signature).Recv() == nil
	}
	return censusNamedType(current.Type().(*types.Signature).Recv().Type()) == expected
}

var censusExpectedReceivers = map[string]string{
	"Initialize":                "Store",
	"JointCommit":               "Store",
	"Issue":                     "Store",
	"Rotate":                    "Store",
	"MarkRetiring":              "Store",
	"Revoke":                    "Store",
	"ensureConfigBindingLocked": "Store",
}

func censusNamedType(typ types.Type) string {
	switch value := typ.(type) {
	case *types.Pointer:
		return censusNamedType(value.Elem())
	case *types.Named:
		return value.Obj().Name()
	default:
		return ""
	}
}

func censusBackendDefinition(object *types.Func) bool {
	function := censusFunctionOf(object)
	if !censusBackendPackages[function.pkgPath] {
		return false
	}
	methods, ok := censusBackendMethods[function.receiver]
	return ok && methods[function.name]
}

// censusIsCensusedDefinition identifies the narrow set of production and
// synthetic definitions whose bodies are already covered by a stronger
var censusBackendPackages = map[string]bool{
	"github.com/relux-works/agent-session-manager/internal/config":    true,
	"github.com/relux-works/agent-session-manager/internal/hosttrust": true,
	"censuscontrol": true,
}

func (scanner *censusTypeScanner) walk(root ast.Node, functionName string, current *types.Func) {
	var stack []ast.Node
	ast.Inspect(root, func(node ast.Node) bool {
		if node == nil {
			if len(stack) != 0 {
				stack = stack[:len(stack)-1]
			}
			return false
		}
		stack = append(stack, node)
		scanner.visit(node, stack, functionName, current)
		return true
	})
}

func (scanner *censusTypeScanner) visit(node ast.Node, stack []ast.Node, functionName string, current *types.Func) {
	switch value := node.(type) {
	case *ast.CallExpr:
		scanner.visitCall(value, stack, functionName, current)
	case *ast.Ident:
		scanner.visitIdent(value, stack, functionName)
	case *ast.SelectorExpr:
		if !scanner.isCallCallee(value, stack) {
			scanner.visitSelectorValue(value, stack, functionName)
		}
	}
}

func (scanner *censusTypeScanner) visitCall(call *ast.CallExpr, stack []ast.Node, functionName string, current *types.Func) {
	object, resolved := scanner.callObject(call)
	if !resolved {
		// A conversion has no callable object and is harmless by definition;
		// every other unresolved callee, including an immediate function
		// literal, is an unknown indirect edge and fails closed.
		if typeAndValue, ok := scanner.unit.info.Types[call.Fun]; ok && typeAndValue.IsType() {
			return
		}
		if _, immediate := call.Fun.(*ast.FuncLit); immediate && scanner.allowedInitializers[functionName] {
			return
		}
		scanner.add(call, "unresolved call callee in "+functionName)
		return
	}
	function, ok := object.(*types.Func)
	if !ok {
		switch object.(type) {
		case *types.Builtin, *types.TypeName:
			return
		}
		if scanner.allowedFunctionValues[object] {
			return
		}
		if !scanner.allowedIndirectObjects[current][object] {
			scanner.add(call, "indirect call callee is not an allowlisted declaration in "+functionName)
		}
		return
	}
	if scanner.callUsesInterfaceMutationMethod(call) && !scanner.allowedInterfaceMethods[current] {
		scanner.add(call, "interface or type-parameter call target is not an allowlisted edge in "+functionName)
		return
	}
	if helper, isGated := scanner.gated[function]; isGated {
		scanner.checkGatedCall(call, stack, functionName, helper, function, current)
		return
	}
	if censusIsOSMutation(function) {
		scanner.add(call, "direct os mutation outside the exact backend definition in "+functionName)
		return
	}
	if censusIsRawMutation(function) {
		allowed := censusRawMutations[function.Name()]
		if !censusAllowedDefinition(function, current, allowed) {
			scanner.add(call, "filesystem mutation method outside the censused writer in "+functionName)
		}
	}
}

func (scanner *censusTypeScanner) checkGatedCall(call *ast.CallExpr, stack []ast.Node, functionName, helper string, helperFunction, current *types.Func) {
	position := scanner.unit.fset.Position(call.Pos())
	if censusPairHelpers[helper] {
		if scanner.insideHoldClosure(stack) {
			return
		}
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s call is outside a resource-bound hold closure in %s", position.Filename, position.Line, helper, functionName))
		return
	}
	if allowed, ok := censusTrustHelpers[helper]; ok {
		if censusAllowedDefinition(helperFunction, current, allowed) {
			return
		}
	}
	if allowed, ok := censusCustodyHelpers[helper]; ok {
		if censusAllowedDefinition(helperFunction, current, allowed) {
			return
		}
	}
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s call is outside the censused writer in %s", position.Filename, position.Line, helper, functionName))
}

func (scanner *censusTypeScanner) visitIdent(identifier *ast.Ident, stack []ast.Node, functionName string) {
	object, ok := scanner.unit.info.Uses[identifier].(*types.Func)
	if !ok {
		return
	}
	if scanner.isCallCallee(identifier, stack) || scanner.isSelectorName(identifier, stack) {
		return
	}
	helper, gated := scanner.gated[object]
	if !gated && !censusIsOSMutation(object) && !censusIsRawMutation(object) {
		return
	}
	position := scanner.unit.fset.Position(identifier.Pos())
	if gated {
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: gated helper %s escapes as a value in %s", position.Filename, position.Line, helper, functionName))
		return
	}
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: filesystem mutation function %s escapes as a value in %s", position.Filename, position.Line, object.Name(), functionName))
}

func (scanner *censusTypeScanner) visitSelectorValue(selector *ast.SelectorExpr, stack []ast.Node, functionName string) {
	object := scanner.selectorObject(selector)
	function, ok := object.(*types.Func)
	if !ok {
		if variable, ok := object.(*types.Var); ok && censusIsMutationFunctionName(variable.Name()) {
			position := scanner.unit.fset.Position(selector.Pos())
			scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: indirect filesystem mutation function escapes as a value in %s", position.Filename, position.Line, functionName))
		}
		return
	}
	if helper, gated := scanner.gated[function]; gated {
		position := scanner.unit.fset.Position(selector.Pos())
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: gated helper %s escapes as a value in %s", position.Filename, position.Line, helper, functionName))
		return
	}
	if censusIsOSMutation(function) || (censusIsRawMutation(function) && function.Name() == "not-a-real-mutation") {
		position := scanner.unit.fset.Position(selector.Pos())
		scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: filesystem mutation function %s escapes as a value in %s", position.Filename, position.Line, function.Name(), functionName))
	}
}

func (scanner *censusTypeScanner) callObject(call *ast.CallExpr) (types.Object, bool) {
	object := scanner.expressionObject(call.Fun)
	if object != nil {
		return object, true
	}
	return nil, false
}

func (scanner *censusTypeScanner) expressionObject(expression ast.Expr) types.Object {
	switch value := expression.(type) {
	case *ast.Ident:
		return scanner.unit.info.Uses[value]
	case *ast.SelectorExpr:
		return scanner.selectorObject(value)
	case *ast.ParenExpr:
		return scanner.expressionObject(value.X)
	case *ast.IndexExpr:
		return scanner.expressionObject(value.X)
	case *ast.IndexListExpr:
		return scanner.expressionObject(value.X)
	}
	return nil
}

func (scanner *censusTypeScanner) selectorObject(selector *ast.SelectorExpr) types.Object {
	if selection := scanner.unit.info.Selections[selector]; selection != nil {
		return selection.Obj()
	}
	return scanner.unit.info.Uses[selector.Sel]
}

func (scanner *censusTypeScanner) callUsesInterfaceMethod(call *ast.CallExpr) bool {
	selector, ok := call.Fun.(*ast.SelectorExpr)
	if !ok {
		return false
	}
	selection := scanner.unit.info.Selections[selector]
	if selection == nil {
		return false
	}
	return censusIsInterfaceType(selection.Recv())
}

func (scanner *censusTypeScanner) callUsesInterfaceMutationMethod(call *ast.CallExpr) bool {
	if !scanner.callUsesInterfaceMethod(call) {
		return false
	}
	selector, ok := call.Fun.(*ast.SelectorExpr)
	return ok && censusIsMutationFunctionName(selector.Sel.Name)
}

func censusIsInterfaceType(typ types.Type) bool {
	switch value := typ.(type) {
	case *types.Pointer:
		return censusIsInterfaceType(value.Elem())
	case *types.Named:
		return censusIsInterfaceType(value.Underlying())
	case *types.Interface:
		return true
	case *types.TypeParam:
		return true
	default:
		return false
	}
}

func (scanner *censusTypeScanner) isCallCallee(node ast.Node, stack []ast.Node) bool {
	for index := len(stack) - 1; index > 0; index-- {
		call, ok := stack[index-1].(*ast.CallExpr)
		if ok && call.Fun == node {
			return true
		}
		if call, ok := stack[index-1].(*ast.CallExpr); ok {
			if containsNode(call.Fun, node) {
				return true
			}
		}
		if _, ok := stack[index-1].(*ast.FuncLit); ok {
			break
		}
	}
	return false
}

func (scanner *censusTypeScanner) isSelectorName(identifier *ast.Ident, stack []ast.Node) bool {
	for index := len(stack) - 1; index >= 0; index-- {
		selector, ok := stack[index].(*ast.SelectorExpr)
		if ok && selector.Sel == identifier {
			return true
		}
	}
	return false
}

func containsNode(root ast.Node, needle ast.Node) bool {
	found := false
	ast.Inspect(root, func(node ast.Node) bool {
		if node == needle {
			found = true
			return false
		}
		return !found
	})
	return found
}

func (scanner *censusTypeScanner) insideHoldClosure(stack []ast.Node) bool {
	for index := len(stack) - 1; index >= 0; index-- {
		literal, ok := stack[index].(*ast.FuncLit)
		if !ok {
			continue
		}
		if index == 0 {
			return false
		}
		call, ok := stack[index-1].(*ast.CallExpr)
		if !ok || !scanner.isHoldEntryCall(call) {
			return false
		}
		for _, argument := range call.Args {
			if argument == literal {
				return true
			}
		}
		return false
	}
	return false
}

func (scanner *censusTypeScanner) isHoldEntryCall(call *ast.CallExpr) bool {
	object, resolved := scanner.callObject(call)
	if !resolved {
		return false
	}
	function, ok := object.(*types.Func)
	if !ok {
		return false
	}
	return censusHoldEntries[censusFunctionOf(function)]
}

func (scanner *censusTypeScanner) add(node ast.Node, message string) {
	position := scanner.unit.fset.Position(node.Pos())
	scanner.result = append(scanner.result, fmt.Sprintf("%s:%d: %s", position.Filename, position.Line, message))
}

func censusIsOSMutation(function *types.Func) bool {
	return function != nil && function.Pkg() != nil && function.Pkg().Path() == "os" && censusOSMutations[function.Name()]
}

func censusIsRawMutation(function *types.Func) bool {
	if function == nil || censusIsOSMutation(function) {
		return false
	}
	if _, ok := censusRawMutations[function.Name()]; ok {
		return function.Type() != nil && function.Type().(*types.Signature).Recv() != nil
	}
	return function.Name() == "CreateExclusive"
}

func censusIsMutationFunctionName(name string) bool {
	switch name {
	case "Write", "WriteFile", "Rename", "Remove", "RemoveAll", "CreateTemp", "CreateExclusive", "Link":
		return true
	default:
		return false
	}
}

var censusHoldEntries = map[censusFunction]bool{
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "JointCommit"}:       true,
	{pkgPath: "github.com/relux-works/agent-session-manager/internal/hosttrust", receiver: "Store", name: "WithExclusiveHold"}: true,
	{pkgPath: "censuscontrol", receiver: "store", name: "JointCommit"}:                                                         true,
	{pkgPath: "censuscontrol", receiver: "store", name: "WithExclusiveHold"}:                                                   true,
}
