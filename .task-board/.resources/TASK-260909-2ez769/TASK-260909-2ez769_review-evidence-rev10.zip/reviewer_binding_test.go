package config
import("bytes";"encoding/json";"errors";"os";"path/filepath";"testing";"github.com/relux-works/agent-session-manager/internal/hosttrust")
func TestReviewerBindingRemovedThenReestablished(t *testing.T){
 f:=setupV4Fixture(t);original,e:=os.ReadFile(f.filename);if e!=nil{t.Fatal(e)}
 if e=os.Remove(filepath.Join(f.store.Root(),"config-binding.json"));e!=nil{t.Fatal(e)}
 s,e:=hosttrust.Open(f.stateDir);if e!=nil{t.Fatal(e)}
 e=s.WithExclusiveHold(func(h hosttrust.HeldExclusive)error{_,e:=writeTempReplace(h,f.stateDir,osMigrationFileSystem{},f.filename,original);return e})
 if !errors.Is(e,hosttrust.ErrExclusiveHoldResourceMismatch){t.Fatalf("missing binding write=%v",e)}
 b,e:=os.ReadFile(f.filename);if e!=nil||!bytes.Equal(b,original){t.Fatal("refusal changed bytes",e)}
 if e=s.EnsureConfigBinding(f.filename,f.stateDir);e!=nil{t.Fatal(e)}
 e=s.WithExclusiveHold(func(h hosttrust.HeldExclusive)error{_,e:=writeTempReplace(h,f.stateDir,osMigrationFileSystem{},f.filename,original);return e});if e!=nil{t.Fatal(e)}
}
func TestReviewerForgedForeignBindingRefuses(t *testing.T){
 f:=setupV4Fixture(t); original,e:=os.ReadFile(f.filename);if e!=nil{t.Fatal(e)}
 state:=t.TempDir();s,e:=hosttrust.Open(state);if e!=nil{t.Fatal(e)}
 b,e:=json.Marshal(hosttrust.ConfigBinding{Schema:"urn:ax:schema:host-config-binding",SchemaVersion:"1.0.0",ConfigPath:f.filename});if e!=nil{t.Fatal(e)}
 if e=os.WriteFile(filepath.Join(s.Root(),"config-binding.json"),b,0600);e!=nil{t.Fatal(e)}
 s,e=hosttrust.Open(state);if e!=nil{t.Fatal(e)}
 e=s.WithExclusiveHold(func(h hosttrust.HeldExclusive)error{_,e:=writeTempReplace(h,f.stateDir,osMigrationFileSystem{},f.filename,[]byte("foreign"));return e})
 if !errors.Is(e,hosttrust.ErrExclusiveHoldResourceMismatch){t.Fatalf("forged binding write=%v",e)}
 after,e:=os.ReadFile(f.filename);if e!=nil||!bytes.Equal(after,original){t.Fatal("refusal changed bytes",e)}
 entries,e:=os.ReadDir(filepath.Dir(f.filename));if e!=nil{t.Fatal(e)};if len(entries)!=2{t.Fatalf("staging residue: %v",entries)}
}
func TestReviewerSymlinkBindingIdentity(t *testing.T){
 f:=setupV4Fixture(t);alias:=filepath.Join(t.TempDir(),"alias.toml");if e:=os.Symlink(f.filename,alias);e!=nil{t.Fatal(e)}
 if e:=f.store.EnsureConfigBinding(alias,f.stateDir);e!=nil{t.Fatal(e)}
 if e:=f.store.WithExclusiveHold(func(h hosttrust.HeldExclusive)error{return h.ValidateConfigPath(alias)});e!=nil{t.Fatal(e)}
}
