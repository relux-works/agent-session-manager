#!/usr/bin/env python3
"""Apply one F1 plant (argv[1] = p1|p2|p3|p4|p5) to probe migration.go."""
import sys

path = "/tmp/rev12/probe/internal/config/migration.go"
src = open(path).read()
guard = "\tif err := requireHoldForConfig(hold, paths); err != nil {\n\t\treturn err\n\t}"
assert src.count(guard) >= 1, "hold guard not found"
plant = sys.argv[1]

if plant == "p1":
    # second Rename of admitted object at a later unlisted position (after hold)
    new = guard + '\n\tif backup == "reviewer-p1" {\n\t\treturn filesystem.Rename(string(original), string(replacement))\n\t}'
    src = src.replace(guard, new, 1)
elif plant == "p2":
    # method value escaping to local closure, invoked before hold
    new = ('\trn := filesystem.Rename\n'
           '\tif backup == "reviewer-p2" {\n\t\treturn rn(string(original), string(replacement))\n\t}\n' + guard)
    src = src.replace(guard, new, 1)
elif plant == "p3":
    # same object called inside a deferred func before hold
    new = ('\tdefer func() { _ = filesystem.Remove(string(original)) }()\n' + guard)
    src = src.replace(guard, new, 1)
elif plant == "p4":
    # admitted edge in an `if false` branch after the hold
    new = guard + '\n\tif false {\n\t\t_ = filesystem.Rename("reviewer-p4-a", "reviewer-p4-b")\n\t}'
    src = src.replace(guard, new, 1)
elif plant == "p5":
    # goto path that skips the hold statement
    new = ('\tif backup == "reviewer-p5" {\n\t\tgoto reviewerBypass\n\t}\n' + guard +
           '\nreviewerBypass:\n\t_, _ = filesystem.Stat(string(original))')
    src = src.replace(guard, new, 1)
else:
    raise SystemExit("unknown plant")

open(path, "w").write(src)
print(f"plant {plant} applied")
