| Mutant | Result | Exit | Expected killer |
| --- | --- | ---: | --- |
| compensate-rollback-source-swap | killed | 1 | TestRollbackV4CompensatesBumpFailure |
| replace-require-skip | killed | 1 | TestReplaceDurablyRefusesZeroHold |
| legacy-revalidate-skip | killed | 1 | TestRevalidateLegacySourceRefusesChangedBytes |
| replace-restore-skip | killed | 1 | TestMigrateRecoversOriginalAfterPostReplaceDirectorySyncFailureAndRetries |
| writepath-method-value-skip | killed | 1 | TestWritePathGateFlagsExecutableRogues/backend_method_value |
| writepath-interface-callsite-skip | killed | 1 | TestWritePathCensusRejectsUnlistedInterfaceCallSite |
| config-association-root-skip | killed | 1 | TestWriteTempReplaceRefusesForeignStoreWithTargetBinding |
