| Mutant | Result | Exit | Expected killer |
| --- | --- | ---: | --- |
| authorize-converge-ignore | killed | 1 | TestMutationAuthorizationRefusesIntervention |
| marker-unreadable | killed | 1 | TestReadSnapshotRefusesUnreadableMarker |
| lock-replacing-init | killed | 1 | TestFirstOpenPreservesHeldLock |
| compensate-marker-skip | killed | 1 | TestJointCommitCompensationRefusesTamperedMarker |
| compensate-restore-verify-skip | killed | 1 | TestJointCommitCompensationVerifiesRestore/noop_restore |
| compensate-restore-ignore | killed | 1 | TestJointCommitCompensationFailsAfterDurableRestore |
| hold-require-skip | killed | 1 | TestCommitDocumentRefusesZeroHold |
| hold-state-root-skip | killed | 1 | TestHeldExclusiveRejectsForeignConfigStateRoot |
| hold-no-lock | killed | 1 | TestWithExclusiveHoldSerializesWithTransaction |
| resolve-source-skip | killed | 1 | TestResolveFailedReplaceKeepsMarker |
| compensate-verify-before-restore | killed | 1 | TestJointCommitCompensatesBumpFailure |
