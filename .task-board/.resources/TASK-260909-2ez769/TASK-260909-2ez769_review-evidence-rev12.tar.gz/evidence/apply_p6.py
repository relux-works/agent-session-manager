#!/usr/bin/env python3
"""P6: goto bypass preserving every line number.
Replaces two comment lines (1:1, zero line delta) so all inventoried
sites keep exact file/line/column:
  - line '// Re-inspect the selected file...' -> single-line goto before guard
  - line '// the ones the replacement inherits.' -> label attaching to the
    inventoried filesystem.Stat call.
If the census admits this, a hold-skipping path to an inventoried site exists.
"""
path = "/tmp/rev12/probe/internal/config/migration.go"
src = open(path).read()
c1 = "\t// Re-inspect the selected file before anything durable is written. Load"
c2 = "\t// the ones the replacement inherits."
assert src.count(c1) == 1 and src.count(c2) == 1, "anchor comments not found"
src = src.replace(c1, '\tif backup == "reviewer-p5b" { goto reviewerSkip }', 1)
src = src.replace(c2, "\treviewerSkip:", 1)
open(path, "w").write(src)
print("plant p6 applied")
