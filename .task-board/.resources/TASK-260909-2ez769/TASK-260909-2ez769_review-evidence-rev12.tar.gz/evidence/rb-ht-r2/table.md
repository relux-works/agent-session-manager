| Mutant | Result | Exit | Expected killer |
| --- | --- | ---: | --- |
| hold-state-root-skip | killed | 1 | TestHeldExclusiveRejectsForeignConfigStateRoot |
| compensate-verify-before-restore | killed | 1 | TestJointCommitCompensatesBumpFailure |
