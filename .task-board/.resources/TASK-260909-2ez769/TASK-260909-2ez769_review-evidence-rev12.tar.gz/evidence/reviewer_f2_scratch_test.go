package hosttrust

// Reviewer scratch probes (NOT committed): own fault injection distinct from
// the producer's index-rename failure, the reverse-ordering crash consequence,
// and a target-side refusal naming a different store.
import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// failTargetBindingRenameFS crashes before the AUTHORITATIVE target sidecar
// is durable (the producer injects at the derived store index instead).
type failTargetBindingRenameFS struct {
	FileSystem
}

func (filesystem failTargetBindingRenameFS) Rename(oldname, newname string) error {
	if strings.HasSuffix(newname, configBindingTargetSuffix) {
		return errors.New("reviewer injected target binding rename failure")
	}
	return filesystem.FileSystem.Rename(oldname, newname)
}

func TestReviewerTargetWriteCrashLeavesNoPartialBinding(t *testing.T) {
	directory := t.TempDir()
	configPath := filepath.Join(directory, "config.toml")
	if err := os.WriteFile(configPath, []byte("source"), 0o600); err != nil {
		t.Fatal(err)
	}
	state := filepath.Join(directory, "state")
	paths := resolvedPathsForTest(t, configPath, state)
	store := openPathsForTest(t, configPath, state)
	store.fs = failTargetBindingRenameFS{FileSystem: store.fs}
	if err := store.EnsureConfigBinding(paths); !errors.Is(err, ErrTrustDurability) {
		t.Fatalf("EnsureConfigBinding(target crash) = %v, want durability error", err)
	}
	canonical, err := canonicalExistingPath(configPath)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := os.Lstat(configBindingPath(canonical)); !os.IsNotExist(err) {
		t.Fatalf("target sidecar after target crash = %v, want absent", err)
	}
	if _, err := os.Lstat(bindingPath(store.Root())); !os.IsNotExist(err) {
		t.Fatalf("store index after target crash = %v, want absent", err)
	}
	store.fs = osFileSystem{}
	if err := store.EnsureConfigBinding(paths); err != nil {
		t.Fatalf("EnsureConfigBinding retry after target crash = %v, want success", err)
	}
}

func TestReviewerIndexWithoutSidecarIsRefusedClosed(t *testing.T) {
	directory := t.TempDir()
	configPath := filepath.Join(directory, "config.toml")
	if err := os.WriteFile(configPath, []byte("source"), 0o600); err != nil {
		t.Fatal(err)
	}
	state := filepath.Join(directory, "state")
	paths := resolvedPathsForTest(t, configPath, state)
	store := openPathsForTest(t, configPath, state)
	if err := store.EnsureConfigBinding(paths); err != nil {
		t.Fatal(err)
	}
	// Simulate the reverse-ordering crash: derived index durable, authority lost.
	canonical, err := canonicalExistingPath(configPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.Remove(configBindingPath(canonical)); err != nil {
		t.Fatal(err)
	}
	// The incoherent state is refused already at Open: a derived index
	// without its authoritative target record can never be used.
	reopened, err := Open(paths)
	if err == nil {
		if err := reopened.EnsureConfigBinding(paths); !errors.Is(err, ErrExclusiveHoldResourceMismatch) {
			t.Fatalf("EnsureConfigBinding(stranded index) = %v, want resource mismatch", err)
		}
	} else if !errors.Is(err, ErrExclusiveHoldResourceMismatch) {
		t.Fatalf("Open with stranded index = %v, want resource mismatch", err)
	} else {
		t.Logf("stranded index refused at Open: %v", err)
	}
	bound, present, err := loadStoreConfigBinding(osFileSystem{}, store.Root())
	if err != nil || !present {
		t.Fatalf("stranded index after refused repair = %#v (present=%v, err=%v), want intact", bound, present, err)
	}
}

func TestReviewerTargetBoundElsewhereRefusesNewStore(t *testing.T) {
	directory := t.TempDir()
	configPath := filepath.Join(directory, "config.toml")
	if err := os.WriteFile(configPath, []byte("source"), 0o600); err != nil {
		t.Fatal(err)
	}
	state1 := filepath.Join(directory, "state-1")
	state2 := filepath.Join(directory, "state-2")
	store1 := openPathsForTest(t, configPath, state1)
	if err := store1.EnsureConfigBinding(resolvedPathsForTest(t, configPath, state1)); err != nil {
		t.Fatal(err)
	}
	store2 := openPathsForTest(t, configPath, state2)
	if err := store2.EnsureConfigBinding(resolvedPathsForTest(t, configPath, state2)); !errors.Is(err, ErrExclusiveHoldResourceMismatch) {
		t.Fatalf("EnsureConfigBinding(bound elsewhere) = %v, want resource mismatch", err)
	}
	if _, err := os.Lstat(bindingPath(store2.Root())); !os.IsNotExist(err) {
		t.Fatalf("second store index after refusal = %v, want absent", err)
	}
	canonical, err := canonicalExistingPath(configPath)
	if err != nil {
		t.Fatal(err)
	}
	bound, present, err := loadTargetConfigBinding(osFileSystem{}, canonical)
	if err != nil || !present {
		t.Fatalf("target sidecar after refused second store = %#v (present=%v, err=%v)", bound, present, err)
	}
	if bound.StateRoot != mustCanonicalPathForTest(t, state1) {
		t.Fatalf("target sidecar now names %q, want %q", bound.StateRoot, mustCanonicalPathForTest(t, state1))
	}
}
