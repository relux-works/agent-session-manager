#!/usr/bin/env python3
"""Reviewer mutation-battery runner: identical semantics to the producer
harnesses, except overlay.json keys use the UNRESOLVED repo path so go's
-overlay matching takes effect on macOS (/tmp -> /private/tmp).

Usage: runbatt.py <config|hosttrust|own> --output DIR [--only a,b]
"""
import argparse
import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path

REPO = Path("/Users/iv/rev12work/candidate")
OUT = None


def load_probes(module_path, extra=()):
    spec = importlib.util.spec_from_file_location("harness", module_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return list(mod.PROBES) + list(extra), mod.TESTS if hasattr(mod, "TESTS") else "Test"


OWN = [
    ("reviewer-expiry-grace-1s", "internal/hosttrust/profile_verify.go", None, None,
     "Admits exactly credentials expired by at most one second", "TestVerifyProfileRefusesJustPastExpiry"),
]


def main():
    global OUT
    ap = argparse.ArgumentParser()
    ap.add_argument("suite", choices=["config", "hosttrust"])
    ap.add_argument("--output", required=True)
    ap.add_argument("--only", default=None)
    args = ap.parse_args()
    OUT = Path(args.output)
    OUT.mkdir(parents=True, exist_ok=True)
    harness = REPO / ("internal/config/mutations_v4.py" if args.suite == "config"
                      else "internal/hosttrust/mutations.py")
    probes, tests = load_probes(str(harness))
    only = set(args.only.split(",")) if args.only else None
    results = []
    unexpected = False
    for name, rel, old, new, narrows, expected in probes:
        if only and name not in only:
            continue
        source = REPO / rel
        original = source.read_bytes()
        text = original.decode()
        if text.count(old) != 1:
            raise RuntimeError(f"{name}: plant must match exactly once, got {text.count(old)}")
        folder = OUT / name
        folder.mkdir(exist_ok=True)
        replacement = folder / source.name
        replacement.write_text(text.replace(old, new, 1))
        # UNRESOLVED keys: no .resolve() on either side.
        overlay = folder / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
        pkg = "./internal/config" if args.suite == "config" else "./internal/hosttrust"
        cmd = ["go", "test", "-overlay", str(overlay), pkg, "-count=1", "-json", "-timeout=300s", "-run", tests]
        env = os.environ.copy()
        env["CENSUS_MUTATION_OVERLAY"] = str(overlay)
        proc = subprocess.run(cmd, cwd=str(REPO), env=env,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
        (folder / "test.log").write_bytes(proc.stdout)
        failed, passed = [], []
        for line in proc.stdout.decode(errors="replace").splitlines():
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "Test" in e:
                if e.get("Action") == "fail":
                    failed.append(e["Test"])
                elif e.get("Action") == "pass":
                    passed.append(e["Test"])
        killed = proc.returncode != 0 and bool(failed) and (expected is None or expected in failed)
        if name == "neutral":
            valid = proc.returncode == 0 and bool(passed)
            state = "neutral passed" if valid else "invalid control"
        else:
            valid = killed
            state = ("killed" if killed else "survived"
                     if proc.returncode == 0 and passed else "invalid instrument/compile failure")
        if not valid:
            unexpected = True
        if source.read_bytes() != original:
            raise RuntimeError(f"{name}: source changed during overlay run")
        results.append({"mutant": name, "narrowing": narrows, "exit_code": proc.returncode,
                        "result": state, "named_failing_tests": sorted(set(failed)),
                        "expected_test": expected})
        print(f"{name}: {state}, exit={proc.returncode}, failed={','.join(sorted(set(failed))[:3])}", flush=True)
        (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    (OUT / "table.md").write_text("\n".join(
        ["| Mutant | Result | Exit | Expected killer |", "| --- | --- | ---: | --- |"] +
        [f"| {r['mutant']} | {r['result']} | {r['exit_code']} | {r['expected_test']} |" for r in results]) + "\n")
    return int(unexpected)


if __name__ == "__main__":
    sys.exit(main())
