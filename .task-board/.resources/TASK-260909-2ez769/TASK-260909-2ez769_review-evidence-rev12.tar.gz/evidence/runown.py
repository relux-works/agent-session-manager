#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants on arms neither harness mutates."""
import json
import os
import subprocess
import sys
from pathlib import Path

REPO = Path("/Users/iv/rev12work/candidate")
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/Users/iv/rev12work/rb-own")

PROBES = [
    ("reviewer-trust-version-downgrade", "internal/hosttrust/trust.go",
     'if version != TrustSchemaVersion {',
     'if version != TrustSchemaVersion && version != "0.9.0" {',
     "Admits exactly the 0.9.0 downgraded document; every other version refusal stands",
     "TestDecodeTrustRefusals", "./internal/hosttrust"),
    ("reviewer-credential-format-leak", "internal/hosttrust/trust.go",
     'func (CredentialEntry) Format(state fmt.State, verb rune) {\n\t_, _ = state.Write([]byte("host trust credential entry"))\n}',
     'func (entry CredentialEntry) Format(state fmt.State, verb rune) {\n\t_, _ = state.Write([]byte("host trust credential entry " + entry.CredentialID.String()))\n}',
     "Emits exactly the credential ID through the redacted formatter; key material still withheld",
     "TestTrustRedaction", "./internal/hosttrust"),
    ("reviewer-exclusion-prerollback-skip", "internal/hosttrust/export.go",
     '\tif strings.Contains(name, ".pre-rollback.") {\n\t\treturn true\n\t}\n',
     '',
     "Admits exactly pre-rollback copies into replication; all other excluded names stand",
     "TestExcludedConfigDirName", "./internal/hosttrust"),
]

OUT.mkdir(parents=True, exist_ok=True)
results = []
unexpected = False
for name, rel, old, new, narrows, expected, pkg in PROBES:
    source = REPO / rel
    original = source.read_bytes()
    text = original.decode()
    assert text.count(old) == 1, f"{name}: match count {text.count(old)}"
    folder = OUT / name
    folder.mkdir(exist_ok=True)
    (folder / source.name).write_text(text.replace(old, new, 1))
    overlay = folder / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {str(source): str(folder / source.name)}}))
    cmd = ["go", "test", "-overlay", str(overlay), pkg, "-count=1", "-json", "-timeout=300s", "-run", "Test"]
    env = os.environ.copy()
    proc = subprocess.run(cmd, cwd=str(REPO), env=env,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
    (folder / "test.log").write_bytes(proc.stdout)
    failed = set()
    for line in proc.stdout.decode(errors="replace").splitlines():
        try:
            e = json.loads(line)
        except json.JSONDecodeError:
            continue
        if e.get("Action") == "fail" and "Test" in e:
            failed.add(e["Test"])
    killed = proc.returncode != 0 and bool(failed) and expected in failed
    state = "killed" if killed else ("survived" if proc.returncode == 0 else "invalid")
    if not killed:
        unexpected = True
    assert source.read_bytes() == original, f"{name}: source changed"
    results.append({"mutant": name, "result": state, "exit_code": proc.returncode,
                    "expected_test": expected, "failed": sorted(failed)})
    print(f"{name}: {state}, exit={proc.returncode}, failed={sorted(failed)[:4]}", flush=True)
(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
sys.exit(int(unexpected))
