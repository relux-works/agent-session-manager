from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parent
candidate=root/'candidate'
shapes={
 'direct_control': 'import "os"\nfunc reviewerRogue(path string, data []byte) error { return os.WriteFile(path,data,0600) }',
 'map_function_value': 'import "os"\nvar reviewerWriters = map[string]func(string, []byte, os.FileMode)error{"write":os.WriteFile}\nfunc reviewerRogue(path string, data []byte) error {return reviewerWriters["write"](path,data,0600)}',
 'alias_import': 'import fs "os"\nfunc reviewerRogue(path string,data []byte)error {return fs.WriteFile(path,data,0600)}',
 'returned_closure_initializer': 'import "os"\nvar reviewerRogue = func() func(string,[]byte)error { return func(path string,data []byte)error {return os.WriteFile(path,data,0600)} }()',
 'backend_method_value': 'var reviewerRename = osMigrationFileSystem{}.Rename\nfunc reviewerRogue(path string,data []byte)error{return reviewerRename(path+".replacement",path)}',
}
witness='''package config
import("testing";"os";"path/filepath")
func TestReviewerRoguePlantExecutes(t *testing.T){
p:=filepath.Join(t.TempDir(),"config.toml")
if e:=os.WriteFile(p,[]byte("old"),0600);e!=nil{t.Fatal(e)}
if e:=os.WriteFile(p+".replacement",[]byte("new"),0600);e!=nil{t.Fatal(e)}
if e:=reviewerRogue(p,[]byte("new"));e!=nil{t.Fatal(e)}
b,e:=os.ReadFile(p);if e!=nil||string(b)!="new"{t.Fatalf("witness %s %v",b,e)}
t.Log("production-position rogue replaced real configuration bytes without a hold")
}
'''
prod=candidate/'internal/config/reviewer_rogue.go'
test=candidate/'internal/config/reviewer_rogue_test.go'
results=[]
try:
 for name,body in shapes.items():
  folder=root/'census-plants'/name;folder.mkdir(parents=True,exist_ok=True)
  prod.write_text('package config\n'+body+'\n');test.write_text(witness)
  (folder/prod.name).write_bytes(prod.read_bytes());(folder/test.name).write_text(witness)
  p=subprocess.run(['go','test','./internal/config','-count=1','-v','-run','^(TestWritePathCensusGate|TestReviewerRoguePlantExecutes)$'],cwd=candidate,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (folder/'test.log').write_bytes(p.stdout)
  results.append({'plant':name,'exit':p.returncode,'witness_pass':b'--- PASS: TestReviewerRoguePlantExecutes' in p.stdout,'gate_pass':b'--- PASS: TestWritePathCensusGate' in p.stdout})
finally:
 prod.unlink(missing_ok=True);test.unlink(missing_ok=True)
(root/'census-results.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
