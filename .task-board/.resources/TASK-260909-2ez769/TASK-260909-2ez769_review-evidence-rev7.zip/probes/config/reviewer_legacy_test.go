package config

import (
 "os"
 "testing"
)

type reviewerLegacyFS struct {
 osMigrationFileSystem
 fixture *v4Fixture
 t *testing.T
 admitted uint64
}
func (f *reviewerLegacyFS) Rename(from, to string) error {
 if to == f.fixture.filename && f.admitted == 0 {
  if _, err := Migrate(f.fixture.inputs, nil, MigrationOptions{TargetVersion: CurrentVersion}); err != nil { f.t.Fatal(err) }
  preview, err := PreviewV4(f.fixture.inputs, nil, f.fixture.trust(f.t), f.fixture.self, nil, f.fixture.now)
  if err != nil { f.t.Fatal(err) }
  if _, err := ApplyV4(f.fixture.inputs, nil, preview, true, f.fixture.now); err != nil { f.t.Fatal(err) }
  snapshot, err := LoadCoherent(f.fixture.inputs, nil, f.fixture.store)
  if err != nil { f.t.Fatal(err) }
  loaded, ok := snapshot.Config.Configuration()
  if !ok || loaded.SourceVersion != Version4 { f.t.Fatal("concurrent writer did not install Config4") }
  f.admitted = snapshot.Generation
 }
 return f.osMigrationFileSystem.Rename(from, to)
}
func TestReviewerLegacyCannotOverwriteCommittedV4(t *testing.T) {
 fixture := setupV4Fixture(t, testPeerID)
 snapshot, err := Load(fixture.inputs, nil)
 if err != nil { t.Fatal(err) }
 loaded, _ := snapshot.Configuration()
 v2, err := encodeVersion2(loaded.Value, DecodeContext{RuntimePlatform:fixture.inputs.Platform})
 if err != nil { t.Fatal(err) }
 if err := os.WriteFile(fixture.filename, v2, 0600); err != nil { t.Fatal(err) }
 fs := &reviewerLegacyFS{fixture:fixture,t:t}
 result, err := migrate(fixture.inputs,nil,MigrationOptions{TargetVersion:CurrentVersion},fs)
 t.Logf("delayed legacy migrate: changed=%v err=%v", result.Changed,err)
 after, err := LoadCoherent(fixture.inputs,nil,fixture.store)
 if err != nil { return } // a fail-closed refusal is safe
 final, ok := after.Config.Configuration()
 if !ok { t.Fatal("missing final configuration") }
 if fs.admitted == 0 { t.Fatal("race seam not reached") }
 if final.SourceVersion != Version4 && after.Generation == fs.admitted {
  t.Fatalf("legacy migration silently overwrote admitted Config4 with %s at unchanged generation %d",final.SourceVersion,after.Generation)
 }
}
