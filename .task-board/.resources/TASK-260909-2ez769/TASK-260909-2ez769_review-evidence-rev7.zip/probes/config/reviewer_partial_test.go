package config
import("errors";"testing";"os";"github.com/relux-works/agent-session-manager/internal/hosttrust")
type reviewerPartialFS struct { osMigrationFileSystem; filename string; renames int }
func (f *reviewerPartialFS) Rename(from,to string) error {
 if to==f.filename {f.renames++;if f.renames==2{return errors.New("injected rollback rename failure")}}
 return f.osMigrationFileSystem.Rename(from,to)
}
func (f *reviewerPartialFS) OpenDirectory(path string)(migrationDirectory,error) {
 if f.renames==1 {return nil,errors.New("injected post-replacement directory open failure")}
 return f.osMigrationFileSystem.OpenDirectory(path)
}
func TestReviewerFailedReplacementCannotLoseIntent(t *testing.T) {
 fixture:=setupV4Fixture(t,testPeerID)
 before:=fixture.trust(t).Generation
 preview,err:=PreviewV4(fixture.inputs,nil,fixture.trust(t),fixture.self,nil,fixture.now)
 if err!=nil{t.Fatal(err)}
 fs:=&reviewerPartialFS{filename:fixture.filename}
 _,err=applyV4(fixture.inputs,nil,preview,true,fixture.now,fs,hosttrust.Open)
 if !errors.Is(err,ErrMigrationRecovery){t.Fatalf("expected rollback failure, got %v",err)}
 _,markerErr:=os.Stat(fixture.store.PendingCommitPath())
 t.Logf("apply error=%v; marker inspection=%v",err,markerErr)
 after,err:=LoadCoherent(fixture.inputs,nil,fixture.store)
 if err!=nil{return}
 loaded,ok:=after.Config.Configuration();if !ok{t.Fatal("missing config")}
 if loaded.SourceVersion==Version4 && after.Generation==before {
  t.Fatalf("failed replacement discarded intent and admitted Config4 at old generation %d",before)
 }
}
func TestReviewerFailedRollbackCannotLoseIntent(t *testing.T) {
 fixture:=setupV4Fixture(t,testPeerID)
 preview,err:=PreviewV4(fixture.inputs,nil,fixture.trust(t),fixture.self,nil,fixture.now)
 if err!=nil{t.Fatal(err)}
 if _,err=ApplyV4(fixture.inputs,nil,preview,true,fixture.now);err!=nil{t.Fatal(err)}
 before:=fixture.trust(t).Generation
 fs:=&reviewerPartialFS{filename:fixture.filename}
 _,err=rollbackV4(fixture.inputs,nil,RollbackV4Options{AcknowledgeNoHostChannelAssurance:true,BackupPath:fixture.filename+".bak."+CurrentVersion},fs,hosttrust.Open)
 if !errors.Is(err,ErrMigrationRecovery){t.Fatalf("expected rollback recovery failure, got %v",err)}
 after,err:=LoadCoherent(fixture.inputs,nil,fixture.store)
 if err!=nil{return}
 loaded,ok:=after.Config.Configuration();if !ok{t.Fatal("missing config")}
 if loaded.SourceVersion==CurrentVersion && after.Generation==before {
  t.Fatalf("failed rollback discarded intent and admitted Config3 at old generation %d",before)
 }
}
