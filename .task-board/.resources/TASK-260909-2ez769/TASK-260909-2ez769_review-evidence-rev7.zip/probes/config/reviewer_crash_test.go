package config

import (
 "os"
 "os/exec"
 "path/filepath"
 "testing"
 "time"
 "github.com/relux-works/agent-session-manager/internal/hosttrust"
 "github.com/relux-works/agent-session-manager/internal/scalar"
)

type reviewerCrashFS struct {osMigrationFileSystem; target string}
func (f reviewerCrashFS) Rename(from,to string) error {
 if err:=f.osMigrationFileSystem.Rename(from,to);err!=nil{return err}
 if to==f.target {os.Exit(77)}
 return nil
}
func TestReviewerCrashBetweenConfigAndGeneration(t *testing.T) {
 if dir:=os.Getenv("AX_REVIEW_CRASH_FIXTURE");dir!="" {
  filename:=filepath.Join(dir,"config.toml")
  state:=filepath.Join(dir,"state")
  inputs:=Inputs{Platform:scalar.PlatformMacOS,HomeDir:dir,TempDir:dir,WorkingDir:dir,Stat:os.Stat,ReadFile:os.ReadFile,LookupEnv:func(k string)(string,bool){if k=="AX_CONFIG"{return filename,true};if k=="AX_STATE_DIR"{return state,true};return "",false}}
  store,err:=hosttrust.Open(state);if err!=nil{t.Fatal(err)}
  snap,err:=store.ReadSnapshot();if err!=nil{t.Fatal(err)}
  self:="";for _,e:=range snap.Trust.Entries{if e.HostID.String()==testHostID{self=e.CredentialID.String()}}
  now:=time.Now().UTC()
  preview,err:=PreviewV4(inputs,nil,snap,self,nil,now);if err!=nil{t.Fatal(err)}
  _,err=applyV4(inputs,nil,preview,true,now,reviewerCrashFS{target:filename},hosttrust.Open)
  t.Fatalf("crash seam not reached: %v",err)
 }
 fixture:=setupV4Fixture(t,testPeerID)
 before:=fixture.trust(t).Generation
 command:=exec.Command(os.Args[0],"-test.run=^TestReviewerCrashBetweenConfigAndGeneration$")
 command.Env=append(os.Environ(),"AX_REVIEW_CRASH_FIXTURE="+fixture.directory)
 output,err:=command.CombinedOutput()
 exit,ok:=err.(*exec.ExitError);if !ok||exit.ExitCode()!=77{t.Fatalf("child did not crash at seam: %v %s",err,output)}
 coherent,err:=LoadCoherent(fixture.inputs,nil,fixture.store)
 if err==nil && coherent.Generation==before { t.Fatalf("surviving Store admits new config with old generation %d",before) }
 loaded,err:=Load(fixture.inputs,nil);if err!=nil{t.Fatal(err)}
 configuration,ok:=loaded.Configuration();if !ok{t.Fatal("missing configuration")}
 reopened,err:=hosttrust.Open(fixture.stateDir);if err!=nil{t.Fatal(err)}
 snap,err:=reopened.ReadSnapshot();if err!=nil{t.Fatal(err)}
 if configuration.SourceVersion==Version4 && snap.Generation==before {t.Fatalf("restart admits new Config4 with old generation %d after child exit 77",before)}
}

func TestReviewerCrashReopenConverges(t *testing.T) {
 if dir:=os.Getenv("AX_REVIEW_REOPEN_FIXTURE");dir!="" {
  filename:=filepath.Join(dir,"config.toml")
  state:=filepath.Join(dir,"state")
  inputs:=Inputs{Platform:scalar.PlatformMacOS,HomeDir:dir,TempDir:dir,WorkingDir:dir,Stat:os.Stat,ReadFile:os.ReadFile,LookupEnv:func(k string)(string,bool){if k=="AX_CONFIG"{return filename,true};if k=="AX_STATE_DIR"{return state,true};return "",false}}
  store,err:=hosttrust.Open(state);if err!=nil{t.Fatal(err)}
  snap,err:=store.ReadSnapshot();if err!=nil{t.Fatal(err)}
  self:="";for _,e:=range snap.Trust.Entries{if e.HostID.String()==testHostID{self=e.CredentialID.String()}}
  now:=time.Now().UTC()
  preview,err:=PreviewV4(inputs,nil,snap,self,nil,now);if err!=nil{t.Fatal(err)}
  _,err=applyV4(inputs,nil,preview,true,now,reviewerCrashFS{target:filename},hosttrust.Open)
  t.Fatalf("crash seam not reached: %v",err)
 }
 fixture:=setupV4Fixture(t,testPeerID)
 before:=fixture.trust(t).Generation
 command:=exec.Command(os.Args[0],"-test.run=^TestReviewerCrashReopenConverges$")
 command.Env=append(os.Environ(),"AX_REVIEW_REOPEN_FIXTURE="+fixture.directory)
 output,err:=command.CombinedOutput()
 exit,ok:=err.(*exec.ExitError);if !ok||exit.ExitCode()!=77{t.Fatalf("child did not crash at seam: %v %s",err,output)}
 loaded,err:=Load(fixture.inputs,nil);if err!=nil{t.Fatal(err)}
 configuration,ok:=loaded.Configuration();if !ok{t.Fatal("missing config")}
 reopened,err:=hosttrust.Open(fixture.stateDir);if err!=nil{t.Fatal(err)}
 snap,err:=reopened.ReadSnapshot();if err!=nil{t.Fatal(err)}
 if configuration.SourceVersion==Version4 && snap.Generation==before {t.Fatalf("restart admits new Config4 with old generation %d after child exit 77",before)}
}

func TestReviewerRollbackCrashSurvivingReader(t *testing.T) {
 if dir:=os.Getenv("AX_REVIEW_ROLLBACK_FIXTURE");dir!="" {
  filename:=filepath.Join(dir,"config.toml")
  state:=filepath.Join(dir,"state")
  inputs:=Inputs{Platform:scalar.PlatformMacOS,HomeDir:dir,TempDir:dir,WorkingDir:dir,Stat:os.Stat,ReadFile:os.ReadFile,LookupEnv:func(k string)(string,bool){if k=="AX_CONFIG"{return filename,true};if k=="AX_STATE_DIR"{return state,true};return "",false}}
  store,err:=hosttrust.Open(state);if err!=nil{t.Fatal(err)}
  snap,err:=store.ReadSnapshot();if err!=nil{t.Fatal(err)}
  _ = snap
  _,err=rollbackV4(inputs,nil,RollbackV4Options{AcknowledgeNoHostChannelAssurance:true},reviewerCrashFS{target:filename},hosttrust.Open)
  t.Fatalf("crash seam not reached: %v",err)
 }
 fixture:=setupV4Fixture(t,testPeerID)
 preview,err:=PreviewV4(fixture.inputs,nil,fixture.trust(t),fixture.self,nil,fixture.now);if err!=nil{t.Fatal(err)}
 if _,err:=ApplyV4(fixture.inputs,nil,preview,true,fixture.now);err!=nil{t.Fatal(err)}
 before:=fixture.trust(t).Generation
 command:=exec.Command(os.Args[0],"-test.run=^TestReviewerRollbackCrashSurvivingReader$")
 command.Env=append(os.Environ(),"AX_REVIEW_ROLLBACK_FIXTURE="+fixture.directory)
 output,err:=command.CombinedOutput()
 exit,ok:=err.(*exec.ExitError);if !ok||exit.ExitCode()!=77{t.Fatalf("child did not crash at seam: %v %s",err,output)}
 coherent,err:=LoadCoherent(fixture.inputs,nil,fixture.store)
 if err==nil && coherent.Generation==before { t.Fatalf("surviving Store admits new config with old generation %d",before) }
 loaded,err:=Load(fixture.inputs,nil);if err!=nil{t.Fatal(err)}
 configuration,ok:=loaded.Configuration();if !ok{t.Fatal("missing configuration")}
 reopened,err:=hosttrust.Open(fixture.stateDir);if err!=nil{t.Fatal(err)}
 snap,err:=reopened.ReadSnapshot();if err!=nil{t.Fatal(err)}
 if configuration.SourceVersion==Version4 && snap.Generation==before {t.Fatalf("restart admits new Config4 with old generation %d after child exit 77",before)}
}

