package config
import (
 "bytes"
 "errors"
 "os"
 "testing"
 "time"
 "github.com/relux-works/agent-session-manager/internal/hosttrust"
)
type reviewerFailedRestoreRaceFS struct {
 osMigrationFileSystem
 filename string
 renames int
 entered chan struct{}
 resume chan struct{}
}
func(f *reviewerFailedRestoreRaceFS)Rename(from,to string)error{
 if to==f.filename{
  f.renames++
  if f.renames==2{return errors.New("internal recovery rename fails")}
  if f.renames==3{close(f.entered);<-f.resume}
 }
 return f.osMigrationFileSystem.Rename(from,to)
}
func(f *reviewerFailedRestoreRaceFS)OpenDirectory(path string)(migrationDirectory,error){
 if f.renames==1{return nil,errors.New("post-rename sync fails")}
 return f.osMigrationFileSystem.OpenDirectory(path)
}
func TestReviewerFailedReplaceRestoreSerializesReader(t *testing.T){
 for _,rollback:=range []bool{false,true}{
  name:="apply";if rollback{name="rollback"}
  t.Run(name,func(t *testing.T){
   f:=setupV4Fixture(t,testPeerID)
   preview,err:=PreviewV4(f.inputs,nil,f.trust(t),f.self,nil,f.now);if err!=nil{t.Fatal(err)}
   if rollback{if _,err=ApplyV4(f.inputs,nil,preview,true,f.now);err!=nil{t.Fatal(err)}}
   before:=f.trust(t).Generation
   source,err:=os.ReadFile(f.filename);if err!=nil{t.Fatal(err)}
   fs:=&reviewerFailedRestoreRaceFS{filename:f.filename,entered:make(chan struct{}),resume:make(chan struct{})}
   done:=make(chan error,1)
   go func(){
    if rollback{_,e:=rollbackV4(f.inputs,nil,RollbackV4Options{AcknowledgeNoHostChannelAssurance:true},fs,hosttrust.Open);done<-e
    }else{_,e:=applyV4(f.inputs,nil,preview,true,f.now,fs,hosttrust.Open);done<-e}
   }()
   select{case <-fs.entered:case e:=<-done:t.Fatalf("missed seam %v",e);case <-time.After(5*time.Second):t.Fatal("seam timeout")}
   type answer struct{s CoherentSnapshot;e error}
   read:=make(chan answer,1)
   go func(){s,e:=LoadCoherent(f.inputs,nil,f.store);read<-answer{s,e}}()
   select{case a:=<-read:close(fs.resume);<-done;t.Fatalf("reader crossed held compensation: %+v",a);case <-time.After(250*time.Millisecond):}
   close(fs.resume)
   if e:=<-done;e==nil{t.Fatal("faulted replace reported success")}
   a:=<-read;if a.e!=nil{t.Fatal(a.e)}
   if a.s.Generation!=before||!bytes.Equal(a.s.Config.Document(),source){t.Fatalf("reader did not observe clean abort: generation %d want %d",a.s.Generation,before)}
   reopened,e:=hosttrust.Open(f.stateDir);if e!=nil{t.Fatal(e)}
   s,e:=LoadCoherent(f.inputs,nil,reopened);if e!=nil{t.Fatal(e)}
   if s.Generation!=before||!bytes.Equal(s.Config.Document(),source){t.Fatal("reopen did not preserve clean abort")}
   if _,e:=os.Stat(f.store.PendingCommitPath());!os.IsNotExist(e){t.Fatalf("marker not removed after clean abort: %v",e)}
  })
 }
}
