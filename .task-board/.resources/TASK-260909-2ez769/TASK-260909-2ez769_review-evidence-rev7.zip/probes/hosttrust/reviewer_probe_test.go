package hosttrust

import (
 "testing"
 "path/filepath"
 "time"
)

func TestReviewerStaleMutation(t *testing.T) {
 local, peer, lc, pc, snap, _ := twoHostFixture(t)
 leaf, root := peerMaterialForTest(t, peer, pc)
 req := dispatchRequest(snap, lc, pc, testHostB, leaf, root, []string{testHostA,testHostB}, testNow)
 if _, err := local.Issue(testHostC, testNow); err != nil {t.Fatal(err)}
 called := false
 err := local.WithMutationAuthorization(req, func() error{called=true; return nil})
 if err == nil || called {t.Fatalf("stale generation admitted: err=%v boundary=%v",err,called)}
}

func TestReviewerRevocationDuringBoundary(t *testing.T) {
 local, peer, lc, pc, snap, _ := twoHostFixture(t)
 leaf, root := peerMaterialForTest(t, peer, pc)
 req := dispatchRequest(snap, lc, pc, testHostB, leaf, root, []string{testHostA,testHostB}, testNow)
 entered, release := make(chan struct{}), make(chan struct{})
 boundaryDone := make(chan error,1)
 go func(){boundaryDone <- local.WithMutationAuthorization(req,func() error{close(entered); <-release; return nil})}()
 <-entered
 revoked := make(chan error,1)
 go func(){revoked <- local.Revoke(pc)}()
 var early bool
 var revokeErr error
 select {case revokeErr= <-revoked: early=true; case <-time.After(250*time.Millisecond):}
 close(release)
 if err:= <-boundaryDone;err!=nil{t.Fatal(err)}
 if !early {revokeErr= <-revoked}
 if revokeErr !=nil {t.Fatal(revokeErr)}
 if early {t.Fatal("revocation reported success while mutation boundary still held prior authorization")}
}

func TestReviewerSeparateStoreRevocationDuringBoundary(t *testing.T) {
 local, peer, lc, pc, snap, _ := twoHostFixture(t)
 leaf, root := peerMaterialForTest(t, peer, pc)
 req := dispatchRequest(snap, lc, pc, testHostB, leaf, root, []string{testHostA,testHostB}, testNow)
 other,err:=Open(filepath.Dir(local.Root()));if err!=nil{t.Fatal(err)}
 entered, release := make(chan struct{}), make(chan struct{})
 boundaryDone := make(chan error,1)
 go func(){boundaryDone <- local.WithMutationAuthorization(req,func() error{close(entered); <-release; return nil})}()
 <-entered
 revoked := make(chan error,1)
 go func(){revoked <- other.Revoke(pc)}()
 var early bool
 var revokeErr error
 select {case revokeErr= <-revoked: early=true; case <-time.After(250*time.Millisecond):}
 close(release)
 if err:= <-boundaryDone;err!=nil{t.Fatal(err)}
 if !early {revokeErr= <-revoked}
 if revokeErr !=nil {t.Fatal(revokeErr)}
 if early {t.Fatal("revocation reported success while mutation boundary still held prior authorization")}
}
