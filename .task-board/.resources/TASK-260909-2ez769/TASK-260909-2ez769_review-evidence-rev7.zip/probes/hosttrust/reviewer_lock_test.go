package hosttrust

import (
 "io/fs"
 "os"
 "os/exec"
 "path/filepath"
 "testing"
 "time"
)

type reviewerInitFS struct { osFileSystem; dir string }
func (f reviewerInitFS) Lstat(path string)(fs.FileInfo,error){
 info,err:=f.osFileSystem.Lstat(path)
 if filepath.Base(path)==lockFileName && os.IsNotExist(err){
  if e:=os.WriteFile(filepath.Join(f.dir,"observed"),[]byte("ready"),0600);e!=nil{panic(e)}
  deadline:=time.Now().Add(5*time.Second)
  for {if _,e:=os.Stat(filepath.Join(f.dir,"continue"));e==nil{break}; if time.Now().After(deadline){panic("barrier timed out")};time.Sleep(5*time.Millisecond)}
 }
 return info,err
}
func TestReviewerCrossProcessLockInitialization(t *testing.T){
 if dir:=os.Getenv("AX_REVIEW_LOCK_INIT");dir!="" {
  if _,err:=openStore(dir,reviewerInitFS{dir:dir});err!=nil{t.Fatal(err)}
  return
 }
 dir:=t.TempDir()
 cmd:=exec.Command(os.Args[0],"-test.run=^TestReviewerCrossProcessLockInitialization$","-test.timeout=10s")
 cmd.Env=append(os.Environ(),"AX_REVIEW_LOCK_INIT="+dir)
 if err:=cmd.Start();err!=nil{t.Fatal(err)}
 defer func(){_ = cmd.Process.Kill()}()
 deadline:=time.Now().Add(5*time.Second)
 for {if _,err:=os.Stat(filepath.Join(dir,"observed"));err==nil{break};if time.Now().After(deadline){t.Fatal("child did not reach absent-lock barrier")};time.Sleep(5*time.Millisecond)}
 store,err:=Open(dir);if err!=nil{t.Fatal(err)}
 if _,err:=store.Initialize();err!=nil{t.Fatal(err)}
 release,err:=store.lock.exclusive();if err!=nil{t.Fatal(err)}
 old,err:=os.Stat(store.lock.path);if err!=nil{t.Fatal(err)}
 if err:=os.WriteFile(filepath.Join(dir,"continue"),[]byte("go"),0600);err!=nil{t.Fatal(err)}
 done:=make(chan error,1);go func(){done<-cmd.Wait()}()
 var early bool
 select{case err= <-done:early=true;case <-time.After(300*time.Millisecond):}
 release()
 if !early{err= <-done}
 if err!=nil{t.Fatal(err)}
 fresh,err:=os.Stat(store.lock.path);if err!=nil{t.Fatal(err)}
 if early || !os.SameFile(old,fresh){t.Fatalf("concurrent Open replaced held authorization lock: returnedWhileHeld=%v sameInode=%v",early,os.SameFile(old,fresh))}
}
