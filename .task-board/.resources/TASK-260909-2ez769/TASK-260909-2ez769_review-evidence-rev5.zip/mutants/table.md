| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent generation increment | none | 0 | neutral passed: Equivalent arithmetic; no independent kill claimed. |
| dance-converge-ignore | Admits exactly the refused-recovery class into converged reads | TestReadSnapshotRefusesIntervention | 1 | killed:  |
| recover-forward-no-bump | Completes forward without the generation bump, admitting replaced configuration with the old generation | TestReadSnapshotConvergesInterruptedApply | 1 | killed:  |
| lock-replacing-init | Publishes the lock with a replacing rename, admitting the concurrent first-open race | TestFirstOpenPreservesHeldLock | 1 | killed:  |
