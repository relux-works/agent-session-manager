package config
import("os";"testing";"github.com/relux-works/agent-session-manager/internal/hosttrust")
type reviewerRestoreFS struct {osMigrationFileSystem; fixture *v4Fixture; t *testing.T; renames int; admittedGeneration uint64}
func(f *reviewerRestoreFS) Rename(from,to string) error {
 if to != f.fixture.filename {return f.osMigrationFileSystem.Rename(from,to)}
 f.renames++
 if f.renames==2 {
  if err:=os.Chmod(f.fixture.store.TrustPath(),0600);err!=nil{return err}
  coherent,err:=LoadCoherent(f.fixture.inputs,nil,f.fixture.store)
  if err!=nil {f.t.Fatalf("surviving read: %v",err)}
  loaded,ok:=coherent.Config.Configuration()
  if !ok || loaded.SourceVersion!=Version4 {f.t.Fatal("reader did not admit Config4")}
  f.admittedGeneration=coherent.Generation
 }
 if err:=f.osMigrationFileSystem.Rename(from,to);err!=nil{return err}
 if f.renames==1 {return os.Chmod(f.fixture.store.TrustPath(),0644)}
 return nil
}
func TestReviewerRestoreCannotOverwriteConvergedCommit(t *testing.T) {
 fixture:=setupV4Fixture(t,testPeerID)
 preview,err:=PreviewV4(fixture.inputs,nil,fixture.trust(t),fixture.self,nil,fixture.now)
 if err!=nil {t.Fatal(err)}
 filesystem:=&reviewerRestoreFS{fixture:fixture,t:t}
 _,err=applyV4(fixture.inputs,nil,preview,true,fixture.now,filesystem,hosttrust.Open)
 if err==nil {t.Fatal("faulted apply unexpectedly succeeded")}
 if filesystem.admittedGeneration==0 {t.Fatal("restore seam not reached")}
 coherent,err:=LoadCoherent(fixture.inputs,nil,fixture.store)
 if err!=nil {t.Fatal(err)}
 loaded,ok:=coherent.Config.Configuration();if !ok {t.Fatal("missing config")}
 if loaded.SourceVersion!=Version4 && coherent.Generation==filesystem.admittedGeneration {
  t.Fatalf("unlocked recovery replaced admitted Config4 with %s without a generation change: before=%d after=%d",loaded.SourceVersion,filesystem.admittedGeneration,coherent.Generation)
 }
}
