# Reproduce CR5 review

Extract `git archive a823eb20be497c3fa0510e7da4d3506ddb284431` into isolated scratch.
Copy probes/reviewer_probe_test.go and reviewer_lock_test.go into internal/hosttrust;
copy reviewer_crash_test.go and reviewer_restore_test.go into internal/config.
Run `go test ./internal/hosttrust ./internal/config -count=1 -run '^TestReviewer' -v`.
Original seven probes pass; TestReviewerRestoreCannotOverwriteConvergedCommit fails.
The new probe changes only fault/scheduling seams, never production source.

Before mutation replay remove these four probe files from test discovery.
Run `python3 internal/hosttrust/mutations.py --output <scratch-output> --only neutral,dance-converge-ignore,recover-forward-no-bump,lock-replacing-init`.
Harness exit 0, neutral exit 0, three semantic plants exit 1 with named failures.
Baseline `go test ./internal/hosttrust ./internal/config ./internal/peeridentity -count=1 -cover` exits 0.
Go 1.25.5 darwin/arm64. No Windows runtime; no power-loss claim.
