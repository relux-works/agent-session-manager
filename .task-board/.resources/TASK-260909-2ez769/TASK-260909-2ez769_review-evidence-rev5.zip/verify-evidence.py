import json,hashlib,pathlib,subprocess
root=pathlib.Path('/Users/iv/Developer/ReluxWorks/agent-session-manager')
review=pathlib.Path(__file__).resolve().parent/'candidate'
backup=root/'.temp/TASK-260830-z1yxg9/preserved-before-credentials-260910'
manifest=json.loads((backup/'manifest.json').read_text())
for f in manifest['files']:
 assert hashlib.sha256((backup/'files'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 if f['untracked']:
  assert hashlib.sha256((root/'.temp/TASK-260909-2ez769/parked-rpc-delta-260910'/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
print('RPC backup 15/15 and parked untracked 11/11 hashes match')
delta=subprocess.check_output(['git','diff','--name-only','a89328ca85a613abde39660f4be749a8fcf57903','a823eb20be497c3fa0510e7da4d3506ddb284431'],text=True).splitlines()
assert not set(delta)&{f['path'] for f in manifest['files']}
print('53-path candidate has no RPC manifest path overlap')
for name in ['hosttrust','config']:
 folder=review.parent/'producer'/('mutations-'+name+'-rev5')
 m=json.loads((folder/'manifest.json').read_text())
 for s in m['sources']:
  assert hashlib.sha256((review/s['path']).read_bytes()).hexdigest()==s['sha256'],s['path']
 results=json.loads((folder/'results.json').read_text())
 print(name,'source hashes match',len(m['sources']),'files; results',[(r['mutant'],r['exit_code'],r['result']) for r in results])
patch=root/'.task-board/.resources/TASK-260909-2ez769/TASK-260909-2ez769_change-request_rev5.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='4a6e3beb15acb6e67dbd628ea9139c75dd333254312375a93347e51af57bbc01'
print('CR patch digest matches assignment')
