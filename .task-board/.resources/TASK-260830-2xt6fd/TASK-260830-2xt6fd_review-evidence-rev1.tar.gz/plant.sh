#!/bin/zsh
# usage: plant.sh NAME FILE PERL_EXPR PKG RUNMASK
S=${0:h}; name=$1; f=$2; expr=$3; pkg=$4; mask=$5
cd $S/mut; cp $f $f.orig
perl -0pi -e "$expr" $f
if cmp -s $f $f.orig; then echo "$name NOT_APPLIED"; mv $f.orig $f; exit; fi
go test -count=1 -run "$mask" $pkg > $S/ev/plant-$name.log 2>&1; rc=$?
mv $f.orig $f
if [ $rc -eq 0 ]; then echo "$name SURVIVED"; else echo "$name KILLED rc=$rc"; fi
