# Importer outcome comparison — TASK-260830-2xt6fd rev6

Base: `5b7876be29cf578ff02583660d77fc10944e855c`; candidate scratch-index tree: `087ac145bb8ef8900a1de36e8d3928f0e64c4bda`. Candidate outcomes are from the exact-tree full `go test ./... -v` run. Base raw JSON outcomes are from `importer-refresh-*-base.jsonl` at the same base commit. The active environment is Go 1.25.5 on darwin/arm64; unset `GOWORK` resolves to no workspace file.

| Touched package | Shared keys | Status moves | Base-only keys | Candidate-only keys |
| --- | ---: | ---: | ---: | ---: |
| `internal/gitsnap` | 0 | 0 | 0 | 270 |
| `internal/provhost` | 909 | 0 | 0 | 1 |
| `internal/axpane` | 215 | 0 | 0 | 0 |
| `internal/resumesmoke` | 195 | 0 | 0 | 0 |
| `internal/sessquery` | 445 | 0 | 0 | 0 |
| `internal/tmuxserver` | 2182 | 1 | 12 | 118 |
| `internal/traceability` | 129 | 0 | 0 | 1 |
| `internal/traceability/cmd/tracecheck` | 23 | 0 | 0 | 0 |

Every per-test result is in `TASK-260830-2xt6fd_importer-outcome-grid-rev6.csv`. Direct importer graph was re-derived separately. `gitsnap` was absent at base, so its candidate-only tests are new-entry outcomes, not inferred baseline refusals.
