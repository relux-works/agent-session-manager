package traceability

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"testing"
)

func TestTaskTemporaryOwnershipDigest(t *testing.T) {
	raw, err := os.ReadFile("ownership.v0.7.0.json")
	if err != nil {
		t.Fatal(err)
	}
	registry, err := decodeOwnershipRegistry(raw)
	if err != nil {
		t.Fatal(err)
	}
	canonical, err := json.Marshal(registry)
	if err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(canonical)
	fmt.Printf("RE-DERIVED reviewedOwnershipCanonicalSHA256=%s bytes=%d\n", hex.EncodeToString(digest[:]), len(canonical))
}
