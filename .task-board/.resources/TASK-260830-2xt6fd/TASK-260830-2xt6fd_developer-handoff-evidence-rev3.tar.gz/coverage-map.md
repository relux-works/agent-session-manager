# Coverage map — TASK-260830-2xt6fd

## Brief gap

The assignment supplied no surface table. This is a brief gap, not a silent
coverage waiver. The map below covers every row in the six-row acceptance
matrix in `internal/gitsnap/testdata/assembly-acceptance.md`.

| Acceptance row | Production call site | Named test(s) | Narrowing evidence |
| --- | --- | --- | --- |
| Held input/provider quiescence | `(*tmuxserver.Lifecycle).CaptureGitWorkspace` | `TestCaptureStopPointStateDomain`, `TestCaptureProviderProofRequirements`, `TestCaptureRejectsCheckpointBoundaryAsProviderProof`, `TestCaptureFinalStatusStateDomain`, `TestCaptureNeverTransitionsOutsideStopPointOwnerSet` | `N-capture-admits-parked` kills `TestCaptureRejectsParkedEvenWithPriorQuiescenceReceipt` alone; `N-capture-restores-with-boundary-token-preserved` kills the successful-entry and AST transition tests. |
| Source change during capture and retry | `(*tmuxserver.Lifecycle).CaptureGitWorkspace` → `gitsnap.AssembleProvisional`; `gitsnap.Capture` | `TestCaptureGitWorkspaceSourceChangeRefusalAndRetry`, `TestAssemblySourceChangesAndRetry`, `TestContentDigestRaceAndRetry` | `N-assembly-source-admits-working-file-change` kills `TestAssemblySourceChangesAndRetry`; `N-consistency-admits-five-byte-digest-change` kills `TestContentDigestRaceAndRetry`. |
| Missing socket versus missing parent | `tmuxserver.UnixDialer.Dial` | `TestUnixDialerMissingSocketIsStale`, `TestUnixDialerMissingDirectoryIsUnknown` | `N-unix-dialer-missing-parent-admits-stale` admits only ENOENT with an absent containing directory as stale; `TestUnixDialerMissingDirectoryIsUnknown` kills it alone. |
| Repository-local packs, exact inventories, raw/logical indexes | `gitsnap.AssembleProvisional` → `captureAssembly` / `assemblePack` | `TestAssemblyPackIndexAndBytes`, `TestAssemblyRecursivePacks`, `TestAssemblyIndexCompatibility`, `TestAssemblyRawIndexRefusals`, `TestAssemblyFailedReadsAndCorruptObjects`, `TestAssemblyIsolatedDatabaseIgnoresAmbientObjects` | `N-assembly-inventory-admits-four-object-metadata-mismatch`, `N-assembly-raw-index-admits-two-entry-disagreement`, and `N-assembly-checksum-admits-last-bit-flip` each kill their named test. |
| Workspace root/child, blobs, cwd/config, safe-path closure | `gitsnap.AssembleProvisional` → `ValidateProvisional` | `TestValidateProvisionalClosureAndDescriptors`, `TestAssemblyGroupRecordAgreement`, `TestAssemblyMissingConfigClosure`, `TestAssemblyRecursiveCWDAndConfigClosure`, `TestValidateProvisionalParentChildOverlap` | `N-assembly-descriptor-admits-seven-byte-entry`, `N-assembly-group-admits-repository-identity-mismatch`, `N-assembly-closure-admits-one-unbound-tree`, `N-assembly-path-admits-missing-config-token-preserved`, and `N-assembly-path-admits-one-parent-partition-entry` each kill their named test. `N-assembly-closure-admits-one-missing-child` survives because the same fixture is rejected by another parent/tree binding; it is not counted as independent evidence. |
| Actual bytes, recursive dirty state, truthful unsupported inputs | `gitsnap.AssembleProvisional` → `gitsnap.Capture` with `ContentOptions` | `TestAssemblyNormativeCorpus`, `TestAssemblyRecursivePacks`, `TestAssemblyIndexCompatibility`, `TestAssemblyOptionsAndUnsupportedSources`, `TestContentSubmoduleUninitializedAndRefusals`, `TestContentSymlinkChainsAndExcludedTargets`, `TestContentSymlinkChainBoundaryAtProductionCapture` | `N-path-admits-escaping-chain`, `N-submodule-admits-stray-uninitialized`, `N-assembly-features-admits-origin-promisor`, and `N-assembly-policy-admits-unclassified-extra` each kill their named test. |
| Crash, idempotency, non-publication | `(*tmuxserver.Lifecycle).CaptureGitWorkspace` → `gitsnap.AssembleProvisional` | `TestCaptureFailureRetryUsesRequestStop`, `TestCaptureProcessCrashRetry`, `TestAssemblyCrashAfterObjectsAndRetry`, `TestAssemblyStoreFailureAndRetry` | `N-assembly-install-admits-shard-failure` kills `TestAssemblyStoreFailureAndRetry`; the stop-point narrowing above covers refusal. Crash exits 74/75 are expected child exits, followed by same-store retry. |

## Measured narrowing results

Each `BEHAVIOR_KILL` below was produced by an applied source plant, a successful
compile, and a nonzero behavior-test exit containing the named test failure.
The `closure-admits-one-missing-child` row is the only surviving gate plant.

| Mutant | What the plant admits | Named failing test / result |
| --- | --- | --- |
| `N-path-admits-escaping-chain` | One named symlink chain bypasses the safety walk | `TestContentSymlinkChainsAndExcludedTargets` — killed |
| `N-submodule-admits-stray-uninitialized` | One uninitialized submodule with stray entries bypasses refusal | `TestContentSubmoduleUninitializedAndRefusals` — killed |
| `N-consistency-admits-five-byte-digest-change` | Digest mismatch is ignored for a five-byte source | `TestContentDigestRaceAndRetry` — killed |
| `N-entry-set-admits-65537` | Shared manifest entry cap increases by one | `TestCheckManifestEntriesCountBounds` — killed |
| `N-assembly-raw-index-admits-two-entry-disagreement` | A two-entry raw/logical index mismatch is admitted | `TestAssemblyFailedReadsAndCorruptObjects` — killed |
| `N-assembly-checksum-admits-last-bit-flip` | A raw index checksum differing by one low bit is admitted | `TestAssemblyRawIndexRefusals` — killed |
| `N-assembly-source-admits-working-file-change` | A changed included working file is ignored by the closing observation | `TestAssemblySourceChangesAndRetry` — killed |
| `N-assembly-group-admits-repository-identity-mismatch` | Group/member repository identity disagreement is ignored | `TestAssemblyGroupRecordAgreement` — killed |
| `N-assembly-descriptor-admits-seven-byte-entry` | A seven-byte entry may disagree with its descriptor size | `TestValidateProvisionalClosureAndDescriptors` — killed |
| `N-assembly-closure-admits-one-missing-child` | One missing child may be treated as reached | `TestValidateProvisionalClosureAndDescriptors` — **survived**; another required repository-tree binding refuses the same malformed fixture, so this plant proves no independent missing-child visit gate. |
| `N-assembly-path-admits-missing-config-token-preserved` | The named missing project config bypasses path closure | `TestAssemblyMissingConfigClosure` — killed |
| `N-assembly-features-admits-origin-promisor` | `remote.origin.promisor=true` is treated as supported | `TestAssemblyOptionsAndUnsupportedSources` — killed |
| `N-assembly-policy-admits-unclassified-extra` | One unclassified include-policy value is admitted | `TestAssemblyInvalidIncludePolicy` — killed |
| `N-assembly-closure-admits-one-unbound-tree` | One extra reachable workspace tree may lack a root/member binding | `TestValidateProvisionalClosureAndDescriptors` — killed |
| `N-assembly-inventory-admits-four-object-metadata-mismatch` | Exact reachable-object metadata mismatch is admitted for a four-object pack | `TestAssemblyFailedReadsAndCorruptObjects` — killed |
| `N-assembly-install-admits-shard-failure` | One object-store shard-creation failure is ignored | `TestAssemblyStoreFailureAndRetry` — killed |
| `N-assembly-path-admits-one-parent-partition-entry` | One named child path may overlap the parent partition | `TestValidateProvisionalParentChildOverlap` — killed |
| `N-capture-admits-parked` | A parked Terminal Instance passes the stop-point admission gate | `TestCaptureRejectsParkedEvenWithPriorQuiescenceReceipt` alone — killed; the test asserts literal `capability_unavailable`. |
| `N-capture-restores-with-boundary-token-preserved` | The coordinator sends `restore` where it must call `wait-safe-boundary`, while receipt/parser tokens remain | `TestCaptureGitWorkspaceQuiescedAssemblesAndRechecks` and `TestCaptureNeverTransitionsOutsideStopPointOwnerSet` — both killed; raw log records both failures. |
| `N-unix-dialer-missing-parent-admits-stale` | An absent containing directory with an ENOENT socket lookup is misclassified as stale | `TestUnixDialerMissingDirectoryIsUnknown` alone — killed; raw log records test failure and process exit 1. |
| `C-control` (control only) | Comment-only source edit with no behavior change | `TestSocketPathDerivesOnlyFromRuntimeDir` passes — expected survivor; this is not a gate mutant. |

The measured acceptance-row ratio is **6 of 6 rows driven** through their
listed production call sites. This is capture/assembly scope only. It does not
claim materialization, checkpoint publication, doctor advertising, or Story
integration. The rev3 table below measures each coordinator refusal sub-gate with its own narrowing and named failing test.

## Out-of-contract rows and the acceptance-criteria boundary

| Row | Acceptance-criteria clause that bounds this leaf |
| --- | --- |
| §10.4#3 checkpoint/provider/task-board manifest selection and conflict resolution | “Drive complete Git transfer-object assembly through the real capture path … workspace root/child manifest closure.” This leaf assembles the explicitly supplied Git workspace members and their root/child closure; it does not select checkpoint/provider/task-board history. |
| §10.4#5 hardlink target semantics | “Detect source changes during capture and prove manifest closure, path safety, byte identity …” The deliverable emits Git tree file modes and blob identity; it does not preserve filesystem inode/hardlink relationships or materialize a destination tree. The path-safety tests cover symlink resolution and partition overlap. |
| §10.4#15 `PROVIDER-CAPTURE-N1` transfer-response admission | “Truthful unsupported cases” and “no unsupported capability is advertised.” This leaf accepts local Git capture inputs and has no external provider transfer-response entry. |
| §10.4#25 cross-platform conditional support | “No unsupported capability is advertised.” The evidence is for the tested host/runtime; no other provider/platform cell is advertised as supported. |
| §12.1#1 checkpoint linkage | “Workspace root/child manifest closure” is required; publishing a checkpoint that references the captured root is not. No checkpoint publisher is part of this capture leaf. |
| §12.2#3–#6 parser-before-destination materialization gates | “Transfer-object assembly through the real capture path” requires the Git pack/index/manifest output. This leaf does not write or replay a destination checkout and does not claim those materialization parser gates. |
| §12.3 steps 2–8 materialization | The acceptance criterion asks to “Detect source changes during capture” and assemble Git transfer objects; it does not ask this leaf to materialize or replay a destination tree. |
| Capture returning to `active` | “Detect source changes during capture” does not ask for a live-session return transition. The §4.C operation table is closed and has no release transition; the capture is a stop-point operation. |

Crash/idempotency is in contract because the AC says “crash/idempotency evidence
is included when the operation mutates durable state”; object-store pack and
blob installation do, so child-process crash/retry evidence is included.

Raw per-plant logs and result JSON are under `.temp/TASK-260830-2xt6fd/` in
`mutants-narrowing-01/`, `mutants-closure-02/`, `mutants-extra-01/`,
`mutants-capture-02/`, `mutants-token-preserved-01/`, and
`mutants-control-01/`, plus the final reruns in `mutants-capture-final-01/`,
`mutants-capture-final-02/`, and `mutants-unix-dialer-final/`. Four earlier broad harness controls that attempted the
whole package suite exceeded the harness's 240-second per-test limit; they are
diagnostics, not pass evidence. Their recorded paths are the four
`mutants-*-run-01.log` files for content-a/content-b/assembly-a/assembly-b.

## Rev3 complete capture-admission gate census and mutant evidence
The final source census walks the coordinator call graph, rejects any non-literal refusal detail, and maps every direct refusal site to exactly one named matrix test. It measures 22 direct refusal sites. Each row below ran alone twice against the current candidate; both behavior runs exited 1 on the named test failure, and each harness invocation exited 0 with KILLED. No rev3 site mutant survived or was NOT_APPLIED. The two matrix fixtures refined after the first pass also received additional fresh isolated reruns. Per-plant raw output is in the current pass directories.

| Mutant | What it admits | Named test that fails | Result |
| --- | --- | --- | --- |
| N-capture-admits-absent-opening-state | Admits exactly the absent opening state past the stop-point state domain; the row requires the absent-state refusal from CaptureGitWorkspace. | TestCaptureAdmission_InitialAbsent | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-active-opening-state | Admits exactly the active opening state past the stop-point state domain; the boundary owner then rejects its false quiescing source and the literal active-state row fails. | TestCaptureAdmission_InitialActive | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-boundary-identity-drift | Admits the one boundary context with a drifted session identity for the fixture group; the subsequent missing closure receipt is not the literal identity-mismatch refusal. | TestCaptureAdmission_BoundaryIdentityMatchesStatus | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-changed-closing-incarnation | Admits exactly the rotated quiescence incarnation at the closing recheck; the named production-entry test requires same-incarnation refusal. | TestCaptureAdmission_IncarnationStableAcrossCapture | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-checkpoint-proof | Admits exactly the checkpoint-only proof kind through the provider-proof gate. The named production-entry test carries a valid Runner, Assembly, current closure receipt and provider boundary, and asserts the literal refusal code and detail. | TestCaptureAdmission_CheckpointOnlyProviderProof | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-closing-status-nonmatch | Admits the final exact-status nonmatch produced by changing the body generation during assembly; the downstream state refusal is not the closing identity row. | TestCaptureAdmission_ClosingStatusIdentityMatch | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-final-parked-state | Admits exactly parked at the closing held-state gate; the capture would return a successful assembly with a parked final state, which the named row rejects. | TestCaptureAdmission_FinalStateRemainsHeld | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-foreign-provider-boundary-receipt | Admits exactly the fixture's other-incarnation provider receipt while all other boundary receipt and proof checks remain; the row requires the literal provider-boundary refusal. | TestCaptureAdmission_CurrentProviderBoundaryReceiptRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-foreign-quiesce-receipt | Drops only the receipt-incarnation comparison, admitting that one receipt while a separate current provider-boundary receipt keeps the baseline barrier proven. The named test asserts the literal receipt refusal through CaptureGitWorkspace. | TestCaptureAdmission_CurrentInputClosureReceiptRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-nil-assembly-runner | Admits a missing assembly runner for exactly the valid matrix fixture group; assembly returns without the required typed capture refusal. | TestCaptureAdmission_AssemblyRunnerRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-nil-lifecycle | Admits the nil Lifecycle receiver only for the valid matrix fixture group; the production entry test requires the literal lifecycle refusal and therefore catches the nil dereference. | TestCaptureAdmission_LifecycleRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-opening-status-nonmatch | Admits the fixture's exact status query after its backend generation no longer matches the binding; the downstream absent-state refusal cannot satisfy the matrix row. | TestCaptureAdmission_OpeningStatusIdentityMatch | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-parked | Admits exactly parked through the capture stop-point state gate; the request retains Runner, Assembly, current-incarnation closure and provider-boundary evidence. The state-domain test requires the literal unsupported-state refusal detail for parked. | TestCaptureAdmission_InitialParked | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-quiescing-without-boundary | Admits exactly the boundary-less matrix request for its fixture group; the parser's protocol error cannot satisfy the missing-provider-boundary row. | TestCaptureAdmission_QuiescingBoundaryRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-quiescing-without-incarnation | Admits the quiescing fixture with its incarnation file removed; the next closure-receipt check must not stand in for the missing-incarnation refusal. | TestCaptureAdmission_QuiescingIncarnationRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-session-scoped-status | Admits the session-scoped status shape for exactly the matrix fixture group; later boundary identity cannot turn it into an exact-instance capture. | TestCaptureAdmission_ExactStatusIdentityRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-stale-fenced-opening-state | Admits exactly stale_fenced at the opening state gate; the named production-entry row requires that state to refuse. | TestCaptureAdmission_InitialStaleFenced | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-stopped-boundary-body | Admits a stopped capture carrying the one valid fixture boundary body; the stopped path must still refuse rather than ignore an operation token. | TestCaptureAdmission_StoppedBoundaryBodyForbidden | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-stopped-to-quiescing-for-one-group | Admits a stopped capture that becomes quiescing only for one workspace-group identity. The named test changes the close-time state from stopped to quiescing after the pack phase and requires the literal stopped-stays-stopped refusal. | TestCaptureAdmission_StoppedRemainsStopped | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-stopped-without-incarnation | Admits the stopped fixture after its current incarnation record is removed; the later close check is not the opening record refusal required by this row. | TestCaptureAdmission_StoppedIncarnationRequired | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-unavailable-opening-state | Admits exactly unavailable at the opening state gate; the named production-entry row requires the literal unavailable-state refusal. | TestCaptureAdmission_InitialUnavailable | killed alone twice (behavior exit 1; harness exit 0) |
| N-capture-admits-unproven-barrier-for-one-group | Admits an unproven barrier only for one workspace-group identity; all other groups still refuse. The named test invalidates both closure receipts after pack assembly and asserts the literal close-time barrier refusal. | TestCaptureAdmission_ClosureBarrierStillProven | killed alone twice (behavior exit 1; harness exit 0) |

Census controls and all observed survivors are declared separately. The unlisted-site control and non-literal-detail control are killed by TestCaptureCoordinatorAdmissionGateCensus; the harmless comment-only C-control is the expected survivor. The prior 368-row harness pass had 366 KILLED and two SURVIVED: D-attach-entry-deadline-shadowed is supplementary and survives because the downstream wait bound rejects the same deadline before admission (independent post-lock and wait-deadline narrowings kill); C-control has no behavior change. A separate assembly mutant N-assembly-closure-admits-one-missing-child survived because the malformed fixture still fails the required repository-tree binding, so it is not counted as an independent child-visit gate. No survivor is reported as a killed gate.

| Mutant / control | What it narrows or changes | Named behavior test / status | Bound for survival |
| --- | --- | --- | --- |
| N-assembly-closure-admits-one-missing-child | Admits one missing child at the closure visitor | TestValidateProvisionalClosureAndDescriptors — survived in the earlier gitsnap mutant run | The fixture still fails the required repository-tree binding, so this is not independent evidence of child-visit coverage. |
| D-attach-entry-deadline-shadowed | Admits exactly the on-deadline instant at attach entry | TestExecuteAttachRefusesDeadline/boundary — survived in the earlier 368-row shipped-harness pass | The downstream wait bound rejects the same instant before admission; the post-lock and wait-deadline narrowings independently kill. Supplementary only. |
| C-control | Comment-only behavior-neutral source edit | TestSocketPathDerivesOnlyFromRuntimeDir — expected survivor in the earlier broad harness | Control only; no production behavior is changed. |

## Current census controls

| Control plant | What it changes | Named test / observed outcome |
| --- | --- | --- |
| C-capture-census-unlisted-refusal-site | Adds one direct refusal call without adding a matrix row | TestCaptureCoordinatorAdmissionGateCensus — killed alone twice on current tree; behavior exit 1, harness exit 0. |
| C-capture-census-nonliteral-detail | Preserves runtime detail but makes its AST value computed | TestCaptureCoordinatorAdmissionGateCensus — killed alone twice on current tree; behavior exit 1, harness exit 0. |
| C-control | Comment-only behavior-neutral source edit | TestSocketPathDerivesOnlyFromRuntimeDir — survived as expected on current tree; behavior exit 0, harness exit 0. |
