# Importer outcome comparison — refreshed exact snapshots

Base source: `origin/main` commit `5b7876be29cf578ff02583660d77fc10944e855c`.
Candidate source: staged scratch-index tree `7bebe7213a4c3c71410c591b14b2761d2e8d4bdc` from the uncommitted Story worktree delta over two refreshed Story checkpoints.
All package runs used Go `GOWORK=off`, `GOTOOLCHAIN=local`, the same task-scoped `HOME` and shared Go build cache, `TMPDIR` unset, `go test -json -count=1`; each raw JSON log is named below. Grid keys are `(package, named production-entry test/input)`; subtests remain distinct keys in the CSV.

| Package / production importer set | Base suite | Candidate suite | Shared test keys | Status moves | Base-only | Candidate-only |
|---|---:|---:|---:|---:|---:|---:|
| `internal/provhost` | pass | pass | 909 | 0 | 0 | 1 |
| `internal/axpane` | pass | pass | 215 | 0 | 0 | 0 |
| `internal/resumesmoke` | pass | pass | 195 | 0 | 0 | 0 |
| `internal/sessquery` | pass | pass | 445 | 0 | 0 | 0 |
| `internal/tmuxserver` | fail | pass | 2182 | 1 | 12 | 108 |
| `internal/traceability` | pass | pass | 129 | 0 | 0 | 1 |
| `internal/traceability/cmd/tracecheck` | pass | pass | 23 | 0 | 0 | 0 |

## Runtime class movements

### `internal/provhost` test-key membership

- Base-only test keys: 0; top-level names: (none)
- Candidate-only test keys: 1; top-level names: `TestCheckIdentityDoesNotVerifyBinding`

### `internal/tmuxserver` test-key membership

- Base-only test keys: 12; top-level names: `TestCustodyPathComponentByteLengthsAtProductionEntries`
- Candidate-only test keys: 108; top-level names: `TestCaptureAdmissionGateValidControls`, `TestCaptureAdmission_AssemblyRunnerRequired`, `TestCaptureAdmission_BoundaryIdentityMatchesStatus`, `TestCaptureAdmission_CheckpointOnlyProviderProof`, `TestCaptureAdmission_ClosingStatusIdentityMatch`, `TestCaptureAdmission_ClosureBarrierStillProven`, `TestCaptureAdmission_CurrentInputClosureReceiptRequired`, `TestCaptureAdmission_CurrentProviderBoundaryReceiptRequired`, `TestCaptureAdmission_ExactStatusIdentityRequired`, `TestCaptureAdmission_FinalStateRemainsHeld`, `TestCaptureAdmission_IncarnationStableAcrossCapture`, `TestCaptureAdmission_InitialAbsent`, `TestCaptureAdmission_InitialActive`, `TestCaptureAdmission_InitialParked`, `TestCaptureAdmission_InitialStaleFenced`, `TestCaptureAdmission_InitialUnavailable`, `TestCaptureAdmission_LifecycleRequired`, `TestCaptureAdmission_OpeningStatusIdentityMatch`, `TestCaptureAdmission_QuiescingBoundaryRequired`, `TestCaptureAdmission_QuiescingIncarnationRequired`, `TestCaptureAdmission_StoppedBoundaryBodyForbidden`, `TestCaptureAdmission_StoppedIncarnationRequired`, `TestCaptureAdmission_StoppedRemainsStopped`, `TestCaptureCoordinatorAdmissionGateCensus`, `TestCaptureFailureRetryUsesRequestStop`, `TestCaptureFinalStatusStateDomain`, `TestCaptureGitWorkspaceQuiescedAssemblesAndRechecks`, `TestCaptureGitWorkspaceSourceChangeRefusalAndRetry`, `TestCaptureGitWorkspaceStoppedAssemblesWithoutBoundary`, `TestCaptureNeverTransitionsOutsideStopPointOwnerSet`, `TestCaptureProcessCrashRetry`, `TestCaptureProviderProofRequirements`, `TestCaptureRejectsBarrierLostAfterAssembly`, `TestCaptureRejectsCheckpointBoundaryAsProviderProof`, `TestCaptureRejectsParkedEvenWithPriorQuiescenceReceipt`, `TestCaptureRejectsQuiesceReceiptFromAnotherIncarnation`, `TestCaptureStopPointStateDomain`, `TestCaptureStoppedMustRemainStoppedAtClose`, `TestCustodyModeOracleAtProductionEntries`, `TestCustodyPathComponentByteLengthsAtProductionEntries`, `TestCustodyPathKindOwnerOracleAtProductionEntries`

### `internal/traceability` test-key membership

- Base-only test keys: 0; top-level names: (none)
- Candidate-only test keys: 1; top-level names: `TestGitWorkspaceStoryLeafCasesDecodeWithClauseEdges`

### Shared-key status moves

- `internal/tmuxserver::TestUnixDialerMissingDirectoryIsUnknown`: `fail` → `pass`.
## Entry-level interpretation

- `internal/gitsnap`: absent from base package discovery (46 packages); candidate adds it (47 packages). The candidate full `gitsnap` suite passed. Its `Capture` and `AssembleProvisional` entry classes have no base runtime outcome and are reported as new, not as inferred baseline refusals.
- `internal/tmuxserver`, `UnixDialer.Dial`, ENOENT beneath a missing parent: base full suite exits 1 at `TestUnixDialerMissingDirectoryIsUnknown` (`stale`, wanted `unknown`); candidate full suite exits 0. This is the only shared-key status movement in the comparison and is the intended fail-closed correction for a failed parent observation under §4.C.
- `internal/tmuxserver`, `(*Lifecycle).CaptureGitWorkspace`: new candidate production entry; candidate full suite is green. The exact capture admission tests and mutants are separately logged in the evidence pack.
- `internal/provhost`, `CheckIdentity`, and the unchanged direct production consumers `axpane`, `resumesmoke`, and `sessquery`: all shared named test keys retain their status. Candidate-only identity/callsite census additions are listed above and do not change the shape-only identity contract.
- `internal/traceability` and `internal/traceability/cmd/tracecheck`: candidate-only registry decode/coverage tests are listed above; shared test keys retain their status and the candidate tracecheck output is pinned to the re-derived digest.
- `internal/traceability/cmd/tracecheck`, `TestMainRejectsRenamedScalarSectionOwnerDeclarations/10.4`: the base input renamed `validateTransferManifest` in `internal/canonicaljson/closed_shapes.go`; the refreshed candidate reuses the original test/subtest name to rename `AssembleProvisional` in `internal/gitsnap/assembly.go`, which is now the Section 10.4 binding owner. Both versions pass their literal owner-refusal assertion; the candidate input follows the merged registry owner.

The base `internal/gitsnap` package suite was not run because `go list ./...` showed that the package did not exist at base; a direct attempted `go test ./internal/gitsnap` exited 1 with “directory not found” and is retained as `importer-refresh-gitsnap-base.jsonl`.

Direct importer graph: `importer-refresh-graph.md`. Complete per-key status comparison: `importer-outcome-grid-refresh.csv`.
