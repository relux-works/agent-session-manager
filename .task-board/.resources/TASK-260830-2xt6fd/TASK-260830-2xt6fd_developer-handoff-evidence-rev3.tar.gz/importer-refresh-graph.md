# Production importer graph (refreshed comparison)

| Touched package | Base direct importers | Candidate direct importers | Added | Removed |
|---|---|---|---|---|
| `internal/gitsnap` | (none) | internal/tmuxserver | internal/tmuxserver | (none) |
| `internal/provhost` | internal/axpane, internal/resumesmoke, internal/sessquery | internal/axpane, internal/resumesmoke, internal/sessquery | (none) | (none) |
| `internal/tmuxserver` | (none) | (none) | (none) | (none) |
| `internal/traceability` | internal/traceability/cmd/tracecheck | internal/traceability/cmd/tracecheck | (none) | (none) |
