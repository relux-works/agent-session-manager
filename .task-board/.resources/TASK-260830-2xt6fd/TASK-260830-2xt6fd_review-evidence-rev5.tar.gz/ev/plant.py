import sys,re
f,old,new=sys.argv[1],sys.argv[2],sys.argv[3]
s=open(f).read()
assert s.count(old)==1,("count",s.count(old))
open(f,'w').write(s.replace(old,new))
