import hashlib,json,os,subprocess,tarfile
from pathlib import Path
root=Path.cwd()
out=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/TASK-260830-2xt6fd/RUN-260908-ec0794')
def git(*args):
 return subprocess.run(['git',*args],capture_output=True,check=True).stdout
head=git('rev-parse','HEAD').decode().strip()
assert head=='d73a28570c221a9c490f98f8a9848546d4c13068',head
assert not git('diff','--cached','--name-only'), 'unexpected staging'
tracked=git('diff','--name-only','HEAD','-z').decode().split('\0')
untracked=git('ls-files','--others','--exclude-standard','-z').decode().split('\0')
paths=sorted(set(tracked+untracked)-{''})
assert paths
for name in paths:
 assert name in ('README.md','LOGBOOK.md','internal/provhost/identity.go','internal/provhost/identity_test.go') or name.startswith('internal/gitsnap/'),name
rows=[]
for name in paths:
 p=root/name
 rows.append(dict(path=name,size=p.stat().st_size,mode=oct(p.stat().st_mode&0o777),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
patch=git('diff','--binary','HEAD','--',*[p for p in tracked if p])
patch_exits={}
for name in untracked:
 if not name:continue
 result=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],capture_output=True)
 assert result.returncode==1,(name,result.returncode,result.stderr)
 patch_exits[name]=1 # expected diff exit, not a validation PASS
 patch+=result.stdout
patch_name=out/'TASK-260830-2xt6fd_partial.patch'
patch_name.write_bytes(patch)
spec=hashlib.sha256((root/'internal/specdoc/SPEC.md').read_bytes()).hexdigest()
assert spec=='562546d240f0fa3e71b47e6359a002f9892c0efd97e19eb55917527552ac484a'
manifest=dict(run='RUN-260908-ec0794',goal='GOAL-260908-ee3e05',revision=1,base=head,branch=git('branch','--show-current').decode().strip(),staged_paths=[],spec_sha256=spec,files=rows,patch_sha256=hashlib.sha256(patch).hexdigest(),new_file_diff_exits=patch_exits)
(out/'TASK-260830-2xt6fd_source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'TASK-260830-2xt6fd_partial-source.tar.gz','w:gz') as tar:
 for name in paths:tar.add(root/name,arcname=name)
print(json.dumps({'changed_paths':len(paths),'base':head,'patch_sha256':manifest['patch_sha256']}))
