import hashlib,json,os,tarfile
from pathlib import Path
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/TASK-260830-2xt6fd/RUN-260908-ec0794')
archive=root/'TASK-260830-2xt6fd_assembly-evidence.tar.gz'
index=root/'TASK-260830-2xt6fd_evidence-index.json'
files=[]
for current,dirs,names in os.walk(root):
 dirs[:]=[d for d in dirs if d!='candidate']
 for name in names:
  p=Path(current)/name
  if p in (archive,index) or name.endswith('.tar.gz'):continue
  files.append(p)
files.sort()
rows=[dict(path=str(p.relative_to(root)),size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
index.write_text(json.dumps({'run':'RUN-260908-ec0794','goal':'GOAL-260908-ee3e05','revision':1,'files':rows,'exclusions':['disposable candidate trees','separately attached source archive','archive itself']},indent=2)+'\n')
with tarfile.open(archive,'w:gz') as tar:
 for p in files+[index]:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
print(json.dumps({'archive':archive.name,'files':len(files)+1,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
