import json
from pathlib import Path
root=Path.cwd()
out=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/TASK-260830-2xt6fd/RUN-260908-ec0794')
vectors=json.loads((root/'internal/gitsnap/testdata/assembly-mutations.json').read_text())
results={}
for directory in ['frozen-controls','frozen-objects','frozen-closure','frozen-path']:
 p=out/directory/'results.json'
 if p.exists():
  for row in json.loads(p.read_text()):results.setdefault(row['name'],[]).append(dict(row,source=directory))
lines=['# TASK-260830-2xt6fd — measured mutant evidence','',
 'Only the current-source batches are summarized here. Each subprocess exit and full failing-test list is retained in the JSON/logs. A mutation with no named failing test is a survivor; the neutral mutation intentionally survives. The missing-child visitor mutation is additionally checked by other closure gates and may survive; it is not counted as an independent proof.', '',
 '| Mutant | What it narrows or controls | Actual outcome / exits | Named failing test | Survival bound |',
 '| --- | --- | --- | --- | --- |']
descriptions={
'C-assembly-bad-empty-object-roots':'Bad control: remove every pack root; not counted as a narrowing.',
'N-assembly-raw-index-admits-two-entry-disagreement':'Keep raw/logical index equality gate except for exactly two decoded entries.',
'N-assembly-checksum-admits-last-bit-flip':'Keep index checksum gate except when the final checksum byte differs by bit 0 only.',
'N-assembly-inventory-admits-four-object-metadata-mismatch':'Keep exact imported metadata comparison except for a four-object pack.',
'N-assembly-source-admits-working-file-change':'Keep closing observation equality except for the fixture-specific changed working-file digest.',
'N-assembly-group-admits-repository-identity-mismatch':'Keep group-record agreement for every other member field; admit repository_identity mismatch.',
'N-assembly-descriptor-admits-seven-byte-entry':'Keep descriptor/reference size agreement except when the manifest claims exactly seven bytes.',
'N-assembly-features-admits-origin-promisor':'Keep true promisor refusal for other remotes; admit remote.origin.promisor=true.'
}
counts={}
for vector in vectors:
 rows=results.get(vector['name'],[])
 if not rows:continue
 statuses={r['status'] for r in rows}
 row=rows[-1]
 counts[row['status']]=counts.get(row['status'],0)+1
 named=[name for name in vector['tests'] if any(name in r.get('failing',[]) for r in rows)]
 outcome='/'.join(sorted(statuses))+'; '+', '.join(f"{r['source']}: compile={r.get('compile_exit')}, behavior={r.get('behavior_exit')}, positive={r.get('positive_exit')}" for r in rows)
 scope=vector['bound'] or descriptions.get(vector['name'], vector['new'].replace('\n',' ')[:180])
 bound='—' if named else (row.get('bound') or 'No named failing test; selected behavioral coverage is not established by this vector.')
 lines.append('| '+ ' | '.join(x.replace('|','\\|') for x in [vector['name'],scope,outcome,', '.join(named) or 'None — survivor',bound])+' |')
lines+=['',f'Unique finished vectors: {len(results)} of {len(vectors)}. Outcomes: {json.dumps(counts,sort_keys=True)}.','']
(out/'TASK-260830-2xt6fd_mutants.md').write_text('\n'.join(lines))
print(json.dumps({'finished':len(results),'expected':len(vectors),'outcomes':counts}))
