| Mutant | Narrowing | Named test | Exit | Result | Raw log |
| --- | --- | --- | ---: | --- | --- |
| sync-duplicate-delivery-drops-active-object | Narrowing for duplicate delivery: admits the identical-byte retry but silently removes its already active durable object; the named production-entry test requires byte-identical durable state after replay. | TestDurableJSONAddIsIdempotentAcrossCrashRestartByNamespace | 1 | killed | `sync-duplicate-delivery-drops-active-object/test.log` |
