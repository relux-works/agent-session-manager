# Unresolved Questions

## Capture-scoped quiescence release — TASK-260830-2xt6fd

Should Git workspace capture leave a live Terminal Instance in durable quiescing state until stop/restore, or should the existing terminal lifecycle owner provide a temporary, generation-bound capture hold/release with crash recovery?

The current tmux lifecycle closes input and proves a safe boundary, but its closed operation set has no same-instance release. A fresh restore reopens input only after stop and incarnation rotation. The capture implementation has no production caller into the lifecycle owner. The recommended path is to extend the existing lifecycle owner with a durable scoped hold/release, then have the capture coordinator hold it through assembly and recover/release through the same owner.
