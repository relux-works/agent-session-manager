# Provisional Git transfer assembly — TASK-260830-2xt6fd

Authority: AX v0.5.0, commit 28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c,
Sections 10.2–10.4 and 12.1–12.3. `internal/specdoc/SPEC.md` is unchanged;
`TestAssemblyNormativeCorpus` consumes its exact pinned payload corpus through
the same fixture loader as the accepted content tests.

This is preserved partial implementation below coordinated capture, not a full
capture handoff. All six original final-leaf rows remain in scope. **5 of 6 AC
rows have component entry drivers**; held quiescence has **0 of 1**. This ratio
does not discharge full capture acceptance or claim a committed candidate.
The managed owner must snapshot/review/checkpoint the preserved source. The
runtime prerequisite and final integration/checklist rows remain open.

| Original final-leaf AC row | Production call site and named tests | Achieved / outstanding |
| --- | --- | --- |
| Held input/provider quiescence through capture | No coordinated entry exists | 0/1; assigned external runtime owner chain TASK-260830-1c28dz -> 35urbp -> 2056mm -> kkh1an -> 1geqhj, with name/admission/journal prerequisites. No caller safe flag, stub or decoder proof. |
| Source-change refusal through the capture interval | AssembleProvisional -> Capture -> objects -> Capture; TestAssemblySourceChangesAndRetry | Observed file/new-file/mode/index/HEAD/config/recursive-child changes refuse. Whole held runtime lifetime and change-and-revert remain unproven. |
| Repository-local packs, exact inventories, raw/logical indexes | AssembleProvisional -> objects/rawIndex -> RunInput/RunIsolated -> contentState.blob -> ObjectStore.PutBlob; TestAssemblyNormativeCorpus, TestAssemblyPackIndexAndBytes, TestAssemblyRecursivePacks, TestAssemblyFailedReadsAndCorruptObjects, TestAssemblyIndexCompatibility | Components implemented; generated packs independently imported, inventory/raw indexes equal pinned corpus, isolated verification cannot borrow ambient object databases. Runtime wiring outstanding. |
| Workspace root/child, blob, cwd/config, safe path closure | AssembleProvisional -> repository/seal -> ValidateProvisional/checkGroupRecord/checkCapturedPaths; TestValidateProvisionalClosureAndDescriptors, TestAssemblyGroupRecordAgreement, TestAssemblyOptionsAndUnsupportedSources, TestAssemblyMultipleMembers, TestAssemblyRecursiveCWDAndConfigClosure, TestValidateProvisionalParentChildOverlap | Canonical owner reused; missing/forged/mismatched objects refuse, selected immutable group topology compared. Group-history authority/conflict resolution is an external record-owner input, not supplied by this component. |
| Actual bytes, recursive dirty state and truthful unsupported cases | AssembleProvisional -> existing Capture/content owner -> per-repository object assembly; TestAssemblyNormativeCorpus, TestAssemblyRecursivePacks, TestAssemblyIndexCompatibility, TestAssemblyOptionsAndUnsupportedSources | Existing guarded bytes/exclusions/symlink/submodule policy reused. Shallow, partial-clone and replacement-history sources explicitly refuse; no materialization implementation is claimed. |
| Truthful capability, mutation/recovery, publication evidence | AssembleProvisional/ObjectStore; TestAssemblyCrashAfterObjectsAndRetry, TestAssemblyPackIndexAndBytes; assembly-mutations.json and task-scoped evidence | Crash exit 74 is expected failure, followed by successful idempotent retry. Immutable objects can remain unreferenced. No checkpoint, coordinated capture, doctor capability, full CR or Story delivery claim. Mutation/command results are attached to the task, not inferred from this map. |

## Component boundaries

`AssembleProvisional` requires a schema-valid, identity-verified immutable Group
Record and all selected Git members in one immutable store outside the source
checkouts. Record resolution, ambiguous histories and session authority belong
to their assigned owners. The result returns exact manifests/descriptors and
separate byte-digest addresses; it is not an attestation or durable publication.

Each Git pack contains closure rooted in its recorded HEAD/upstream and all
non-gitlink index OIDs. Unrecorded branches and arbitrary unreachable objects are
not copied. Each initialized child is packed independently; three submodule
pointer states remain independent. Inventory lines have bare Git OIDs, matching
the exact normative corpus. SHA-1/SHA-256 are selected per repository.

Raw indexes are copied and decoded by Git in a disposable repository. Split
indexes are flattened there, preserving logical entries, flags and version;
unborn empty checkouts receive an equivalent valid empty raw index. Unknown
required extensions fail through Git. Working bytes remain distinct from staged
blobs. File contents reuse the existing chunked immutable-install owner; packs
and raw indexes currently use memory. No 128 GiB pack throughput claim is made.

Up to 1024 repository trees are direct children of the workspace root. Larger
groups use empty per-workspace composites; TestAssemblyManifestFanout measures
1024/1025 tree construction, not 1025 live repositories. Their local
paths are interpreted by the Git member/submodule mappings; a child README is
not a path partition rooted at the parent's README. Cwd/config paths resolve through the repository and initialized submodule
closure. The immutable Group Record selects the member resume cwd; Directory
locates the repository to read. Parent entries may name submodule directories
but cannot overlap child-owned partitions; required configs must be files, and ignored configs still
need an explicit non-secret include policy. Schema and entry path/case validation
remain with canonicaljson and filesystem symlink checks remain with Capture.

`ValidateProvisional` verifies graph/schema/descriptor relationships. It does
not reread blob-store content, import externally supplied packs or prove runtime
quiescence. Assembly verifies/imports the freshly generated bytes before passing
them through PutBlob. Arbitrary external transfer validation/materialization is
not represented by the graph-only validator.

The runner is trusted to execute the selected Git binary faithfully. Isolated
verification strips ambient Git routing/config variables; source reads preserve
the existing trusted configuration policy, disable lazy fetch/replacement objects,
and do not sandbox arbitrary filters. Native tests are not cross-platform runtime
proof. Repeated observations cannot detect a change-and-revert between reads.
A killed process can leave disposable OS-temp verifier directories and verified
unreferenced objects. Retry performs fresh observation and reuses immutable bytes.
