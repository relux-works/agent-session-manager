Full command stopped at bounded 9-minute point after 45 ok packages and specpin missing-board failure; remaining packages rerun separately. See verdict.
