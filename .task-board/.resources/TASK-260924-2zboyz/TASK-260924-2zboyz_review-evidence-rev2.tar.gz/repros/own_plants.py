from pathlib import Path
import subprocess
root=Path('plants')
out=Path('own-plants')
out.mkdir(exist_ok=True)
rows=[
 ('case_fold', 'internal/clonereadback/decode.go', 'if !allowed[name] {', 'if !allowed[name] && !allowed[strings.ToLower(name)] {', 'TestMemberCensusMiscased$'),
 ('mode_result_swap', 'internal/clonereadback/readback.go', 'Mode:                        mode,', 'Mode:                        "live",', 'TestModeBindsIdentity$'),
 ('valid_one_false', 'internal/clonereadback/report.go', 'if !checks.LiveStructuralValid {', 'if !checks.LiveStructuralValid && !checks.StagedStructuralValid {', 'TestValidWholeDomainOracle$'),
 ('owner_wrong_input', 'internal/clonereadback/report.go', 'sessadapter.DecodeFindings(json.RawMessage(input.Findings), maxReportFindings)', 'sessadapter.DecodeFindings(json.RawMessage(`[]`), maxReportFindings)', 'TestOwnerDelegation$'),
 ('media_plus_one', 'internal/clonereadback/readback.go', 'length < 1 || length > 128', 'length < 1 || length > 129', 'TestMediaTypeStringEdges$'),
 ('neutral', 'internal/clonereadback/readback.go', '// checkEvidenceOrder enforces', '// neutral review control\n// checkEvidenceOrder enforces', 'TestMediaTypeStringEdges$'),
]
for name,path,anchor,replacement,test in rows:
 p=root/path
 original=p.read_text()
 if original.count(anchor)!=1:
  raise RuntimeError(f'{name}: anchor count {original.count(anchor)}')
 altered=original.replace(anchor,replacement)
 if name=='case_fold':
  altered=altered.replace('"io"\n', '"io"\n\t"strings"\n',1)
 p.write_text(altered)
 cmd=['go','test','-count=1','./internal/clonereadback/','-run',test]
 try:
  result=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
  code=result.returncode
  output=result.stdout
 finally:
  p.write_text(original)
 (out/(name+'.log')).write_text(f'plant={name}\ncommand={" ".join(cmd)}\nexit={code}\n{output}')
 print(name,code,flush=True)
