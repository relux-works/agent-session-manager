import json,hashlib,re
from pathlib import Path
lines=Path('review-fixtures.log').read_text().splitlines()
for label,field in [('READBACK','read_back_evidence_manifest_id'),('REPORT','validation_report_id')]:
 line=next(x for x in lines if label+'=' in x)
 raw=line.split(label+'=',1)[1]
 obj=json.loads(raw)
 claim=obj.pop(field)
 canonical=json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode('utf-8')
 computed='sha256:'+hashlib.sha256(canonical).hexdigest()
 print(label,'claim='+claim,'computed='+computed,'match='+str(claim==computed),'canonical_bytes='+str(len(canonical)))
 assert claim==computed
