package clonereadback_test
import (
 "testing"
 clonereadback "github.com/relux-works/agent-session-manager/internal/clonereadback"
)
func TestReviewValidationReportNeedsDistinctReadRefs(t *testing.T) {
 input := validReportInput()
 input.LiveReadBackEvidenceManifestID = input.StagedReadBackEvidenceManifestID
 sealed, err := clonereadback.BuildValidationReport(input)
 if err == nil {
  if _, decodeErr := clonereadback.DecodeValidationReport(sealed); decodeErr == nil {
   t.Fatal("same digest admitted as both staged and live with valid=true")
  }
 }
}
