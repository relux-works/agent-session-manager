package clonereadback_test
import (
 "testing"
 clonereadback "github.com/relux-works/agent-session-manager/internal/clonereadback"
)
func TestReviewResealedStagedRelabelRefuses(t *testing.T) {
 input := validReadBackInput()
 input.Mode = "staged"
 staged := mustBuildReadBack(t, input)
 document := decodeDocument(t, staged)
 document["mode"] = "live"
 document["read_back_evidence_manifest_id"] = independentSelfDigest(t, marshalDocument(t, document), "read_back_evidence_manifest_id")
 if _, err := clonereadback.DecodeReadBackEvidenceManifest(marshalDocument(t, document)); err == nil {
  t.Fatal("resealed staged evidence admitted as live")
 }
}
