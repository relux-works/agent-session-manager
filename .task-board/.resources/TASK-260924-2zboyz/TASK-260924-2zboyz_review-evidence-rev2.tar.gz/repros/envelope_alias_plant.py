#!/usr/bin/env python3
"""Apply the single-site Schema alias narrowing in a disposable candidate copy."""
from pathlib import Path
import subprocess
p=Path('internal/clonereadback/decode.go')
original=p.read_text()
anchor='return members, nil\n}'
replacement='if v, ok := members["Schema"]; ok { delete(members, "Schema"); members["schema"] = v }\n\treturn members, nil\n}'
assert original.count(anchor)==1
p.write_text(original.replace(anchor,replacement))
try:
 result=subprocess.run(['go','test','-count=1','./internal/clonereadback/'],check=False)
finally:
 p.write_text(original)
raise SystemExit(result.returncode)
