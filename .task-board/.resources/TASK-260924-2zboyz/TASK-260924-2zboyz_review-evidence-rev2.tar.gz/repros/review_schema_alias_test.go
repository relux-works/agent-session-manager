package clonereadback_test
import (
 "testing"
 clonereadback "github.com/relux-works/agent-session-manager/internal/clonereadback"
)
func TestReviewPlantSchemaAliasAdmitted(t *testing.T) {
 sealed := mustBuildReadBack(t, validReadBackInput())
 document := decodeDocument(t, sealed)
 document["Schema"] = document["schema"]
 delete(document, "schema")
 if _, err := clonereadback.DecodeReadBackEvidenceManifest(marshalDocument(t, document)); err != nil {
  t.Fatalf("plant did not admit miscased schema: %v", err)
 }
}
