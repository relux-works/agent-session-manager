from pathlib import Path
import subprocess, sys
root=Path(__file__).parent/'candidate3'
out=Path(__file__).parent/'own-plants'
out.mkdir(exist_ok=True)
rows=[
 ('alias-mode','internal/clonereadback/readback.go','\tif name, unknown := unknownMember(members, readBackMembers); unknown {','\tif raw, ok := members["Mode"]; ok { delete(members, "Mode"); members["mode"] = raw }\n\tif name, unknown := unknownMember(members, readBackMembers); unknown {','TestMemberCensusMiscased$'),
 ('relabel-live','internal/clonereadback/readback.go','\tif err := checkModeAuthority(owner, mode, expectedMode, authority.Purpose); err != nil {','\tif authority.Purpose == "target_staged" && mode == "live" { expectedMode = "live" }\n\tif err := checkModeAuthority(owner, mode, expectedMode, authority.Purpose); err != nil {','TestDecodeStagedAuthorityRefusesResealedLiveClaim$'),
 ('valid-marker-decode','internal/clonereadback/report.go','\tif err := checkValidAgreement(owner, valid, checks, expected, observed, findings); err != nil {','\tif !checks.SemanticMarkerValid { checks.SemanticMarkerValid = true }\n\tif err := checkValidAgreement(owner, valid, checks, expected, observed, findings); err != nil {','TestValidWholeDomainOracle$'),
 ('owner-object-bypass','internal/clonereadback/readback.go','\tif err != nil {\n\t\treturn ReadBackManifest{}, nil, invalid("%s observed_environment is not an Environment Tuple: %v", owner, err)\n\t}','\tif err != nil && (len(input.ObservedEnvironment) == 0 || input.ObservedEnvironment[0] != \'{\') {\n\t\treturn ReadBackManifest{}, nil, invalid("%s observed_environment is not an Environment Tuple: %v", owner, err)\n\t}','TestOwnerDelegation$'),
 ('head-bound-decode','internal/clonereadback/readback.go','checkSortedUniqueStrings(members["parsed_head_ids"], 1, 512, 0, maxParsedHeadIDs)','checkSortedUniqueStrings(members["parsed_head_ids"], 1, 512, 0, maxParsedHeadIDs+1)','TestParsedHeadIDsSweep$'),
 ('neutral-comment','internal/clonereadback/report.go','// checkReadRefs enforces that the report aggregates TWO distinct','// neutral reviewer control.\n// checkReadRefs enforces that the report aggregates TWO distinct','TestReportReadRefRelationOracle$'),
]
for name, rel, old, new, test in rows:
 path=root/rel
 original=path.read_text()
 if original.count(old)!=1:
  print(name,'ANCHOR',original.count(old),flush=True); continue
 path.write_text(original.replace(old,new))
 try:
  cmd=['go','test','-count=1','./internal/clonereadback/','-run',test]
  p=subprocess.run(cmd,cwd=root,text=True,capture_output=True,timeout=300)
  log=f'$ {" ".join(cmd)}\nexit={p.returncode}\n--- stdout ---\n{p.stdout}\n--- stderr ---\n{p.stderr}\n'
  (out/(name+'.log')).write_text(log)
  print(name,'exit',p.returncode,'expected',0 if name=='neutral-comment' else 1,flush=True)
 finally:
  path.write_text(original)
