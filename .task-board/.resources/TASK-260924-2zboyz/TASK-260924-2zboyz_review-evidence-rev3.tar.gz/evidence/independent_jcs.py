import pathlib, json, hashlib
path=pathlib.Path(__file__).parent/'fixture-dump.log'
for label,member in [('READBACK','read_back_evidence_manifest_id'),('LIVE','read_back_evidence_manifest_id'),('REPORT','validation_report_id')]:
    source=next(line.split(label+'=',1)[1] for line in path.read_text().splitlines() if label+'=' in line)
    document=json.loads(source)
    claimed=document.pop(member)
    # The fixture value domain contains integer numbers and no escaped control characters.
    canonical=json.dumps(document,ensure_ascii=False,separators=(',',':'),sort_keys=True,allow_nan=False).encode('utf-8')
    computed='sha256:'+hashlib.sha256(canonical).hexdigest()
    print(label, claimed, computed, claimed==computed, len(canonical))
    if claimed!=computed: raise SystemExit(1)
