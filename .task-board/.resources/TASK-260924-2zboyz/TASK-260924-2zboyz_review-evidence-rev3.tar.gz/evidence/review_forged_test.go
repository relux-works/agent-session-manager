package clonereadback_test

import (
 "testing"
 clonereadback "github.com/relux-works/agent-session-manager/internal/clonereadback"
 "github.com/relux-works/agent-session-manager/internal/scalar"
)

func TestReviewForgedReadSiblingsRefused(t *testing.T) {
 // These two IDs were minted by this caller; no read-back bytes exist for them.
 fakeStaged := clonereadback.ReadBackManifest{ManifestID: scalar.SHA256Digest([]byte("invented-staged")), Mode: "staged"}
 fakeLive := clonereadback.ReadBackManifest{ManifestID: scalar.SHA256Digest([]byte("invented-live")), Mode: "live"}
 input := validReportInput(fakeStaged, fakeLive)
 if _, err := clonereadback.BuildValidationReport(input, fakeStaged, fakeLive); err == nil {
  t.Error("Build accepted caller-minted read IDs with no read-back manifest bytes")
 }

 // Decode is independently driven with a valid report frame resealed
 // after replacing both references. It must refuse even if Build is fixed.
 realStaged, realLive := mustReadPair(t)
 sealed := mustBuildReport(t, validReportInput(realStaged, realLive), realStaged, realLive)
 document := decodeDocument(t, sealed)
 document["staged_read_back_evidence_manifest_id"] = fakeStaged.ManifestID.String()
 document["live_read_back_evidence_manifest_id"] = fakeLive.ManifestID.String()
 document["validation_report_id"] = independentSelfDigest(t, marshalDocument(t, document), "validation_report_id")
 if _, err := clonereadback.DecodeValidationReport(marshalDocument(t, document), fakeStaged, fakeLive); err == nil {
  t.Error("Decode accepted caller-minted read IDs with no read-back manifest bytes")
 }
}
