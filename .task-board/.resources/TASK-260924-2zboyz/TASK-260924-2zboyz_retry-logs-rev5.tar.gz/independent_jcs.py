import json, hashlib, sys
# Independent JCS (RFC 8785 subset: ASCII-only docs, no floats) + omit-self digest check.
def jcs(o):
    return json.dumps(o, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
fails = 0
for name, selfid in (("staged.json", "read_back_evidence_manifest_id"),
                     ("live.json", "read_back_evidence_manifest_id"),
                     ("report.json", "validation_report_id")):
    raw = open(f"{sys.argv[1]}/{name}", 'rb').read()
    doc = json.loads(raw)
    claimed = doc.pop(selfid)
    # also verify the sealed bytes themselves are already canonical (byte-exact JCS)
    canon_full = jcs(doc)
    recomputed = "sha256:" + hashlib.sha256(canon_full).hexdigest()
    ok = (recomputed == claimed)
    fails += (not ok)
    print(f"{name}: claimed={claimed[:19]}... recomputed={recomputed[:19]}... match={ok}")
    # verify canonical form: re-adding the id and re-canonicalizing must reproduce sealed bytes
    doc[selfid] = claimed
    print(f"  sealed-bytes-canonical={jcs(doc) == raw}")
sys.exit(1 if fails else 0)
