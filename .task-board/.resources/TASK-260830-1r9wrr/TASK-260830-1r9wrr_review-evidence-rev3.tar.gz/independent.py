from pathlib import Path
import subprocess,json,re,hashlib
out=Path(__file__).resolve().parent
root=out/'independent-copy';pkg=root/'internal/sessstate'
base={p.name:p.read_bytes() for p in pkg.glob('*.go')}
layers=json.loads((out/'gate/selectors.json').read_text())
selectors={k:'^('+'|'.join(v)+')$' for k,v in layers.items()}
results=[]
def run(label,args):
 with (out/(label+'.log')).open('w') as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 data=(out/(label+'.log')).read_text()
 row={'label':label,'command':args,'exit':r.returncode,'failures':re.findall(r'^\s*--- FAIL: ([^\s]+)',data,re.M)}
 results.append(row);(out/'independent-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True);return row
def restore():
 for name,data in base.items():(pkg/name).write_bytes(data)
 for p in pkg.glob('*.go'):
  if p.name not in base:p.unlink()
 assert all((pkg/n).read_bytes()==d for n,d in base.items())
probe='''package sessstate
import "testing"
func TestReviewerUnknownNeighbor(t *testing.T) {
 record:=decodeTestRecord(t)
 specs:=append(baseBootstrap(record),eventSpec{typ:"session.review_neighbor",payload:map[string]any{"note":"reviewer"}})
 got,err:=reduceSpecs(t,record,specs,Input{})
 if err!=nil {t.Fatal(err)}
 if got.State!=StateRunning {t.Fatalf("unknown changed state: %s",got.State)}
}
'''
wire='\tdefault:\n\t\treturn nil\n\t}\n}\n\n// effectCreated opens the bootstrap'
try:
 (pkg/'review_probe_test.go').write_text(probe)
 assert run('independent-baseline-probe',['go','test','./internal/sessstate','-count=1','-run','^TestReviewerUnknownNeighbor$','-v'])['exit']==0
 restore()
 for id,args,helper,killed in [
 ('Q1-alias-closure','event, name','''package sessstate
type reviewerAlias = Event
func (fold *chainFold) reviewExtra(event reviewerAlias,name string) error {
 read:=func() string {return event.Type}
 kind:=read()
 if kind=="session.review_neighbor" {return fold.step(StateIdle,name)}
 return nil
}
''',True),
 ('Q2-diagnostic-residual','name','''package sessstate
import "strings"
func (fold *chainFold) reviewExtra(name string) error {
 if strings.HasPrefix(name,"event session.review_neighbor ") {return fold.step(StateIdle,name)}
 return nil
}
''',False)]:
  restore();p=pkg/'sessstate.go';s=p.read_text();assert s.count(wire)==1
  p.write_text(s.replace(wire,wire.replace('return nil','return fold.reviewExtra('+args+')',1),1))
  (pkg/'review_extra.go').write_text(helper)
  assert run(id+'-build',['go','build','./internal/sessstate'])['exit']==0
  for layer,selector in selectors.items():
   r=run(id+'-'+layer,['go','test','./internal/sessstate','-count=1','-run',selector,'-v'])
   if killed and layer=='census':assert r['exit']==1 and 'TestEventTypeUsesAreOwned' in r['failures']
   else:assert r['exit']==0
  (pkg/'review_probe_test.go').write_text(probe)
  r=run(id+'-probe',['go','test','./internal/sessstate','-count=1','-run','^TestReviewerUnknownNeighbor$','-v'])
  assert r['exit']==1 and 'TestReviewerUnknownNeighbor' in r['failures']
 restore()
 (pkg/'evidence_counts_test.go').write_bytes((out/'producer/measure.go.txt').read_bytes())
 assert run('independent-counts',['go','test','./internal/sessstate','-count=1','-run','^TestEvidenceCensusCounts$','-v'])['exit']==0
finally:
 restore()
 (out/'independent-restored.json').write_text(json.dumps({n:hashlib.sha256(d).hexdigest() for n,d in base.items()},indent=2)+'\n')
