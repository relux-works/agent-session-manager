#!/bin/bash
# sessstate mutation battery. Usage: ./mutate.sh [ID...]
# With no IDs, runs the whole battery. Each mutant applies one exact-once
# source replacement to a production file, rebuilds, and runs two gates:
#   BEH  = go test -run '.*' (TestMain audits skip: test.run is set)
#   FULL = go test (every audit runs)
# KILLED(behavioral): BEH red. KILLED(census-only|audit-only): BEH green,
# FULL red. SURVIVED: both green. NOT_APPLIED: pattern count != 1.
# COMPILE_FAIL: the mutant tree does not build. Every run restores the
# file from backup, so the tree is clean at the end. Controls XN/XK
# assert the harness itself: XN is behaviour-neutral and must reach
# both gates green (proving SURVIVED is reportable), XK is known-bad
# and must redden (proving KILLED is reportable). A control that
# misbehaves prints HARNESS-FAIL and exits nonzero.
set -u
PKG=./internal/sessstate
BK=.temp/TASK-260830-1r9wrr/backup
mkdir -p "$BK"
for f in sessstate.go decode.go project.go; do
  [ -f "$BK/$f" ] || cp "internal/sessstate/$f" "$BK/$f"
done

run_one() {
  local ID="$1" FILE="$2" OLD="$3" NEW="$4" WANT="$5"
  local F="internal/sessstate/$FILE"
  cp "$BK/$FILE" "$F"
  local COUNT
  COUNT=$(python3 -c "import sys; s=open('$F').read(); sys.stdout.write(str(s.count(sys.argv[1])))" "$OLD")
  if [ "$COUNT" != "1" ]; then echo "$ID: NOT_APPLIED (pattern count=$COUNT)"; cp "$BK/$FILE" "$F"; return; fi
  python3 -c "import sys; p='$F'; s=open(p).read(); s=s.replace(sys.argv[1], sys.argv[2], 1); open(p,'w').write(s)" "$OLD" "$NEW"
  if ! go build "$PKG" >/dev/null 2>&1; then echo "$ID: COMPILE_FAIL"; cp "$BK/$FILE" "$F"; return; fi
  local BEH FULL
  if go test "$PKG" -count=1 -run '.*' >"/tmp/sess_beh_$ID.log" 2>&1; then BEH=PASS; else BEH=FAIL; fi
  if go test "$PKG" -count=1 >"/tmp/sess_full_$ID.log" 2>&1; then FULL=PASS; else FULL=FAIL; fi
  local K
  if [ "$BEH" = "FAIL" ]; then K="KILLED(behavioral)";
  elif [ "$FULL" = "FAIL" ]; then
    case "$WANT" in
      census-only) K="KILLED(census-only)";;
      audit-only) K="KILLED(audit-only)";;
      *) K="KILLED(census-only)";; # BEH green + FULL red without a named layer is still a census kill
    esac
  else K="SURVIVED"; fi
  echo "$ID: $K  behavioral=$BEH full=$FULL"
  if [ "$BEH" = "FAIL" ]; then grep -E "^\s*--- FAIL" "/tmp/sess_beh_$ID.log" | head -4; fi
  if [ "$BEH" = "PASS" ] && [ "$FULL" = "FAIL" ]; then grep -E "sessstate (refusal|sentinel|exercised|observed)|outside direct-call|outside the refuse funnel|unregistered|orphan" "/tmp/sess_full_$ID.log" | head -4; fi
  cp "$BK/$FILE" "$F"
}

N() { run_one "$1" "$2" "$3" "$4" narrowing; }
D() { run_one "$1" "$2" "$3" "$4" arm-deletion; }
C() { run_one "$1" "$2" "$3" "$4" census-only; }
A() { run_one "$1" "$2" "$3" "$4" audit-only; }

ALL="$*"
want() { [ -z "$ALL" ] && return 0; case " $ALL " in *" $1 "*) return 0;; *) return 1;; esac; }

echo "== baseline =="
if go test "$PKG" -count=1 >/dev/null 2>&1; then echo "baseline green"; else echo "BASELINE RED"; exit 1; fi

echo "== narrowing: winner and transition gates =="
want N1 && N N1 sessstate.go 'case a.LeaseID < b.LeaseID:
		return -1' 'case a.LeaseID < b.LeaseID:
		return 1'
want N2 && N N2 sessstate.go 'if lease.Epoch > fold.current.Epoch+1 {' 'if lease.Epoch > fold.current.Epoch+2 {'
want N3 && N N3 sessstate.go 'if !hasCheckpoint || !resumable {
			return refuse(ErrIntegrity, "%s closes checkpointed without a resumable checkpoint", what)' 'if !resumable {
			return refuse(ErrIntegrity, "%s closes checkpointed without a resumable checkpoint", what)'
want N4 && N N4 sessstate.go 'if fold.seenAbort {
		return refuse(ErrInvalidTransition, "%s retries bootstrap past an authoritative abort", what)' 'if fold.seenAbort && fold.seenCheckpoint {
		return refuse(ErrInvalidTransition, "%s retries bootstrap past an authoritative abort", what)'
want N5 && N N5 sessstate.go 'if providerID != fold.recordProvider {
		return refuse(ErrIntegrity, "%s repeats provider %q past record provider %q", what, providerID, fold.recordProvider)' 'if providerID != fold.recordProvider && providerID != "qwen" {
		return refuse(ErrIntegrity, "%s repeats provider %q past record provider %q", what, providerID, fold.recordProvider)'
want N6 && N N6 sessstate.go '	StateCreating: {}, StateRunning: {}, StateIdle: {}, StateFailed: {},' '	StateCreating: {}, StateRunning: {}, StateIdle: {}, StateFailed: {}, StateStopped: {},'
want N7 && N N7 sessstate.go '	default:
		return nil
	}
}

// effectCreated opens the bootstrap' '	default:
		return fold.step(StateIdle, name)
	}
}

// effectCreated opens the bootstrap'
want N8 && N N8 sessstate.go 'if successor != lease.LeaseID {
			return refuse(ErrIntegrity, "%s transfers to lease %s outside its envelope lease %s", what, successor, lease.LeaseID)' 'if successor != lease.LeaseID && successor != "cccccccc-dddd-4eee-8fff-000000000000" {
			return refuse(ErrIntegrity, "%s transfers to lease %s outside its envelope lease %s", what, successor, lease.LeaseID)'
want N9 && N N9 sessstate.go 'if hasCheckpoint || resumable {
		return refuse(ErrIntegrity, "%s closes bootstrap_abort with a checkpoint or resumable set", what)' 'if hasCheckpoint && resumable {
		return refuse(ErrIntegrity, "%s closes bootstrap_abort with a checkpoint or resumable set", what)'

echo "== narrowing: read and recovery paths =="
want N10 && N N10 project.go 'if found.Parked {' 'if found.Parked && found.RetryHint == "" {'
want N11 && N N11 sessstate.go '	if providerID != fold.recordProvider {
		fold.conflict(ConflictProviderMismatch, ResolveRuleRecordPinnedProviderWins,' '	if providerID != fold.recordProvider && providerID != "qwen" {
		fold.conflict(ConflictProviderMismatch, ResolveRuleRecordPinnedProviderWins,'
want N12 && N N12 sessstate.go 'if payloadEpoch != fold.createLease.Epoch || payloadLease != fold.createLease.LeaseID {' 'if payloadLease != fold.createLease.LeaseID {'

echo "== arm-deletion =="
want D1 && D D1 sessstate.go '	if _, ok := allowedTransitions[fold.state][target]; !ok {
		return refuse(ErrInvalidTransition, "%s moves %q to %q without a Section 5.7 edge", what, string(fold.state), string(target))' '	if _, ok := allowedTransitions[fold.state][target]; !ok {
		fold.state = target
		return nil'
want D2 && D D2 sessstate.go '		if lease.Epoch == fold.current.Epoch {
			return false, refuse(ErrDivergentLease, "event %s under lease %s diverges from chain head lease %s at epoch %d", event.ID, lease.LeaseID, fold.current.LeaseID, fold.current.Epoch)
		}' '		if false {
			return false, refuse(ErrDivergentLease, "planted", event.ID)
		}'
want D3 && D D3 sessstate.go '	default:
		return false, refuse(ErrStaleLease, "event %s lease epoch %d precedes chain head epoch %d", event.ID, lease.Epoch, fold.current.Epoch)' '	default:
		fold.trackTail(event)
		return false, nil'
want D4 && D D4 sessstate.go '	if input.Parked != nil {
		projection.State = StateParked' '	if input.Parked != nil && false {
		projection.State = StateParked'
want D5 && D D5 sessstate.go '	providerID, err := payloadString(event.Payload, "provider_id")
	if err != nil {
		return err
	}
	if providerID != fold.recordProvider {
		return refuse(ErrIntegrity, "%s repeats provider %q past record provider %q", what, providerID, fold.recordProvider)
	}' '	providerID, err := payloadString(event.Payload, "provider_id")
	if err != nil {
		return err
	}
	_ = providerID'
want D6 && D D6 sessstate.go '	if event.LeaseEpoch != 1 || event.LeaseID != fold.createLease.LeaseID ||
		event.LeaseEpoch != fold.createLease.Epoch {
		return refuse(ErrInvalidTransition, "%s retries bootstrap under a new lease", what)' '	if false {
		return refuse(ErrInvalidTransition, "%s retries bootstrap under a new lease", what)'
want D7 && D D7 sessstate.go '	if !containsString(event.Predecessors, tail) {
		return refuse(ErrInvalidTransition, "event %s predecessors omit prior authoritative event", event.ID)' '	if !containsString(event.Predecessors, tail) && false {
		return refuse(ErrInvalidTransition, "event %s predecessors omit prior authoritative event", event.ID)'
want D8 && D D8 sessstate.go '	if target == "" || target == fold.state {
		return nil
	}' '	if target == "" {
		return nil
	}'

echo "== TestMain-only kills (behavioral green, full-package red) plus one roster-test kill =="
want C1 && C C1 sessstate.go '	case "sync.completed":
		return nil' '	case "sync.completed":
		_ = refuse(ErrInvalidEvent, "planted unrouted refusal")
		return nil'
want A1 && A A1 sessstate.go '	case "sync.completed":
		return nil' '	case "sync.completed":
		var deny = refuse; _ = deny; return nil'
want A2 && A A2 sessstate.go '	case "sync.completed":
		return nil' '	case "sync.completed":
		func() { refuse := 0; _ = refuse }(); return nil'
want A3 && A A3 sessstate.go '	case "sync.completed":
		return nil' '	case "sync.completed":
		_ = fmt.Errorf("%w: planted", ErrInvalidEvent); return nil'

echo "== census-test kills (the state and event censuses are tests, so both gates redden) =="
want T1 && run_one T1 sessstate.go '	StateCreating      State = "creating"' '	StateCreating      State = "created"' narrowing
want T2 && run_one T2 sessstate.go '	case "sync.completed":' '	case "sync.completed", "session.future":' narrowing

echo "== narrowing: union and local-lease derivation (F1/F2 regression rows) =="
want N13 && N N13 sessstate.go '		case 0:
			// A duplicate union entry names the tuple already
			// selected: the winner and the off-chain flag stand.
			// Clearing here would drop a correctly recorded
			// union_supersedes_chain conflict (and its
			// divergent_history warning) on a repeated entry.' '		case 0:
			if _, ok := onChain[lease.LeaseID]; !ok {
				offChainWinner = false
			}'
want N14 && N N14 sessstate.go '	if Compare(local, fold.projection.Winner) >= 0 {' '	if Compare(local, fold.projection.Winner) == 0 {'

echo "== harness controls (both compile and reach both gates) =="
run_control() {
  local ID="$1" FILE="$2" OLD="$3" NEW="$4" EXPECT="$5"
  local F="internal/sessstate/$FILE"
  cp "$BK/$FILE" "$F"
  local COUNT
  COUNT=$(python3 -c "import sys; s=open('$F').read(); sys.stdout.write(str(s.count(sys.argv[1])))" "$OLD")
  if [ "$COUNT" != "1" ]; then echo "$ID: HARNESS-FAIL (pattern count=$COUNT)"; cp "$BK/$FILE" "$F"; exit 1; fi
  python3 -c "import sys; p='$F'; s=open(p).read(); s=s.replace(sys.argv[1], sys.argv[2], 1); open(p,'w').write(s)" "$OLD" "$NEW"
  if ! go build "$PKG" >/dev/null 2>&1; then echo "$ID: HARNESS-FAIL (control does not compile)"; cp "$BK/$FILE" "$F"; exit 1; fi
  local BEH FULL
  if go test "$PKG" -count=1 -run '.*' >"/tmp/sess_beh_$ID.log" 2>&1; then BEH=PASS; else BEH=FAIL; fi
  if go test "$PKG" -count=1 >"/tmp/sess_full_$ID.log" 2>&1; then FULL=PASS; else FULL=FAIL; fi
  local GOT
  if [ "$BEH" = "FAIL" ]; then GOT="KILLED";
  elif [ "$FULL" = "FAIL" ]; then GOT="KILLED";
  else GOT="SURVIVED"; fi
  if [ "$GOT" != "$EXPECT" ]; then echo "$ID: HARNESS-FAIL (got $GOT behavioral=$BEH full=$FULL, want $EXPECT)"; cp "$BK/$FILE" "$F"; exit 1; fi
  echo "$ID: CONTROL-OK ($GOT as intended)  behavioral=$BEH full=$FULL"
  if [ "$BEH" = "FAIL" ]; then grep -E "^\s*--- FAIL" "/tmp/sess_beh_$ID.log" | head -4; fi
  cp "$BK/$FILE" "$F"
}
want XN && run_control XN sessstate.go 'func (fold *chainFold) tailEventID() string { return fold.tailID }' 'func (fold *chainFold) tailEventID() string { return "" + fold.tailID }' SURVIVED
want XK && run_control XK sessstate.go '	StateRunning: {}, StateIdle: {}, StateQuiescing: {},
	StateFailed: {}, StateParked: {},' '	StateRunning: {}, StateIdle: {}, StateQuiescing: {},
	StateFailed: {}, StateParked: {}, StateStopped: {},' KILLED

echo "== results =="
for id in N1 N2 N3 N4 N5 N6 N7 N8 N9 N10 N11 N12 N13 N14 D1 D2 D3 D4 D5 D6 D7 D8 C1 A1 A2 A3 T1 T2 XN XK; do
  case " $ALL " in ""|" "*$id*" ") :;; *) continue;; esac
done
echo "(see rows above)"
