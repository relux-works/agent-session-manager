from pathlib import Path
import subprocess,os,re,json,shlex,hashlib,sys
source=Path(os.environ.get('SESSSTATE_WORKTREE','/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3tq4ns/worktree'))
out=Path(__file__).resolve().parent
copy=out/'candidate-copy'
copy.mkdir(exist_ok=True)
(copy/'internal').mkdir(exist_ok=True)
for name in ['go.mod','go.sum']:(copy/name).write_bytes((source/name).read_bytes())
for path in (source/'internal').iterdir():
 if path.name!='sessstate' and not (copy/'internal'/path.name).exists():(copy/'internal'/path.name).symlink_to(path,target_is_directory=path.is_dir())
pkg=copy/'internal/sessstate';pkg.mkdir(exist_ok=True)
for path in (source/'internal/sessstate').glob('*.go'):(pkg/path.name).write_bytes(path.read_bytes())
base={p.name:p.read_bytes() for p in pkg.glob('*.go')}
discovery=subprocess.run(['go','test','./internal/sessstate','-run','^$','-list','^Test'],cwd=copy,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
(out/'test-discovery.log').write_text(discovery.stdout)
(out/'test-discovery-command.json').write_text(json.dumps({'command':['go','test','./internal/sessstate','-run','^$','-list','^Test'],'exit':discovery.returncode})+'\n')
assert discovery.returncode==0
compiled=set(re.findall(r'^Test\w+$',discovery.stdout,re.M))
layers={'behavior':[],'census':[],'audit':[]}
for p in pkg.glob('*_test.go'):
 for name in re.findall(r'^func (Test\w+)\(',p.read_text(),re.M):
  if name not in compiled or name in ['TestMain','TestCensusLiveEventOwnershipPlants']:continue
  layer='audit' if name=='TestSessstateStaticAudit' else ('census' if p.name.startswith('census') else 'behavior')
  layers[layer].append(name)
selectors={k:'^('+'|'.join(sorted(v))+')$' for k,v in layers.items()}
assert all(layers.values())
assert len(set(sum(layers.values(),[])))==sum(map(len,layers.values()))
(out/'selectors.json').write_text(json.dumps(layers,indent=2)+'\n')
commands=[]
def run(label,args,timeout=240):
 with (out/(label+'.log')).open('w') as f:
  r=subprocess.run(args,cwd=copy,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
 data=(out/(label+'.log')).read_text()
 failures=re.findall(r'^\s*--- FAIL: ([^\s]+)',data,re.M)
 row={'label':label,'command':args,'exit':r.returncode,'failures':failures}
 commands.append(row)
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 return row

def restore():
 for name,data in base.items():(pkg/name).write_bytes(data)
 for p in pkg.glob('*.go'):
  if p.name not in base:p.unlink()
 assert all((pkg/name).read_bytes()==data for name,data in base.items())

mode=sys.argv[1] if len(sys.argv)>1 else 'gate'
try:
 for layer in selectors:
  assert run(mode+'-baseline-'+layer,['go','test','./internal/sessstate','-count=1','-run',selectors[layer]])['exit']==0
 if mode=='gate':
  p=pkg/'census_state_test.go'
  old='for _, site := range unregistered {\n\t\tfailures = append(failures, "unregistered event-type use'
  new='for _, site := range unregistered {\n\t\tif strings.HasSuffix(site, "|kind := event.Type") { continue }\n\t\tfailures = append(failures, "unregistered event-type use'
  s=p.read_text();assert s.count(old)==1
  p.write_text(s.replace(old,new,1))
  assert run('G-N-build',['go','build','./internal/sessstate'])['exit']==0
  r=run('G-N-composed',['go','test','./internal/sessstate','-count=1','-run','^TestCensusLiveEventOwnershipPlants$','-v'])
  assert r['exit']!=0 and 'TestCensusLiveEventOwnershipPlants/PB' in r['failures'],r
 else:
  tokens=shlex.split((out/'legacy-mutants.sh').read_text(),comments=True)
  mutants=[]
  for i,tok in enumerate(tokens):
   if tok=='want' and i+8<len(tokens) and tokens[i+2]=='&&' and tokens[i+3] in ['N','D','C','A','run_one','run_control']:
    kind,id,file,old,new=tokens[i+3:i+8]
    if not re.fullmatch(r'(N|D|C|A|T|X)[A-Z0-9]+',id):continue
    mutants.append((kind,id,file,old,new))
  assert len(mutants)==30,len(mutants)
  results=[]
  for kind,id,file,old,new in mutants:
   restore();p=pkg/file;s=p.read_text()
   assert s.count(old)==1,(id,s.count(old))
   p.write_text(s.replace(old,new,1))
   row={'id':id,'category':{'N':'narrowing','D':'arm-deletion','C':'census-only','A':'audit-only'}.get(kind,'census-only' if id.startswith('T') else 'control'),'old':old,'new':new,'file':file}
   row['build']=run(id+'-build',['go','build','./internal/sessstate'])
   assert row['build']['exit']==0,(id,'COMPILE_FAIL')
   row['gates']={layer:run(id+'-'+layer,['go','test','./internal/sessstate','-count=1','-run',selector]) for layer,selector in selectors.items()}
   failures=[layer for layer,g in row['gates'].items() if g['exit']!=0]
   row['classification']=failures[0]+'-kill' if failures else 'SURVIVED'
   if id=='XN':assert not failures,row
   if id=='XK':assert failures and row['gates']['behavior']['failures'],row
   results.append(row)
   (out/'battery-results.json').write_text(json.dumps(results,indent=2)+'\n')
finally:
 restore()
 (out/(mode+'-integrity.json')).write_text(json.dumps({name:hashlib.sha256(data).hexdigest() for name,data in base.items()},indent=2)+'\n')
