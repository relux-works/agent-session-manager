from pathlib import Path
import json,os,subprocess,re,collections,hashlib,tarfile
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3tq4ns/worktree')
os.chdir(root)
out=Path(__file__).resolve().parent
logs=root/'.temp/TASK-260830-1r9wrr'
# Re-derive only after the last managed artifact. A detached index leaves the
# Story's real index and signed checkpoint untouched.
idx=out/'delivery.index'
if idx.exists():idx.unlink()
env=dict(os.environ,GIT_INDEX_FILE=str(idx))
for args in [['git','read-tree','HEAD'],['git','add','--','LOGBOOK.md','README.md','internal/sessstate']]:subprocess.run(args,env=env,check=True)
tree=subprocess.check_output(['git','write-tree'],env=env,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
paths=subprocess.check_output(['git','diff','--name-only',head,tree],text=True).splitlines()
rework=subprocess.check_output(['git','diff','--name-only','6bdd953fb044b5b5fad568f94fcff86477e9d7fb',tree],text=True).splitlines()
assert len(paths)==16 and head=='0d9d0ad5acee26fed7bff78b605a07ff5230242c'
assert all(p in ['LOGBOOK.md','README.md'] or p.startswith('internal/sessstate/') for p in paths)
for filename,base in [('TASK-260830-1r9wrr_candidate-rev3.patch',head),('review-delta.patch','6bdd953fb044b5b5fad568f94fcff86477e9d7fb')]:
 with (out/filename).open('wb') as f:subprocess.run(['git','diff','--binary',base,tree],stdout=f,check=True)
identity={'checkpoint':head,'candidate_tree':tree,'paths':paths,'rework_paths':rework,'real_index_tree':subprocess.check_output(['git','write-tree'],text=True).strip(),'worktree_commit_gap_to_local_main':subprocess.check_output(['git','rev-list','--count','HEAD..main'],text=True).strip()}
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
mutants=json.loads((out/'battery-results.json').read_text())
production=[m for m in mutants if not m['id'].startswith('X')]
assert len(production)==28
counts=collections.Counter(m['classification'] for m in production)
assert counts=={'behavior-kill':22,'census-kill':3,'audit-kill':3},counts
categories=collections.Counter(m['category'] for m in production)
assert categories=={'narrowing':14,'arm-deletion':8,'census-only':3,'audit-only':3},categories
measured=json.loads(re.search(r'MEASURE (\{.*\})',(out/'census-measure-03.log').read_text()).group(1))
full=logs.joinpath('full-test-03.log').read_text()
coverage=logs.joinpath('coverage-03.log').read_text()
full_packages=len(re.findall(r'^ok\s+',full,re.M))
coverage_packages=len(re.findall(r'^ok\s+',coverage,re.M))
coverage_value=re.search(r'^ok\s+\S+/sessstate\s+.*coverage: ([\d.]+%)',coverage,re.M).group(1)
local_rows=len(re.findall(r'--- PASS: TestReduceEmptyChainLocalIsIgnored/[^\s/]+/[^\s/]+',full))
assert full_packages==25 and coverage_packages==25 and local_rows==14
old=(root/'.temp/TASK-260830-1r9wrr/review-rev2-astra/outcome.md').read_text()
ac=old[old.index('## AC coverage:'):old.index('## Gate table')]
descriptions={}
for line in old.splitlines():
 if line.startswith('| '):
  cells=line.split('|')
  match=re.match(r'\s*([NDCTXA]\w*)\b',cells[1])
  if match:descriptions[match.group(1)]=cells[2].strip()
table=['| Mutant | Category / narrowing or change | B / C / A exits | Named failing test; survival bound |','| --- | --- | --- | --- |']
for m in mutants:
 gates=m['gates'];exits=' / '.join(str(gates[k]['exit']) for k in ['behavior','census','audit'])
 layer=next((k for k in ['behavior','census','audit'] if gates[k]['exit']!=0),None)
 if layer:
  assert gates[layer]['failures'],m
  named='; '.join('`'+n+'`' for n in gates[layer]['failures'][:2])
 else:named='SURVIVED: identity transform only (`"" + tailID`); no general safety claim'
 table.append(f"| {m['id']} | {m['category']}: {descriptions.get(m['id'],'control')} | {exits} | {named} |")
validation=[('go test ./... -v',0,'full-test-03.log'),('go test ./... -cover',0,'coverage-03.log'),('go build ./...',0,'build-03.log'),('go vet ./...',0,'vet-03.log'),('go run ./internal/traceability/cmd/tracecheck',0,'tracecheck-03.log'),("go test ./internal/sessstate -count=1 -run '^TestReduceEmptyChainLocalIsIgnored$' -v",0,'local-bound-01.log'),("go test ./internal/sessstate -count=1 -run '^TestCensusLiveEventOwnershipPlants$' -v",0,'live-ownership-02.log'),('python3 battery.py all',0,'battery-03.log'),('python3 battery.py gate',0,'gate-narrowing-03.log')]
(out/'validation-observed.json').write_text(json.dumps([{'command':c,'exit':rc,'log':l} for c,rc,l in validation],indent=2)+'\n')
text=f'''# TASK-260830-1r9wrr — developer evidence for review, rev3

Candidate tree: `{tree}`. Signed Story checkpoint remains `{head}`.
No manual commit, branch switch, rebase, sibling run, upstream #176/#177 work,
or change to sessrepo/provhost occurred. Managed developer handoff owns the
candidate publication; independent review/checkpoint/integration belong to
the orchestrator. Exactly {len(paths)} CR paths, enumerated below. This rework
changes {len(rework)} of those paths against rev2; runtime implementation bytes
are preserved (only documentation and tests change in this rework).

## R2-F1: prerequisite established before broader rework

The already-attached `TASK-260830-1r9wrr_missing-gate-prerequisite.md` records
the gate-first ordering. Every direct Type-field use is derived via invcore,
classified by exact owning AST context and matched both directions. Aliases,
helper arguments, address-taking, package bindings, writes, closures and
unclassifiable contexts cannot silently disappear from that denominator.
Existing diagnostic expressions, effect dispatch and lease subtype comparison
remain the four classified uses; there is no list of newly guessed event names.
`TestEventTypeUsesAreOwned` runs with the event-spelling census in every
unfiltered suite. `TestSessstateStaticAudit` separately exposes static audits.

Residual bound: this is direct-field-access ownership, not whole-program taint
analysis. Reflection/unsafe/serialization of whole Event values and downstream
interpretation of permitted diagnostic strings are not proved. Other selectors
named Type are conservatively rejected for classification. This explicitly
withdraws the old exhaustive arbitrary-dispatch claim. No product redesign or
runtime validation was added to conceal the limitation.

The permanent `TestCensusLiveEventOwnershipPlants` compiles and wires the
reviewer plants into `Reduce -> apply -> effect -> reviewExtra -> step`,
executes separate behavior/census/audit selectors, then adds an independent
control-effect probe. All subprocess commands and real exits are retained in
full logs. The temporary copy is restored; the managed package is untouched.

| Mutant | Narrowing / behavior change | Build | B / C / A exits | Named failing test / survival bound |
| --- | --- | --- | --- | --- |
| PA | direct unknown selector handler | 0 | 0 / 1 / 0 | TestEventHandlingIsCensused; TestEventTypeUsesAreOwned |
| PB | copied kind switched in helper | 0 | 0 / 1 / 0 | TestEventTypeUsesAreOwned |
| PC | Type passed to string helper | 0 | 0 / 1 / 0 | TestEventTypeUsesAreOwned |
| PD | pointer to Type read in helper | 0 | 0 / 1 / 0 | TestEventTypeUsesAreOwned |
| live XN | identity-transform tail ID | 0 | 0 / 0 / 0 | SURVIVED: behavior-neutral identity transform only |
| live XK | inert default changed to idle, selector/case tokens preserved | 0 | 1 / 0 / 0 | TestReduceTreatsUnknownV1TypeAsInert |
| G-N | gate permits only the kind := event.Type copy while every other use still requires ownership | 0 | composed wrapper exit 1 | TestCensusLiveEventOwnershipPlants/PB |

4 of 4 dispatch plants killed, all census-only; 0 of 4 behavioral kills.
The post-gate `TestPlantUnknownV1Effect` is generated from each plant's unknown
literal and fails at Reduce with idle (expected exit 1) in all four cases.
Those probes establish live control effects, not additional delivered behavior
coverage. PB/PC/PD and XK retain the old searched tokens. G-N is an applied
narrowing, not a deletion: baseline green, weakened PB census green, permanent
live-control wrapper red. Its `go test` exit 1 is expected-red evidence; the
Python harness exit 0 only verifies that expected failure. Parse-only ownership
controls are separate from compiling live controls.

## R2-F2: explicit empty-chain Local bound

`TestReduceEmptyChainLocalIsIgnored` drives {local_rows} combinations through
Reduce: absent/lesser/equal/greater/malformed/epoch-only/ID-only Local against
empty Union and a valid multi-entry Union with a selected winner. It compares
the entire Projection with the no-Local baseline, checks the named union
conflict, and pins creating plus unknown local role/owner. Local is intentionally
not validated when there is no authoritative event/process lease. README and
doc.go say so. Historical F7 closure now refers only to the Union half.

{ac}
The 10 of 10 mapping is carried from accepted rev2 review findings; the named
committed tests ran again in the full suite. Closed F1/F2/F4/F5/F6, canonical
enums, multiple predecessors and the existing create-window recovery tests
were preserved. Prior independent 64-call reviewer probe was accepted from
attached evidence and not repeated; committed purity coverage did run again.
The read-only projector owns no durable write window. Existing tests exercise
the four sessrepo create boundaries via secconftest and recover through Project.

## Validation run directly in this developer session

| Command | Real exit | Full log |
| --- | --- | --- |
'''
text+='\n'.join(f'| `{c}` | {rc} | `{l}` |' for c,rc,l in validation)
text+=f'''
| gofmt -l over all sessstate Go files | 0, empty output | format-03.log |
| git diff --check | 0, empty output | diff-check-03.log |

Full suite: {full_packages} package rows. Coverage: {coverage_packages} package
rows, sessstate {coverage_value}. Platform: Go 1.25.5, darwin/arm64. Native
build/test is the relevant target; Linux/Windows compile and full-repo race,
fuzz and remaining configured validation are not claimed in this pre-handoff
artifact. The observed handoff command returned exit 0, status to-review and checklist
27/27; it did not return a CR tree or execute the configured publication suite
in this live turn. Managed run completion captures the CR and its configured
validation after the headless session exits. That later system evidence must
not be confused with the checks already executed and attached here.
No tests were left running at handoff. The copy-local mutation and gate tests
use direct subprocess exit statuses; no tee/pipeline hides a gate status.

## Re-derived census and mutation measurements

After the last managed artifact: refusal sites {measured['refusals']} / rows
{measured['refusal_rows']} ({measured['by_file']}); states {measured['states']} /
rows {measured['state_rows']}; handled events {measured['events']} / rows
{measured['event_rows']}; Type uses {measured['uses']} / ownership rows
{measured['use_rows']}. `census-measure-03.log` derives these through the same
invcore functions, and baseline census tests require equality in both directions.
Unregistered/orphan/unclassifiable controls, import aliases and var bindings
remain in the committed suites. This is the production-derived inventory
against which selected mutations are reported, not a claim of one mutant per
refusal or exhaustive arbitrary-Go mutation coverage.

Legacy selected roster re-executed: {len(production)} killed / {len(production)}
applied, {counts['behavior-kill']} behavioral, {counts['census-kill']} census-only,
{counts['audit-kill']} audit-only; mutation categories: {categories['narrowing']}
narrowing, {categories['arm-deletion']} arm-deletion, {categories['census-only']}
census-only, {categories['audit-only']} audit-only. All compile (build exit 0).
Neutral XN survives with its bound; legacy XK fails its named stopped-state
test. These controls are excluded from the 28-member mutation denominator.
The four live dispatch plants and one gate-instrument narrowing are separately
reported above to avoid mixing selected-gate and instrument coverage.

B/C/A are disjoint anchored selectors: {len(json.loads((out/'selectors.json').read_text())['behavior'])}
behavioral tests, {len(json.loads((out/'selectors.json').read_text())['census'])}
census tests and one static-audit test. AST selection (live controls) and
compiled-test discovery (external runner) exclude the recursive live wrapper.
The TestMain runtime refusal census is exercised by the ordinary unfiltered
full-suite and coverage commands, not smuggled into the isolated layers.
A named failure is required for every kill below; full co-firing failures and
the exact source replacements are in `battery-results.json`. Mutant test
commands with exit 1 are expected failures; none is reported as passing.

'''
text+='\n'.join(table)
text+='''

## Candidate identity and exact CR paths

Detached-index commands: `GIT_INDEX_FILE=<task scratch>/delivery.index git
read-tree HEAD`, scoped `git add -- LOGBOOK.md README.md internal/sessstate`,
then `git write-tree`. The real index is read for identity only. The candidate
was re-derived after README, LOGBOOK and every code/test artifact; outcome
and archives live outside the managed worktree so they cannot change this tree.
The re-derived tree equals the attached `candidate-identity.json` record.
The managed CR must publish that same OID. Its record is not yet observable
before this headless run exits; the orchestrator must compare the published
CR tree to this attachment when routing independent review. The task-scoped candidate patch is exactly
HEAD-to-tree; review-delta.patch is the narrower rev2-to-tree delta.

```
'''+ '\n'.join(paths)+'\n```\n'
text+='\nCheckpoint gap to local main: '+identity['worktree_commit_gap_to_local_main']+' (local-ref evidence only, no remote-main freshness claim).\n'
(out/'TASK-260830-1r9wrr_outcome-rev3.md').write_text(text)
# Preserve full relevant logs outside the worktree before resource attachment.
for p in logs.iterdir():
 if p.is_file() and (p.name.endswith('-03.log') or p.name in ['live-ownership-02.log','local-bound-01.log','go-readiness.log','readiness-notes.log']):(out/p.name).write_bytes(p.read_bytes())
print(json.dumps({'tree':tree,'paths':len(paths),'rework_paths':len(rework),'census':measured,'mutation_counts':dict(counts),'packages':full_packages,'coverage':coverage_value},indent=2))
