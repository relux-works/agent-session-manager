# Review method

Run RUN-260907-cf1098, Codex gpt-6-astra high. Reviewer only.

Initial detached-index tree equals CR rev2, so no cancelled-reviewer restoration was needed. Production and test files in the managed Story workspace were never edited by this run. Mutation work uses two git archive copies of the exact candidate, under this task-scoped directory. The copied source is restored from bytes captured before each reviewer plant; the producer battery uses fresh copy-local backups.

The producer battery was relocated only to give it a fresh backup path and full task-scoped per-row logs. The harness source, mutation patterns, and gates were otherwise unchanged. Its behavioral label includes census tests; independently distinguish those failures by the failing test names. The reviewer plants additionally run only TestReduce/TestProject/TestWinner/TestProvider/TestDecode, then the producer all-tests gate, then unfiltered TestMain. The new unknown-v1 probe is installed only after measuring the shipped suite, so it cannot inflate the candidate's kill count.

Tool readiness: task-board status mutation succeeded first as requested; CLI help and git/rg/go/python versions saved in tool-readiness.log. Local managed Go skill was absent in the isolated worktree; read the same Curator-managed skill from the main checkout. No installs or global modifications.

Transient instrument failures: initial skill-location search exited 2 because adapters were absent here; task-board change-request is not a command (repaired by documented worktree status); the first relocated battery command was launched from the copy before creating its harness at the correct path (FileNotFoundError, shell exit 127 in producer-battery-rerun-01.log). No mutation applied in that failed start. Corrected setup and reran the battery as producer-battery-rerun-02.log. These are instrument failures, never kills. Web fetch of the pinned raw SPEC returned cache miss; used git show from the local normative repository at exact pinned commit 28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c.

Accepted prior evidence without reopening: canonical enums, multiple predecessors, firing of the four durable create-window crash points, 64-call purity/input/slice checks, and AC 10/10 mapping. The new full suite, cover, build, vet, tracecheck, and sessstate race were rerun. Windows and wider-package race were not rerun in this revision review. No changes to upstream #176/#177.
