from pathlib import Path
import subprocess,json,sys
root=Path(__file__).resolve().parent
candidate=root/'probe-candidate'
pkg=candidate/'internal/sessstate'
source=pkg/'sessstate.go'
base=source.read_bytes()
plant=pkg/'zz_reviewer_dispatch.go'
probe=pkg/'zz_reviewer_probe_test.go'
assert not plant.exists() and not probe.exists()
wire='\tdefault:\n\t\treturn nil\n\t}\n}\n\n// effectCreated opens the bootstrap'
assert base.decode().count(wire)==1
rows=[]
def run(label,args):
 with (root/(label+'.log')).open('w') as log:
  result=subprocess.run(args,cwd=candidate,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 return result.returncode
def restore():
 source.write_bytes(base)
 plant.unlink(missing_ok=True)
 probe.unlink(missing_ok=True)
try:
 probe.write_bytes((root/'reviewer-probes.go.txt').read_bytes())
 rc=run('reviewer-baseline-probes',['go','test','./internal/sessstate','-count=1','-run','^TestReviewer','-v'])
 assert rc==0,rc
 restore()
 shapes={
 'PA_direct_switch':('event, name','func (fold *chainFold) reviewExtra(event Event, name string) error { switch event.Type { case "session.reaped": return fold.step(StateIdle,name) }; return nil }'),
 'PB_var_binding':('event, name','func (fold *chainFold) reviewExtra(event Event, name string) error { kind := event.Type; switch kind { case "session.reaped": return fold.step(StateIdle,name) }; return nil }'),
 'PC_helper_argument':('event.Type, name','func (fold *chainFold) reviewExtra(kind string, name string) error { switch kind { case "session.reaped": return fold.step(StateIdle,name) }; return nil }'),
 }
 for name,(args,body) in shapes.items():
  restore()
  source.write_text(base.decode().replace(wire,wire.replace('return nil','return fold.reviewExtra('+args+')'),1))
  plant.write_text('package sessstate\n\n'+body+'\n')
  row={'id':name}
  row['build']=run(name+'-build',['go','build','./internal/sessstate'])
  if row['build']!=0:
   row['classification']='COMPILE_FAIL'
  else:
   row['behavior']=run(name+'-behavior',['go','test','./internal/sessstate','-count=1','-run','^Test(Reduce|Project|Winner|Provider|Decode)'])
   row['producer_gate']=run(name+'-producer-gate',['go','test','./internal/sessstate','-count=1','-run','.*'])
   row['full']=run(name+'-full',['go','test','./internal/sessstate','-count=1'])
   probe.write_bytes((root/'reviewer-probes.go.txt').read_bytes())
   row['independent_probe']=run(name+'-independent-probe',['go','test','./internal/sessstate','-count=1','-run','^TestReviewerUnknownV1Neighbor$','-v'])
   row['classification']='BEHAVIOR_KILL' if row['behavior'] else ('CENSUS_OR_AUDIT_KILL' if row['full'] else 'SURVIVED')
  rows.append(row)
  print(json.dumps(row),flush=True)
  (root/'reviewer-plants-results.json').write_text(json.dumps(rows,indent=2)+'\n')
finally:
 restore()
 assert source.read_bytes()==base
 print('Reviewer-owned plants removed; copied candidate source restored.',flush=True)
