# Untrusted Mesh RPC wire components

Owner: TASK-260830-z1yxg9 in STORY-260830-1kiyj6. Authority: embedded AX
v0.5.0 SPEC.md, commit `28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c`.
This is staged implementation; the complete task remains blocked on the
independent inbound SSH identity-to-configured-host association decision.

`EncodeRequest` / `DecodeRequest` and `EncodeSuccess` / `EncodeFailure` /
`DecodeResponse` implement the reusable wire surface. `EncodeRejection` can
frame a supported-version bootstrap failure despite an invalid body; it returns
no bytes for an unframeable identity/version/JSON/size. All output is LF-free
for `sshtransport.Session.Send`; input is one line from `Session.Receive`.
The codec does not open SSH or invoke those transport methods itself.

The package owns no responder, handshake state, authenticated identity,
capability advertisement, operation dispatch, or pending-request queue. Its
success means structural validity only. In particular, `Request.Hello().HostID`
is an untrusted claim, `Response.OK()` means only the envelope's `ok=true`, and
`OfferedLimits` computes minima without making them authenticated or installing
them on a connection. Repeating `DecodeResponse` is possible; this codec does
not claim replay resistance. Received randomness/freshness cannot be proven by
nonce shape validation. `NewNonce` obtains 256 random bits from crypto/rand.

## Implemented surface and traceability

| Pinned rule | Production call site | Named test | Bound |
| --- | --- | --- | --- |
| 11.2 exact envelopes, UUIDv7 ID echo; 17.1 containing version first | DecodeRequest, DecodeResponse, EncodeRequest, EncodeSuccess | TestPinnedHelloProfiles, TestRequestRefusals, TestResponseRefusals | Correlation of one supplied request; no connection sequencing |
| 1.6 closed objects and common JSON model | DecodeRequest/DecodeResponse through object/exact | TestFrameRefusals, TestRequestRefusals | Shared canonicaljson validates bytes; opaque operation semantics remain with operation owners |
| 11.2 fourteen-key hello map, nonce/echo and limit floors | DecodeRequest, DecodeResponse, Request.Hello, OfferedLimits | TestHelloRefusals, TestLimitsAndUntrustedIsolation | v2 arrays have 1–16 bytewise sorted unique semvers; selecting mutually supported versions remains TASK-260830-219okr |
| 11.8/11.9 exact historical 24/25-key maps | DecodeRequest/DecodeResponse | TestPinnedHelloProfiles, TestHelloRefusals | Exact pinned 2.0.0/3.0.0/4.0.0 syntax; no automatic major or minor negotiation |
| 11.3/11.8/11.9 inventory.roots 6/7/8 namespace vocabulary and bounds | DecodeRequest, DecodeResponse, EncodeSuccess | TestInventoryNamespacesAndCardinality | Explicit subsets remain valid; results must match requested namespaces. No Merkle digest verification, schema membership or object exchange |
| 11.2/15.1/17 static historical errors and bootstrap framing | EncodeFailure, DecodeResponse, EncodeRejection -> axerror.DecodeBound | TestHistoricalFailureBindings, TestBootstrapRejectionFraming | No responder chooses/sends the error or performs the required one-frame close |
| 11.2 8 MiB line bound | DecodeRequest, EncodeRequest, DecodeResponse | TestFrameRefusals, TestWriterAndAccessorBounds | Codec line limit; partial I/O is owned by sshtransport |

**0 of 7 full RPC AC rows are proven through an authenticated runtime consumer.**
Five rows have new component evidence (correlation, hello maps/nonce, inventory
namespace/cardinality, offered limits, historical errors). Bilateral admission
has no implementation; connection deadlines/recovery have predecessor transport
evidence only. Codec tests do not discharge the complete seven-row deliverable.
Tests are in the uncommitted task delta, awaiting the managed review/checkpoint
flow after the unresolved decision is supplied.

Other operation bodies are retained as isolated raw JSON objects, without
schema or permission validation. No caller may dispatch from this library's
success. Object limits are advertised structural offers; object decoding,
negotiated transfer enforcement and durable mutation/recovery remain with their
operation owners. There is no durable state change in this package, hence no
new crash/idempotency behavior to attest.

## Existing owners and unchanged decision

`sshtransport` already owns the fixed 8 MiB LF framing, bounded partial I/O,
process teardown and earlier-of-caller/configured RPC timeout. Section 6.2
provides the 300-second default and 10–3600-second configuration range; sections
11.2–11.3 do not define an additional numeric hello timeout. This package adds
no competing timer or stream pump. `peeridentity` retains configured identity
selection/comparison; `axerror` retains error validation and static binding.

The eventual responder still needs an independently authoritative association
between externally authenticated SSH identity/invocation and one configured
host, or an explicit human decision accepting membership-only semantics with
its cross-listed-host impersonation bound. The membership-only interpretation
is withdrawn. No expected-peer injection, verified flag, claim-selected target
or fallback is introduced here. TASK-260830-219okr and TASK-260830-2x16gz retain
their complete subsequent negotiation and hostile-peer obligations.

## Verification tools

| Purpose | Command | Output |
| --- | --- | --- |
| Component behavior | `go test ./internal/rpcwire -count=1 -v` | stdout; task logs in `.temp/TASK-260830-z1yxg9/` |
| Races and coverage | `go test ./internal/rpcwire -race -count=1 -cover` | stdout and task log |
| Behavioral narrowing and controls | `python3 internal/rpcwire/mutations.py --output .temp/TASK-260830-z1yxg9/mutations` | Per-mutant Go overlay, JSON events, real exit, named failures and Markdown table; source remains unchanged |
| Bounded fuzz smoke | `go test ./internal/rpcwire -run '^$' -fuzz '^FuzzUntrustedEnvelopes$' -fuzztime=100x -parallel=1` | stdout and task log |

The overlay harness accepts `--only NAME,NAME` for bounded reruns. A kill requires
an actual named failing behavioral test. Compile errors, empty test selections
and instrumentation failures are not kills. Survivors must retain explicit
bounds in the task outcome. No source-only check is added by this package.
