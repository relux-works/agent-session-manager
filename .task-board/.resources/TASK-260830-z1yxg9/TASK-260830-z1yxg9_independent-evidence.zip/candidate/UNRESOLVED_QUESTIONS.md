# Unresolved implementation decisions

## Inbound RPC identity association

Owner: primary coordinator for TASK-260830-z1yxg9, within
STORY-260830-1kiyj6. Status: unresolved; membership-only interpretation withdrawn.

Pinned AX v0.5.0 section 11.1 requires bilateral protocol host-ID verification
following external SSH authentication. The outbound transport independently
selects its configured Target. The fixed inbound `ax rpc serve --stdio` command
and current configuration do not define how the responder independently selects
the configured expected peer before reading its claimed host ID.

Required decision: approve an external SSH identity/invocation-to-configured-host
association contract, or explicitly accept membership-only inbound admission
with the bound that an authenticated SSH user can claim any listed host. The
second choice must be reconciled with the existing cross-listed-host spoofing
requirement; it is not currently approved. The independent association is the
recommended route for retaining that requirement.

`internal/rpcwire` now provides untrusted structural components. They do not
answer this question or authorize operation dispatch. Full RPC negotiation,
bilateral admission and TASK-260830-2x16gz hostile-peer conformance remain open.
The board's `TASK-260830-z1yxg9_independent-stop-packet.md` records evidence,
options, command exits and the preserved partial delta.
