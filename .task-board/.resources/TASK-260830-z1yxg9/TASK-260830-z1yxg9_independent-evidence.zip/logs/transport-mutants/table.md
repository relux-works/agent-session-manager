| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent size accumulator | none | 0 | neutral passed:  |
| known-bad | Adds a remote command token | TestOpenStructuredCommand | 1 | killed:  |
| send-plus-one | Admits exactly one excess outbound byte | TestDuplexAndSendBoundaries/oversize | 1 | killed:  |
| read-plus-one | Admits exactly one excess inbound byte | TestReceiveFailureAndLimits/oversize | 1 | killed:  |
| read-partial | Treats one unterminated success-shaped frame as EOF | TestReceiveFailureAndLimits/partial | 1 | killed:  |
| cancel-as-success | Suppresses explicit cancellation but keeps other failures | TestCancellationAndCleanup/stall | 1 | killed:  |
| rpc-timeout | Allows one extra second of process lifetime | TestCancellationAndCleanup/deadline | 1 | killed:  |
