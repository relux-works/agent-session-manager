| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent expression | none | 0 | neutral passed:  |
| known-bad | Fixed command changed, code still compiles | TestLoadPeerIdentityVersions | 1 | killed:  |
| protocol-grammar | Allows one malformed protocol ID through grammar only; exact identity gate subsumes it | none | 0 | survived: Grammar alone is subsumed by exact target-ID equality; malformed IDs still fail equality. No independent grammar kill claimed. |
| protocol-id | Admits one other allowlisted peer ID | TestProtocolIdentityRefusal | 1 | killed:  |
