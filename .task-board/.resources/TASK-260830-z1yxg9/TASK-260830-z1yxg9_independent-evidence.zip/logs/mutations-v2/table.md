| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | ---: | --- |
| neutral | Equivalent major value | none | 0 | neutral passed:  |
| known-bad | Wrong request accessor | TestPinnedHelloProfiles/2.0.0 | 1 | killed:  |
| line-plus-one | Admits exactly 8388609 bytes | TestFrameRefusals/oversize | 1 | killed:  |
| lf | Admits final LF in a line payload | TestFrameRefusals/newline | 1 | killed:  |
| protocol | Admits urn:other only | TestRequestRefusals/protocol | 1 | killed:  |
| request-uuid | Admits one UUIDv4 request ID | TestRequestRefusals/uuid | 1 | killed:  |
| closed-extra | Admits one extra=true member | TestRequestRefusals/extra | 1 | killed:  |
| correlation-id | Admits one mismatched request ID | TestResponseRefusals/id | 1 | killed:  |
| correlation-version | Admits mismatched response version 3 only | TestResponseRefusals/version | 1 | killed:  |
| nonce-echo | Admits the wrong echo fixture only | TestResponseRefusals/nonce-echo | 1 | killed:  |
| failure-binding | Admits Error 1.0 in RPC3 while retaining other bindings | TestHistoricalFailureBindings/3.0.0 | 1 | killed:  |
| rejection-shape | Admits request-shaped object without operation | TestBootstrapRejectionFraming/response | 1 | killed:  |
| hello-host | Admits one malformed host ID | TestHelloRefusals/host | 1 | killed:  |
| hello-platform | Admits ios only | TestHelloRefusals/platform | 1 | killed:  |
| hello-version | Admits one leading-zero version | TestHelloRefusals/ax-version | 1 | killed:  |
| nonce-short | Admits exactly 120 nonce bits | TestHelloRefusals/nonce-short | 1 | killed:  |
| line-floor | Admits line floor minus one | TestHelloRefusals/line-floor | 1 | killed:  |
| object-floor | Admits object floor minus one | TestHelloRefusals/object-floor | 1 | killed:  |
| contract-extra | Admits one forbidden error map key | TestHelloRefusals/error-key | 1 | killed:  |
| contract-seventeen | Admits exactly 17 versions | TestHelloRefusals/seventeen-versions | 1 | killed:  |
| contract-empty | Admits present empty version array | TestHelloRefusals/empty-versions | 1 | killed:  |
| contract-duplicate | Admits duplicate adjacent versions | TestHelloRefusals/duplicate-versions | 1 | killed:  |
| contract-unsorted | Admits one descending adjacent pair | TestHelloRefusals/unsorted-versions | 1 | killed:  |
| contract-semver | Admits v1.0.0 version string only | TestHelloRefusals/invalid-version | 1 | killed:  |
| v3-exact | Admits nonexact v3 lease array | TestHelloRefusals/exact-map-3.0.0 | 1 | killed:  |
| v4-exact | Admits nonexact v4 lease array | TestHelloRefusals/exact-map-4.0.0 | 1 | killed:  |
| offered-pair | Admits one cross-request limit pair | TestLimitsAndUntrustedIsolation | 1 | killed:  |
| namespace-empty | Admits nonnil empty namespace array | TestInventoryNamespacesAndCardinality/2.0.0 | 1 | killed:  |
| namespace-member | Admits credential namespace only | TestInventoryNamespacesAndCardinality/2.0.0 | 1 | killed:  |
| namespace-duplicate | Admits duplicate namespaces | TestInventoryNamespacesAndCardinality/2.0.0 | 1 | killed:  |
| namespace-sort | Admits event/blob descending pair | TestInventoryNamespacesAndCardinality/2.0.0 | 1 | killed:  |
| roots-missing | Admits one missing requested root | TestInventoryNamespacesAndCardinality/2.0.0/missing | 1 | killed:  |
| root-association | Admits event root in blob slot | TestInventoryNamespacesAndCardinality/2.0.0 | 1 | killed:  |
| common-data-model | Admits the duplicate protocol fixture while retaining the canonicalization call | TestFrameRefusals/duplicate | 1 | killed:  |
