package peeridentity_test

import (
 "errors"
 "testing"
 "github.com/relux-works/agent-session-manager/internal/config"
 "github.com/relux-works/agent-session-manager/internal/peeridentity"
)

// This is an architectural counterexample, not a shipped RPC or SSH test.
func TestResponderBindingIndependentSelectionControl(t *testing.T) {
 d := requireLoad(t, document(config.CurrentVersion)+peer(otherID, "other", "other.example"))
 expected := requireTarget(t, d, peerID)
 if err := expected.CheckProtocolHost(peerID); err != nil { t.Fatal(err) }
 if err := expected.CheckProtocolHost(otherID); !errors.Is(err, peeridentity.ErrHostIdentityMismatch) { t.Fatal("independently selected peer did not refuse another allowed ID") }
 if _, err := d.Resolve("unknown"); !errors.Is(err, peeridentity.ErrNotAllowlisted) { t.Fatal("unknown admitted") }
}

// EXPECTED RED: demonstrates why selecting the target from the peer's own
// claimed ID does not establish the independently expected inbound identity.
func TestResponderClaimSelectedTargetCannotAttestInboundIdentity(t *testing.T) {
 d := requireLoad(t, document(config.CurrentVersion)+peer(otherID, "other", "other.example"))
 claimed := otherID
 selfSelected := requireTarget(t, d, claimed)
 if err := selfSelected.CheckProtocolHost(claimed); err == nil {
  t.Fatal("claim-selected target accepts another configured identity; no independent inbound association was supplied")
 }
}
