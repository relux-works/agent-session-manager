import hashlib,json
def jcs(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def node(ns,p,ids):
    ids=sorted(set(i for i in ids if i[7:].startswith(p)))
    ch=[];leaf=[]
    if len(ids)==1: leaf=ids
    elif len(ids)>1:
        assert len(p)<64
        for l in sorted({i[7+len(p)] for i in ids}):
            c=node(ns,p+l,ids); ch.append({"count":c[0],"hash":c[1],"label":l})
    h="sha256:"+hashlib.sha256(jcs({"children":ch,"count":len(ids),"domain":"urn:ax:merkle-node:1","ids":leaf,"namespace":ns,"prefix":p})).hexdigest()
    return len(ids),h
Z=lambda n:"sha256:"+"0"*63+str(n); T=lambda n:"sha256:"+"2"*63+str(n); R=lambda c:"sha256:"+c*64
print("empty",node("record","",[])[1]); print("single",node("record","",[R("0")])[1])
print("branch",node("record","",[R("0"),R("f")])[1], node("record","0",[R("0")])[1], node("record","f",[R("f")])[1])
fx={"record":[Z(i) for i in range(1,6)],"event":[R("1")],"manifest":[T(i) for i in range(1,5)],"tombstone":[R("3")],"tombstone_ack":[R("4")],"blob":[R("5")]}
for k,v in fx.items(): print(k,node(k,"",v))
