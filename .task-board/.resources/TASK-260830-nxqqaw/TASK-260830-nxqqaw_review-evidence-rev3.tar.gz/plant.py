import sys,subprocess,pathlib
root=pathlib.Path(sys.argv[1]); name,path,old,new=sys.argv[2:6]
p=root/path; src=p.read_text()
if src.count(old)!=1: print(name,"NOT_APPLIED",src.count(old)); sys.exit(0)
p.write_text(src.replace(old,new))
try:
  r=subprocess.run(["go","test","-count=1","./internal/merkleinventory"],cwd=root,capture_output=True,text=True)
  open(f"{root}/../plant-{name}.log","w").write(r.stdout+r.stderr)
  fails=[l.split()[2] for l in r.stdout.splitlines() if l.startswith("--- FAIL") and "/" not in l.split()[2]]
  print(name,"KILLED" if r.returncode else "SURVIVED",r.returncode,fails[:4])
finally: p.write_text(src)
