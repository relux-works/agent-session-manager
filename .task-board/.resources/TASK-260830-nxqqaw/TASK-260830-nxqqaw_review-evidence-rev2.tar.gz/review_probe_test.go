package merkleinventory

import (
	"encoding/base64"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/rpcwire"
)

type rawBodySource struct{ body string }

func (s *rawBodySource) ObjectsGet(line []byte, _ string, _ uint64) ([]byte, error) {
	req, err := rpcwire.DecodeRequest(line)
	if err != nil {
		return nil, err
	}
	return rpcwire.EncodeSuccess(req, []byte(s.body))
}

// §11.3 WireObject members are object_id, media_type, encoding, data (exact).
func TestReviewFetchObjectsRefusesMiscasedWireObjectKeys(t *testing.T) {
	_, objects := inventoryObjectsByNamespace(t)
	data := objects["record"]
	m, err := ClassifyJSON(data)
	if err != nil {
		t.Fatal(err)
	}
	id := m.ID.String()
	d := base64.RawURLEncoding.EncodeToString(data)
	bodies := map[string]string{
		"exact":   `{"objects":[{"data":"` + d + `","encoding":"json","media_type":"application/json","object_id":"` + id + `"}]}`,
		"miscase": `{"objects":[{"DATA":"` + d + `","Encoding":"json","Media_Type":"application/json","OBJECT_ID":"` + id + `"}]}`,
	}
	for name, body := range bodies {
		got, err := FetchObjects(&rawBodySource{body: body}, "record", []string{id}, rpcwire.MaxLineBytes, func() (string, error) { return testRequestID, nil })
		t.Logf("%s: objects=%d err=%v", name, len(got), err)
		if name != "exact" && err == nil {
			t.Errorf("%s: admitted a WireObject whose member names are not the §11.3 literals", name)
		}
	}
}
