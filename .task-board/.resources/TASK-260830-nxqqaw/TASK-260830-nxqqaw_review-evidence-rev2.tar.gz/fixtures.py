import hashlib,json
def jcs(o): return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def node(ns,p,ids):
    ids=sorted({i for i in ids if i[7:].startswith(p)})
    if not ids: c=[];L=[]
    elif len(ids)==1: c=[];L=ids
    else:
        assert len(p)<64
        L=[];c=[]
        for n in '0123456789abcdef':
            k=[i for i in ids if i[7:].startswith(p+n)]
            if k: c.append({"count":len(k),"hash":node(ns,p+n,k),"label":n})
    return "sha256:"+hashlib.sha256(jcs({"children":c,"count":len(ids),"domain":"urn:ax:merkle-node:1","ids":L,"namespace":ns,"prefix":p})).hexdigest()
Z=lambda n:"sha256:"+"0"*63+str(n); T=lambda n:"sha256:"+"2"*63+str(n)
print("empty",node("record","",[]));print("single",node("record","",[Z(0)]))
print("branch",node("record","",[Z(0),"sha256:"+"f"*64]),node("record","0",[Z(0)]),node("record","f",["sha256:"+"f"*64]))
for ns,ids in [("record",[Z(i) for i in range(1,6)]),("event",["sha256:"+"1"*64]),("manifest",[T(i) for i in range(1,5)]),("tombstone",["sha256:"+"3"*64]),("tombstone_ack",["sha256:"+"4"*64]),("blob",["sha256:"+"5"*64])]:
    print(ns,len(ids),node(ns,"",ids))
