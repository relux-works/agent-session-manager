| Mutant | Narrowing | Named test | Exit | Result | Raw log |
| --- | --- | --- | ---: | --- | --- |
| server-casefold-prefix | Admits the miscased Prefix member at the server inventory.children entry. | TestDispatchRejectsEveryNonExactOperationBodyShape | 1 | killed | `server-casefold-prefix/test.log` |
| client-casefold-wireobject | Admits one case-folded WireObject member at the hostile client response entry. | TestFetchObjectsRejectsEveryNonExactSuccessWireShape | 1 | killed | `client-casefold-wireobject/test.log` |
