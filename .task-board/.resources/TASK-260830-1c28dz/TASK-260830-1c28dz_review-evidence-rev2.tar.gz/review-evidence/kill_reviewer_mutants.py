import pathlib,subprocess,time,ast,json,os
p=pathlib.Path(__file__).resolve().parent;root=p/'probes';mod=ast.parse((p/'reviewer_mutants.py').read_text());rows=next(ast.literal_eval(n.value) for n in mod.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='rows' for x in n.targets));out=p/'reviewer-killers';out.mkdir(exist_ok=True);results=[]
for name,file,old,new,note in rows:
 if name.startswith(('R3','C-')):continue
 path=root/'internal/tmuxserver'/file;orig=path.read_text();assert orig.count(old)==1
 try:
  path.write_text(orig.replace(old,new))
  for rep in [1,2]:
   with (out/f'{name}-{rep}.log').open('w') as f:
    start=time.monotonic();proc=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-v','-run','^TestReviewKill'],cwd=root,stdout=f,stderr=subprocess.STDOUT,timeout=120);f.write(f'\nexit={proc.returncode} elapsed={time.monotonic()-start} load={os.getloadavg()}\n')
   txt=(out/f'{name}-{rep}.log').read_text();results.append({'name':name,'repeat':rep,'exit':proc.returncode,'kill_lines':[l for l in txt.splitlines() if '--- FAIL:' in l]});print(results[-1],flush=True)
 finally:path.write_text(orig)
(out/'results.json').write_text(json.dumps(results,indent=2))
