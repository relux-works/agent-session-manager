import pathlib,subprocess,time,json,os
p=pathlib.Path(__file__).resolve().parent;r=p/'attacks';out=p/'reviewer-mutants';out.mkdir(exist_ok=True)
rows=[
('R1-restore-instance','ops.go','binding.TerminalInstanceID != mctx.TerminalInstanceID ||','(binding.TerminalInstanceID != mctx.TerminalInstanceID && binding.TerminalInstanceID != "0198f4c8-8e50-7f66-8f70-222222222222") ||','Admit one substituted instance through restore binding agreement; other instances still refuse.'),
('R2-outcome-lookup-key','state.go','if document.IdempotencyKey != key {','if document.IdempotencyKey != key && document.IdempotencyKey != "review-forged-key" {','Admit exactly review-forged-key at lookup; record-side key gate stays intact.'),
('R3-status-negative-count','status.go','if err != nil || attached < 0 {','if err != nil || (attached < 0 && attached != -1) {','Admit exactly -1 attached count; other negatives still refuse.'),
('R4-materialization-error','ops.go','err == nil && valid {','(err == nil || err.Error() == "review-material-error") && valid {','Admit valid=true plus one named read failure; other errors still refuse.'),
('R5-custody-create','lifecycle.go','if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {','if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil && !(operation == terminalbackend.OperationCreate && err.Error() == "tmux server refused: tmux_unsafe_socket_path at socket root") {','Different entry from measured rootwrite status/restore: admit root-only custody refusal at create.'),
('C-review-control','ops.go','// sortedEffects copies effects','// Reviewer harmless applied control.\n// sortedEffects copies effects','Comment only control.')]
results=[]
for name,file,old,new,note in rows:
 path=r/'internal/tmuxserver'/file;orig=path.read_text();count=orig.count(old)
 if count!=1:
  results.append({'name':name,'status':'NOT_APPLIED','count':count});continue
 try:
  path.write_text(orig.replace(old,new))
  for rep in [1,2]:
   log=out/f'{name}-{rep}.log';start=time.monotonic()
   with log.open('w') as f:
    f.write(f'plant={name}\nfile={file}\nold={old}\nnew={new}\nnote={note}\nstart={time.time()} load={os.getloadavg()}\n');f.flush()
    proc=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-v'],cwd=r,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    f.write(f'\nexit={proc.returncode} elapsed={time.monotonic()-start} load={os.getloadavg()}\n')
   txt=log.read_text();verdict='SURVIVED' if proc.returncode==0 else ('KILLED' if '--- FAIL:' in txt else 'ERROR')
   results.append({'name':name,'repeat':rep,'exit':proc.returncode,'verdict':verdict,'note':note});print(results[-1],flush=True)
 finally:path.write_text(orig)
 (out/'results.json').write_text(json.dumps(results,indent=2))
(out/'results.json').write_text(json.dumps(results,indent=2))
