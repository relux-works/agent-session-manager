//go:build !windows

package tmuxserver

import (
 "context"
 "crypto/sha256"
 "encoding/hex"
 "os"
 "path/filepath"
 "testing"
 "time"
 "github.com/relux-works/agent-session-manager/internal/terminstance"
)

func TestReviewReadonlyMustNotReopenQuiescedInput(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 fx.runner.queue("lock-session", "", 0).queue("detach-client", "", 0)
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"quiesce-input",Body:lxQuiesceBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()});err!=nil {t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,func(m map[string]any){m["client_id"]=lxClientB;m["input_authorized"]=false;m["authorization"]=lxAttachAuth("local_only",false)}),Source:"parked",Admitted:fullLifecycleAdmitted()});err!=nil {t.Fatal(err)}
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()})
 if err==nil {t.Fatalf("quiesced input reopened by read-only observation: argv=%q",out.Argv)}
}

func TestReviewRestoreAcrossServerGeneration(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 fx.runner.queue("new-session","",0)
 created,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"create",Body:lxCreateBody(t,nil),Source:"absent",Admitted:fullLifecycleAdmitted()})
 if err!=nil {t.Fatal(err)}
 rebooted,err:=terminstance.OpenReceiptStore(filepath.Join(fx.data,"receipts-after-reboot"));if err!=nil {t.Fatal(err)};fx.lc.Receipts=rebooted
 fx.lc.CurrentGeneration=func()string{return "generation-after-reboot"}
 fx.runner.queue("new-session","",0)
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"restore",Body:lxRestoreBody(t,created.Binding.BindingID,func(m map[string]any){m["context"].(map[string]any)["backend_generation"]="generation-after-reboot"}),Source:"absent",Admitted:fullLifecycleAdmitted()})
 if err!=nil {t.Fatalf("valid restore to new generation failed after effects %v: %v",fx.runner.subcommands(),err)}
 if out.Binding==nil || out.Binding.BackendGeneration!="generation-after-reboot" {t.Fatalf("restore lacks new-generation binding: %+v",out.Binding)}
}

func TestReviewCorruptOutcomeMustNotBecomeFreshEvidence(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 req:=OpRequest{Operation:"quiesce-input",Body:lxQuiesceBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()}
 first,err:=fx.lc.Execute(context.Background(),req);if err!=nil {t.Fatal(err)}
 sum:=sha256.Sum256([]byte(lxInstance+"/quiesce/"+lxQuiesce))
 p:=filepath.Join(fx.lc.States.root,"tmuxlifecycle","outcomes",hex.EncodeToString(sum[:])+".json")
 if err:=os.WriteFile(p,[]byte("corrupt"),0600);err!=nil {t.Fatal(err)}
 fx.clock.Sleep(time.Second)
 second,err:=fx.lc.Execute(context.Background(),req)
 if err==nil && first.InputClosedAt!=second.InputClosedAt {t.Fatalf("corrupt replay silently manufactured new closure time %s -> %s",first.InputClosedAt,second.InputClosedAt)}
}

func TestReviewRestoreTrulyLapsedGrantReachesOffer(t *testing.T) {
 fx := newLifecycleFixture(t,fullLifecycleAdmitted())
 fx.lc.LocalHostID=lxHost
 called:=false
 fx.lc.LeaseRefresh=func(context.Context,string)(RefreshWinner,error){called=true;return RefreshWinner{LeaseID:lxLeaseB,Epoch:9,HolderHostID:lxRemoteHost},nil}
 recordBinding(t,fx,lxDigestA);fx.runner.queue("new-session","",0)
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"restore",Body:lxRestoreBody(t,lxDigestA,func(m map[string]any){m["context"].(map[string]any)["authorization"].(map[string]any)["expires_at"]="2026-09-01T11:00:00.000Z"}),Source:"absent",Admitted:fullLifecycleAdmitted(),Interactive:true})
 if !called || out.AfterRestore==nil || out.AfterRestore.Action!="remote_offered" {t.Fatalf("claimed lapsed-grant composition not reached: refreshed=%v branch=%+v err=%v",called,out.AfterRestore,err)}
}

func TestReviewStatusMustObserveIdentityNotEchoQuery(t *testing.T) {
 for _,member:=range []string{"session_id","implementation_version","protocol_version"} {
  t.Run(member,func(t *testing.T){
   fx:=newLifecycleFixture(t,fullLifecycleAdmitted());recordBinding(t,fx,lxDigestA)
   fx.runner.queue("list-panes","ax\n",0).queue("list-sessions",lxInstance+"|0\n",0)
   out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"status",Body:lxStatusBody(t,true,false,func(m map[string]any){if member=="session_id" {m[member]=lxSessionB} else {m[member]="9.9.9"}}),Source:"parked",Admitted:fullLifecycleAdmitted()})
   if err!=nil {t.Logf("refused %s: %v",member,err);return}
   if out.Status.IdentityMatch {t.Fatalf("query %s echoed as independently matching identity: %+v",member,out.Status)}
  })
 }
}
