//go:build !windows
package tmuxserver
import("context";"testing";"errors";"crypto/sha256";"encoding/hex";"os";"path/filepath";"encoding/json")
func TestReviewKillRestoreInstanceNarrowing(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());recordBinding(t,fx,lxDigestA)
 doc:=lxBindingDoc(t,func(m map[string]any){m["terminal_instance_id"]="0198f4c8-8e50-7f66-8f70-222222222222"})
 if err:=fx.lc.States.RecordBindingDoc(lxSession,lxBootstrap,doc);err!=nil {t.Fatal(err)}
 fx.runner.queue("new-session","",0)
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"restore",Body:lxRestoreBody(t,lxDigestA,nil),Source:"absent",Admitted:fullLifecycleAdmitted()});err==nil {t.Fatal("substituted instance admitted")}
}
func TestReviewKillOutcomeLookupNarrowing(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());key:="review-original-key"
 if err:=fx.lc.States.RecordOutcome(key,OperationOutcome{Operation:"quiesce-input",InputClosedAt:lxIssued});err!=nil {t.Fatal(err)}
 sum:=sha256.Sum256([]byte(key));path:=filepath.Join(fx.lc.States.root,"tmuxlifecycle","outcomes",hex.EncodeToString(sum[:])+".json")
 raw,err:=os.ReadFile(path);if err!=nil {t.Fatal(err)};var m map[string]any;if err=json.Unmarshal(raw,&m);err!=nil {t.Fatal(err)}
 m["idempotency_key"]="review-forged-key";raw,err=json.Marshal(m);if err!=nil {t.Fatal(err)};if err=os.WriteFile(path,raw,0600);err!=nil {t.Fatal(err)}
 if _,_,err=fx.lc.States.LookupOutcome(key);err==nil {t.Fatal("forged lookup key admitted")}
}
func TestReviewKillMaterializationErrorNarrowing(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());recordBinding(t,fx,lxDigestA);fx.lc.LocalHostID=lxHost
 fx.lc.LeaseRefresh=func(context.Context,string)(RefreshWinner,error){return RefreshWinner{LeaseID:lxLease,Epoch:7,HolderHostID:lxHost},nil}
 fx.lc.Materialization=func(string,string)(bool,error){return true,errors.New("review-material-error")};fx.runner.queue("new-session","",0)
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"restore",Body:lxRestoreBody(t,lxDigestA,nil),Source:"absent",Admitted:fullLifecycleAdmitted()});if err!=nil {t.Fatal(err)}
 if out.AfterRestore==nil || out.AfterRestore.Action!="parked" {t.Fatalf("failed materialization admitted: %+v",out.AfterRestore)}
}
func TestReviewKillCustodyCreateNarrowing(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());if err:=os.Chmod(fx.root,0777);err!=nil {t.Fatal(err)};defer os.Chmod(fx.root,0755)
 fx.runner.queue("new-session","",0)
 _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"create",Body:lxCreateBody(t,nil),Source:"absent",Admitted:fullLifecycleAdmitted()})
 if err==nil {t.Fatal("writable root admitted by create")};requireLocalCode(t,err,"tmux_unsafe_socket_path","socket root")
}
func TestReviewKillNegativeCountNarrowing(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());fx.runner.queue("list-panes","ax\n",0).queue("list-sessions",lxInstance+"|-1\n",0)
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"status",Body:lxStatusBody(t,true,false,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil {t.Fatal("negative attached-client count admitted")}
}
