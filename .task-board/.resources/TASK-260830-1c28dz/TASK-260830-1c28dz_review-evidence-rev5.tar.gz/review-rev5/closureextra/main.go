package main
import("fmt";"github.com/relux-works/agent-session-manager/internal/cloneproject";"github.com/relux-works/agent-session-manager/internal/sshtransport";"github.com/relux-works/agent-session-manager/internal/crashgate";"github.com/relux-works/agent-session-manager/internal/config")
func main(){
_,e:=cloneproject.Normalize(cloneproject.NormalizeRequest{});fmt.Printf("cloneproject/Normalize/no-fetcher => %v\n",e)
_,e=cloneproject.Normalize(cloneproject.NormalizeRequest{Fetch:func(string)([]byte,error){panic("unexpected fetch")}});fmt.Printf("cloneproject/Normalize/no-sink => %v\n",e)
_,e=sshtransport.New(config.Snapshot{});fmt.Printf("sshtransport/New/zero-snapshot => %v\n",e)
_,found:=crashgate.Lookup("CR-LAUNCH-D-01");fmt.Printf("crashgate/Lookup/known => %v\n",found)
_,found=crashgate.Lookup("unknown");fmt.Printf("crashgate/Lookup/unknown => %v\n",found)
}
