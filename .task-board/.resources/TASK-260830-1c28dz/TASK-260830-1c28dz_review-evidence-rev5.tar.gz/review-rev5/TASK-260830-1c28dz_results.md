# TASK-260830-1c28dz rework rev5 — results (standalone)

Ready for review. This run repairs the rev4 CHANGES REQUESTED on
checkpoint `d4bd91d0` (trunk unmoved, no rebase). Both P1 close by
construction rather than by case analysis; P2-A, P2-B, and P3 close
with the requested instruments. The worktree is intentionally
UNCOMMITTED for the Story handoff snapshot.

Scope of the production delta (all in `internal/tmuxserver`):
`state.go` (incarnation store + incarnation-scoped barrier scan),
`lifecycle.go` (incarnation binding, failure recording, create
rotation), `ops.go` (proof-only admission + health check, restore
rotation), `wrapper.go` (composed binding). Touched landed files:
error-code registry (new codes, prior revision), ownership seam
(test hook, prior revision), mutant harnesses (new rows). No other
production file changed.

## P1-A — the barrier verdict is the incarnation-scoped proof alone

Construction: every closure report binds the incarnation that was
current when it recorded; a fresh create or restore success rotates
the incarnation to its own idempotency key; replays never rotate;
the attach entry consults exactly `QuiesceBarrierProven` (plus a
store-health read whose value is ignored and whose error fails
closed). Advisory memory, caller-carried source state, and failure
reporting cannot reopen a closed barrier because admission never
reads their values; a new incarnation supersedes stale reports
because the scan skips them. Row 79's lost-write claim now reads
as the construction (memory is advisory; the proof decides).

Writer census — every writer of barrier-relevant state:

| # | Writer (file:function) | What it writes | Proof the barrier holds |
|---|---|---|---|
| W1 | lifecycle.go:executeCreate success | best-effort Active/Parked memory; checked incarnation rotation on fresh success only | `TestExecuteCreateReplayPreservesBarrier` (replay skips) + `TestExecuteCreateIncarnationWriteFailureFailsClosed` (lost rotation fails closed); memory values proven ignored by `TestExecuteAdvisoryMemoryNeverDecidesAdmission` |
| W2 | lifecycle.go:executeEngineOp non-barrier success | best-effort memory (stop) | `TestExecuteStop` memory pin; values ignored for admission (same advisory test) |
| W3 | lifecycle.go:executeEngineOp barrier success | checked memory (status fidelity) + closure report binding the current incarnation | `TestExecuteAttachRefusesInputWhenQuiescing` + `N-quiesce-state-record` / `N-boundary-state-record` |
| W4 | lifecycle.go:recordFailure | first echo only when absent; honest unknown overwrites | `TestReviewFailedStopCannotEraseQuiescence` + `N-failure-preserves-record` (never-overwrite); `TestExecuteTerminateResumesAfterEffectFailure` (first-echo resume) |
| W5 | ops.go:executeAttach success | best-effort active memory | `TestExecuteAttach` memory pin; values ignored for admission (same advisory test) |
| W6 | ops.go:runLifecycleEffects success | best-effort target memory; checked incarnation rotation on fresh restore only | `TestExecuteRestoreReplayPreservesBarrier` + `D-restore-replay-rotation` (structural, B41); `TestExecuteTerminate` + `N-terminate-no-rotation` (terminate never rotates) |
| W7 | state.go:RecordOutcome via report funcs | closure report + incarnation bind, first success records, retries replay | `TestExecuteQuiesceRetryAfterStateWriteFailureHealsBarrier` (+ boundary twin); `N-quiesce-report-record` / `N-boundary-report-record` |

Reader census — every reader deciding admission:

| # | Reader (file:function) | What it trusts | Proof / bound |
|---|---|---|---|
| R1 | ops.go:checkAttachQuiesced | the incarnation-scoped closure proof as the sole verdict | `TestExecuteAdvisoryMemoryNeverDecidesAdmission` forces memory both directions with no verdict change; `N-quiesce-attach-gate` (re-anchored to the proof) |
| R2 | ops.go:checkAttachQuiesced health read | nothing (value ignored); read errors propagate | `TestExecuteAttachErrorsOnStateReadFailure` + `N-attach-health-check`; the Lookup absent arm itself is `N-state-read-absent` |
| R3 | state.go:QuiesceBarrierProven scoping | current incarnation; stale reports skipped | `TestExecuteQuiesceStopRestoreReopensBarrier` + `N-attach-barrier-incarnation`; store-level `TestQuiesceBarrierIgnoresSupersededIncarnation` |
| R4 | status.go:ClassifyStatus memory leg | advisory memory for status only, never admission | status rows 80/88; the reopen test admits attach while stale reports persist, proving the split |

The two reviewer sequences run verbatim:
`TestReviewExistingActiveMemoryCannotReopenQuiescedInput` (stale
active + lost state write refuses via the proof) and
`TestReviewFailedStopCannotEraseQuiescence` (failed stop preserves
quiescing memory and refuses). The legitimate reopening is
`TestExecuteQuiesceStopRestoreReopensBarrier` (quiesce→stop→
restore→writable attach admitted, incarnation asserted).

Bound B40 (owner: axpane receipt/bootstrap contracts): a lost
rotation with a prior closure stays closed with no
production-entry recovery — retries replay without rotating, and a
fresh key is unreachable (one bootstrap per session, pinned
mechanically in
`TestExecuteCreateIncarnationWriteFailureFailsClosed` via the
landed `idempotency_mismatch`). Over-strict in the safe direction;
a lost rotation with no prior closure is harmless (self-consistent
zero incarnation). Bound B41 (owner: this leaf): the restore
replay skip is structural (no code to narrow); the supplementary
`D-restore-replay-rotation` proves the test observes the forbidden
write.

## P1-B — one composed authorization over six members

`checkRestoreComposedBound` (wrapper.go) refuses
`local_precondition_failed` before any effect unless the executed
restore names the decided session, bootstrap, admitted-descriptor
instance/backend/generation triple, and winner lease/epoch. The
descriptor triple comes from the landed
`terminalbackend.AdmitProviderDescriptor` output inside Decide —
compared, never re-parsed.

Identity census — every identity member the decision and the
effect each carry:

| # | Decision member | Effect member | Disposition |
|---|---|---|---|
| 1 | Decide.SessionID | mctx.SessionID | JOINED — `TestWrapperRestoreRefusesDivergentSession` + `N-wrapper-restore-session` |
| 2 | Decide.BootstrapOperationID | body.BootstrapOperationID | JOINED — `TestReviewWrapperBootstrapMustBindExecutedRestore` + `N-wrapper-restore-bootstrap` |
| 3 | admitted Descriptor.TerminalInstanceID | mctx.TerminalInstanceID | JOINED — `TestReviewWrapperInstanceMustBindExecutedRestore` + `N-wrapper-restore-instance` |
| 4 | admitted Descriptor.TerminalBackendID | mctx.TerminalBackendID | JOINED — `TestWrapperRestoreRefusesDivergentBackend` + `N-wrapper-restore-backend` |
| 5 | admitted Descriptor.BackendGeneration | mctx.BackendGeneration | JOINED — `TestWrapperRestoreRefusesDivergentGeneration` + `N-wrapper-restore-generation` |
| 6 | ordered winner (lease_id, epoch) | auth (lease_id, epoch) | JOINED — rev4 tests + `N-wrapper-winner-lease`, `N-wrapper-winner-epoch` (kept) |
| 7 | winner HolderHostID | auth holder_host_id | UNJOINED — backend `CheckAuthorization` binds kind/expiry/lease/epoch only (terminstance/auth.go); the holder routes inside Decide's fencing arm |
| 8 | Journal/materialization | (no counterpart) | UNJOINED — decision-local gate enforced inside Decide before effects; restore carries no materialization member |
| 9 | checkpoint (Newest/Required) | body.CheckpointID | UNJOINED — different roles: decision admission runs over the fold authority; the restore checkpoint is opaque carried evidence with no production consumer (bodies.go only) |
| 10 | ExistingBinding | body.PriorBindingID | UNJOINED — backend `checkPriorBinding` binds the prior to the recorded receipt; the decision binding drives the bootstrap-window verdict |
| 11 | descriptor versions (provider build) | mctx versions (AX API) | UNJOINED — different namespaces; the honest fixture differs by design (2.1.0/1.1.0 vs 1.2.3/1.0.0) |
| 12 | descriptor TerminalBindingID | body.PriorBindingID | UNJOINED — different namespaces (host-local provider binding vs recorded bootstrap binding; honest differs) |
| 13 | Presented/Observation/Entrypoint/Profile/Provider/Realm/Backend-facts | (no counterpart) | N/A — decision-local inputs enforced inside Decide |

Table E grows 17→22 outcomes with the five composed-binding
refusals, each with a divergence test asserting the wrapper
detail, a launched decision, zero backend outcome, and zero
executed subcommands.

## P2-B — the four clause gaps, all witnessed

| Gap | Committed test (production entry) | Harness row (reviewer plant shape) |
|---|---|---|
| R1 malformed attached count `0junk` | `TestExecuteStatusMalformedAttachedCountIsUnknown` via `Execute(status)` | `N-status-attached-parse` — admits exactly `0junk` past the parse-error clause |
| R2 exactly-`{}` barrier report | `TestExecuteAttachErrorsOnEmptyBarrierKey` via `Execute(attach)` | `N-attach-barrier-empty-key` — admits exactly `{}` past the empty-key arm |
| R3 prober writable-root custody | `TestServerProberRefusesWritableRoot` via `ServerProber.Probe` | `N-prober-root-custody` — admits exactly the writable-root class; the PRB rootwrite cell moves B39→M |
| R4 EISDIR state-read failure | `TestExecuteAttachErrorsOnStateReadFailure` via `Execute(attach)` | `N-state-read-absent` — admits exactly EISDIR as absence |

## P2-A — closure outcome grid (36-package variant, declared)

The fixed-corpus driver `closuregrid` (ships in the evidence
tarball, copied into each tree; no clock, no randomness, no
network; filesystem probes normalized to `<tmp>`) records
`(package, entry, input class) -> (outcome, refusal string,
value summary)` over the reviewer's 36-package closure
(34 production + crashgate + environ). 33 packages probed;
3 stated bounds with owners (no exported pure callable
surface; fenced by the suite-verdict grid below): cloneproject,
crashgate, sshtransport. The 7 tmuxserver records for
story-added entries sit behind the `closuregrid_candidate`
build tag and are declared candidate-only by construction.

- Shared keys: 193. MOVED: 0. Base-only: 0.
- Candidate-only: 7, all declared (`tmuxserver/CheckSocketLength`
  × short/long, `tmuxserver/ClassifyStatus` × 5 input classes).
- Stability: 6/6 identical candidate runs (sha256 match). One
  flake found and fixed during authoring (resumesmoke's
  missing-member loop iterates a map; the inputs now fail
  deterministically before it), and every member-naming error in
  the corpus audited for fixed-order checks (clonebundle,
  canonicaljson, sessrepo) or member-free strings (provhost,
  termbind).
- Suite verdicts over the complete importer set: 23,874 shared
  `(package, test)` keys, zero moved verdicts, zero base-only,
  498 candidate-only additions (493 tmuxserver incl. subtests,
  5 termbind), all PASS. No input moved across any admission or
  refusal arm: the outcome grid above names every probed input
  and every one is identical or declared.

## P3 — prose

B27 counts 18 U2c cells (was 19). The determinism sentence now
reads "no committed test execs a real tmux or dials a real tmux
server socket (one dialer test dials a synthetic local listener
it creates itself, not a tmux server)" in the matrix, results
narrative, and README-adjacent claims.

## Census and ratios

- Gate × entry census (Tables A/B/D recomputed by script over
  the tables): 250 measured of 5064 (50+10+190 M); 187 bound;
  4627 unreachable with reasons; 156 named undriven gaps (148
  B39 + 8 named cells; B40/B41 are non-cell bounds). Table C
  all U. Every two-sided gate carries a row-count symmetry line
  (rotation create 1 / restore 1; custody CUS 1 / EXC 1 / EXS 1 /
  EXR 1 / PRB 1 / SPW 1 + shared row; reached-lookup EXA 1 /
  LOOK 2 on different arms).
- AC rows 59-92: 34 of 34 driven through production entries by
  named tests (call sites in the matrix).
- Eight operations, 8 of 8, each through `Lifecycle.Execute`
  (lifecycle.go) by a named committed test: create
  (`TestExecuteCreateInteractive`), attach (`TestExecuteAttach`),
  status (`TestExecuteStatusPresent`), quiesce
  (`TestExecuteQuiesce`), safe-boundary (`TestExecuteBoundary`),
  stop (`TestExecuteStop`), stale termination
  (`TestExecuteTerminate`), restore (`TestExecuteRestore`).
- Mutant battery: 273/273 tmuxserver rows as expected (269
  narrowing `N-*` + 3 additive `D-*` KILLED, shared control
  SURVIVED), 40/40 termbind rows as expected; one raw log per
  plant in the tarball. 22 new tmuxserver rows this round (21
  narrowing + 1 supplementary), 4 re-anchored to the
  construction (attach gate, failure record, two report
  records, state foreign split).
- No-real-tmux: zero real-tmux witnesses by the determinism
  design (bound B1); tmux is installed on this host and no tmux
  process ran before, during, or after the suite (pgrep audit
  in the evidence).

## Validation (all exit 0, this run)

| Gate | Result |
|---|---|
| `go test ./... -count=1` candidate / base | 45 ok / 45 ok |
| `go test -race` tmuxserver + termbind | ok, no races |
| `go test ./... -cover` | ok (tmuxserver 88.0%, termbind 83.5%) |
| `go vet ./...` + `GOOS=windows go vet` touched pkgs | clean |
| `gofmt -l internal/` | clean |
| tmuxserver harness 273 + termbind harness 40 | all as expected |
| no-tmux process audit | no tmux process before/after; suite green |
| closure grid determinism | 6/6 identical streams |
| census recount + matrix mirror check | counts match; AC/census/bounds byte-identical |

## Evidence

- `TASK-260830-1c28dz_conformance-matrix.md` (updated, attached):
  AC rows, ops table, mirrored census Tables B/C/D + Table E,
  bounds B22-B41, battery, crash/idempotency.
- `TASK-260830-1c28dz_rework-evidence-rev5.tar.gz` (attached):
  closure grid driver + base/candidate streams + diff,
  per-test verdict streams + diff, full suite logs both trees,
  273 + 40 raw per-plant harness logs, vet/fmt/race/cover/
  no-tmux logs, census recount, mirror check, SHA256SUMS.
- Handoff: ready for review; candidate UNCOMMITTED in the
  Story worktree for snapshot.
