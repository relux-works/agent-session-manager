//go:build !windows
package tmuxserver
import (
 "context"
 "os"
 "path/filepath"
 "testing"
)
func TestReviewKillIncarnationReadFailure(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 p:=filepath.Join(fx.lc.States.root,"tmuxlifecycle","incarnation",lxInstance+".json")
 if err:=os.MkdirAll(p,0700);err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("unreadable incarnation admitted writable attach")}
}
func TestReviewKillOutcomeDirectoryReadFailure(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 p:=filepath.Join(fx.lc.States.root,"tmuxlifecycle","outcomes")
 if err:=os.MkdirAll(filepath.Dir(p),0700);err!=nil{t.Fatal(err)}
 if err:=os.WriteFile(p,[]byte("broken"),0600);err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("unreadable outcome directory admitted writable attach")}
}
func TestReviewKillOutcomeFileReadFailure(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 p:=filepath.Join(fx.lc.States.root,"tmuxlifecycle","outcomes")
 if err:=os.MkdirAll(p,0700);err!=nil{t.Fatal(err)}
 if err:=os.Symlink(p,filepath.Join(p,"broken.json"));err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("unreadable outcome file admitted writable attach")}
}
func TestReviewKillAttachCustody(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 if err:=os.Chmod(fx.root,0777);err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("unsafe root admitted attach")}
}
