//go:build closuregrid_candidate

package main

import (
	"fmt"
	"strings"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/tmuxserver"
)

// gridTmuxserverExtra probes tmuxserver entries that exist only on the
// candidate (story-added after the CR base). The base run builds
// without the closuregrid_candidate tag and emits none of these
// records; the diff names them as declared candidate-only keys.
func gridTmuxserverExtra() {
	emitErr("tmuxserver", "CheckSocketLength", "short", tmuxserver.CheckSocketLength("/tmp/ax.sock", scalar.PlatformMacOS))
	emitErr("tmuxserver", "CheckSocketLength", "long", tmuxserver.CheckSocketLength("/tmp/"+strings.Repeat("s", 200)+".sock", scalar.PlatformMacOS))
	for _, tc := range []struct {
		name  string
		input tmuxserver.ClassifyInput
	}{
		{"live-tri", tmuxserver.ClassifyInput{Present: true, Attached: 1, AttachCapable: true}},
		{"parked", tmuxserver.ClassifyInput{Present: true, Attached: 0, AttachCapable: true}},
		{"quiescing-memory", tmuxserver.ClassifyInput{Present: true, Attached: 0, Memory: terminalbackend.StateQuiescing, MemoryFound: true, AttachCapable: true}},
		{"absent", tmuxserver.ClassifyInput{}},
		{"negative", tmuxserver.ClassifyInput{Present: true, Attached: -1, AttachCapable: true}},
	} {
		state, live, provider, foreign := tmuxserver.ClassifyStatus(tc.input)
		emit("tmuxserver", "ClassifyStatus", tc.name, "ok", "", fmt.Sprintf("%s/%v/%v/%v", state, live, provider, foreign))
	}
}
