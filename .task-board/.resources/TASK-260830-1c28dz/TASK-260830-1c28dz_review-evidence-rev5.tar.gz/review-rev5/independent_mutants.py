import pathlib,subprocess,time,os,json,tarfile
p=pathlib.Path(__file__).resolve().parent
root=p/'mutations';root.mkdir(exist_ok=True)
with tarfile.open(p/'tree.tar') as t:t.extractall(root,filter='data')
rows=[
('R1','state.go','\t\tif errors.Is(err, os.ErrNotExist) {\n\t\t\treturn "", false, nil\n\t\t}\n\t\treturn "", false, fmt.Errorf("read tmux instance incarnation: %w", err)', '\t\tif errors.Is(err, os.ErrNotExist) || strings.Contains(err.Error(), "is a directory") {\n\t\t\treturn "", false, nil\n\t\t}\n\t\treturn "", false, fmt.Errorf("read tmux instance incarnation: %w", err)','TestReviewKillIncarnationReadFailure'),
('R2','state.go','\t\tif errors.Is(err, os.ErrNotExist) {\n\t\t\treturn false, nil\n\t\t}\n\t\treturn false, fmt.Errorf("read tmux operation outcomes: %w", err)', '\t\tif errors.Is(err, os.ErrNotExist) || strings.Contains(err.Error(), "not a directory") {\n\t\t\treturn false, nil\n\t\t}\n\t\treturn false, fmt.Errorf("read tmux operation outcomes: %w", err)','TestReviewKillOutcomeDirectoryReadFailure'),
('R3','state.go','\t\tif err != nil {\n\t\t\treturn false, fmt.Errorf("read tmux operation outcome: %w", err)\n\t\t}', '\t\tif err != nil {\n\t\t\tif strings.Contains(err.Error(), "is a directory") { continue }\n\t\t\treturn false, fmt.Errorf("read tmux operation outcome: %w", err)\n\t\t}','TestReviewKillOutcomeFileReadFailure'),
('R4','lifecycle.go','if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {','if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil && !(operation == terminalbackend.OperationAttach && err.Error() == "tmux server refused: tmux_unsafe_socket_path at socket root") {','TestReviewKillAttachCustody'),
('C','errors.go','// Error is a package-local refusal.','// Error is a package-local refusal. Harmless reviewer control.','TestReviewKill')]
log=p/'independent';log.mkdir(exist_ok=True)
targettest=root/'internal/tmuxserver/review_killers_test.go'
def run(name,args):
 start=time.time();result=subprocess.run(['go','test','./internal/tmuxserver','-count=2','-timeout=3m']+args,cwd=root,capture_output=True,text=True)
 (log/(name+'.log')).write_text(f'command: go test ./internal/tmuxserver -count=2 -timeout=3m {args}\nexit={result.returncode}\nelapsed={time.time()-start}\n'+result.stdout+result.stderr)
 print(name,result.returncode,flush=True)
 return result.returncode
targettest.write_bytes((p/'independent_killers.go').read_bytes());run('baseline',['-run','^TestReviewKill']);targettest.unlink()
for name,file,old,new,test in rows:
 target=root/'internal/tmuxserver'/file;s=target.read_text();assert s.count(old)==1,(name,s.count(old))
 (log/(name+'.json')).write_text(json.dumps({'file':file,'find':old,'replace':new,'test':test},indent=2))
 try:
  target.write_text(s.replace(old,new));run(name+'-committed',[])
  targettest.write_bytes((p/'independent_killers.go').read_bytes());run(name+'-killer',['-run','^'+test]);targettest.unlink()
 finally:
  target.write_text(s)
  targettest.unlink(missing_ok=True)
