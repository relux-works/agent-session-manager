# Reviewer evidence reproduction

Candidate tree: 1d4067513dbda9296b3889b055f4b31d7490d08a.
Base: d4bd91d0e740285b21b8d65bf6f074c8009b04ae.

Use disposable archive copies, never the live Story worktree. Produce tree.tar with `git archive 1d4067513dbda9296b3889b055f4b31d7490d08a -o tree.tar` beside independent_mutants.py. `PYTHONDONTWRITEBYTECODE=1 python3 independent_mutants.py` creates its own mutation copy, runs baseline killers, then each committed suite and targeted killer with count=2, restoring production bytes after each plant. Raw logs and patches are in independent/.

To reproduce the two unchanged-production failures, unpack tree.tar into a separate directory, copy review_regression_test.go into internal/tmuxserver/, and run `go test ./internal/tmuxserver -run '^TestReview(OutcomeWriteFailure|AttachMustRecheck)' -count=2 -race -v`. Expected exit 1, four assertion failures, no data-race report. Earlier failed setup/compile logs are preserved and are not counted as behavioral evidence.

The shipped harness raw logs and named rows are in harness-pass1/, harness-pass2/, and termbind-pass*.log. All expected rows finished twice before attachment. Shipped tmuxserver harness selection used 140 then 133 rows on the second pass to bound shell duration.

closuregrid/ is the supplied producer corpus, rerun on both trees. Put it under .temp/closuregrid inside each archive; run `go run ./.temp/closuregrid` on base and `go run -tags=closuregrid_candidate ./.temp/closuregrid` on candidate. closureextra/ contains the independent five-row counterexample to the excluded-package claim; run it without tags in both trees.

execution-exits.json distinguishes successful validation, intended regression failures, and unsuccessful reviewer setup attempts. Production source equality after all plants is in restored-source-audit.json. Environment/load are point-in-time samples; no timing comparison or continuous process census is claimed.
