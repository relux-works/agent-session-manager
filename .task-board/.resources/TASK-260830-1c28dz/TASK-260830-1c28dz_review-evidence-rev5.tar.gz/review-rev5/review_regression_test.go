//go:build !windows
package tmuxserver
import (
 "context"
 "strings"
 "testing"
)
func TestReviewOutcomeWriteFailureMustNotReopen(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 _, err := fx.lc.Execute(context.Background(), OpRequest{Operation:"attach", Body:lxAttachBody(t,nil), Source:"parked", Admitted:fullLifecycleAdmitted()})
 if err != nil { t.Fatal(err) }
 fx.lc.States.WithHooks(&StateHooks{AfterStage:func(path string)error{if strings.Contains(path,"/outcomes/"){return errFakeTransport};return nil}})
 fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 _,err=fx.lc.Execute(context.Background(),OpRequest{Operation:"quiesce-input",Body:lxQuiesceBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()})
 if err==nil {t.Fatal("expected report write failure")}
 t.Logf("closure executed: %v; error=%v",fx.runner.subcommands(),err)
 fx.lc.States.WithHooks(nil)
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,func(o map[string]any){o["client_id"]=lxClientB}),Source:"parked",Admitted:fullLifecycleAdmitted()})
 if err==nil {t.Fatalf("closed input reopened after report-write failure: %+v argv=%v",out.Attach,out.Argv)}
}
func TestReviewAttachMustRecheckClosureBeforeReceipt(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 admission:=fx.lc.ServerAdmission
 entered,resume:=make(chan struct{}),make(chan struct{})
 fx.lc.ServerAdmission=func()(RealmAdmission,error){close(entered);<-resume;return admission()}
 req:=OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()}
 type answer struct{out OpOutcome;err error}
 done:=make(chan answer,1)
 go func(){out,err:=fx.lc.Execute(context.Background(),req);done<-answer{out,err}}()
 <-entered
 fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 _,qerr:=fx.lc.Execute(context.Background(),OpRequest{Operation:"quiesce-input",Body:lxQuiesceBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()})
 close(resume)
 got:=<-done
 if qerr!=nil{t.Fatal(qerr)}
 if got.err==nil{t.Fatalf("attach admitted after concurrent closure completed: %+v argv=%v",got.out.Attach,got.out.Argv)}
}
