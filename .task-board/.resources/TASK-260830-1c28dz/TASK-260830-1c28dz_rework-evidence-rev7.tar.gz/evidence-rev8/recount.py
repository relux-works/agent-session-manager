#!/usr/bin/env python3
"""Census recount over TRACEABILITY Table D (and A/B): classify every cell.

Cell classes: M (measured: starts with 'M '), B (bound: starts with 'B'),
U (unreachable: starts with 'U'). Prints per-table M/B/U and the grand ratio.
Usage: recount.py <traceability.md>
"""
import re
import sys

def table_rows(text, name):
    lines = text.split("\n")
    idxs = [i for i, l in enumerate(lines) if l.startswith("| Gate (site) |")]
    order = {"A": 0, "B": 1, "D": 2}
    start = idxs[order[name]]
    rows = []
    for line in lines[start + 2:]:
        if not line.startswith("|"):
            break
        rows.append(line)
    return rows

def count_cells(rows, cols):
    m = b = u = 0
    for row in rows:
        cells = [c.strip() for c in row.split("|")[2:2 + cols]]
        assert len(cells) == cols, row[:80]
        for cell in cells:
            if cell.startswith("M "):
                m += 1
            elif cell.startswith("B"):
                b += 1
            elif cell.startswith("U"):
                u += 1
            else:
                raise AssertionError(f"unclassified cell: {cell[:60]!r} in {row[:80]!r}")
    return m, b, u

def main(path):
    text = open(path).read()
    a = table_rows(text, "A")
    b = table_rows(text, "B")
    d = table_rows(text, "D")
    ma, ba, ua = count_cells(a, 11)
    mb, bb, ub = count_cells(b, 21)
    md, bd, ud = count_cells(d, 21)
    print(f"Table A: {len(a)} rows x 11 = {len(a)*11}; M={ma} B={ba} U={ua} (sum={ma+ba+ua})")
    print(f"Table B: {len(b)} rows x 21 = {len(b)*21}; M={mb} B={bb} U={ub} (sum={mb+bb+ub})")
    print(f"Table D: {len(d)} rows x 21 = {len(d)*21}; M={md} B={bd} U={ud} (sum={md+bd+ud})")
    c_cells = len(d) * 11
    total = len(a)*11 + len(b)*21 + c_cells + len(d)*21
    print(f"Table C: {len(d)} x 11 = {c_cells} (all U by derivation)")
    print(f"TOTAL: M={ma+mb+md} B={ba+bb+bd} U={ua+ub+c_cells+ud} cells={total}")

if __name__ == "__main__":
    main(sys.argv[1])
