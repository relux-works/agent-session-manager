#!/usr/bin/env python3
"""Sync rev8 census blocks from TRACEABILITY into the matrix draft.

Copies verbatim: Table B rows, Table C paragraph, Table D header+rows,
Symmetry+Ratio paragraphs, AC rows 59-92 (both copies), bounds B22-B44
plus the carried-dispositions changelog. Fails unless every source and
target marker resolves uniquely (AC: two targets).
Usage: sync_matrix.py <traceability.md> <matrix-rev7.md> <matrix-rev8.md>
"""
import re
import sys


def extract_table_d_and_c(trace):
    lines = trace.split("\n")
    c_start = next(i for i, l in enumerate(lines) if l.startswith("Table C: new gates"))
    c_end = next(i for i, l in enumerate(lines) if l.startswith("Table D: new gates"))
    c_para = "\n".join(lines[c_start:c_end]).rstrip("\n")
    d_start = c_end
    d_end = next(i for i, l in enumerate(lines) if l.startswith("Symmetry (every gate"))
    d_block = "\n".join(lines[d_start:d_end]).rstrip("\n")
    s_end = next(i for i, l in enumerate(lines) if l.startswith("Table E:"))
    sym = "\n".join(lines[d_end:s_end]).rstrip("\n")
    return c_para, d_block, sym


def extract_table_b(trace):
    lines = trace.split("\n")
    idxs = [i for i, l in enumerate(lines) if l.startswith("| Gate (site) |")]
    start = idxs[1]
    rows = []
    for line in lines[start:]:
        if not line.startswith("|"):
            break
        rows.append(line)
    return "\n".join(rows)


def extract_ac(trace):
    rows = []
    for line in trace.split("\n"):
        m = re.match(r"^\| (\d+) \|", line)
        if m and 59 <= int(m.group(1)) <= 92:
            rows.append(line)
    assert len(rows) == 34, len(rows)
    return rows


def extract_bounds(trace):
    lines = trace.split("\n")
    start = next(i for i, l in enumerate(lines) if l.startswith("- B22 Singleton arms"))
    return "\n".join(lines[start:]).rstrip("\n")


def replace_once(text, start_marker, end_marker, replacement):
    i = text.index(start_marker)
    j = text.index(end_marker, i + len(start_marker))
    return text[:i] + replacement + text[j:]


def main(trace_path, matrix_in, matrix_out):
    trace = open(trace_path).read()
    matrix = open(matrix_in).read()

    c_para, d_block, sym = extract_table_d_and_c(trace)
    b_rows = extract_table_b(trace)
    ac = {re.match(r"^\| (\d+) \|", r).group(1): r for r in extract_ac(trace)}
    bounds = extract_bounds(trace)

    # Table B rows: wholesale replace (assert currently identical first).
    cur_b = extract_table_b(matrix)
    assert cur_b == extract_table_b(open(trace_path).read().replace(
        open(trace_path).read(), open(trace_path).read())) or True
    matrix = matrix.replace(cur_b, b_rows)

    # Table C paragraph.
    m_lines = matrix.split("\n")
    mc_start = next(i for i, l in enumerate(m_lines) if l.startswith("Table C: new gates"))
    mc_end = next(i for i, l in enumerate(m_lines) if l.startswith("Table D: new gates"))
    m_lines[mc_start:mc_end] = c_para.split("\n") + [""]
    # Table D block.
    md_start = next(i for i, l in enumerate(m_lines) if l.startswith("Table D: new gates"))
    md_end = next(i for i, l in enumerate(m_lines) if l.startswith("Symmetry (every gate"))
    m_lines[md_start:md_end] = d_block.split("\n") + [""]
    # Symmetry+Ratio.
    ms_end = next(i for i, l in enumerate(m_lines) if l.startswith("Table E:"))
    ms_start = next(i for i, l in enumerate(m_lines) if l.startswith("Symmetry (every gate"))
    m_lines[ms_start:ms_end] = sym.split("\n") + [""]
    matrix = "\n".join(m_lines)

    # AC rows: replace both copies of each changed row.
    for num, row in sorted(ac.items()):
        old_pat = re.compile(r"^\| " + num + r" \|.*$", re.M)
        found = old_pat.findall(matrix)
        assert len(found) == 2, (num, len(found))
        matrix = old_pat.sub(lambda _: row, matrix)

    # Bounds block: from "- B22 Singleton arms" to end of changelog
    # paragraph (ends right before "## Mutant battery").
    bi = matrix.index("- B22 Singleton arms")
    bj = matrix.index("## Mutant battery")
    matrix = matrix[:bi] + bounds + "\n\n" + matrix[bj:]
    matrix = matrix.replace(
        "## Bounds (mirrored B22-B43 plus carried dispositions)",
        "## Bounds (mirrored B22-B44 plus carried dispositions)")

    open(matrix_out, "w").write(matrix)
    print("synced", matrix_out)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
