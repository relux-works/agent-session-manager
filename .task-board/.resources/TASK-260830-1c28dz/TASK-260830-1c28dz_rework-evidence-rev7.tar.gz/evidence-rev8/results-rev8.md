# TASK-260830-1c28dz rev8 — results (RUN-260922-996a4f)

Rework run for the rev7 verdict (`TASK-260830-1c28dz_review-verdict-rev7.md`,
RUN-260922-f502a1), which confirmed the rev7 P1/P2-A close and the P3/P4-A/P5
evidence repairs, and returned three findings: rev8 P1-A (stop escalation
issues `kill-session` after its poll without revalidating generation,
authorization expiry, or the operation deadline), rev8 P2 (attach deadline
does not cancel the admission/barrier waits), and P1-B re-scoped (overlap
capabilities subdivided: liveness to TASK-260922-vcx6yo, fail-closed
receipt-inferred gate here). This run closes P1-A and P2, implements the
narrowed overlap gate, probes every sibling effect boundary with the same
invariant, and repairs the rev7 race timing failure. The candidate is left
UNCOMMITTED on `task-board/story/STORY-260830-2t4g7i` at checkpoint
`d4bd91d0` for the handoff to snapshot.

## What changed (production)

- `internal/tmuxserver/backend.go` — `confirmClosed` revalidates at the
  escalation boundary after its poll: the graceful wait expiring escalates,
  but an operation deadline passed, an authorization lapsed, or a generation
  rotated during the poll refuses WITHOUT issuing `kill-session`.
  `closeInput` revalidates between the lock and detach commands. Both
  boundaries fail closed on a missing revalidation (protocol error, never
  blind). The graceful wait and the operation deadline are distinct bounds:
  the poll runs to the lesser (graceful) bound; the escalation answers to
  the request deadline.
- `internal/tmuxserver/lifecycle.go` — `effectRecheck` builds the
  within-effect revalidation over the landed gates (same
  `terminstance.CheckAuthorization` call with the table-resolved kind,
  same live lease/generation/clock reads, the row's own timeout code);
  `acquireBarrier` + `waitUntil` give every barrier user one
  deadline/cancellation contract (fired-context pre-check, orphan
  acquisition with race-free release); `ServerAdmission` takes the wait
  context and documents the non-cooperative-adapter bound.
- `internal/tmuxserver/ops.go` — `executeAttach` runs admission
  (`admitServer`: waiter goroutine + buffered answer + select, late
  answers discarded, nothing commits after the caller timed out) and the
  barrier acquisition under one wait context, then enforces the overlap
  gate post-lock: a second client that may overlap a recorded peer needs
  `multi_attach`; new input over a recorded input peer needs
  `multiple_input_clients`; same-client retries exempt; unreadable peers
  fail closed. Quiesce span and boundary report commit acquire through
  the same contract (row's own timeout: quiesce reports against its
  committed proof).
- `internal/termbind/overlap.go` (new, extends the landed owner like
  `successor.go`) — `AttachStore.Peers`: the stored peer census
  excluding the requesting client, sorted; read/decode/binding failures
  error, never an empty census.
- `rowTimeoutCode` is now the per-row mapping (stop→`stop_timeout`,
  boundary→`quiesce_timeout`, else `terminal_backend_timeout`), mirroring
  the landed engine's mapping with spec-cited literals pinned by tests.

No landed file is modified: `internal/terminstance`, `internal/terminalbackend`,
and the landed `termbind`/`tmuxserver` files are composed, never forked
(successor.go/overlap.go are additive extensions; the earlier-revision
error-registry/ownership-seam additions stand unchanged).

## The same invariant on every other path (measured, not asserted)

Each row mutates one admission fact during the path's wait (or command
round trip) through `Lifecycle.Execute` and asserts the post-wait effect:

| Path | Wait / round trip | Post-wait destructive command | Disposition | Probe |
|---|---|---|---|---|
| stop escalation | `has-session` poll | `kill-session` | CLOSED: recheck refuses (stale/unauthorized/stop_timeout), kill never issues | `TestExecuteStopRefusesStaleFactsAfterPoll` (generation/authorization/deadline/deadline-instant) + `TestExecuteStopEscalatesAfterGracefulTimeoutAlone` control |
| quiesce detach | lock round trip | `detach-client` | CLOSED: mid-sequence recheck refuses, detach never issues | `TestExecuteQuiesceRefusesStaleFactsBetweenCommands` (3 facts) |
| attach | admission + barrier | receipt commit | CLOSED: waits bounded (P2) + rev7 post-lock rechecks | `TestAttachWaitBoundedByOperationDeadline`, `TestAttachWaitCancelledReturnsPromptly` + rev7 recheck tests |
| create | none (single command) | none exists | STRUCTURAL: exactly one scripted command; any second command reddens the unscripted call | `TestEffectBoundaryAuditCreateIssuesSingleCommand` |
| restore | none (single command) | none exists | STRUCTURAL: same shape | `TestEffectBoundaryAuditRestoreIssuesSingleCommand` |
| terminate tail | re-confirm poll | none follows the wait | MEASURED: kill count stays one, refusal stands however the facts moved | `TestEffectBoundaryAuditTerminateIssuesNoPostWaitCommand` |
| boundary tail | wrapper-signal wait | none (read-only rows probe) | MEASURED: post-signal command is `list-panes` only, proof commits | `TestEffectBoundaryAuditBoundaryTailIsReadOnly` |
| quiesce span / boundary commit | barrier acquisition | engine / report commit | CLOSED: same wait contract, row's own timeout | `TestQuiesceBarrierWaitBoundedByOperationDeadline`, `TestBoundaryCommitWaitBoundedByOperationDeadline`, `TestQuiesceMalformedDeadlineRefusesBeforeBarrierWait` |

## Keyed verdicts (evidence map)

- [V-rev8-P1-A] FIXED — `TestExecuteStopRefusesStaleFactsAfterPoll`
  (mirrors the rev7 reviewer probe shape: 5ms graceful wait, fact change
  at +3ms, clock +10ms): kill absent from the argv record on all four
  facts; `Effects == [graceful_stop_requested]`; literal codes
  `terminal_backend_stale_generation` / `terminal_backend_unauthorized` /
  `stop_timeout`. `TestExecuteStopEscalatesAfterGracefulTimeoutAlone`
  proves a graceful timeout still escalates exactly once.
- [V-rev8-P1-A-quiesce] FIXED — `TestExecuteQuiesceRefusesStaleFactsBetweenCommands`:
  detach absent on all three facts; literal row codes.
- [V-rev8-P2] FIXED — `TestAttachWaitBoundedByOperationDeadline`
  (admission/barrier, non-cooperative adapter, 200ms deadline, release at
  +1s): refusal before the release with `terminal_backend_timeout`, no
  argv, no receipt at release, no receipt after the settle window.
  `TestAttachWaitCancelledReturnsPromptly`: expired+cancelled returns
  with no unlock. Quiesce/boundary twins prove the uniform contract.
- [V-rev8-overlap] FAIL-CLOSED — `TestAttachOverlapRequiresMultiAttach`
  (reviewer scenario 1 shape: first without the capability, second
  refuses with no receipt, second with the capability succeeds, third
  without refuses over two peers),
  `TestAttachOverlapInputRequiresMultipleInputClients` (reviewer
  scenario 2 shape + read-only-stays-admitted + two-peer precision),
  `TestAttachSameClientRetryIgnoresOverlap` (idempotent replay on the
  transport capability alone),
  `TestAttachOverlapPeerReadFailureFailsClosed` (corrupt peer errors,
  no receipt). Liveness stays out: bound B44 names
  TASK-260922-vcx6yo (`active-client-census-and-overlap-admission`,
  status backlog at handoff) as the census owner; the §4.C attach row
  claims only the fail-closed gate.
- [V-rev8-flaky] REPAIRED — `TestWrapperRestoreRefreshBoundEnforced` is
  release-controlled: the adapter blocks on the test channel, the entry
  must return while it is provably still blocked (deterministic proof,
  no tight ceiling), then the release drains the goroutine. The 52.9ms
  race failure mode (scheduler skew vs a 50ms ceiling) cannot recur;
  the remaining 500ms ceiling is promptness-only with 10x margin.
- [V-rev8-shadow] DOCUMENTED — `D-attach-entry-deadline-shadowed`:
  the wait bound refuses the entry arm's instant member with the same
  verdict before any admission runs, so the entry narrowing survives by
  reroute and is reclassified supplementary (deterministic via
  fired-context pre-checks; verified SURVIVED ×3). The enforced
  boundary is measured by `N-attach-postlock-deadline` +
  `N-attach-wait-deadline`; the entry arm stays as fail-fast
  precedence pinned behaviorally.
- [V-8of8] 8/8 operations driven through `Lifecycle.Execute`
  (lifecycle.go:192): create→executeCreate (lifecycle.go:392),
  attach→executeAttach (ops.go:68), status→executeStatus
  (lifecycle.go:454), quiesce/boundary/stop→executeEngineOp
  (lifecycle.go:480), terminate-stale→executeTerminate (ops.go:343),
  restore→executeRestore (ops.go:493), plus
  `ExecuteWrapperRestore` (wrapper.go:100). Per-operation tests in the
  matrix ops table; every AC message/state/refusal named in rows 59-92
  is driven or bound (34/34 rows green).
- [V-census] 261 measured of 5376 (50+10+201 M; Table C all U), 187
  stated bounds, 155 named undriven gaps, 4928 unreachable with
  reasons — verified by script over the tables. New Table D rows:
  effectrecheck (EXE, stop 4 / quiesce 4: 3 shared arms + 1 per-site
  skip each), overlapmulti + overlapinput (EXA, single-sided),
  waitbound (EXA 1 / EXE 1 shared, 4 killers + cancellation
  companion). Tables B/D byte-identical with TRACEABILITY, AC rows
  mirrored ×2, bounds B22-B44 byte-identical (mirror check in the
  evidence).
- [V-battery] tmuxserver 293/293 as expected on two full passes
  (286 narrowing KILLED incl. 8 new, 5 supplementary KILLED, 1
  supplementary SURVIVED-shadowed, control SURVIVED; second leaf owns
  213 net: 216 added, 3 reclassified), one raw log per plant per
  pass; termbind 41/41 as expected on two verbose passes (39
  narrowing incl. `N-attach-peers-decode`, 1 supplementary, control).
  334/334 rows total. Shared-site rows kill through every claimed
  entry with per-test attribution from the raw logs; precision legs
  (other-fact subtests, two-peer legs, cancellation companion) stay
  green under the plants.
- [V-compose] Outcome grid over the same 36-package corpus: 198
  shared keys, 0 moved, 0 base-only, 11 declared candidate-only (7
  story + 4 new `Peers` keys), 6/6 stable. Suite-verdict grid:
  23,874 shared, 0 moved, 0 base-only, 549 candidate-only additions,
  0 fails. No input moved across any admission or refusal arm.
- [V-real-tmux] No committed test execs a real tmux or dials a real
  tmux server socket (determinism design, bound B1): the restricted-
  PATH loopback run passes with the host tmux unresolvable, and no
  acceptance row relies on a real-tmux witness. The eight timing
  tests (3 refresh + 5 wait) decide on release-controlled instants
  or generous guards, never on tight scheduler margins.
- [V-validate] All 30 configured validation commands pass firsthand
  (gofmt/build/vet/full suite/race/cover/17 fuzz/tracecheck/
  cataloggen/linux+windows builds/JSON/task-board validate/
  diff-check), plus windows vet, package race, and the no-tmux
  loopback. Logs in the evidence tarball.

## Files

- Production: `internal/tmuxserver/backend.go`,
  `internal/tmuxserver/lifecycle.go`, `internal/tmuxserver/ops.go`,
  `internal/termbind/overlap.go` (new).
- Tests: `internal/tmuxserver/lifecycle_rev8_unix_test.go` (new, 19
  tests), `internal/termbind/overlap_test.go` (new, 4 tests),
  `internal/tmuxserver/wrapper_unix_test.go` (flaky-test repair),
  fixture updates (`ServerAdmission` context signature,
  `fullLifecycleAdmitted` + `multiple_input_clients`, helper
  permissive recheck with the entry contract pinned through
  `Execute`).
- Harnesses: 8 new + 6 repaired tmuxserver rows (1 reclassified),
  1 new termbind row.
- Docs: `internal/tmuxserver/TRACEABILITY.md` (census 144 gates,
  AC rows, B22/B44, battery), `internal/termbind/TRACEABILITY.md`
  (row 68 + mutant row), `README.md` (narrowed recheck/wait/overlap
  prose + battery counts), `LOGBOOK.md` (rev8 entry),
  `TASK-260830-1c28dz_conformance-matrix.md` (board attachment,
  mirrored).
