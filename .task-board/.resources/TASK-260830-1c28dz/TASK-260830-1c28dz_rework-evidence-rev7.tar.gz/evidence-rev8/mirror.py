#!/usr/bin/env python3
"""Mirror check: Table B/D rows and AC rows identical between TRACEABILITY and matrix.

Table B/D: same row multiset in both files. AC rows: every TRACEABILITY AC
row text appears exactly twice in the matrix (summary + section).
Usage: mirror.py <traceability.md> <matrix.md>
"""
import re
import sys
from collections import Counter

def table_rows(text, name, table_a=True):
    lines = text.split("\n")
    idxs = [i for i, l in enumerate(lines) if l.startswith("| Gate (site) |")]
    order = {"A": 0, "B": 1, "D": 2} if table_a else {"B": 0, "D": 1}
    start = idxs[order[name]]
    rows = []
    for line in lines[start + 2:]:
        if not line.startswith("|"):
            break
        rows.append(line)
    return rows

def ac_rows(text):
    rows = []
    for l in text.split("\n"):
        m = re.match(r"^\| (\d+) \|", l)
        if m and 59 <= int(m.group(1)) <= 92:
            rows.append(l)
    return rows

def main(trace_path, matrix_path):
    trace = open(trace_path).read()
    matrix = open(matrix_path).read()
    for name in ("B", "D"):
        t, m = table_rows(trace, name), table_rows(matrix, name, table_a=False)
        status = "IDENTICAL" if Counter(t) == Counter(m) else "DIFFERS"
        print(f"{name}: trace={len(t)} matrix={len(m)} {status}")
        if status == "DIFFERS":
            for row in (Counter(t) - Counter(m)):
                print(f"  trace-only: {row[:100]}")
            for row in (Counter(m) - Counter(t)):
                print(f"  matrix-only: {row[:100]}")
    ta, ma = ac_rows(trace), ac_rows(matrix)
    cm, ca = Counter(ma), Counter(ta)
    ok = all(ma.count(r) == 2 for r in ca) and set(cm) == set(ca)
    print(f"AC: trace={len(ta)} matrix={len(ma)} {'MIRROREDx2' if ok else 'DIFFERS'}")
    if not ok:
        for r, c in cm.items():
            if ca.get(r, 0) * 2 != c:
                print(f"  matrix x{c}: {r[:100]}")

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
