//go:build !windows
package tmuxserver
import("context";"testing";"time";"os";"sync/atomic")
func TestReviewAttachDeadlineAfterAdmission(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 fx.lc.ServerAdmission=func()(RealmAdmission,error){fx.clock.Sleep(7*time.Hour);return RealmAdmission{Admitted:fullLifecycleAdmitted(),RawGeneration:lxGeneration},nil}
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()})
 _,found,lookupErr:=fx.lc.Attach.Lookup(lxSession,lxInstance,lxClient)
 if lookupErr!=nil{t.Fatal(lookupErr)}
 if err==nil || found {t.Fatalf("expired request committed: now=%v err=%v receipt=%v attach=%+v argv=%v",fx.clock.Now(),err,found,out.Attach,out.Argv)}
}

func TestReviewAttachGenerationAfterLockWait(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());var changed atomic.Bool; arrived:=make(chan struct{},1)
 fx.lc.CurrentGeneration=func()string{if changed.Load(){return "generation-two"};return lxGeneration}
 fx.lc.ServerAdmission=func()(RealmAdmission,error){g:=fx.lc.CurrentGeneration();arrived<-struct{}{};return RealmAdmission{Admitted:fullLifecycleAdmitted(),RawGeneration:g},nil}
 fx.lc.barrierMu.Lock()
 done:=make(chan error,1);body:=lxAttachBody(t,nil)
 go func(){out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:body,Source:"parked",Admitted:fullLifecycleAdmitted()});if err==nil{t.Errorf("stale generation authorized writable attach: %+v",out.Attach)};done<-err}()
 <-arrived;changed.Store(true);fx.lc.barrierMu.Unlock()
 select{case <-done:case <-time.After(5*time.Second):t.Fatal("attach stuck")}
}
func TestReviewCustodyFourEntries(t *testing.T) {
 for _,op:=range []string{"quiesce-input","wait-safe-boundary","request-stop","terminate-stale"}{t.Run(op,func(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());r:=OpRequest{Operation:op,Admitted:fullLifecycleAdmitted()}
 switch op {
 case "quiesce-input":r.Body=lxQuiesceBody(t,nil);r.Source="active";fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 case "wait-safe-boundary":r.Body=lxBoundaryBody(t,"ax_checkpoint_boundary",60000,nil);r.Source="quiescing";fx.runner.queue("wait-for","",0)
 case "request-stop":r.Body=lxStopBody(t,60000,nil);r.Source="quiescing";fx.runner.queue("send-keys","",0).queueFull("has-session","","can't find session: "+lxInstance,1)
 case "terminate-stale":r.Body=lxTerminateBody(t,nil);r.Source="stale_fenced";r.Presented,r.Winner=terminateFencing();r.HasWinner=true;r.ForceRecovery=true;r.DiagnosticsPreserved=true;fx.runner.queue("kill-session","",0).queueFull("has-session","","can't find session: "+lxInstance,1)
 }
 if err:=os.Chmod(fx.root,0777);err!=nil{t.Fatal(err)}
 out,err:=fx.lc.Execute(context.Background(),r)
 if err==nil||fx.runner.callCount()!=0{t.Fatalf("unsafe root admitted: err=%v effects=%v outcome=%+v",err,fx.runner.subcommands(),out)}
 requireLocalCode(t,err,"tmux_unsafe_socket_path","socket root")
 })}
}

func TestReviewAttachAuthorizationMembers(t *testing.T) {
 for _,member:=range []string{"expiry","input","transport"}{t.Run(member,func(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 body:=lxAttachBody(t,func(o map[string]any){a:=lxAttachAuth("local_only",true);switch member{case "expiry":a["expires_at"]=fx.clock.Now().Format("2006-01-02T15:04:05.000Z");case "input":a["input_authorized"]=false;case "transport":a["transport"]="trusted_private_mesh"};o["authorization"]=a})
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:body,Source:"parked",Admitted:fullLifecycleAdmitted()})
 _,found,lookupErr:=fx.lc.Attach.Lookup(lxSession,lxInstance,lxClient);if lookupErr!=nil{t.Fatal(lookupErr)}
 if err==nil||found{t.Fatalf("unauthorized effect: member=%s err=%v receipt=%v attach=%+v",member,err,found,out.Attach)}
 requireLandedCode(t,err,"terminal_backend_unauthorized")
 })}
}
