# TASK-260830-1c28dz rework rev6 — results (standalone)

Ready for review. This run answers the rev5 CHANGES REQUESTED on
checkpoint `d4bd91d0` (trunk unmoved, no rebase): P1-B, P2-A, P2-B
and P3 close with instruments; P1-A is escalated as the structural
receipt-owner contract the brief explicitly accepts as a complete
revision 6, with its boundary stated and every P1-A-adjacent claim
narrowed to match. The worktree is intentionally UNCOMMITTED for
the Story handoff snapshot.

Scope of the production delta (all in `internal/tmuxserver`):
`lifecycle.go` (ordering-lock field, quiesce/boundary report
spans), `ops.go` (authoritative attach recheck under the lock).
No other production file changed. Touched landed files: none this
round (error registry, ownership seam, and harnesses keep their
prior-revision changes).

## Finding-by-finding disposition

| # | Verdict finding | Disposition | Witness |
|---|---|---|---|
| P1-A | outcome-report write failure after committed closure reopens input (third boundary) | ESCALATED — bound B43: owner `internal/terminstance ReceiptStore`, scoped contract is completed-closure enumeration distinguishing pending-without-completion from completed; row 79 narrowed to the lost state-record write, B34 discloses reopening, README narrowed | B43 text in TRACEABILITY + matrix; no fourth guard added |
| P1-B | in-flight attach commits after successful quiescence (logical check/use race, no data race) | FIXED — one ordering contract at the effect boundary: attach rechecks the barrier under `barrierMu` immediately before its receipt commit and holds it through receipt, returned vector, and memory; quiesce holds it across engine closure plus report, boundary across its report only | `TestAttachRefusesAfterQuiescenceWhenAdmittedLate`, `TestAttachQuiesceOrderingOverlapQuiesce`, `TestAttachQuiesceOrderingOverlapBoundary` via `Lifecycle.Execute`; narrowings `N-attach-barrier-recheck`, `N-ordering-lock-{attach,quiesce,boundary}` |
| P2-A | three read-error narrowings survive (incarnation EISDIR, outcomes ENOTDIR, outcome-file EISDIR) | FIXED — three production-entry tests plus three reviewer-shaped narrowings; attach custody entry carries its own valid-body test plus narrowing | tests + `N-incarnation-read-absent`, `N-outcomes-dir-read-absent`, `N-outcome-file-read-skip`, `N-attach-entry-root-custody` |
| P2-B | corpus excludes cloneproject, sshtransport, crashgate on a false premise | FIXED — five representative rows added; corpus covers 36/36 with no exclusion bounds | closure grid 198 shared keys, 0 moved; verdict grid 23,874 shared, 0 moved |
| P3 | Table C denominator stale (129 vs 137 gates); attach "lease members" prose; README/row-79 overclaims | FIXED — Table C recounted from the Table D gate set (140 gates incl. 3 new); row 72 corrected; README + row 79 narrowed | recount script over both tables; mirror check TRACEABILITY vs matrix |

## P1-A — escalation with the boundary (no fourth guard)

Three boundaries in three rounds is structural: the barrier is
reconstructed from whichever storage artefact survived, so the
failure to create the outcome proof reads as permission. This
revision does not add another guard. Bound B43 (in TRACEABILITY
and mirrored in the matrix) states:

- Owner: `internal/terminstance ReceiptStore` (landed receipt
  owner). Scoped contract: completed-closure enumeration — the
  completed quiesce/boundary receipts for one instance,
  distinguishing pending-without-completion from completed — so
  attach admission can consult receipt completion as the
  authoritative proof with pending-versus-committed
  representable. This leaf owns the admission side once it
  lands.
- Boundary: a lost outcome-report write after committed closure
  admits a fresh writable attach until the identical retry heals
  the report; the same window covers a crash between the receipt
  commit and the report, and a simultaneous loss of both the
  report and the state record. Retrying the identical quiesce
  heals the report and re-closes input; no other production
  entry heals it.

Every P1-A-adjacent claim now matches the boundary: row 79
claims only the lost state-record write fails closed (still
proven by `TestExecuteQuiesceStateWriteFailureRefusesWiredAttach`
through the wired attach); B34 discloses reopening before retry;
the README refuses new writable attaches only once the closure
report commits. The rev5 construction (incarnation-scoped proof,
advisory-memory split, writer/reader censuses) stands unchanged
around the bound: the rev4 regressions
(`TestReviewExistingActiveMemoryCannotReopenQuiescedInput`,
`TestReviewFailedStopCannotEraseQuiescence`) and the legitimate
reopening (`TestExecuteQuiesceStopRestoreReopensBarrier`) all
still pass.

## P1-B — one ordering contract at the effect boundary

`Lifecycle.barrierMu` serializes the input-closure ordering
contract: the quiesce report commit, the boundary report commit,
and the attach writable-receipt commit (barrier recheck, client
receipt, returned vector, advisory memory) are mutually
exclusive, so whichever lands first wins and no writable receipt
commits after a durable closure report.

- Attach side (`ops.go:executeAttach`): the fast-path check and
  the server admission run outside the lock (admission may
  block); the authoritative recheck runs under the lock
  immediately before the receipt commit, and the lock holds
  through the receipt, the returned vector, and the memory
  record. The check did not merely move: without the lock the
  overlap tests observe the attach completing mid-commit.
- Quiesce side (`lifecycle.go:executeEngineOp`): the lock spans
  the engine input closure and the report commit, so no receipt
  commits between the tmux closure effects and their durable
  proof. Its tmux effects return immediately, so the span never
  blocks on a signal.
- Boundary side: the wait runs outside the lock (it blocks on
  the wrapper signal); only the report commit serializes.

The covered vector handoff ends at vector construction: a
caller that execs a pre-quiescence vector after quiescence
commits holds a pre-quiescence authorization, which quiesce does
not revoke (stated on the field and in B42). Cross-process
attach/quiesce races observe only the report files (bound B42:
closing needs a lock file; no committed test stages two
processes).

Narrowings (all instance-scoped, all KILLED):
`N-attach-barrier-recheck` (recheck bypassed for the fixture
instance — the late attach succeeds),
`N-ordering-lock-attach`, `N-ordering-lock-quiesce`,
`N-ordering-lock-boundary` (one side unlocked for the fixture
instance — the attach completes mid-commit). Symmetry: attach
1 / quiesce 1 / boundary 1. The late-attach and both overlap
tests pass twice under `-race` with no data-race diagnostic.

## P2-A — the three read-error clauses, witnessed

| Gap | Committed test (production entry) | Harness row (reviewer plant shape) |
|---|---|---|
| R1 incarnation EISDIR as absence | `TestExecuteAttachErrorsOnIncarnationReadFailure` via `Execute(attach)` (incarnation path staged as a directory) | `N-incarnation-read-absent` — admits exactly EISDIR past the absent arm |
| R2 outcomes ENOTDIR as absence | `TestExecuteAttachErrorsOnOutcomesDirReadFailure` via `Execute(attach)` (outcomes path staged as a file) | `N-outcomes-dir-read-absent` — admits exactly ENOTDIR past the absent arm |
| R3 outcome-file EISDIR skipped | `TestExecuteAttachErrorsOnOutcomeFileReadFailure` via `Execute(attach)` (`.json` symlink to a directory, kept by the entry pre-filter) | `N-outcome-file-read-skip` — admits exactly `deadbeef.json` past the error arm |

Each test asserts the production read-failure string and zero
tmux execs; each plant makes the attach succeed. The attach
custody entry now carries its own valid-body test
(`TestExecuteAttachRefusesWritableRootValidBody`) plus
`N-attach-entry-root-custody` (reviewer R4 shape: custody
bypassed only for attach — the weakened attach is served,
proving admission rather than rerouting to a body refusal).

## P2-B — importer outcome corpus, 36 of 36

The fixed-corpus driver (ships in the evidence tarball) gains
five rows and loses all three exclusion bounds:

- `cloneproject.Normalize` no-fetcher and no-sink refusals
  (deterministic pre-effect arms);
- `sshtransport.New(config.Snapshot{})` invalid-snapshot
  refusal (no SSH, no network);
- `crashgate.Lookup` known (`CR-LAUNCH-D-01`) and unknown
  boundary rows.

Outcome grid over the reviewer's 36-package closure (34
production + crashgate + environ): 198 shared
`(package, entry, input)` keys, MOVED 0, base-only 0,
candidate-only 7 (the declared `CheckSocketLength` × 2 and
`ClassifyStatus` × 5 story-added entries). Stability: 6/6
identical candidate runs (sha256 match). Suite verdicts over
the complete importer set: 23,874 shared `(package, test)`
keys, zero moved verdicts, zero base-only, 505 candidate-only
additions (500 tmuxserver incl. subtests, 5 termbind), all
PASS, 0 FAILs. No input moved across any admission or refusal
arm: the outcome grid names every probed input and every one
is identical or declared.

## P3 — census denominator and prose, item by item

- Table C derives its gate set from Table D: 140 gates × 11 =
  1540 cells (1522 U2a + 18 U2c), adding the 8 revision-5 gates
  the verdict named plus the 3 revision-6 gates (recheck,
  ordering, barrierread). Total census: 255 measured of 5248
  (50+10+195 M; 186 bound; 4807 unreachable), recount verified
  by script over TRACEABILITY and over the matrix.
- Revision-6 Table D: 140 rows × 21 = 2940 (195 M, 182 B, 2563
  U). New rows recheck (EXA 1), ordering (EXA 1 / EXE 2),
  barrierread (EXA 2 arms); incarnationlookup EXA moves B39 →
  measured; rootwrite EXA gains the attach entry row. Every
  two-sided gate carries its symmetry line (ordering attach 1 /
  quiesce 1 / boundary 1; barrierread directory 1 / file 1;
  incarnationlookup EXA 1 / LOOK 3 on different arms; rootwrite
  CUS 1 / EXC 1 / EXA 1 / EXS 1 / EXR 1 / SPW 1 + shared row).
- Row 72 corrected: the attach authorization is
  ownership-neutral with no lease member (identity, client,
  transport, input flag, deadline listed literally).
- Row 79, B34, and the README narrowed to the B43 boundary as
  listed above; battery counts updated (281 tmuxserver rows:
  277 narrowing + 3 supplementary + control; 321/321 across
  both harnesses).

## Census and ratios

- Gate × entry census: 255 measured of 5248 (50+10+195 M
  across Tables A/B/D; Table C all U); 186 bound; 4807
  unreachable with reasons; 155 named undriven gaps (147 B39 +
  8 named cells; B40/B41/B42/B43 are non-cell bounds). Tables
  B/D and bounds B22-B43 are byte-identical between
  TRACEABILITY and the conformance matrix (mirror check in the
  evidence).
- AC rows 59-92: 34 of 34 driven through production entries by
  named tests (call sites in the matrix).
- Eight operations, 8 of 8, each through `Lifecycle.Execute`
  (`lifecycle.go`) by a named committed test: create
  (`TestExecuteCreateInteractive`), attach (`TestExecuteAttach`),
  status (`TestExecuteStatusPresent`), quiesce
  (`TestExecuteQuiesce`), safe-boundary (`TestExecuteBoundary`),
  stop (`TestExecuteStop`), stale termination
  (`TestExecuteTerminate`), restore (`TestExecuteRestore`).
- Mutant battery: 281/281 tmuxserver rows as expected (277
  narrowing `N-*` KILLED + 3 additive `D-*` KILLED, shared
  control SURVIVED), 40/40 termbind rows as expected; one raw
  log per plant in the tarball. 8 new tmuxserver rows this
  round, all narrowing.
- No-real-tmux: zero real-tmux witnesses by the determinism
  design (bound B1); the suite passes with the tmux binary
  unresolvable (1000 passing test events, zero failures, zero
  skips in the changed packages; no tmux process before, during,
  or after).
- Handovers retained: exec/probe adapters driven (unchanged);
  B18 sun_path, B16 ambient, B19/B20 custody, and the P3-A
  fresh-decoy attestation witnesses all still pass; this leaf
  extends the landed termbind owner for successor minting and
  composes terminalbackend, terminstance, axpane, and fencing
  without forking (no landed production file touched this
  round).

## Validation (all exit 0, this run)

| Gate | Result |
|---|---|
| `go test ./... -count=1` candidate / base | 45 ok / 45 ok |
| `go test -race` tmuxserver + termbind | ok, no races |
| `go test ./... -cover` | ok (tmuxserver 88.3%, termbind 83.5%) |
| `go vet ./...` + `GOOS=windows go vet ./...` | clean |
| `gofmt -l` | clean |
| tmuxserver harness 281 + termbind harness 40 | all as expected |
| no-tmux PATH run (changed packages) | green, zero skips |
| closure grid determinism | 6/6 identical streams |
| census recount + matrix mirror check | counts match; tables/bounds byte-identical |
| full configured suite (30 commands) | green firsthand |

## Evidence

- `TASK-260830-1c28dz_conformance-matrix.md` (updated, attached):
  AC rows, ops table, mirrored census Tables B/C/D + Table E,
  bounds B22-B43, battery, crash/idempotency.
- `TASK-260830-1c28dz_rework-evidence-rev6.tar.gz` (attached):
  closure grid driver + base/candidate streams + diff,
  per-test verdict streams + diff, full suite logs both trees,
  281 + 40 raw per-plant harness logs, vet/fmt/race/cover/
  no-tmux logs, census recount, mirror check, SHA256SUMS.
- Handoff: ready for review; candidate UNCOMMITTED in the
  Story worktree for snapshot.
