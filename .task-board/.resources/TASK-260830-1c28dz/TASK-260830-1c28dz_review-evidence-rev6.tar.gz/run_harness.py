import runpy,sys,pathlib,time,os
os.environ["PYTHONDONTWRITEBYTECODE"]="1"
root=pathlib.Path(__file__).resolve().parent
m=runpy.run_path(str(root/(sys.argv[5] if len(sys.argv)>5 else "mutants")/"internal"/sys.argv[1]/"mutant_harness.py"))
rows=m["MUTANTS"][int(sys.argv[2]):int(sys.argv[3])]
out=root/("harness-"+sys.argv[4]+"-"+sys.argv[1]);out.mkdir(exist_ok=True)
for row in rows:
 print(m["run_mutant"](row,out),flush=True)
