# Reviewer setup failures (not behavioral evidence)

- Initial go-testing-tools path was absent in this Story archive; read the Curator-managed skill from the control repository instead.
- An unsupported resources() query failed; recovered with scoped get(...){outcomeResources}.
- The first regression writer resolved its scratch path against the scratch cwd twice and raised FileNotFoundError. An early Go call ran before archive extraction completed and reported setup failed. Corrected with absolute working directories before recording the actual regressions.
- One preliminary auth-baseline invocation used the live worktree with a reviewer-only test mask and matched no tests. It is not counted. No live source was modified; actual probes were subsequently executed in the attacks archive.
- The broader A3 count=2 run is inconclusive for whole-repository survival: environ audit failure reproduces unchanged at count=2, and sessquery timed out. Its real exit 1 and full output are preserved.
