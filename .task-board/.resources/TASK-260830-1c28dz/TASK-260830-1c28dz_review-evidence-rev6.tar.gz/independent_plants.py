import pathlib,subprocess,time,json,difflib
p=pathlib.Path(__file__).resolve().parent;r=p/"attacks";f=r/"internal/tmuxserver/lifecycle.go";original=f.read_text()
anchor="if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {"
rows=[("R1", "OperationQuiesceInput"),("R2","OperationWaitSafeBoundary"),("R3","OperationRequestStop"),("R4","OperationTerminateStale"),("C",None)]
for name,op in rows:
 replacement=anchor.replace("err != nil {", "err != nil && operation != terminalbackend."+op+" {") if op else anchor+" // harmless reviewer control"
 assert original.count(anchor)==1
 mutated=original.replace(anchor,replacement);f.write_text(mutated)
 (p/(name+".patch")).write_text("".join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True))))
 try:
  start=time.time();cmd=["go","test","./internal/tmuxserver","-run","^TestExecute","-count=2","-v"];z=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=240)
  (p/(name+".log")).write_text("exit: "+str(z.returncode)+" elapsed: "+str(time.time()-start)+" command: "+str(cmd)+"\n"+z.stdout+z.stderr)
  print(name,z.returncode,flush=True)
 finally:f.write_text(original)
