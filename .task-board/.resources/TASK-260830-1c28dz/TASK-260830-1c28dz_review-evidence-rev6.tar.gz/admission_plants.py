import pathlib,subprocess,time,difflib,json
p=pathlib.Path(__file__).resolve().parent;r=p/"attacks";f=r/"internal/terminalbackend/conformance.go";original=f.read_text()
review=r/"internal/tmuxserver/reviewer_rev6_unix_test.go";saved=review.read_bytes();review.unlink()
rows=[("A1-transition",'if !allowed {','if !allowed && !(parsedOperation == OperationAttach && parsedSource == StateStopped) {'),("A2-expiry",'if !now.Before(expires) {','if !now.Before(expires) && !now.Equal(expires) {'),("A3-input",'if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {','if requested != auth.Transport || (inputAuthorized != auth.InputAuthorized && !inputAuthorized) {'),("A4-transport",'if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {','if (requested != auth.Transport && requested != TransportLocalOnly) || inputAuthorized != auth.InputAuthorized {'),("A-control",'// CheckAttachRequest','// Harmless reviewer control.\n// CheckAttachRequest')]
try:
 for name,anchor,replacement in rows:
  assert original.count(anchor)==1,(name,original.count(anchor))
  mutated=original.replace(anchor,replacement);f.write_text(mutated);(p/(name+".patch")).write_text("".join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True))))
  try:
   start=time.time();cmd=["go","test","./internal/tmuxserver","-count=2","-v"];z=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=240)
   (p/(name+".log")).write_text("exit: "+str(z.returncode)+" elapsed: "+str(time.time()-start)+" command: "+str(cmd)+"\n"+z.stdout+z.stderr);print(name,z.returncode,flush=True)
  finally:f.write_text(original)
finally:review.write_bytes(saved)
