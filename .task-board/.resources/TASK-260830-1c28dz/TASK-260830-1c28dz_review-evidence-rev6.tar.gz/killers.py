import pathlib,subprocess,time,difflib
p=pathlib.Path(__file__).resolve().parent;r=p/"attacks"
rows=[("A2-expiry","internal/terminalbackend/conformance.go",'if !now.Before(expires) {','if !now.Before(expires) && !now.Equal(expires) {',"^TestReviewAttachAuthorizationMembers$/expiry"),("A3-input","internal/terminalbackend/conformance.go",'if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {','if requested != auth.Transport || (inputAuthorized != auth.InputAuthorized && !inputAuthorized) {',"^TestReviewAttachAuthorizationMembers$/input"),("A4-transport","internal/terminalbackend/conformance.go",'if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {','if (requested != auth.Transport && requested != TransportLocalOnly) || inputAuthorized != auth.InputAuthorized {',"^TestReviewAttachAuthorizationMembers$/transport")]
for i,op in enumerate(["OperationQuiesceInput","OperationWaitSafeBoundary","OperationRequestStop","OperationTerminateStale"]):
 a="if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {";b=a.replace("err != nil {","err != nil && operation != terminalbackend."+op+" {");rows.append(("R"+str(i+1),"internal/tmuxserver/lifecycle.go",a,b,"^TestReviewCustodyFourEntries$"))
for name,path,a,b,mask in rows:
 f=r/path;original=f.read_text();assert original.count(a)==1;f.write_text(original.replace(a,b))
 try:
  cmd=["go","test","./internal/tmuxserver","-run",mask,"-count=2","-v"];start=time.time();z=subprocess.run(cmd,cwd=r,capture_output=True,text=True,timeout=240);(p/(name+"-killer.log")).write_text("exit: "+str(z.returncode)+" elapsed: "+str(time.time()-start)+"\n"+z.stdout+z.stderr);print(name,z.returncode,flush=True)
 finally:f.write_text(original)
