# TASK-260830-1c28dz — Producer results, rev4 (tmux lifecycle operations)

Revision-4 rework on checkpoint `d4bd91d0` (STORY-260830-2t4g7i
worktree, branch `task-board/story/STORY-260830-2t4g7i`,
uncommitted). Closes the three rev3 P1s, P2-A, P2-B, and the four
surviving narrowings plus the SPW custody fifth. Production `.go`
delta is purely additive (0 deleted lines across the three touched
landed files; every other production file is new) — see
`grid/additive_diff.txt`.

## Revision-4 fixes (reviewer P1/P2/R1-R5)

P1-A (quiescence fails open after state write fails;
`internal/tmuxserver/lifecycle.go:executeEngineOp`,
`ops.go:checkAttachQuiesced`, `state.go:QuiesceBarrierProven`).
The barrier write is fail-closed now: quiesce-input and
wait-safe-boundary return `terminal_backend_integrity_failure`
at `quiesce/boundary state image` when their memory write fails,
and the closure-outcome report commits BEFORE the memory write
so the identical retry replays the original closure time and
heals the barrier. When the memory holds no record, attach
recovers the barrier from the completed quiesce/boundary
outcomes for the instance instead of mistaking the loss for an
open input; a corrupt scan or an empty closure time errors.
Non-barrier operations keep advisory memory (their lost writes
never admit input — pinned by
`TestRecordFailureLeavesPresenceReconciliation`). Five committed
tests
(`TestExecuteQuiesceStateWriteFailureRefusesWiredAttach`,
`TestExecuteQuiesceRetryAfterStateWriteFailureHealsBarrier`,
`TestExecuteBoundaryBarrierSurvivesStateWriteFailure`,
`TestExecuteAttachErrorsOnCorruptBarrierScan`,
`TestExecuteAttachErrorsOnEmptyBarrierTime/quiesce,boundary`)
drive the reviewer 2-call sequence plus healing, boundary-arm
isolation, corrupt-scan, and empty-time shapes through
`Execute` with literal code assertions. Seven narrowing rows
(`N-quiesce-state-record`, `N-boundary-state-record`,
`N-attach-barrier-quiesce-recovery`,
`N-attach-barrier-boundary-recovery`,
`N-attach-barrier-corrupt-scan`,
`N-attach-barrier-empty-quiesce`,
`N-attach-barrier-empty-boundary`) KILLED; the pre-existing
`N-quiesce-attach-gate` row re-anchored to the restructured
check and still KILLED.

P1-B (refreshed lease decision not bound to executed restore;
`internal/tmuxserver/wrapper.go:checkRestoreWinnerBound`). The
launch/reattach arms refuse `local_precondition_failed` at
`wrapper restore winner binding` before any effect unless the
carried restore authorization `(lease_id, lease_epoch)` equals
the ordered winner — the decision, the binding, and the backend
restore (which still authorizes against the current lease)
form one authorization. Backend restore authorization is
never weakened to make the join fit. Three committed tests
(`TestWrapperRestoreRefusesDivergentWinner` — the reviewer
sequence — plus `...Lease` and `...Epoch` single-arm
isolations) and two narrowing rows
(`N-wrapper-winner-lease`, `N-wrapper-winner-epoch`) KILLED.
The honest launch/reattach tests (winner == carried auth)
still execute.

P1-C (expired refresh accepted; bound only cooperative;
`internal/tmuxserver/wrapper.go:refreshWinner`). The adapter
runs on its own goroutine and the entry takes whichever
answers first — the adapter or the deadline. Late answers
never verify even with a nil error (expiry is checked on the
answer path too, because both arms can be ready at once), and
a non-cooperative adapter loses at the bound (measured 9.9ms
wall for a 1ms bound against a 100ms ignoring adapter).
`TestWrapperRestoreRefreshRaceRejectsLateAnswer` stalls the
select hook twenty times past the bound to force the
both-ready race deterministically (20/20 parks; the expired
mutant kills through it twice-verified). The cooperative
`configured-50ms` subtest dropped its shared-var observation
(unsynchronized by design under enforcement — it would race)
and tightened elapsed 5s→1s. Two narrowing rows
(`N-wrapper-refresh-expired`, `N-wrapper-refresh-deadline`)
KILLED. Bound B37 states the missing production mesh
transport: the composition enforces the bound on any injected
adapter.

R1-R5 (reviewer narrowings; corrected R5 plant). Five committed
clause witnesses through the production entries
(`TestExecuteStatusAttachedExitIsUnknown`,
`TestExecuteStatusForeignAttachedRowIsUnknown`,
`TestExecuteStatusUnknownPanesExitIsUnknown`,
`TestOSRunnerRefusesNulArgument`,
`TestServerSpawnerRefusesWritableRoot`) plus five harness rows
with the reviewer's exact plants
(`N-status-attached-exit`, `N-status-foreign-row`,
`N-status-panes-unknown-exit`, `N-osrunner-argv-nul`,
`N-spawn-root-custody`) KILLED. The SPW rootwrite cell moves
B39→M, closing the already-owned spawner custody bound.

P2-B (census/prose). Table C 19→18 U2c (18 names listed);
totals recomputed by script over the tables (238 measured of
4896; 181 bound; 4477 unreachable); resume-reachable status
cells reclassified U2a/U1→B39 (20 cells across 10 rows:
statusunbound, statusdoc, statusmatch, statusnegative,
absentmemory, presentmemory, attachable, cutrow, emptypanes,
triple); row 83 drops the five removed test names and
corrects the order claim (prior validation precedes effects;
the successor persists after); intro 92/92; wall-time prose
corrected (three wrapper refresh tests measure elapsed time);
Table E grows 13→17 outcomes; symmetry paragraph covers the
revision-4 sidedness (rootwrite gains SPW 1).

P2-A (outcome grid over the importer closure; `grid/`). Entry
grid: drivers `zz_grid_p_test.go` (pre-existing entries, both
trees) and `zz_grid_n_test.go` (new entries, candidate only)
emit `{package, entry, input, outcome, code, digest}` JSONL.
Pre-existing tmuxserver (18 keys) + termbind (9 keys): zero
moves. New entries (25 + 2 keys): all ADDED, none on the base.
Suite grid: `go test -json ./...` on the base worktree and the
candidate, diffed keyed `(package, test) → pass|fail|skip`
over the 34-package production closure: 23,054 shared keys,
zero moves, 476 additions (471 tmuxserver + 5 termbind, all
pass), zero removed. Blast radius is `{tmuxserver,
termbind}` — nothing imports either except tmuxserver→termbind
— and no production `.go` line outside them changed.
Exclusions stated: crashgate/environ (test-only deps,
pass→pass, included in the streams); store-backed termbind
entries excluded from the entry grid (covered by the suites);
timing-sensitive tests are the three candidate-only
wall-clock wrapper tests. Drivers, raw streams, diff reports,
and the additive diff ship in the tarball.

## Mutant battery

tmuxserver (`harness_chunk1.log`..`harness_chunk4.log`,
`harness/`):

- 251/251 rows as expected: 250 KILLED (248 narrowing `N-*`
  + 2 additive `D-*`) and `C-control` SURVIVED (harmless
  comment-only control, shared with the first leaf).
- One raw log per plant under `harness/` (251 files).
- All four chunks ran after the final code/test/harness
  edits in this session (exit 0 each). The only post-harness
  delta is prose (`TRACEABILITY.md`, matrix, `README.md`,
  `LOGBOOK.md`, results), which no harness row reads; the
  package suite re-ran green after every edit.

termbind (`harness_termbind.log`):

- 40/40 rows as expected: 38 narrowing `N-*` + 1
  supplementary `D-*` KILLED, `C-control` SURVIVED, including
  the 4 reboot-successor rows. Re-ran after the final edits
  (exit 0).

Combined: 291/291 rows as expected, zero mismatches.

## Acceptance criteria

34 of 34 tmuxserver rows (TRACEABILITY rows 59-92) driven
through production entries by named tests, plus termbind row
67 (successor mint); see
`TASK-260830-1c28dz_conformance-matrix.md` (AC table +
per-section mirrors + dispatch-arm table + gate x entry
census Tables B/C/D + Table E + bounds + battery; clause,
census, and bounds mirrors verified byte-identical to the
package TRACEABILITY by script). Eight of eight lifecycle
operations driven through `Execute` (ops table in the
matrix), plus the after-restore composition entry.

## OUTCOME-keyed base-vs-candidate comparison (`grid/`)

Entry grid (`entry_diff.txt`, drivers under
`grid/tmuxserver/` + `grid/termbind/`, raw `grid_*.jsonl`):

- Pre-existing tmuxserver entries (Acquire, SocketPath,
  ResolveSocket, BuildArgv, CheckServerAttested,
  CheckBrokerContact, Ensure/VerifyRuntimeDir,
  ObserveAmbient): 18 keys, zero moves.
- Pre-existing termbind entries (ParseTerminalBinding,
  CheckInstanceIdentity, AdmitMutationContext,
  AdmitStatusBody): 9 keys, zero moves.
- New entries (Lifecycle.Execute 8 ops admitted/refused,
  ExecuteWrapperRestore launch/divergent, InstanceStates,
  BuildCommand, CheckSocketLength/Custody,
  MintSuccessorBinding): 27 keys, all ADDED — the base has
  no such entries.

Suite grid (`suite_diff.txt`, raw `suite_base.json` /
`suite_candidate.json`, base from a detached worktree at
`d4bd91d0`, candidate from this tree), keyed
`(package, test) → pass|fail|skip` over the 34-package
production closure:

- Base: 23,054 keys. Candidate: 23,530 keys.
- MOVED: 0. ADDED: 476 (all pass; 471 tmuxserver + 5
  termbind). REMOVED: 0. No package outcome moves.
- crashgate/environ: pass→pass (test-only deps, in-stream).

Inputs that moved across an admission/refusal arm are all
inside the new leaf (no pre-existing entry changed behavior
— 27/27 grid keys plus 23,054/23,054 suite keys retained
prove it): barrier-state failures now fail the operation
instead of reporting closure; divergent wrapper winners
refuse instead of executing; expired/late refreshes park
instead of resuming; exit-1 attached, foreign attached rows,
exit-2 panes, NUL argv, and writable spawn roots refuse at
their entries. Each moved input has a named negative test
and a narrowing row above.

## Validation gates (all exit 0; logs in the tarball)

- gofmt clean, `go build ./...`, `go vet ./...` unix and
  windows, `git diff --check`, windows build.
- `go test ./... -count=1` (also as `suite_candidate.json`).
- `go test -race -count=1` on tmuxserver and termbind.
- `go test -cover`: tmuxserver 87.7%, termbind 83.5%.
- tracecheck, cataloggen clean, catalog pin, specdoc suites
  green (inside the full run).
- No-tmux run: `tmux` absent from PATH (`NO_TMUX`
  asserted), both touched packages pass (`v-notmux.log`).
- `task-board validate`: exit 0, 179 pre-existing
  missing-activity notes, none on this task (`v-board.log`).
- Fuzz: no `Fuzz` targets exist in the touched packages
  (grep-verified); fuzz seed corpora of the untouched
  packages run inside the full suite.

## Real-tmux witnesses

Zero: no committed test execs a real tmux or dials a real
socket (`v-notmux.log`). Three wrapper refresh tests measure
wall-clock elapsed time against generous bounds (enforcement
is timing by definition); every other test runs on the
manual clock. Every AC row is witnessed deterministically
only.

## Census (second leaf)

Table B 24x21 (10 M, 494 U2a), Table C 129x11 (1401 U2a,
18 U2c), Table D 129x21 (178 M, 177 B, 2354 U; counts
verified by script over the table), Table E 17 after-restore
outcomes; totals 238 measured of 4896 with 181 bound and
4477 unreachable with reasons. Bounds B1-B39 (B37 filled):
27 driven-but-rowless cells and 150 named undriven gaps (142
of them the B39 reachable-undriven reclass), each with its
owner in the matrix.

## Handoff

Ready for review. Worktree intentionally UNCOMMITTED for
Story handoff snapshot (no commits on the Story branch this
run). Attachments: this file (standalone), the conformance
matrix, and `TASK-260830-1c28dz_rework-evidence-rev4.tar.gz`.
