package tmuxserver

// P2-A outcome grid, driver N (new entries). Fixed corpus over the
// second-leaf production entries: one admitted and one refused
// input per lifecycle operation through Execute, the wrapper
// composition outcomes, the state memory, and the adapter
// entries. Runs on the candidate only (the CR base has none of
// these entries); every key is ADDED against the base. Evidence
// tooling: shipped in the evidence tarball, not committed.

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axpane"
	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminstance"
)

type gridNRow struct {
	Package string `json:"package"`
	Entry   string `json:"entry"`
	Input   string `json:"input"`
	Outcome string `json:"outcome"` // ok | error
	Code    string `json:"code"`
	Digest  string `json:"digest"`
}

func TestGridNewEntries(t *testing.T) {
	var rows []gridNRow
	var roots []string
	scrub := func(value string) string {
		for _, root := range roots {
			value = strings.ReplaceAll(value, root, "<TMP>")
		}
		return value
	}
	record := func(entry, input string, value any, err error) {
		t.Helper()
		row := gridNRow{Package: "tmuxserver", Entry: entry, Input: input}
		if err != nil {
			row.Outcome = "error"
			var local *Error
			var engine *terminstance.Error
			switch {
			case errors.As(err, &local):
				row.Code = local.Code + " at " + local.Detail
			case errors.As(err, &engine):
				row.Code = engine.Code + " at " + engine.Detail
			default:
				row.Code = "uncoded: " + scrub(err.Error())
			}
			raw, _ := json.Marshal(row.Code)
			sum := sha256.Sum256(raw)
			row.Digest = hex.EncodeToString(sum[:])[:16]
		} else {
			row.Outcome = "ok"
			raw, _ := json.Marshal(value)
			sum := sha256.Sum256([]byte(scrub(string(raw))))
			row.Digest = hex.EncodeToString(sum[:])[:16]
		}
		rows = append(rows, row)
	}
	admitted := func(operation, source string, setup func(fx *lxFixture) []byte) {
		t.Helper()
		fx := newLifecycleFixture(t, fullLifecycleAdmitted())
		roots = append(roots, fx.root, fx.data)
		body := setup(fx)
		outcome, err := fx.lc.Execute(context.Background(), OpRequest{
			Operation: operation, Body: body, Source: source, Admitted: fullLifecycleAdmitted(),
		})
		if err != nil {
			t.Fatalf("%s admitted: %v", operation, err)
		}
		record("Execute/"+operation, "admitted", outcome, nil)
	}
	refused := func(operation, source string, body func(*testing.T) []byte) {
		t.Helper()
		fx := newLifecycleFixture(t, fullLifecycleAdmitted())
		roots = append(roots, fx.root, fx.data)
		_, err := fx.lc.Execute(context.Background(), OpRequest{
			Operation: operation, Body: foreignBackendBody(t, body(t)), Source: source, Admitted: fullLifecycleAdmitted(),
		})
		if err == nil {
			t.Fatalf("%s refused: admitted", operation)
		}
		record("Execute/"+operation, "foreign-backend", nil, err)
	}

	admitted("create", "stopped", func(fx *lxFixture) []byte {
		fx.runner.queue("new-session", "", 0)
		return lxCreateBody(t, func(object map[string]any) { object["interactive"] = false })
	})
	admitted("attach", "parked", func(fx *lxFixture) []byte { return lxAttachBody(t, nil) })
	admitted("status", "parked", func(fx *lxFixture) []byte {
		recordBinding(t, fx, lxDigestA)
		fx.runner.queue("list-panes", "sh\n", 0).queue("list-sessions", lxInstance+"|0\n", 0)
		return lxStatusBody(t, true, true, nil)
	})
	admitted("quiesce-input", "active", func(fx *lxFixture) []byte {
		fx.runner.queue("lock-session", "", 0).queue("detach-client", "", 0)
		return lxQuiesceBody(t, nil)
	})
	admitted("wait-safe-boundary", "quiescing", func(fx *lxFixture) []byte {
		fx.runner.queue("wait-for", "", 0)
		return lxBoundaryBody(t, "ax_checkpoint_boundary", 60000, nil)
	})
	admitted("request-stop", "quiescing", func(fx *lxFixture) []byte {
		fx.runner.queue("send-keys", "", 0).queueFull("has-session", "", "can't find session: "+lxInstance, 1)
		return lxStopBody(t, 60000, nil)
	})
	{
		fx := newLifecycleFixture(t, fullLifecycleAdmitted())
		roots = append(roots, fx.root, fx.data)
		fx.runner.queue("kill-session", "", 0).queueFull("has-session", "", "can't find session: "+lxInstance, 1)
		presented, winner := terminateFencing()
		outcome, err := fx.lc.Execute(context.Background(), OpRequest{
			Operation: "terminate-stale", Body: lxTerminateBody(t, nil), Source: "stale_fenced",
			Admitted: fullLifecycleAdmitted(), Presented: presented, Winner: winner,
			HasWinner: true, ForceRecovery: true, DiagnosticsPreserved: true,
		})
		if err != nil {
			t.Fatalf("terminate-stale admitted: %v", err)
		}
		record("Execute/terminate-stale", "admitted", outcome, nil)
	}
	admitted("restore", "absent", func(fx *lxFixture) []byte {
		recordBinding(t, fx, lxDigestA)
		fx.runner.queue("new-session", "", 0)
		return lxRestoreBody(t, lxDigestA, nil)
	})
	refused("create", "absent", func(t *testing.T) []byte { return lxCreateBody(t, nil) })
	refused("attach", "parked", func(t *testing.T) []byte { return lxAttachBody(t, nil) })
	refused("status", "parked", func(t *testing.T) []byte { return lxStatusBody(t, true, false, nil) })
	refused("quiesce-input", "active", func(t *testing.T) []byte { return lxQuiesceBody(t, nil) })
	refused("wait-safe-boundary", "quiescing", func(t *testing.T) []byte {
		return lxBoundaryBody(t, "ax_checkpoint_boundary", 60000, nil)
	})
	refused("request-stop", "quiescing", func(t *testing.T) []byte { return lxStopBody(t, 60000, nil) })
	refused("terminate-stale", "stale_fenced", func(t *testing.T) []byte { return lxTerminateBody(t, nil) })
	refused("restore", "absent", func(t *testing.T) []byte { return lxRestoreBody(t, lxDigestA, nil) })

	// Wrapper composition: launch, divergent refusal, expired park.
	{
		fx := newLifecycleFixture(t, fullLifecycleAdmitted())
		roots = append(roots, fx.root, fx.data)
		fx.lc.LocalHostID = lxHost
		fx.lc.LeaseRefresh = func(ctx context.Context, session string) (RefreshWinner, error) {
			return RefreshWinner{LeaseID: lxLease, Epoch: 7, HolderHostID: lxHost}, nil
		}
		recordBinding(t, fx, lxDigestA)
		fx.runner.queue("new-session", "", 0)
		outcome, err := fx.lc.ExecuteWrapperRestore(context.Background(), WrapperRestoreRequest{
			Decide: wDecideInput(t, true), Grant: wGrant(t, wFreshValidatedAt), HasGrant: true, Policy: wPolicy(), Restore: wRestoreRequest(t),
		})
		if err != nil {
			t.Fatal(err)
		}
		if outcome.Decision.Action != axpane.ActionLaunch {
			t.Fatalf("action = %s", outcome.Decision.Action)
		}
		record("ExecuteWrapperRestore", "local-win-launch", outcome.Decision.Action, nil)
	}
	{
		fx, outcome, err := wDivergentWinner(t,
			RefreshWinner{LeaseID: lxLeaseB, Epoch: 9, HolderHostID: lxHost},
			terminstance.LeaseView{LeaseID: lxLease, Epoch: 7}, lxLease, 7)
		roots = append(roots, fx.root, fx.data)
		if err == nil {
			t.Fatal("divergent winner admitted")
		}
		record("ExecuteWrapperRestore", "divergent-winner", outcome.Decision.Action, err)
	}

	// State memory.
	{
		fx := newLifecycleFixture(t, fullLifecycleAdmitted())
		roots = append(roots, fx.root, fx.data)
		if err := fx.lc.States.Record(lxInstance, "parked"); err != nil {
			t.Fatal(err)
		}
		state, found, err := fx.lc.States.Lookup(lxInstance)
		if err != nil || !found {
			t.Fatal("lookup missed")
		}
		record("InstanceStates", "record-lookup", state, nil)
		record("InstanceStates", "record-creating", nil, fx.lc.States.Record(lxInstance, "creating"))
	}

	// Adapter entries.
	argv, err := BuildCommand(DirectiveNewSession, lxCommandArgs(SocketPath("/root/tmux")))
	if err != nil {
		t.Fatal(err)
	}
	record("BuildCommand", "new-session", argv, nil)
	_, err = BuildCommand(Directive("kill-server"), CommandArgs{})
	record("BuildCommand", "unknown-directive", nil, err)
	record("CheckSocketLength", "short", nil, CheckSocketLength("/tmp/ax.sock", scalar.PlatformMacOS))
	record("CheckSocketLength", "over-limit", nil, CheckSocketLength("/tmp/"+strings.Repeat("s", 200)+".sock", scalar.PlatformMacOS))
	record("CheckSocketCustody", "misplaced", nil, CheckSocketCustody("/tmp/evil.sock", t.TempDir(), scalar.PlatformMacOS))

	out := os.Getenv("AX_GRID_OUT")
	if out == "" {
		t.Fatal("AX_GRID_OUT is empty")
	}
	var sb strings.Builder
	for _, row := range rows {
		raw, _ := json.Marshal(row)
		sb.Write(raw)
		sb.WriteByte('\n')
	}
	if err := os.WriteFile(out, []byte(sb.String()), 0o600); err != nil {
		t.Fatal(err)
	}
}
