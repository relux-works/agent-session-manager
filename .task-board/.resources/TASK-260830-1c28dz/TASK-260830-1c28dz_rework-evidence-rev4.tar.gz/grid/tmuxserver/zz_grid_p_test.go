package tmuxserver

// P2-A outcome grid, driver P (pre-existing entries). Drives the
// first-leaf production entries with a fixed corpus and emits one
// JSONL row per (entry, input) with the outcome class, refusal
// code, and a normalized value digest. Compiles and runs
// identically on the CR base and the candidate (base API and base
// fixtures only). Evidence tooling: shipped in the evidence
// tarball, not committed. The test always passes; the comparison
// happens offline over the emitted streams.

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/scalar"
)

type gridRow struct {
	Package string `json:"package"`
	Entry   string `json:"entry"`
	Input   string `json:"input"`
	Outcome string `json:"outcome"` // ok | error
	Code    string `json:"code"`
	Digest  string `json:"digest"`
}

type gridEmitter struct {
	t     *testing.T
	rows  []gridRow
	roots []string
}

func (g *gridEmitter) scrub(value string) string {
	for _, root := range g.roots {
		value = strings.ReplaceAll(value, root, "<TMP>")
	}
	return value
}

func (g *gridEmitter) record(entry, input string, value any, err error) {
	g.t.Helper()
	row := gridRow{Package: "tmuxserver", Entry: entry, Input: input}
	if err != nil {
		row.Outcome = "error"
		var local *Error
		if errors.As(err, &local) {
			row.Code = local.Code + " at " + local.Detail
		} else {
			row.Code = "uncoded: " + g.scrub(err.Error())
		}
		raw, _ := json.Marshal(row.Code)
		sum := sha256.Sum256(raw)
		row.Digest = hex.EncodeToString(sum[:])[:16]
	} else {
		row.Outcome = "ok"
		raw, _ := json.Marshal(value)
		sum := sha256.Sum256([]byte(g.scrub(string(raw))))
		row.Digest = hex.EncodeToString(sum[:])[:16]
	}
	g.rows = append(g.rows, row)
}

func (g *gridEmitter) flush() {
	g.t.Helper()
	out := os.Getenv("AX_GRID_OUT")
	if out == "" {
		g.t.Fatal("AX_GRID_OUT is empty")
	}
	var sb strings.Builder
	for _, row := range g.rows {
		raw, _ := json.Marshal(row)
		sb.Write(raw)
		sb.WriteByte('\n')
	}
	if err := os.WriteFile(out, []byte(sb.String()), 0o600); err != nil {
		g.t.Fatal(err)
	}
}

func TestGridPreexistingEntries(t *testing.T) {
	g := &gridEmitter{t: t}
	root := runtimeRoot(t)
	g.roots = append(g.roots, root)

	// Acquire: fixed requests over fake dependencies.
	spawned := func() (Outcome, error) {
		req := validRequest(t, root)
		req.Ambient = hostileAmbient()
		req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
		req.Deps.Spawn = func(socket string, argv []string) error { return nil }
		return Acquire(req)
	}
	outcome, err := spawned()
	g.record("Acquire", "foreground-spawn", outcome, err)

	req := validRequest(t, root)
	req.Caller = "nobody"
	_, err = Acquire(req)
	g.record("Acquire", "bad-caller", nil, err)

	req = validRequest(t, root)
	req.SocketOverride = "/tmp/evil.sock"
	_, err = Acquire(req)
	g.record("Acquire", "socket-override", nil, err)

	req = validRequest(t, root)
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	_, err = Acquire(req)
	g.record("Acquire", "missing-spawn-dep", nil, err)

	req = validRequest(t, root)
	req.SessionID = "not-a-uuid"
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = func(socket string, argv []string) error { return nil }
	_, err = Acquire(req)
	g.record("Acquire", "bad-session", nil, err)

	req = validRequest(t, root)
	req.Caller = CallerBackground
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return BrokerReport{}, errors.New("no broker") }
	_, err = Acquire(req)
	g.record("Acquire", "background-no-broker", nil, err)

	// Socket path surface.
	g.record("SocketPath", "fixed-runtime-dir", SocketPath(filepath.Join(root, RuntimeDirName)), nil)
	resolved, err := ResolveSocket(filepath.Join(root, RuntimeDirName), "", hostileAmbient())
	g.record("ResolveSocket", "empty-override", resolved, err)
	_, err = ResolveSocket(filepath.Join(root, RuntimeDirName), "/tmp/evil.sock", hostileAmbient())
	g.record("ResolveSocket", "override-set", nil, err)

	// Argv builder.
	argv, err := BuildArgv(filepath.Join(root, RuntimeDirName), SocketPath(filepath.Join(root, RuntimeDirName)), fixtureSession)
	g.record("BuildArgv", "valid", argv, err)
	_, err = BuildArgv(filepath.Join(root, RuntimeDirName), SocketPath(filepath.Join(root, RuntimeDirName)), "nope")
	g.record("BuildArgv", "bad-session", nil, err)

	// Readiness gates.
	g.record("CheckServerAttested", "bound", nil, CheckServerAttested(boundAdmission(), fixtureGeneration))
	g.record("CheckServerAttested", "unadmitted", nil, CheckServerAttested(RealmAdmission{RawGeneration: fixtureGeneration}, fixtureGeneration))
	g.record("CheckBrokerContact", "empty-report", nil, CheckBrokerContact(BrokerReport{}, fixtureGeneration, 501))

	// Runtime directory.
	ensured, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	g.record("EnsureRuntimeDir", "valid", ensured, err)
	g.record("VerifyRuntimeDir", "ensured", nil, VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS))
	g.record("VerifyRuntimeDir", "missing", nil, VerifyRuntimeDir(filepath.Join(root, "absent"), RuntimeDirName, scalar.PlatformMacOS))

	// Ambient observation.
	ambient := ObserveAmbient(func(name string) (string, bool) {
		if name == "TMUX" {
			return "/tmp/tmux-501/default,1,0", true
		}
		return "", false
	}, "/tmp/inherited.sock", "/tmp/tmux-501/default", "default")
	g.record("ObserveAmbient", "tmux-set", ambient, nil)

	g.flush()
}
