#!/usr/bin/env python3
"""Recount the gate x entry census tables in TRACEABILITY.md.

Parses the fully expanded Tables A, B, and D (gate rows between the
header line starting with '| Gate (site)' and the next blank line),
classifies each cell by its leading token (M, U1, U2a, U2b, U2c, U3,
or B*), and reports dimensions plus per-class counts. Table C is
prose-only and asserted separately.

Usage: python3 census_count.py internal/tmuxserver/TRACEABILITY.md
"""
import re
import sys
from pathlib import Path


def classify(cell):
    cell = cell.strip()
    if cell.startswith("M "):
        return "M"
    for prefix in ("U2a", "U2b", "U2c", "U2", "U1", "U3"):
        if cell == prefix or cell.startswith(prefix + " ") or cell.startswith(prefix + ";"):
            return prefix
    if cell.startswith("B "):
        return "B"
    if re.match(r"B\d+(\s|;|$)", cell):
        return "B"
    return "???"


def main(path):
    lines = Path(path).read_text().split("\n")
    tables = {}
    i = 0
    order = []
    while i < len(lines):
        if lines[i].startswith("| Gate (site)"):
            header = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            entries = header[1:]
            i += 2  # skip separator
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            tables[len(order)] = (entries, rows)
            order.append(len(order))
            continue
        i += 1
    names = ["A", "B", "D"]
    total = {"M": 0, "B": 0, "U": 0, "cells": 0}
    for idx, name in zip(order, names):
        entries, rows = tables[idx]
        counts = {}
        bad = []
        for cells in rows:
            if len(cells) != len(entries) + 1:
                bad.append(f"width {len(cells)} want {len(entries) + 1}: {cells[0][:60]}")
            for cell in cells[1:]:
                token = classify(cell)
                counts[token] = counts.get(token, 0) + 1
        cells = len(rows) * len(entries)
        m = counts.get("M", 0)
        b = counts.get("B", 0)
        u = cells - m - b - counts.get("???", 0)
        print(f"Table {name}: {len(rows)}x{len(entries)}={cells} cells; "
              f"M={m} B={b} U={u} ???={counts.get('???', 0)} detail={counts}")
        for line in bad:
            print(f"  BAD: {line}")
        total["M"] += m
        total["B"] += b
        total["U"] += u
        total["cells"] += cells
    print(f"TOTAL A+B+D: {total['cells']} cells; M={total['M']} B={total['B']} U={total['U']}")


if __name__ == "__main__":
    main(sys.argv[1])
