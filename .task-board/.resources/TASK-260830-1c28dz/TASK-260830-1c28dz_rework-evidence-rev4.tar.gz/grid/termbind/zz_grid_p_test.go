package termbind

// P2-A outcome grid, driver P (pre-existing entries). Fixed corpus
// over the pure grammar entries, emitted as JSONL per (entry,
// input). Compiles and runs identically on the CR base and the
// candidate. Evidence tooling: shipped in the evidence tarball,
// not committed.

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"os"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
)

type gridRow struct {
	Package string `json:"package"`
	Entry   string `json:"entry"`
	Input   string `json:"input"`
	Outcome string `json:"outcome"` // ok | error
	Code    string `json:"code"`
	Digest  string `json:"digest"`
}

func TestGridPreexistingEntries(t *testing.T) {
	var rows []gridRow
	record := func(entry, input string, value any, err error) {
		t.Helper()
		row := gridRow{Package: "termbind", Entry: entry, Input: input}
		if err != nil {
			row.Outcome = "error"
			var coded *axerror.Error
			if errors.As(err, &coded) {
				row.Code = string(coded.Code())
			} else {
				row.Code = "uncoded: " + err.Error()
			}
			raw, _ := json.Marshal(row.Code)
			sum := sha256.Sum256(raw)
			row.Digest = hex.EncodeToString(sum[:])[:16]
		} else {
			row.Outcome = "ok"
			raw, _ := json.Marshal(value)
			sum := sha256.Sum256(raw)
			row.Digest = hex.EncodeToString(sum[:])[:16]
		}
		rows = append(rows, row)
	}

	parsed, err := ParseTerminalBinding(bindingDoc(t, nil))
	record("ParseTerminalBinding", "valid", parsed, err)
	_, err = ParseTerminalBinding(bindingDoc(t, func(object map[string]any) { delete(object, "session_id") }))
	record("ParseTerminalBinding", "missing-member", nil, err)
	_, err = ParseTerminalBinding([]byte("{broken"))
	record("ParseTerminalBinding", "garbage", nil, err)

	record("CheckInstanceIdentity", "uuidv7", nil, CheckInstanceIdentity("0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1"))
	record("CheckInstanceIdentity", "forbidden", nil, CheckInstanceIdentity("local"))

	mctx, err := AdmitMutationContext(mutationContextDoc("0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1"))
	record("AdmitMutationContext", "uuidv7", mctx, err)
	_, err = AdmitMutationContext(mutationContextDoc("local"))
	record("AdmitMutationContext", "forbidden", nil, err)

	sbody, err := AdmitStatusBody(statusBodyDoc(statusInstanceFragment("0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1")))
	record("AdmitStatusBody", "uuidv7", sbody, err)
	_, err = AdmitStatusBody(statusBodyDoc(statusInstanceFragment("local")))
	record("AdmitStatusBody", "forbidden", nil, err)

	out := os.Getenv("AX_GRID_OUT")
	if out == "" {
		t.Fatal("AX_GRID_OUT is empty")
	}
	var sb strings.Builder
	for _, row := range rows {
		raw, _ := json.Marshal(row)
		sb.Write(raw)
		sb.WriteByte('\n')
	}
	if err := os.WriteFile(out, []byte(sb.String()), 0o600); err != nil {
		t.Fatal(err)
	}
}
