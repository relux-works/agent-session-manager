package termbind

// P2-A outcome grid, driver N (new entries). Fixed corpus over the
// reboot-successor mint. Runs on the candidate only. Evidence
// tooling, not committed.

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"strings"
	"testing"
)

func TestGridNewEntries(t *testing.T) {
	type row struct {
		Package string `json:"package"`
		Entry   string `json:"entry"`
		Input   string `json:"input"`
		Outcome string `json:"outcome"`
		Code    string `json:"code"`
		Digest  string `json:"digest"`
	}
	var rows []row
	record := func(input string, value any, err error) {
		t.Helper()
		r := row{Package: "termbind", Entry: "MintSuccessorBinding", Input: input}
		if err != nil {
			r.Outcome = "error"
			r.Code = err.Error()
		} else {
			r.Outcome = "ok"
			raw, _ := json.Marshal(value)
			sum := sha256.Sum256(raw)
			r.Digest = hex.EncodeToString(sum[:])[:16]
			r.Code = ""
			raw2, _ := json.Marshal(r.Code)
			_ = raw2
		}
		if err != nil {
			raw, _ := json.Marshal(r.Code)
			sum := sha256.Sum256(raw)
			r.Digest = hex.EncodeToString(sum[:])[:16]
		}
		rows = append(rows, r)
	}
	prior := mintPrior(t)
	minted, _, err := MintSuccessorBinding(prior, "generation-beta")
	record("successor", minted, err)
	_, _, err = MintSuccessorBinding(prior, prior.BackendGeneration)
	record("same-generation", nil, err)
	out := os.Getenv("AX_GRID_OUT")
	if out == "" {
		t.Fatal("AX_GRID_OUT is empty")
	}
	var sb strings.Builder
	for _, r := range rows {
		raw, _ := json.Marshal(r)
		sb.Write(raw)
		sb.WriteByte('\n')
	}
	if err := os.WriteFile(out, []byte(sb.String()), 0o600); err != nil {
		t.Fatal(err)
	}
}
