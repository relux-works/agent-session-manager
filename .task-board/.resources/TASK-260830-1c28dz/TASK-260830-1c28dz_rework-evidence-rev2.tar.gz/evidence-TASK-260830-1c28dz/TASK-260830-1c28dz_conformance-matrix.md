# Conformance matrix — TASK-260830-1c28dz (implement-tmux-lifecycle-operations)

DoD verdict: all acceptance criteria driven (rows 59-91 of
`internal/tmuxserver/TRACEABILITY.md`, 33 of 33 new rows green),
zero real-tmux witnesses by the determinism design (bound B1,
carried), 134 narrowing mutants KILLED plus the shared harmless
control SURVIVED, gate × entry census 208 measured of 4448 with
34 stated bounds and 8 named undriven gaps, full 30-command
validation suite green firsthand (see the evidence tarball).
No capability or CLI claims: this leaf ships library behavior
only, exercised through `go test` as below.

Scope: §4.2 production adapters (exec, dial, probe, spawn), the
B18/B19/B20 socket bind step, and the §4.C lifecycle operations
create, attach, status, quiesce-input, wait-safe-boundary,
request-stop, terminate-stale, restore with receipt discipline,
tamper evidence, and the AX-side state memory. Landed code is
composed, never forked: terminstance engine/receipts/results,
terminalbackend vocabulary/transitions/conformance, termbind and
axpane stores, fencing gates, sessrepo summaries, scalar and
environ grammars, secprim argv guard, and the first-leaf custody
and readiness gates are called as-is; the only touched landed
files are the error-code registry (new codes), the ownership
seam (test hook), and the mutant harness (new rows).

## AC rows (33 of 33; mirrored from TRACEABILITY rows 59-91)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 59 | The exec adapter runs -S vectors with AX-owned argv only: exits and both streams report as data, TMUX/TMUX_TMPDIR scrub from the child, malformed argv refuses, transport failures and signal deaths pass through as errors and prove nothing. | OSRunner (exec.go) | TestOSRunnerReportsExitAsData, TestOSRunnerCapturesStderr, TestOSRunnerSignalDeathProvesNothing, TestOSRunnerScrubsAmbientInChild, TestOSRunnerRefusesBadArgv, TestOSRunnerTransportErrorProvesNothing, TestScrubTmuxEnv |
| 60 | The primitive vocabulary is exactly the ten tmux directives and the per-operation map covers exactly the eight lifecycle operations; unknown primitives and non-lifecycle operations refuse. | ParseDirective, DirectivesFor | TestParseDirectiveAdmitsTenPrimitives, TestParseDirectiveRefusesUnknown, TestDirectivesForMapsEightOperations, TestDirectivesForRefusesNonLifecycle |
| 61 | Every built vector is the fixed -S shape for its directive: the socket is pinned to the runtime leaf (ambient sockets refuse), targets parse as UUIDv7, the quiescence channel parses as UUIDv7, the attach vector states its input authorization (read-only emits -r, unstated refuses), the boundary vector is the bare blocking wait, and detach-client addresses the session. | BuildCommand | TestBuildCommandVectors, TestBuildCommandAttachReadOnlyVector, TestBuildCommandAttachRequiresInputFlag, TestBuildCommandRefusesAmbientSocket, TestBuildCommandRefusesBadIdentity |
| 62 | Dialing the socket reports live, stale, or unknown: refused and missing sockets are stale, a missing directory and every other failure is unknown, never absent. | UnixDialer.Dial | TestUnixDialerLiveStaleUnknown, TestUnixDialerMissingSocketIsStale, TestUnixDialerMissingDirectoryIsUnknown |
| 63 | The prober enforces dependencies, length, and custody before dialing: stale reports not-running, unknown errors, live attests through the admission, and admission failures pass through. | ServerProber.Probe | TestServerProberRefusesWithoutDependencies, TestServerProberMapsDialOutcomes, TestServerProberAdmissionFailurePassesThrough, TestServerProberEnforcesLengthAndCustody |
| 64 | The broker prober reports the miss, admission reconciliation fails closed without a verifier, and the Production constructor wires the prober, spawner, dialer, and admission into the Dependencies. | probe.go | TestBrokerProberReportsMiss, TestReconcileAdmissionFailsClosedWithoutVerifier, TestProductionWiresDependencies |
| 65 | The spawner enforces length, custody, and the exec-site socket pin before spawning: a stale socket unlinks (hook-observed), a non-socket refuses, and exit/transport outcomes map to the spawn verdict. | ServerSpawner.Spawn | TestServerSpawnerRefusesWithoutRunner, TestServerSpawnerPinAndCustody, TestServerSpawnerUnlinksStaleSocket, TestServerSpawnerRefusesNonSocketFile, TestServerSpawnerMapsRunnerOutcome, TestServerSpawnerRefusesAbsentLeaf |
| 66 | B18: the socket path refuses at or beyond the platform sun_path limit (104/108), counted in bytes. | CheckSocketLength | TestCheckSocketLengthBounds, TestCheckSocketLengthCountsBytes |
| 67 | B19/B20: the socket verifies at exactly the runtime leaf, and the leaf custody delegates to the landed Verify with its refusal propagated. | CheckSocketCustody | TestCheckSocketCustodyAdmitsCompliant, TestCheckSocketCustodyRefusesMisplacedSocket, TestCheckSocketCustodyPropagatesLeafRefusal |
| 68 | B20: the runtime root verifies as a caller-owned directory unwritable by others through the landed no-follow open, with the open handle bound back to its path. | checkCustodyRoot | TestCheckSocketCustodyRefusesUnsafeRoot, TestCheckSocketCustodyRefusesForeignRoot, TestCheckSocketCustodyIdentityMismatchRefuses, TestCheckSocketCustodyNoCacheAfterChange |
| 69 | B20: every ancestor verifies as a non-symlink directory unwritable by others up the lexical chain; sticky directories admit, symlinks and files refuse through the no-follow opens. | checkCustodyAncestors | TestCheckSocketCustodyRefusesWritableAncestor, TestCheckSocketCustodyAdmitsStickyAncestor, TestCheckSocketAncestorKindArm, TestCheckSocketCustodyRefusesIntermediateSymlink, TestSocketCustodySymlinkRefusesAtProbeAndSpawn |
| 70 | B19: the socket path itself is bindable when absent and unlinkable when a socket; any other kind refuses so the stale-unlink step can never remove a non-socket. | checkCustodySocket | TestCheckSocketCustodyAdmitsCompliant, TestCheckSocketCustodyRefusesNonSocketFile |
| 71 | Create bodies are the closed six-member shape with the operation context, binding, bootstrap, entrypoint, transport, and interactive members. | parseCreateBody | TestParseCreateBodyValid, TestParseCreateBodyMemberSet, TestParseCreateBodyMembers |
| 72 | Attach bodies are the closed eleven-member shape with server, channel, presentation, and lease members. | parseAttachBody | TestParseAttachBodyValid, TestParseAttachBodyMemberSet, TestParseAttachBodyMembers |
| 73 | Terminate bodies are the closed four-member shape with the stale lease, stale epoch, and evidence members. | parseTerminateBody | TestParseTerminateBodyValid, TestParseTerminateBodyViolations |
| 74 | Restore bodies are the closed four-member shape with the prior binding, checkpoint, and bootstrap members. | parseRestoreBody | TestParseRestoreBodyValid, TestParseRestoreBodyViolations |
| 75 | Execute admits all eight lifecycle operations through the dependency, vocabulary, scope, length, and custody pre-gates; each pre-gate refuses before dispatch on every operation. | Lifecycle.Execute | TestExecuteRefusesMissingDependencies, TestExecuteRefusesNonLifecycleScope, TestExecuteRefusesLongSocket, TestExecuteRefusesUnsafeSocket, TestExecuteCustodyEntryRoots |
| 76 | Every operation verifies the ax.tmux backend identity before dispatch; foreign backends refuse on all eight operations without exec. | checkLifecycleBackend | TestExecuteRefusesForeignBackend |
| 77 | Out-of-row error codes normalize to the protocol error; in-row codes propagate with their report, on all eight rows. | rowError | TestRowErrorNormalizesOutsideSet, TestRowErrorCoversEightRows, TestLifecycleEmittedCodesAreRowAllowed |
| 78 | Create runs the closed-shape admission, binding agreement, and relay refusal through the engine: interactive returns the bound descriptor, headless returns none, and identical requests replay one spawn. | executeCreate | TestExecuteCreateInteractive, TestExecuteCreateHeadless, TestExecuteCreateIdempotent, TestExecuteCreateRefusals, TestExecuteCreateBindingAgreement |
| 79 | Attach returns the caller-executed vector with its descriptor and never execs an interactive attach: closed-shape admission, deadline, matching-transport capability, the quiescing input barrier, live attestation, and the durable client receipt, with identical requests replaying; read-only authorization emits the read-only vector. | executeAttach | TestExecuteAttach, TestExecuteAttachRefusals, TestExecuteAttachIdempotent, TestAttachDescriptorNeverPersisted, TestExecuteAttachRefusesMeshWithoutCapability, TestExecuteAttachRefusesDeadline, TestExecuteAttachRefusesInputWhenQuiescing, TestExecuteReadOnlyAttachIsReadOnly |
| 80 | Status classifies present, absent, and unknown observations against the AX-side memory: absence needs its stderr marker (unmarked, refused, and killed probes read unavailable), contradictions read unavailable, malformations refuse, and the provider triple evidences only when requested, capable, and observed. | executeStatus, ObserveStatus | TestExecuteStatusPresent, TestExecuteStatusAbsent, TestExecuteStatusPresentIncludesIdentity, TestExecuteStatusUnknownProbeIsUnavailable, TestExecuteStatusProviderConditional, TestExecuteStatusContradictions, TestClassifyStatusAbsentProbe, TestClassifyStatusPresentProbe, TestClassifyAbsenceMarkers, TestObserveStatusPresentParked, TestObserveStatusAbsentProbe, TestObserveStatusMemoryReconciles, TestObserveStatusUnknowns, TestProviderTripleRule, TestCutRowShapes |
| 81 | Quiesce, boundary, and stop run through the engine with their outcome members: quiesce locks then detaches with no provider input, the boundary waits blocking with the proof kind bound into its evidence and replays its recorded time, and stop proves closure only from marked absence; identical requests replay. | executeEngineOp | TestExecuteQuiesce, TestExecuteQuiesceIdempotent, TestExecuteQuiesceBarrierSequence, TestExecuteQuiesceEmitsNoProviderInput, TestExecuteQuiesceRefusesFailedClose, TestExecuteQuiesceReplayKeepsTimestamps, TestExecuteBoundary, TestExecuteBoundaryIdempotent, TestExecuteBoundaryWaitsForSignal, TestExecuteBoundaryBindsProofKind, TestExecuteBoundaryWaitTimeout, TestExecuteBoundaryPastDeadline, TestExecuteBoundaryRefusesFailedWait, TestExecuteBoundaryReplayKeepsProofAndTime, TestExecuteStop, TestExecuteStopIdempotent, TestExecuteStopUnknownProbeIsNotClosure, TestExecuteStopUnmarkedExitIsNotClosure, TestBoundWaitTakesLesser, TestLesserDeadlineTakesLesser, TestLifecycleIgnoresAmbientEnvironment, TestObserveBoundaryBindsProviderRows, TestOutcomeRecordCrashConverges |
| 82 | Terminate-stale runs the key, capability, transition, authorization, generation, fencing, target, winner, and deadline gates before the receipt-bound kill with its live-session confirm; an unproven confirm is unknown, never termination; the memory adopts stopped, identical requests replay, and effect failures resume through status. | executeTerminate | TestExecuteTerminate, TestExecuteTerminateRefusals, TestExecuteTerminateIdempotent, TestExecuteTerminateResumesAfterEffectFailure, TestExecuteTerminateUnknownConfirmIsNotTerminated, TestExecuteTerminateWinnerTracksCurrentLease, TestExecuteTerminateTargetLeaseIdentity, TestExecuteTerminateTargetSessionBinds, TestExecuteTerminateRefusesProviderOnlyCapability, TestExecuteTerminateRefusesOnDeadline, TestExecuteTerminateRedriveMismatch |
| 83 | Restore runs the capability, prior-binding, and receipt-bound persist-plus-wrapper sequence, then returns the required binding and the after-restore branch report (local resume, remote offer, or parked under the measured refresh bound); a substituted prior refuses the mismatch, a swapped document refuses the integrity failure, the memory adopts parked, identical requests replay, and rechecks resume through status. | executeRestore | TestExecuteRestore, TestExecuteRestoreMismatch, TestExecuteRestoreIdempotent, TestExecuteRestoreReturnsBinding, TestExecuteRestoreRefusesSwappedBindingDoc, TestExecuteCreatePersistsBindingDocForRestore, TestExecuteCreateRefusesBindingDocFailure, TestExecuteRestoreRemoteOfferOnLapsedGrant, TestExecuteRestoreOffersWhenRemoteHoldsLocalTuple, TestExecuteRestoreResumesUnderLocalLease, TestExecuteRestoreParksOtherwise, TestExecuteRestoreRefreshBounded, TestExecuteResumeRefusesWhenStatusProvesOtherwise, TestExecuteRestoreResumesAfterRecheckFailure, TestExecuteRestoreRefusesWithoutRebootCapability, TestExecuteRestoreRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadlineEffect, TestExecuteRestoreRefusesGenerationDrift |
| 84 | The receipt discipline binds, replays, resumes, and completes under the idempotency key: tampered completions refuse member by member, corrupt images refuse, hook failures report uncertainty, and forged effect evidence fails the run pre-commit. | executeWithReceipt, resumeUncertain, runLifecycleEffects | TestExecuteTerminateReplayRefusesTamperedImage, TestExecuteTerminateReplayRefusesCorruptImage, TestExecuteTerminateBindHookFailure, TestRunLifecycleEffectsRefusesForgedEvidence |
| 85 | Deadlines are strict bounds at entry and before every effect: the on-deadline instant refuses, and the entry arm leaves the key unbound where the loop would bind it. | ops.go, executeAttach | TestExecuteTerminateRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadlineEffect, TestExecuteAttachRefusesDeadline |
| 86 | Generations validate at entry and recheck before every effect: drift between entry and effect refuses under the stale binding with nothing committed. | ops.go | TestExecuteEntryRefusesStaleGeneration, TestExecuteRestoreRefusesGenerationDrift |
| 87 | The presented idempotency key re-derives from the request inputs on both receipt operations; an underived key refuses before capability, receipt, or exec. | executeTerminate, executeRestore | TestExecuteRefusesWrongIdempotencyKey |
| 88 | The AX-side state memory records and looks up per-instance states with identity and value grammars: creating never records, foreign documents refuse, and failures reconcile to the adopted state. Operation outcome reports and binding documents persist beside the states with key, identity, and shape grammars. | InstanceStates | TestInstanceStatesRoundTrip, TestOpenInstanceStatesRefusesEmptyRoot, TestInstanceStatesRefusesCreating, TestInstanceStatesRefusesBadIdentity, TestInstanceStatesRefusesUnknownState, TestInstanceStatesRefusesForeignDocument, TestRecordFailureLeavesPresenceReconciliation, TestInstanceStatesOutcomeRoundTrip, TestInstanceStatesBindingDocRoundTrip |
| 89 | Every mutating operation is idempotent under retry and resumes uncertainty through status: second identical requests replay without new execs, uncertain receipts reconcile before resuming, and tampered replays refuse. | Lifecycle.Execute | TestExecuteCreateIdempotent, TestExecuteAttachIdempotent, TestExecuteQuiesceIdempotent, TestExecuteBoundaryIdempotent, TestExecuteStopIdempotent, TestExecuteTerminateIdempotent, TestExecuteRestoreIdempotent, TestExecuteTerminateResumesAfterEffectFailure, TestExecuteRestoreResumesAfterRecheckFailure, TestExecuteResumeRefusesWhenStatusProvesOtherwise |
| 90 | B16: lifecycle entries take no ambient input, so a nested invocation cannot collide through them; the child environment scrubs the ambient tmux variables, and the Acquire-level over-strict nested refusal stands unchanged as first-leaf-owned. | Lifecycle.Execute, scrubTmuxEnv | TestLifecycleIgnoresAmbientEnvironment, TestScrubTmuxEnv, TestOSRunnerScrubsAmbientInChild |
| 91 | Terminate-stale decides over the landed fencing authorization with local target and winner bindings: the fencing decision authorizes exactly the keyed stale lease, and only a winner that still wins authorizes. | executeTerminate, mapFencingError | TestExecuteTerminateRefusals, TestExecuteTerminateTargetLeaseIdentity, TestExecuteTerminateTargetSessionBinds, TestExecuteTerminateWinnerTracksCurrentLease |
## Lifecycle adapters (Section 4.2, second leaf)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 59 | The exec adapter runs -S vectors with AX-owned argv only: exits and both streams report as data, TMUX/TMUX_TMPDIR scrub from the child, malformed argv refuses, transport failures and signal deaths pass through as errors and prove nothing. | OSRunner (exec.go) | TestOSRunnerReportsExitAsData, TestOSRunnerCapturesStderr, TestOSRunnerSignalDeathProvesNothing, TestOSRunnerScrubsAmbientInChild, TestOSRunnerRefusesBadArgv, TestOSRunnerTransportErrorProvesNothing, TestScrubTmuxEnv |
| 60 | The primitive vocabulary is exactly the ten tmux directives and the per-operation map covers exactly the eight lifecycle operations; unknown primitives and non-lifecycle operations refuse. | ParseDirective, DirectivesFor | TestParseDirectiveAdmitsTenPrimitives, TestParseDirectiveRefusesUnknown, TestDirectivesForMapsEightOperations, TestDirectivesForRefusesNonLifecycle |
| 61 | Every built vector is the fixed -S shape for its directive: the socket is pinned to the runtime leaf (ambient sockets refuse), targets parse as UUIDv7, the quiescence channel parses as UUIDv7, the attach vector states its input authorization (read-only emits -r, unstated refuses), the boundary vector is the bare blocking wait, and detach-client addresses the session. | BuildCommand | TestBuildCommandVectors, TestBuildCommandAttachReadOnlyVector, TestBuildCommandAttachRequiresInputFlag, TestBuildCommandRefusesAmbientSocket, TestBuildCommandRefusesBadIdentity |
| 62 | Dialing the socket reports live, stale, or unknown: refused and missing sockets are stale, a missing directory and every other failure is unknown, never absent. | UnixDialer.Dial | TestUnixDialerLiveStaleUnknown, TestUnixDialerMissingSocketIsStale, TestUnixDialerMissingDirectoryIsUnknown |
| 63 | The prober enforces dependencies, length, and custody before dialing: stale reports not-running, unknown errors, live attests through the admission, and admission failures pass through. | ServerProber.Probe | TestServerProberRefusesWithoutDependencies, TestServerProberMapsDialOutcomes, TestServerProberAdmissionFailurePassesThrough, TestServerProberEnforcesLengthAndCustody |
| 64 | The broker prober reports the miss, admission reconciliation fails closed without a verifier, and the Production constructor wires the prober, spawner, dialer, and admission into the Dependencies. | probe.go | TestBrokerProberReportsMiss, TestReconcileAdmissionFailsClosedWithoutVerifier, TestProductionWiresDependencies |
| 65 | The spawner enforces length, custody, and the exec-site socket pin before spawning: a stale socket unlinks (hook-observed), a non-socket refuses, and exit/transport outcomes map to the spawn verdict. | ServerSpawner.Spawn | TestServerSpawnerRefusesWithoutRunner, TestServerSpawnerPinAndCustody, TestServerSpawnerUnlinksStaleSocket, TestServerSpawnerRefusesNonSocketFile, TestServerSpawnerMapsRunnerOutcome, TestServerSpawnerRefusesAbsentLeaf |

## Socket bind step (Sections 3.2, 4.2; B18, B19, B20)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 66 | B18: the socket path refuses at or beyond the platform sun_path limit (104/108), counted in bytes. | CheckSocketLength | TestCheckSocketLengthBounds, TestCheckSocketLengthCountsBytes |
| 67 | B19/B20: the socket verifies at exactly the runtime leaf, and the leaf custody delegates to the landed Verify with its refusal propagated. | CheckSocketCustody | TestCheckSocketCustodyAdmitsCompliant, TestCheckSocketCustodyRefusesMisplacedSocket, TestCheckSocketCustodyPropagatesLeafRefusal |
| 68 | B20: the runtime root verifies as a caller-owned directory unwritable by others through the landed no-follow open, with the open handle bound back to its path. | checkCustodyRoot | TestCheckSocketCustodyRefusesUnsafeRoot, TestCheckSocketCustodyRefusesForeignRoot, TestCheckSocketCustodyIdentityMismatchRefuses, TestCheckSocketCustodyNoCacheAfterChange |
| 69 | B20: every ancestor verifies as a non-symlink directory unwritable by others up the lexical chain; sticky directories admit, symlinks and files refuse through the no-follow opens. | checkCustodyAncestors | TestCheckSocketCustodyRefusesWritableAncestor, TestCheckSocketCustodyAdmitsStickyAncestor, TestCheckSocketAncestorKindArm, TestCheckSocketCustodyRefusesIntermediateSymlink, TestSocketCustodySymlinkRefusesAtProbeAndSpawn |
| 70 | B19: the socket path itself is bindable when absent and unlinkable when a socket; any other kind refuses so the stale-unlink step can never remove a non-socket. | checkCustodySocket | TestCheckSocketCustodyAdmitsCompliant, TestCheckSocketCustodyRefusesNonSocketFile |

## Lifecycle bodies (Section 4.C)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 71 | Create bodies are the closed six-member shape with the operation context, binding, bootstrap, entrypoint, transport, and interactive members. | parseCreateBody | TestParseCreateBodyValid, TestParseCreateBodyMemberSet, TestParseCreateBodyMembers |
| 72 | Attach bodies are the closed eleven-member shape with server, channel, presentation, and lease members. | parseAttachBody | TestParseAttachBodyValid, TestParseAttachBodyMemberSet, TestParseAttachBodyMembers |
| 73 | Terminate bodies are the closed four-member shape with the stale lease, stale epoch, and evidence members. | parseTerminateBody | TestParseTerminateBodyValid, TestParseTerminateBodyViolations |
| 74 | Restore bodies are the closed four-member shape with the prior binding, checkpoint, and bootstrap members. | parseRestoreBody | TestParseRestoreBodyValid, TestParseRestoreBodyViolations |

## Lifecycle dispatch (Sections 4, 4.D)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 75 | Execute admits all eight lifecycle operations through the dependency, vocabulary, scope, length, and custody pre-gates; each pre-gate refuses before dispatch on every operation. | Lifecycle.Execute | TestExecuteRefusesMissingDependencies, TestExecuteRefusesNonLifecycleScope, TestExecuteRefusesLongSocket, TestExecuteRefusesUnsafeSocket, TestExecuteCustodyEntryRoots |
| 76 | Every operation verifies the ax.tmux backend identity before dispatch; foreign backends refuse on all eight operations without exec. | checkLifecycleBackend | TestExecuteRefusesForeignBackend |
| 77 | Out-of-row error codes normalize to the protocol error; in-row codes propagate with their report, on all eight rows. | rowError | TestRowErrorNormalizesOutsideSet, TestRowErrorCoversEightRows, TestLifecycleEmittedCodesAreRowAllowed |

## Lifecycle operations (Section 4.C)

8 of 8 operations driven through the production entry `Execute`
(lifecycle.go:187), one dispatch arm each:

| Operation | Dispatch arm | Test |
|-----------|--------------|------|
| create | executeCreate (lifecycle.go:357) | TestExecuteCreateHeadless, TestExecuteCreateInteractive, TestExecuteCreateIdempotent, TestExecuteCreateRefusals, TestExecuteCreateBindingAgreement, TestExecuteCreatePersistsBindingDocForRestore, TestExecuteCreateRefusesBindingDocFailure |
| attach | executeAttach (ops.go:66) | TestExecuteAttach, TestExecuteAttachRefusals, TestExecuteAttachIdempotent, TestAttachDescriptorNeverPersisted, TestAcquireForegroundRefusesEveryCatalogDecoyRunning (P3-A decoy arm on the acquire wiring), TestExecuteAttachRefusesInputWhenQuiescing, TestExecuteReadOnlyAttachIsReadOnly |
| status | executeStatus (lifecycle.go:398) | TestExecuteStatusAbsent, TestExecuteStatusPresent, TestExecuteStatusPresentIncludesIdentity, TestExecuteStatusProviderConditional, TestExecuteStatusUnknownProbeIsUnavailable |
| quiesce | executeEngineOp (lifecycle.go:424) | TestExecuteQuiesce, TestExecuteQuiesceBarrierSequence, TestExecuteQuiesceEmitsNoProviderInput, TestExecuteQuiesceRefusesFailedClose, TestExecuteQuiesceReplayKeepsTimestamps |
| safe-boundary | executeEngineOp (lifecycle.go:424) | TestExecuteBoundary, TestExecuteBoundaryPastDeadline, TestExecuteBoundaryWaitTimeout, TestExecuteBoundaryWaitsForSignal, TestExecuteBoundaryBindsProofKind, TestExecuteBoundaryRefusesFailedWait, TestExecuteBoundaryReplayKeepsProofAndTime |
| stop | executeEngineOp (lifecycle.go:424) | TestExecuteStop, TestExecuteStopUnknownProbeIsNotClosure, TestExecuteStopUnmarkedExitIsNotClosure |
| terminate-stale | executeTerminate (ops.go:189) | TestExecuteTerminate, TestExecuteTerminateIdempotent, TestExecuteTerminateRefusals, TestExecuteTerminateResumesAfterEffectFailure, TestExecuteTerminateUnknownConfirmIsNotTerminated |
| restore | executeRestore (ops.go:338) | TestExecuteRestore, TestExecuteRestoreMismatch, TestExecuteRestoreIdempotent, TestExecuteRestoreReturnsBinding, TestExecuteRestoreRefusesSwappedBindingDoc, TestExecuteRestoreRemoteOfferOnLapsedGrant, TestExecuteRestoreOffersWhenRemoteHoldsLocalTuple, TestExecuteRestoreResumesUnderLocalLease, TestExecuteRestoreParksOtherwise, TestExecuteRestoreRefreshBounded, TestExecuteRestoreResumesAfterRecheckFailure, TestExecuteResumeRefusesWhenStatusProvesOtherwise |

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 78 | Create runs the closed-shape admission, binding agreement, and relay refusal through the engine: interactive returns the bound descriptor, headless returns none, and identical requests replay one spawn. | executeCreate | TestExecuteCreateInteractive, TestExecuteCreateHeadless, TestExecuteCreateIdempotent, TestExecuteCreateRefusals, TestExecuteCreateBindingAgreement |
| 79 | Attach returns the caller-executed vector with its descriptor and never execs an interactive attach: closed-shape admission, deadline, matching-transport capability, the quiescing input barrier, live attestation, and the durable client receipt, with identical requests replaying; read-only authorization emits the read-only vector. | executeAttach | TestExecuteAttach, TestExecuteAttachRefusals, TestExecuteAttachIdempotent, TestAttachDescriptorNeverPersisted, TestExecuteAttachRefusesMeshWithoutCapability, TestExecuteAttachRefusesDeadline, TestExecuteAttachRefusesInputWhenQuiescing, TestExecuteReadOnlyAttachIsReadOnly |
| 80 | Status classifies present, absent, and unknown observations against the AX-side memory: absence needs its stderr marker (unmarked, refused, and killed probes read unavailable), contradictions read unavailable, malformations refuse, and the provider triple evidences only when requested, capable, and observed. | executeStatus, ObserveStatus | TestExecuteStatusPresent, TestExecuteStatusAbsent, TestExecuteStatusPresentIncludesIdentity, TestExecuteStatusUnknownProbeIsUnavailable, TestExecuteStatusProviderConditional, TestExecuteStatusContradictions, TestClassifyStatusAbsentProbe, TestClassifyStatusPresentProbe, TestClassifyAbsenceMarkers, TestObserveStatusPresentParked, TestObserveStatusAbsentProbe, TestObserveStatusMemoryReconciles, TestObserveStatusUnknowns, TestProviderTripleRule, TestCutRowShapes |
| 81 | Quiesce, boundary, and stop run through the engine with their outcome members: quiesce locks then detaches with no provider input, the boundary waits blocking with the proof kind bound into its evidence and replays its recorded time, and stop proves closure only from marked absence; identical requests replay. | executeEngineOp | TestExecuteQuiesce, TestExecuteQuiesceIdempotent, TestExecuteQuiesceBarrierSequence, TestExecuteQuiesceEmitsNoProviderInput, TestExecuteQuiesceRefusesFailedClose, TestExecuteQuiesceReplayKeepsTimestamps, TestExecuteBoundary, TestExecuteBoundaryIdempotent, TestExecuteBoundaryWaitsForSignal, TestExecuteBoundaryBindsProofKind, TestExecuteBoundaryWaitTimeout, TestExecuteBoundaryPastDeadline, TestExecuteBoundaryRefusesFailedWait, TestExecuteBoundaryReplayKeepsProofAndTime, TestExecuteStop, TestExecuteStopIdempotent, TestExecuteStopUnknownProbeIsNotClosure, TestExecuteStopUnmarkedExitIsNotClosure, TestBoundWaitTakesLesser, TestLesserDeadlineTakesLesser, TestLifecycleIgnoresAmbientEnvironment, TestObserveBoundaryBindsProviderRows, TestOutcomeRecordCrashConverges |
| 82 | Terminate-stale runs the key, capability, transition, authorization, generation, fencing, target, winner, and deadline gates before the receipt-bound kill with its live-session confirm; an unproven confirm is unknown, never termination; the memory adopts stopped, identical requests replay, and effect failures resume through status. | executeTerminate | TestExecuteTerminate, TestExecuteTerminateRefusals, TestExecuteTerminateIdempotent, TestExecuteTerminateResumesAfterEffectFailure, TestExecuteTerminateUnknownConfirmIsNotTerminated, TestExecuteTerminateWinnerTracksCurrentLease, TestExecuteTerminateTargetLeaseIdentity, TestExecuteTerminateTargetSessionBinds, TestExecuteTerminateRefusesProviderOnlyCapability, TestExecuteTerminateRefusesOnDeadline, TestExecuteTerminateRedriveMismatch |
| 83 | Restore runs the capability, prior-binding, and receipt-bound persist-plus-wrapper sequence, then returns the required binding and the after-restore branch report (local resume, remote offer, or parked under the measured refresh bound); a substituted prior refuses the mismatch, a swapped document refuses the integrity failure, the memory adopts parked, identical requests replay, and rechecks resume through status. | executeRestore | TestExecuteRestore, TestExecuteRestoreMismatch, TestExecuteRestoreIdempotent, TestExecuteRestoreReturnsBinding, TestExecuteRestoreRefusesSwappedBindingDoc, TestExecuteCreatePersistsBindingDocForRestore, TestExecuteCreateRefusesBindingDocFailure, TestExecuteRestoreRemoteOfferOnLapsedGrant, TestExecuteRestoreOffersWhenRemoteHoldsLocalTuple, TestExecuteRestoreResumesUnderLocalLease, TestExecuteRestoreParksOtherwise, TestExecuteRestoreRefreshBounded, TestExecuteResumeRefusesWhenStatusProvesOtherwise, TestExecuteRestoreResumesAfterRecheckFailure, TestExecuteRestoreRefusesWithoutRebootCapability, TestExecuteRestoreRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadlineEffect, TestExecuteRestoreRefusesGenerationDrift |
| 84 | The receipt discipline binds, replays, resumes, and completes under the idempotency key: tampered completions refuse member by member, corrupt images refuse, hook failures report uncertainty, and forged effect evidence fails the run pre-commit. | executeWithReceipt, resumeUncertain, runLifecycleEffects | TestExecuteTerminateReplayRefusesTamperedImage, TestExecuteTerminateReplayRefusesCorruptImage, TestExecuteTerminateBindHookFailure, TestRunLifecycleEffectsRefusesForgedEvidence |
| 85 | Deadlines are strict bounds at entry and before every effect: the on-deadline instant refuses, and the entry arm leaves the key unbound where the loop would bind it. | ops.go, executeAttach | TestExecuteTerminateRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadline, TestExecuteRestoreRefusesOnDeadlineEffect, TestExecuteAttachRefusesDeadline |
| 86 | Generations validate at entry and recheck before every effect: drift between entry and effect refuses under the stale binding with nothing committed. | ops.go | TestExecuteEntryRefusesStaleGeneration, TestExecuteRestoreRefusesGenerationDrift |
| 87 | The presented idempotency key re-derives from the request inputs on both receipt operations; an underived key refuses before capability, receipt, or exec. | executeTerminate, executeRestore | TestExecuteRefusesWrongIdempotencyKey |
| 88 | The AX-side state memory records and looks up per-instance states with identity and value grammars: creating never records, foreign documents refuse, and failures reconcile to the adopted state. Operation outcome reports and binding documents persist beside the states with key, identity, and shape grammars. | InstanceStates | TestInstanceStatesRoundTrip, TestOpenInstanceStatesRefusesEmptyRoot, TestInstanceStatesRefusesCreating, TestInstanceStatesRefusesBadIdentity, TestInstanceStatesRefusesUnknownState, TestInstanceStatesRefusesForeignDocument, TestRecordFailureLeavesPresenceReconciliation, TestInstanceStatesOutcomeRoundTrip, TestInstanceStatesBindingDocRoundTrip |

## Lifecycle crash and ambient discipline (Sections 4.2, 4.C; B16)

| # | Clause | Call site | Test |
|---|--------|-----------|------|
| 89 | Every mutating operation is idempotent under retry and resumes uncertainty through status: second identical requests replay without new execs, uncertain receipts reconcile before resuming, and tampered replays refuse. | Lifecycle.Execute | TestExecuteCreateIdempotent, TestExecuteAttachIdempotent, TestExecuteQuiesceIdempotent, TestExecuteBoundaryIdempotent, TestExecuteStopIdempotent, TestExecuteTerminateIdempotent, TestExecuteRestoreIdempotent, TestExecuteTerminateResumesAfterEffectFailure, TestExecuteRestoreResumesAfterRecheckFailure, TestExecuteResumeRefusesWhenStatusProvesOtherwise |
| 90 | B16: lifecycle entries take no ambient input, so a nested invocation cannot collide through them; the child environment scrubs the ambient tmux variables, and the Acquire-level over-strict nested refusal stands unchanged as first-leaf-owned. | Lifecycle.Execute, scrubTmuxEnv | TestLifecycleIgnoresAmbientEnvironment, TestScrubTmuxEnv, TestOSRunnerScrubsAmbientInChild |
| 91 | Terminate-stale decides over the landed fencing authorization with local target and winner bindings: the fencing decision authorizes exactly the keyed stale lease, and only a winner that still wins authorizes. | executeTerminate, mapFencingError | TestExecuteTerminateRefusals, TestExecuteTerminateTargetLeaseIdentity, TestExecuteTerminateTargetSessionBinds, TestExecuteTerminateWinnerTracksCurrentLease |

## Gate × entry census (mirrored from TRACEABILITY)

Table A (first leaf, 24 × 11) is frozen and unchanged; only
row N-verify-absence-detail widened its killer mask to the new
entries (old cells unchanged). Tables B/C/D below are copied
verbatim from the package TRACEABILITY, whose counts were
verified by script over the tables.

## Second-leaf census

New columns: EXC/EXA/EXS/EXE/EXT/EXR = Execute create, attach,
status, engine ops (quiesce/boundary/stop), terminate-stale, restore;
PRB = ServerProber.Probe, SPW = ServerSpawner.Spawn, DIAL =
UnixDialer.Dial, CMD = BuildCommand, DIRV = DirectivesFor, PDIR =
ParseDirective, LEN = CheckSocketLength, CUS = CheckSocketCustody,
REC/LOOK = InstanceStates Record/Lookup (including the RecordOutcome/RecordBindingDoc writes and the LookupOutcome/LookupBindingDoc reads), CLS = ClassifyStatus, OBSP =
ObserveStatus called directly, PFX = PerformEffect called directly,
OSR = OSRunner called directly, UNT = unexported internals called
directly in unit tests (body parsers, rowError, providerTriple,
cutRow, ReconcileAdmission). Cell codes M/U1/U2/U3/B as above, with
U2 reasons tagged: U2a = entry never calls this code; U2b = entry
tests carry post-gate values only (the narrowed direction is measured
at the listed entry); U2c = reachable only through caller-injected
Production Dependencies with no committed composition test (bound
B27).

Table B: old gates × new entries (24 × 21 = 504 cells; 10 M, 494
U2a). Only the verify side (via custody delegation) and the server
attestation (via attach) are reachable from new entries; every other
old gate reads U2a throughout because no new code calls it (new code
never ensures, never lexically gates, never reads ambient, never
remaps, never consults creation, and never calls BuildArgv,
CheckBrokerContact, or the Acquire call sites).

| Gate (site) | EXC | EXA | EXS | EXE | EXT | EXR | PRB | SPW | DIAL | CMD | DIRV | PDIR | LEN | CUS | REC | LOOK | CLS | OBSP | PFX | OSR | UNT |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| caller (acquire.go:149) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| details (acquire.go:152) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| render (acquire.go:289) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| dispatch (acquire.go:163) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| plat (runtime.go:76) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| root (runtime.go:87) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| name (runtime.go:110) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| guard (runtime.go:93) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| wiring (acquire.go:155,183,228) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| override (socket.go:85) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| collision (socket.go:106) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| deps (acquire.go:180,222) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| session (acquire.go:225, argv.go:20) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| commit (runtime_unix.go:35) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| verify (runtime_unix.go:106) | M UnsafeSocket/create / N-verify-absence-detail | M UnsafeSocket/attach / same row | M UnsafeSocket/status / same row | M UnsafeSocket/quiesce-input,boundary,stop / same row | M UnsafeSocket/terminate-stale / same row | M UnsafeSocket/restore / same row | M EnforcesLengthAndCustody / same row | M RefusesAbsentLeaf / same row | U2a | U2a | U2a | U2a | U2a | M PropagatesLeafRefusal / same row | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| absence (acquire.go:184,258) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| creation (acquire.go:277) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| broker (readiness.go:80) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| broker-server (readiness.go:86) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| server (readiness.go:40) | U2a | M AttachRefusals fresh-decoy,stale-admission / N-attach-attestation-decoy | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| running (acquire.go:236) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| probe (acquire.go:190,232) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| spawn (acquire.go:246) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |
| argv (argv.go:17,24) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a |

Table C: new gates × old entries (115 × 11 = 1265 cells; 1246 U2a,
19 U2c). Old code predates new code and calls none of it, except
through caller-injected Dependencies: AFG reaches the adapter and
bind gates below only when the caller injects the Production
implementations, and no committed test composes Production into
Acquire (bound B27), so those 19 cells read U2c. ABG reaches no new
gate (background never probes, spawns, or binds). The U2c cells are
AFG × {dialstale, probedeps, probeunknown, spawnpin, spawnshape,
spawnexit, spawnnil, unlinkkind, reconcilenil, sunpath, placement,
leafdelegate, leafwiring, rootwrite, rootowner, ancestorwrite,
ancestorkind, socketkind}; every other Table C cell is U2a.

Table D: new gates × new entries (115 × 21 = 2415 cells; 148 M, 30
B, 2237 U; counts verified by script over the table). Test names
drop the common Test prefix; "same N rows" means the row list in the
gate's first M cell.

| Gate (site) | EXC | EXA | EXS | EXE | EXT | EXR | PRB | SPW | DIAL | CMD | DIRV | PDIR | LEN | CUS | REC | LOOK | CLS | OBSP | PFX | OSR | UNT |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| directive (exec.go:104) | U2b post-gate vectors; M at PDIR,CMD | U2b post-gate; M at PDIR,CMD | U2b post-gate; M at PDIR,CMD | U2b post-gate; M at PDIR,CMD | U2b post-gate; M at PDIR,CMD | U2b post-gate; M at PDIR,CMD | U1 | U1 | U1 | M RefusesUnknownDirective / N-exec-directive-unknown | U1 | M ParseDirectiveRefusesUnknown / same row | U1 | U1 | U1 | U1 | U1 | U1 | U2b engine effects valid; M at PDIR,CMD | U1 | U1 |
| cmdsocket (exec.go:158) | U2b derived sockets; M at CMD | U2b derived; M at CMD | U2b derived; M at CMD | U2b derived; M at CMD | U2b derived; M at CMD | U2b derived; M at CMD | U1 | U1 | U1 | M RefusesAmbientSocket / N-exec-ambient-socket | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b derived; M at CMD | U1 | U1 |
| cmdident (exec.go:200,213,226) | U2b parsed identities; M at CMD | U2b parsed; M at CMD | U2b parsed; M at CMD | U2b parsed; M at CMD | U2b parsed; M at CMD | U2b parsed; M at CMD | U1 | U1 | U1 | M RefusesBadIdentity / N-exec-instance-identity, N-exec-session-identity, N-exec-quiescence-identity | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b parsed; M at CMD | U1 | U1 |
| scrub (exec.go:69) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M ScrubsAmbientInChild / N-exec-scrub-tmux, N-exec-scrub-tmpdir | M ScrubTmuxEnv / same 2 rows |
| cmdvector (exec.go:158) | M CreateInteractive / N-exec-vector-detached | M Attach / N-cmdvector-attach | U2a status builds no vectors | M BoundaryWaitsForSignal / N-boundary-blocking-vector; quiesce/stop subcommand-only (M at CMD) | U2b kill/has subcommands; M at CMD | M Restore / N-exec-vector-detached | U1 | U1 | U1 | M Vectors / N-exec-vector-detached, N-cmdvector-attach, N-boundary-blocking-vector, N-cmdvector-detach | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b subcommand-only; M at CMD | U1 | U1 |
| osrun (exec.go:40) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M SignalDeathProvesNothing / N-osrunner-signal-death; other mappings B30 total | U1 |
| directives (backend.go:30) | M RefusesNonLifecycleScope / N-exec-directives-manifest | M same test+row; pre-gate op-independent | M same test+row; pre-gate | M same test+row; pre-gate | M same test+row; pre-gate | M same test+row; pre-gate | U1 | U1 | U1 | U1 | M DirectivesForRefusesNonLifecycle / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| effectvocab (backend.go:92) | U2b landed effects; M at PFX | U2b landed; M at PFX | U1 | U2b landed; M at PFX | U2b landed; M at PFX | U2b landed; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RefusesUnknownVocabulary / N-backend-effect-vocabulary | U1 | U1 |
| exitrefused (backend.go:253) | U2b execs succeed; M at PFX | U1 attach never execs | U1 | U2b execs succeed; M at PFX | U2b kill confirms inline; M at PFX | U2b execs succeed; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RefusesFailedExec / N-backend-exit-refused | U1 | U1 |
| transport (backend.go:253) | U2b runners scripted; M at PFX | U1 | U1 | U2b valid ctx; M at PFX | U2b scripted; M at PFX | U2b scripted; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M TransportProvesNothing / N-backend-transport-unknown | U1 | U1 |
| reconfirm (backend.go:216) | U1 | U1 | U1 | U1 | U2b single-effect failures; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M TerminateLiveRefuses, ReconfirmRefusesFailedKill / N-backend-reconfirm-failed-kill | U1 | U1 |
| boundarywait (backend.go:278) | U1 | U1 | U1 | M BoundaryWaitTimeout / N-backend-boundary-timeout | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BoundaryTimeout / same row | U1 | U1 |
| escalation (backend.go:216) | U1 | U1 | U1 | U2b clean closes; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M EscalationKillFailure / N-stop-escalation-kill | U1 | U1 |
| persistmap (backend.go:124) | U2b bindings succeed; M at PFX | U1 | U1 | U1 | U1 | U2b priors mismatch first; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BindingConflict / N-persist-conflict-map | U1 | U1 |
| attachmap (backend.go:150) | U1 | U2b receipts replay; M at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M AttachClient / N-attach-conflict-map | U1 | U1 |
| selfconfirm (backend.go:187) | U1 | U1 | U1 | U1 | B22 ResumesAfterEffectFailure; singleton | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B22 TerminateLiveRefuses; singleton | U1 | U1 |
| stoptimeout (backend.go:216) | U1 | U1 | U1 | U2b closes clean; M nowhere (B22 at PFX) | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B22 StopTimeout; singleton | U1 | U1 |
| cmdmap (backend.go:99) | U2b parsed identities; B28 at PFX | U2b parsed; B28 at PFX | U2b parsed; B28 at PFX | U2b parsed; B28 at PFX | U2b parsed; B28 at PFX | U2b parsed; B28 at PFX | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B28 untested mapping; builder rows at CMD | U1 | U1 |
| storenil (backend.go:124,150) | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B22 NilStoresRefuse; singleton | U1 | U1 |
| staterecord (state.go:74) | U2b adopted states; M at REC | U2b adopted; M at REC | U2b adopted; M at REC | U2b adopted; M at REC | U2b adopted; M at REC | U2b adopted; M at REC | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RoundTrip, RefusesCreating, RefusesUnknownState / N-state-creating, N-state-unknown | U1 | U1 | U1 | U1 | U1 | U1 |
| statelookup (state.go:104) | U2a | U2a | U2b parsed instance; M at LOOK | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RefusesBadIdentity, RefusesForeignDocument / N-state-lookup-identity, N-state-foreign | U1 | U1 | U1 | U1 | U1 |
| stateopen (state.go:60) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B22 RefusesEmptyRoot; singleton | U1 | U1 | U1 | U1 | U1 | U1 |
| createcount (bodies.go:64) | U2b valid bodies; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M MemberSet / N-bodies-create-count |
| attachcount (bodies.go:152) | U1 | U2b valid bodies; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M MemberSet / N-bodies-attach-count |
| termcount (bodies.go:241) | U1 | U1 | U1 | U1 | U2b valid bodies; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M Violations / N-bodies-terminate-count |
| restorecount (bodies.go:304) | U1 | U1 | U1 | U1 | U1 | U2b valid bodies; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M Violations / N-bodies-restore-count |
| transportvocab (bodies.go:340) | U2b valid transports; M at UNT | U2b valid; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M Create/AttachMembers / N-bodies-transport |
| epochzero (bodies.go:265) | U1 | U1 | U1 | U1 | U2b valid epochs; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M Violations/epoch-zero / N-bodies-epoch-zero |
| entrypoint (bodies.go:110) | U2b valid entrypoints; M at UNT | U2b valid; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M StringRefuses, shapes pinned / N-bodies-entrypoint-string |
| absentmemory (status.go:296) | U1 | U1 | M Contradictions/quiescing-memory / N-status-absent-quiescing | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M AbsentProbe/memory-quiescing / same row | U2b live shapes; M at CLS,EXS | U1 | U1 | U1 |
| presentmemory (status.go:314) | U1 | U1 | M Contradictions/stopped-memory / N-status-present-stopped | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M PresentProbe/memory-stopped / same row | M MemoryReconciles / same row | U1 | U1 | U1 |
| attachable (status.go:334) | U1 | U1 | M Contradictions/incapable-attach / N-status-attachable | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M PresentProbe/no-attach-cap / same row | U2b quiescing never attachable; M at CLS,EXS | U1 | U1 | U1 |
| cutrow (status.go:160) | U1 | U1 | B23 count-less-row pins code; engine normalizes detail | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2a classify takes parsed rows | M Unknowns / N-status-cutrow-count | U1 | U1 | M CutRowShapes / same row |
| emptypanes (status.go:96) | U1 | U1 | B23 empty-rows pins code; engine maps uncoded | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M Unknowns/empty-rows / N-status-empty-panes | U1 | U1 | U1 |
| triple (status.go:344) | U1 | U1 | M Contradictions/unrequested-present / N-provider-triple-unrequested | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b requested shapes; M at UNT,EXS | U1 | U1 | M TripleRule / same row |
| dialstale (probe.go:60) | U2a | U2a | U2a | U2a | U2a | U2a | U2b injected outcomes; M at DIAL | U1 | M LiveStaleUnknown, MissingSocketIsStale / N-probe-dial-refused, N-probe-dial-enoent | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| probedeps (probe.go:100) | U2a | U2a | U2a | U2a | U2a | U2a | M RefusesWithoutDependencies / N-probe-deps-dialer, N-probe-deps-admit | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| probeunknown (probe.go:112) | U2a | U2a | U2a | U2a | U2a | U2a | M MapsDialOutcomes/unknown / N-probe-unknown-passthrough | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| spawnpin (probe.go:182) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | M PinAndCustody / N-spawn-pin | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| spawnshape (probe.go:182) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | M PinAndCustody / N-spawn-shape | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| spawnexit (probe.go:196) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | M MapsRunnerOutcome / N-spawn-exit | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| spawnnil (probe.go:177) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | B22 RefusesWithoutRunner; singleton | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| unlinkkind (probe.go:206) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U3 custody refuses non-sockets first | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| reconcilenil (probe.go:238) | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B22 FailsClosedWithoutVerifier; singleton |
| sunpath (bind.go:28) | M AtLimitSocket/create / N-bind-length-boundary | M AtLimitSocket/attach / same row | M AtLimitSocket/status / same row | M AtLimitSocket/3 engine ops / same row | M AtLimitSocket/terminate-stale / same row | M AtLimitSocket/restore / same row | M EnforcesLengthAndCustody / same row | U2b socket arg short; M at LEN,EXS,PRB | U1 | U1 | U1 | U1 | M Bounds, CountsBytes / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| placement (bind.go:44) | U2b compliant sockets; M at CUS,PRB | U2b compliant; M at CUS,PRB | U2b compliant; M at CUS,PRB | U2b compliant; M at CUS,PRB | U2b compliant; M at CUS,PRB | U2b compliant; M at CUS,PRB | M EnforcesLengthAndCustody / N-bind-placement | U2b pinned vectors; M at CUS,PRB | U1 | U1 | U1 | U1 | U1 | M RefusesMisplacedSocket / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| leafdelegate (bind.go:52) | B32 UnsafeSocket/create; propagation pinned | B32 UnsafeSocket/attach; pinned | B32 UnsafeSocket/status; pinned | B32 UnsafeSocket/3 ops; pinned | B32 UnsafeSocket/terminate; pinned | B32 UnsafeSocket/restore; pinned | B32 EnforcesLengthAndCustody; pinned | B32 RefusesAbsentLeaf; pinned | U1 | U1 | U1 | U1 | U1 | M PropagatesLeafRefusal / N-bind-wiring-verify | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| leafwiring (bind.go:44,52) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | M AdmitsCompliant / N-bind-wiring-placement, N-bind-wiring-verify | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| rootwrite (bind.go:96) | U2b staged compliant; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | M CustodyEntryRoots/status/root / N-custody-entry-root-status | U2b staged; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | M CustodyEntryRoots/restore/root / N-custody-entry-root-restore | U2b staged; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | U1 | U1 | U1 | U1 | U1 | M RefusesUnsafeRoot / N-bind-root-writable | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| rootowner (bind.go:96) | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | B31 ForeignRoot stages leaf-first; arm untested+singleton | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| ancestorwrite (bind.go:116) | U2b staged compliant; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | M CustodyEntryRoots/status/ancestor / N-custody-entry-ancestor-status | U2b staged; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | M CustodyEntryRoots/restore/ancestor / N-custody-entry-ancestor-restore | U2b staged; M at CUS,EXS,EXR | U2b staged; M at CUS,EXS,EXR | U1 | U1 | U1 | U1 | U1 | M RefusesWritableAncestor / N-bind-ancestor-writable | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| ancestorkind (bind.go:116) | U2b staged compliant; M at CUS,PRB,SPW | U2b staged; M at CUS,PRB,SPW | U2b staged; M at CUS,PRB,SPW | U2b staged; M at CUS,PRB,SPW | U2b staged; M at CUS,PRB,SPW | U2b staged; M at CUS,PRB,SPW | M SymlinkRefusesAtProbeAndSpawn/probe, RefusesIntermediateSymlink / N-custody-alias-skip | M SymlinkRefusesAtProbeAndSpawn/spawn / same row | U1 | U1 | U1 | U1 | U1 | M RefusesIntermediateSymlink, AncestorKindArm / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| socketkind (bind.go:164) | U2a staged absent; M at CUS | U2a staged; M at CUS | U2a staged; M at CUS | U2a staged; M at CUS | U2a staged; M at CUS | U2a staged; M at CUS | U2a staged; M at CUS | U2b absent sockets; M at CUS | U1 | U1 | U1 | U1 | U1 | M RefusesNonSocketFile / N-bind-socket-kind | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| backendid (lifecycle.go:200) | M RefusesForeignBackend/create / N-lifecycle-backend-identity | M RefusesForeignBackend/attach / same row | M RefusesForeignBackend/status / same row | M RefusesForeignBackend/3 engine ops / same row | M RefusesForeignBackend/terminate-stale / same row | M RefusesForeignBackend/restore / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| agreement (lifecycle.go:255) | M BindingAgreement / N-lifecycle-agreement-session, -instance, -backend, -generation | U2a create-only gate | U2a | U2a | U2a | U2a | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| rowvocab (lifecycle.go:270) | U2b in-row codes; M at UNT | U2b in-row; M at UNT | U2b in-row; M at UNT | U2b in-row; M at UNT | U2b in-row; M at UNT | U2b in-row; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M NormalizesOutsideSet, CoversEightRows / N-rowvocab-pass |
| enginemembers (lifecycle.go:380) | U1 | U1 | U1 | M Quiesce, Boundary, Stop / N-engineop-quiesce-generation, N-engineop-boundary-evidence, N-engineop-stop-process, N-engineop-stop-store | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| waitlesser (lifecycle.go:410) | U1 | U1 | U1 | U2b scripted waits; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BoundWaitTakesLesser / N-wait-bound-lesser |
| stoplesser (lifecycle.go:421) | U1 | U1 | U1 | U2b staged deadlines; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b staged; M at UNT | U1 | M LesserDeadlineTakesLesser / N-stop-deadline-lesser |
| relay (lifecycle.go:300) | B22 CreateRefusals/relay; singleton | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| descpresence (lifecycle.go:330) | B22 Interactive+Headless; boolean fork | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attachcap (ops.go:100) | U1 | M wrong-transport-capability, MeshWithoutCapability / N-attach-capability-local, N-attach-capability-mesh | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attachdeadline (ops.go:72) | U1 | M RefusesDeadline / N-attach-deadline-boundary | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attestation (ops.go:113) | U1 | M fresh-decoy / N-attach-attestation-decoy; stale member pinned | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attachrecord (ops.go:140) | U1 | M Attach / N-attach-record | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attachdesc (ops.go:46) | U1 | M Attach / N-attach-descriptor-order | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| createdesc (ops.go:56) | M CreateInteractive / N-create-descriptor-order | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| serveadmitnil (ops.go:108) | U1 | B22 no-admission; singleton | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attacheffect (ops.go:119) | U1 | B26 unstaged failure mapping | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| attachbuild (ops.go:128) | U1 | U3 body parse precedes; parsed identities never refuse | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| authkind (ops.go:196,352,520) | U1 | U1 | U1 | U1 | M Terminate / N-entry-authkind-terminate, N-lifecycle-terminate-authkind | M Restore / N-entry-authkind-restore, N-lifecycle-restore-authkind | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| generation (ops.go:205,361,524) | U1 | U1 | U1 | U1 | M EntryRefusesStaleGeneration/terminate / N-entry-generation | M EntryRefusesStaleGeneration/restore, RefusesGenerationDrift / N-entry-generation, N-lifecycle-loop-generation | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| deadline (ops.go:72,226,374,510) | U1 | M RefusesDeadline/boundary / N-attach-deadline-boundary | U1 | U1 | M RefusesOnDeadline / N-lifecycle-entry-deadline-terminate | M RefusesOnDeadline, RefusesOnDeadlineEffect / N-lifecycle-entry-deadline-restore, N-lifecycle-loop-deadline | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| keymaterial (ops.go:176,338) | U1 | U1 | U1 | U1 | M WrongIdempotencyKey/terminate / N-key-material-terminate | M WrongIdempotencyKey/restore / N-key-material-restore | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| capdual (ops.go:240) | U1 | U1 | U1 | U1 | M missing-capability, RefusesProviderOnlyCapability / N-lifecycle-capability-provider, N-lifecycle-capability-stale | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| restorecap (ops.go:345) | U1 | U1 | U1 | U1 | U1 | M RefusesWithoutRebootCapability / N-lifecycle-restore-capability | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| fencingmap (ops.go:262) | U1 | U1 | U1 | U1 | M no-force, malformed-presented / N-lifecycle-fencing-force, N-fencing-invalid-reroute; other members pinned | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| target (ops.go:270) | U1 | U1 | U1 | U1 | M target-mismatch, TargetLeaseIdentity, TargetSessionBinds / N-lifecycle-target-epoch, N-lifecycle-target-lease, N-lifecycle-target-session | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| winner (ops.go:285) | U1 | U1 | U1 | U1 | M winner-rotated, winner-lease-identity / N-lifecycle-winner-epoch, N-lifecycle-winner-lease; session arm U3 fenced | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| mismatch (ops.go:368) | U1 | U1 | U1 | U1 | U1 | M RestoreMismatch/wrong-digest / N-lifecycle-restore-mismatch | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| bindmap (ops.go:410) | U1 | U1 | U1 | U1 | M RedriveMismatch / N-bind-mismatch-map | U2b shared code; unstaged redrive on restore; M at EXT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| bindfound (ops.go:424) | U1 | U1 | U1 | U1 | M BindHookFailure / N-bind-hook-found | U2b shared code; unstaged hook failure on restore; M at EXT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| bindmiss (ops.go:424) | U1 | U1 | U1 | U1 | B25 clean-miss unstageable; hooks fire post-commit | B25 clean-miss unstageable | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| completedread (ops.go:440) | U1 | U1 | U1 | U1 | B24 read failure unstaged; no seam | B24 read failure unstaged | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| evidence (ops.go:548) | U1 | U1 | U1 | U1 | U2b real digests; M at UNT | U2b real digests; M at UNT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RefusesForgedEvidence / N-lifecycle-evidence-digest |
| record (ops.go:505,592) | U1 | U2a attach records at its own site | U1 | U1 | M Terminate / N-lifecycle-record-success; failure arm untested here | M Restore / same row; failure arm untested here | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M RefusesForgedEvidence / N-lifecycle-record-failure |
| resume (ops.go:463) | U1 | U1 | U1 | U1 | U2b source-proven resumes; M at EXR | M RefusesWhenStatusProvesOtherwise / N-lifecycle-resume-state; error arm subsumed | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| replay (ops.go:407) | U1 | U1 | U1 | U1 | M TamperedImage, CorruptImage / N-lifecycle-replay-session, N-replay-corrupt-image; other members pinned | U2b clean replays; M at EXT | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| completearms (ops.go:580) | U1 | U1 | U1 | U1 | U2a Complete runs post-Bind once; never fails here | U2a Complete runs post-Bind once | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| readonly (exec.go:attach) | U1 | M ReadOnlyAttachIsReadOnly / N-attach-readonly-vector | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M AttachReadOnlyVector / same row | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| inputflag (exec.go:attach) | U1 | U2b stated authorizations; M at CMD | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M AttachRequiresInputFlag / N-attach-input-flag | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| detachvec (exec.go:detach) | U2a quiesce-only vector | U2a quiesce-only | U2a quiesce-only | U2b subcommand-only; M at CMD | U2a quiesce-only | U2a quiesce-only | U1 | U1 | U1 | M Vectors / N-cmdvector-detach | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b subcommand-only; M at CMD | U1 | U1 |
| boundarykind (backend.go:observeBoundary) | U2a boundary-only gate | U2a boundary-only | U2a boundary-only | M BoundaryBindsProofKind / N-boundary-proof-kind | U2a boundary-only | U2a boundary-only | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b kind-echoed; M at EXE | U1 | U1 |
| boundexit (backend.go:observeBoundary) | U2a boundary-only gate | U2a boundary-only | U2a boundary-only | M BoundaryRefusesFailedWait / N-boundary-exit-refused | U2a boundary-only | U2a boundary-only | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BoundaryRefusedExit / same row | U1 | U1 |
| quiescedetach (backend.go:closeInput) | U2a quiesce-only gate | U2a quiesce-only | U2a quiesce-only | M BarrierSequence / N-quiesce-detach-step | U2a quiesce-only | U2a quiesce-only | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M InputClosed / same row | U1 | U1 |
| nosendkeys (backend.go:closeInput) | U2a quiesce-only gate | U2a quiesce-only | U2a quiesce-only | M EmitsNoProviderInput / N-quiesce-sendkeys-absent | U2a quiesce-only | U2a quiesce-only | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b shared sequence; M at EXE | U1 | U1 |
| closeexit (backend.go:closeInput) | U2a quiesce-only gate | U2a quiesce-only | U2a quiesce-only | M RefusesFailedClose / N-quiesce-close-exit | U2a quiesce-only | U2a quiesce-only | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b clean closes; M at EXE | U1 | U1 |
| quiescegate (ops.go:checkAttachQuiesced) | U1 | M RefusesInputWhenQuiescing / N-quiesce-attach-gate | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| probemarker (backend.go:classifyAbsence) | U2a no has/list probes | U2a no probes | M StatusUnknownProbe / N-probe-unmarked-exit | M StopUnmarkedExit / same row | M TerminateUnknownConfirm / same row | U2a no probes | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b shared code; M at EXS | U2b shared code; M at EXE,EXT | U1 | U1 |
| probeneg (backend.go:classifyAbsence) | U2a no has/list probes | U2a no probes | U2b non-negative scripts; M at EXE | M StopUnknownProbe / N-probe-negative-exit | U2b non-negative scripts; M at EXE | U2a no probes | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b non-negative scripts; M at EXE | U1 | U1 |
| identity (bind.go:checkCustodyRoot) | U2b matching identity; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U2b matching; M at CUS | U1 | U1 | U1 | U1 | U1 | M IdentityMismatchRefuses / N-custody-identity-bind | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| bindcontract (ops.go:restoreBinding) | U1 | U1 | U1 | U1 | U1 | M ReturnsBinding, Idempotent / N-restore-binding-omit | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| restoreagree (ops.go:restoreBinding) | U1 | U1 | U1 | U1 | U1 | M RefusesSwappedBindingDoc / N-restore-agreement-session | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| replaytime (lifecycle.go:report) | U1 | U1 | U1 | M QuiesceReplayKeepsTimestamps, BoundaryReplayKeepsProofAndTime (+Idempotent) / N-replay-timestamp-quiesce, N-replay-timestamp-boundary | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| branchholder (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M OffersWhenRemoteHoldsLocalTuple / N-restore-branch-holder | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| branchtuple (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M ParksOtherwise/stale-tuple / N-restore-branch-tuple | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| branchmaterial (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M ParksOtherwise/local-invalid-material / N-restore-branch-material | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| branchremote (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M ParksOtherwise/stale-tuple / N-restore-branch-remote | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| branchoffer (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M RemoteOfferOnLapsedGrant / N-restore-branch-offer | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| refreshbound (ops.go:afterRestoreBranch) | U1 | U1 | U1 | U1 | U1 | M RefreshBounded / N-refresh-bound-default | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 |
| outcomekey (state.go:RecordOutcome) | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M OutcomeRoundTrip / N-outcome-key-record | B22 OutcomeRoundTrip; lookup singleton | U1 | U1 | U1 | U1 | U1 |
| binddocid (state.go:RecordBindingDoc) | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BindingDocRoundTrip / N-binddoc-session-identity | M BindingDocRoundTrip / N-binddoc-lookup-identity | U1 | U1 | U1 | U1 | U1 |
| binddocshape (state.go:RecordBindingDoc) | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | M BindingDocRoundTrip / N-binddoc-document-shape | U1 | U1 | U1 | U1 | U1 | U1 |
| docpersist (backend.go:persistBinding) | U2b doc-kept; M at EXR | U1 | U1 | U1 | U1 | M CreatePersistsBindingDocForRestore / N-create-doc-persist | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U2b unstaged bindingDoc; M at EXR | U1 | U1 |
| pollbound (backend.go:300) | U1 | U1 | U1 | B29 lesser-fed; boundary unmeasured | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | U1 | B29 past-deadline pinned; boundary unmeasured | U1 | U1 |

Symmetry (every gate on two or more sides, with admitting-row
counts per side; "shared" marks one row killing through several
entries, attribution verified per entry from the raw logs):
directive CMD 1 / PDIR 1 shared; scrub OSR 2 / UNT 2 shared; cmdident
CMD 3 members; cmdvector EXC 1 / EXA 1 / EXE 1 / EXR 1 / CMD 4;
directives 6 EX + DIRV shared 1; effectvocab/exitrefused/transport
single-sided at PFX; reconfirm/escalation/persistmap/attachmap
single-sided at PFX; boundarywait EXE 1 / PFX 1 shared; staterecord
REC 2 members; statelookup LOOK 2 members; entrypoint/transportvocab
single-sided at UNT; absentmemory EXS 1 / CLS 1 shared; presentmemory
EXS 1 / CLS 1 / OBSP 1 shared; attachable EXS 1 / CLS 1 shared; cutrow
OBSP 1 / UNT 1 shared (EXS B23); triple EXS 1 / UNT 1 shared; dialstale
DIAL 2 members; probedeps PRB 2 members; sunpath LEN 1 / 6 EX 1 /
PRB 1 shared; placement CUS 1 / PRB 1 shared; leafdelegate CUS 1 (B32
propagation elsewhere); leafwiring CUS 2 sites; rootwrite CUS 1 / EXS
1 / EXR 1; ancestorwrite CUS 1 / EXS 1 / EXR 1; ancestorkind CUS 1 /
PRB 1 / SPW 1 shared; backendid 6 EX shared 1; agreement EXC 4
members; enginemembers EXE 4 members; attachcap EXA 2 members;
attestation EXA 1 + pinned member; authkind EXT 2 / EXR 2; generation
EXT 1 / EXR 2; deadline EXA 1 / EXT 1 / EXR 2; keymaterial EXT 1 / EXR
1; capdual EXT 2 members; fencingmap EXT 2 + 3 pinned; target EXT 3
members; winner EXT 2 members (session arm U3: fencing+target
precede); record EXT 1 / EXR 1 shared + UNT 1; replay EXT 2 + 6
pinned; bindmap/bindfound single-sided at EXT; readonly EXA 1 / CMD 1
shared; detachvec CMD 1; boundarykind/boundexit EXE 1 each + PFX
0/1; quiescedetach EXE 1 / PFX 1 shared; nosendkeys/closeexit EXE 1
each; probemarker EXS 1 / EXE 1 / EXT 1 shared; probeneg EXE 1;
identity CUS 1; bindcontract/restoreagree EXR 1 each; replaytime EXE
2; afterRestoreBranch holder/tuple/material/remote/offer/bound 1
each (all EXR); refreshbound EXR 1; outcomekey REC 1 / LOOK 0 (B22
singleton); binddocid REC 1 / LOOK 1; binddocshape REC 1; docpersist
EXR 1; Table B verify 9 new-entry sides shared 1, server EXA 1 (its
other sides are first-leaf symmetry).

Ratio: 208 measured of 4448 (50+10+148 M across Tables A/B/D;
Table C all U); 34 bound; 4206 unreachable with reasons. Every
driven refusal direction is measured except the bound cells: 22
driven but rowless (B22 singletons/forks, B23 normalized details,
B29 poll past-deadline, B32 propagation) and 8 named undriven gaps
(B24/B25/B26/B28/B31 cells, B29 dispatch side), each with its owner
below.

## Bounds (mirrored B22-B35 plus carried dispositions)

- B22 Singleton arms ship no narrowing mutant: admitting the
  singleton refused member is deleting the gate. Covered sites, each
  test-pinned in both directions where a fork exists: create relay
  transport (relay), descriptor presence fork (descpresence),
  attach admission nil (serveadmitnil), spawner runner nil
  (spawnnil), reconcile verifier nil (reconcilenil), states root
  empty (stateopen), persist/attach stores nil (storenil),
  failed-kill self-confirm (selfconfirm), live-after-escalation
  (stoptimeout), outcome-lookup empty key (outcomekey LOOK side;
  the record side narrows over its operation member). Owner: this
  leaf; retest if any site grows a second refused member.
- B23 The landed status engine normalizes backend error details to
  "status observation unknown" (coded or not), so the cutrow and
  empty-panes narrowings measure at the helper entries while the
  dispatch legs pin the code. Owner: this leaf; retest if the
  engine stops normalizing.
- B24 The idempotency-store Completed read-failure arm is unstaged:
  no seam fails receipt reads (hooks fire on write paths only).
  Owner: hardening; stage with a read-failure seam to measure.
- B25 The Bind clean-miss sub-arm is unstageable: every Bind error
  the hooks stage leaves the committed file, so Lookup always finds
  it. The clean-found sub-arm is measured (N-bind-hook-found).
  Owner: hardening.
- B26 The attach effect-failure dispatch mapping is unstaged: no
  committed failure reaches it (the store replays identical
  receipts; conflicting receipts are untested at dispatch).
  Owner: hardening.
- B27 No committed test composes the Production Dependencies into
  Acquire: AFG reaches the adapter and bind gates only through
  caller-injected implementations (the 19 Table C U2c cells). The
  injection seam is first-leaf-owned; Production wiring is
  unit-pinned (TestProductionWiresDependencies). Owner: composition
  test, sibling scope.
- B28 The backend command-error wrap is unmeasured at PFX (no
  backend test stages a refused build; the builder rows pin the
  refused shapes at CMD). Owner: this leaf; retest with a
  refused-build backend test.
- B29 The close-confirm poll deadline is pinned for past-deadline
  at PFX via direct staging; the exact-boundary member and
  dispatch-level staging are unmeasured (the fake runner advances
  no time). Owner: hardening.
- B30 The OSRunner exit/transport/argv mappings are total functions
  over uncoded inputs with no refused class to admit a member of;
  tests pin them including real-exec scrub, stderr-capture, and
  signal-death integrations. The signal-death arm (a killed child
  errors instead of reporting -1 data) is a refused class and
  carries its own narrowing row; the remaining mappings stay total.
  Owner: this leaf.
- B31 The custody root-ownership arm is untested and singleton: the
  ownership seam stages leaf-first (the leaf refuses before the
  root arm runs), and a truly foreign root needs privilege. Owner:
  hardening with a privileged stage or a root-level seam.
- B32 The leaf-delegation wiring is measured at CUS (wrong-leaf
  mutants are observable only on compliant roots); the absence
  propagation through the six dispatch paths, the prober, and the
  spawner is pinned by absence tests without a row. Owner: this
  leaf.
- B33 The wrapper safe-boundary signal step is unimplemented in the
  landed wrapper: the boundary entry waits blocking on
  `ax-boundary-<generation>` for the wrapper's `wait-for -S`, and
  the wrapper never signals today, so boundary waits time out with
  the coded quiesce_timeout (fail closed, never a faked proof)
  until the signal step lands. The wait vector, the proof-kind
  binding, the provider-row context, and the timeout are this
  leaf's and fully driven; the signal emission is the wrapper's.
  Owner: the wrapper (`ax pane`) task; retest the full
  quiesce-boundary-stop flow when the signal lands.
- B34 A crash between the mutation-receipt commit and the operation
  outcome record re-observes the report time on retry: the effect
  never re-runs and the evidence never changes, but the reported
  closure/boundary time renders from the retry clock instead of
  the original one. Sequential retries without a crash replay
  identical times. Owner: this leaf; closing the window needs the
  outcome inside the engine-owned receipt.
- B35 The absence stderr markers are verified against tmux 3.6a
  (`can't find session`, `can't find window`, and the
  no-such-socket connect error); any other version's
  absence-shaped stderr fails closed to unknown. Owner: this leaf;
  re-verify the marker set when the tmux floor version moves.

Carried bounds (first-leaf statements dispositioned by this leaf).
B9 adapter split is discharged: the production exec, dial, probe,
and spawn adapters ship (exec.go, probe.go, backend.go) and
Production wires them into Dependencies; the residual is the
uncomposed wiring (B27). B16 nested invocation is decided: lifecycle
entries take no Ambient input, so nesting cannot collide through
them (row 90); the Acquire-level over-strict nested refusal stands
unchanged as first-leaf-owned. B18 sun_path is decided: strict-below
per platform, counted in bytes (row 66). B19/B20 bind step is built:
CheckSocketCustody enforces placement, leaf delegation, root,
ancestors, and socket kind (rows 67-70); the bind step refuses
intermediate symlinks through no-follow opens, which is stricter
than the B11 Acquire rule it stands beside. The rev7 P3-A fresh-decoy
foreground attach wiring is closed: TestAcquireForegroundRefusesEveryCatalogDecoyRunning
refuses every catalog-derived decoy alone and together on the
foreground running path with a spawn spy silent on every member, and
the attach attestation cells carry N-attach-attestation-decoy. New
bounds this revision: B33 states the unimplemented wrapper boundary
signal (fail-closed timeout until it lands), B34 the receipt/outcome
crash window, and B35 the tmux-version marker set.

## Mutant battery

`PYTHONDONTWRITEBYTECODE=1 python3
internal/tmuxserver/mutant_harness.py`: 134 second-leaf
narrowing rows KILLED, 1 harmless control SURVIVED (shared with
the first leaf's 76 rows, all still green), full pass with one
raw log per plant in the evidence tarball. Multi-entry rows
list every entry their killers cover, attribution verified per
test from the raw logs (see the row notes). Singleton refusal
arms ship no row by bound B22; engine-normalized status details
measure at the helper by bound B23.

## Crash, idempotency, and determinism

Every mutating operation replays the identical request without
new execs (seven idempotency tests, one per mutating op);
uncertain receipts reconcile through status before resuming
(resume tests for effect failure, recheck failure, and
otherwise-proven status); tampered and corrupt replays refuse
(per-member tamper table, corrupt-image, hook-failure tests).
No committed test execs a real tmux, dials a real socket, or
reads wall time: the scripted runner, staged sockets, and
manual clock are the only tmux the suite sees, and the suite
passes with no tmux installed (bound B1).

## Validation and evidence

Full 30-command configured suite green firsthand on the frozen
tree (gofmt, build, vet, full suite, race gate, cover, all fuzz
gates, tracecheck, cataloggen, linux/windows builds, JSON
check, board validate, diff check, windows vet); the
OUTCOME-keyed base-vs-candidate importer comparison over the
complete 34-package importer closure is clean (2662 shared top-level
inputs and 20345 shared subtests, zero moved; 205 top-level and 169
subtest additions, all PASS; zero removed).
Raw logs: `TASK-260830-1c28dz_rework-evidence-rev2.tar.gz`.