# TASK-260830-1c28dz rework rev2 — results

Base: rev1 candidate on checkpoint `1ba06e9` (trunk unmoved, no
refresh, no rebase). Candidate branch
`task-board/story/STORY-260830-2t4g7i`, work UNCOMMITTED.

## Verdict

All seven rev1 blocking findings (P1-A…P1-E, P2-A, P2-B) are closed
with driven evidence. AC rows 59–91: 33 of 33 carry at least one
passing named test through a production entry. Operations: 8 of 8
dispatch through `Lifecycle.Execute`.

Coverage distinction (per the brief §8): dispatch/execution
coverage (8/8 entries reached, 33/33 rows referenced) is not
production conformance. Conformance here is measured by narrowing
mutants: 134 second-leaf narrowing rows KILLED plus the shared
harmless control SURVIVED (first leaf's 76 rows still green),
with one raw log per plant per run. The rev1 claims the P1s
falsified (rows 67/69, 79–83, 89) are re-driven below; every
multi-side/multi-member gate carries per-side admitting-row counts
in the symmetry paragraph, and the measured ratio is restated from
a mechanical recount (208 of 4448, 34 bound, 4206 unreachable with
reasons, 8 named undriven gaps).

## Finding table

Finding → production change → the test that fails without it →
evidence path (inside
`TASK-260830-1c28dz_rework-evidence-rev2.tar.gz` under
`evidence-TASK-260830-1c28dz/`).

| Finding | Change | Test that fails without it | Evidence |
|---|---|---|---|
| P1-A boundary vector | bare blocking `wait-for <channel>`, no `-L` | `TestExecuteBoundaryWaitsForSignal` (exact argv) | `mutant-logs/N-boundary-blocking-vector.log` |
| P1-A proof kind | `proofKind` carried engine→evidence, provider rows as context | `TestExecuteBoundaryBindsProofKind` (same rows/time, different evidence) | `mutant-logs/N-boundary-proof-kind.log` |
| P1-A barrier | quiesce = `lock-session` then `detach-client -s`; input attaches refuse once quiescing; no `send-keys` | `TestExecuteQuiesceBarrierSequence`, `TestExecuteAttachRefusesInputWhenQuiescing`, `TestExecuteQuiesceEmitsNoProviderInput` | `mutant-logs/N-quiesce-detach-step.log`, `N-quiesce-attach-gate.log`, `N-quiesce-sendkeys-absent.log`, `N-quiesce-close-exit.log`, `N-cmdvector-detach.log` |
| P1-B read-only | `attach-session -r` iff `input_authorized=false`; unstated refuses | `TestExecuteReadOnlyAttachIsReadOnly` (entry, both directions), `TestBuildCommandAttachRequiresInputFlag` | `mutant-logs/N-attach-readonly-vector.log`, `N-attach-input-flag.log` |
| P1-C stderr/signal | `RunResult` carries stderr; signal death errors, proves nothing | `TestOSRunnerCapturesStderr`, `TestOSRunnerSignalDeathProvesNothing` | `mutant-logs/N-osrunner-signal-death.log` |
| P1-C markers | absence only from exit + stderr marker; unmarked/denied/negative → unknown at all three consumers | `TestClassifyAbsenceMarkers`, `TestExecuteStopUnknownProbeIsNotClosure`, `TestExecuteStopUnmarkedExitIsNotClosure`, `TestExecuteStatusUnknownProbeIsUnavailable`, `TestExecuteTerminateUnknownConfirmIsNotTerminated` | `mutant-logs/N-probe-negative-exit.log`, `N-probe-unmarked-exit.log` |
| P1-D custody | lexical walk with per-prefix `OpenNoFollowDir`; root handle bound via `os.SameFile` | `TestCheckSocketCustodyRefusesIntermediateSymlink`, `TestSocketCustodySymlinkRefusesAtProbeAndSpawn`, `TestCheckSocketCustodyIdentityMismatchRefuses` | `mutant-logs/N-custody-alias-skip.log`, `N-custody-identity-bind.log`, `N-bind-ancestor-writable.log` |
| P1-E binding | create persists binding doc; restore re-admits via `termbind.ParseTerminalBinding`, agreement-checked, returned | `TestExecuteRestoreReturnsBinding`, `TestExecuteCreatePersistsBindingDocForRestore` (create→reboot→restore), `TestExecuteRestoreRefusesSwappedBindingDoc` | `mutant-logs/N-restore-binding-omit.log`, `N-restore-agreement-session.log`, `N-create-doc-persist.log`, `N-binddoc-session-identity.log`, `N-binddoc-lookup-identity.log`, `N-binddoc-document-shape.log` |
| P1-E sequence | after-restore branch: local lease → bounded refresh → resume/offer/park | `TestExecuteRestoreResumesUnderLocalLease`, `TestExecuteRestoreRemoteOfferOnLapsedGrant`, `TestExecuteRestoreParksOtherwise`, `TestExecuteRestoreRefreshBounded` | `mutant-logs/N-restore-branch-offer.log`, `N-restore-branch-holder.log`, `N-restore-branch-tuple.log`, `N-restore-branch-material.log`, `N-restore-branch-remote.log`, `N-refresh-bound-default.log` |
| P2-A replay | outcome (incl. original timestamps) persisted per idempotency key and replayed | `TestExecuteQuiesceReplayKeepsTimestamps`, `TestExecuteBoundaryReplayKeepsProofAndTime`, `TestOutcomeRecordCrashConverges` | `mutant-logs/N-replay-timestamp-quiesce.log`, `N-replay-timestamp-boundary.log`, `N-outcome-key-record.log` |
| P2-B entries | rootwrite/ancestorwrite × status/restore refusal witnesses | `TestExecuteCustodyEntryRoots` (4 subtests, literal messages) | `mutant-logs/N-custody-entry-root-status.log`, `N-custody-entry-root-restore.log`, `N-custody-entry-ancestor-status.log`, `N-custody-entry-ancestor-restore.log` |

Full harness verdict: `harness-final.log` (210/210 ok, exit 0).

## Finding closures

### P1-A safe-boundary barrier/boundary protocol — CLOSED

- Boundary vector is the bare blocking `wait-for <channel>`
  (verified against tmux 3.6a `list-commands` + manual: bare form
  blocks until `wait-for -S`; `-L` acquires a lock and succeeds
  immediately).
- Proof kind carried: `executeEngineOp` sets
  `backend.proofKind` from `Params`; `observeBoundary` binds it
  into evidence; provider kinds bind contemporaneous `list-panes`
  rows as best-effort context (never failing the signaled proof).
- Barrier: quiesce runs `lock-session` then `detach-client -s`
  (verified: `lock-session` locks only currently attached clients
  — a newly attaching client gets an unlocked shell — and
  `detach-client -s` detaches all current clients of the session);
  new input-authorized attaches refuse at `executeAttach` once
  quiescing records (`local_precondition_failed` /
  `attach quiesced input`); read-only attaches stay admitted
  (observation retained); quiesce emits no `send-keys` (only the
  ordered request-stop effect sends).
- Stated bound B33: the wrapper `wait-for -S` signal step is
  unimplemented in the landed wrapper, so boundary waits time out
  fail-closed (`quiesce_timeout`) until it lands. Owner: wrapper task.

### P1-B read-only attach vector — CLOSED

- `BuildCommand` takes the input authorization and emits
  `attach-session -r` for `input_authorized=false` (man: read-only
  clients only detach/switch), writable otherwise; unstated
  authorization refuses (`tmux_invalid_arguments` /
  `command attach authorization`).

### P1-C probe failure classification — CLOSED

- `RunResult` carries stderr; `OSRunner` errors signal deaths
  instead of reporting -1 data.
- `classifyAbsence` proves absence only from exit + stderr marker
  (`can't find session`, `can't find window`, no-such-socket
  connect error — all verified on tmux 3.6a, whose every failure
  exits 1); negative, unmarked, denied, and refused exits are
  unknown. Consumers: `probePanes` (unknown →
  `terminal_backend_unavailable`), `pollSession` (tri-state;
  unknown polls to the deadline, never closes), `terminateStale`
  (unknown confirm errors, never terminates).
- Stated bound B35: markers verified on tmux 3.6a; other versions
  fail closed to unknown.

### P1-D custody symlink traversal — CLOSED

- `checkCustodyAncestors` walks the lexical path with per-prefix
  `secprim.OpenNoFollowDir` (no `EvalSymlinks`);
  `checkCustodyRoot` opens no-follow, verifies through the
  descriptor, and binds the handle back to the path
  (`os.SameFile`, seam-tested). Details preserved (`socket root`,
  `socket ancestor`).

### P1-E restore binding + after-restore sequence — CLOSED

- Create keeps the carried binding document beside the bootstrap
  receipt (`InstanceStates.RecordBindingDoc`); restore re-admits
  it through `termbind.ParseTerminalBinding`, checks
  session/instance/backend/generation agreement, and returns it
  (nothing minted).
- After-restore branch in `executeRestore`: local lease read →
  bounded mesh refresh (default 5000 ms, measured) → resume iff
  local holds the winning tuple + material valid; remote offer
  iff another host holds + interactive; else parked, never
  launching.

### P2-A replay timestamps — CLOSED

- `InstanceStates.RecordOutcome/LookupOutcome` persist the
  quiesce/boundary report per idempotency key; first success
  records, retries replay.
- Stated bound B34: a crash between receipt commit and outcome
  record re-observes the report time (no second effect, same
  proof).

### P2-B census + comparison — CLOSED

- rootwrite/ancestorwrite × status/restore reclassified U2a → M,
  with the reviewer's exact four shapes committed as witnesses +
  rows.
- Symmetry paragraph carries per-side admitting-row counts for
  every multi-side/multi-member gate (shared rows noted); see the
  conformance matrix.
- Ratio restated from a mechanical recount: 208 measured of 4448
  (50+10+148), 34 bound, 4206 unreachable.
- Fixed witness names: `TestExecuteRefusesMissingDependencies`
  (was `...NilDependencies`), plus the created
  `TestExecuteRestoreIdempotent`,
  `TestExecuteStatusPresentIncludesIdentity`,
  `TestObserveStatusAbsentProbe`.
- OUTCOME-keyed comparison over the complete 34-package importer
  closure (JSON event grids, top-level + subtests): 2662 shared
  top-level inputs and 20345 shared subtests, ZERO moved; 205
  top-level + 169 subtest additions, all PASS, all in tmuxserver;
  zero removed. No input moved across any admission/refusal arm.
  Grids: `importer-base.json`, `importer-cand.json`; closure:
  `importer-pkgs.txt`; additions: `importer-added.txt`.
- Post-comparison tree delta (comparison ran 07:01–07:22, suite
  green since): one timing-helper body in `exec_test.go` (yield
  until child death; no test added/renamed/removed, no outcome
  changed) and one harness anchor re-indent in
  `mutant_harness.py` (comment-only w.r.t. shipped code). No
  production file changed after the comparison; the fresh full
  suite, race gate, and 210/210 harness below ran on the final
  tree.

## Census and battery

- Table D: 115 × 21 = 2415 cells; 148 M, 30 B, 2237 U (script).
- Battery: 210 rows, 210 ok — 209 KILLED (207 narrowing:
  134 second-leaf + 73 first-leaf; 2 supplementary additive)
  plus the 1 shared harmless control SURVIVED. The first leaf's
  76 rows are all still green. Verdict `harness-final.log`, one
  raw log per plant in `mutant-logs/`.
- Mask audit: all 162 distinct harness `run=` masks match ≥1
  passing test on the clean tree (`mask-coverage.log`); no
  vacuous row.

## Validation

Configured 30-command suite + required extras, all firsthand,
exit 0 (log → command):

| Log | Command | Result |
|---|---|---|
| `v-fast.log` | gofmt check + `go build ./...` + `go vet ./...` | clean / ok / ok |
| `v-full.log` | `go test ./... -count=1` | 45 ok, 0 FAIL |
| `v-race.log` | `go test ./... -race -count=1 -timeout 25m` | 45 ok, 0 FAIL, no data races |
| `v-cover.log` | `go test ./... -cover -count=1` | ok; tmuxserver 87.4% |
| `v-fuzz.log` | 17 fuzz gates (rpcwire ×4, scalar, canonicaljson ×4, secconftest ×8) | all PASS |
| `v-gates.log` | tracecheck + cataloggen `-adopted -check` | ok / ok |
| `v-cross.log` | GOOS=linux + GOOS=windows amd64 builds | ok / ok |
| `v-tree.log` | JSON check + `git diff --check` | ok / clean |
| `v-board.log` | `task-board validate` | exit 0; pre-existing board-wide issues only, none referencing this task |
| `v-winvets.log` | `GOOS=windows GOARCH=amd64 go vet ./...` | clean |
| `v-notmux.log` | tmux hidden from PATH + package suite `-v` | `tmux not on PATH`, 604 PASS, 0 FAIL |

Full `-v` count on the same test set: 3083 top-level PASS, 0
FAIL (the only later test edit was the timing-helper body, which
adds no tests). No gate timed out; no elapsed/load report owed.

## Reviewer rev1 file, verbatim rerun

6 of 7 pass unmodified against this candidate
(`TestReviewStopUnknownExit`, `TestReviewCustodyIntermediateSymlink`,
`TestReviewBoundaryNeedsSignal`, `TestReviewReadOnlyAttach`,
`TestReviewCustodyEntryRoots` 4/4, `TestReviewRestoreRequiredBinding`).
`TestReviewQuiesceReplayTimestamp` needs its one-line script update
(the P1-A barrier runs `detach-client` after `lock-session`, which
rev1 demanded): the committed `TestExecuteQuiesceReplayKeepsTimestamps`
is the adapted witness and passes.

## Bounds carried

B33 (wrapper signal unimplemented, fail-closed timeout), B34
(receipt/outcome crash window re-observes time), B35 (markers
verified on tmux 3.6a). B22–B32 as in the matrix. No claim is
made inside any bound.
