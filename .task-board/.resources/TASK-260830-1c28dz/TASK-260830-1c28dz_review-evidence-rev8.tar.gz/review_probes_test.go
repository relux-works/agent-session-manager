//go:build !windows
package tmuxserver
import("context";"testing";"time";"os";"path/filepath")
type reviewWaitRunner struct { reached chan struct{}; release chan struct{} }
func(r reviewWaitRunner) Run(ctx context.Context, argv []string)(RunResult,error){
 if argv[3]!="has-session" {return RunResult{},nil}
 select {case r.reached<-struct{}{}:default:}
 select {case <-ctx.Done():return RunResult{},ctx.Err();case <-r.release:return RunResult{ExitCode:1,Stderr:[]byte("can't find session")},nil}
}
func TestReviewStopPollCommandHonorsDeadline(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted()); fx.lc.Now=time.Now;fx.lc.Sleep=time.Sleep
 now:=time.Now().UTC();deadline:=now.Add(200*time.Millisecond)
 raw:=lxStopBody(t,5,func(o map[string]any){c:=o["context"].(map[string]any);c["deadline_at"]=formatTimestamp(deadline);a:=c["authorization"].(map[string]any);a["issued_at"]=formatTimestamp(now.Add(-time.Hour));a["expires_at"]=formatTimestamp(now.Add(time.Hour))})
 r:=reviewWaitRunner{make(chan struct{},1),make(chan struct{})};fx.lc.Runner=r
 done:=make(chan error,1);start:=time.Now()
 go func(){_,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"request-stop",Body:raw,Source:"quiescing",Admitted:fullLifecycleAdmitted()});done<-err}()
 select {case <-r.reached:case <-time.After(time.Second*5):close(r.release);t.Fatal("no poll")}
 var err error;late:=false
 select {case err=<-done:case <-time.After(time.Until(deadline)+400*time.Millisecond):late=true}
 close(r.release);if late {err=<-done;t.Fatalf("poll waits until external release at %v past 200ms deadline; err=%v",time.Since(start),err)}
 t.Logf("returned %v err=%v",time.Since(start),err)
}
func TestReviewAttachRetryWithOtherPeer(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 for _,id:=range []string{lxClient,lxClientB}{raw:=lxAttachBody(t,func(o map[string]any){o["client_id"]=id});if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:raw,Source:"active",Admitted:fullLifecycleAdmitted()});err!=nil {t.Fatal(err)}}
 _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"active",Admitted:admittedWith("local_attach")})
 if err!=nil {t.Fatalf("identical retry over existing peer refused: %v",err)}
}

func TestReviewAttachPeerDirectoryFailsClosed(t *testing.T){
 fx:=newLifecycleFixture(t,withoutCapability("multi_attach"))
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:withoutCapability("multi_attach")});err!=nil {t.Fatal(err)}
 peer:=filepath.Join(fx.data,"attachstore","termbind","attach",lxInstance,lxClient+".json")
 raw,err:=os.ReadFile(peer);if err!=nil {t.Fatal(err)}
 if err=os.Remove(peer);err!=nil{t.Fatal(err)};if err=os.Mkdir(peer,0700);err!=nil{t.Fatal(err)};if err=os.WriteFile(filepath.Join(peer,"saved"),raw,0600);err!=nil{t.Fatal(err)}
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,func(o map[string]any){o["client_id"]=lxClientB}),Source:"active",Admitted:withoutCapability("multi_attach")})
 _,found,lookupErr:=fx.lc.Attach.Lookup(lxSession,lxInstance,lxClientB)
 if err==nil ||found {t.Fatalf("unreadable peer counted as absent: err=%v new_receipt=%v lookup=%v attach=%+v",err,found,lookupErr,out.Attach)}
}
