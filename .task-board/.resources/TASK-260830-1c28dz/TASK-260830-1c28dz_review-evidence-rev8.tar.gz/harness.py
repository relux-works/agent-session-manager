import pathlib,subprocess,os,time,json,runpy,sys
p=pathlib.Path(__file__).resolve().parent
pkg=sys.argv[1];chunk=int(sys.argv[2]);rep=int(sys.argv[3])
h=p/('mutants2/internal' if rep==2 else 'mutants/internal')/pkg/'mutant_harness.py'
rows=runpy.run_path(str(h))['MUTANTS']; selected=rows[chunk*60:(chunk+1)*60]
if not selected: raise SystemExit('empty')
name=f'harness-{pkg}-{chunk}-{rep}'; logs=p/name;logs.mkdir(exist_ok=True)
start=time.time()
with (p/(name+'.log')).open('w') as f:
 r=subprocess.run([sys.executable,str(h),'--log-dir',str(logs),*[m.name for m in selected]],stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',AX_MUTANT_VERBOSE='1'),timeout=540)
(p/(name+'.json')).write_text(json.dumps(dict(exit=r.returncode,rows=len(selected),seconds=time.time()-start,load=os.getloadavg())))
print(name,r.returncode,len(selected),time.time()-start)
