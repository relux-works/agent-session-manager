import pathlib,re,json,subprocess
p=pathlib.Path(__file__).resolve().parent;summary={}
for n in [1,2]:
 v={};errors=[]
 for f in [*p.glob(f'harness-tmuxserver-*-{n}.log'),p/f'infrastructure-retry-{n}.log',p/f'missing-tail-retry-{n}.log']:
  for l in f.read_text().splitlines():
   m=re.match(r'(ok|MISMATCH): ([^:]+): (KILLED|SURVIVED)',l)
   if m:v[m[2]]={'mark':m[1],'verdict':m[3]}
   if l.startswith('ERROR:'):errors.append(l)
 tb={}
 for l in (p/f'termbind-{n}.log').read_text().splitlines():
  m=re.match(r'(ok|MISMATCH): ([^:]+): (KILLED|SURVIVED)',l)
  if m:tb[m[2]]={'mark':m[1],'verdict':m[3]}
 summary[str(n)]={'tmuxserver':v,'termbind':tb,'initial_infrastructure_errors':errors}
 print(n,len(v),len(tb),'kills',sum(x['verdict']=='KILLED' for x in list(v.values())+list(tb.values())),'all expected',all(x['mark']=='ok' for x in list(v.values())+list(tb.values())))
 assert len(v)==293 and len(tb)==41 and all(x['mark']=='ok' for x in list(v.values())+list(tb.values()))
(p/'mutation-summary.json').write_text(json.dumps(summary,indent=2))
files=subprocess.check_output(['git','ls-tree','-r','--name-only','02441ead3068785b9ad5d52771a073da74a13986','internal','README.md','LOGBOOK.md','go.mod','go.sum','task-board.config.json'],text=True).splitlines()
mismatches={}
for copy in ['candidate','own','mutants','mutants2']:
 mismatches[copy]=[x for x in files if (p/copy/x).read_bytes()!=(p/'candidate'/x).read_bytes()]
(p/'restoration-audit.json').write_text(json.dumps(mismatches,indent=2));print('restoration',mismatches)
assert not any(mismatches.values())
attrib={}
for name in ['N-stop-escalation-generation','N-stop-escalation-expiry','N-stop-escalation-deadline','N-attach-wait-deadline']:
 matches=list(p.glob('harness-tmuxserver-*-1/'+name+'.log'))
 attrib[name]=[l for f in matches for l in f.read_text().splitlines() if '--- FAIL:' in l]
(p/'shared-site-attribution.json').write_text(json.dumps(attrib,indent=2));print('attribution', {k:len(v) for k,v in attrib.items()})
