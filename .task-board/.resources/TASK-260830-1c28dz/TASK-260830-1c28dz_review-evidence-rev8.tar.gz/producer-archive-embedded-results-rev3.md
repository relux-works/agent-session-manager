# TASK-260830-1c28dz — Producer results, rev3 (tmux lifecycle operations)

Date: 2026-09-22. Candidate UNCOMMITTED in the Story worktree
(`task-board/story/STORY-260830-2t4g7i`, 41 changed paths over
the branch tip).
Base: `d4bd91d` (branch tip over trunk `40bb8c9`; rev1 compared
against `1ba06e9` before the refresh).

## Revision-3 fixes (reviewer P1/P2)

- P1-A: read-only attach observes without reopening quiesced
  input (no `recordAfter` on the read-only path).
  `TestExecuteReadOnlyAttachPreservesQuiescedInput` /
  `N-attach-readonly-record`.
- P2-A: corrupt, forged-key, and empty-time outcome reports
  refuse integrity instead of becoming fresh evidence.
  `TestExecute{Quiesce,Boundary}CorruptOutcomeRefusesIntegrity`,
  `TestExecuteQuiesceForgedOutcomeKeyRefusesIntegrity`,
  `TestExecute{Quiesce,Boundary}EmptyRecordedTimeRefusesIntegrity`,
  `TestExecuteBoundaryRecordCrashRefusesIntegrity`,
  `TestInstanceStatesLookupOutcomeRefusesForgedKey` /
  `N-{quiesce,boundary}-report-{corrupt,empty,record}`,
  `N-outcome-key-forged` (the LOOK arm left bound B22 by
  narrowing).
- P1-B: status observes the recorded binding tuple instead of
  echoing the query: member-by-member non-match on drift,
  unbound sessions refuse unknown, tampered documents refuse
  integrity, negative backend counts refuse.
  `TestExecuteStatusNonMatchEachMember`,
  `TestExecuteStatusExactUnboundSessionRefusesUnknown`,
  `TestExecuteStatusBindingTamperRefusesIntegrity`,
  `TestObserveStatusSessionScopedObservesRecordedTuple`,
  `TestObserveStatusExact{Backend,Protocol}DriftNonMatches`,
  `TestExecuteStatusRefusesNegativeAttachedCount` /
  `N-status-{exact-unbound,doc-missing,parse-admit,agree-session,agree-instance,match-instance,match-impl,match-generation,match-backend,match-proto,negative-attached}`.
- P1-C: reboot restore mints a termbind successor generation
  (`MintSuccessorBinding`: new generation, prior link,
  recomputed identity, deterministic, re-admitted), persisted
  before effects, with prior validation preceding effects and
  successor retries converging.
  `TestExecuteRestore{AcrossServerGeneration,SuccessorRetryConverges,PriorValidationPrecedesEffects,RefusesSubstitutedInstance,RefusesSubstitutedSession,RefusesSubstitutedBackend}` /
  `N-restore-{succession-gen,mint-generation,successor-persist,prior-instance,prior-backend,agreement-session}`,
  plus termbind `TestMintSuccessorBinding*` /
  `N-successor-{same-generation,supersedes,identity-field,generation-inherit}`.
- P1-D: after-restore composition at the wrapper entry
  (`ExecuteWrapperRestore`): mesh refresh under the measured
  bound runs before Decide; a lapsed local grant under a
  refreshed remote winner offers remote attach/takeover with no
  backend effects; every other non-resume case parks without
  effects. Table E (13 outcomes) in TRACEABILITY; clause row
  92. `TestWrapperRestore{LocalWinResumes,ReattachReplaysBackend,LapsedGrantRemoteOffer,ParksWithoutEffects,RefusesMalformed,RefreshBoundMeasured}` /
  `N-wrapper-{reorder-refresh,route-material,mode,operation}`,
  `N-refresh-bound-default`.
- P2-B: per-operation custody twins (root/ancestor/socket-kind/
  leaf-mode on all six Execute legs) with narrowing rows
  `N-bind-{root-writable,ancestor-writable,socket-kind}` and
  entry rows `N-custody-entry-*`.
- Census: reachable-undriven cells reclassed from U2b
  (unreachable) to bound B39; new bounds B36 (dependency
  singletons), B38 (unmodeled union rivals); Table C recount
  (119x11); Table D recount (119x21: 167 M, 152 B, 2180 U);
  Table E outcome grid (new); termbind clause row 67 +
  4 successor battery rows (termbind doc now 40 rows).

## Mutant battery

tmuxserver (`chunk1.out`..`chunk4.out`, `harness-logs/`):

- 235/235 rows as expected: 234 KILLED (232 narrowing `N-*`
  + 2 additive `D-*`) and `C-control` SURVIVED (harmless
  comment-only control, shared with the first leaf).
- One raw log per plant under `harness-logs/` (235 files).
- Chunk 1 (60 first-leaf rows) re-ran after the final doc
  edits (exit 0, 60/60 `ok:`); chunks 2-4 ran earlier in the
  same session on the identical code/tests/harness. The only
  post-harness delta is the two `TRACEABILITY.md` prose files,
  which no harness row reads; the package and full suites
  re-ran green after every edit.

termbind (`termbind-harness.out`, verbose with 40 raw blocks):

- 40/40 rows as expected: 38 narrowing `N-*` + 1
  supplementary `D-*` KILLED, `C-control` SURVIVED, including
  the 4 reboot-successor rows. Re-ran after the final edits
  (exit 0).

Combined: 275/275 rows as expected, zero mismatches.

## Acceptance criteria

34 of 34 tmuxserver rows (TRACEABILITY rows 59-92) driven
through production entries by named tests, plus termbind row
67 (successor mint); see
`TASK-260830-1c28dz_conformance-matrix.md` (AC table +
per-section mirrors + dispatch-arm table + gate x entry
census Tables B/C/D + Table E + bounds + battery; clause,
census, and bounds mirrors verified byte-identical to the
package TRACEABILITY by script).

## OUTCOME-keyed base-vs-candidate comparison (`outcome-comparison.txt`)

`outcome_compare.py` over `go test -json` streams (base from
a detached worktree at `d4bd91d`, candidate from this tree),
keyed by full test name:

- Base: 23806 tests (23792 pass, 14 pre-existing skips,
  all platform/conditional skips, zero failures).
- Candidate: 24263 tests (24249 pass, 0 fail, 14 skip).
- Base PASS retained: 23792/23792. 457 new (all pass).
- COMPARISON CLEAN: zero regressions.

Inputs that moved across an admission/refusal arm are all
inside the new leaf (no landed entry changed behavior —
23792/23792 retained proves it): read-only attach on quiesced
input now observes without recording; drifted status queries
now non-match instead of echoing; unbound status sessions
refuse unknown; corrupt/empty/forged-key outcome reports
refuse integrity; reboot restores mint successor generations;
lapsed-grant after-restores under a remote winner offer
instead of reaching backend authorization. Each moved input
has a named negative test and a narrowing row above.

## Validation gates (all exit 0; logs in the tarball)

- gofmt clean, `go build ./...`, `go vet ./...`,
  `git diff --check`, linux + windows builds
  (`v-fmt-build-vet.log`).
- `go test ./... -count=1` (`v-full.log`).
- `go test -race -count=1` on tmuxserver and termbind
  (`v-race-tmuxserver.log`, `v-race-termbind.log`).
- `go test -cover`: tmuxserver 87.9%, termbind 83.5%
  (`v-cover.log`).
- tracecheck, cataloggen, catalog, specdoc, traceability
  suites green (inside `v-full.log`).
- No-tmux run: `tmux` absent from PATH (`NO_TMUX`
  asserted), both touched packages pass (`v-notmux.log`).
- `task-board validate`: exit 0, 179 pre-existing
  missing-activity notes, none on this task (`v-board.log`).
- Fuzz: no `Fuzz` targets exist in the touched packages
  (grep-verified); fuzz seed corpora of the untouched
  packages run inside the full suite.

## Real-tmux witnesses

Zero: no committed test execs a real tmux, dials a real
socket, or reads wall time (`v-notmux.log`). Every AC row is
witnessed deterministically only.

## Census (second leaf)

Table B 24x21 (10 M, 494 U2a), Table C 119x11 (1290 U2a,
19 U2c), Table D 119x21 (167 M, 152 B, 2180 U; counts
verified by script over the table), Table E 13 after-restore
outcomes; totals 227 measured of 5576 with 156 bound and
4193 unreachable with reasons. Bounds B1-B39 (B37
unassigned): 27 driven-but-rowless cells and 125 named
undriven gaps (117 of them the B39 reachable-undriven
reclass), each with its owner in the matrix.
