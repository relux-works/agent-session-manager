import subprocess,time,os,sys,json,pathlib
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1];cmd=sys.argv[2:];start=time.time()
with (root/(name+'.log')).open('w') as f:
 f.write('command='+repr(cmd)+'\n');f.flush()
 r=subprocess.run(cmd,cwd=root/'candidate',stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'),timeout=550)
meta=dict(command=cmd,exit=r.returncode,seconds=time.time()-start,load=os.getloadavg())
(root/(name+'.json')).write_text(json.dumps(meta));print(name,meta)
