import pathlib,subprocess,json,time
r=pathlib.Path(__file__).resolve().parent; repo=r/'independent'; output=r/'independent-logs';output.mkdir(exist_ok=True)
plants=[
('R1','status.go','if err != nil || attached < 0 {','if (err != nil && count != "0junk") || attached < 0 {','TestReviewKillAttachedParseError'),
('R2','state.go','if document.IdempotencyKey == "" {','if document.IdempotencyKey == "" && string(raw) != "{}" {','TestReviewKillEmptyBarrierKey'),
('R3','probe.go','if err := CheckSocketCustody(socket, prober.Root, prober.Platform); err != nil {','if err := CheckSocketCustody(socket, prober.Root, prober.Platform); err != nil && err.Error() != "tmux server refused: tmux_unsafe_socket_path at socket root" {','TestReviewKillProberRootCustody'),
('R4','state.go','if errors.Is(err, os.ErrNotExist) {\n\t\t\treturn "", false, nil','if errors.Is(err, os.ErrNotExist) || strings.Contains(err.Error(), "is a directory") {\n\t\t\treturn "", false, nil','TestReviewKillStateReadFailure'),
('control','errors.go','// Error is a package-local refusal.','// Error is a package-local refusal. Harmless review control.','TestReviewKill')]
results=[];killer=repo/'internal/tmuxserver/review_killers_test.go'
def run(name,args):
 cmd=['go','test','./internal/tmuxserver','-count=1']+args
 start=time.time();p=subprocess.run(cmd,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=300)
 (output/(name+'.log')).write_text('command: '+repr(cmd)+'\nexit: '+str(p.returncode)+'\nseconds: '+str(time.time()-start)+'\n'+p.stdout)
 return p.returncode,'--- FAIL' in p.stdout
killer.write_text((r/'killers.go').read_text());results.append(('baseline-killers',run('baseline-killers',['-run','^TestReviewKill','-v'])));killer.unlink()
for name,file,old,new,test in plants:
 p=repo/'internal/tmuxserver'/file;original=p.read_text();assert original.count(old)==1,(name,original.count(old))
 (output/(name+'.patch.json')).write_text(json.dumps(dict(file=file,old=old,new=new),indent=2))
 try:
  p.write_text(original.replace(old,new))
  for i in (1,2):results.append((name,'committed',i,run(f'{name}-committed-{i}',[])))
  killer.write_text((r/'killers.go').read_text())
  for i in (1,2):results.append((name,'killer',i,run(f'{name}-killer-{i}',['-run','^'+test,'-v'])))
 finally:
  p.write_text(original);killer.unlink(missing_ok=True)
 (output/'results.json').write_text(json.dumps(results,indent=2));print(name,results[-4:],flush=True)
