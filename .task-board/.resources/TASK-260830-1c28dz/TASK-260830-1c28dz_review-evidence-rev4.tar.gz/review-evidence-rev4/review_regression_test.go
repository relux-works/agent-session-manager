//go:build !windows

package tmuxserver

import (
	"context"
	"github.com/relux-works/agent-session-manager/internal/axpane"
	"strings"
	"testing"
)

func TestReviewExistingActiveMemoryCannotReopenQuiescedInput(t *testing.T) {
	fx := newLifecycleFixture(t, fullLifecycleAdmitted())
	if _, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "attach", Body: lxAttachBody(t, nil), Source: "parked", Admitted: fullLifecycleAdmitted()}); err != nil {
		t.Fatal(err)
	}
	fx.lc.States.WithHooks(&StateHooks{AfterStage: func(path string) error {
		if strings.Contains(path, "/instances/") {
			return errFakeTransport
		}
		return nil
	}})
	fx.runner.queue("lock-session", "", 0).queue("detach-client", "", 0)
	_, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "quiesce-input", Body: lxQuiesceBody(t, nil), Source: "active", Admitted: fullLifecycleAdmitted()})
	if err == nil {
		t.Fatal("quiesce unexpectedly succeeded")
	}
	fx.lc.States.WithHooks(nil)
	out, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "attach", Body: lxAttachBody(t, func(o map[string]any) { o["client_id"] = lxClientB }), Source: "parked", Admitted: fullLifecycleAdmitted()})
	if err == nil {
		t.Fatalf("writable attach admitted after durable closure with stale active memory: %+v argv=%v", out.Attach, out.Argv)
	}
}

func TestReviewWrapperBootstrapMustBindExecutedRestore(t *testing.T) {
	fx := newLifecycleFixture(t, fullLifecycleAdmitted())
	fx.lc.LocalHostID = lxHost
	fx.lc.LeaseRefresh = func(context.Context, string) (RefreshWinner, error) {
		return RefreshWinner{LeaseID: lxLease, Epoch: 7, HolderHostID: lxHost}, nil
	}
	recordBinding(t, fx, lxDigestA)
	fx.runner.queue("new-session", "", 0)
	input := wDecideInput(t, true)
	input.BootstrapOperationID = lxOperation
	out, err := fx.lc.ExecuteWrapperRestore(context.Background(), WrapperRestoreRequest{Decide: input, Grant: wGrant(t, wFreshValidatedAt), HasGrant: true, Policy: wPolicy(), Restore: wRestoreRequest(t)})
	if err == nil && out.Decision.Action == axpane.ActionLaunch && fx.runner.callCount() > 0 {
		t.Fatalf("launch decision for bootstrap %s executed restore for different bootstrap %s: commands=%v", input.BootstrapOperationID, lxBootstrap, fx.runner.subcommands())
	}
}

func TestReviewWrapperInstanceMustBindExecutedRestore(t *testing.T) {
	fx := newLifecycleFixture(t, fullLifecycleAdmitted())
	fx.lc.LocalHostID = lxHost
	fx.lc.LeaseRefresh = func(context.Context, string) (RefreshWinner, error) {
		return RefreshWinner{LeaseID: lxLease, Epoch: 7, HolderHostID: lxHost}, nil
	}
	recordBinding(t, fx, lxDigestA)
	fx.runner.queue("new-session", "", 0)
	input := wDecideInput(t, true)
	descriptor, err := axpane.BuildDescriptor(axpane.DescriptorParams{Binding: axpane.BindingRef{BindingDigest: input.HostBinding.TerminalBindingID, BackendID: input.HostBinding.BackendID, ImplementationVersion: input.HostBinding.ImplementationVersion, ProtocolVersion: input.HostBinding.ProtocolVersion, Generation: input.HostBinding.Generation}, InstanceID: lxClientB, Interactive: true, Columns: 80, Rows: 24})
	if err != nil {
		t.Fatal(err)
	}
	input.Descriptor = descriptor
	out, err := fx.lc.ExecuteWrapperRestore(context.Background(), WrapperRestoreRequest{Decide: input, Grant: wGrant(t, wFreshValidatedAt), HasGrant: true, Policy: wPolicy(), Restore: wRestoreRequest(t)})
	if err == nil && out.Decision.Action == axpane.ActionLaunch && fx.runner.callCount() > 0 {
		t.Fatalf("launch decision for instance %s executed restore for different instance %s: commands=%v", lxClientB, lxInstance, fx.runner.subcommands())
	}
}

func TestReviewFailedStopCannotEraseQuiescence(t *testing.T) {
	fx := newLifecycleFixture(t, fullLifecycleAdmitted())
	fx.runner.queue("lock-session", "", 0).queue("detach-client", "", 0)
	if _, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "quiesce-input", Body: lxQuiesceBody(t, nil), Source: "active", Admitted: fullLifecycleAdmitted()}); err != nil {
		t.Fatal(err)
	}
	body := lxStopBody(t, 60000, func(o map[string]any) {
		o["context"].(map[string]any)["authorization"].(map[string]any)["expires_at"] = "2026-09-01T01:00:00.000Z"
	})
	if _, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "request-stop", Body: body, Source: "active", Admitted: fullLifecycleAdmitted()}); err == nil {
		t.Fatal("expired stop admitted")
	}
	out, err := fx.lc.Execute(context.Background(), OpRequest{Operation: "attach", Body: lxAttachBody(t, nil), Source: "parked", Admitted: fullLifecycleAdmitted()})
	if err == nil {
		t.Fatalf("failed stop erased successful quiescence: attach=%+v", out.Attach)
	}
}
