//go:build !windows
package tmuxserver
import("context";"os";"path/filepath";"testing")
func TestReviewKillAttachedParseError(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());recordBinding(t,fx,lxDigestA)
 fx.runner.queue("list-panes","sh\n",0).queue("list-sessions",lxInstance+"|0junk\n",0)
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"status",Body:lxStatusBody(t,true,true,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("malformed count admitted")}
}
func TestReviewKillEmptyBarrierKey(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());dir:=filepath.Join(fx.data,"states","tmuxlifecycle","outcomes")
 if err:=os.MkdirAll(dir,0755);err!=nil{t.Fatal(err)};if err:=os.WriteFile(filepath.Join(dir,"review.json"),[]byte("{}"),0600);err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("empty-key report admitted writable attach")}
}
func TestReviewKillProberRootCustody(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());if err:=os.Chmod(fx.root,0777);err!=nil{t.Fatal(err)}
 p:=ServerProber{Root:fx.root,Platform:fx.lc.Platform,Dialer:&fakeDialer{outcomes:[]DialOutcome{DialLive}},Admit:func()(RealmAdmission,error){return RealmAdmission{},nil}}
 if _,err:=p.Probe(fx.socket);err==nil{t.Fatal("prober admitted writable root")}
}
func TestReviewKillStateReadFailure(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());path:=filepath.Join(fx.data,"states","tmuxlifecycle","instances",lxInstance+".json")
 if err:=os.MkdirAll(path,0755);err!=nil{t.Fatal(err)}
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"parked",Admitted:fullLifecycleAdmitted()});err==nil{t.Fatal("unreadable state admitted attach")}
}
