import pathlib,subprocess,json,hashlib
p=pathlib.Path(__file__).resolve().parent
cwd=pathlib.Path.cwd();tree='8ce88f1e30a3faebe3717417faac1f6a03026fb1';base='d4bd91d0e740285b21b8d65bf6f074c8009b04ae'
def git(*args):return subprocess.check_output(['git',*args])
files={}
for entry in git('ls-tree','-r','-z',tree).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();files[name.decode()]=(mode,oid)
out={}
for label,root in [('live',cwd),('validation',p/'validation')]:
 mismatch=[];count=0
 for name,(mode,oid) in files.items():
  if name.startswith('.task-board/'):continue
  f=root/name
  raw=str(f.readlink()).encode() if f.is_symlink() else f.read_bytes()
  found=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  if found!=oid:mismatch.append(name)
  count+=1
 out[label]={'checked':count,'mismatches':mismatch}
out['head']=git('rev-parse','HEAD').decode().strip()
out['index_diff']=git('diff','--cached','--name-only').decode()
out['config_equal']=git('show',base+':task-board.config.json')==git('show',tree+':task-board.config.json')
out['registry_delta']=git('diff','--name-only',base,tree,'--','internal/traceability').decode()
main=git('rev-parse','origin/main').decode().strip()
trunkpaths=git('diff','--name-only',base,main).decode().splitlines()
out['trunk_paths_present_in_candidate']=[n for n in trunkpaths if n in files]
out['trunk_drift_outside_story']=[n for n in trunkpaths if n in files and not n.startswith(('.task-board/','internal/tmuxserver/')) and git('show',tree+':'+n)!=git('show',main+':'+n)]
out['python_cache']=[str(f.relative_to(p)) for f in p.rglob('*') if f.name=='__pycache__' or f.suffix=='.pyc']
(p/'identity-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
