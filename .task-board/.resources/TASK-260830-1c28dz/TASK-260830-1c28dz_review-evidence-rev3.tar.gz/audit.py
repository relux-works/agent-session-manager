import pathlib,json,re,subprocess,hashlib,collections,tarfile
p=pathlib.Path(__file__).resolve().parent;r=p/'validation'
events=[json.loads(l) for l in (p/'notmux.json').read_text().splitlines() if l.startswith('{')]
passed={e.get('Test') for e in events if e['Action']=='pass' and e.get('Test')}
s=(r/'internal/tmuxserver/TRACEABILITY.md').read_text();rows={}
for line in s.splitlines():
 m=re.match(r'\| (\d+) \|',line)
 if m and 59<=int(m[1])<=92:
  names=re.findall(r'Test\w+',line);rows[m[1]]={'tests':names,'all_executed':all(n in passed for n in names),'call_site':line.split('|')[3].strip()}
counts=collections.Counter(e['Action'] for e in events if e.get('Test') and e['Action'] in ['pass','fail','skip'])
config=json.loads((r/'task-board.config.json').read_text())
census=collections.Counter();nrows=0
for l in s.splitlines():
 cells=[c.strip() for c in l.strip('|').split('|')]
 if len(cells)==22 and re.match(r'^[a-z].*\(',cells[0]):
  nrows+=1
  for c in cells[1:]:census['M' if c.startswith('M ') else 'B' if c.startswith('B') else 'U' if c.startswith('U') else '?']+=1
out={'candidate':'8ce88f1e30a3faebe3717417faac1f6a03026fb1','no_tmux_test_counts':dict(counts),'ac_count':len(rows),'ac_named_tests_executed':sum(v['all_executed'] for v in rows.values()),'ac_rows':rows,'tableD_rows':nrows,'tableD_counts':dict(census),'configured_commands':config['spawn']['worktree_isolation']['validation']['commands']}
(p/'audit.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['ac_rows','configured_commands']},indent=2));print('configured command count',len(out['configured_commands']))
print('missing names',[n for v in rows.values() for n in v['tests'] if n not in passed])
with tarfile.open(p/'producer.tar.gz') as tar:
 script=tar.extractfile('./outcome_compare.py').read();(p/'producer-outcome_compare.py.txt').write_bytes(script)
 packages={}
 for name in ['outcome-base.json','outcome-cand.json']:
  pk=set()
  for line in tar.extractfile('./'+name):
   try:e=json.loads(line)
   except:continue
   if e.get('Package'):pk.add(e['Package'])
  packages[name]=sorted(pk)
(p/'producer-package-inventory.json').write_text(json.dumps(packages,indent=2))
