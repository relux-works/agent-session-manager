import pathlib,subprocess,json,time
p=pathlib.Path(__file__).resolve().parent;r=p/'probes';f=r/'internal/tmuxserver/probe.go';k=r/'internal/tmuxserver/reviewer_killers_unix_test.go'
raw=f.read_text();tests=k.read_bytes()
old='if err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil {'
new='if err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil && err.Error() != "tmux server refused: tmux_unsafe_socket_path at socket root" {'
assert raw.count(old)==1
rows=[]
def run(label,mask):
 s=time.monotonic();v=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-run',mask,'-v','-timeout=180s'],cwd=r,capture_output=True,text=True,timeout=220)
 (p/(label+'.log')).write_text(v.stdout+v.stderr);row=dict(name=label,exit=v.returncode,seconds=time.monotonic()-s);rows.append(row);print(json.dumps(row),flush=True)
try:
 f.write_text(raw.replace(old,new));k.unlink()
 for n in (1,2):run('R5-corrected-suite-'+str(n),'.')
 k.write_bytes(tests)
 for n in (1,2):run('R5-corrected-killer-'+str(n),'^TestReviewKillSpawnRootCustody$')
finally:f.write_text(raw);k.write_bytes(tests)
(p/'r5fix-results.json').write_text(json.dumps(dict(old=old,new=new,runs=rows),indent=2))
