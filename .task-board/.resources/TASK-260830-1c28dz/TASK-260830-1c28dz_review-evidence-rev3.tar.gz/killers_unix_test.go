//go:build !windows
package tmuxserver
import("context";"os";"os/exec";"testing")
func TestReviewKillStatusAttachedExit(t *testing.T){reviewStatusRefusal(t,"sh\n",0,lxInstance+"|0\n",1)}
func TestReviewKillStatusForeignRow(t *testing.T){reviewStatusRefusal(t,"sh\n",0,"review-foreign-instance|0\n",0)}
func TestReviewKillStatusUnknownPanes(t *testing.T){reviewStatusRefusal(t,"sh\n",2,lxInstance+"|0\n",0)}
func reviewStatusRefusal(t *testing.T,panes string,pe int,sessions string,se int){
 t.Helper();fx:=newLifecycleFixture(t,fullLifecycleAdmitted());recordBinding(t,fx,lxDigestA)
 fx.runner.queue("list-panes",panes,pe).queue("list-sessions",sessions,se)
 _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"status",Body:lxStatusBody(t,true,true,nil),Admitted:fullLifecycleAdmitted()})
 if err==nil {t.Fatal("unproven status admitted")}
}
func TestReviewKillOSRunnerArgv(t *testing.T){
 called:=false
 runner:=OSRunner{Command:func(ctx context.Context,_ string,_ ...string)*exec.Cmd{called=true;return exec.CommandContext(ctx,"/usr/bin/true")}}
 _,err:=runner.Run(context.Background(),[]string{"tmux","review\x00arg"})
 if err==nil || called {t.Fatalf("NUL argument admitted to execution: called=%v err=%v",called,err)}
}
func TestReviewKillSpawnRootCustody(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());if err:=os.Chmod(fx.root,0777);err!=nil{t.Fatal(err)}
 fx.runner.queue("new-session","",0)
 spawner:=ServerSpawner{Root:fx.root,Platform:fx.lc.Platform,Runner:fx.runner}
 err:=spawner.Spawn(fx.socket,[]string{"tmux","-S",fx.socket,"new-session","-d","-s",lxInstance,"ax","pane",lxSession})
 if err==nil || fx.runner.callCount()!=0 {t.Fatalf("unsafe root admitted by spawn: err=%v calls=%v",err,fx.runner.subcommands())}
}
