import pathlib,subprocess,time,json,os
root=pathlib.Path(__file__).resolve().parent
repo=root/'probes'
probe=repo/'internal/tmuxserver/reviewer_unix_test.go'
probe.unlink()
plants=[
('R1-attached-exit','status.go','if result.ExitCode != 0 {','if result.ExitCode != 0 && result.ExitCode != 1 {'),
('R2-attached-target','status.go','if name != instance {','if name != instance && name != "review-foreign-instance" {'),
('R3-panes-unknown','status.go','if !present {','if !present && result.ExitCode != 2 {'),
('R4-osrunner-argv','exec.go','if err := secprim.CheckArgv(argv); err != nil {','if err := secprim.CheckArgv(argv); err != nil && !(len(argv) == 2 && argv[1] == "review\\x00arg") {'),
('C-harmless','status.go','package tmuxserver','package tmuxserver\n// Reviewer harmless control.')]
rows=[]
for name,file,old,new in plants:
 path=repo/'internal/tmuxserver'/file
 original=path.read_text()
 # exec.go has a second helper arm; mutate only the first OSRunner arm.
 assert old in original,(name,'NOT_APPLIED')
 try:
  path.write_text(original.replace(old,new,1))
  for attempt in (1,2):
   start=time.monotonic()
   p=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-timeout=180s'],cwd=repo,capture_output=True,text=True,timeout=220)
   (root/f'{name}-{attempt}.log').write_text(p.stdout+p.stderr)
   verdict='SURVIVED' if p.returncode==0 else ('KILLED' if '--- FAIL:' in p.stdout else 'ERROR')
   row=dict(name=name,file=file,old=old,new=new,attempt=attempt,exit=p.returncode,verdict=verdict,seconds=time.monotonic()-start)
   rows.append(row);print(json.dumps(row),flush=True)
 finally:path.write_text(original)
(root/'independent-results.json').write_text(json.dumps(rows,indent=2))
