//go:build !windows
package tmuxserver
import (
 "context"
 "strings"
 "testing"
 "time"
 "github.com/relux-works/agent-session-manager/internal/axpane"
)
func TestReviewQuiesceStateWriteFailureCannotReopenInput(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 fx.lc.States.WithHooks(&StateHooks{AfterStage:func(path string) error { if strings.Contains(path,"/instances/") { return errFakeTransport }; return nil }})
 fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"quiesce-input",Body:lxQuiesceBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()})
 t.Logf("quiesce error=%v",err)
 fx.lc.States.WithHooks(nil)
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:lxAttachBody(t,nil),Source:"active",Admitted:fullLifecycleAdmitted()})
 if err==nil && out.Attach!=nil && out.Attach.InputAuthorized { t.Fatalf("writable attach admitted after closure with lost state: argv=%v",out.Argv) }
}
func TestReviewExpiredRefreshMustNotResume(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted()); fx.lc.LocalHostID=lxHost
 fx.lc.MeshRefreshTimeout=time.Millisecond
 fx.lc.LeaseRefresh=func(ctx context.Context,_ string)(RefreshWinner,error){ <-ctx.Done(); return RefreshWinner{LeaseID:lxLease,Epoch:7,HolderHostID:lxHost},nil }
 recordBinding(t,fx,lxDigestA);fx.runner.queue("new-session","",0)
 out,err:=fx.lc.ExecuteWrapperRestore(context.Background(),WrapperRestoreRequest{Decide:wDecideInput(t,true),Grant:wGrant(t,wFreshValidatedAt),HasGrant:true,Policy:wPolicy(),Restore:wRestoreRequest(t)})
 if err==nil && (out.Decision.Action==axpane.ActionLaunch || fx.runner.callCount()!=0) { t.Fatalf("expired refresh admitted: action=%s succeeded=%v effects=%v",out.Decision.Action,out.RefreshSucceeded,fx.runner.subcommands()) }
}
func TestReviewRefreshBoundNotJustCooperativeDeadline(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted()); fx.lc.LocalHostID=lxHost
 fx.lc.MeshRefreshTimeout=time.Millisecond
 fx.lc.LeaseRefresh=func(ctx context.Context,_ string)(RefreshWinner,error){time.Sleep(100*time.Millisecond);return RefreshWinner{},context.DeadlineExceeded}
 req:=WrapperRestoreRequest{Decide:wDecideInput(t,true),Grant:wGrant(t,wFreshValidatedAt),HasGrant:true,Policy:wPolicy(),Restore:wRestoreRequest(t)}
 start:=time.Now();_,_ =fx.lc.ExecuteWrapperRestore(context.Background(),req)
 if elapsed:=time.Since(start);elapsed>50*time.Millisecond {t.Fatalf("configured 1ms refresh blocks %s",elapsed)}
}
func TestReviewRefreshedWinnerMustBindExecutedRestore(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted()); fx.lc.LocalHostID=lxHost
 fx.lc.LeaseRefresh=func(context.Context,string)(RefreshWinner,error){return RefreshWinner{LeaseID:lxLeaseB,Epoch:9,HolderHostID:lxHost},nil}
 input:=wDecideInput(t,true);input.Presented.LeaseID=lxLeaseB;input.Presented.Epoch=9
 recordBinding(t,fx,lxDigestA);fx.runner.queue("new-session","",0)
 out,err:=fx.lc.ExecuteWrapperRestore(context.Background(),WrapperRestoreRequest{Decide:input,Grant:wGrant(t,wFreshValidatedAt),HasGrant:true,Policy:wPolicy(),Restore:wRestoreRequest(t)})
 t.Logf("action=%s cause=%v err=%v effects=%v",out.Decision.Action,out.Decision.Cause,err,fx.runner.subcommands())
 if err==nil && fx.runner.callCount()!=0 {t.Fatalf("winner epoch9 authorizes restore carrying old epoch7: %+v",out.Restore)}
}
