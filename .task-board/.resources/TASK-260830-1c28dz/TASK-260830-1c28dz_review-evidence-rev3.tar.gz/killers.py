import pathlib,subprocess,json,time
p=pathlib.Path(__file__).resolve().parent;r=p/'probes'
plants=json.loads((p/'independent-results.json').read_text())[::2][:4]
plants.append(dict(name='R5-spawn-root',file='probe.go',old='if err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil {',new='if err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil && err.Error() != "tmux_unsafe_socket_path at socket root" {'))
# R5 is an entry-specific narrowing of the shared custody gate; other custody failures stay rejected.
rows=[]
def run(name,mask):
 s=time.monotonic();x=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-run',mask,'-v','-timeout=180s'],cwd=r,capture_output=True,text=True,timeout=220)
 (p/(name+'.log')).write_text(x.stdout+x.stderr);row=dict(name=name,exit=x.returncode,seconds=time.monotonic()-s);rows.append(row);print(json.dumps(row),flush=True)
 return x
# full committed suite twice, R5 only before injecting killers
plant=plants[-1];f=r/'internal/tmuxserver'/plant['file'];raw=f.read_text();assert plant['old'] in raw
try:
 f.write_text(raw.replace(plant['old'],plant['new'],1))
 for n in (1,2):run('R5-spawn-root-'+str(n),'.')
finally:f.write_text(raw)
(r/'internal/tmuxserver/reviewer_killers_unix_test.go').write_bytes((p/'killers_unix_test.go').read_bytes())
run('killers-original','^TestReviewKill')
names=['StatusAttachedExit','StatusForeignRow','StatusUnknownPanes','OSRunnerArgv','SpawnRootCustody']
for plant,test in zip(plants,names):
 f=r/'internal/tmuxserver'/plant['file'];raw=f.read_text();assert plant['old'] in raw
 try:
  f.write_text(raw.replace(plant['old'],plant['new'],1))
  for n in (1,2):run(plant['name']+'-killer-'+str(n),'^TestReviewKill'+test+'$')
 finally:f.write_text(raw)
(p/'killers-results.json').write_text(json.dumps({'plants':plants,'runs':rows},indent=2))
