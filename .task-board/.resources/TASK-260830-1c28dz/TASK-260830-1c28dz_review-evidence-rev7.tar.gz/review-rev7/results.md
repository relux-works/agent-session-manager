# TASK-260830-1c28dz rework rev7 — results (standalone)

Ready for review. This run answers the rev6 CHANGES REQUESTED on
checkpoint `d4bd91d0` (trunk unmoved, no rebase): the P1 and P2-A
close as one invariant with its fact enumeration, P2-B closes
with the composed effect-level witness, and P3 closes with the
reclassification plus a genuinely admitting loop mutant. Every
rev6 closure is retained (B43 handoff, ordering lock, refresh
bound, importer corpus, corrected census). The worktree is
intentionally UNCOMMITTED for the Story handoff snapshot.

Scope of the production delta (all in `internal/tmuxserver`):
`ops.go` (two post-lock attach rechecks plus the boundary
comment). No other production file changed. Touched landed
files: none (the cross-package harness row patches
`terminalbackend/conformance.go` only inside its own run and
restores it; the candidate tree holds no landed diff).

## Finding-by-finding disposition

| # | Verdict finding | Disposition | Witness |
|---|---|---|---|
| P1 | generation admission goes stale while attach waits for its new lock (no generation recheck at the effect boundary) | FIXED — live `CurrentGeneration` recheck under the lock immediately before the receipt commit; same-Lifecycle rotation before lock acquisition now refuses | `TestAttachRefusesGenerationRotatedDuringLockWait` via `Lifecycle.Execute` (channel-ordered rotation, deterministic); narrowing `N-attach-postlock-generation` |
| P2-A | attach commits a new receipt after its operation deadline (deadline checked only before the waits) | FIXED — live clock deadline recheck under the lock; the lock wait counts against the deadline; deadline stays distinct from authorization expiry | `TestAttachRefusesDeadlineExpiredDuringAdmission` (operation expired, authorization valid) + `TestAttachRefusesDeadlineOnTheInstantDuringAdmission` via `Lifecycle.Execute`; narrowing `N-attach-postlock-deadline` |
| P2-B | false-to-true input escalation has no effect-level negative witness (receipt commits before the result binding refuses) | FIXED — composed negative test asserting refusal AND receipt absence; landed gate kept, no fork | `TestAttachAuthorizationMembersRefuseWithoutReceipt` (expiry/input/transport) via `Lifecycle.Execute`; narrowing `N-attach-input-escalation` (reviewer A3 shape, cross-package row) |
| P3 | two reported narrowing rows are positive-path wiring mutations (`N-lifecycle-restore/terminate-authkind`) | FIXED — reclassified as supplementary `D-` wiring rows; entry rows converted to genuine no-bind narrowings; new genuinely admitting shared loop mutant with two-entry killers | `TestExecuteEntryRefusesWrongAuthorizationKind` (terminate/restore no-bind), `TestExecuteTerminate/RestoreRefusesAuthorizationExpiredAfterReceipt`; rows `N-entry-authkind-*`, `N-lifecycle-loop-authorization`, `D-lifecycle-*-authkind` |

## P1+P2-A — one invariant: the effect-boundary fact enumeration

SPEC §4.C line 1095 (pinned `internal/specdoc/SPEC.v0.7.0.md`):
"Authorization and generation are rechecked immediately before
each side effect." plus "A deadline cancels waiting, not a
committed effect." The attach row allows both
`terminal_backend_stale_generation` and
`terminal_backend_timeout`, so the new refusals are in-row
codes. Every authorization fact the attach path carries:

| Fact | First observed | Waits before the effect | Revalidated at the effect boundary |
|---|---|---|---|
| closure (incarnation-scoped proof) | fast-path check (`ops.go` pre-admission) | server admission + barrier-lock wait | YES — recheck under the lock (rev6, kept) |
| server generation | admission + attestation | barrier-lock wait | YES (new) — live `CurrentGeneration` vs request generation under the lock |
| request deadline | entry check | server admission + barrier-lock wait | YES (new) — live clock under the lock; lock wait counts; distinct from expiry |
| authorization expiry | entry `CheckAttachRequest` | server admission + barrier-lock wait | YES — inside the commit call itself (`AttachStore.Attach` rechecks with the live clock; no wait between its check and the no-replace install) |
| transport binding | entry binding + capability arms | same waits | YES — binding arm inside the commit; capability arm is a pure check over request-immutable `Admitted` (no live fact) |
| input binding | entry `CheckAttachRequest` | same waits | YES — inside the commit, plus the post-commit `CheckAttachResult` |
| transition / operation capability / backend identity | entry checks | same waits | N/A — pure checks over request-immutable members; no live fact to go stale |
| attestation value (fresh vs decoy) | admission | barrier-lock wait | value immutable once returned; its live counterpart is the generation recheck |

Residual: a rotation landing between the post-lock recheck and
the commit — inside one process or across processes — is not
excluded; the window holds no waits (file I/O only). That is
the B42 in-process scope, extended to the two new rechecks
(B42 text in TRACEABILITY + matrix; code comment cites it).

The same interval on the other paths: create, quiesce-input,
wait-safe-boundary, and request-stop run through the landed
engine, whose `runEffects` (`internal/terminstance/execute.go`
per-effect deadline, authorization, and generation gates)
rechecks before every effect including the first, after the
receipt bind; terminate-stale and restore run through this
leaf's `runLifecycleEffects` (`ops.go` per-effect deadline,
authorization, and generation gates) with the same shape. No
blocking wait sits between those paths' admission and their
loops (no ServerAdmission, no lock acquisition; the resume
path's status reconcile runs before the loop rechecks), and
status has no side effects so §4.C imposes no recheck on it.
Attach was the only path whose effect lacked a post-wait
revalidation; it now has one. No new bound is stated for the
sibling paths because the per-effect loops already close the
interval by construction.

Narrowing precision, proven rather than asserted: under the
post-lock-deadline plant the strictly-past test still passes
(only the on-the-instant member is admitted); under the
input-escalation plant the expiry and transport members still
pass; under the loop-authorization plant the positive
terminate/restore tests still pass. The entry-deadline row
needed its own repair: the new post-lock arm is textually
identical to the entry arm, so the row's anchor is now
transition-pinned to the entry site and its killer asserts the
admission never ran — without that assertion the plant would
reroute to the post-lock refusal with the same verdict and
survive.

## P2-B — the composed authorization witness

`TestAttachAuthorizationMembersRefuseWithoutReceipt` drives
all three `CheckAttachRequest` members (expiry/input/transport)
through `Execute(attach)` and asserts the landed
`terminal_backend_unauthorized` plus the absence of the durable
receipt, zero argv, and no authorized input. The input member is
the required witness: under `N-attach-input-escalation` the
entry and the store both admit the weakened arm, the receipt
commits, and only the result binding refuses — so the test's
receipt-absence assertion is the kill line, not the error
assertion. Delegated-gate accounting: the input-binding gate is
owned by `terminalbackend` (its owner suite measures the gate
arms, as the verdict's A2/A4 owner kills confirm); this leaf
measures only the composed entry's effect-level consequence
through the cross-package row. No landed production file is
touched by the candidate; no gate is forked.

## P3 — authkind evidence, corrected and recounted

- `D-lifecycle-restore-authkind` /
  `D-lifecycle-terminate-authkind`: reclassified as
  SUPPLEMENTARY POSITIVE-PATH WIRING (notes say so
  explicitly). They prove the loop consults the passed kind;
  they admit no forbidden grant and are not counted as any
  gate's narrowing.
- `N-entry-authkind-terminate` / `N-entry-authkind-restore`:
  converted to genuine narrowings with no-bind negative
  killers (`TestExecuteEntryRefusesWrongAuthorizationKind`).
  A control-kind body refuses at entry with the key unbound;
  under the plant the entry admits it, the receipt binds, and
  only the loop refuses — the no-bind assertion reddens.
- `N-lifecycle-loop-authorization` (new): genuinely admits
  pre-commit authorization failures past the shared per-effect
  recheck — the first effect runs under the lapsed grant —
  while post-commit failures still refuse. Negative
  witnesses on both entries
  (`TestExecuteTerminate/RestoreRefusesAuthorizationExpiredAfterReceipt`,
  authorization valid at entry, lapsed before the first
  effect via the receipt hook, deadline still future):
  refusal before any effect with zero execs on terminate,
  nothing committed on restore. Both kill lines redden under
  the plant (attribution verified per entry from the raw
  log).
- Census symmetry for authkind now reads EXT 2 / EXR 2
  (entry 1 / shared loop 1 each; D-loop wiring supplementary,
  uncounted). Battery recount from actual plant behavior:
  279 narrowing + 5 supplementary (3 additive + 2 wiring) +
  control = 285/285 as expected; 208 second-leaf narrowings.

## Census and ratios

- Gate × entry census: 256 measured of 5248 (50+10+196 M
  across Tables A/B/D; Table C all U); 186 bound; 4806
  unreachable with reasons; 155 named undriven gaps (147 B39 +
  8 named cells; B40/B41/B42/B43 are non-cell bounds). Tables
  B/D and bounds B22-B43 are byte-identical between
  TRACEABILITY and the conformance matrix (mirror check in the
  evidence). The one new measured cell is generation EXA
  (U1→M); deadline and authkind cells extend on already-M
  cells. Every two-sided gate carries its symmetry line
  (generation EXA 1 / EXT 1 / EXR 2; deadline EXA 2 / EXT 1 /
  EXR 2; authkind EXT 2 / EXR 2 as above; attachdeadline EXA 2
  arms).
- AC rows 59-92: 34 of 34 driven through production entries by
  named tests (call sites in the matrix). Row 85 is now
  behaviorally satisfied for attach (the lock wait counts
  against the deadline; operation-expired-yet-authorized
  refuses); row 79 names the post-lock rechecks; rows 82/83
  name the loop/entry authorization witnesses.
- Eight operations, 8 of 8, each through `Lifecycle.Execute`
  (`lifecycle.go`) by a named committed test: create
  (`TestExecuteCreateInteractive`), attach (`TestExecuteAttach`),
  status (`TestExecuteStatusPresent`), quiesce
  (`TestExecuteQuiesce`), safe-boundary (`TestExecuteBoundary`),
  stop (`TestExecuteStop`), stale termination
  (`TestExecuteTerminate`), restore (`TestExecuteRestore`).
- Mutant battery: 285/285 tmuxserver rows as expected (279
  narrowing `N-*` KILLED + 5 supplementary `D-*` KILLED,
  shared control SURVIVED), 40/40 termbind rows as expected;
  one raw log per plant in the tarball (285 tmuxserver logs +
  verbose termbind log). 4 new tmuxserver narrowing rows this
  round, 2 reclassified, 2 converted.
- No-real-tmux: zero real-tmux witnesses by the determinism
  design (bound B1); the suite passes with the tmux binary
  unresolvable (1012 passing test events, zero failures, zero
  skips in the changed packages; no tmux process before, during,
  or after).
- Handovers retained: exec/probe adapters driven (unchanged);
  B18 sun_path, B16 ambient, B19/B20 custody, and the P3-A
  fresh-decoy attestation witnesses all still pass; this leaf
  extends the landed termbind owner for successor minting and
  composes terminalbackend, terminstance, axpane, and fencing
  without forking (no landed production file touched this
  round).

## Validation (all exit 0, this run)

| Gate | Result |
|---|---|
| `go test ./... -count=1` candidate / base | 45 ok / 45 ok, 0 FAILs either tree |
| `go test -race` tmuxserver + termbind | ok, no races |
| `go test ./... -cover` | ok (tmuxserver 88.6%, termbind 83.5%) |
| `go vet ./...` + `GOOS=windows go vet ./...` | clean |
| `gofmt -l` | clean |
| tmuxserver harness 285 + termbind harness 40 | all as expected |
| no-tmux PATH run (changed packages) | green, zero skips, tmux unresolvable |
| closure grid determinism | 6/6 identical streams |
| census recount + matrix mirror check | counts match; tables/bounds byte-identical |
| full configured suite (30 commands) | green firsthand (race gate 419s) |

Composition: outcome grid over the 36-package closure, 198
shared `(package, entry, input)` keys, MOVED 0, base-only 0,
candidate-only 7 (the declared `CheckSocketLength` × 2 and
`ClassifyStatus` × 5 story-added entries — no input moved
across any admission or refusal arm). Suite verdicts: 23,874
shared `(package, test)` keys, zero moved verdicts, zero
base-only, 517 candidate-only additions (512 tmuxserver incl.
subtests — 500 carried + 12 new rev7 nodes — 5 termbind), all
PASS, 0 FAILs.

## Evidence

- `TASK-260830-1c28dz_conformance-matrix.md` (updated, attached):
  AC rows, ops table, mirrored census Tables B/C/D + Table E,
  bounds B22-B43, battery, crash/idempotency.
- `TASK-260830-1c28dz_rework-evidence-rev7.tar.gz` (attached):
  closure grid driver + base/candidate streams + diff,
  per-test verdict streams + diff, full suite logs, 285 + 40
  raw per-plant harness logs, vet/fmt/race/cover/no-tmux
  logs, census recount, mirror check, SHA256SUMS.
- Handoff: ready for review; candidate UNCOMMITTED in the
  Story worktree for snapshot.
