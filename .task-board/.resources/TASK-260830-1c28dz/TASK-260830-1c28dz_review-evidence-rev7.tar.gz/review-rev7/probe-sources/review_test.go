//go:build !windows
package tmuxserver
import ("context"; "testing"; "time")
func TestReviewStopRechecksBeforeEscalation(t *testing.T) {
 for _, fact := range []string{"generation", "authorization", "deadline"} {
 t.Run(fact, func(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 generation := lxGeneration
 fx.lc.CurrentGeneration = func() string {return generation}
 raw := lxStopBody(t, 5, func(o map[string]any) {
 c := o["context"].(map[string]any)
 if fact == "authorization" {c["authorization"].(map[string]any)["expires_at"] = "2026-09-01T12:00:00.003Z"}
 if fact == "deadline" {c["deadline_at"] = "2026-09-01T12:00:00.003Z"}
 })
 fx.runner.queue("send-keys", "", 0).queue("has-session", "", 0).queueFull("has-session", "", "can't find session: "+lxInstance, 1).queue("kill-session", "", 0)
 seen := false
 fx.runner.onRun = func(argv []string) {
 if argv[3] == "has-session" && !seen {seen = true; if fact == "generation" {generation = "generation-two"}; fx.clock.Sleep(10*time.Millisecond)}
 }
 outcome, err := fx.lc.Execute(context.Background(), OpRequest{Operation:"request-stop", Body:raw, Source:"quiescing", Admitted:fullLifecycleAdmitted()})
 for _, command := range fx.runner.subcommands() {if command == "kill-session" {t.Fatalf("kill-session executed after %s changed during poll: err=%v outcome=%+v", fact, err, outcome.Mutation)}}
 })
 }
}
func TestReviewAttachDeadlineCancelsLockWait(t *testing.T) {
 fx := newLifecycleFixture(t, fullLifecycleAdmitted())
 arrived := make(chan struct{},1)
 admission := fx.lc.ServerAdmission
 fx.lc.ServerAdmission = func() (RealmAdmission,error) {a,e:=admission(); arrived<-struct{}{}; return a,e}
 fx.lc.barrierMu.Lock()
 done:=make(chan error,1)
 body:=lxAttachBody(t,nil)
 ctx,cancel:=context.WithCancel(context.Background()); defer cancel()
 go func(){_,err:=fx.lc.Execute(ctx,OpRequest{Operation:"attach",Body:body,Source:"parked",Admitted:fullLifecycleAdmitted()});done<-err}()
 <-arrived
 fx.clock.Sleep(7*time.Hour); cancel()
 select {
 case <-done: fx.lc.barrierMu.Unlock()
 case <-time.After(100*time.Millisecond): fx.lc.barrierMu.Unlock(); <-done; t.Fatal("expired and cancelled attach remained blocked on barrier lock until external unlock")
 }
}
