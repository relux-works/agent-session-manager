//go:build !windows
package tmuxserver
import("context";"testing")
func TestReviewAttachOverlapCapability(t *testing.T){
 for _, writable:=range []bool{false,true}{t.Run(map[bool]string{false:"read-only-no-multi",true:"writable-no-multiple-input"}[writable],func(t *testing.T){
 admitted:=fullLifecycleAdmitted()
 if !writable {caps:=[]string{};for _,c:=range admitted.Capabilities{if c!="multi_attach"{caps=append(caps,c)}};admitted.Capabilities=caps}
 fx:=newLifecycleFixture(t,admitted)
 first:=lxAttachBody(t,func(o map[string]any){o["input_authorized"]=writable;o["authorization"]=lxAttachAuth("local_only",writable)})
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:first,Source:"parked",Admitted:admitted});err!=nil{t.Fatal(err)}
 second:=lxAttachBody(t,func(o map[string]any){o["client_id"]=lxClientB;o["input_authorized"]=writable;o["authorization"]=lxAttachAuth("local_only",writable)})
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:second,Source:"active",Admitted:admitted})
 _,found,e:=fx.lc.Attach.Lookup(lxSession,lxInstance,lxClientB)
 if e!=nil{t.Fatal(e)}
 if err==nil||found{t.Fatalf("overlap admitted without capability: err=%v receipt=%v attach=%+v",err,found,out.Attach)}
 })}
}
