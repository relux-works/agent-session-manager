//go:build !windows
package tmuxserver
import("context";"testing";"time")
func TestReviewAttachWallDeadlineCancelsWait(t *testing.T){
 for _,where:=range []string{"lock","admission"}{t.Run(where,func(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted());fx.lc.Now=time.Now
 now:=time.Now().UTC();deadline:=now.Add(200*time.Millisecond)
 body:=lxAttachBody(t,func(o map[string]any){o["deadline_at"]=formatTimestamp(deadline);a:=lxAttachAuth("local_only",true);a["issued_at"]=formatTimestamp(now.Add(-time.Hour));a["expires_at"]=formatTimestamp(now.Add(time.Hour));o["authorization"]=a})
 entered:=make(chan struct{},1);release:=make(chan struct{});old:=fx.lc.ServerAdmission
 fx.lc.ServerAdmission=func()(RealmAdmission,error){entered<-struct{}{};if where=="admission"{<-release};return old()}
 if where=="lock"{fx.lc.barrierMu.Lock()}
 done:=make(chan error,1);start:=time.Now()
 go func(){_,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:body,Source:"parked",Admitted:fullLifecycleAdmitted()});done<-err}()
 select{case <-entered:case err:=<-done: if where=="lock"{fx.lc.barrierMu.Unlock()};close(release);t.Fatalf("entry did not reach wait: %v",err)}
 timer:=time.NewTimer(time.Until(deadline)+200*time.Millisecond);defer timer.Stop()
 select{
 case err:=<-done:
  if where=="lock"{fx.lc.barrierMu.Unlock()};close(release);if err==nil{t.Fatal("wait returned success")}
 case <-timer.C:
  if where=="lock"{fx.lc.barrierMu.Unlock()};close(release);err:=<-done
  t.Fatalf("%s wait did not terminate at 200ms operation deadline; external release after %s, eventual error=%v",where,time.Since(start),err)
 }
 })}
}
