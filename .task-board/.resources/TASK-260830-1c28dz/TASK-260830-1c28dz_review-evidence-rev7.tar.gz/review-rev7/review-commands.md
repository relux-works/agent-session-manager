# Reviewer command provenance

Root: exact tree a7ffc935ff3c44396734ea1b39cdc1c8acc2651a extracted with git archive. Base d4bd91d0e740285b21b8d65bf6f074c8009b04ae. Archive copies preserve every tracked byte. Mutation/probe writes occur only in copies. Host is darwin/arm64, Go 1.25.5.

- focused.json: go test ./internal/tmuxserver ./internal/termbind -count=1 -json
- all.json: go test ./... -count=1 -json
- cover.log: go test ./... -cover -count=1
- vet.log: go vet ./...
- windows-vet.log: GOOS=windows GOARCH=amd64 go vet ./...
- race.json: go test ./internal/tmuxserver ./internal/termbind -race -count=1 -json (exit 1; timing threshold, not race detector)
- race-timing-rerun.log: go test ./internal/tmuxserver -race -run '^TestWrapperRestoreRefreshBoundEnforced$' -count=5 -v
- no-tmux.json: PATH=go-only-directory:/usr/bin:/bin:/usr/sbin:/sbin go test ./internal/tmuxserver ./internal/termbind -count=1 -json. No stop or kill of any user's tmux.
- effect-probes-unmutated.log: go test ./internal/tmuxserver -run '^(TestReviewStopRechecksBeforeEscalation|TestReviewAttachOverlapCapability)$' -count=2 -race -v
- wait-probes-real.log: go test ./internal/tmuxserver -run '^TestReviewAttachWallDeadlineCancelsWait$' -count=2 -race -v
- custody-baseline.log: go test ./internal/tmuxserver -run '^TestReviewCustodyValidBodies$' -count=2 -v
- shipped harness calls and exits: battery.py/battery2.py and battery-*.log, per-row command/exit in harness1/ and harness2/. PYTHONDONTWRITEBYTECODE=1 throughout.
- termbind-candidate-harness1/2.log: AX_MUTANT_VERBOSE=1 PYTHONDONTWRITEBYTECODE=1 python3 internal/termbind/mutant_harness.py, candidate production restored per row.
- own-battery*.py: four independent entry-specific custody narrowings and a harmless control, two repetitions each. Raw malformed-body reroute kills separated from valid-body actual-effect kills.
- reorder.py: supplemental backend-before-refresh/offer ordering attack; twice, then restore.
- closuregrid source is the already-attached producer fixed corpus, copied unchanged into internal/reviewclosure temporarily on each archive; go run ./internal/reviewclosure on base, go run -tags closuregrid_candidate ./internal/reviewclosure on candidate. Scratch driver removed after use. OUTCOME comparison in closure-diff.json; importer set independently derived from go list imports and test imports.

Setup errors excluded from evidence denominators: initial command tried using a scratch cwd before it existed; another test started before git archive extraction completed and failed setup with missing package; one wait-test heredoc used the wrong relative output path and the accompanying run matched no test. A termbind battery accidentally ran against the base; termbind-harness1.* is base-only and excluded. A subsequent effect probe overlapped a termbind mutation run; final-effect-probes.* is excluded, replaced by the serialized, production-byte-audited effect-probes-unmutated.*. All definitive original-source failures have source probes and two repetitions. No compilation/setup/no-tests exit is counted as a behavioral kill.
