import pathlib,subprocess,json,sys,time,os
r=pathlib.Path(__file__).resolve().parent
names=json.loads((r/'mutant-names.json').read_text())
start,end,repeat=map(int,sys.argv[1:])
out=r/f'harness{repeat}';out.mkdir(exist_ok=True)
cmd=['python3','internal/tmuxserver/mutant_harness.py',*names[start:end],'--log-dir',str(out)]
t=time.time()
with (r/f'battery-{repeat}-{start}.log').open('w') as f:
 p=subprocess.run(cmd,cwd=r/'mutants',stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=540)
print(start,end,repeat,p.returncode,time.time()-t,flush=True)
sys.exit(p.returncode)
