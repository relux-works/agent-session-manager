import pathlib,subprocess,json,time,os
root=pathlib.Path(__file__).resolve().parent
p=root/'attacks/internal/tmuxserver/lifecycle.go'
original=p.read_text()
rows=[]
needle='if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {'
for detail in ['socket root','socket ancestor']:
 for entry in ['Status','Restore']:
  replacement=needle.replace('err != nil {', 'err != nil && !(operation == terminalbackend.Operation'+entry+' && err.Error() == "tmux server refused: tmux_unsafe_socket_path at '+detail+'") {')
  rows.append((detail.replace(' ','-')+'-'+entry,needle,replacement))
for name,needle,replacement in rows:
 assert original.count(needle)==1
 try:
  p.write_text(original.replace(needle,replacement))
  for n in [1,2]:
   r=subprocess.run(['go','test','./internal/tmuxserver','-count=1','-run','^TestReviewCustodyEntryRoots$'],cwd=root/'attacks',capture_output=True,text=True)
   (root/(name+'-probe-'+str(n)+'.log')).write_text('exit='+str(r.returncode)+'\n'+r.stdout+r.stderr)
   print(name,n,r.returncode,flush=True)
 finally:p.write_text(original)
