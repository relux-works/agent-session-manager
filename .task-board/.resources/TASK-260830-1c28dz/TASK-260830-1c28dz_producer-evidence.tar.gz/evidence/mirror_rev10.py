#!/usr/bin/env python3
"""Mirror rev10 TRACEABILITY updates into the conformance matrix.

Splices Table C prose+header, Table D header+peershape+escalationbound,
symmetry rev10 addendum, ratio, AC rows 79/81 (behavior+tests) from
TRACEABILITY; updates the DoD header, battery, and validation counts.
Every splice asserts its match count. Byte-identity of Tables B/D
bodies is verified separately by diffing extracted bodies.
"""
import sys

TRACE = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/internal/tmuxserver/TRACEABILITY.md"
SRC = "/tmp/p2b/matrix-rev9.md"
DST = "/tmp/p2b/matrix-rev10.md"

trace = open(TRACE).read()
mat = open(SRC).read()


def block(text, start, end_exclusive):
    i = text.index(start)
    j = text.index(end_exclusive, i)
    return text[i:j]


def replace_once(text, old, new, tag):
    n = text.count(old)
    assert n == 1, f"{tag}: matched {n}, want 1"
    return text.replace(old, new, 1)


# --- Table C prose + Table D head (TRACEABILITY -> matrix) ---
trace_c = block(trace, "Table C: new gates", "Table D: new gates")
mat_c = block(mat, "Table C: new gates", "Table D: new gates")
mat = replace_once(mat, mat_c, trace_c, "tableC")

trace_d_head = block(trace, "Table D: new gates", "| Gate (site) |")
mat_d_head = block(mat, "Table D: new gates", "| Gate (site) |")
mat = replace_once(mat, mat_d_head, trace_d_head, "tableDhead")


# --- Table D body: replace matrix rows with TRACEABILITY rows ---
def table_body(lines, head_idx):
    rows = []
    i = head_idx + 2
    while lines[i].startswith("| "):
        rows.append(lines[i])
        i += 1
    return rows, i


def heads(lines):
    return [i for i, l in enumerate(lines) if l.startswith("| Gate (site) |")]


t_lines = trace.splitlines()
m_lines = mat.splitlines()
t_heads = heads(t_lines)
m_heads = heads(m_lines)
assert len(t_heads) == 3, f"trace heads {len(t_heads)}"
assert len(m_heads) == 2, f"matrix heads {len(m_heads)}"
# Table D is the last table in both files.
t_rows, t_end = table_body(t_lines, t_heads[2])
m_rows, m_end = table_body(m_lines, m_heads[1])
print(f"trace D rows: {len(t_rows)}, matrix D rows: {len(m_rows)}")
new_m = m_lines[: m_heads[1] + 2] + t_rows + m_lines[m_end:]
mat = "\n".join(new_m) + "\n"


# --- Symmetry + ratio + bound split (TRACEABILITY -> matrix) ---
trace_sym = block(trace, "Symmetry (every gate", "Ratio: 267")
mat_sym = block(mat, "Symmetry (every gate", "Ratio: 266")
mat = replace_once(mat, mat_sym, trace_sym, "symmetry")
trace_ratio = block(trace, "Ratio: 267", "Table E:")
mat_ratio = block(mat, "Ratio: 266", "## Bounds")
mat = replace_once(mat, mat_ratio, trace_ratio, "ratio")


# --- AC rows 79/81 behavior + tests (TRACEABILITY -> matrix) ---
def ac_row(lines, num, want):
    prefix = f"| {num} |"
    hits = [l for l in lines if l.startswith(prefix)]
    assert len(hits) == want, f"AC row {num}: {len(hits)} hits, want {want}"
    assert len(set(hits)) == 1, f"AC row {num}: copies differ"
    return hits[0]


for num in ("79", "81"):
    # Matrix carries both copies of each AC row; TRACEABILITY carries one.
    old, new = ac_row(mat.splitlines(), num, 2), ac_row(trace.splitlines(), num, 1)
    mat = mat.replace(old, new)


# --- DoD header counts ---
mat = replace_once(mat, "216 second-leaf narrowing mutants KILLED net", "218 second-leaf narrowing mutants KILLED net", "dod-narrow")
mat = replace_once(mat, "(296/296 tmuxserver rows and\n42/42 termbind rows as expected)", "(298/298 tmuxserver rows and\n43/43 termbind rows as expected)", "dod-rows")
mat = replace_once(mat, "gate x entry census 266\nmeasured of 5504 with 190 stated bounds and 159 named undriven\ngaps", "gate x entry census 267\nmeasured of 5536 with 191 stated bounds and 160 named undriven\ngaps", "dod-census")

# --- Battery counts ---
mat = replace_once(mat, "internal/tmuxserver/mutant_harness.py`: 296/296 rows as\nexpected (289 narrowing `N-*` KILLED", "internal/tmuxserver/mutant_harness.py`: 298/298 rows as\nexpected (291 narrowing `N-*` KILLED", "battery-tmux")
mat = replace_once(mat, "The second leaf owns 216\nnarrowing rows net (219 added, 3 reclassified)", "The second leaf owns 218\nnarrowing rows net (221 added, 3 reclassified)", "battery-leaf")
mat = replace_once(mat, "internal/termbind/mutant_harness.py`: 42/42 rows as expected\n(40 narrowing plus 1 supplementary plus the control),\nincluding the 4 reboot-successor rows and the 2 peer-census rows.", "internal/termbind/mutant_harness.py`: 43/43 rows as expected\n(41 narrowing plus 1 supplementary plus the control),\nincluding the 4 reboot-successor rows and the 3 peer-census rows.", "battery-termbind")

# --- Validation counts ---
mat = replace_once(mat, "338/338 mutant rows as expected across both harnesses", "341/341 mutant rows as expected across both harnesses", "validation-rows")

open(DST, "w").write(mat)
print("wrote", DST)
