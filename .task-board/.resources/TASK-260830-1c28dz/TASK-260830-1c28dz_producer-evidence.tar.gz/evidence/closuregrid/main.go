// Command closuregrid emits fixed-corpus production-entry outcome records
// for the 36-package composing closure (34 production packages plus the
// two test-only closure members). One JSON object per line:
//
//	{"package":"...","entry":"...","input":"...","outcome":"ok|error",
//	 "code":"...","detail":"..."}
//
//   - outcome "ok": code is empty and detail summarizes the returned
//     value with explicit scalar fields (never map dumps or pointers).
//   - outcome "error": code carries the normalized error string (which
//     embeds the refusal code token) and detail is empty.
//
// The corpus is fixed literals; no clock, no randomness, no network.
// Filesystem probes use a fresh work directory whose path is normalized
// to <tmp> before recording. The same driver runs against the CR base
// and the candidate; the diff key is (package, entry, input) and the
// value is (outcome, code, detail). Three closure members have no
// exported pure callable surface (cloneproject, crashgate,
// sshtransport) and are declared as bounds in the results; their
// behavior stays fenced by the suite-verdict grid.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/axpane"
	"github.com/relux-works/agent-session-manager/internal/canonicaljson"
	"github.com/relux-works/agent-session-manager/internal/cigate"
	"github.com/relux-works/agent-session-manager/internal/cliresult"
	"github.com/relux-works/agent-session-manager/internal/clonebundle"
	"github.com/relux-works/agent-session-manager/internal/clonesnap"
	"github.com/relux-works/agent-session-manager/internal/config"
	"github.com/relux-works/agent-session-manager/internal/dirnode"
	"github.com/relux-works/agent-session-manager/internal/environ"
	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/hostchannel"
	"github.com/relux-works/agent-session-manager/internal/hosttrust"
	"github.com/relux-works/agent-session-manager/internal/localstore"
	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/meshneg"
	"github.com/relux-works/agent-session-manager/internal/peeridentity"
	"github.com/relux-works/agent-session-manager/internal/provhost"
	"github.com/relux-works/agent-session-manager/internal/provider"
	"github.com/relux-works/agent-session-manager/internal/resumesmoke"
	"github.com/relux-works/agent-session-manager/internal/rpcwire"
	"github.com/relux-works/agent-session-manager/internal/secconftest"
	"github.com/relux-works/agent-session-manager/internal/secprim"
	"github.com/relux-works/agent-session-manager/internal/sessadapter"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessprofile"
	"github.com/relux-works/agent-session-manager/internal/sessquery"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/sessstate"
	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/termbind"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/terminstance"
	"github.com/relux-works/agent-session-manager/internal/tmuxserver"
)

type record struct {
	Package string `json:"package"`
	Entry   string `json:"entry"`
	Input   string `json:"input"`
	Outcome string `json:"outcome"`
	Code    string `json:"code"`
	Detail  string `json:"detail"`
}

var workdir string

func normalize(s string) string {
	s = strings.ReplaceAll(s, workdir, "<tmp>")
	s = strings.ReplaceAll(s, os.TempDir(), "<tmp>")
	return s
}

func emit(pkg, entry, input, outcome, code, detail string) {
	raw, err := json.Marshal(record{
		Package: pkg, Entry: entry, Input: input,
		Outcome: outcome, Code: normalize(code), Detail: normalize(detail),
	})
	if err != nil {
		panic(err)
	}
	fmt.Println(string(raw))
}

func emitErr(pkg, entry, input string, err error) {
	if err == nil {
		emit(pkg, entry, input, "ok", "", "nil-error")
		return
	}
	emit(pkg, entry, input, "error", err.Error(), "")
}

func digestOf(data []byte) string {
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:16])
}

func joinSorted(values []string) string {
	out := append([]string(nil), values...)
	sort.Strings(out)
	return strings.Join(out, ",")
}

// --- axerror ---

func gridAxerror() {
	for _, status := range []int{0, 1, 2, 99, 231} {
		meaning, ok := axerror.ExitStatusMeaning(status)
		emit("axerror", "ExitStatusMeaning", fmt.Sprintf("status=%d", status), "ok", "", fmt.Sprintf("%q/%v", meaning, ok))
		emit("axerror", "IsFailureExitStatus", fmt.Sprintf("status=%d", status), "ok", "", fmt.Sprintf("%v", axerror.IsFailureExitStatus(status)))
	}
}

// --- axpane ---

func gridAxpane() {
	emit("axpane", "BindingDigest", "filled", "ok", "", axpane.BindingDigest(axpane.Binding{
		SessionID: "0198f4c8-8e50-7f66-8f70-111111111111", OperationID: "0198f4c8-8e50-7f66-8f70-333333333331",
		TerminalInstanceID: "0198f4c8-8e50-7f66-8f70-222222222221", BindingDigest: "sha256:aaaa",
	}))
	emit("axpane", "BindingDigest", "zero", "ok", "", axpane.BindingDigest(axpane.Binding{}))
	params := axpane.DescriptorParams{
		Binding:     axpane.BindingRef{BindingDigest: "sha256:bbbb", BackendID: "ax.tmux", ImplementationVersion: "2.1.0", ProtocolVersion: "1.1.0", Generation: "generation-one"},
		InstanceID:  "0198f4c8-8e50-7f66-8f70-222222222221",
		Interactive: true, Columns: 80, Rows: 24,
	}
	raw, err := axpane.BuildDescriptor(params)
	if err != nil {
		emitErr("axpane", "BuildDescriptor", "valid", err)
	} else {
		emit("axpane", "BuildDescriptor", "valid", "ok", "", digestOf(raw))
	}
	bad := params
	bad.InstanceID = "not-a-uuid"
	_, err = axpane.BuildDescriptor(bad)
	emitErr("axpane", "BuildDescriptor", "bad-instance", err)
	bad = params
	bad.Binding.BackendID = "bogus backend !!"
	_, err = axpane.BuildDescriptor(bad)
	emitErr("axpane", "BuildDescriptor", "bad-backend", err)
}

// --- canonicaljson ---

func gridCanonicaljson() {
	raw, err := canonicaljson.Canonicalize([]byte(`{"b":2,"a":[3,2,1]}`))
	if err != nil {
		emitErr("canonicaljson", "Canonicalize", "valid", err)
	} else {
		emit("canonicaljson", "Canonicalize", "valid", "ok", "", string(raw))
	}
	_, err = canonicaljson.Canonicalize([]byte(`{"a":`))
	emitErr("canonicaljson", "Canonicalize", "truncated", err)
	_, err = canonicaljson.Canonicalize(nil)
	emitErr("canonicaljson", "Canonicalize", "empty", err)
	emitErr("canonicaljson", "ValidateObservationEvent", "garbage", canonicaljson.ValidateObservationEvent([]byte(`[1,2`)))
	emitErr("canonicaljson", "ValidateObservationEvent", "empty-object", canonicaljson.ValidateObservationEvent([]byte(`{}`)))
	emitErr("canonicaljson", "ValidateObservationStream", "empty", canonicaljson.ValidateObservationStream(nil))
}

// --- cigate ---

func gridCigate() {
	ids, err := cigate.CapabilityIDs()
	if err != nil {
		emitErr("cigate", "CapabilityIDs", "none", err)
	} else {
		emit("cigate", "CapabilityIDs", "none", "ok", "", joinSorted(ids))
	}
	targets, err := cigate.FuzzTargets()
	if err != nil {
		emitErr("cigate", "FuzzTargets", "none", err)
	} else {
		emit("cigate", "FuzzTargets", "none", "ok", "", joinSorted(targets))
	}
	releases, err := cigate.PinnedReleases()
	if err != nil {
		emitErr("cigate", "PinnedReleases", "none", err)
	} else {
		emit("cigate", "PinnedReleases", "none", "ok", "", joinSorted(releases))
	}
	emit("cigate", "SortedReleases", "fixed", "ok", "", strings.Join(cigate.SortedReleases(map[string][]cigate.ContractVersions{
		"b": {{Name: "c", Versions: []string{"1.0"}}},
		"a": {{Name: "c", Versions: []string{"1.0"}}},
	}), ","))
	emitErr("cigate", "VerifyContractPreservation", "none", cigate.VerifyContractPreservation())
}

// --- cliresult ---

func gridCliresult() {
	emit("cliresult", "CapabilityNames", "none", "ok", "", joinSorted(cliresult.CapabilityNames()))
	emit("cliresult", "ContractNames", "none", "ok", "", joinSorted(cliresult.ContractNames()))
	status, err := cliresult.ExitStatus(cliresult.Outcome{})
	if err != nil {
		emitErr("cliresult", "ExitStatus", "zero", err)
	} else {
		emit("cliresult", "ExitStatus", "zero", "ok", "", fmt.Sprintf("%d", status))
	}
	status, err = cliresult.ExitStatus(cliresult.Outcome{Rendered: "done"})
	if err != nil {
		emitErr("cliresult", "ExitStatus", "rendered", err)
	} else {
		emit("cliresult", "ExitStatus", "rendered", "ok", "", fmt.Sprintf("%d", status))
	}
}

// --- clonebundle ---

func gridClonebundle() {
	digestA, err := scalar.ParseDigest("sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
	if err != nil {
		panic(err)
	}
	digestB, err := scalar.ParseDigest("sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
	if err != nil {
		panic(err)
	}
	emitErr("clonebundle", "CheckDigestsEqual", "equal", clonebundle.CheckDigestsEqual(digestA, digestA))
	emitErr("clonebundle", "CheckDigestsEqual", "different", clonebundle.CheckDigestsEqual(digestA, digestB))
	emitErr("clonebundle", "CheckOrdinalContiguity", "contiguous", clonebundle.CheckOrdinalContiguity([]uint64{1, 2, 3}))
	emitErr("clonebundle", "CheckOrdinalContiguity", "gap", clonebundle.CheckOrdinalContiguity([]uint64{1, 3}))
	emitErr("clonebundle", "CheckOrdinalContiguity", "empty", clonebundle.CheckOrdinalContiguity(nil))
	emit("clonebundle", "ValidCaptureClass", "raw", "ok", "", fmt.Sprintf("%v", clonebundle.ValidCaptureClass("raw")))
	emit("clonebundle", "ValidCaptureClass", "bogus", "ok", "", fmt.Sprintf("%v", clonebundle.ValidCaptureClass("bogus!!")))
	emitErr("clonebundle", "SanitizeNativeKey", "ok", clonebundle.SanitizeNativeKey("session-1"))
	emitErr("clonebundle", "SanitizeNativeKey", "empty", clonebundle.SanitizeNativeKey(""))
	emitErr("clonebundle", "SanitizeNativeKey", "slash", clonebundle.SanitizeNativeKey("a/b"))
}

// --- clonesnap ---

func gridClonesnap() {
	_, err := clonesnap.AdmitForTarget([]byte(`{}`), "stable")
	emitErr("clonesnap", "AdmitForTarget", "empty-object", err)
	_, err = clonesnap.AdmitForTarget([]byte(`[`), "stable")
	emitErr("clonesnap", "AdmitForTarget", "truncated", err)
	_, err = clonesnap.AdmitForTarget(nil, "bogus-profile!!")
	emitErr("clonesnap", "AdmitForTarget", "nil-bogus-profile", err)
	digestA, err := scalar.ParseDigest("sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
	if err != nil {
		panic(err)
	}
	digestB, err := scalar.ParseDigest("sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
	if err != nil {
		panic(err)
	}
	raw, err := clonesnap.BuildAdmissionReceipt(digestA, digestB, "stable")
	if err != nil {
		emitErr("clonesnap", "BuildAdmissionReceipt", "stable", err)
	} else {
		emit("clonesnap", "BuildAdmissionReceipt", "stable", "ok", "", digestOf(raw))
	}
	_, err = clonesnap.BuildAdmissionReceipt(digestA, digestB, "")
	emitErr("clonesnap", "BuildAdmissionReceipt", "empty-profile", err)
}

// --- config ---

func gridConfig() {
	raw, err := config.EncodeCurrent(config.Configuration{}, config.DecodeContext{})
	if err != nil {
		emitErr("config", "EncodeCurrent", "zero", err)
	} else {
		emit("config", "EncodeCurrent", "zero", "ok", "", digestOf(raw))
	}
	raw, err = config.EncodeVersion4(config.Configuration{}, config.DecodeContext{})
	if err != nil {
		emitErr("config", "EncodeVersion4", "zero", err)
	} else {
		emit("config", "EncodeVersion4", "zero", "ok", "", digestOf(raw))
	}
}

// --- dirnode ---

func gridDirnode() {
	for _, version := range []string{"1.0", "9.9", "bogus", ""} {
		major, ok := dirnode.MajorForVersion(version)
		emit("dirnode", "MajorForVersion", fmt.Sprintf("version=%q", version), "ok", "", fmt.Sprintf("%d/%v", major, ok))
	}
	for _, major := range []int{3, 1, 0, -1} {
		lower, ok := dirnode.NextLowerMajor(major)
		emit("dirnode", "NextLowerMajor", fmt.Sprintf("major=%d", major), "ok", "", fmt.Sprintf("%d/%v", lower, ok))
	}
	emit("dirnode", "AvailableCapabilities", "zero", "ok", "", joinSorted(dirnode.AvailableCapabilities(dirnode.Manifest{})))
	emitErr("dirnode", "CheckCursorReuse", "fresh", dirnode.CheckCursorReuse("cursor-1", false))
	emitErr("dirnode", "CheckCursorReuse", "reuse-bounds-changed", dirnode.CheckCursorReuse("cursor-1", true))
	emitErr("dirnode", "CheckCursorReuse", "empty", dirnode.CheckCursorReuse("", false))
}

// --- environ ---

func gridEnviron() {
	for _, value := range []string{"production", "bogus env!!", ""} {
		emit("environ", "CheckEnvironmentID", fmt.Sprintf("value=%q", value), "ok", "", fmt.Sprintf("%v", environ.CheckEnvironmentID(value)))
	}
	for _, value := range []string{"1.2.3", "1.2", "bogus"} {
		emit("environ", "CheckSemver", fmt.Sprintf("value=%q", value), "ok", "", fmt.Sprintf("%v", environ.CheckSemver(value)))
	}
	emit("environ", "StringLength", "empty", "ok", "", fmt.Sprintf("%d", environ.StringLength("")))
	emit("environ", "StringLength", "abc", "ok", "", fmt.Sprintf("%d", environ.StringLength("abc")))
	emit("environ", "HasLoneSurrogateEscape", "clean", "ok", "", fmt.Sprintf("%v", environ.HasLoneSurrogateEscape([]byte(`{"a":"b"}`))))
	emit("environ", "HasLoneSurrogateEscape", "lone", "ok", "", fmt.Sprintf("%v", environ.HasLoneSurrogateEscape([]byte(`{"a":"\ud800"}`))))
}

// --- fencing ---

func gridFencing() {
	for _, tc := range []struct {
		name      string
		hasWinner bool
		force     bool
		preserved bool
	}{
		{"no-winner", false, false, false},
		{"winner", true, false, false},
		{"winner-force", true, true, false},
		{"winner-preserved", true, false, true},
	} {
		emitErr("fencing", "AuthorizeTerminateStale", tc.name, fencing.AuthorizeTerminateStale(
			fencing.PresentedToken{}, sessrepo.LeaseSummary{}, tc.hasWinner, tc.force, tc.preserved))
	}
	stale, decided := fencing.StaleRelativeToWinner(fencing.PresentedToken{}, fencing.Observation{})
	emit("fencing", "StaleRelativeToWinner", "zero", "ok", "", fmt.Sprintf("%v/%v", stale, decided))
	emit("fencing", "IsParked", "nil", "ok", "", fmt.Sprintf("%v", fencing.IsParked(nil)))
}

// --- hostchannel ---

func gridHostchannel() {
	argv, err := hostchannel.LaunchArgv(peeridentity.Target{})
	if err != nil {
		emitErr("hostchannel", "LaunchArgv", "zero-target", err)
	} else {
		emit("hostchannel", "LaunchArgv", "zero-target", "ok", "", strings.Join(argv, " "))
	}
	emit("hostchannel", "AuthorityListOverflow", "nil", "ok", "", fmt.Sprintf("%v", hostchannel.AuthorityListOverflow(nil)))
	emit("hostchannel", "AuthorityListOverflow", "one", "ok", "", fmt.Sprintf("%v", hostchannel.AuthorityListOverflow([][]byte{[]byte("a")})))
	line, err := hostchannel.ReadLine(strings.NewReader("hello\nrest"))
	if err != nil {
		emitErr("hostchannel", "ReadLine", "line", err)
	} else {
		emit("hostchannel", "ReadLine", "line", "ok", "", string(line))
	}
	_, err = hostchannel.ReadLine(strings.NewReader(""))
	emitErr("hostchannel", "ReadLine", "empty", err)
}

// --- hosttrust ---

func gridHosttrust() {
	emit("hosttrust", "SHA256HexOf", "fixed", "ok", "", hosttrust.SHA256HexOf([]byte("grid-fixture")))
	for _, relative := range []string{"trust/roots.json", "sessions/data.json", ""} {
		emit("hosttrust", "MatchExcludedFromReplication", fmt.Sprintf("relative=%q", relative), "ok", "", fmt.Sprintf("%v", hosttrust.MatchExcludedFromReplication(relative)))
	}
	for _, base := range []string{"tmp", "trust", ""} {
		emit("hosttrust", "ExcludedConfigDirName", fmt.Sprintf("base=%q", base), "ok", "", fmt.Sprintf("%v", hosttrust.ExcludedConfigDirName(base)))
	}
	emit("hosttrust", "ExcludedFromReplication", "none", "ok", "", joinSorted(hosttrust.ExcludedFromReplication()))
}

// --- localstore ---

func gridLocalstore() {
	zero := scalar.Digest{}
	path, err := localstore.DigestPathV1(zero, localstore.PathStylePOSIX)
	if err != nil {
		emitErr("localstore", "DigestPathV1", "zero-posix", err)
	} else {
		emit("localstore", "DigestPathV1", "zero-posix", "ok", "", path)
	}
	_, err = localstore.DigestPathV1(zero, "bogus-style")
	emitErr("localstore", "DigestPathV1", "zero-bogus-style", err)
}

// --- matjournal ---

func gridMatjournal() {
	for _, tc := range []struct {
		name  string
		facts matjournal.DestinationFacts
	}{
		{"zero", matjournal.DestinationFacts{}},
		{"target-absent", matjournal.DestinationFacts{TargetAbsent: true}},
		{"marker-manifest", matjournal.DestinationFacts{MarkerPresent: true, ManifestMatches: true, FingerprintMatches: true}},
		{"marker-stale", matjournal.DestinationFacts{MarkerPresent: true}},
	} {
		dest, err := matjournal.ClassifyDestination(tc.facts)
		if err != nil {
			emitErr("matjournal", "ClassifyDestination", tc.name, err)
		} else {
			emit("matjournal", "ClassifyDestination", tc.name, "ok", "", dest)
		}
	}
}

// --- meshneg ---

func gridMeshneg() {
	selected, err := meshneg.Select([]int{1, 2, 3}, []int{2, 3, 4})
	if err != nil {
		emitErr("meshneg", "Select", "overlap", err)
	} else {
		emit("meshneg", "Select", "overlap", "ok", "", fmt.Sprintf("%d", selected))
	}
	_, err = meshneg.Select([]int{1}, []int{2})
	emitErr("meshneg", "Select", "disjoint", err)
	_, err = meshneg.Select(nil, nil)
	emitErr("meshneg", "Select", "empty", err)
	majors, err := meshneg.LocalMajors("4.2.0")
	if err != nil {
		emitErr("meshneg", "LocalMajors", "valid", err)
	} else {
		emit("meshneg", "LocalMajors", "valid", "ok", "", fmt.Sprintf("%v", majors))
	}
	_, err = meshneg.LocalMajors("bogus")
	emitErr("meshneg", "LocalMajors", "bogus", err)
	offer, err := meshneg.PeerOffer("1.0", rpcwire.Hello{})
	if err != nil {
		emitErr("meshneg", "PeerOffer", "zero", err)
	} else {
		emit("meshneg", "PeerOffer", "zero", "ok", "", fmt.Sprintf("%d", offer))
	}
}

// --- peeridentity (zero Target: degenerate but deterministic) ---

func gridPeeridentity() {
	var target peeridentity.Target
	emit("peeridentity", "String", "zero", "ok", "", target.String())
	emit("peeridentity", "GoString", "zero", "ok", "", target.GoString())
	emit("peeridentity", "KeyProvenance", "zero", "ok", "", target.KeyProvenance())
	emitErr("peeridentity", "CheckProtocolHost", "zero", target.CheckProtocolHost("host-1"))
	argv, err := target.RPCArgv()
	if err != nil {
		emitErr("peeridentity", "RPCArgv", "zero", err)
	} else {
		emit("peeridentity", "RPCArgv", "zero", "ok", "", strings.Join(argv, " "))
	}
}

// --- provhost ---

func gridProvhost() {
	emit("provhost", "Capabilities", "none", "ok", "", joinSorted(provhost.Capabilities()))
	emit("provhost", "CapabilityUsable", "ready-true", "ok", "", fmt.Sprintf("%v", provhost.CapabilityUsable("ready", true)))
	emit("provhost", "CapabilityUsable", "ready-false", "ok", "", fmt.Sprintf("%v", provhost.CapabilityUsable("ready", false)))
	emit("provhost", "CapabilityUsable", "bogus-true", "ok", "", fmt.Sprintf("%v", provhost.CapabilityUsable("bogus", true)))
	emitErr("provhost", "CheckResumeTuple", "zero", provhost.CheckResumeTuple(provhost.BuildTuple{}))
	emitErr("provhost", "DecodeProbe", "empty-object", provhost.DecodeProbe([]byte(`{}`)))
	emitErr("provhost", "DecodeProbe", "truncated", provhost.DecodeProbe([]byte(`[`)))
	emitErr("provhost", "DecodeManifest", "empty-object", provhost.DecodeManifest([]byte(`{}`)))
}

// --- provider ---

type gridSystem struct{ err error }

func (s gridSystem) ReadDir(string) ([]string, error) { return nil, s.err }
func (s gridSystem) Canonicalize(string) (string, error) {
	return "", s.err
}
func (s gridSystem) Inspect(string) (provider.FileInfo, error) {
	return provider.FileInfo{}, s.err
}
func (s gridSystem) ReadFile(string) ([]byte, error) { return nil, s.err }
func (s gridSystem) PathDirs() []string              { return []string{"/fixed/bin"} }

func gridProvider() {
	emit("provider", "Builtins", "none", "ok", "", joinSorted(provider.Builtins()))
	lifted, err := provider.Lift(provider.Error{})
	if err != nil {
		emitErr("provider", "Lift", "zero", err)
	} else if lifted == nil {
		emit("provider", "Lift", "zero", "ok", "", "nil")
	} else {
		emit("provider", "Lift", "zero", "ok", "", normalize(lifted.Error()))
	}
	stub := gridSystem{err: errors.New("grid: no filesystem")}
	emitErr("provider", "Verify", "zero", provider.Verify(provider.TrustRecord{}, provider.OwnerPolicy{}, stub))
}

// --- resumesmoke ---

func gridResumesmoke() {
	// Refusal arms only: a valid record needs the sealed digest
	// frame (fixture-heavy), and the missing-member loop iterates
	// a map, so these inputs fail deterministically before it.
	_, err := resumesmoke.Store(workdir, []byte(`[1,2]`), nil)
	emitErr("resumesmoke", "Store", "array-record", err)
	_, err = resumesmoke.Store(workdir, []byte(`0`), nil)
	emitErr("resumesmoke", "Store", "scalar-record", err)
}

// --- rpcwire ---

func gridRpcwire() {
	raw, err := rpcwire.EncodeRequest("1.0", "req-1", "status", []byte(`{}`))
	if err != nil {
		emitErr("rpcwire", "EncodeRequest", "valid", err)
	} else {
		emit("rpcwire", "EncodeRequest", "valid", "ok", "", digestOf(raw))
	}
	_, err = rpcwire.EncodeRequest("bogus", "req-1", "status", []byte(`{}`))
	emitErr("rpcwire", "EncodeRequest", "bogus-version", err)
	namespaces, err := rpcwire.Namespaces("1.0")
	if err != nil {
		emitErr("rpcwire", "Namespaces", "valid", err)
	} else {
		emit("rpcwire", "Namespaces", "valid", "ok", "", joinSorted(namespaces))
	}
	_, err = rpcwire.Namespaces("bogus")
	emitErr("rpcwire", "Namespaces", "bogus", err)
	profile, err := rpcwire.ContractProfile("1.0")
	if err != nil {
		emitErr("rpcwire", "ContractProfile", "valid", err)
	} else {
		keys := make([]string, 0, len(profile))
		for key := range profile {
			keys = append(keys, key)
		}
		emit("rpcwire", "ContractProfile", "valid", "ok", "", joinSorted(keys))
	}
}

// --- secconftest ---

func gridSecconftest() {
	emit("secconftest", "Members", "bogus", "ok", "", joinSorted(secconftest.Members("bogus-id")))
	runes := secconftest.BidiRunes()
	emit("secconftest", "BidiRunes", "none", "ok", "", fmt.Sprintf("%d:%x", len(runes), []rune(runes)))
	emit("secconftest", "SortedNames", "nil", "ok", "", joinSorted(secconftest.SortedNames(nil)))
	emit("secconftest", "Digest", "nil", "ok", "", secconftest.Digest(nil))
	emit("secconftest", "SkippedIDs", "none", "ok", "", joinSorted(secconftest.SkippedIDs()))
}

// --- secprim ---

func gridSecprim() {
	for _, name := range []string{"AX_HOME", "1bogus", ""} {
		emit("secprim", "IsEnvName", fmt.Sprintf("name=%q", name), "ok", "", fmt.Sprintf("%v", secprim.IsEnvName(name)))
	}
	emitErr("secprim", "CheckArgv", "valid", secprim.CheckArgv([]string{"tmux", "new-session"}))
	emitErr("secprim", "CheckArgv", "empty", secprim.CheckArgv(nil))
	emitErr("secprim", "CheckArgv", "nul", secprim.CheckArgv([]string{"tmux\x00"}))
	emit("secprim", "EscapeForTerminal", "fixed", "ok", "", secprim.EscapeForTerminal("a\x1bb"))
	emit("secprim", "Redact", "fixed", "ok", "", secprim.Redact("token=secret-value", []string{"secret-value"}))
	emit("secprim", "Redact", "no-secrets", "ok", "", secprim.Redact("token=secret-value", nil))
	first, ok := secprim.DetectCaseCollision([]string{"Session"}, "session")
	emit("secprim", "DetectCaseCollision", "collision", "ok", "", fmt.Sprintf("%q/%v", first, ok))
	first, ok = secprim.DetectCaseCollision([]string{"Session"}, "other")
	emit("secprim", "DetectCaseCollision", "clean", "ok", "", fmt.Sprintf("%q/%v", first, ok))
}

// --- sessadapter ---

func gridSessadapter() {
	emitErr("sessadapter", "CheckBindingEquality", "zero-zero", sessadapter.CheckBindingEquality(sessadapter.ExecutionBinding{}, sessadapter.ExecutionBinding{}))
	emitErr("sessadapter", "CheckFreshSink", "zero-empty", sessadapter.CheckFreshSink(sessadapter.ObjectAuthority{}, true))
	emitErr("sessadapter", "CheckFreshSink", "zero-full", sessadapter.CheckFreshSink(sessadapter.ObjectAuthority{}, false))
	emit("sessadapter", "Capabilities", "none", "ok", "", joinSorted(sessadapter.Capabilities()))
	emit("sessadapter", "CapabilityUsable", "zero", "ok", "", fmt.Sprintf("%v", sessadapter.CapabilityUsable(sessadapter.Probe{}, "doctor")))
}

// --- sessckpt ---

func gridSessckpt() {
	dir := filepath.Join(workdir, "sessckpt")
	if err := os.MkdirAll(dir, 0o755); err != nil {
		panic(err)
	}
	store, err := sessckpt.Open(dir)
	if err != nil {
		emitErr("sessckpt", "Open", "fresh-dir", err)
		return
	}
	emit("sessckpt", "Open", "fresh-dir", "ok", "", "opened")
	_, err = store.Get("bogus-checkpoint")
	emitErr("sessckpt", "Get", "missing", err)
	_, err = sessckpt.Open(filepath.Join(workdir, "no-such-dir", "deep"))
	emitErr("sessckpt", "Open", "missing-dir", err)
}

// --- sessprofile ---

func gridSessprofile() {
	emitErr("sessprofile", "CheckLaunchPair", "zero-zero", sessprofile.CheckLaunchPair(sessprofile.Pair{}, sessprofile.Pair{}))
	for _, flag := range []string{"", "stable", "bogus!!"} {
		profile, err := sessprofile.ResolveCreationProfile(flag)
		if err != nil {
			emitErr("sessprofile", "ResolveCreationProfile", fmt.Sprintf("flag=%q", flag), err)
		} else {
			emit("sessprofile", "ResolveCreationProfile", fmt.Sprintf("flag=%q", flag), "ok", "", profile)
		}
	}
	emit("sessprofile", "ForkProjection", "zero", "ok", "", sessprofile.ForkProjection(sessprofile.Pair{}))
}

// --- sessquery ---

func gridSessquery() {
	for _, action := range []string{"attach", "bogus!!", ""} {
		boundaries, ok := sessquery.BoundariesFor(action)
		emit("sessquery", "BoundariesFor", fmt.Sprintf("action=%q", action), "ok", "", fmt.Sprintf("%v/%s", ok, joinSorted(boundaries)))
	}
}

// --- sessrepo ---

func gridSessrepo() {
	emit("sessrepo", "CompareLeaseTuple", "zero-zero", "ok", "", fmt.Sprintf("%d", sessrepo.CompareLeaseTuple(sessrepo.LeaseSummary{}, sessrepo.LeaseSummary{})))
	_, _, err := sessrepo.AttestLeaseRecord([]byte(`{}`))
	emitErr("sessrepo", "AttestLeaseRecord", "empty-object", err)
	_, _, err = sessrepo.AttestLeaseRecord([]byte(`[`))
	emitErr("sessrepo", "AttestLeaseRecord", "truncated", err)
	_, _, err = sessrepo.AttestCheckpointRecord([]byte(`{}`))
	emitErr("sessrepo", "AttestCheckpointRecord", "empty-object", err)
}

// --- sessstate ---

func gridSessstate() {
	emit("sessstate", "States", "none", "ok", "", joinSorted(sessstate.States()))
	emit("sessstate", "Compare", "zero-zero", "ok", "", fmt.Sprintf("%d", sessstate.Compare(sessstate.LeaseHead{}, sessstate.LeaseHead{})))
}

// --- termbind ---

func gridTermbind() {
	emitErr("termbind", "CheckInstanceIdentity", "valid", termbind.CheckInstanceIdentity("0198f4c8-8e50-7f66-8f70-222222222221"))
	emitErr("termbind", "CheckInstanceIdentity", "empty", termbind.CheckInstanceIdentity(""))
	emitErr("termbind", "CheckInstanceIdentity", "garbage", termbind.CheckInstanceIdentity("bogus!!"))
	_, err := termbind.AdmitMutationContext([]byte(`{}`))
	emitErr("termbind", "AdmitMutationContext", "empty-object", err)
	_, err = termbind.AdmitMutationContext([]byte(`[`))
	emitErr("termbind", "AdmitMutationContext", "truncated", err)
	_, err = termbind.AdmitStatusBody([]byte(`{}`))
	emitErr("termbind", "AdmitStatusBody", "empty-object", err)
	_, err = termbind.AdmitStatusBody([]byte(`[`))
	emitErr("termbind", "AdmitStatusBody", "truncated", err)
}

// --- terminalbackend ---

func gridTerminalbackend() {
	for _, tc := range []struct {
		name        string
		operation   string
		source      string
		interactive bool
	}{
		{"create-absent", "create", "absent", true},
		{"attach-parked", "attach", "parked", false},
		{"quiesce-active", "quiesce-input", "active", false},
		{"stop-quiescing", "request-stop", "quiescing", false},
		{"restore-stopped", "restore", "stopped", false},
		{"bogus-op", "bogus!!", "parked", false},
		{"attach-creating", "attach", "creating", false},
	} {
		after, effects, err := terminalbackend.CheckTransition(tc.operation, tc.source, tc.interactive)
		if err != nil {
			emitErr("terminalbackend", "CheckTransition", tc.name, err)
		} else {
			emit("terminalbackend", "CheckTransition", tc.name, "ok", "", fmt.Sprintf("%s/%d", after, len(effects)))
		}
	}
	key, err := terminalbackend.IdempotencyKey("create", "session-1", "bootstrap-1")
	if err != nil {
		emitErr("terminalbackend", "IdempotencyKey", "valid", err)
	} else {
		emit("terminalbackend", "IdempotencyKey", "valid", "ok", "", key)
	}
	_, err = terminalbackend.IdempotencyKey("create")
	emitErr("terminalbackend", "IdempotencyKey", "no-segments", err)
	emitErr("terminalbackend", "CheckOperation", "known", terminalbackend.CheckOperation("attach", terminalbackend.Admitted{Capabilities: []string{"local_attach"}}))
	emitErr("terminalbackend", "CheckOperation", "bogus", terminalbackend.CheckOperation("bogus!!", terminalbackend.Admitted{}))
	digest, err := terminalbackend.GenerationDigest("generation-one")
	if err != nil {
		emitErr("terminalbackend", "GenerationDigest", "valid", err)
	} else {
		emit("terminalbackend", "GenerationDigest", "valid", "ok", "", digest)
	}
	_, err = terminalbackend.GenerationDigest("")
	emitErr("terminalbackend", "GenerationDigest", "empty", err)
}

// --- terminstance ---

func gridTerminstance() {
	for _, tc := range []struct {
		name      string
		operation terminalbackend.Operation
		source    terminalbackend.InstanceState
	}{
		{"create-absent", terminalbackend.OperationCreate, terminalbackend.StateAbsent},
		{"quiesce-active", terminalbackend.OperationQuiesceInput, terminalbackend.StateActive},
		{"stop-quiescing", terminalbackend.OperationRequestStop, terminalbackend.StateQuiescing},
	} {
		emit("terminstance", "InterimState", tc.name, "ok", "", string(terminstance.InterimState(tc.operation, tc.source)))
	}
	emit("terminstance", "ErrorCode", "nil", "ok", "", terminstance.ErrorCode(nil))
	segments, err := terminstance.KeySegments(terminalbackend.OperationCreate, terminstance.MutationContext{}, terminstance.Params{})
	if err != nil {
		emitErr("terminstance", "KeySegments", "zero", err)
	} else {
		emit("terminstance", "KeySegments", "zero", "ok", "", segments)
	}
	emitErr("terminstance", "CheckResult", "zero", terminstance.CheckResult(terminstance.MutationContext{}, terminalbackend.StateParked, terminstance.Result{}))
}

// --- tmuxserver (pre-existing entries only; must exist on the base) ---

func gridTmuxserver() {
	emit("tmuxserver", "SocketPath", "fixed", "ok", "", tmuxserver.SocketPath("/tmp/ax-grid"))
	for _, tc := range []struct {
		name                                    string
		runtimeDir, socket, sessionID           string
	}{
		{"valid", "/tmp/ax-grid", "/tmp/ax-grid/ax.sock", "session-1"},
		{"empty-session", "/tmp/ax-grid", "/tmp/ax-grid/ax.sock", ""},
		{"empty-socket", "/tmp/ax-grid", "", "session-1"},
	} {
		argv, err := tmuxserver.BuildArgv(tc.runtimeDir, tc.socket, tc.sessionID)
		if err != nil {
			emitErr("tmuxserver", "BuildArgv", tc.name, err)
		} else {
			emit("tmuxserver", "BuildArgv", tc.name, "ok", "", strings.Join(argv, " "))
		}
	}
	socket, err := tmuxserver.ResolveSocket("/tmp/ax-grid", "", tmuxserver.Ambient{})
	if err != nil {
		emitErr("tmuxserver", "ResolveSocket", "conventional", err)
	} else {
		emit("tmuxserver", "ResolveSocket", "conventional", "ok", "", socket)
	}
	_, err = tmuxserver.ResolveSocket("/tmp/ax-grid", "", tmuxserver.Ambient{TMUXEnv: "/tmp/ambient.sock"})
	emitErr("tmuxserver", "ResolveSocket", "ambient", err)
	gridTmuxserverExtra()
}

func main() {
	var err error
	workdir, err = os.MkdirTemp("", "closuregrid")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(workdir)
	gridAxerror()
	gridAxpane()
	gridCanonicaljson()
	gridCigate()
	gridCliresult()
	gridClonebundle()
	gridClonesnap()
	gridConfig()
	gridDirnode()
	gridEnviron()
	gridFencing()
	gridHostchannel()
	gridHosttrust()
	gridLocalstore()
	gridMatjournal()
	gridMeshneg()
	gridPeeridentity()
	gridProvhost()
	gridProvider()
	gridResumesmoke()
	gridRpcwire()
	gridSecconftest()
	gridSecprim()
	gridSessadapter()
	gridSessckpt()
	gridSessprofile()
	gridSessquery()
	gridSessrepo()
	gridSessstate()
	gridTermbind()
	gridTerminalbackend()
	gridTerminstance()
	gridTmuxserver()
}
