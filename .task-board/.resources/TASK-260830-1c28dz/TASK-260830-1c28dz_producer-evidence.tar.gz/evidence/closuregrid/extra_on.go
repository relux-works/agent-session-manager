//go:build closuregrid_candidate

package main

import (
	"fmt"
	"os"
	"strings"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/termbind"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/tmuxserver"
)

// gridTmuxserverExtra probes tmuxserver entries that exist only on the
// candidate (story-added after the CR base). The base run builds
// without the closuregrid_candidate tag and emits none of these
// records; the diff names them as declared candidate-only keys.
//
// Revision 10 extends the revision-5 set (CheckSocketLength,
// ClassifyStatus) with the leaf's operation-to-directive table
// (DirectivesFor: 8 admitted operations plus manifest, probe, and
// bogus refusals) and the leaf-added peer census on the landed
// attach store (Peers: empty-store admission plus the three
// identity refusals). The termbind census probes live here rather
// than in gridTermbind so main.go stays byte-identical to the
// revision-5 driver on both runs.
func gridTmuxserverExtra() {
	emitErr("tmuxserver", "CheckSocketLength", "short", tmuxserver.CheckSocketLength("/tmp/ax.sock", scalar.PlatformMacOS))
	emitErr("tmuxserver", "CheckSocketLength", "long", tmuxserver.CheckSocketLength("/tmp/"+strings.Repeat("s", 200)+".sock", scalar.PlatformMacOS))
	for _, tc := range []struct {
		name  string
		input tmuxserver.ClassifyInput
	}{
		{"live-tri", tmuxserver.ClassifyInput{Present: true, Attached: 1, AttachCapable: true}},
		{"parked", tmuxserver.ClassifyInput{Present: true, Attached: 0, AttachCapable: true}},
		{"quiescing-memory", tmuxserver.ClassifyInput{Present: true, Attached: 0, Memory: terminalbackend.StateQuiescing, MemoryFound: true, AttachCapable: true}},
		{"absent", tmuxserver.ClassifyInput{}},
		{"negative", tmuxserver.ClassifyInput{Present: true, Attached: -1, AttachCapable: true}},
	} {
		state, live, provider, foreign := tmuxserver.ClassifyStatus(tc.input)
		emit("tmuxserver", "ClassifyStatus", tc.name, "ok", "", fmt.Sprintf("%s/%v/%v/%v", state, live, provider, foreign))
	}
	for _, tc := range []struct {
		name      string
		operation terminalbackend.Operation
	}{
		{"create", terminalbackend.OperationCreate},
		{"attach", terminalbackend.OperationAttach},
		{"status", terminalbackend.OperationStatus},
		{"quiesce-input", terminalbackend.OperationQuiesceInput},
		{"wait-safe-boundary", terminalbackend.OperationWaitSafeBoundary},
		{"request-stop", terminalbackend.OperationRequestStop},
		{"terminate-stale", terminalbackend.OperationTerminateStale},
		{"restore", terminalbackend.OperationRestore},
		{"manifest", terminalbackend.OperationManifest},
		{"probe", terminalbackend.OperationProbe},
		{"bogus", terminalbackend.Operation("bogus!!")},
	} {
		directives, err := tmuxserver.DirectivesFor(tc.operation)
		if err != nil {
			emitErr("tmuxserver", "DirectivesFor", tc.name, err)
			continue
		}
		members := make([]string, 0, len(directives))
		for _, directive := range directives {
			members = append(members, string(directive))
		}
		emit("tmuxserver", "DirectivesFor", tc.name, "ok", "", strings.Join(members, " "))
	}
	gridTermbindPeersExtra()
}

// gridTermbindPeersExtra probes the leaf-added Peers census over a
// fresh attach store: an unrecorded instance admits the empty
// census, and each malformed identity refuses. Receipt-bearing
// shapes are witnessed by the committed attach tests, not this
// fixed corpus.
func gridTermbindPeersExtra() {
	storeDir, err := os.MkdirTemp("", "closuregrid-peers")
	if err != nil {
		panic(err)
	}
	defer os.RemoveAll(storeDir)
	store, err := termbind.OpenAttachStore(storeDir)
	if err != nil {
		panic(err)
	}
	session := "0198f4c8-8e50-7f66-8f70-111111111111"
	instance := "0198f4c8-8e50-7f66-8f70-222222222221"
	client := "0198f4c8-8e50-7f66-8f70-555555555551"
	peers, err := store.Peers(session, instance, client)
	if err != nil {
		emitErr("termbind", "Peers", "empty-store", err)
	} else {
		emit("termbind", "Peers", "empty-store", "ok", "", fmt.Sprintf("%d", len(peers)))
	}
	_, err = store.Peers("bogus", instance, client)
	emitErr("termbind", "Peers", "bad-session", err)
	_, err = store.Peers(session, "bogus", client)
	emitErr("termbind", "Peers", "bad-instance", err)
	_, err = store.Peers(session, instance, "bogus")
	emitErr("termbind", "Peers", "bad-client", err)
}
