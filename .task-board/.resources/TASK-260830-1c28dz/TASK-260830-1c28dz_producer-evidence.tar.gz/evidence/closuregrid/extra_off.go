//go:build !closuregrid_candidate

package main

// gridTmuxserverExtra is empty on the CR base: the story-added
// tmuxserver entries do not exist there.
func gridTmuxserverExtra() {}
