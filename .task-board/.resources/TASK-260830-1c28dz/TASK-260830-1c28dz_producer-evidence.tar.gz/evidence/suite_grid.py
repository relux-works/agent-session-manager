#!/usr/bin/env python3
"""Outcome-keyed suite comparison: base vs candidate `go test -json`.

Keys each (package, test) to its verdict (pass/fail/skip), groups by
verdict class, and reports shared-retained / moved (with direction) /
base-only / candidate-only. Any moved test is a candidate regression
or admission/refusal-arm crossing and must be named and explained.
"""
import json
import sys

BASE = "/tmp/p2b/ev10/base-suite.json"
CAND = "/tmp/p2b/ev10/candidate-suite.json"


def grid(path):
    verdicts = {}
    with open(path) as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if event.get("Action") not in ("pass", "fail", "skip"):
                continue
            test = event.get("Test", "")
            package = event.get("Package", "")
            if not test or "/" in test:
                # Top-level tests only; subtests roll into their parent.
                if "/" in test:
                    continue
                if not test:
                    continue
            key = (package, test)
            # Final verdict wins (run/pass/fail sequence per test).
            verdicts[key] = event["Action"]
    return verdicts


def main():
    base = grid(BASE)
    cand = grid(CAND)
    shared = set(base) & set(cand)
    moved = sorted(k for k in shared if base[k] != cand[k])
    base_only = sorted(set(base) - set(cand))
    cand_only = sorted(set(cand) - set(base))
    shared_same = len(shared) - len(moved)
    print(f"shared keys: {len(shared)}; retained: {shared_same}; moved: {len(moved)}")
    print(f"base-only: {len(base_only)}; candidate-only: {len(cand_only)}")
    base_fail = sorted(k for k, v in base.items() if v == "fail")
    cand_fail = sorted(k for k, v in cand.items() if v == "fail")
    print(f"base fails: {len(base_fail)}; candidate fails: {len(cand_fail)}")
    for key in moved:
        print(f"MOVED {key[0]} {key[1]}: {base[key]} -> {cand[key]}")
    for key in base_fail:
        print(f"BASE-FAIL {key[0]} {key[1]}")
    for key in cand_fail:
        print(f"CAND-FAIL {key[0]} {key[1]}")
    for key in base_only[:20]:
        print(f"BASE-ONLY {key[0]} {key[1]}: {base[key]}")
    if len(base_only) > 20:
        print(f"... and {len(base_only) - 20} more base-only")
    print(f"candidate-only additions: {len(cand_only)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
