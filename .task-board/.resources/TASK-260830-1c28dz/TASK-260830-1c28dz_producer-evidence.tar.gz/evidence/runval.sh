#!/bin/bash
# Runs validation commands START..END (1-based) from commands.txt in the worktree.
cd /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree || exit 99
START=$1; END=$2; LOG=/tmp/p2b/ev10/validation.log
i=0
while IFS= read -r cmd; do
  i=$((i+1))
  if [ $i -lt $START ] || [ $i -gt $END ]; then continue; fi
  echo "=== command $i/30: $cmd" | tee -a $LOG
  start=$(date +%s)
  bash -c "$cmd" >> $LOG 2>&1
  code=$?
  end=$(date +%s)
  echo "=== command $i exit: $code elapsed: $((end-start))s" | tee -a $LOG
done < /tmp/p2b/commands.txt
