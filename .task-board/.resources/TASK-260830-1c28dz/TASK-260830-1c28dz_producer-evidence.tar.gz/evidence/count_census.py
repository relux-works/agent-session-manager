import re, sys
path = sys.argv[1]
lines = open(path).read().splitlines()
def classify(cell):
    c = cell.strip()
    if c == 'M' or c.startswith('M '): return 'M'
    if c == 'B' or c.startswith('B ') or re.match('^B[0-9]', c): return 'B'
    if c.startswith('U'): return 'U'
    return '?'
heads = [i for i,l in enumerate(lines) if l.startswith('| Gate (site) |')]
names = ["A", "B", "D"] if len(heads) == 3 else ["B", "D"]
for idx, h in enumerate(heads):
    rows = []
    for l in lines[h+2:]:
        if not l.startswith('| '): break
        rows.append(l)
    m=b=u=q=0; bad=[]
    for r in rows:
        parts = r.split('|')
        data = parts[2:-1]
        want = 11 if names[idx] == "A" else 21
        if len(data) != want:
            bad.append((r.split('|')[1][:50], len(data)))
        for c in data:
            k = classify(c)
            if k=='M': m+=1
            elif k=='B': b+=1
            elif k=='U': u+=1
            else: q+=1; bad.append(('Q:'+c[:60], 0))
    ncol = 11 if names[idx] == "A" else 21
    print("Table %s: rows=%d cells=%d M=%d B=%d U=%d ?=%d bad=%d" % (names[idx], len(rows), len(rows)*ncol, m, b, u, q, len(bad)))
    for x in bad[:8]: print("  BAD:", x)
