import pathlib,subprocess,os,time,json,runpy,sys,tarfile
r=pathlib.Path(__file__).resolve().parent;rep=int(sys.argv[1]);root=r/f'mutants{rep}'
if not root.exists():
 root.mkdir()
 with tarfile.open(r/'candidate.tar') as t:
  t.extractall(root,members=[m for m in t.getmembers() if not m.name.startswith('.task-board/')],filter='data')
for pkg in ['tmuxserver','termbind']:
 h=root/'internal'/pkg/'mutant_harness.py';rows=runpy.run_path(str(h))['MUTANTS']
 for chunk in range(0,len(rows),40):
  selected=rows[chunk:chunk+40];name=f'harness-{pkg}-{rep}-{chunk}';logs=r/name;logs.mkdir(exist_ok=True);start=time.time()
  cmd=[sys.executable,str(h),*[m.name for m in selected]]
  if pkg=='tmuxserver':cmd+=['--log-dir',str(logs)]
  with open(r/(name+'.log'),'w') as f:
   p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',AX_MUTANT_VERBOSE='1'),timeout=540)
  record=dict(name=name,exit=p.returncode,rows=len(selected),elapsed=time.time()-start,load=os.getloadavg())
  with open(r/'harness-runs.jsonl','a') as f:f.write(json.dumps(record)+'\n')
  print(record,flush=True)
