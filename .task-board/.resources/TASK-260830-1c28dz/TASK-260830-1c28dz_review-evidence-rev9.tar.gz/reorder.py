import pathlib,subprocess,difflib
r=pathlib.Path(__file__).resolve().parent;p=r/'own/internal/tmuxserver/wrapper.go';s=p.read_text();anchor='\tlocal := lc.CurrentLease()\n';assert s.count(anchor)==1
m=s.replace(anchor,'\t// Reviewer ordering attack: backend restore admission before winner refresh/offer.\n\tif _, err := lc.Execute(ctx, req.Restore); err != nil { return empty, err }\n'+anchor)
(r/'restore-reorder.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),m.splitlines(True),fromfile='a/internal/tmuxserver/wrapper.go',tofile='b/internal/tmuxserver/wrapper.go')))
try:
 p.write_text(m)
 for n in [1,2]:
  cmd=['go','test','./internal/tmuxserver','-run','^TestWrapperRestoreLapsedGrantRemoteOffer$','-count=1','-v'];q=subprocess.run(cmd,cwd=r/'own',capture_output=True,text=True,timeout=120)
  (r/f'restore-reorder-{n}.log').write_text(f'command: {cmd}\nexit: {q.returncode}\n'+q.stdout+q.stderr);print(n,q.returncode)
finally:p.write_text(s)
