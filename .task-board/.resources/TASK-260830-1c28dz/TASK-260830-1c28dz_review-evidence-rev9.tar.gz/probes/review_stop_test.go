//go:build !windows
package tmuxserver
import("context";"testing";"time";"github.com/relux-works/agent-session-manager/internal/terminalbackend")
type reviewContextRunner struct { inner Runner }
func (r reviewContextRunner) Run(ctx context.Context, argv []string)(RunResult,error){
 if err:=ctx.Err();err!=nil{return RunResult{},err}
 return r.inner.Run(ctx,argv)
}
func TestReviewStopEscalationWithContextHonoringRunner(t *testing.T) {
	fx := newLifecycleFixture(t, fullLifecycleAdmitted())
	fx.runner.queue("send-keys", "", 0).queue("has-session", "", 0).
		queue("kill-session", "", 0).
		queueFull("has-session", "", "can't find session: "+lxInstance, 1)
	fx.lc.Runner = reviewContextRunner{fx.runner}
	seen := false
	fx.runner.onRun = func(argv []string) {
		if len(argv) >= 4 && argv[3] == "has-session" && !seen {
			seen = true
			fx.clock.Sleep(10 * time.Millisecond)
		}
	}
	outcome, err := fx.lc.Execute(context.Background(), OpRequest{
		Operation: "request-stop", Body: lxStopBody(t, 5, nil), Source: "quiescing", Admitted: fullLifecycleAdmitted(),
	})
	t.Logf("calls=%v outcome=%+v now=%v", fx.runner.subcommands(), outcome.Mutation, fx.lc.Now())
	if err != nil {
		t.Fatal(err)
	}
	if got := fx.runner.subcommands(); len(got) != 4 || got[0] != "send-keys" || got[1] != "has-session" || got[2] != "kill-session" || got[3] != "has-session" {
		t.Fatalf("calls = %v, want the graceful poll, one escalation, and the re-confirm", got)
	}
	if outcome.Mutation.After != terminalbackend.StateStopped {
		t.Fatalf("after = %s", outcome.Mutation.After)
	}
}
