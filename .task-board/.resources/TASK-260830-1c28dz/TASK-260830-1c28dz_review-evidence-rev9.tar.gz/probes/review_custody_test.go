//go:build !windows
package tmuxserver
import("context";"os";"testing")
func TestReviewCustodyValidBodies(t *testing.T){
 for _,op:=range []string{"quiesce-input","wait-safe-boundary","request-stop","terminate-stale"}{t.Run(op,func(t *testing.T){
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 req:=OpRequest{Operation:op,Admitted:fullLifecycleAdmitted()}
 switch op {
 case "quiesce-input":req.Body=lxQuiesceBody(t,nil);req.Source="active";fx.runner.queue("lock-session","",0).queue("detach-client","",0)
 case "wait-safe-boundary":req.Body=lxBoundaryBody(t,"ax_checkpoint_boundary",60000,nil);req.Source="quiescing";fx.runner.queue("wait-for","",0)
 case "request-stop":req.Body=lxStopBody(t,60000,nil);req.Source="quiescing";fx.runner.queue("send-keys","",0).queueFull("has-session","","can't find session: "+lxInstance,1)
 case "terminate-stale":req.Body=lxTerminateBody(t,nil);req.Source="stale_fenced";req.Presented,req.Winner=terminateFencing();req.HasWinner=true;req.ForceRecovery=true;req.DiagnosticsPreserved=true;fx.runner.queue("kill-session","",0).queueFull("has-session","","can't find session: "+lxInstance,1)
 }
 if err:=os.Chmod(fx.root,0777);err!=nil{t.Fatal(err)}
 out,err:=fx.lc.Execute(context.Background(),req)
 if err==nil||fx.runner.callCount()!=0{t.Fatalf("unsafe custody reached effects: err=%v calls=%v outcome=%+v",err,fx.runner.subcommands(),out)}
 requireLocalCode(t,err,"tmux_unsafe_socket_path","socket root")
 })}
}
