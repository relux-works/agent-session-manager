//go:build !windows

package tmuxserver

import (
 "context"
 "os"
 "path/filepath"
 "testing"
)

// A valid receipt for the incoming client stored at another client's
// receipt path is corrupt identity evidence, not an empty peer census.
func TestReviewAttachPeerFilenameMismatchFailsClosed(t *testing.T) {
 fx:=newLifecycleFixture(t,fullLifecycleAdmitted())
 body:=lxAttachBody(t,func(o map[string]any){o["client_id"]=lxClientB})
 if _,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:body,Source:"parked",Admitted:fullLifecycleAdmitted()});err!=nil{t.Fatal(err)}
 dir:=filepath.Join(fx.data,"attachstore","termbind","attach",lxInstance)
 if err:=os.Rename(filepath.Join(dir,lxClientB+".json"),filepath.Join(dir,lxClient+".json"));err!=nil{t.Fatal(err)}
 out,err:=fx.lc.Execute(context.Background(),OpRequest{Operation:"attach",Body:body,Source:"active",Admitted:withoutCapability("multi_attach")})
 _,found,readErr:=fx.lc.Attach.Lookup(lxSession,lxInstance,lxClientB)
 if err==nil||found||out.Attach!=nil||len(out.Argv)!=0{t.Fatalf("corrupt receipt namespace admitted: err=%v newReceipt=%v lookupErr=%v attach=%+v argv=%v",err,found,readErr,out.Attach,out.Argv)}
}
