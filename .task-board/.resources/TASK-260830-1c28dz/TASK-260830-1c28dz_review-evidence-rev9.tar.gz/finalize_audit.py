import pathlib,subprocess,json,re,runpy,hashlib,collections
r=pathlib.Path(__file__).resolve().parent
summary={}
for rep in [1,2]:
 summary[rep]={}
 for pkg in ['tmuxserver','termbind']:
  expected={m.name:m.expect for m in runpy.run_path(str(r/f'mutants{rep}/internal/{pkg}/mutant_harness.py'))['MUTANTS']}
  seen={};problems=[]
  for f in r.glob(f'harness-{pkg}-{rep}-*.log'):
   for line in f.read_text().splitlines():
    m=re.match(r'(ok|MISMATCH): ([^:]+): (KILLED|SURVIVED)',line)
    if m:seen[m[2]]=dict(mark=m[1],verdict=m[3])
    if line.startswith('ERROR:'):problems.append(line)
  missing=sorted(set(expected)-set(seen));assert not missing,(rep,pkg,missing)
  assert not problems,(rep,pkg,problems)
  assert all(v['mark']=='ok' and v['verdict']==expected[n] for n,v in seen.items())
  summary[rep][pkg]={'count':len(seen),'counts':dict(collections.Counter(v['verdict'] for v in seen.values())),'verdicts':seen}
(r/'mutation-summary.json').write_text(json.dumps(summary,indent=2))
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','ddae5b7781152de3ffa737879f970129694d8fea','internal','README.md','LOGBOOK.md','go.mod','go.sum','task-board.config.json'],text=True).splitlines()
a={}
for name in ['own','mutants1','mutants2']:
 a[name]=[p for p in paths if (r/name/p).read_bytes()!=(r/'candidate'/p).read_bytes()]
assert not any(a.values()),a
(r/'restoration-audit.json').write_text(json.dumps(a,indent=2))
cache={name:[str(p.relative_to(r/name)) for p in (r/name).rglob('*') if p.name=='__pycache__' or p.suffix=='.pyc'] for name in ['candidate','own','mutants1','mutants2']}
assert not any(cache.values()),cache
(r/'cache-audit.json').write_text(json.dumps(cache,indent=2))
print({n:{p:(x['count'],x['counts']) for p,x in v.items()} for n,v in summary.items()})
print('restored',a,'cache',cache)
