import pathlib,json,hashlib,tarfile,shutil
r=pathlib.Path(__file__).resolve().parent
summary=json.load(open(r/'mutation-summary.json'));counts={}
for rep,pkgs in summary.items():
 counts[rep]={key:sum(v['counts'].get(key,0) for v in pkgs.values()) for key in ['KILLED','SURVIVED']}
assert all(v==dict(KILLED=335,SURVIVED=3) for v in counts.values()),counts
v=r/'TASK-260830-1c28dz_review-verdict-rev9.md'
s=v.read_text().replace('FINAL_VALIDATION_PLACEHOLDER','''Firsthand on the exact candidate tree:

- Full `go test ./... -count=1 -json`: exit 0, 254.56s; all 261 named AC witnesses pass, 14 pre-existing skips outside the changed packages. No failing package.
- Restricted-PATH changed-package suite: exit 0, 35.36s, 1058 pass events, zero skips/failures. `tmux` lookup is absent; before/after `pgrep -x tmux` both return exit 1 with empty stdout/stderr. No acceptance row claims a real-tmux witness.
- Changed-package race suite: exit 0, 48.77s. The two adversarial production probes separately fail twice under race with assertion failures, no race diagnostic.
- Native vet: exit 0, 6.92s; `GOOS=windows GOARCH=amd64 go vet ./...`: exit 0, 27.00s. Gofmt produces no paths.
- Repository coverage: exit 0, 227.66s; tmuxserver 89.0%, termbind 83.3%. Host load is captured alongside every timed suite in `checks.jsonl` and `harness-runs.jsonl`; concurrent host work drove observed load as high as 164.23, and no timing failure was dismissed as load.
- The config contains 30 validation commands. The exact CR9 handoff attachment reports `required=30 green=30 failed=0 missing=0`, with actual command exits. Accepted as existing handoff evidence; this reviewer did not rerun every fuzz target, cross-build or the full-repository race command. The separate Windows vet above includes test files.
- Shipped harnesses: **296/296 tmuxserver and 42/42 termbind expected verdicts per pass, twice; 676 total verdicts**. Each pass has 335 KILLED and three expected SURVIVED (both harmless controls and the shadowed supplementary attach row). Names reconcile against the exact harness lists, with no missing, ERROR or MISMATCH row. Per-plant logs include subprocess exits; termbind verbose logs retain each raw block. Each Go killer is bounded at 300s and the harness is partitioned into at most 40-row subprocess shards with 540s bounds. Source restoration and zero Python cache artifacts were independently checked after both passes.
- The first two integrity-probe launch attempts ran before the disposable copy finished extracting and returned setup failure (`directory not found`). They are preserved as `integrity-{1,2}.log` and are not counted as behavioral evidence. All findings use the subsequent compiled, completed, restored-source race runs.

The current producer archive's 640 manifest entries all match. The exact CR patch and downloaded resources have digests recorded in `resource-digests.json`. Independent full-importer outcome coverage remains unverified as explained in P2-B; neither a green suite nor the 28 identical inputs is represented as a substitute.''')
assert 'PLACEHOLDER' not in s;v.write_text(s)
# Keep the supplied current corpus and its scripts inspectable without
# repackaging the large prior/producer archives as new measurements.
d=r/'producer-corpus';d.mkdir(exist_ok=True)
for name in ['outcome_driver_main.go','suite_grid.py']:
 p=r/'producer/evidence'/name
 if p.exists():shutil.copyfile(p,d/name)
excluded={'candidate','base','own','mutants1','mutants2','prior','producer','path-bin','readback'}
files=[p for p in r.rglob('*') if p.is_file() and not any(x in excluded for x in p.relative_to(r).parts) and not p.name.endswith(('.tar','.tar.gz')) and p.name!='review-MANIFEST.json']
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
mp=r/'review-MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2));files.append(mp)
out=r/'TASK-260830-1c28dz_review-evidence-rev9.tar.gz'
with tarfile.open(out,'w:gz') as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(r)),recursive=False)
print('archive',out,'bytes',out.stat().st_size,'sha256',hashlib.sha256(out.read_bytes()).hexdigest(),'files',len(files))
