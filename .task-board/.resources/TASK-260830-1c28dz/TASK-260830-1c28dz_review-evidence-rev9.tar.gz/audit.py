import pathlib,subprocess,json,re,hashlib
r=pathlib.Path(__file__).resolve().parent;c=r/'candidate';base='d4bd91d0e740285b21b8d65bf6f074c8009b04ae';tree='ddae5b7781152de3ffa737879f970129694d8fea'
def git(*a):return subprocess.check_output(['git',*a])
paths=git('diff','--name-only',base,tree).decode().splitlines()
a={'base':base,'tree':tree,'head':git('rev-parse','HEAD').decode().strip(),'changed_count':len(paths),'config_equal':git('show',base+':task-board.config.json')==git('show',tree+':task-board.config.json'),'registry_delta':[p for p in paths if p.startswith('internal/traceability/')],'live_candidate_mismatches':[p for p in paths if pathlib.Path(p).read_bytes()!=(c/p).read_bytes()],'worktree_behind_main':git('rev-list','--count','HEAD..main').decode().strip()}
p=subprocess.run(['git','ls-remote','origin','refs/heads/main'],capture_output=True,text=True);a['remote_main']={'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
overlap=set(git('diff','--name-only',base,'origin/main').decode().splitlines())&set(git('ls-tree','-r','--name-only',tree).decode().splitlines())
a['main_overlap']={p:('base-retained' if git('show',base+':'+p)==git('show',tree+':'+p) else 'leaf-edit' if p in paths else 'other') for p in sorted(overlap)}
a['pycache']=git('ls-tree','-r','--name-only',tree).decode().splitlines();a['pycache']=[p for p in a['pycache'] if '__pycache__' in p or p.endswith('.pyc')]
(r/'tree-audit.json').write_text(json.dumps(a,indent=2));print(a)
text=(c/'internal/tmuxserver/TRACEABILITY.md').read_text();tables=[]
lines=text.splitlines()
for i,l in enumerate(lines):
 if l.startswith('| Gate (site) |'):
  counts={'M':0,'B':0,'U':0};rows=[]
  for row in lines[i+2:]:
   if not row.startswith('|'):break
   cells=[s.strip() for s in row.split('|')[2:-1]];rows.append(cells)
   for cell in cells:counts[cell[0]]+=1
  tables.append(dict(rows=len(rows),cols=len(rows[0]),counts=counts))
ac={}
for l in (r/'TASK-260830-1c28dz_conformance-matrix.md').read_text().splitlines():
 m=re.match(r'\| (\d+) \|',l)
 if m and 59<=int(m[1])<=92:
  fields=l.split('|');ac[m[1]]={'callsite':fields[3].strip(),'tests':re.findall(r'\bTest\w+',fields[4])}
(r/'census-ac.json').write_text(json.dumps(dict(tables=tables,ac=ac),indent=2));print(tables,len(ac))
