import pathlib,subprocess,os,time,difflib
r=pathlib.Path(__file__).resolve().parent
root=r/'own'; target=root/'internal/tmuxserver/lifecycle.go'; original=target.read_text()
anchor='if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {'
assert original.count(anchor)==1
out=r/'own-battery';out.mkdir(exist_ok=True)
for op in ['quiesce-input','wait-safe-boundary','request-stop','terminate-stale','control']:
 replacement=anchor[:-1]+' // harmless reviewer control\n{' if op=='control' else f'if err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil && string(operation) != "{op}" {{'
 if op=='control': replacement=anchor+' // harmless reviewer control'
 mutated=original.replace(anchor,replacement)
 (out/(op+'.patch')).write_text(''.join(difflib.unified_diff(original.splitlines(True),mutated.splitlines(True),fromfile='a/internal/tmuxserver/lifecycle.go',tofile='b/internal/tmuxserver/lifecycle.go')))
 try:
  target.write_text(mutated)
  for n in [1,2]:
   cmd=['go','test','./internal/tmuxserver','-run','^(TestExecuteEachOperationRefusesWritableRoot|TestReviewCustodyValidBodies)$','-count=1','-v']
   t=time.time();p=subprocess.run(cmd,cwd=root,capture_output=True,text=True,timeout=120)
   (out/f'{op}-{n}.log').write_text(f'command: {cmd}\nexit: {p.returncode}\nelapsed: {time.time()-t}\n'+p.stdout+p.stderr)
   print(op,n,p.returncode,flush=True)
 finally: target.write_text(original)
