package main

// Outcome-grid driver for the rev9 composition check. Drives a fixed
// (package, entry, input) key set over LANDED packages only, so the
// same driver compiles and runs on the base tree and the candidate
// tree. Each line is "key => outcome"; the grids are diffed
// line-by-line. Run with `go run ./tmpoutcomegrid`, then REMOVE the
// directory before running the suite (a stray main package trips the
// specdoc no-product-command gate).

import (
	"errors"
	"fmt"
	"os"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/terminstance"
	"github.com/relux-works/agent-session-manager/internal/termbind"
)

func fail(err error) {
	fmt.Fprintln(os.Stderr, "driver error:", err)
	os.Exit(1)
}

func code(err error) string {
	if err == nil {
		return "ok"
	}
	var backendErr *terminalbackend.Error
	if errors.As(err, &backendErr) {
		return "err:" + backendErr.Code
	}
	var instanceErr *terminstance.Error
	if errors.As(err, &instanceErr) {
		return "err:" + instanceErr.Code
	}
	return "err:untyped:" + err.Error()
}

func main() {
	lines := []string{}
	emit := func(key, outcome string) {
		lines = append(lines, key+" => "+outcome)
	}

	stamp, err := scalar.ParseTimestamp("2026-09-01T12:00:00.000Z")
	if err != nil {
		fail(err)
	}
	instant, err := stamp.Time()
	if err != nil {
		emit("scalar.valid-time", code(err))
	} else {
		emit("scalar.valid-time", "ok "+instant.UTC().Format("2006-01-02T15:04:05.999Z07:00"))
	}
	_, err = scalar.ParseTimestamp("not-a-time")
	emit("scalar.garbage", code(err))
	_, err = scalar.ParseTimestamp("")
	emit("scalar.empty", code(err))
	_, err = scalar.ParseTimestamp("2026-13-01T00:00:00Z")
	emit("scalar.bad-month", code(err))

	ops := []string{"create", "attach", "status", "quiesce-input", "wait-safe-boundary", "request-stop", "terminate-stale", "restore"}
	for _, op := range ops {
		caps, err := terminalbackend.CapabilitiesForOperation(op)
		if err != nil {
			emit("op."+op+".derived", code(err))
		} else {
			emit("op."+op+".derived", code(terminalbackend.CheckOperation(op, terminalbackend.Admitted{Capabilities: caps})))
		}
		emit("op."+op+".empty", code(terminalbackend.CheckOperation(op, terminalbackend.Admitted{})))
	}
	_, err = terminalbackend.CapabilitiesForOperation("bogus-operation")
	emit("op.bogus.derived", code(err))

	emit("errmap.attach.mismatch", code(terminalbackend.CheckErrorAllowed("attach", "idempotency_mismatch")))
	emit("errmap.attach.bogus", code(terminalbackend.CheckErrorAllowed("attach", "bogus_code")))
	emit("errmap.status.unavailable", code(terminalbackend.CheckErrorAllowed("status", "terminal_backend_unavailable")))
	emit("errmap.status.mismatch", code(terminalbackend.CheckErrorAllowed("status", "idempotency_mismatch")))

	emit("identity.v7", code(termbind.CheckInstanceIdentity("0198f4c8-8e50-7f66-8f70-1234567890ab")))
	emit("identity.pid", code(termbind.CheckInstanceIdentity("pid")))
	emit("identity.empty", code(termbind.CheckInstanceIdentity("")))

	for _, line := range lines {
		fmt.Println(line)
	}
}
