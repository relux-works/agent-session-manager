#!/usr/bin/env python3
"""Isolated kill attribution for the shared narrowing rows (rev9 P2-D).

For each shared plant, applies the plant once and runs every claimed
killer test ALONE (anchored -run), expecting FAIL, plus every claimed
green companion ALONE, expecting PASS. Two rounds. Raw logs per
(round, plant, test) under /tmp/c28dz/isolated/.
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, '/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-1c28dz/review9/own/internal/tmuxserver')
import mutant_harness as H  # noqa: E402

REPO = Path(__file__).resolve().parents[0]  # unused; H.REPO rules
OUT = Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-1c28dz/review9/isolated')

STOP = "TestExecuteStopRefusesStaleFactsAfterPoll"
QUIESCE = "TestExecuteQuiesceRefusesStaleFactsBetweenCommands"
PLAN = {
    "N-stop-escalation-generation": ([STOP, QUIESCE], []),
    "N-stop-escalation-expiry": ([STOP, QUIESCE], []),
    "N-stop-escalation-deadline": ([STOP, QUIESCE], []),
    "N-attach-wait-deadline": (
        [
            "TestAttachWaitBoundedByOperationDeadline",
            "TestQuiesceBarrierWaitBoundedByOperationDeadline",
            "TestBoundaryCommitWaitBoundedByOperationDeadline",
        ],
        ["TestAttachWaitCancelledReturnsPromptly"],
    ),
    "N-probe-deadline": (
        [
            "TestExecuteStopPollHonorsOperationDeadline",
            "TestExecuteTerminateConfirmHonorsOperationDeadline",
            "TestExecuteStatusProbeHonorsOperationDeadline",
        ],
        [],
    ),
}

MUTANTS = {m.name: m for m in H.MUTANTS}


def run_single(test, log_path):
    run = subprocess.run(
        ["go", "test", "./internal/tmuxserver/", "-run", f"^{test}$",
         "-count=1", "-v"],
        cwd=H.REPO,
        capture_output=True,
        text=True,
        timeout=180,
    )
    output = (run.stdout + run.stderr).strip()
    log_path.write_text(
        f"exit: {run.returncode}\nrun: go test ./internal/tmuxserver/ -run ^{test}$ -count=1 -v\n\n{output}\n"
    )
    return run.returncode, output


def main():
    failures = 0
    for rnd in (1, 2):
        for name, (killers, greens) in PLAN.items():
            mutant = MUTANTS[name]
            target = H.REPO / mutant.path
            original = target.read_text()
            found = original.count(mutant.find)
            if found != mutant.count:
                print(f"ERROR: {name}: patch anchors {found}, want {mutant.count}")
                failures += 1
                continue
            target.write_text(original.replace(mutant.find, mutant.replace))
            try:
                for test in killers:
                    log = OUT / f"round{rnd}" / f"{name}.{test}.log"
                    log.parent.mkdir(parents=True, exist_ok=True)
                    code, output = run_single(test, log)
                    killed = code != 0 and ("--- FAIL" in output or "FAIL:" in output)
                    print(f"{'ok' if killed else 'MISMATCH'}: round{rnd} {name} :: {test} alone -> {'KILLED' if killed else 'NOT-KILLED'} [exit {code}]")
                    if not killed:
                        failures += 1
                for test in greens:
                    log = OUT / f"round{rnd}" / f"{name}.{test}.log"
                    log.parent.mkdir(parents=True, exist_ok=True)
                    code, output = run_single(test, log)
                    green = code == 0
                    print(f"{'ok' if green else 'MISMATCH'}: round{rnd} {name} :: {test} alone -> {'GREEN' if green else 'RED'} [exit {code}]")
                    if not green:
                        failures += 1
            finally:
                target.write_text(original)
    # restoration audit
    print(f"failures: {failures}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
