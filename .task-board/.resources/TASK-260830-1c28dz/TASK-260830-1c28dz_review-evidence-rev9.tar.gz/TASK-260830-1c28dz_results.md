# TASK-260830-1c28dz rev9 results — implement-tmux-lifecycle-operations

Revision 9 closes all five verdict-rev8 findings: one P1 fail-open
boundary (peer-census directory skip), three P2 behavior gaps (stop
poll in-flight bound, same-client replay with a peer present, kill
attribution), and the evidence-freshness process failure. The
candidate is UNCOMMITTED in the Story worktree against checkpoint
`d4bd91d0`.

## 1. Finding dispositions

| Finding | Severity | Disposition | Evidence |
|---|---|---|---|
| P1 receipt-namespace directory skipped | P1 | FIXED: `Peers` skips only staging (`attach-*`) and non-receipt names; a directory at a receipt-shaped name errors, and the attach refuses with no receipt, no argv, no authorized input | `TestAttachPeerDirectoryFailsClosed` (entry, two legs) + `TestAttachStorePeersDirectoryFailsClosed` (census); narrowings `N-attach-peers-dir-skip` (tmuxserver, cross-package plant) and `N-attach-peers-dir` (termbind), both KILLED |
| P2-A stop poll waits past the deadline | P2 | FIXED: one shared `probeContext` bounds the stop poll, the terminate-stale self-confirm, and the status live probes in-flight; expiry concludes unknown, never a verdict | `TestExecuteStopPollHonorsOperationDeadline`, `TestExecuteTerminateConfirmHonorsOperationDeadline`, `TestExecuteStatusProbeHonorsOperationDeadline` (release-controlled, refusal-before-release); shared narrowing `N-probe-deadline` KILLED through each entry alone; runner audit in §2 |
| P2-B same-client replay refused with a peer present | P2 | FIXED: a Lookup-proven recorded receipt exempts the identical retry (replay, or `idempotency_mismatch` when transport/input changed); a client with no recorded receipt still gates | `TestAttachSameClientRetryWithPeerPresent` (input + read-only + conflict legs); narrowing `N-attach-overlap-replay-unproven` KILLED |
| P2-C stale evidence archive | P2 | FIXED: the rev9 archive is built from the frozen rev9 tree, attached by absolute path, read back, and digest-verified | `TASK-260830-1c28dz_producer-evidence-rev9.tar.gz`, sha256 recorded in §9 and verified after attach |
| P2-D overstated kill attribution | P2 | FIXED: fixtures drive the admitted class (30-min-past expiry, on-deadline instant leg, 6.5h advance with release-controlled barrier); every shared plant kills through every claimed killer ALONE, twice | Isolated logs `isolated/round{1,2}/<plant>.<test>.log` in the tarball; per-test table in §4 |

## 2. Runner-wait audit (P2-A)

Every `Runner.Run` call site in the leaf, dispositioned through the
same shared contract (a read-only wait/probe carries a
deadline-derived context; expiry concludes unknown, never a
verdict):

| Site | Class | Disposition |
|---|---|---|
| `backend.go` `pollSession` has-session (stop pre/post poll, terminate tail) | read-only poll | BOUNDED by the graceful/op deadline via `probeContext`; answered probes follow the clock exactly, only never-answered probes conclude by the context. Test + shared row (§1) |
| `backend.go` `terminateStale` confirm has-session | read-only probe | BOUNDED by the op deadline via `probeContext`; expiry maps to the existing unknown arm. Test + shared row (§1) |
| `status.go` `ObserveStatus` list-panes / list-sessions | read-only probes | BOUNDED by the query deadline via `probeContext`; expiry surfaces the existing uncoded-unknown mapping, never absent. Test + shared row (§1) |
| `backend.go` `observeBoundary` wait-for | blocking wait | Already bounded (wait context); unchanged |
| `boundaryProviderRows` list-panes | read-only probe | Already bounded (runs under the wait context); unchanged |
| `ServerAdmission` / barrier acquire | blocking waits | Already bounded (uniform wait contract, rev8); unchanged |
| `UnixDialer` dial | blocking dial | Already bounded (1s timeout); unchanged |
| `closeInput` lock/detach, `execEvidence` send-keys/new-session, escalation kill, terminate kill | single-shot commits | Caller-cancellation-bounded; stated bound B45 (mid-commit cancellation cannot un-commit; the landed engine passes its context through to commits and checks the deadline between effects; this leaf mirrors that contract; a hung commit hangs, never mis-verdicts). Owner: this leaf for the audit; `internal/terminstance` for any engine-wide change |
| `ServerSpawner.Spawn` (bind step, `context.Background`) | commit on the acquire path | Caller-cancellation does not reach it (the landed `Dependencies.Spawn` signature takes no context); stated bound B45 with the interface change owned by TASK-260830-35urbp. Hang-only, never a wrong verdict |

## 3. New tests and narrowings

Production call sites: `Peers` (`internal/termbind/overlap.go`),
`checkAttachOverlap` (`internal/tmuxserver/ops.go`),
`probeContext` + `pollSession` + `terminateStale`
(`internal/tmuxserver/backend.go`), `ObserveStatus`
(`internal/tmuxserver/status.go`).

| Test (all through `Lifecycle.Execute` unless noted) | Finding | Narrowing | Verdict |
|---|---|---|---|
| `TestAttachPeerDirectoryFailsClosed` (refuse-dir + still-skipped legs) | P1 | `N-attach-peers-dir-skip` | KILLED |
| `TestAttachStorePeersDirectoryFailsClosed` (termbind census direct) | P1 | `N-attach-peers-dir` | KILLED |
| `TestExecuteStopPollHonorsOperationDeadline` | P2-A | `N-probe-deadline` (shared) | KILLED alone |
| `TestExecuteTerminateConfirmHonorsOperationDeadline` | P2-A | `N-probe-deadline` (shared) | KILLED alone |
| `TestExecuteStatusProbeHonorsOperationDeadline` | P2-A | `N-probe-deadline` (shared) | KILLED alone |
| `TestAttachSameClientRetryWithPeerPresent` (input + readonly + conflict) | P2-B | `N-attach-overlap-replay-unproven` | KILLED |
| `TestExecuteQuiesceRefusesStaleFactsBetweenCommands` (repaired: 13:30 expiry + deadline-instant leg) | P2-D | `N-stop-escalation-expiry`, `N-stop-escalation-deadline` | KILLED alone (each) |
| `TestBoundaryCommitWaitBoundedByOperationDeadline` (repaired: 6.5h + release) | P2-D | `N-attach-wait-deadline` | KILLED alone |

No `tmux` process anywhere in any test (fake runners + a
context-honoring blocking runner); zero real-tmux witnesses by the
determinism design (bound B1, carried).

## 4. Isolated kill attribution (P2-D)

Each shared plant applied once, each claimed killer run ALONE
(anchored `-run`), two rounds. Raw logs:
`isolated/round{1,2}/<plant>.<test>.log`.

| Plant | Killer alone | Round 1 | Round 2 | Precision in the same run |
|---|---|---|---|---|
| `N-stop-escalation-generation` | stop stale-facts | KILLED | KILLED | other-fact subtests green |
| `N-stop-escalation-generation` | quiesce stale-facts | KILLED | KILLED | other-fact subtests green |
| `N-stop-escalation-expiry` | stop stale-facts | KILLED | KILLED | other-fact subtests green |
| `N-stop-escalation-expiry` | quiesce stale-facts | KILLED | KILLED | authorization subtest reddens, generation/deadline green |
| `N-stop-escalation-deadline` | stop stale-facts | KILLED | KILLED | deadline-instant reddens, strictly-past green |
| `N-stop-escalation-deadline` | quiesce stale-facts | KILLED | KILLED | deadline-instant reddens, strictly-past green |
| `N-attach-wait-deadline` | attach wait | KILLED | KILLED | admission + barrier subtests both redden |
| `N-attach-wait-deadline` | quiesce-span wait | KILLED | KILLED | single test |
| `N-attach-wait-deadline` | boundary-commit wait | KILLED | KILLED | admitted wait commits, timeout assertion reddens |
| `N-attach-wait-deadline` | attach cancel (companion) | GREEN | GREEN | cancellation unaffected by the widening |
| `N-probe-deadline` | stop poll deadline | KILLED | KILLED | verdict lands at the release, not the bound |
| `N-probe-deadline` | terminate confirm deadline | KILLED | KILLED | verdict lands at the release, not the bound |
| `N-probe-deadline` | status probe deadline | KILLED | KILLED | verdict lands at the release, not the bound |

Effect-recheck symmetry is now measured stop 4 / quiesce 4 (3
shared arms × 2 entries above, plus the two single-killer skip
rows); the wait bound kills through all 4 wait paths (attach
admission, attach barrier, quiesce span, boundary commit).

## 5. Census and battery

- Table D: 148 gates × 21 entries = 3108 cells; 206 M / 186 B /
  2716 U, verified by script over the table (`count_census.py` in
  the tarball). New rows: `peershape`, `overlapreplay`,
  `confirmbound`, `statusbound`; `pollbound` moves from B29 to
  measured, with the terminate tail corrected from U1 to B39
  (terminate-stale effects include `process_closed`, so the tail
  reaches the shared poll; measured at EXE).
- Table C recounted from the Table D gate set: 148 × 11 = 1628
  cells (1610 U2a + 18 U2c).
- Totals: 266 measured of 5504 (50+10+206 M across Tables
  A/B/D); 190 bound; 5048 unreachable with reasons. Bound-cell
  split verified by ID: 27 driven-but-rowless
  (B22/B23/B32/B36) + 159 named undriven gaps
  (B24/B25/B26/B28/B31 + 152 B39).
- Battery: 296/296 tmuxserver rows as expected (289 narrowing
  KILLED + 5 supplementary KILLED + 1 shadowed SURVIVED + 1
  control SURVIVED) on two full passes with one raw log per
  plant per pass; 42/42 termbind rows as expected (40 narrowing
  KILLED + 1 supplementary + 1 control) on two full verbose
  passes. Combined 338/338.
- Bounds: B29 revised to the exact-instant remainder (non-cell);
  B44 clarified (receipt-validated replay here, liveness with
  TASK-260922-vcx6yo); B45 stated (commits bounded by caller
  cancellation). The conformance matrix mirrors Table B/D
  byte-identically, AC rows 59-92 in both copies, and bounds
  B22-B45 (mirror check in the tarball).

## 6. Operation coverage (8 of 8)

Each operation driven through `Lifecycle.Execute` by a named
committed test (call site `Execute`, `lifecycle.go`):

| Operation | Witness | Second witness (rev9) |
|---|---|---|
| create | `TestExecuteCreateInteractive` | — |
| attach | `TestExecuteAttach` | `TestAttachSameClientRetryWithPeerPresent`, `TestAttachPeerDirectoryFailsClosed` |
| status | `TestExecuteStatusPresent` | `TestExecuteStatusProbeHonorsOperationDeadline` |
| quiesce | `TestExecuteQuiesce` | — (repaired stale-facts legs) |
| safe-boundary | `TestExecuteBoundary` | — (repaired commit-wait fixture) |
| stop | `TestExecuteStop` | `TestExecuteStopPollHonorsOperationDeadline` |
| stale termination | `TestExecuteTerminate` | `TestExecuteTerminateConfirmHonorsOperationDeadline` |
| restore | `TestExecuteRestore` | — |

## 7. Composition (base vs candidate)

Base is the pristine checkpoint tree (`git archive d4bd91d0`);
candidate is the frozen rev9 worktree. Both comparisons are
outcome-keyed over the complete importer set (the whole-repo
suite is a superset of every importer; the entry corpus covers
the direct composition surface).

- Suite-verdict grid (`go test ./... -count=1 -json` on both
  trees, keyed by `(package, test)` top-level verdict):
  2894 shared keys, 2894 retained, **0 moved**, 0 base-only,
  316 candidate-only, 0 fails on either side. All 316
  candidate-only tests sit in the leaf's own packages (306
  `internal/tmuxserver`, 10 `internal/termbind`); no other
  package gained, lost, or moved a test. No input moved across
  an admission or refusal arm — there is nothing to name.
- Entry-outcome corpus (fixed 28-key driver over landed
  packages only, compiled and run on both trees, directory
  removed after each run): **28/28 identical**. Keys: 4 scalar
  timestamp shapes, 16 operation-table checks (8 operations ×
  derived-capabilities admit / empty refuses
  `capability_unproven`) plus the bogus-operation probe, 4
  error-vocabulary checks (attach mismatch admitted, attach
  bogus refused, status unavailable admitted, status mismatch
  refused), 3 instance-identity shapes (UUIDv7 admitted, `pid`
  and empty refused `protocol_error`).
- Raw artifacts: `base-suite.json`, `candidate-suite.json`,
  `base-grid.txt`, `candidate-grid.txt`, `suite_grid.py`,
  `outcome_driver_main.go` (all in the tarball).

## 8. Validation

- Full 30-command configured suite: **30/30 passed, 0 failed**,
  firsthand on the frozen tree (`validation.log`, 55853 lines):
  gofmt clean, `go build ./...`, `go vet ./...`, full suite
  `-count=1 -v`, race gate `-race -timeout 25m`, cover gate, 17
  fuzz gates (100x each: rpcwire 4, scalar 1, canonicaljson 4,
  secconftest 8), tracecheck, cataloggen `-check`, linux +
  windows builds, JSON check, `task-board validate`,
  `git diff --check`. (The `FAIL` strings inside the log are
  nested fixture output of the resumesmoke negative tests; the
  package reports `ok` in the suite, race, and cover runs.)
- `GOOS=windows go vet ./...`: exit 0.
- Changed-package race: `go test ./internal/tmuxserver/
  ./internal/termbind/ -count=1 -race` green (21.0s + 3.3s).
- No worktree edit happened between the freeze and the
  validation runs; `git diff --check` (command 30/30) and the
  final `git status` (49 intended paths, HEAD still
  `d4bd91d0`, no commits) confirm the candidate tree.

## 9. Evidence manifest

- `TASK-260830-1c28dz_producer-evidence.tar.gz` (sha256
  `fa7b00c29ce887ce3d2d566cbebd2f5f8328eab0ddb0c750b23b74021734fa56`,
  3699159 bytes, 648 entries): isolated attribution logs (2
  rounds), tmuxserver harness pass 1 + pass 2 (per-plant raw
  logs), termbind harness pass 1 + pass 2 (verbose), full
  30-command validation log, suite grids (base + candidate JSON),
  entry-outcome grids (base + candidate), `count_census.py` +
  its outputs, `mirror_matrix.py` + its output, `isolate.py`,
  the outcome-grid driver source, the validation runner, and a
  per-file sha256 `MANIFEST.txt`. Built from the frozen rev9
  tree, attached by absolute path, read back, and
  digest-verified (P2-C).
- `TASK-260830-1c28dz_conformance-matrix.md`: updated matrix
  (this revision).
- `TASK-260830-1c28dz_results.md`: this file.

## 10. Carried bounds and handover notes

- B18 (sun_path 104-byte limit), B16 (nested invocation ambient
  collision — deliberate ambient refusal), B19/B20 (SPEC 810-812
  before-bind unsafe-root rejection): unchanged from rev8, all
  measured in rows 59-77.
- Rev7 P3-A (fresh-decoy foreground attach wiring): unchanged;
  attach semantics here are the structured-command path, and
  the rev7 wiring question stays with the g0pcnt-side handover.
- B44 handover to TASK-260922-vcx6yo stays intact: this leaf
  distinguishes validated replay from new client by durable
  receipt; live-client overlap admission is theirs.
- The exec adapter (`BuildCommand` + `ExecRunner`) and the probe
  adapters (`UnixDialer`, `ServerSpawner`, `ServerProbe`) exist
  and are driven as in rev8; the server socket crash/idempotency
  evidence is carried (crash-converges rows, spawn rows).
