import subprocess,pathlib,time,os,json
r=pathlib.Path(__file__).resolve().parent;c=r/'candidate'
for name,cmd in [('suite',['go','test','./...','-count=1','-json']),('race',['go','test','./internal/tmuxserver','./internal/termbind','-race','-count=1']),('vet',['go','vet','./...']),('windows-vet',['go','vet','./...']),('cover',['go','test','./...','-cover','-count=1'])]:
 env=os.environ.copy()
 if name=='windows-vet':env.update(GOOS='windows',GOARCH='amd64')
 start=time.time()
 with open(r/(name+'.log'),'w') as f:p=subprocess.run(cmd,cwd=c,env=env,stdout=f,stderr=subprocess.STDOUT)
 record=dict(name=name,cmd=cmd,exit=p.returncode,elapsed=time.time()-start,load=os.getloadavg())
 with open(r/'checks.jsonl','a') as f:f.write(json.dumps(record)+'\n')
 print(record,flush=True)
