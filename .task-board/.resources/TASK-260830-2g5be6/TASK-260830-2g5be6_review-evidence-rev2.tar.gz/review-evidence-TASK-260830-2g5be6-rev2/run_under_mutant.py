#!/usr/bin/env python3
"""Apply one reviewer mutant, run one probe test, restore (RUN-260918-fdce92).

Usage: PYTHONDONTWRITEBYTECODE=1 python3 run_under_mutant.py --repo candidate --log FILE MUTANT_NAME TEST_REGEX
MUTANT_NAME may be 'pristine' to run the probe without a plant.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from reviewer_mutants_rev2 import MUTANTS, PKG, SIZE_ONLY_HELPER  # noqa: E402

HERE = Path(__file__).resolve().parent
PROBE = HERE / "zz_rev2_probe_test.go"
UNDER = HERE / "zz_rev2_under_mutant_test.go"


def main(argv):
    repo = Path("candidate")
    log = None
    rest = []
    i = 0
    while i < len(argv):
        if argv[i] == "--repo":
            repo = Path(argv[i + 1]); i += 2
        elif argv[i] == "--log":
            log = Path(argv[i + 1]); i += 2
        else:
            rest.append(argv[i]); i += 1
    name, pattern = rest
    repo = repo.resolve()
    mutant = None if name == "pristine" else next(m for m in MUTANTS if m.name == name)
    pkg = repo / PKG
    probe_dst = pkg / PROBE.name
    under_dst = pkg / UNDER.name
    shutil.copy2(PROBE, probe_dst)
    shutil.copy2(UNDER, under_dst)
    backup = None
    target = None
    original = None
    try:
        if mutant is not None:
            target = repo / mutant.path
            original = target.read_bytes()
            text = original.decode()
            assert text.count(mutant.find) == 1, f"anchor count {text.count(mutant.find)}"
            patched = text.replace(mutant.find, mutant.replace)
            if mutant.name == "R1-size-equality-is-proof":
                patched += SIZE_ONLY_HELPER
            target.write_text(patched)
        proc = subprocess.run(["go", "test", f"./{PKG}/", "-run", pattern, "-count=1", "-v"], cwd=repo, capture_output=True, text=True, timeout=600)
        output = (proc.stdout + proc.stderr)
    finally:
        if target is not None:
            target.write_bytes(original)
        probe_dst.unlink(missing_ok=True)
        under_dst.unlink(missing_ok=True)
    header = f"# under mutant={name} run={pattern} exit={proc.returncode}\n"
    if log is not None:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(header + output)
    print(header + "\n".join(l for l in output.splitlines() if "PROBE" in l or l.startswith("--- ") or l.startswith("ok") or l.startswith("FAIL")))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
