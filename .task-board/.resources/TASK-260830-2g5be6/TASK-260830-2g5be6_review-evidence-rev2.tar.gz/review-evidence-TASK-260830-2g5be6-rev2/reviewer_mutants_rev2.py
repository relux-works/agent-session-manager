#!/usr/bin/env python3
"""Reviewer mutant battery for CR-TASK-260830-2g5be6-2 (RUN-260918-fdce92).

Each row patches ONE production file in the isolated copy of the exact
candidate tree (e7c9a12d…), runs the WHOLE committed internal/clonesnap
suite (go test ./internal/clonesnap/ -count=1) as the killer, records the
raw output with the subprocess exit, and restores the file from a byte
copy. Verdicts: KILLED iff the suite fails with a FAIL line; SURVIVED iff
exit 0; ERROR otherwise (unapplied anchor, build break, timeout).

Rows R1-* re-plant the five narrowings that SURVIVED revision 1 (plus the
rev1 widening and seam control); rows R2-* are new plants on gates the
producer's shipped harness does not mutate; C-* are controls.

Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 reviewer_mutants_rev2.py --repo candidate --log-dir logs/mutants/run1 [NAME ...]
"""

import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

PKG = "internal/clonesnap"

PROJECT_ORDER_PIN = (
    "\t// ORDER-PIN: the source-race gate precedes any seal, admission,\n"
    "\t// or projection output. N-race-order-project moves this gate\n"
    "\t// after admitAndEmit: the early seal then refuses with a seal\n"
    "\t// error instead of the race refusal, so the killer reddens on\n"
    "\t// the wrong error — and on any emitted receipt blob.\n"
    "\tif err := state.gateSourceRace(); err != nil {\n"
    "\t\tcaptured, raceErr := state.raceOutcome(err)\n"
    "\t\tif raceErr != nil {\n"
    "\t\t\treturn nil, raceErr\n"
    "\t\t}\n"
    "\t\t// Archive-only output never enters a target branch: the\n"
    "\t\t// admission gate below refuses it, so no receipt exists.\n"
    "\t\tif _, err := AdmitForTarget(captured.CaptureManifest, request.FidelityProfile); err != nil {\n"
    "\t\t\treturn nil, err\n"
    "\t\t}\n"
    '\t\treturn nil, invalid("capture archive unexpectedly admitted to a target branch")\n'
    "\t}\n"
    "\tsealed, err := state.sealAndPublish(false)\n"
    "\tif err != nil {\n"
    "\t\treturn nil, err\n"
    "\t}\n"
    "\treturn state.admitAndEmit(request, sealed)\n"
)

CAPTURE_ORDER_PIN = (
    "\t// ORDER-PIN: the source-race gate precedes any seal or publish.\n"
    "\t// N-race-order-capture moves this gate after sealAndPublish and\n"
    "\t// the killer reddens on the published manifests.\n"
    "\tif err := state.gateSourceRace(); err != nil {\n"
    "\t\treturn state.raceOutcome(err)\n"
    "\t}\n"
    "\treturn state.sealAndPublish(false)\n"
)


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    kind: str  # narrowing | add-write | widening | control | seam-control
    expect: str
    note: str


MUTANTS = [
    # ---- Step 0: the five revision-1 survivors re-planted on the rev2 tree ----
    Mutant(
        name="R1-blockedAncestor-optional",
        path=f"{PKG}/capture.go",
        find="\t\tif !present && !item.Required && !blockedAncestor(byKey, key) {\n",
        replace="\t\tif !present && !item.Required {\n",
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 2: an OPTIONAL member behind a symlinked intermediate seals as plan_optional_absent instead of reaching the Guard refusal.",
    ),
    Mutant(
        name="R1-archive-emits-receipt",
        path=f"{PKG}/project.go",
        find="\t\t// Archive-only output never enters a target branch: the\n",
        replace=(
            "\t\t_, _ = request.TargetSink.PutBlob(scalar.SHA256Digest(captured.CaptureManifest), uint64(len(captured.CaptureManifest)), bytes.NewReader(captured.CaptureManifest))\n"
            "\t\t// Archive-only output never enters a target branch: the\n"
        ),
        kind="add-write", expect="KILLED",
        note="rev1 P2-α row 8: the projection entry writes the archive capture manifest into the TARGET sink before the G2 refusal.",
    ),
    Mutant(
        name="R1-skip-payload-install-blob-b",
        path=f"{PKG}/capture.go",
        find="\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n\t\t}\n",
        replace=(
            "\t\tif key != \"store/blob-b\" {\n"
            "\t\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n"
            "\t\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n"
            "\t\t\t}\n"
            "\t\t}\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 14: exactly store/blob-b is sealed into the raw manifest without its blob ever being installed (10.2 MUST).",
    ),
    Mutant(
        name="R1-post-falls-back-to-captured-hash",
        path=f"{PKG}/capture.go",
        find="\t\t\tif !useCaptured {\n\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n\t\t\t\t\tcontinue\n\t\t\t\t}\n\t\t\t}\n",
        replace=(
            "\t\t\tif !useCaptured {\n"
            "\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n"
            "\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t\tfallback := false\n"
            "\t\t\t\tfor _, captured := range state.captured {\n"
            "\t\t\t\t\tif captured.key == member.key {\n"
            "\t\t\t\t\t\trecord.addFile(member.key, captured.descriptor.Size, contentHash(captured.payload))\n"
            "\t\t\t\t\t\tfallback = true\n"
            "\t\t\t\t\t}\n"
            "\t\t\t\t}\n"
            "\t\t\t\tif fallback {\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t}\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 9: a member unreadable at post time falls back to the captured hash instead of unknown content.",
    ),
    Mutant(
        name="R1-clonebundle-unknown-ignores-excluded",
        path="internal/clonebundle/capturebuild.go",
        find="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        replace="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" && item.Included() {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 5 / inherited P3-ε: an EXCLUDED unknown-class item no longer drives raw_complete=false nor blocks maximal_safe (plant in clonebundle, killer in clonesnap).",
    ),
    Mutant(
        name="R1-size-equality-is-proof",
        path=f"{PKG}/race.go",
        find="\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n",
        replace=(
            "\tif sizeOnly(preLines) == sizeOnly(postLines) {\n"
            "\t\treturn nil\n"
            "\t}\n"
            "\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n"
        ),
        kind="widening", expect="KILLED",
        note="rev1 rerun: size equality decides the race (spec: file-size equality is never proof).",
    ),
    Mutant(
        name="R1-hook-after-post-measure",
        path=f"{PKG}/capture.go",
        find="\tstate.pre, state.preLines = state.recordSource(observed, true)\n\tif state.request.Hooks.AfterWalk != nil {\n\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n\t\t}\n\t}\n\treturn state.measurePost()\n",
        replace=(
            "\tstate.pre, state.preLines = state.recordSource(observed, true)\n"
            "\tif err := state.measurePost(); err != nil {\n"
            "\t\treturn err\n"
            "\t}\n"
            "\tif state.request.Hooks.AfterWalk != nil {\n"
            "\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n"
            "\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n"
            "\t\t}\n"
            "\t}\n"
            "\treturn nil\n"
        ),
        kind="seam-control", expect="KILLED",
        note="rev1 rerun: the injection hook runs after the post measurement, so every injected mutation lands outside the measured window.",
    ),
    # ---- New reviewer plants on gates the shipped harness does not mutate ----
    Mutant(
        name="R2-project-seal-before-gate",
        path=f"{PKG}/project.go",
        find=PROJECT_ORDER_PIN,
        replace=(
            "\tsealed, sealErr := state.sealAndPublish(false)\n"
            "\tif err := state.gateSourceRace(); err != nil {\n"
            "\t\tcaptured, raceErr := state.raceOutcome(err)\n"
            "\t\tif raceErr != nil {\n"
            "\t\t\treturn nil, raceErr\n"
            "\t\t}\n"
            "\t\tif _, err := AdmitForTarget(captured.CaptureManifest, request.FidelityProfile); err != nil {\n"
            "\t\t\treturn nil, err\n"
            "\t\t}\n"
            '\t\treturn nil, invalid("capture archive unexpectedly admitted to a target branch")\n'
            "\t}\n"
            "\tif sealErr != nil {\n"
            "\t\treturn nil, sealErr\n"
            "\t}\n"
            "\treturn state.admitAndEmit(request, sealed)\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="ORDERING at the projection entry: CaptureAndProject seals and PUBLISHES the raw manifest BEFORE the race gate, then returns the race refusal (the stable capture-manifest seal fails closed on unequal digests, so no receipt is ever emitted). Measures whether 'the gate precedes any seal' is pinned at CaptureAndProject, or only 'precedes projection output'.",
    ),
    Mutant(
        name="R2-capture-seal-before-gate",
        path=f"{PKG}/capture.go",
        find=CAPTURE_ORDER_PIN,
        replace=(
            "\tsealed, sealErr := state.sealAndPublish(false)\n"
            "\tif err := state.gateSourceRace(); err != nil {\n"
            "\t\treturn state.raceOutcome(err)\n"
            "\t}\n"
            "\tif sealErr != nil {\n"
            "\t\treturn nil, sealErr\n"
            "\t}\n"
            "\treturn sealed, nil\n"
        ),
        kind="narrowing", expect="KILLED",
        note="Same shape at the Capture entry (control for R2-project-seal-before-gate): the raw manifest is published before the gate and the race refusal is still returned.",
    ),
    Mutant(
        name="R2-unplanned-special-admitted",
        path=f"{PKG}/walk.go",
        find="func intermediatePrefix(plan map[string]PlanItem, key string) bool {\n\tprefix := key + \"/\"\n",
        replace="func intermediatePrefix(plan map[string]PlanItem, key string) bool {\n\tif key == \"stray-link\" {\n\t\treturn true\n\t}\n\tprefix := key + \"/\"\n",
        kind="narrowing", expect="SURVIVED?",
        note="Exactly one UNPLANNED special member (a symlink named stray-link) is treated as an intermediate: it bypasses the 'not a plan candidate' refusal and the early containment open, so the capture silently drops it and seals as stable/complete. Pristine refuses it (probe P1).",
    ),
    Mutant(
        name="R2-store-root-follows-symlink",
        path=f"{PKG}/capture.go",
        find="\troot, err := secprim.OpenNoFollowDir(request.StoreRoot)\n",
        replace="\troot, err := os.Open(request.StoreRoot)\n",
        kind="widening", expect="SURVIVED?",
        note="The store root handle follows a trailing symlink (the landed nofollow discipline is dropped at the ROOT only; every member open still goes through the Guard). Pristine refuses a symlinked store root (probe P4). Measures whether any committed test drives a symlinked store root.",
    ),
    Mutant(
        name="R2-excluded-size-ignored",
        path=f"{PKG}/capture.go",
        find="\t\t\tif class == \"\" || excludedClass(class) {\n\t\t\t\trecord.addFile(member.key, member.size, \"-\")\n\t\t\t\tcontinue\n\t\t\t}\n",
        replace=(
            "\t\t\tif class == \"\" || excludedClass(class) {\n"
            "\t\t\t\tsize := member.size\n"
            "\t\t\t\tif member.key == \"store/token-cache\" {\n"
            "\t\t\t\t\tsize = 0\n"
            "\t\t\t\t}\n"
            "\t\t\t\trecord.addFile(member.key, size, \"-\")\n"
            "\t\t\t\tcontinue\n"
            "\t\t\t}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Exactly the excluded member store/token-cache contributes a constant size to the source record, so its SIZE change between walk and post is missed (TRACEABILITY claims 'presence, shape, and size changes still race' for excluded members; pristine refuses, probe P9b).",
    ),
    Mutant(
        name="R2-unstable-seals-pre-as-post",
        path=f"{PKG}/capture.go",
        find="\t\t\tPreCaptureDigest:  state.pre.String(),\n\t\t\tPostCaptureDigest: state.post.String(),\n\t\t\tCore:              true,\n",
        replace="\t\t\tPreCaptureDigest:  state.pre.String(),\n\t\t\tPostCaptureDigest: state.pre.String(),\n\t\t\tCore:              true,\n",
        kind="narrowing", expect="SURVIVED?",
        note="The unstable_archive form seals the PRE digest for post_capture_digest: the archive manifest then carries equal digests while flagged source_not_quiescent (AC row 8 says the form carries the pre/post digests; pristine seals the two measured digests, probe P10b).",
    ),
    Mutant(
        name="R2-required-blockedAncestor-dropped",
        path=f"{PKG}/capture.go",
        find="\t\tif !present && item.Required && !blockedAncestor(byKey, key) {\n",
        replace="\t\tif !present && item.Required {\n",
        kind="narrowing", expect="KILLED",
        note="A REQUIRED member behind a symlinked intermediate refuses as 'required but absent' instead of reaching the Guard refusal that names the symlink escape.",
    ),
    Mutant(
        name="R2-plan-grammar-admits-dotdot",
        path=f"{PKG}/walk.go",
        find="\t\tif err := secprim.CheckMemberPath(platform, item.NativeKey); err != nil {\n",
        replace="\t\tif err := secprim.CheckMemberPath(platform, item.NativeKey); err != nil && item.NativeKey != \"store/../escape\" {\n",
        kind="narrowing", expect="KILLED",
        note="The plan member-grammar gate admits exactly store/../escape (SanitizeNativeKey does not refuse parent segments, so this gate is the only one).",
    ),
    Mutant(
        name="R2-fingerprints-129",
        path=f"{PKG}/workspace.go",
        find="\tif len(fingerprints) > 128 {\n",
        replace="\tif len(fingerprints) > 129 {\n",
        kind="narrowing", expect="KILLED",
        note="The [0..128] fingerprint bound admits exactly 129 (no shipped harness row for this bound).",
    ),
    Mutant(
        name="R2-branch-1025",
        path=f"{PKG}/workspace.go",
        find="\tif length := environ.StringLength(*value); length < minimum || length > maximum {\n",
        replace="\tif length := environ.StringLength(*value); length < minimum || length > maximum+1 {\n",
        kind="narrowing", expect="KILLED",
        note="The branch string[1..1024] bound admits exactly 1025 characters (no shipped harness row for this bound).",
    ),
    Mutant(
        name="R2-first-chunk-oversize",
        path=f"{PKG}/descriptor.go",
        find="\t\tlength := uint64(blobChunkSize)\n",
        replace="\t\tlength := uint64(blobChunkSize)\n\t\tif len(chunks) == 0 && size > uint64(blobChunkSize) {\n\t\t\tlength = uint64(blobChunkSize) + 1\n\t\t}\n",
        kind="narrowing", expect="KILLED",
        note="The first chunk of a multi-chunk blob is 4194305 bytes (chunk size bound uint53[1..4194304]).",
    ),
    Mutant(
        name="C-stable-seals-pre-as-post",
        path=f"{PKG}/capture.go",
        find="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.post.String(),\n\t\tInputBlocked:      request.InputBlocked,\n",
        replace="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.pre.String(),\n\t\tInputBlocked:      request.InputBlocked,\n",
        kind="control", expect="SURVIVED",
        note="Equivalence control: on the stable path the gate proved pre == post before the seal, so sealing pre for post_capture_digest is byte-identical and must SURVIVE.",
    ),
    Mutant(
        name="C-rev2-comment",
        path=f"{PKG}/race.go",
        find="// This file owns the source-race record: the canonical digest over\n",
        replace="// This file owns the source-race record (reviewer control): the canonical digest over\n",
        kind="control", expect="SURVIVED",
        note="Harmless control: a comment-only edit must SURVIVE.",
    ),
]

SIZE_ONLY_HELPER = '''
// sizeOnly (reviewer mutant helper) strips content hashes from a record listing.
func sizeOnly(lines []string) string {
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		if i := strings.LastIndex(line, "\\x00"); i >= 0 {
			line = line[:i]
		}
		out = append(out, line)
	}
	sort.Strings(out)
	return strings.Join(out, "\\n")
}
'''


def run(repo: Path, mutant: Mutant, log_dir: Path) -> str:
    target = repo / mutant.path
    original = target.read_bytes()
    text = original.decode()
    count = text.count(mutant.find)
    if count != 1:
        line = f"ERROR: {mutant.name}: anchor count {count}, want 1"
        (log_dir / f"{mutant.name}.log").write_text(line + "\n")
        return line
    patched = text.replace(mutant.find, mutant.replace)
    if mutant.name == "R1-size-equality-is-proof":
        patched += SIZE_ONLY_HELPER
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        backup.write_bytes(original)
        try:
            target.write_text(patched)
            started = time.time()
            try:
                proc = subprocess.run(
                    ["go", "test", f"./{PKG}/", "-count=1"],
                    cwd=repo, capture_output=True, text=True, timeout=600,
                )
                output = (proc.stdout + proc.stderr).strip()
                code = proc.returncode
            except subprocess.TimeoutExpired:
                output = "TIMEOUT"
                code = -1
            elapsed = time.time() - started
        finally:
            target.write_bytes(backup.read_bytes())
    if target.read_bytes() != original:
        raise SystemExit(f"restore failed for {mutant.path}")
    if output == "TIMEOUT":
        verdict = "ERROR(timeout)"
    elif "build failed" in output or output.startswith("# ") or "\n# " in output:
        verdict = "ERROR(build)"
    elif code == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        verdict = f"ERROR(exit {code})"
    killers = sorted({l.split()[2] for l in output.splitlines() if l.startswith("--- FAIL")})
    line = f"{mutant.name}: {verdict} (expect {mutant.expect}) kind={mutant.kind} exit={code} elapsed={elapsed:.1f}s killers={','.join(killers) or '-'} :: {mutant.note}"
    (log_dir / f"{mutant.name}.log").write_text(
        f"# mutant={mutant.name} path={mutant.path} kind={mutant.kind} expect={mutant.expect}\n# exit={code} elapsed={elapsed:.1f}s verdict={verdict}\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{output}\n"
    )
    return line


def main(argv):
    repo = Path("candidate")
    log_dir = Path("logs/mutants/run")
    names = []
    i = 0
    while i < len(argv):
        if argv[i] == "--repo":
            repo = Path(argv[i + 1]); i += 2
        elif argv[i] == "--log-dir":
            log_dir = Path(argv[i + 1]); i += 2
        else:
            names.append(argv[i]); i += 1
    log_dir.mkdir(parents=True, exist_ok=True)
    selected = [m for m in MUTANTS if not names or m.name in names]
    for m in selected:
        print(run(repo.resolve(), m, log_dir), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
