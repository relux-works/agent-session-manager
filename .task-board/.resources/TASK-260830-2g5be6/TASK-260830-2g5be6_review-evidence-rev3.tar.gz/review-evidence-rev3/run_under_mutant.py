#!/usr/bin/env python3
"""Execute the reviewer probes UNDER one surviving plant: apply the named
mutant from reviewer_mutants_rev3.py to the isolated candidate copy, run the
named probe tests (-v), write the raw log with the subprocess exit, restore
the production file from a byte copy, and verify the restoration.

Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 run_under_mutant.py --repo candidate --log-dir logs/under-mutant MUTANT 'TestRegexp'
"""

import subprocess
import sys
import tempfile
from pathlib import Path

import reviewer_mutants_rev3 as battery


def main(argv):
    repo = Path("candidate")
    log_dir = Path("logs/under-mutant")
    rest = []
    i = 0
    while i < len(argv):
        if argv[i] == "--repo":
            repo = Path(argv[i + 1]); i += 2
        elif argv[i] == "--log-dir":
            log_dir = Path(argv[i + 1]); i += 2
        else:
            rest.append(argv[i]); i += 1
    name, pattern = rest[0], rest[1]
    mutant = next(m for m in battery.MUTANTS if m.name == name)
    log_dir.mkdir(parents=True, exist_ok=True)
    target = repo.resolve() / mutant.path
    original = target.read_bytes()
    text = original.decode()
    assert text.count(mutant.find) == 1, f"anchor count {text.count(mutant.find)}"
    patched = text.replace(mutant.find, mutant.replace)
    if mutant.name == "R1-size-equality-is-proof":
        patched += battery.SIZE_ONLY_HELPER
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        backup.write_bytes(original)
        try:
            target.write_text(patched)
            proc = subprocess.run(
                ["go", "test", f"./{battery.PKG}/", "-run", pattern, "-count=1", "-v"],
                cwd=repo.resolve(), capture_output=True, text=True, timeout=600,
            )
        finally:
            target.write_bytes(backup.read_bytes())
    if target.read_bytes() != original:
        raise SystemExit(f"restore failed for {mutant.path}")
    output = (proc.stdout + proc.stderr).strip()
    (log_dir / f"{name}.log").write_text(
        f"# under mutant={name} path={mutant.path} probes={pattern}\n# exit={proc.returncode}\n---\n{output}\n"
    )
    for line in output.splitlines():
        if "PROBE" in line or line.startswith("--- ") or line.startswith("ok") or line.startswith("FAIL") or line.startswith("panic"):
            print(line.strip()[:400])
    print(f"# exit={proc.returncode}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
