#!/usr/bin/env python3
"""Reviewer mutant battery for CR-TASK-260830-2g5be6-3 (RUN-260918-4b4c38).

Each row patches ONE production file in the isolated copy of the exact
candidate tree (9114b466…), runs the WHOLE committed internal/clonesnap
suite (go test ./internal/clonesnap/ -count=1) as the killer, records the
raw output with the subprocess exit, and restores the file from a byte
copy. Verdicts: KILLED iff the suite fails with a FAIL line; SURVIVED iff
exit 0; ERROR otherwise (unapplied anchor, build break, timeout).

Rows R2-* re-plant the rev2 reviewer battery (RUN-260918-fdce92) on the
rev3 tree — the five rev2 survivors first; rows R1-* re-plant the rev1
survivors and controls; rows R3-* are new plants on gates the producer's
shipped harness does not mutate; C-* are controls.

Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 reviewer_mutants_rev3.py --repo candidate --log-dir logs/mutants/run1 [NAME ...]
"""

import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

PKG = "internal/clonesnap"

# rev3 anchor: the ORDER-PIN comment changed in this revision.
PROJECT_ORDER_PIN = (
    "\t// ORDER-PIN: the source-race gate precedes any seal, admission,\n"
    "\t// or projection output. N-race-order-project moves this gate\n"
    "\t// after admitAndEmit: the early seal then refuses with a seal\n"
    "\t// error instead of the race refusal, so that row's killer\n"
    "\t// reddens on the wrong error (the seal error message, not a\n"
    "\t// sink). N-race-order-project-seal keeps the race error while\n"
    "\t// sealing first: its killer reddens on the sealed raw manifest\n"
    "\t// in the capture store.\n"
    "\tif err := state.gateSourceRace(); err != nil {\n"
    "\t\tcaptured, raceErr := state.raceOutcome(err)\n"
    "\t\tif raceErr != nil {\n"
    "\t\t\treturn nil, raceErr\n"
    "\t\t}\n"
    "\t\t// Archive-only output never enters a target branch: the\n"
    "\t\t// admission gate below refuses it, so no receipt exists.\n"
    "\t\tif _, err := AdmitForTarget(captured.CaptureManifest, request.FidelityProfile); err != nil {\n"
    "\t\t\treturn nil, err\n"
    "\t\t}\n"
    '\t\treturn nil, invalid("capture archive unexpectedly admitted to a target branch")\n'
    "\t}\n"
    "\tsealed, err := state.sealAndPublish(false)\n"
    "\tif err != nil {\n"
    "\t\treturn nil, err\n"
    "\t}\n"
    "\treturn state.admitAndEmit(request, sealed)\n"
)

CAPTURE_ORDER_PIN = (
    "\t// ORDER-PIN: the source-race gate precedes any seal or publish.\n"
    "\t// N-race-order-capture moves this gate after sealAndPublish and\n"
    "\t// the killer reddens on the published manifests.\n"
    "\tif err := state.gateSourceRace(); err != nil {\n"
    "\t\treturn state.raceOutcome(err)\n"
    "\t}\n"
    "\treturn state.sealAndPublish(false)\n"
)

UNSTABLE_BOUNDARY = (
    "\t\t\tPreCaptureDigest:  state.pre.String(),\n"
    "\t\t\tPostCaptureDigest: state.post.String(),\n"
    "\t\t\tCore:              true,\n"
)

EARLY_PASS = (
    "\tfor _, member := range observed {\n"
    "\t\tif member.kind != memberOther {\n"
    "\t\t\tcontinue\n"
    "\t\t}\n"
    "\t\tif intermediatePrefix(state.plan, member.key) {\n"
    "\t\t\tcontinue\n"
    "\t\t}\n"
    "\t\tif excludedClass(state.plan[member.key].Class) {\n"
    "\t\t\tcontinue\n"
    "\t\t}\n"
    "\t\tif _, err := openMember(state.guard, state.root, member.key, state.limit); err != nil {\n"
    "\t\t\treturn err\n"
    "\t\t}\n"
    "\t}\n"
)

MEASURE_POST = (
    "func (state *pipeline) measurePost() error {\n"
    "\tobserved, err := enumerateStore(state.request.StoreRoot)\n"
    "\tif err != nil {\n"
    "\t\treturn err\n"
    "\t}\n"
    "\tstate.post, state.postLines = state.recordSource(observed, false)\n"
    "\treturn nil\n"
    "}\n"
)

RESULT_DIGESTS = (
    "\t\tPreDigest:        state.pre,\n"
    "\t\tPostDigest:       state.post,\n"
)


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    kind: str  # narrowing | add-write | widening | control | seam-control | add-behaviour
    expect: str
    note: str


MUTANTS = [
    # ---- Step 0: the two rev2 P2 survivors and the three rev2 P3 survivors, re-planted on the rev3 tree ----
    Mutant(
        name="R2-unstable-seals-pre-as-post",
        path=f"{PKG}/capture.go",
        find=UNSTABLE_BOUNDARY,
        replace=UNSTABLE_BOUNDARY.replace("PostCaptureDigest: state.post.String()", "PostCaptureDigest: state.pre.String()"),
        kind="narrowing", expect="KILLED",
        note="rev2 P2-α row 8: the unstable_archive form seals the PRE digest for post_capture_digest (equal digests while flagged source_not_quiescent).",
    ),
    Mutant(
        name="R2-project-seal-before-gate",
        path=f"{PKG}/project.go",
        find=PROJECT_ORDER_PIN,
        replace=(
            "\tsealed, sealErr := state.sealAndPublish(false)\n"
            "\tif err := state.gateSourceRace(); err != nil {\n"
            "\t\tcaptured, raceErr := state.raceOutcome(err)\n"
            "\t\tif raceErr != nil {\n"
            "\t\t\treturn nil, raceErr\n"
            "\t\t}\n"
            "\t\tif _, err := AdmitForTarget(captured.CaptureManifest, request.FidelityProfile); err != nil {\n"
            "\t\t\treturn nil, err\n"
            "\t\t}\n"
            '\t\treturn nil, invalid("capture archive unexpectedly admitted to a target branch")\n'
            "\t}\n"
            "\tif sealErr != nil {\n"
            "\t\treturn nil, sealErr\n"
            "\t}\n"
            "\treturn state.admitAndEmit(request, sealed)\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev2 P2-α row 10: CaptureAndProject seals and PUBLISHES the raw manifest BEFORE the race gate, then returns the race refusal (no receipt is ever emitted).",
    ),
    Mutant(
        name="R2-unplanned-special-admitted",
        path=f"{PKG}/walk.go",
        find="func intermediatePrefix(plan map[string]PlanItem, key string) bool {\n\tprefix := key + \"/\"\n",
        replace="func intermediatePrefix(plan map[string]PlanItem, key string) bool {\n\tif key == \"stray-link\" {\n\t\treturn true\n\t}\n\tprefix := key + \"/\"\n",
        kind="narrowing", expect="KILLED",
        note="rev2 P3-a: exactly one UNPLANNED special member (a symlink named stray-link) is treated as an intermediate and silently dropped.",
    ),
    Mutant(
        name="R2-store-root-follows-symlink",
        path=f"{PKG}/capture.go",
        find="\troot, err := secprim.OpenNoFollowDir(request.StoreRoot)\n",
        replace="\troot, err := os.Open(request.StoreRoot)\n",
        kind="widening", expect="KILLED",
        note="rev2 P3-b: the store root handle follows a trailing symlink (nofollow dropped at the ROOT only).",
    ),
    Mutant(
        name="R2-excluded-size-ignored",
        path=f"{PKG}/capture.go",
        find="\t\t\tif class == \"\" || excludedClass(class) {\n\t\t\t\trecord.addFile(member.key, member.size, \"-\")\n\t\t\t\tcontinue\n\t\t\t}\n",
        replace=(
            "\t\t\tif class == \"\" || excludedClass(class) {\n"
            "\t\t\t\tsize := member.size\n"
            "\t\t\t\tif member.key == \"store/token-cache\" {\n"
            "\t\t\t\t\tsize = 0\n"
            "\t\t\t\t}\n"
            "\t\t\t\trecord.addFile(member.key, size, \"-\")\n"
            "\t\t\t\tcontinue\n"
            "\t\t\t}\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev2 P3-c: exactly the excluded member store/token-cache contributes a constant size to the source record, so its size change is missed.",
    ),
    Mutant(
        name="R2-branch-1025",
        path=f"{PKG}/workspace.go",
        find="\tif length := environ.StringLength(*value); length < minimum || length > maximum {\n",
        replace="\tif length := environ.StringLength(*value); length < minimum || length > maximum+1 {\n",
        kind="narrowing", expect="SURVIVED",
        note="rev2 P3-d: the local branch bound admits exactly 1025 characters; the landed DecodeWorkspaceBinding refuses first, so this must SURVIVE (attributed in TRACEABILITY).",
    ),
    # ---- rev2 rows that were KILLED, re-confirmed on the rev3 tree ----
    Mutant(
        name="R2-capture-seal-before-gate",
        path=f"{PKG}/capture.go",
        find=CAPTURE_ORDER_PIN,
        replace=(
            "\tsealed, sealErr := state.sealAndPublish(false)\n"
            "\tif err := state.gateSourceRace(); err != nil {\n"
            "\t\treturn state.raceOutcome(err)\n"
            "\t}\n"
            "\tif sealErr != nil {\n"
            "\t\treturn nil, sealErr\n"
            "\t}\n"
            "\treturn sealed, nil\n"
        ),
        kind="narrowing", expect="KILLED",
        note="Same shape at the Capture entry: the raw manifest is published before the gate and the race refusal is still returned.",
    ),
    Mutant(
        name="R2-required-blockedAncestor-dropped",
        path=f"{PKG}/capture.go",
        find="\t\tif !present && item.Required && !blockedAncestor(byKey, key) {\n",
        replace="\t\tif !present && item.Required {\n",
        kind="narrowing", expect="KILLED",
        note="A REQUIRED member behind a symlinked intermediate refuses as 'required but absent' instead of the Guard refusal naming the escape.",
    ),
    Mutant(
        name="R2-plan-grammar-admits-dotdot",
        path=f"{PKG}/walk.go",
        find="\t\tif err := secprim.CheckMemberPath(platform, item.NativeKey); err != nil {\n",
        replace="\t\tif err := secprim.CheckMemberPath(platform, item.NativeKey); err != nil && item.NativeKey != \"store/../escape\" {\n",
        kind="narrowing", expect="KILLED",
        note="The plan member-grammar gate admits exactly store/../escape.",
    ),
    Mutant(
        name="R2-fingerprints-129",
        path=f"{PKG}/workspace.go",
        find="\tif len(fingerprints) > 128 {\n",
        replace="\tif len(fingerprints) > 129 {\n",
        kind="narrowing", expect="KILLED",
        note="The [0..128] fingerprint bound admits exactly 129.",
    ),
    Mutant(
        name="R2-first-chunk-oversize",
        path=f"{PKG}/descriptor.go",
        find="\t\tlength := uint64(blobChunkSize)\n",
        replace="\t\tlength := uint64(blobChunkSize)\n\t\tif len(chunks) == 0 && size > uint64(blobChunkSize) {\n\t\t\tlength = uint64(blobChunkSize) + 1\n\t\t}\n",
        kind="narrowing", expect="KILLED",
        note="The first chunk of a multi-chunk blob is 4194305 bytes.",
    ),
    # ---- rev1 survivors and controls, re-confirmed on the rev3 tree ----
    Mutant(
        name="R1-blockedAncestor-optional",
        path=f"{PKG}/capture.go",
        find="\t\tif !present && !item.Required && !blockedAncestor(byKey, key) {\n",
        replace="\t\tif !present && !item.Required {\n",
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 2: an OPTIONAL member behind a symlinked intermediate seals as plan_optional_absent.",
    ),
    Mutant(
        name="R1-archive-emits-receipt",
        path=f"{PKG}/project.go",
        find="\t\t// Archive-only output never enters a target branch: the\n",
        replace=(
            "\t\t_, _ = request.TargetSink.PutBlob(scalar.SHA256Digest(captured.CaptureManifest), uint64(len(captured.CaptureManifest)), bytes.NewReader(captured.CaptureManifest))\n"
            "\t\t// Archive-only output never enters a target branch: the\n"
        ),
        kind="add-write", expect="KILLED",
        note="rev1 P2-α row 8: the projection entry writes the archive capture manifest into the TARGET sink before the G2 refusal.",
    ),
    Mutant(
        name="R1-skip-payload-install-blob-b",
        path=f"{PKG}/capture.go",
        find="\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n\t\t}\n",
        replace=(
            "\t\tif key != \"store/blob-b\" {\n"
            "\t\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n"
            "\t\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n"
            "\t\t\t}\n"
            "\t\t}\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 14: exactly store/blob-b is sealed into the raw manifest without its blob ever being installed.",
    ),
    Mutant(
        name="R1-post-falls-back-to-captured-hash",
        path=f"{PKG}/capture.go",
        find="\t\t\tif !useCaptured {\n\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n\t\t\t\t\tcontinue\n\t\t\t\t}\n\t\t\t}\n",
        replace=(
            "\t\t\tif !useCaptured {\n"
            "\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n"
            "\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t\tfallback := false\n"
            "\t\t\t\tfor _, captured := range state.captured {\n"
            "\t\t\t\t\tif captured.key == member.key {\n"
            "\t\t\t\t\t\trecord.addFile(member.key, captured.descriptor.Size, contentHash(captured.payload))\n"
            "\t\t\t\t\t\tfallback = true\n"
            "\t\t\t\t\t}\n"
            "\t\t\t\t}\n"
            "\t\t\t\tif fallback {\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t}\n"
        ),
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 9: a member unreadable at post time falls back to the captured hash.",
    ),
    Mutant(
        name="R1-clonebundle-unknown-ignores-excluded",
        path="internal/clonebundle/capturebuild.go",
        find="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        replace="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" && item.Included() {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        kind="narrowing", expect="KILLED",
        note="rev1 P2-α row 5 / inherited P3-ε: an EXCLUDED unknown-class item no longer drives raw_complete=false (plant in clonebundle, killer here).",
    ),
    Mutant(
        name="R1-size-equality-is-proof",
        path=f"{PKG}/race.go",
        find="\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n",
        replace=(
            "\tif sizeOnly(preLines) == sizeOnly(postLines) {\n"
            "\t\treturn nil\n"
            "\t}\n"
            "\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n"
        ),
        kind="widening", expect="KILLED",
        note="size equality decides the race (spec: file-size equality is never proof).",
    ),
    Mutant(
        name="R1-hook-after-post-measure",
        path=f"{PKG}/capture.go",
        find="\tstate.pre, state.preLines = state.recordSource(observed, true)\n\tif state.request.Hooks.AfterWalk != nil {\n\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n\t\t}\n\t}\n\treturn state.measurePost()\n",
        replace=(
            "\tstate.pre, state.preLines = state.recordSource(observed, true)\n"
            "\tif err := state.measurePost(); err != nil {\n"
            "\t\treturn err\n"
            "\t}\n"
            "\tif state.request.Hooks.AfterWalk != nil {\n"
            "\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n"
            "\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n"
            "\t\t}\n"
            "\t}\n"
            "\treturn nil\n"
        ),
        kind="seam-control", expect="KILLED",
        note="seam control: the injection hook runs after the post measurement, so every injected mutation lands outside the measured window.",
    ),
    # ---- New rev3 reviewer plants on gates the shipped harness does not mutate ----
    Mutant(
        name="R3-archive-swaps-pre-post",
        path=f"{PKG}/capture.go",
        find=UNSTABLE_BOUNDARY + "\t\t}\n\t}\n",
        replace=(
            "\t\t\tPreCaptureDigest:  state.post.String(),\n"
            "\t\t\tPostCaptureDigest: state.pre.String(),\n"
            "\t\t\tCore:              true,\n"
            "\t\t}\n"
            "\t\tstate.pre, state.post = state.post, state.pre\n"
            "\t}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Row 8 member LABELLING: the unstable_archive form seals the post-capture measurement as pre_capture_digest and the pre-capture measurement as post_capture_digest, and the CaptureResult reports the same swap consistently. Both digests are present but mislabelled; a test needs an oracle independent of the pipeline (the quiet capture's digest of the unmutated fixture) to see it.",
    ),
    Mutant(
        name="R3-archive-policy-always-unstable",
        path=f"{PKG}/capture.go",
        find=CAPTURE_ORDER_PIN,
        replace=(
            "\t// ORDER-PIN: the source-race gate precedes any seal or publish.\n"
            "\t// N-race-order-capture moves this gate after sealAndPublish and\n"
            "\t// the killer reddens on the published manifests.\n"
            "\tif state.request.OnRace == RaceArchive && state.request.OperatorExplicit {\n"
            "\t\treturn state.sealAndPublish(true)\n"
            "\t}\n"
            "\tif err := state.gateSourceRace(); err != nil {\n"
            "\t\treturn state.raceOutcome(err)\n"
            "\t}\n"
            "\treturn state.sealAndPublish(false)\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Row 8 'core-created only for archive-only output': under RaceArchive+OperatorExplicit every capture seals unstable_archive (source_not_quiescent asserted) even when the source was QUIET and the gate would have passed. Measures whether any committed row drives the archive policy over an unmutated store.",
    ),
    Mutant(
        name="R3-post-measure-only-with-hook",
        path=f"{PKG}/capture.go",
        find=MEASURE_POST,
        replace=(
            "func (state *pipeline) measurePost() error {\n"
            "\tif state.request.Hooks.AfterWalk == nil {\n"
            "\t\tstate.post, state.postLines = state.pre, append([]string(nil), state.preLines...)\n"
            "\t\treturn nil\n"
            "\t}\n"
            "\tobserved, err := enumerateStore(state.request.StoreRoot)\n"
            "\tif err != nil {\n"
            "\t\treturn err\n"
            "\t}\n"
            "\tstate.post, state.postLines = state.recordSource(observed, false)\n"
            "\treturn nil\n"
            "}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Row 9/10 measurement axis: the post-capture measurement runs ONLY when the AfterWalk injection seam is present; every hook-less capture (all production captures) reports post == pre without re-reading the store. Measures whether the race window is pinned through anything but the seam.",
    ),
    Mutant(
        name="R3-post-enumerate-failure-as-quiet",
        path=f"{PKG}/capture.go",
        find=MEASURE_POST,
        replace=(
            "func (state *pipeline) measurePost() error {\n"
            "\tobserved, err := enumerateStore(state.request.StoreRoot)\n"
            "\tif err != nil {\n"
            "\t\tstate.post, state.postLines = state.pre, append([]string(nil), state.preLines...)\n"
            "\t\treturn nil\n"
            "\t}\n"
            "\tstate.post, state.postLines = state.recordSource(observed, false)\n"
            "\treturn nil\n"
            "}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Absence-vs-failure-to-read at the POST measurement: a store that cannot be re-enumerated (unreadable subdirectory at post time) is laundered into 'no change' and the capture seals STABLE. Pristine refuses with the enumeration error (rev2 probe P9d); no committed row drives it.",
    ),
    Mutant(
        name="R3-enumerate-unreadable-as-empty",
        path=f"{PKG}/walk.go",
        find=(
            "\t\tentries, err := os.ReadDir(directory)\n"
            "\t\tif err != nil {\n"
            "\t\t\treturn invalid(\"capture cannot enumerate store member %q: %v\", relative, err)\n"
            "\t\t}\n"
        ),
        replace=(
            "\t\tentries, err := os.ReadDir(directory)\n"
            "\t\tif err != nil {\n"
            "\t\t\tif relative != \"\" {\n"
            "\t\t\t\treturn nil\n"
            "\t\t\t}\n"
            "\t\t\treturn invalid(\"capture cannot enumerate store member %q: %v\", relative, err)\n"
            "\t\t}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="Absence-vs-failure-to-read at the WALK: an unreadable store SUBDIRECTORY enumerates as empty instead of refusing ('a member that cannot be listed cannot be captured' is the doc claim), so its planned members read as absent (optional -> plan_optional_absent, sealed stable and raw_complete=true). No committed row drives an unreadable subdirectory.",
    ),
    Mutant(
        name="R3-receipt-profile-unchecked",
        path=f"{PKG}/project.go",
        find=(
            "func BuildAdmissionReceipt(rawManifestID, captureManifestID scalar.Digest, profile string) ([]byte, error) {\n"
            "\tif !validFidelityProfile(profile) {\n"
        ),
        replace=(
            "func BuildAdmissionReceipt(rawManifestID, captureManifestID scalar.Digest, profile string) ([]byte, error) {\n"
            "\tif !validFidelityProfile(profile) && profile != \"ultra\" {\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="The exported BuildAdmissionReceipt entry admits exactly profile ultra into a sealed receipt; AdmitForTarget still refuses it on the composed path. Measures whether the standalone exported entry's profile gate is pinned (P3-η shape: an exported entry advertising a check no test drives).",
    ),
    Mutant(
        name="R3-drop-early-containment-pass",
        path=f"{PKG}/capture.go",
        find=EARLY_PASS,
        replace="",
        kind="arm-delete", expect="SURVIVED?",
        note="ARM-DELETE (labelled): the early containment pass ('this pass fails fast with nothing installed') is removed; every special still refuses at its planned member's Guard open, but payload blobs sorted before the special are installed first. Measures whether the 'nothing installed' claim is pinned for a special member that sorts after an included member.",
    ),
    Mutant(
        name="R3-empty-cwd-as-root",
        path=f"{PKG}/workspace.go",
        find=(
            "\tif cwd == \"\" {\n"
            "\t\treturn \"\", invalid(\"workspace binding cwd_relative is empty\")\n"
            "\t}\n"
        ),
        replace=(
            "\tif cwd == \"\" {\n"
            "\t\tcwd = \".\"\n"
            "\t}\n"
        ),
        kind="narrowing", expect="SURVIVED?",
        note="An EMPTY cwd seals as the workspace root ('.') instead of refusing (rev2 probe P18b: pristine refuses 'cwd_relative is empty'). No committed row supplies an empty cwd.",
    ),
    Mutant(
        name="R3-early-pass-opens-excluded-special",
        path=f"{PKG}/capture.go",
        find=(
            "\t\tif excludedClass(state.plan[member.key].Class) {\n"
            "\t\t\tcontinue\n"
            "\t\t}\n"
            "\t\tif _, err := openMember(state.guard, state.root, member.key, state.limit); err != nil {\n"
        ),
        replace=(
            "\t\tif _, err := openMember(state.guard, state.root, member.key, state.limit); err != nil {\n"
        ),
        kind="arm-delete", expect="SURVIVED?",
        note="ARM-DELETE (labelled, OVER-STRICT direction): an excluded-class SPECIAL member (symlink/FIFO credential) is opened through the Guard and refuses the capture instead of sealing as excluded-never-opened. Measures whether 'excluded members are never opened' is pinned for special shapes (rev2 probe P13a is the only evidence).",
    ),
    Mutant(
        name="R3-nil-target-sink-unchecked",
        path=f"{PKG}/project.go",
        find=(
            "\tif request.TargetSink == nil {\n"
            "\t\treturn nil, invalid(\"capture projection requires a target sink\")\n"
            "\t}\n"
        ),
        replace="",
        kind="arm-delete", expect="SURVIVED?",
        note="ARM-DELETE (labelled): the nil-target-sink refusal is removed; a nil sink would capture, seal and publish, then fault at the receipt PutBlob. rev2 informational (probe P3, no committed test).",
    ),
    Mutant(
        name="R3-archive-not-core",
        path=f"{PKG}/capture.go",
        find=UNSTABLE_BOUNDARY,
        replace=UNSTABLE_BOUNDARY.replace("Core:              true,", "Core:              false,"),
        kind="narrowing", expect="KILLED",
        note="Control for the landed core-only rule reached from this entry: the unstable form is requested without the Core assertion; the landed builder must refuse and the archive rows must redden.",
    ),
    # ---- controls ----
    Mutant(
        name="C-stable-seals-pre-as-post",
        path=f"{PKG}/capture.go",
        find="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.post.String(),\n\t\tInputBlocked:      request.InputBlocked,\n",
        replace="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.pre.String(),\n\t\tInputBlocked:      request.InputBlocked,\n",
        kind="control", expect="SURVIVED",
        note="Equivalence control: on the stable path the gate proved pre == post before the seal, so sealing pre for post_capture_digest is byte-identical and must SURVIVE.",
    ),
    Mutant(
        name="C-rev3-comment",
        path=f"{PKG}/race.go",
        find="// This file owns the source-race record: the canonical digest over\n",
        replace="// This file owns the source-race record (reviewer rev3 control): the canonical digest over\n",
        kind="control", expect="SURVIVED",
        note="Harmless control: a comment-only edit must SURVIVE.",
    ),
]

SIZE_ONLY_HELPER = '''
// sizeOnly (reviewer mutant helper) strips content hashes from a record listing.
func sizeOnly(lines []string) string {
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		if i := strings.LastIndex(line, "\\x00"); i >= 0 {
			line = line[:i]
		}
		out = append(out, line)
	}
	sort.Strings(out)
	return strings.Join(out, "\\n")
}
'''


def run(repo: Path, mutant: Mutant, log_dir: Path, extra_pkgs: list[str]) -> str:
    target = repo / mutant.path
    original = target.read_bytes()
    text = original.decode()
    count = text.count(mutant.find)
    if count != 1:
        line = f"ERROR: {mutant.name}: anchor count {count}, want 1"
        (log_dir / f"{mutant.name}.log").write_text(line + "\n")
        return line
    patched = text.replace(mutant.find, mutant.replace)
    if mutant.name == "R1-size-equality-is-proof":
        patched += SIZE_ONLY_HELPER
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        backup.write_bytes(original)
        try:
            target.write_text(patched)
            started = time.time()
            try:
                proc = subprocess.run(
                    ["go", "test", f"./{PKG}/", *extra_pkgs, "-count=1"],
                    cwd=repo, capture_output=True, text=True, timeout=600,
                )
                output = (proc.stdout + proc.stderr).strip()
                code = proc.returncode
            except subprocess.TimeoutExpired:
                output = "TIMEOUT"
                code = -1
            elapsed = time.time() - started
        finally:
            target.write_bytes(backup.read_bytes())
    if target.read_bytes() != original:
        raise SystemExit(f"restore failed for {mutant.path}")
    if output == "TIMEOUT":
        verdict = "ERROR(timeout)"
    elif "build failed" in output or output.startswith("# ") or "\n# " in output:
        verdict = "ERROR(build)"
    elif code == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        verdict = f"ERROR(exit {code})"
    killers = sorted({l.split()[2] for l in output.splitlines() if l.startswith("--- FAIL")})
    line = f"{mutant.name}: {verdict} (expect {mutant.expect}) kind={mutant.kind} exit={code} elapsed={elapsed:.1f}s killers={','.join(killers) or '-'} :: {mutant.note}"
    (log_dir / f"{mutant.name}.log").write_text(
        f"# mutant={mutant.name} path={mutant.path} kind={mutant.kind} expect={mutant.expect}\n# exit={code} elapsed={elapsed:.1f}s verdict={verdict}\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{output}\n"
    )
    return line


def main(argv):
    repo = Path("candidate")
    log_dir = Path("logs/mutants/run")
    names = []
    i = 0
    while i < len(argv):
        if argv[i] == "--repo":
            repo = Path(argv[i + 1]); i += 2
        elif argv[i] == "--log-dir":
            log_dir = Path(argv[i + 1]); i += 2
        else:
            names.append(argv[i]); i += 1
    log_dir.mkdir(parents=True, exist_ok=True)
    selected = [m for m in MUTANTS if not names or m.name in names]
    for m in selected:
        extra: list[str] = []  # the killer suite is always internal/clonesnap, also for the clonebundle plant
        print(run(repo.resolve(), m, log_dir, extra), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
