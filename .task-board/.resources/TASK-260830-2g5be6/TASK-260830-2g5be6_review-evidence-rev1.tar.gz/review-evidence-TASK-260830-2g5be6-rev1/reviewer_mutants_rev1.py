#!/usr/bin/env python3
"""Reviewer narrowing-mutant battery for CR-TASK-260830-2g5be6-1.

Each row patches ONE production file in the isolated `mut/` copy of the
exact candidate tree, runs the WHOLE committed internal/clonesnap suite
(go test ./internal/clonesnap/ -count=1), records the raw output with the
subprocess exit, and restores the file from a byte copy. Verdicts:
KILLED iff the suite fails with a FAIL line; SURVIVED iff exit 0; ERROR
otherwise (unapplied anchor, build break, timeout).

Usage: PYTHONDONTWRITEBYTECODE=1 python3 reviewer_mutants_rev1.py --repo mut --log-dir logs/mutants/run1
"""

import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

PKG = "internal/clonesnap"


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    kind: str  # narrowing | add-write | control | widening
    note: str


MUTANTS = [
    Mutant(
        name="R1-blockedAncestor-optional",
        path=f"{PKG}/capture.go",
        find="\t\tif !present && !item.Required && !blockedAncestor(byKey, key) {\n",
        replace="\t\tif !present && !item.Required {\n",
        kind="narrowing",
        note="An OPTIONAL member behind a symlinked/special intermediate seals as plan_optional_absent instead of reaching the Guard refusal; required members still route to the Guard.",
    ),
    Mutant(
        name="R1-excluded-bytes-into-blob",
        path=f"{PKG}/capture.go",
        find="\t\tif excludedClass(item.Class) {\n\t\t\tstate.log.Linef(\"exclude member=%q class=%s reason=%s\", key, item.Class, exclusionReason(item.Class))\n\t\t\tcontinue\n\t\t}\n",
        replace=(
            "\t\tif excludedClass(item.Class) {\n"
            "\t\t\tstate.log.Linef(\"exclude member=%q class=%s reason=%s\", key, item.Class, exclusionReason(item.Class))\n"
            "\t\t\tif leaked, leakErr := openMember(state.guard, state.root, key, state.limit); leakErr == nil {\n"
            "\t\t\t\tif leakDescriptor, descErr := BuildBlobDescriptor(leaked); descErr == nil {\n"
            "\t\t\t\t\t_, _ = clonebundle.InstallRawBlob(state.request.Store, leakDescriptor.Descriptor, bytes.NewReader(leaked))\n"
            "\t\t\t\t}\n"
            "\t\t\t}\n"
            "\t\t\tcontinue\n"
            "\t\t}\n"
        ),
        kind="add-write",
        note="Opens an always-excluded member and installs its bytes as an orphan blob (no manifest entry, no log line). Measures whether the blob scan in TestCaptureExcludesSecrets is load-bearing.",
    ),
    Mutant(
        name="R1-size-equality-is-proof",
        path=f"{PKG}/race.go",
        find="\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n",
        replace=(
            "\tif sizeOnly(preLines) == sizeOnly(postLines) {\n"
            "\t\treturn nil\n"
            "\t}\n"
            "\tif err := clonebundle.CheckDigestsEqual(pre, post); err != nil {\n"
        ),
        kind="widening",
        note="Size equality decides the race: when every (key, kind, size) agrees the gate passes without comparing content hashes. The spec clause 'file-size equality is never proof'.",
    ),
    Mutant(
        name="R1-archive-seals-stable",
        path=f"{PKG}/capture.go",
        find="\treturn state.sealAndPublish(true)\n",
        replace="\treturn state.sealAndPublish(false)\n",
        kind="narrowing",
        note="The archive path seals the STABLE form (pre digest for both) after a detected mutation with explicit acknowledgement.",
    ),
    Mutant(
        name="R1-archive-emits-receipt",
        path=f"{PKG}/project.go",
        find="\t\t// Archive-only output never enters a target branch: the\n",
        replace=(
            "\t\t_, _ = request.TargetSink.PutBlob(scalar.SHA256Digest(captured.CaptureManifest), uint64(len(captured.CaptureManifest)), bytes.NewReader(captured.CaptureManifest))\n"
            "\t\t// Archive-only output never enters a target branch: the\n"
        ),
        kind="add-write",
        note="The projection entry writes the archive capture manifest into the TARGET sink before the G2 refusal. Measures whether 'archive output never reaches the target sink' is pinned at the sink, not only at the error.",
    ),
    Mutant(
        name="R1-skip-payload-install-blob-b",
        path=f"{PKG}/capture.go",
        find="\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n\t\t}\n",
        replace=(
            "\t\tif key != \"store/blob-b\" {\n"
            "\t\t\tif _, err := clonebundle.InstallRawBlob(state.request.Store, descriptor.Descriptor, bytes.NewReader(payload)); err != nil {\n"
            "\t\t\t\treturn invalid(\"capture member %q: %v\", key, err)\n"
            "\t\t\t}\n"
            "\t\t}\n"
        ),
        kind="narrowing",
        note="Exactly store/blob-b is sealed into the raw manifest without its blob ever being installed. Measures whether payload-blob installation (10.2 'before publishing a record that references a blob') is pinned by the committed suite.",
    ),
    Mutant(
        name="R1-post-falls-back-to-captured-hash",
        path=f"{PKG}/capture.go",
        find="\t\t\tif !useCaptured {\n\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n\t\t\t\t\tcontinue\n\t\t\t\t}\n\t\t\t}\n",
        replace=(
            "\t\t\tif !useCaptured {\n"
            "\t\t\t\tif payload, err := openMember(state.guard, state.root, member.key, state.limit); err == nil {\n"
            "\t\t\t\t\trecord.addFile(member.key, uint64(len(payload)), contentHash(payload))\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t\tfallback := false\n"
            "\t\t\t\tfor _, captured := range state.captured {\n"
            "\t\t\t\t\tif captured.key == member.key {\n"
            "\t\t\t\t\t\trecord.addFile(member.key, captured.descriptor.Size, contentHash(captured.payload))\n"
            "\t\t\t\t\t\tfallback = true\n"
            "\t\t\t\t\t}\n"
            "\t\t\t\t}\n"
            "\t\t\t\tif fallback {\n"
            "\t\t\t\t\tcontinue\n"
            "\t\t\t\t}\n"
            "\t\t\t}\n"
        ),
        kind="narrowing",
        note="A member that cannot be re-read at post time (retyped to a symlink/special, permission lost) falls back to the captured hash instead of unknown content, so the race is missed for exactly the unreadable-at-post class.",
    ),
    Mutant(
        name="R1-hook-after-post-measure",
        path=f"{PKG}/capture.go",
        find="\tstate.pre, state.preLines = state.recordSource(observed, true)\n\tif state.request.Hooks.AfterWalk != nil {\n\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n\t\t}\n\t}\n\treturn state.measurePost()\n",
        replace=(
            "\tstate.pre, state.preLines = state.recordSource(observed, true)\n"
            "\tif err := state.measurePost(); err != nil {\n"
            "\t\treturn err\n"
            "\t}\n"
            "\tif state.request.Hooks.AfterWalk != nil {\n"
            "\t\tif err := state.request.Hooks.AfterWalk(state.request.StoreRoot); err != nil {\n"
            "\t\t\treturn invalid(\"capture hook refused after the walk: %v\", err)\n"
            "\t\t}\n"
            "\t}\n"
            "\treturn nil\n"
        ),
        kind="narrowing",
        note="Seam control: the injection hook runs after the post measurement, so every injected mutation lands outside the measured window. Proves the race suite depends on the seam it names.",
    ),
    Mutant(
        name="R1-descriptor-media-uppercase",
        path=f"{PKG}/descriptor.go",
        find='\tblobMediaType = "application/octet-stream"\n',
        replace='\tblobMediaType = "Application/Octet-Stream"\n',
        kind="narrowing",
        note="Descriptor media_type violates the lowercase rule; measures that the landed canonicaljson closed-shape validator is in the descriptor path.",
    ),
    Mutant(
        name="R1-unstable-not-core",
        path=f"{PKG}/capture.go",
        find="\t\t\tCore:              true,\n",
        replace="\t\t\tCore:              false,\n",
        kind="narrowing",
        note="The unstable form is built without the core flag; measures that the landed core-only construction rule is enforced through the capture entry.",
    ),
    Mutant(
        name="R1-publish-under-manifest-id",
        path=f"{PKG}/capture.go",
        find="\trawPut, err := request.Store.PutBlob(scalar.SHA256Digest(rawBytes), uint64(len(rawBytes)), bytes.NewReader(rawBytes))\n",
        replace="\trawPut, err := request.Store.PutBlob(raw.ManifestID, uint64(len(rawBytes)), bytes.NewReader(rawBytes))\n",
        kind="narrowing",
        note="Publishes the raw manifest under its omit-self identity instead of the digest of its sealed bytes; measures that the store verifies the digest of what it installs.",
    ),
    Mutant(
        name="R1-oversize-boundary-off-by-one",
        path=f"{PKG}/walk.go",
        find="\tif uint64(info.Size()) > limit {\n",
        replace="\tif uint64(info.Size()) > limit+1 {\n",
        kind="narrowing",
        note="Admits exactly limit+1 bytes: the far edge of the single-object bound (TestCaptureRefusesOversizedMember pins 11 and 12 under a 10-byte bound).",
    ),
    Mutant(
        name="R1-stable-seals-post-as-pre",
        path=f"{PKG}/capture.go",
        find="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.pre.String(),\n",
        replace="\t\tPreCaptureDigest:  state.pre.String(),\n\t\tPostCaptureDigest: state.post.String(),\n",
        kind="control",
        note="Equivalence control: sealing the measured post digest instead of the pre digest for post_capture_digest. Under the gate the two are equal, so this must SURVIVE; it also refutes the doc claim that this variant 'would fail closed under a reorder and leave the ordering unpinned' only if the ordering rows still kill (checked separately).",
    ),
    Mutant(
        name="R1-clonebundle-unknown-ignores-excluded",
        path="internal/clonebundle/capturebuild.go",
        find="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        replace="\tfor _, item := range items {\n\t\tif item.Class == \"unknown\" && item.Included() {\n\t\t\treturn true\n\t\t}\n\t}\n\treturn false\n}\n",
        kind="narrowing",
        note="Inherited P3-ε re-planted at the landed site: an EXCLUDED unknown-class item no longer drives raw_complete=false nor blocks maximal_safe. Run against the clonesnap suite to measure whether this leaf closed the gap.",
    ),
    Mutant(
        name="C-rev1-comment",
        path=f"{PKG}/walk.go",
        find="// This file owns the contained capture walk over a provider store\n",
        replace="// This file owns the contained capture walk over a provider store (reviewer control)\n",
        kind="control",
        note="Harmless control: a comment-only edit must SURVIVE.",
    ),
]

SIZE_ONLY_HELPER = '''
// sizeOnly (reviewer mutant helper) strips content hashes from a record listing.
func sizeOnly(lines []string) string {
	out := make([]string, 0, len(lines))
	for _, line := range lines {
		if i := strings.LastIndex(line, "\\x00"); i >= 0 {
			line = line[:i]
		}
		out = append(out, line)
	}
	sort.Strings(out)
	return strings.Join(out, "\\n")
}
'''


def run(repo: Path, mutant: Mutant, log_dir: Path) -> str:
    target = repo / mutant.path
    original = target.read_bytes()
    text = original.decode()
    count = text.count(mutant.find)
    if count != 1:
        line = f"ERROR: {mutant.name}: anchor count {count}, want 1"
        (log_dir / f"{mutant.name}.log").write_text(line + "\n")
        return line
    patched = text.replace(mutant.find, mutant.replace)
    if mutant.name == "R1-size-equality-is-proof":
        patched += SIZE_ONLY_HELPER
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        backup.write_bytes(original)
        try:
            target.write_text(patched)
            started = time.time()
            try:
                proc = subprocess.run(
                    ["go", "test", f"./{PKG}/", "-count=1"],
                    cwd=repo, capture_output=True, text=True, timeout=600,
                )
                output = (proc.stdout + proc.stderr).strip()
                code = proc.returncode
            except subprocess.TimeoutExpired:
                output = "TIMEOUT"
                code = -1
            elapsed = time.time() - started
        finally:
            target.write_bytes(backup.read_bytes())
    if target.read_bytes() != original:
        raise SystemExit(f"restore failed for {mutant.path}")
    if output == "TIMEOUT":
        verdict = "ERROR(timeout)"
    elif "build failed" in output or output.startswith("# ") or "\n# " in output:
        verdict = "ERROR(build)"
    elif code == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        verdict = f"ERROR(exit {code})"
    killers = sorted({l.split()[2] for l in output.splitlines() if l.startswith("--- FAIL")})
    line = f"{mutant.name}: {verdict} kind={mutant.kind} exit={code} elapsed={elapsed:.1f}s killers={','.join(killers) or '-'} :: {mutant.note}"
    (log_dir / f"{mutant.name}.log").write_text(
        f"# mutant={mutant.name} path={mutant.path} kind={mutant.kind}\n# exit={code} elapsed={elapsed:.1f}s verdict={verdict}\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{output}\n"
    )
    return line


def main(argv):
    repo = Path("mut")
    log_dir = Path("logs/mutants/run")
    names = []
    i = 0
    while i < len(argv):
        if argv[i] == "--repo":
            repo = Path(argv[i + 1]); i += 2
        elif argv[i] == "--log-dir":
            log_dir = Path(argv[i + 1]); i += 2
        else:
            names.append(argv[i]); i += 1
    log_dir.mkdir(parents=True, exist_ok=True)
    selected = [m for m in MUTANTS if not names or m.name in names]
    for m in selected:
        print(run(repo.resolve(), m, log_dir), flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
