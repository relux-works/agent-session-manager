TASK-260830-32jeti round-5 review probe pack.

mutate.py                              harness (plant once, run, cp-restore, sha256-verify)
probe_widen.json                       14 rows: 9 closed-vocabulary widenings + 5 required-list drops
probe_failclosed.json                  4 rows: derivation fail-closed attacks (V1/V2/V3) + %v collision (V4)
k6fix.json                             K6 with the corrected file path (manifest.go, not probe.go)
review-round5-widening-probe_test.go.txt
                                       the fixture the suite is missing. Drop it in as
                                       internal/provhost/zz_reviewprobe_test.go, then:
                                         python3 mutate.py probe_widen.json      # 9 SURVIVED against the shipped suite
                                         # with the probe file present, run with "run":"TestReviewProbe":
                                         #   the same 9 go RED -> the widening is a real acceptance, not a no-op

Measured at candidate tree ca45ddf611c18ca58d573e6e13f5238904f109a8.
