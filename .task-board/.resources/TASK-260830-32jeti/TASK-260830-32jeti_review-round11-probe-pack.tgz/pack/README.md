Round-11 (CR rev 9) reviewer probe pack — TASK-260830-32jeti

Candidate tree b63faae75f0e85b54f2544645e2ba05841fa79f0, base 2512f2087bcea43481f8541ee780f11daeececd4.
Run from the story worktree .temp/STORY-260830-3jqsx1/worktree.

Contents
  reproduce.sh                       every check in the verdict, in order
  go-test-all.log                    go test ./... -count=1  (16 ok, 0 FAIL)
  m-a2-windows-vet-mutated.log       GOOS=windows go vet ./... with the scratch probe present -> exit 1
  m-a2-windows-vet-restored.log      same, probe removed -> exit 0 (empty)

Mutants
  M-A1  NARROWING. internal/terminalbackend/terminalbackend.go:625
        `if !info.Mode().IsRegular()` -> `if info.Mode().IsDir()`
        Guard stays present; refusal string `not a regular file` preserved;
        narrowed to admit exactly FIFOs.
        Expected: TestDigestFile PASS (directory case cannot see the narrowing,
        os.ReadFile rejects directories on its own), TestDigestFileRefusesFIFO
        FAILs by blocking in os.ReadFile on the FIFO -> package FAIL at -timeout.
        Observed stack: terminalbackend_unix_test.go:28 -> DigestFile
        (terminalbackend.go:628).

  M-A2  GATE LIVENESS. Adds a scratch _test.go in internal/terminalbackend
        referencing syscall.Mkfifo with no build constraint.
        Expected: GOOS=windows go vet ./... exit 1 (proves the CI step compiles
        _test.go files and is not a no-op on this tree); exit 0 once removed.

After each mutant the file was restored and the live worktree tree OID
re-verified as b63faae75f0e85b54f2544645e2ba05841fa79f0.
