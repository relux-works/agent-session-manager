#!/bin/sh
# Round-11 reviewer probes. Run from the story worktree root.
set -u
CAND=b63faae75f0e85b54f2544645e2ba05841fa79f0
BASE=2512f2087bcea43481f8541ee780f11daeececd4
REV8=39853bf3acf148b62307a382e29677b9ed3c6c23
REV7=3817cef48c266f4158370d84db95936fa58dd4ab

live_tree() {
  GIT_INDEX_FILE=$(mktemp -t livetreeXXXX); export GIT_INDEX_FILE
  git read-tree HEAD && git add -A -- . >/dev/null 2>&1 && git write-tree
  rm -f "$GIT_INDEX_FILE"; unset GIT_INDEX_FILE
}

echo "## provenance"
echo "live tree: $(live_tree)  (want $CAND)"
git diff --name-status "$REV8" "$CAND"                       # want exactly 3 paths
git diff --stat "$REV7" "$CAND" -- internal/provider internal/provhost .github   # want empty

echo "## gates"
go build ./...;               echo "build EXIT=$?"
go vet ./...;                 echo "vet EXIT=$?"
GOOS=linux   go vet ./...;    echo "linux vet EXIT=$?"
GOOS=windows go vet ./...;    echo "windows vet EXIT=$?"
gofmt -l internal/;           echo "gofmt EXIT=$?"
go test ./... -count=1;       echo "suite EXIT=$?"
go run ./internal/traceability/cmd/tracecheck -root .; echo "tracecheck EXIT=$?"

echo "## coverage did not leave the build"
go test ./internal/terminalbackend/ -list '.*' | grep -cE '^(Test|Fuzz|Example)'   # want 99
go test ./internal/terminalbackend/ -list '.*' | grep -c '^TestDigestFileRefusesFIFO$'  # want 1
go list -f 'host xtest={{len .XTestGoFiles}}' ./internal/terminalbackend/          # want 4
GOOS=linux   go list -f 'linux xtest={{len .XTestGoFiles}}'   ./internal/terminalbackend/  # want 4
GOOS=windows go list -f 'windows xtest={{len .XTestGoFiles}}' ./internal/terminalbackend/  # want 3

echo "## M-A1 narrowing mutant"
SRC=internal/terminalbackend/terminalbackend.go
cp -p "$SRC" /tmp/ma1.bak
perl -0pi -e 's/\tif !info\.Mode\(\)\.IsRegular\(\) \{/\tif info.Mode().IsDir() {/' "$SRC"
go test ./internal/terminalbackend/ -run 'TestDigestFile$|TestDigestFileRefusesFIFO$' -v -count=1 -timeout 25s
echo "M-A1 EXIT=$?  (want non-zero: TestDigestFile PASS, FIFO test times out in DigestFile)"
cp -p /tmp/ma1.bak "$SRC"
echo "restored tree: $(live_tree)  (want $CAND)"

echo "## M-A2 gate liveness"
cat > internal/terminalbackend/zz_scratch_probe_test.go <<'GO'
package terminalbackend_test

import (
	"syscall"
	"testing"
)

func TestScratchProbeUnconstrained(t *testing.T) {
	_ = syscall.Mkfifo
}
GO
GOOS=windows go vet ./...; echo "M-A2 EXIT=$?  (want 1)"
rm -f internal/terminalbackend/zz_scratch_probe_test.go
GOOS=windows go vet ./...; echo "restored EXIT=$?  (want 0)"
echo "restored tree: $(live_tree)  (want $CAND)"
