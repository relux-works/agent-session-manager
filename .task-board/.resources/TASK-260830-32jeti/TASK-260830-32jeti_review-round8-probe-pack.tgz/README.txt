TASK-260830-32jeti round-8 review probe pack.
Measured at candidate tree f926d104ab88f04d6b8a5c96931eb7518e1245a8
(worktree content verified byte-identical to the CR rev-6 candidate tree
before and after every mutant run).

Harness
  mutate.py        plant one mutant, run, cp-restore, sha256-verify restore
                   usage: python3 mutate.py <spec>.json
                   (ROOT is hardcoded to the story worktree)

Specs
  reanchor.json    10 rows: the two round-7 NOT_APPLIED census anchors
                   re-anchored to the rev-6 source, four new runner
                   narrowings against the round-8 F1 fix, two new
                   foreign-major narrowings against the round-8 F3 fix,
                   and the two surrogate pair-boundary narrowings that
                   are finding F1 of this round.
  rn7a.json        RN6 (WaitDelay 600s); run with RN4 already planted by
                   hand to get the combined RN7.
  rn89.json        RN8 (collectDrains unbounded) and RN9 (wait-select
                   ctx.Done branch made unreachable).

out/               every battery log from this round. b1..b7, k6fix,
                   probe_widen, probe_failclosed, census3 and supp are
                   replays of the round-4..7 batteries; reanchor.log is
                   this round's new rows.

probes/            drop each into internal/provhost/ as a _test.go file
  zz_reviewsgc_test.go.txt          F1: the two pair-boundary vectors the
                                    derived sweep never generates
  zz_reviewselfdetach_test.go.txt   A2: why the Kill backstop branch is
                                    unreachable on unix
