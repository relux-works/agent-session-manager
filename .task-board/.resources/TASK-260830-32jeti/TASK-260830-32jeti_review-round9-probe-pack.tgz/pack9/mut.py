import json,shutil,subprocess,sys,tempfile,os
spec=json.load(open(sys.argv[1]))
for m in spec:
    f=m["file"]; bak=tempfile.mktemp(); shutil.copy(f,bak)
    s=open(f).read(); c=s.count(m["old"])
    if c!=1:
        print(f'{m["id"]:34s} NOT_APPLIED anchor_count={c}'); os.remove(bak); continue
    open(f,"w").write(s.replace(m["old"],m["new"]))
    try:
        r=subprocess.run(["go","test",m.get("pkg","./internal/provhost/"),"-run",m["pat"],"-count=1"],
                         capture_output=True,text=True,timeout=540)
    finally:
        shutil.copy(bak,f); os.remove(bak)
    out=r.stdout+r.stderr
    if "build failed" in out or "[build" in out:
        st="NOT_APPLIED build"
    elif r.returncode!=0:
        st="KILLED"
    else:
        st="SURVIVED"
    fails=[l for l in out.splitlines() if l.startswith("--- FAIL") or l.startswith("    --- FAIL")][:3]
    print(f'{m["id"]:34s} {st:18s} {" ".join(x.strip() for x in fails)[:160]}')
