TASK-260830-32jeti round-9 review probe pack.
Measured at candidate tree 3817cef48c266f4158370d84db95936fa58dd4ab
(worktree verified byte-identical by git write-tree over a temporary
index before the first mutant and after every battery).

mut.py        reviewer harness: plant one mutant, run, restore.
              usage: python3 mut.py <spec>.json   (run from the worktree root)
spec1.json    22 surrogate-gate mutants: all four range constants moved in
              both directions (M1-M8), the predicate narrowings (SGC, SGJ,
              SGK, SGL, SGM, SGN), the arm/hex narrowings (SGP, SGP2, SGQ,
              SGQ2, SGR, SGS), and the two gate deletions (SGT, SGW).
              21 KILLED, 1 SURVIVED (SGU, a panic-vs-refuse shape, not a
              gate weakening -- stated as a bound in the verdict).
spec2.json    SG3r (round-8 SG3 re-anchored to the rev7 constants, KILLED)
              and the A3 contrast pair: AL2 direct constructor -> KILLED,
              AL1 aliased constructor -> SURVIVED.
out/          every battery log replayed this round (b1..b7, k6fix,
              probe_widen, probe_failclosed, census3, supp, reanchor,
              rn7a, rn89) using the round-8 harness.
