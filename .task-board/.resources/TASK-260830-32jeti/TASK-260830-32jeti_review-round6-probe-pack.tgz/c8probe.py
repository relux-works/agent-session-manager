#!/usr/bin/env python3
import json, collections
from mutate import run_mutant
m = json.load(open("c8only.json"))[0]
tally = collections.Counter(); fails = collections.Counter()
for i in range(24):
    r = run_mutant(m["id"], m["file"], m["old"], m["new"], m.get("run"))
    tally[r["result"]] += 1
    for f in r.get("fails", []): fails[f.strip().split(" (")[0]] += 1
print("tally:", dict(tally))
print("failing tests:", dict(fails))
