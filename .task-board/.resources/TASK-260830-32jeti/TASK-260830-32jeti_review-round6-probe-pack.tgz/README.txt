TASK-260830-32jeti round-6 review probe pack.
Measured at candidate tree aa190969ba39fee5234fbb10bbff2af68441c5a0.

Harness (from the round-5 pack, unchanged):
  mutate.py            plant one mutant, run, cp-restore, sha256-verify
  repeat.py            run a spec N times and tally results (map-iteration rule)
                       usage: python3 repeat.py <spec>.json <reps>

F1 — switch-shaped closed vocabularies the census cannot see:
  census.json          C1..C7  (C1, C2 SURVIVE = the finding; C3..C7 kill the census itself)
  census2.json         C8..C10 (C8 SURVIVES = the finding; C9 proves build-tagged files are scanned)
  stability.json       C1/C2/C8 for repeat.py; observed 12/12, 12/12, 22/24 SURVIVED
  c8only.json          C8 alone, for characterising its nondeterministic "kill"
  census_probe.json    C1/C2/C8 run against the probe fixture below; all three KILLED,
                       which is what proves the widenings are real acceptances

  review-round6-switch-vocab-probe_test.go.txt
                       drop in as internal/provhost/zz_reviewprobe_test.go.
                       Shipped tree: all three REFUSE. With the matching mutant: ACCEPT.

  enum_vars.go         independent denominator: AST walk of every package-level
                       var/const/type in the 15 non-test files.
                       usage: go run enum_vars.go ./internal/provhost

F2 — ExecRunner discards a judged result on a stdin EPIPE:
  review-round6-runner-race-probe_test.go.txt
                       drop in as internal/provhost/zz_runnerrace_test.go.
                       Observed across two runs:
                         valid frame discarded   10/400 and 2/300
                         crash misclassified     32/400 and 6/300

G-B replay (round-5 pack, unchanged; results in the verdict):
  r4/b1 b1b b2 b2r b3 b4 b5 b6 b7   122 rows -> 120 killed, 2 stated bounds
  probe_widen.json                   14 rows -> 12 killed, R1/R3 stated bounds
  probe_failclosed.json               4 rows -> 4 killed
  k6fix.json                          1 row  -> killed
