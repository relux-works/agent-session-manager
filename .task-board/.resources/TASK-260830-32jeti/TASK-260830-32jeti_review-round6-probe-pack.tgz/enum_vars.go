//go:build ignore
package main

import (
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

func main() {
	dir := os.Args[1]
	entries, _ := os.ReadDir(dir)
	fs := token.NewFileSet()
	type decl struct{ file, name, kind, typ string }
	var out []decl
	for _, e := range entries {
		n := e.Name()
		if e.IsDir() || !strings.HasSuffix(n, ".go") || strings.HasSuffix(n, "_test.go") {
			continue
		}
		src, _ := os.ReadFile(filepath.Join(dir, n))
		f, err := parser.ParseFile(fs, n, src, 0)
		if err != nil { panic(err) }
		for _, d := range f.Decls {
			g, ok := d.(*ast.GenDecl)
			if !ok { continue }
			if g.Tok != token.VAR && g.Tok != token.CONST && g.Tok != token.TYPE { continue }
			for _, s := range g.Specs {
				switch v := s.(type) {
				case *ast.ValueSpec:
					t := v.Type
					if t == nil && len(v.Values) == 1 {
						if lit, ok := v.Values[0].(*ast.CompositeLit); ok { t = lit.Type }
					}
					ts := "<inferred>"
					if t != nil {
						var b strings.Builder
						printType(&b, t)
						ts = b.String()
					}
					for _, nm := range v.Names {
						out = append(out, decl{n, nm.Name, g.Tok.String(), ts})
					}
				case *ast.TypeSpec:
					var b strings.Builder
					printType(&b, v.Type)
					out = append(out, decl{n, v.Name.Name, "type", b.String()})
				}
			}
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].file != out[j].file { return out[i].file < out[j].file }
		return out[i].name < out[j].name
	})
	for _, d := range out {
		fmt.Printf("%-22s %-6s %-32s %s\n", d.file, d.kind, d.name, d.typ)
	}
}

func printType(b *strings.Builder, e ast.Expr) {
	switch t := e.(type) {
	case *ast.Ident:
		b.WriteString(t.Name)
	case *ast.ArrayType:
		b.WriteString("[")
		if t.Len != nil { b.WriteString("N") }
		b.WriteString("]")
		printType(b, t.Elt)
	case *ast.MapType:
		b.WriteString("map[")
		printType(b, t.Key)
		b.WriteString("]")
		printType(b, t.Value)
	case *ast.StructType:
		b.WriteString("struct{...}")
	case *ast.SelectorExpr:
		printType(b, t.X); b.WriteString("."); b.WriteString(t.Sel.Name)
	case *ast.StarExpr:
		b.WriteString("*"); printType(b, t.X)
	case *ast.InterfaceType:
		b.WriteString("interface{...}")
	case *ast.FuncType:
		b.WriteString("func(...)")
	default:
		b.WriteString(fmt.Sprintf("%T", e))
	}
}
