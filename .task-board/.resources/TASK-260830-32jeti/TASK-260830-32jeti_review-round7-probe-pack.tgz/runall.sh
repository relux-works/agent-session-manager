#!/bin/sh
set -e
W=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/rev5-review
cd $W
for b in pack6/r4/b1.json pack6/r4/b1b.json pack6/r4/b2.json pack6/r4/b2r.json pack6/r4/b3.json pack6/r4/b4.json pack6/r4/b5.json pack6/r4/b6.json pack6/r4/b7.json pack6/k6fix.json pack6/probe_widen.json pack6/probe_failclosed.json; do
  n=$(basename $b .json)
  echo "### $n"
  python3 mutate.py $b > out/$n.log 2>&1 || echo "RUNNER ERROR $n"
  tail -2 out/$n.log
done
echo "### ALL DONE"
