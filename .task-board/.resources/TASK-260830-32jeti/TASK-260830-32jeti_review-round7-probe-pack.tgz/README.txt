TASK-260830-32jeti round-7 review probe pack.
Measured at candidate tree a72c56666ff528db446884c5708af94b3940fe7b.

Harness (unchanged from the round-5/6 packs):
  mutate.py   plant one mutant, run, cp-restore, sha256-verify
  repeat.py   run a spec N times and tally (map-iteration / flake rule)
              usage: python3 repeat.py <spec>.json <reps>
  runall.sh   the nine round-4 batches + k6fix + the round-5 probe packs
  runsupp.sh  census3.json + supp.json

Specs:
  census3.json   C1r/C2r/C8r re-anchored to the new maps (all KILLED = round-6 F1 closed),
                 C1floor-r (SURVIVED, equivalent mutant), C4..C7/C9/C10 (KILLED)
  supp.json      PR2r/PR4r re-anchored profile mutants (KILLED);
                 SG1..SG5 surrogate-gate narrowings (SG1, SG5 SURVIVE = finding F2);
                 SW1 unclassified switch (KILLED) / SW2 type switch (SURVIVED = bound);
                 RN1..RN3 runner narrowings (RN1/RN2 SURVIVED, RN3 hangs the suite)
  repeat1.json   SG1, SG5, SW2, RN2 x6 -- all SURVIVED 6/6

Probes (drop each into internal/provhost/ as a _test.go file):
  probes/zz_reviewhang_test.go.txt        F1: detached grandchild holds stdout, 500ms deadline
  probes/zz_reviewgc_test.go.txt          F1: 12-call rate measurement, sleep 6 grandchild
  probes/zz_reviewf2_test.go.txt          F1/F2: deterministic stdin EPIPE + grandchild scaling
  probes/zz_reviewsurrogate_test.go.txt   F2: derived 201,548-vector sweep, gate vs canonicaljson
  probes/zz_reviewsg5_test.go.txt         F2: uppercase-hex sweep (473 divergences under SG5)
  probes/zz_reviewidentity_test.go.txt    G-C A2: 32-vector CheckIdentity vs CalculateObjectIdentity
  probes/zz_reviewv3_test.go.txt          F3: 3.x envelope classification
  probes/zz_reviewv3b_test.go.txt         F3: clean vs v3-shaped envelopes
  probes/zz_reviewstamp_test.go.txt       helper for the grandchild probes

out/  every battery log from this round.
