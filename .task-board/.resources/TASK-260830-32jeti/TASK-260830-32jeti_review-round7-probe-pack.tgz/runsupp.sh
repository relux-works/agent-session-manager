#!/bin/sh
W=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/rev5-review
cd $W
for b in census3 supp; do
  echo "### $b"
  python3 mutate.py $b.json > out/$b.log 2>&1 || echo "RUNNER ERROR $b"
  tail -2 out/$b.log
done
echo "### SUPP DONE"
