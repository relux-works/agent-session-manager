#!/usr/bin/env python3
import json, sys, collections
from mutate import run_mutant
spec = json.load(open(sys.argv[1]))
reps = int(sys.argv[2])
for m in spec:
    tally = collections.Counter()
    for _ in range(reps):
        r = run_mutant(m["id"], m["file"], m["old"], m["new"], m.get("run"))
        tally[r["result"]] += 1
    print(f'{m["id"]}: ' + ", ".join(f"{k}={v}" for k, v in sorted(tally.items())) + f"  (n={reps})", flush=True)
