#!/usr/bin/env python3
"""Mutation harness: apply one narrowing mutant, run a targeted test, restore."""
import hashlib, os, shutil, subprocess, sys, json

ROOT = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3jqsx1/worktree"

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()

def run_mutant(mid, relpath, old, new, testexpr, pkg="./internal/provhost/"):
    path = os.path.join(ROOT, relpath)
    backup = path + ".reviewbak"
    shutil.copy2(path, backup)
    before = sha(path)
    try:
        src = open(path).read()
        n = src.count(old)
        if n != 1:
            return {"id": mid, "result": "NOT_APPLIED", "occurrences": n}
        open(path, "w").write(src.replace(old, new))
        after = sha(path)
        if after == before:
            return {"id": mid, "result": "NOT_APPLIED", "occurrences": n}
        cmd = ["go", "test", pkg, "-count=1"]
        if testexpr:
            cmd += ["-run", testexpr]
        proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=540)
        killed = proc.returncode != 0
        fails = [l for l in proc.stdout.splitlines() if l.startswith("--- FAIL") or l.startswith("    --- FAIL")]
        return {"id": mid, "result": "KILLED" if killed else "SURVIVED",
                "exit": proc.returncode, "fails": fails[:6],
                "build_err": proc.stderr.strip().splitlines()[:4]}
    finally:
        shutil.copy2(backup, path)
        os.remove(backup)
        assert sha(path) == before, f"restore failed for {relpath}"

if __name__ == "__main__":
    spec = json.load(open(sys.argv[1]))
    out = []
    for m in spec:
        r = run_mutant(m["id"], m["file"], m["old"], m["new"], m.get("run"))
        out.append(r)
        print(json.dumps(r), flush=True)
    print("=== SUMMARY ===")
    print(f"killed={sum(1 for r in out if r['result']=='KILLED')} survived={sum(1 for r in out if r['result']=='SURVIVED')} notapplied={sum(1 for r in out if r['result']=='NOT_APPLIED')} total={len(out)}")
