#!/usr/bin/env python3
"""Reviewer mutation runner for TASK-260830-24z2b3 rev4.

Loads the producer's Mutant type from the shipped harness (import, no copy),
re-plants every rev3 reviewer SURVIVOR on the rev4 tree, adds the rev4
reviewer plants (arms the producer did not mutate), runs each plant N times
against the isolated candidate copy and writes one raw log per run with the
subprocess exit code. Verdict rule mirrors the shipped harness: KILLED iff go
test fails with a FAIL line, SURVIVED iff exit 0, COMPILE_FAIL / NOT_APPLIED /
ERROR otherwise (never a kill).
"""
import importlib.util, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / os.environ.get("REVIEW_TREE", "candidate")
LOGDIR = HERE / "logs" / "mutants"
LOGDIR.mkdir(parents=True, exist_ok=True)
PACKAGE = "internal/clonebundle"

spec = importlib.util.spec_from_file_location("mutant_harness", CANDIDATE / PACKAGE / "testdata" / "mutant_harness.py")
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
Mutant = harness.Mutant

# --- rev3 reviewer SURVIVORS (P2-beta, P3-c') re-planted on the rev4 tree ---
REV3_SURVIVORS = [
    Mutant("R3-raw-entries-dup-decode", f"{PACKAGE}/rawmanifest.go",
           "\t\tif index > 0 && key <= previous {\n",
           "\t\tif index > 0 && key < previous {\n", 1,
           "Test", "KILLED",
           "P2-beta: decodeRawEntries admits an equal-key duplicate at DECODE (whole suite)."),
    Mutant("R3-proof-input-blocked", f"{PACKAGE}/boundary.go",
           "\t\tif !proof.InputBlocked || !proof.ForegroundIdle || !proof.BackgroundIdle {\n",
           "\t\tif !proof.ForegroundIdle || !proof.BackgroundIdle {\n", 1,
           "Test", "KILLED",
           "P3-c': closed_store/provider_quiescence admits input_blocked=false (whole suite)."),
    Mutant("R3-ax-number-negative-edge", f"{PACKAGE}/decode.go",
           "\tif err != nil || integer < -maxSafeInteger || integer > maxSafeInteger {\n",
           "\tif err != nil || integer < -maxSafeInteger-1 || integer > maxSafeInteger {\n", 1,
           "Test", "KILLED",
           "P3-c': the literal gate admits exactly -(2^53) (whole suite)."),
    Mutant("R3-sanitizer-zp", f"{PACKAGE}/identity.go",
           "\t\tif unicode.Is(unicode.Cf, unit) || unicode.Is(unicode.Zl, unit) || unicode.Is(unicode.Zp, unit) {\n",
           "\t\tif unicode.Is(unicode.Cf, unit) || unicode.Is(unicode.Zl, unit) {\n", 1,
           "Test", "KILLED",
           "P3-c': sanitizer admits Zp (U+2029) (whole suite)."),
    Mutant("R3-payload-strict-object", f"{PACKAGE}/event.go",
           "\tmembers, fault := decodeStrictObject(bytesTrimSpace(raw))\n\tif fault != nil {\n\t\treturn nil, invalid(\"canonical event payload %s (%s)\", fault.detail, memberField(fault.member))\n\t}\n",
           "\tmembers, fault := decodeStrictObject(bytesTrimSpace(raw))\n\tif fault != nil && fault.detail != \"duplicate member\" {\n\t\treturn nil, invalid(\"canonical event payload %s (%s)\", fault.detail, memberField(fault.member))\n\t}\n", 1,
           "Test", "KILLED",
           "P3-c': payload frame admits a top-level duplicate member (whole suite)."),
    Mutant("R3-decode-external-null-parent", f"{PACKAGE}/session.go",
           "\tif kind != \"main\" && parent == nil {\n\t\treturn Actor{}, invalid(\"actor[%d] non-main actor requires a parent\", index)\n",
           "\tif kind == \"subagent\" && parent == nil {\n\t\treturn Actor{}, invalid(\"actor[%d] non-main actor requires a parent\", index)\n", 1,
           "Test", "KILLED",
           "P3-c': decode admits an external actor with null parent (whole suite)."),
    Mutant("R3-decode-main-count", f"{PACKAGE}/session.go",
           "\tif mainCount != 1 {\n\t\treturn nil, invalid(\"canonical session carries %d main actors, want exactly one\", mainCount)\n\t}\n\treturn actors, nil\n",
           "\tif mainCount < 1 {\n\t\treturn nil, invalid(\"canonical session carries %d main actors, want exactly one\", mainCount)\n\t}\n\treturn actors, nil\n", 1,
           "Test", "KILLED",
           "P3-e': decode admits two main actors (whole suite)."),
]

# --- rev4 reviewer plants: arms the producer did not mutate ---
REV4 = [
    # the brief's four named classes, re-planted on this tree
    Mutant("R4-unknown-ignores-one", f"{PACKAGE}/capturebuild.go",
           "\t\tif item.Class == \"unknown\" {\n",
           "\t\tif item.Class == \"unknown\" && item.NativeItemKey != \"store/zz-unknown\" {\n", 1,
           "Test", "KILLED",
           "raw_complete derivation (shared hasUnknownClass, build + decode) ignores exactly one unknown item."),
    Mutant("R4-excluded-set-missing-runtime_state", f"{PACKAGE}/captureitem.go",
           '\tcase "credential", "machine_auth", "runtime_state", "transient_lock":\n',
           '\tcase "credential", "machine_auth", "transient_lock":\n', 1,
           "Test", "KILLED",
           "always-excluded set missing runtime_state."),
    Mutant("R4-raw-subset-admits-transient_lock", f"{PACKAGE}/rawmanifest.go",
           '\t"derived_cache_optional",\n\t"unknown",\n',
           '\t"derived_cache_optional",\n\t"transient_lock",\n\t"unknown",\n', 1,
           "Test", "KILLED",
           "raw entry class subset admits transient_lock."),
    Mutant("R4-sanitizer-c1-u009f", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x9f {\n", 1,
           "Test", "KILLED",
           "sanitizer admits exactly U+009F (C1 beyond the pinned U+0085) — stated as owner-informational by the producer."),
    Mutant("R4-sanitizer-c0-u0001", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x01 {\n", 1,
           "Test", "KILLED",
           "sanitizer admits exactly U+0001 (a C0 control the corpus does not name)."),
    # new arms
    Mutant("R4-heads-skip-last-build", f"{PACKAGE}/session.go",
           "\tfor _, id := range headIDs {\n\t\tif !eventSet[id.String()] {\n\t\t\treturn nil, invalid(",
           "\tfor i, id := range headIDs {\n\t\tif i < len(headIDs)-1 && !eventSet[id.String()] {\n\t\t\treturn nil, invalid(", 1,
           "Test", "KILLED",
           "build: the last head ID is exempt from the head-in-events rule."),
    Mutant("R4-heads-skip-last-decode", f"{PACKAGE}/session.go",
           "\tfor _, id := range headIDs {\n\t\tif !eventSet[id.String()] {\n\t\t\treturn CanonicalSession{}, invalid(",
           "\tfor i, id := range headIDs {\n\t\tif i < len(headIDs)-1 && !eventSet[id.String()] {\n\t\t\treturn CanonicalSession{}, invalid(", 1,
           "Test", "KILLED",
           "decode: the last head ID is exempt from the head-in-events rule."),
    Mutant("R4-sanitizer-schemeless-cred", f"{PACKAGE}/identity.go",
           "\tif at := strings.Index(key, \"@\"); at >= 0 && strings.Contains(key[:at], \":\") {\n",
           "\tif at := strings.Index(key, \"@\"); at >= 0 && strings.Contains(key[:at], \"://\") {\n", 1,
           "Test", "KILLED",
           "sanitizer admits schemeless user:secret@host credentials (schemed ones still refuse)."),
    Mutant("R4-drive-prefix-backslash", f"{PACKAGE}/identity.go",
           "value[1] == ':' && (value[2] == '/' || value[2] == '\\\\')\n",
           "value[1] == ':' && value[2] == '/'\n", 1,
           "Test", "KILLED",
           "sanitizer admits exactly the backslash drive form C:\\..."),
    Mutant("R4-inline-65537", f"{PACKAGE}/event.go",
           "\t\t\tif len(text) > maxInlineContent {\n",
           "\t\t\tif len(text) > maxInlineContent+1 {\n", 1,
           "Test", "KILLED",
           "inline content bound admits exactly 65537 bytes."),
    Mutant("R4-ordinal-edge", f"{PACKAGE}/event.go",
           "\t\tif ordinal >= uint64(len(ordinals)) {\n",
           "\t\tif ordinal > uint64(len(ordinals)) {\n", 1,
           "Test", "KILLED",
           "ordinal contiguity admits exactly ordinal == n."),
    Mutant("R4-reason-codes-dup-build", f"{PACKAGE}/event.go",
           "\t\tif index > 0 && reason <= previousReason {\n",
           "\t\tif index > 0 && reason < previousReason {\n", 1,
           "Test", "KILLED",
           "build: reason codes admit an equal-pair duplicate."),
    Mutant("R4-rawrefs-dup-build", f"{PACKAGE}/event.go",
           "\t\tif index > 0 && bytes.Compare(key, previous) <= 0 {\n",
           "\t\tif index > 0 && bytes.Compare(key, previous) < 0 {\n", 1,
           "Test", "KILLED",
           "build: raw refs admit an equal duplicate."),
    Mutant("R4-actor-external-null-parent-build", f"{PACKAGE}/session.go",
           "\tif input.Kind != \"main\" && parent == nil {\n",
           "\tif input.Kind == \"subagent\" && parent == nil {\n", 1,
           "Test", "KILLED",
           "build: an external actor with null parent is admitted."),
    Mutant("R4-digests-equal-one-order", f"{PACKAGE}/generation.go",
           "\tif pre != post {\n",
           "\tif pre != post && pre.String() < post.String() {\n", 1,
           "Test", "KILLED",
           "CheckDigestsEqual admits unequal digests in exactly one ordering."),
    Mutant("R4-unstable-operator-explicit", f"{PACKAGE}/boundary.go",
           "\tif !ok || !explicit {\n",
           "\tif !ok {\n\t\t_ = explicit\n", 1,
           "Test", "KILLED",
           "decode: unstable_archive admits operator_explicit=false (single-member class)."),
    Mutant("R4-unstable-reason-code", f"{PACKAGE}/boundary.go",
           "\tif !ok || reason != \"source_not_quiescent\" {\n",
           "\tif !ok || (reason != \"source_not_quiescent\" && reason != \"source_quiescent\") {\n", 1,
           "Test", "KILLED",
           "decode: unstable_archive admits exactly reason_code=source_quiescent."),
    Mutant("R4-plan-dup-other-key", f"{PACKAGE}/capturebuild.go",
           "\t\tif seenPlan[key] {\n",
           "\t\tif seenPlan[key] && key != \"store/token-cache\" {\n", 1,
           "Test", "KILLED",
           "duplicate plan keys: admits a duplicate of exactly store/token-cache (the producer row duplicates store/blob-a)."),
    Mutant("R4-cwd-dotdot", f"{PACKAGE}/identity.go",
           "\tif cwd == \".\" {\n",
           "\tif cwd == \".\" || cwd == \"..\" {\n", 1,
           "Test", "KILLED",
           "workspace cwd admits exactly the bare parent escape \"..\"."),
    Mutant("R4-generation-empty", f"{PACKAGE}/generation.go",
           "\tif stringLength(value) < 1 || stringLength(value) > 512 {\n",
           "\tif stringLength(value) > 512 {\n", 1,
           "Test", "KILLED",
           "ParseGeneration admits the empty token."),
    Mutant("R4-evidence-partial-operation", f"{PACKAGE}/event.go",
           "\tif hasOperation {\n\t\treturn invalid(\"source evidence %s carries a core operation\", status)\n",
           "\tif hasOperation && status != \"partial\" {\n\t\treturn invalid(\"source evidence %s carries a core operation\", status)\n", 1,
           "Test", "KILLED",
           "evidence coupling admits exactly partial+core operation (rows use exact)."),
    Mutant("R4-immutable-identity-required", f"{PACKAGE}/boundary.go",
           "\t\tif proof.SnapshotIdentity == nil {\n",
           "\t\tif proof.SnapshotIdentity == nil && proof.ProofKind != \"verified_log_prefix\" {\n", 1,
           "Test", "KILLED",
           "proof coupling admits verified_log_prefix without identity (immutable_snapshot still refuses)."),
    Mutant("C4-comment-control", f"{PACKAGE}/event.go",
           "// This file validates and constructs Canonical Event 1.0.0 with its\n",
           "// This file validates and constructs Canonical Event 1.0.0 with its (reviewer control)\n", 1,
           "Test", "SURVIVED",
           "harmless control: a comment-only edit must survive the whole suite."),
]


def run_once(mutant, run_index):
    target = CANDIDATE / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    log = LOGDIR / f"{mutant.name}-run{run_index}.log"
    if found != mutant.count:
        log.write_text(f"NOT_APPLIED anchors={found} want={mutant.count}\n# find={mutant.find!r}\n")
        return "NOT_APPLIED", log
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            started = time.time()
            proc = subprocess.run(["go", "test", f"./{PACKAGE}/", "-run", mutant.run, "-count=1"],
                                  cwd=CANDIDATE, capture_output=True, text=True, timeout=600,
                                  env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
            elapsed = time.time() - started
        finally:
            shutil.copy2(backup, target)
    assert target.read_text() == original, "restore failed"
    out = proc.stdout + proc.stderr
    log.write_text(f"# mutant={mutant.name} run={run_index} path={mutant.path} -run={mutant.run}\n"
                   f"# exit={proc.returncode} elapsed={elapsed:.1f}s\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{out}")
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "COMPILE_FAIL", log
    if proc.returncode == 0:
        return "SURVIVED", log
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED", log
    return f"ERROR(exit {proc.returncode})", log


def main(argv):
    which = argv[0] if argv else "all"
    repeats = int(argv[1]) if len(argv) > 1 else 1
    only = argv[2:] if len(argv) > 2 else None
    table = {"rev3": REV3_SURVIVORS, "rev4": REV4, "all": REV3_SURVIVORS + REV4}[which]
    if only:
        table = [m for m in table if m.name in only]
    print(f"# runner={Path(__file__).name} candidate={CANDIDATE} set={which} repeats={repeats} rows={len(table)}")
    counts = {}
    for m in table:
        verdicts = []
        for i in range(1, repeats + 1):
            v, log = run_once(m, i)
            verdicts.append(v)
            print(f"{m.name:44s} run{i} {v:14s} want={m.expect:9s} log={log.name}", flush=True)
        stable = len(set(verdicts)) == 1
        mark = "ok" if stable and verdicts[0] == m.expect else "MISMATCH"
        counts[mark] = counts.get(mark, 0) + 1
        print(f"  => {mark}: {m.name}: {'/'.join(verdicts)} :: {m.note}", flush=True)
    print(f"# summary {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
