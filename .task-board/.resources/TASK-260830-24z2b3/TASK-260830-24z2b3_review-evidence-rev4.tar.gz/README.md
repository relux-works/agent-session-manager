# TASK-260830-24z2b3 reviewer evidence (rev4, RUN-260917-ab25c8)

Isolated immutable copies of candidate tree 33b52bcbe16b7dc2b40f8e54168768d2cc73f768
(`git archive`), `.task-board` dropped; live worktree never touched.

- TASK-260830-24z2b3_review-verdict-rev4.md: the verdict (also attached on the board).
- logs/pkg-test-baseline.log, pkg-cover.log: package suite on the exact tree (verbose; 86.8%).
- logs/probes-rev4.log, probes-rev4-k.log, probes-rev4-l.log: reviewer probe batteries
  (sections A-L) — sources in zz_rev4_probe*_test.go.txt (test-only, never asserting).
- logs/probes-rev3-on-rev4.log: the rev3 reviewer probe battery (zz_rev3_probe_test.go.txt)
  re-executed on this tree (310 probes).
- logs/mutants-producer-run{1,2}.log + logs/mutants-producer/run{1,2}/: the shipped
  harness (testdata/mutant_harness.py --log-dir) run twice, one raw log per plant.
- logs/mutants-reviewer-rev4-runs1-2.log, logs/mutants-reviewer-rev4-replant-operator-explicit.log
  + logs/mutants/*-run{1,2}.log: reviewer_mutants_rev4.py (7 rev3 survivors re-planted +
  23 rev4 plants incl. control), one raw log per plant per run with `# exit=`.
- logs/mutants-ext-sites-runs1-2.log + logs/mutants/S-ext-values-*: site_plants.py class
  narrowing at each of the 17 checkExtensionsClosed sites, two runs.
- logs/tree-diff-after-*.log: candidate vs pristine diff after every battery (diff-exit=0).
- logs/sessquery-race.log: `go test ./internal/sessquery -race -count=1 -timeout 25m` with host load.
- logs/four-packages.log, provhost-census.log, tracecheck.log, cataloggen.log, gofmt.log,
  vet.log, refusal-census.log (+ clonebundle.coverprofile).
- MANIFEST.sha256: sha256 of every file in this archive.

PYTHONDONTWRITEBYTECODE=1 for every harness; no __pycache__ / .pyc.
