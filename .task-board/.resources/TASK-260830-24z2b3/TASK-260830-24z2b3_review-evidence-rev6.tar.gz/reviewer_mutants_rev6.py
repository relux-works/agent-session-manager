#!/usr/bin/env python3
"""Reviewer narrowing mutants for TASK-260830-24z2b3 rev6 (RUN-260918-3180f5).

Same M/R/V discipline as the shipped testdata/mutant_harness.py: mutate one
production file in place, run the Go killer (the WHOLE package suite for class
plants, a named row for per-site plants), verdict from the exit code plus a
FAIL line, restore from a copy. Run from the isolated candidate copy root:

  PYTHONDONTWRITEBYTECODE=1 python3 reviewer_mutants_rev6.py --repo candidate --log-dir logs/mutants/run1
"""

import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

PACKAGE = "internal/clonebundle"
ALL = "."


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    count: int
    run: str
    expect: str
    note: str


MUTANTS = [
    # --- the brief's four classes (item 6) + rev4 re-plants
    Mutant("R6-unknown-ignores-excluded", f"{PACKAGE}/capturebuild.go",
           '\t\tif item.Class == "unknown" {\n',
           '\t\tif item.Class == "unknown" && item.Included() {\n', 1, ALL, "KILLED",
           "raw_complete derivation (and decode/maximal_safe gates) ignore an EXCLUDED unknown item; only included unknowns count."),
    Mutant("R6-excluded-set-missing-machine_auth", f"{PACKAGE}/captureitem.go",
           '\tcase "credential", "machine_auth", "runtime_state", "transient_lock":\n',
           '\tcase "credential", "runtime_state", "transient_lock":\n', 1, ALL, "KILLED",
           "always-excluded class set drops machine_auth: a machine_auth item may be included."),
    Mutant("R6-raw-subset-admits-machine_auth", f"{PACKAGE}/rawmanifest.go",
           '\t"derived_cache_optional",\n\t"unknown",\n',
           '\t"derived_cache_optional",\n\t"machine_auth",\n\t"unknown",\n', 1, ALL, "KILLED",
           "raw entry class subset admits exactly machine_auth."),
    Mutant("R6-items-dup-build", f"{PACKAGE}/capturebuild.go",
           "\t\titem, err := buildCaptureItem(candidate, index)\n\t\tif err != nil {\n\t\t\treturn CaptureManifest{}, nil, err\n\t\t}\n\t\tif index > 0 && item.NativeItemKey <= previous {\n",
           "\t\titem, err := buildCaptureItem(candidate, index)\n\t\tif err != nil {\n\t\t\treturn CaptureManifest{}, nil, err\n\t\t}\n\t\tif index > 0 && item.NativeItemKey < previous {\n", 1, ALL, "KILLED",
           "capture items: equal-key duplicate admitted at BUILD (unsorted still refuses)."),
    Mutant("R6-items-dup-decode", f"{PACKAGE}/capturebuild.go",
           "\t\titem, err := decodeCaptureItem(element, index)\n\t\tif err != nil {\n\t\t\treturn nil, err\n\t\t}\n\t\tif index > 0 && item.NativeItemKey <= previous {\n",
           "\t\titem, err := decodeCaptureItem(element, index)\n\t\tif err != nil {\n\t\t\treturn nil, err\n\t\t}\n\t\tif index > 0 && item.NativeItemKey < previous {\n", 1, ALL, "KILLED",
           "capture items: equal-key duplicate admitted at DECODE."),
    Mutant("R6-raw-entries-dup-decode", f"{PACKAGE}/rawmanifest.go",
           "\t\tif index > 0 && key <= previous {\n",
           "\t\tif index > 0 && key < previous {\n", 1, ALL, "KILLED",
           "raw entries: equal-key duplicate admitted at DECODE (rev4 R3 re-plant)."),
    Mutant("R6-sanitizer-c0-u001f", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != '\\x1f' {\n", 1, ALL, "KILLED",
           "sanitizer admits exactly U+001F (pinned member of the C0 class)."),
    Mutant("R6-sanitizer-c0-tab", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != '\\t' {\n", 1, ALL, "KILLED",
           "sanitizer admits exactly TAB (informational per-member probe of the C0 class)."),
    # --- P2-delta one step away: per-site text gate, walker arms, encode-time sanitize
    Mutant("R6-text-site-title", f"{PACKAGE}/session.go",
           "\t\tif !validText(*input.Title) {\n",
           '\t\tif !validText(*input.Title) && *input.Title != "ti\\xfftle" {\n', 1, ALL, "KILLED",
           "title site exempts exactly the killer value."),
    Mutant("R6-text-site-actor-name", f"{PACKAGE}/session.go",
           "\t\tif !validText(*input.Name) {\n",
           '\t\tif !validText(*input.Name) && *input.Name != "na\\xffme" {\n', 1, ALL, "KILLED",
           "actor name site exempts exactly the killer value."),
    Mutant("R6-text-site-actor-model", f"{PACKAGE}/session.go",
           "\t\tif !validText(*input.Model) {\n",
           '\t\tif !validText(*input.Model) && *input.Model != "mo\\xffdel" {\n', 1, ALL, "KILLED",
           "actor model site exempts exactly the killer value."),
    Mutant("R6-text-site-native-type", f"{PACKAGE}/event.go",
           "\t\tif !validText(*input.NativeType) {\n",
           '\t\tif !validText(*input.NativeType) && *input.NativeType != "nt\\xff" {\n', 1, ALL, "KILLED",
           "evidence native_type site exempts exactly the killer value."),
    Mutant("R6-text-site-reason", f"{PACKAGE}/event.go",
           "\t\tif !validText(reason) {\n",
           '\t\tif !validText(reason) && reason != "rc\\xff" {\n', 1, ALL, "KILLED",
           "reason-code site exempts exactly the killer value."),
    Mutant("R6-text-site-exclusion-reason", f"{PACKAGE}/captureitem.go",
           "\t\tif !validText(*input.ExclusionReason) {\n",
           '\t\tif !validText(*input.ExclusionReason) && *input.ExclusionReason != "credential\\xff" {\n', 1, ALL, "KILLED",
           "exclusion_reason site exempts exactly the killer value."),
    Mutant("R6-text-site-generation", f"{PACKAGE}/generation.go",
           "\tif !validText(value) {\n",
           '\tif !validText(value) && value != "g\\xff" {\n', 1, ALL, "KILLED",
           "generation site exempts exactly the killer value."),
    Mutant("R6-text-site-kind", f"{PACKAGE}/identity.go",
           "\tif !validText(identity.IdentityKind) {\n",
           '\tif !validText(identity.IdentityKind) && identity.IdentityKind != "provider\\xff" {\n', 1, ALL, "KILLED",
           "identity kind site exempts exactly the killer value."),
    Mutant("R6-text-walk-skip-keys", f"{PACKAGE}/decode.go",
           "\t\t\tif !extensionTextValid(iter.Key()) || !extensionTextValid(iter.Value()) {\n",
           "\t\t\tif !extensionTextValid(iter.Value()) {\n", 1, ALL, "KILLED",
           "extension walker stops checking map keys."),
    Mutant("R6-text-walk-skip-struct", f"{PACKAGE}/decode.go",
           '\t\t\tif own.Field(index).PkgPath != "" {\n',
           '\t\t\tif own.Field(index).PkgPath != "" || index >= 0 {\n', 1, ALL, "KILLED",
           "extension walker skips every struct field."),
    Mutant("R6-text-walk-skip-first-element", f"{PACKAGE}/decode.go",
           "\t\tfor index := 0; index < value.Len(); index++ {\n",
           "\t\tfor index := 1; index < value.Len(); index++ {\n", 1, ALL, "KILLED",
           "extension walker skips the first slice/array element."),
    Mutant("R6-encode-skip-opaque-sanitize", f"{PACKAGE}/identity.go",
           "\t\tif err := SanitizeNativeKey(*identity.OpaqueIdentity); err != nil {\n",
           '\t\tif err := SanitizeNativeKey(*identity.OpaqueIdentity); err != nil && *identity.OpaqueIdentity != "op\\xff" {\n', 1, ALL, "KILLED",
           "EncodeNativeIdentity lets exactly op\\xff past the encode-time sanitizer (the original P2-delta hole, one member)."),
    Mutant("R6-encode-skip-native-sanitize", f"{PACKAGE}/identity.go",
           '\t\treturn nil, invalid("native identity kind is not valid UTF-8")\n\t}\n\tif err := SanitizeNativeKey(identity.NativeSessionID); err != nil {\n',
           '\t\treturn nil, invalid("native identity kind is not valid UTF-8")\n\t}\n\tif err := SanitizeNativeKey(identity.NativeSessionID); err != nil && identity.NativeSessionID != "native\\xff" {\n', 1, ALL, "KILLED",
           "EncodeNativeIdentity lets exactly native\\xff past the encode-time sanitizer (BuildCaptureManifest path; IdentityDigest sanitizes first itself)."),
    Mutant("R6-text-helper-lone-title", f"{PACKAGE}/decode.go",
           "\treturn utf8.ValidString(value)\n",
           '\treturn utf8.ValidString(value) || value == "ti\\xed\\xa0\\x80tle"\n', 1, ALL, "KILLED",
           "shared text gate admits exactly one WTF-8 lone-surrogate title (is the lone-surrogate MEMBER pinned at a validText site?)."),
    # --- blob/descriptor claim gates (item 4/5)
    Mutant("R6-verify-claim-any", f"{PACKAGE}/blobref.go",
           "\tif calculated != claimed {\n\t\treturn invalid(",
           "\tif false && calculated != claimed {\n\t\treturn invalid(", 1, ALL, "KILLED",
           "VerifyDescriptorAgreement accepts any descriptor_id claim (brief item 4: accept-any comparison)."),
    Mutant("R6-install-claim-any", f"{PACKAGE}/blobref.go",
           "\tif calculated != claimed {\n\t\treturn BlobAgreement{}, invalid(",
           "\tif false && calculated != claimed {\n\t\treturn BlobAgreement{}, invalid(", 1, ALL, "KILLED",
           "InstallRawBlob accepts any descriptor_id claim."),
    Mutant("R6-verify-entry-link-any", f"{PACKAGE}/blobref.go",
           "\tif calculated != wantDescriptorID {\n",
           "\tif false && calculated != wantDescriptorID {\n", 1, ALL, "KILLED",
           "entry blob_descriptor_id no longer has to name the verified descriptor."),
    # --- other arms
    Mutant("R6-reconcile-flag-one-way", f"{PACKAGE}/capturebuild.go",
           "\tif manifest.RawComplete != derived {\n",
           "\tif manifest.RawComplete && !derived {\n", 1, ALL, "KILLED",
           "VerifyCaptureReconciliation admits raw_complete=false when the derivation says true."),
    Mutant("R6-evidence-partial-operation", f"{PACKAGE}/event.go",
           "\tif hasOperation {\n",
           '\tif hasOperation && status != "partial" {\n', 1, ALL, "KILLED",
           "partial status may carry a core operation (rev4 informational re-plant)."),
    Mutant("R6-ordinal-dup-zero", f"{PACKAGE}/event.go",
           "\t\tif seen[ordinal] {\n",
           "\t\tif seen[ordinal] && ordinal != 0 {\n", 1, ALL, "KILLED",
           "ordinal contiguity admits a duplicate zero."),
    Mutant("R6-excluded-exact-extra", f"{PACKAGE}/capturebuild.go",
           "\tif len(derived) != len(excluded) {\n",
           "\tif len(derived) > len(excluded) {\n", 1, ALL, "KILLED",
           "excluded_classes may carry extra trailing classes beyond the excluded rows."),
    Mutant("C6-comment-control", f"{PACKAGE}/captureitem.go",
           "// This file validates the CaptureItem, Capture Source Basis, and\n",
           "// This file validates the CaptureItem, Capture Source Basis, and (control)\n", 1, ALL, "SURVIVED",
           "Harmless control: a comment-only edit must survive."),
]


def run_mutant(repo: Path, mutant: Mutant) -> tuple[str, str, int, float]:
    target = repo / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    if found != mutant.count:
        return f"ERROR: {mutant.name}: patch anchors {found}, want {mutant.count}", "", -1, 0.0
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            started = time.time()
            run = subprocess.run(
                ["go", "test", f"./{PACKAGE}/", "-run", mutant.run, "-count=1"],
                cwd=repo, capture_output=True, text=True, timeout=600,
            )
            elapsed = time.time() - started
        finally:
            shutil.copy2(backup, target)
    output = (run.stdout + run.stderr).strip()
    if "build failed" in output or "\n# " in output or output.startswith("# "):
        return f"ERROR: {mutant.name}: build broke under the patch", output, run.returncode, elapsed
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant.name}: exit {run.returncode} with no kill line", output, run.returncode, elapsed
    mark = "ok" if verdict == mutant.expect else "MISMATCH"
    return f"{mark}: {mutant.name}: {verdict} (want {mutant.expect}) :: {mutant.note}", output, run.returncode, elapsed


def main(argv: list[str]) -> int:
    repo = Path(".")
    log_dir = None
    names: list[str] = []
    args = list(argv)
    while args:
        if args[0] == "--repo":
            repo = Path(args[1]).resolve()
            args = args[2:]
        elif args[0] == "--log-dir":
            log_dir = Path(args[1])
            args = args[2:]
        else:
            names.append(args[0])
            args = args[1:]
    selected = [m for m in MUTANTS if not names or m.name in names]
    if log_dir is not None:
        log_dir.mkdir(parents=True, exist_ok=True)
    failures = 0
    for mutant in selected:
        try:
            line, output, exit_code, elapsed = run_mutant(repo, mutant)
        except subprocess.TimeoutExpired:
            line, output, exit_code, elapsed = f"ERROR: {mutant.name}: killer timed out", "", -1, 0.0
        print(line, flush=True)
        if log_dir is not None:
            killed_lines = "\n".join(l for l in output.splitlines() if "--- FAIL" in l)
            (log_dir / f"{mutant.name}.log").write_text(
                f"# mutant={mutant.name} path={mutant.path} -run={mutant.run}\n"
                f"# exit={exit_code} elapsed={elapsed:.1f}s\n"
                f"# find={mutant.find!r}\n# replace={mutant.replace!r}\n"
                f"# fail-lines:\n{killed_lines}\n---\n{output}\n"
            )
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
