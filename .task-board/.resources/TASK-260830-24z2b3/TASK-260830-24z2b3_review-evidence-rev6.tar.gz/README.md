# TASK-260830-24z2b3 reviewer evidence (rev6, RUN-260918-3180f5)

Isolated immutable copies of candidate tree 7a3784136c4f24bea753ea1bd860ccde35fddd87
(`git archive`), `.task-board` dropped; live worktree never touched.

- TASK-260830-24z2b3_review-verdict-rev6.md: the verdict (also attached on the board).
- logs/four-packages.log, gofmt.log, build.log, vet.log, pkg-cover.log (87.1%), pkg-race.log,
  tracecheck.log, cataloggen.log, diff-check.log, cross-builds.log: hygiene on the exact tree.
- logs/probes-rev4-k-on-rev6.log, probes-rev4-on-rev6.log: the rev4 reviewer probe batteries
  (sections A-L; K = native-key laundering) re-executed on this tree (zz_rev4_probe*_test.go.txt;
  C13 label fixed to %.20s because the digest is now empty on refusal).
- logs/probes-rev3-and-l-on-rev6.log: the rev3 probe battery + rev4 L re-executed (72 admitted, same as rev4).
- logs/probes-rev6-text.log: section T (43 sites x {\xff, \xed\xa0\x80} = 86 probes), T2 raw-byte
  inputs and escapes, T3 valid-text near misses, T4 decode side, T5 EncodeNativeIdentity standalone.
- logs/probes-rev6-refusals.log: section R refusal census (150 probes) incl. R14 envelope rules x 4 shapes.
- logs/probes-rev6-exclusion.log: section X row-21 exclusion derived from hosttrust.ExcludedFromReplication()
  plus every handoff class, at raw entry / excluded item / included item construction and both decode paths.
- logs/probes-rev6-blob-determinism.log: D1-D9 byte-identity, B1-B14 Section 10.2 agreement + install.
- logs/probe-under-mutant-unknown-excluded.log: the P3-epsilon survivor applied to the probe copy; R1 seals
  raw_complete=true with an excluded unknown item while the committed suite stays green.
- logs/mutants-producer-run{1,2}.log + logs/mutants-producer/run{1,2}/: the shipped harness
  (testdata/mutant_harness.py --log-dir) run twice in the isolated copy, one raw log per plant (66 KILLED + control).
- logs/mutants-reviewer-rev6-run{1,2}.log + logs/mutants/run{1,2}/: reviewer_mutants_rev6.py (30 rows,
  whole-suite killer), one raw log per plant per run with `# exit=` and the FAIL lines; identical verdicts both runs.
- logs/sessquery-race.log: `go test ./internal/sessquery -race -count=1 -timeout 25m` with wall time and host load.
- logs/provhost-census.log: TestNoProductionPathAttestsProviderIdentityBinding on the exact tree.
- MANIFEST.sha256: sha256 of every file in this archive.

PYTHONDONTWRITEBYTECODE=1 for every harness; no __pycache__ / .pyc.
