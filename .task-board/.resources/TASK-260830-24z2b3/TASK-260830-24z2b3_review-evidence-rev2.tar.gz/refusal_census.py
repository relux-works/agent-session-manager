#!/usr/bin/env python3
"""Refusal census: every production `invalid(` site in internal/clonebundle,
with the coverage verdict from the suite's coverprofile."""
import re, sys
from pathlib import Path
root = Path(sys.argv[1]); prof = Path(sys.argv[2])
blocks = {}  # file -> list of (sl, sc, el, ec, count)
for line in prof.read_text().splitlines()[1:]:
    loc, _, cnt = line.split(' ')
    f, rng = loc.split(':')
    a, b = rng.split(',')
    sl, sc = map(int, a.split('.')); el, ec = map(int, b.split('.'))
    blocks.setdefault(f.split('/')[-1], []).append((sl, sc, el, ec, int(cnt)))
total = covered = 0
rows = []
for go in sorted(root.glob('*.go')):
    if go.name.endswith('_test.go'):
        continue
    src = go.read_text().splitlines()
    for i, text in enumerate(src, 1):
        if 'invalid(' in text and 'func invalid' not in text:
            total += 1
            hits = [c for (sl, sc, el, ec, c) in blocks.get(go.name, []) if sl <= i <= el]
            cov = max(hits) if hits else -1
            if cov > 0:
                covered += 1
            rows.append((go.name, i, cov, text.strip()[:110]))
for r in rows:
    if r[2] <= 0:
        print(f"UNCOVERED {r[0]}:{r[1]} cov={r[2]} {r[3]}")
print(f"\nrefusal sites total={total} covered={covered} uncovered={total-covered}")
