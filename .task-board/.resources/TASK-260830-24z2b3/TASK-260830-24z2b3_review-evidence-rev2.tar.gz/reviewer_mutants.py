#!/usr/bin/env python3
"""Reviewer mutation runner for TASK-260830-24z2b3 rev2.

Loads the producer's MUTANTS table from the shipped harness (import, no
copy), adds the reviewer's own plants, runs each plant N times against the
isolated candidate copy, and writes one raw log per run with the subprocess
exit code. Verdict rule mirrors the shipped harness: KILLED iff go test
fails with a FAIL line, SURVIVED iff exit 0, ERROR otherwise.
"""
import importlib.util, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE.parent / "candidate"
LOGDIR = HERE / "logs" / "mutants"
LOGDIR.mkdir(parents=True, exist_ok=True)
PACKAGE = "internal/clonebundle"

spec = importlib.util.spec_from_file_location("mutant_harness", CANDIDATE / PACKAGE / "testdata" / "mutant_harness.py")
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
Mutant = harness.Mutant
PRODUCER = list(harness.MUTANTS)

REVIEWER = [
    # --- the four classes the reviewer brief names ---
    Mutant("R-unknown-ignores-one", f"{PACKAGE}/capturebuild.go",
           '\t\tif item.Class == "unknown" {\n',
           '\t\tif item.Class == "unknown" && item.NativeItemKey != "store/zz-unknown" {\n', 1,
           "TestBuildCaptureManifestUnknownMakesIncomplete", "KILLED",
           "raw_complete derivation ignores exactly one unknown item (the killer's key)."),
    Mutant("R-excluded-set-missing-machine_auth", f"{PACKAGE}/captureitem.go",
           '\tcase "credential", "machine_auth", "runtime_state", "transient_lock":\n',
           '\tcase "credential", "runtime_state", "transient_lock":\n', 1,
           "TestCaptureItemRefusals/machine_auth_included", "KILLED",
           "always-excluded set missing machine_auth."),
    Mutant("R-raw-subset-admits-machine_auth", f"{PACKAGE}/rawmanifest.go",
           '\t"derived_cache_optional",\n\t"unknown",\n',
           '\t"derived_cache_optional",\n\t"machine_auth",\n\t"unknown",\n', 1,
           "TestRawManifestRefusals/build/machine_auth_forbidden", "KILLED",
           "raw entry class subset admits machine_auth."),
    Mutant("R-capture-items-dup-build", f"{PACKAGE}/capturebuild.go",
           "\t\tif index > 0 && item.NativeItemKey <= previous {\n\t\t\treturn CaptureManifest{}, nil, invalid(",
           "\t\tif index > 0 && item.NativeItemKey < previous {\n\t\t\treturn CaptureManifest{}, nil, invalid(", 1,
           "TestCaptureItemRefusals/duplicate_items", "KILLED",
           "capture items sorted-unique accepts an equal-key duplicate at BUILD."),
    Mutant("R-capture-items-dup-decode", f"{PACKAGE}/capturebuild.go",
           "\t\tif index > 0 && item.NativeItemKey <= previous {\n\t\t\treturn nil, invalid(",
           "\t\tif index > 0 && item.NativeItemKey < previous {\n\t\t\treturn nil, invalid(", 1,
           "Test", "KILLED",
           "capture items sorted-unique accepts an equal-key duplicate at DECODE (whole suite as killer)."),
    Mutant("R-sorted-digests-dup-decode", f"{PACKAGE}/decode.go",
           "\t\tif index > 0 && text <= previous {\n",
           "\t\tif index > 0 && text < previous {\n", 1,
           "Test", "KILLED",
           "checkSortedUniqueDigests accepts an equal duplicate (heads/parents/fingerprints at decode)."),
    Mutant("R-sorted-strings-dup-decode", f"{PACKAGE}/decode.go",
           "\t\tif index > 0 && value <= previous {\n",
           "\t\tif index > 0 && value < previous {\n", 1,
           "Test", "KILLED",
           "checkSortedUniqueStrings accepts an equal duplicate (excluded_classes/reason_codes at decode)."),
    Mutant("R-rawrefs-dup-decode", f"{PACKAGE}/event.go",
           "\t\tif index > 0 && bytes.Compare(canonical, previous) <= 0 {\n",
           "\t\tif index > 0 && bytes.Compare(canonical, previous) < 0 {\n", 1,
           "Test", "KILLED",
           "raw_refs sorted-unique accepts an equal duplicate at DECODE."),
    Mutant("R-sanitizer-admits-0x01", f"{PACKAGE}/identity.go",
           "\t\tif unit < 0x20 || unit == 0x7f {\n",
           "\t\tif (unit < 0x20 && unit != 0x01) || unit == 0x7f {\n", 1,
           "Test", "KILLED",
           "native-key sanitizer admits exactly U+0001."),
    Mutant("R-sanitizer-admits-0x1f", f"{PACKAGE}/identity.go",
           "\t\tif unit < 0x20 || unit == 0x7f {\n",
           "\t\tif (unit < 0x20 && unit != 0x1f) || unit == 0x7f {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "native-key sanitizer admits exactly U+001F (in the corpus)."),
    # --- decode-side duplicates of build-tested rules ---
    Mutant("R-decode-item-class", f"{PACKAGE}/captureitem.go",
           '\tif !ok || !ValidCaptureClass(class) {\n\t\treturn CaptureItem{}, invalid("capture item[%d] class %q is outside the nine-class vocabulary", index, class)\n\t}\n\tdisposition, ok := rawString(members["disposition"])\n',
           '\tif !ok || (!ValidCaptureClass(class) && class != "mystery") {\n\t\treturn CaptureItem{}, invalid("capture item[%d] class %q is outside the nine-class vocabulary", index, class)\n\t}\n\tdisposition, ok := rawString(members["disposition"])\n', 1,
           "Test", "KILLED",
           "decodeCaptureItem admits exactly class mystery."),
    Mutant("R-decode-actor-main-parent", f"{PACKAGE}/session.go",
           '\tif kind == "main" && parent != nil {\n',
           '\tif kind == "main" && parent != nil && index != 0 {\n', 1,
           "Test", "KILLED",
           "decodeActor admits exactly actor[0] main-with-parent."),
    Mutant("R-decode-evidence-status", f"{PACKAGE}/event.go",
           '\tstatus, ok := rawString(members["capture_status"])\n\tif !ok || !validCaptureStatus(status) {\n',
           '\tstatus, ok := rawString(members["capture_status"])\n\tif !ok || (!validCaptureStatus(status) && status != "maybe") {\n', 1,
           "Test", "KILLED",
           "DecodeSourceEvidence admits exactly capture_status maybe."),
    Mutant("R-decode-event-visibility", f"{PACKAGE}/event.go",
           '\tif !ok || !validVisibility(visibility) {\n\t\treturn CanonicalEvent{}, invalid(',
           '\tif !ok || (!validVisibility(visibility) && visibility != "secret") {\n\t\treturn CanonicalEvent{}, invalid(', 1,
           "Test", "KILLED",
           "DecodeCanonicalEvent admits exactly visibility secret."),
    # --- verification entries with positive-only evidence ---
    Mutant("R-verify-descriptors-skip-0", f"{PACKAGE}/rawmanifest.go",
           "\t\tif err := VerifyDescriptorAgreement(descriptor, entry.BlobID, entry.ByteCount); err != nil {\n\t\t\treturn invalid(\"raw object entry[%d]: %v\", index, err)\n",
           "\t\tif err := VerifyDescriptorAgreement(descriptor, entry.BlobID, entry.ByteCount); err != nil && index != 0 {\n\t\t\treturn invalid(\"raw object entry[%d]: %v\", index, err)\n", 1,
           "Test", "KILLED",
           "VerifyRawManifestDescriptors admits a disagreeing descriptor at entry 0."),
    Mutant("R-install-site-claim", f"{PACKAGE}/blobref.go",
           "\tif calculated != claimed {\n\t\treturn BlobAgreement{}, invalid(",
           "\tif calculated != claimed && false {\n\t\treturn BlobAgreement{}, invalid(", 1,
           "Test", "KILLED",
           "InstallRawBlob install-site claim comparison disabled (the site N-descriptor-claim says it pins)."),
    Mutant("R-identity-digest-kind", f"{PACKAGE}/identity.go",
           "func validNativeIdentityKind(kind string) bool {\n",
           "func validNativeIdentityKind(kind string) bool {\n\tif kind == \"imported\" {\n\t\treturn true\n\t}\n", 1,
           "TestIdentityRefusals/native_identity/bad_kind", "KILLED",
           "identity kind vocabulary admits exactly imported."),
    Mutant("R-descriptor-id-unlinked2", f"{PACKAGE}/rawmanifest.go",
           "\t\tif err := VerifyDescriptorAgreement(input.Descriptor, blobID, input.ByteCount); err != nil {\n\t\t\treturn nil, 0, invalid(\"raw object entry[%d]: %v\", index, err)\n\t\t}\n",
           "\t\tif err := VerifyDescriptorAgreement(input.Descriptor, blobID, input.ByteCount); err != nil {\n\t\t\treturn nil, 0, invalid(\"raw object entry[%d]: %v\", index, err)\n\t\t}\n\t\tdescriptorID = scalar.SHA256Digest([]byte(input.DescriptorID))\n", 1,
           "Test", "KILLED",
           "P1 witness: the sealed entry's blob_descriptor_id is replaced by an unrelated digest after agreement passes; no test notices."),
    Mutant("C-review-comment", f"{PACKAGE}/generation.go",
           "// This file owns the Section 13.14.1 immutable generations: the\n",
           "// This file owns the Section 13.14.1 immutable generations (control): the\n", 1,
           "Test", "SURVIVED", "Reviewer harmless control: comment-only edit must survive."),
]


def run_once(mutant, run_index):
    target = CANDIDATE / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    log = LOGDIR / f"{mutant.name}-run{run_index}.log"
    if found != mutant.count:
        log.write_text(f"NOT_APPLIED anchors={found} want={mutant.count}\n")
        return "NOT_APPLIED", log
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            started = time.time()
            proc = subprocess.run(["go", "test", f"./{PACKAGE}/", "-run", mutant.run, "-count=1"],
                                  cwd=CANDIDATE, capture_output=True, text=True, timeout=600,
                                  env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
            elapsed = time.time() - started
        finally:
            shutil.copy2(backup, target)
    assert target.read_text() == original, "restore failed"
    out = proc.stdout + proc.stderr
    log.write_text(f"# mutant={mutant.name} run={run_index} path={mutant.path} -run={mutant.run}\n"
                   f"# exit={proc.returncode} elapsed={elapsed:.1f}s\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{out}")
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "COMPILE_FAIL", log
    if proc.returncode == 0:
        return "SURVIVED", log
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED", log
    return f"ERROR(exit {proc.returncode})", log


def main(argv):
    which = argv[0] if argv else "all"
    repeats = int(argv[1]) if len(argv) > 1 else 1
    table = {"producer": PRODUCER, "reviewer": REVIEWER, "all": PRODUCER + REVIEWER}[which]
    print(f"# runner={Path(__file__).name} candidate={CANDIDATE} set={which} repeats={repeats}")
    counts = {}
    for m in table:
        verdicts = []
        for i in range(1, repeats + 1):
            v, log = run_once(m, i)
            verdicts.append(v)
            print(f"{m.name:44s} run{i} {v:14s} want={m.expect:9s} log={log.name}", flush=True)
        stable = len(set(verdicts)) == 1
        mark = "ok" if stable and verdicts[0] == m.expect else "MISMATCH"
        counts[mark] = counts.get(mark, 0) + 1
        print(f"  => {mark}: {m.name}: {'/'.join(verdicts)} :: {m.note}", flush=True)
    print(f"# summary {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
