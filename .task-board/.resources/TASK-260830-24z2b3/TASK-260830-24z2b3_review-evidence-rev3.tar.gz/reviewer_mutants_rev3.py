#!/usr/bin/env python3
"""Reviewer mutation runner for TASK-260830-24z2b3 rev3 (RUN-260917-62d051).

Loads the producer's MUTANTS table from the shipped harness (import, no copy),
re-anchors the rev2 reviewer plants to the rev3 tree, adds the rev3 reviewer
plants, runs each plant N times against the isolated candidate copy, and
writes one raw log per run with the subprocess exit code. Verdict rule mirrors
the shipped harness: KILLED iff go test fails with a FAIL line, SURVIVED iff
exit 0, COMPILE_FAIL / NOT_APPLIED / ERROR otherwise (never a kill).
"""
import importlib.util, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / os.environ.get("REVIEW_TREE", "candidate")
LOGDIR = HERE / "logs" / "mutants"
LOGDIR.mkdir(parents=True, exist_ok=True)
PACKAGE = "internal/clonebundle"

spec = importlib.util.spec_from_file_location("mutant_harness", CANDIDATE / PACKAGE / "testdata" / "mutant_harness.py")
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
Mutant = harness.Mutant
PRODUCER = list(harness.MUTANTS)

D_OTHER = "sha256:d9298a10d1b0735837dc4bd85dac641b0f3cef27a47e5d53a54f2f3f5b2fcffa"
D_OTHER_BLOB = "sha256:b77376af3081fb2351136da020ad58053388762f3ceb66625656aa10382b8e06"
D_EVENT0 = "sha256:261447eec7152d0375cd5271b0baf299d5225506e24b3a2d7ef7eb89400eac09"

# --- rev2 reviewer plants, re-anchored to the rev3 tree (every one re-run) ---
REV2 = [
    Mutant("R-unknown-ignores-one", f"{PACKAGE}/capturebuild.go",
           '\t\tif item.Class == "unknown" {\n',
           '\t\tif item.Class == "unknown" && item.NativeItemKey != "store/zz-unknown" {\n', 1,
           "TestBuildCaptureManifestUnknownMakesIncomplete", "KILLED",
           "raw_complete derivation ignores exactly one unknown item (the killer's key)."),
    Mutant("R-excluded-set-missing-machine_auth", f"{PACKAGE}/captureitem.go",
           '\tcase "credential", "machine_auth", "runtime_state", "transient_lock":\n',
           '\tcase "credential", "runtime_state", "transient_lock":\n', 1,
           "TestCaptureItemRefusals/machine_auth_included", "KILLED",
           "always-excluded set missing machine_auth."),
    Mutant("R-raw-subset-admits-machine_auth", f"{PACKAGE}/rawmanifest.go",
           '\t"derived_cache_optional",\n\t"unknown",\n',
           '\t"derived_cache_optional",\n\t"machine_auth",\n\t"unknown",\n', 1,
           "TestRawManifestRefusals/build/machine_auth_forbidden", "KILLED",
           "raw entry class subset admits machine_auth."),
    Mutant("R-capture-items-dup-build", f"{PACKAGE}/capturebuild.go",
           "\t\tif index > 0 && item.NativeItemKey <= previous {\n\t\t\treturn CaptureManifest{}, nil, invalid(",
           "\t\tif index > 0 && item.NativeItemKey < previous {\n\t\t\treturn CaptureManifest{}, nil, invalid(", 1,
           "TestCaptureItemRefusals/duplicate_items", "KILLED",
           "capture items sorted-unique accepts an equal-key duplicate at BUILD."),
    Mutant("R-capture-items-dup-decode", f"{PACKAGE}/capturebuild.go",
           "\t\tif index > 0 && item.NativeItemKey <= previous {\n\t\t\treturn nil, invalid(",
           "\t\tif index > 0 && item.NativeItemKey < previous {\n\t\t\treturn nil, invalid(", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: capture items equal-key duplicate at DECODE (whole suite)."),
    # rev2 R-sorted-digests-dup-decode / R-sorted-strings-dup-decode targeted the local
    # fork, now gone. Re-anchored as a CLASS narrowing of the delegating wrapper:
    # any two-element equal pair of digests/strings is admitted (not only the
    # killer's literal pair). Whole suite as killer, then per-site runs below.
    Mutant("R-sorted-digests-dup-decode", f"{PACKAGE}/decode.go",
           "func checkSortedUniqueDigests(raw json.RawMessage, minimumCount, maximumCount uint64) ([]scalar.Digest, bool) {\n\treturn environ.CheckSortedUniqueDigests(raw, minimumCount, maximumCount)\n}\n",
           "func checkSortedUniqueDigests(raw json.RawMessage, minimumCount, maximumCount uint64) ([]scalar.Digest, bool) {\n\tif elements, ok := decodeArray(raw); ok && len(elements) == 2 && string(bytesTrimSpace(elements[0])) == string(bytesTrimSpace(elements[1])) {\n\t\tif first, ok := environ.CheckDigest(elements[0]); ok {\n\t\t\treturn []scalar.Digest{first, first}, true\n\t\t}\n\t}\n\treturn environ.CheckSortedUniqueDigests(raw, minimumCount, maximumCount)\n}\n", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR re-anchored: wrapper admits any equal digest pair (heads/parents/fingerprints at decode)."),
    Mutant("R-sorted-strings-dup-decode", f"{PACKAGE}/decode.go",
           "func checkSortedUniqueStrings(raw json.RawMessage, minimumLength, maximumLength int, minimumCount, maximumCount uint64) ([]string, bool) {\n\treturn environ.CheckSortedUniqueStrings(raw, minimumLength, maximumLength, minimumCount, maximumCount)\n}\n",
           "func checkSortedUniqueStrings(raw json.RawMessage, minimumLength, maximumLength int, minimumCount, maximumCount uint64) ([]string, bool) {\n\tif elements, ok := decodeArray(raw); ok && len(elements) == 2 && string(bytesTrimSpace(elements[0])) == string(bytesTrimSpace(elements[1])) {\n\t\tif first, ok := rawString(elements[0]); ok {\n\t\t\treturn []string{first, first}, true\n\t\t}\n\t}\n\treturn environ.CheckSortedUniqueStrings(raw, minimumLength, maximumLength, minimumCount, maximumCount)\n}\n", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR re-anchored: wrapper admits any equal string pair (excluded_classes/reason_codes at decode)."),
    Mutant("R-rawrefs-dup-decode", f"{PACKAGE}/event.go",
           "\t\tif index > 0 && bytes.Compare(canonical, previous) <= 0 {\n",
           "\t\tif index > 0 && bytes.Compare(canonical, previous) < 0 {\n", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: raw_refs equal duplicate at DECODE."),
    Mutant("R-sanitizer-admits-0x01", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x01 {\n", 1,
           "Test", "KILLED",
           "rev2 informational survivor re-anchored: sanitizer admits exactly U+0001 (not in corpus)."),
    Mutant("R-sanitizer-admits-0x1f", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x1f {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer admits exactly U+001F (in the corpus)."),
    Mutant("R-decode-item-class", f"{PACKAGE}/captureitem.go",
           '\tif !ok || !ValidCaptureClass(class) {\n\t\treturn CaptureItem{}, invalid("capture item[%d] class %q is outside the nine-class vocabulary", index, class)\n\t}\n\tdisposition, ok := rawString(members["disposition"])\n',
           '\tif !ok || (!ValidCaptureClass(class) && class != "mystery") {\n\t\treturn CaptureItem{}, invalid("capture item[%d] class %q is outside the nine-class vocabulary", index, class)\n\t}\n\tdisposition, ok := rawString(members["disposition"])\n', 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: decodeCaptureItem admits exactly class mystery."),
    Mutant("R-decode-actor-main-parent", f"{PACKAGE}/session.go",
           '\tif kind == "main" && parent != nil {\n',
           '\tif kind == "main" && parent != nil && index != 0 {\n', 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: decodeActor admits exactly actor[0] main-with-parent."),
    Mutant("R-decode-evidence-status", f"{PACKAGE}/event.go",
           '\tstatus, ok := rawString(members["capture_status"])\n\tif !ok || !validCaptureStatus(status) {\n',
           '\tstatus, ok := rawString(members["capture_status"])\n\tif !ok || (!validCaptureStatus(status) && status != "maybe") {\n', 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: DecodeSourceEvidence admits exactly capture_status maybe."),
    Mutant("R-decode-event-visibility", f"{PACKAGE}/event.go",
           '\tif !ok || !validVisibility(visibility) {\n\t\treturn CanonicalEvent{}, invalid(',
           '\tif !ok || (!validVisibility(visibility) && visibility != "secret") {\n\t\treturn CanonicalEvent{}, invalid(', 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: DecodeCanonicalEvent admits exactly visibility secret."),
    Mutant("R-verify-descriptors-skip-0", f"{PACKAGE}/rawmanifest.go",
           "\t\tif err := VerifyDescriptorAgreement(descriptor, entry.BlobDescriptorID, entry.BlobID, entry.ByteCount); err != nil {\n\t\t\treturn invalid(\"raw object entry[%d]: %v\", index, err)\n",
           "\t\tif err := VerifyDescriptorAgreement(descriptor, entry.BlobDescriptorID, entry.BlobID, entry.ByteCount); err != nil && index != 0 {\n\t\t\treturn invalid(\"raw object entry[%d]: %v\", index, err)\n", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR re-anchored: VerifyRawManifestDescriptors admits a disagreeing descriptor at entry 0."),
    Mutant("R-install-site-claim", f"{PACKAGE}/blobref.go",
           "\tif calculated != claimed {\n\t\treturn BlobAgreement{}, invalid(",
           "\tif calculated != claimed && false {\n\t\treturn BlobAgreement{}, invalid(", 1,
           "Test", "KILLED",
           "rev2 SURVIVOR: InstallRawBlob install-site claim comparison disabled (arm-delete, existence only)."),
    Mutant("R-identity-digest-kind", f"{PACKAGE}/identity.go",
           "func validNativeIdentityKind(kind string) bool {\n",
           "func validNativeIdentityKind(kind string) bool {\n\tif kind == \"imported\" {\n\t\treturn true\n\t}\n", 1,
           "TestIdentityRefusals/native_identity/bad_kind", "KILLED",
           "identity kind vocabulary admits exactly imported."),
    Mutant("R-descriptor-id-unlinked2", f"{PACKAGE}/rawmanifest.go",
           "\t\tif err := VerifyDescriptorAgreement(input.Descriptor, descriptorID, blobID, input.ByteCount); err != nil {\n\t\t\treturn nil, 0, invalid(\"raw object entry[%d]: %v\", index, err)\n\t\t}\n",
           "\t\tif err := VerifyDescriptorAgreement(input.Descriptor, descriptorID, blobID, input.ByteCount); err != nil {\n\t\t\treturn nil, 0, invalid(\"raw object entry[%d]: %v\", index, err)\n\t\t}\n\t\tdescriptorID = scalar.SHA256Digest([]byte(input.DescriptorID))\n", 1,
           "Test", "KILLED",
           "rev2 P1 witness (SURVIVED 3/3): sealed blob_descriptor_id replaced by an unrelated digest after agreement passes."),
    Mutant("C-review-comment", f"{PACKAGE}/generation.go",
           "// This file owns the Section 13.14.1 immutable generations: the\n",
           "// This file owns the Section 13.14.1 immutable generations (control): the\n", 1,
           "Test", "SURVIVED", "Reviewer harmless control: comment-only edit must survive."),
]

# --- rev3 reviewer plants (arms the producer did not mutate, plus one-step-away variants) ---
REV3 = [
    Mutant("R3-raw-entries-dup-decode", f"{PACKAGE}/rawmanifest.go",
           "\t\tif index > 0 && key <= previous {\n",
           "\t\tif index > 0 && key < previous {\n", 1,
           "Test", "KILLED",
           "decodeRawEntries admits an equal-key duplicate entry at DECODE (producer mutated only the build site)."),
    Mutant("R3-link-any-claim", f"{PACKAGE}/blobref.go",
           "\tif calculated != wantDescriptorID {\n",
           "\tif calculated != wantDescriptorID && false {\n", 1,
           "Test", "KILLED",
           "descriptor identity link accepts any claim (arm-delete: existence only; brief item 4)."),
    Mutant("R3-link-narrow-sibling", f"{PACKAGE}/blobref.go",
           "\tif calculated != wantDescriptorID {\n",
           "\tif calculated != wantDescriptorID && wantDescriptorID.Hex() != \"369c0225affac23e2a7a16052d03b24bfd9421ea3f83c8fe39111e864c344cfb\" {\n", 1,
           "Test", "KILLED",
           "descriptor identity link admits exactly sha256('some-other-descriptor') (the build AND verify AND agreement killers all use it)."),
    Mutant("R3-blob-id-agreement", f"{PACKAGE}/blobref.go",
           "\tif blobID != wantBlobID {\n",
           "\tif blobID != wantBlobID && wantBlobID.String() != \"" + D_OTHER + "\" {\n", 1,
           "TestBlobAgreementRefusals", "KILLED",
           "blob_id agreement admits exactly the killer's other digest."),
    Mutant("R3-blob-id-agreement-build", f"{PACKAGE}/blobref.go",
           "\tif blobID != wantBlobID {\n",
           "\tif blobID != wantBlobID && wantBlobID.String() != \"" + D_OTHER_BLOB + "\" {\n", 1,
           "TestRawManifestRefusals/build/blob_disagreement", "KILLED",
           "blob_id agreement admits exactly the build killer's other-blob digest."),
    Mutant("R3-plan-match-renamed", f"{PACKAGE}/capturebuild.go",
           "\t\tif !itemSet[key] {\n",
           "\t\tif !itemSet[key] && key != \"store/zz-renamed\" {\n", 1,
           "TestCaptureManifestRefusals/build_plan_match", "KILLED",
           "checkPlanItemMatch admits exactly the killer's renamed candidate."),
    Mutant("R3-derive-raw-subset", f"{PACKAGE}/capturebuild.go",
           "\tif len(included) != len(rawKeys) {\n",
           "\tif len(included) < len(rawKeys) {\n", 1,
           "TestCaptureManifestRefusals/reconciliation", "KILLED",
           "deriveRawComplete admits a raw-key SUBSET of the included items (all-half dropped)."),
    Mutant("R3-evidence-exact-with-op", f"{PACKAGE}/event.go",
           "\tif hasOperation {\n",
           "\tif hasOperation && status != \"exact\" {\n", 1,
           "Test", "KILLED",
           "checkEvidenceCoupling admits exactly an exact-status evidence carrying a core operation."),
    Mutant("R3-decode-external-null-parent", f"{PACKAGE}/session.go",
           '\tif kind != "main" && parent == nil {\n',
           '\tif kind != "main" && kind != "external" && parent == nil {\n', 1,
           "Test", "KILLED",
           "decodeActor admits exactly an external actor with null parent (decode site; build has the external row)."),
    Mutant("R3-decode-main-count", f"{PACKAGE}/session.go",
           "\tif mainCount != 1 {\n\t\treturn nil, invalid(\"canonical session carries %d main actors, want exactly one\", mainCount)\n\t}\n\treturn actors, nil\n",
           "\tif mainCount < 1 {\n\t\treturn nil, invalid(\"canonical session carries %d main actors, want exactly one\", mainCount)\n\t}\n\treturn actors, nil\n", 1,
           "Test", "KILLED",
           "decodeActors alone admits multi-main sessions (producer N-main-count patches both sites, one killer)."),
    Mutant("R3-decode-actor-dup", f"{PACKAGE}/session.go",
           "\t\tif seen[actor.ActorID.String()] {\n",
           "\t\tif seen[actor.ActorID.String()] && index != 1 {\n", 1,
           "Test", "KILLED",
           "decodeActors admits exactly a duplicate actor ID at index 1 (the decode killer's shape)."),
    Mutant("R3-decode-events-dup", f"{PACKAGE}/session.go",
           "\t\tid, ok := checkDigest(element)\n\t\tif !ok {\n\t\t\treturn nil, invalid(\"canonical session %s[%d] is not a digest\", name, index)\n\t\t}\n\t\tif seen[id.String()] {\n",
           "\t\tid, ok := checkDigest(element)\n\t\tif !ok {\n\t\t\treturn nil, invalid(\"canonical session %s[%d] is not a digest\", name, index)\n\t\t}\n\t\tif seen[id.String()] && id.String() != \"" + D_EVENT0 + "\" {\n", 1,
           "Test", "KILLED",
           "decodeOrderedUniqueDigests admits exactly a duplicated test-event-0 at decode."),
    Mutant("R3-ordinal-edge", f"{PACKAGE}/event.go",
           "\t\tif ordinal >= uint64(len(ordinals)) {\n",
           "\t\tif ordinal > uint64(len(ordinals)) {\n", 1,
           "TestOrdinalContiguity", "KILLED",
           "CheckOrdinalContiguity admits ordinal == n (off-by-one at the edge)."),
    Mutant("R3-cwd-escape", f"{PACKAGE}/identity.go",
           "\tif cwd == \".\" {\n",
           "\tif cwd == \".\" || cwd == \"../escape\" {\n", 1,
           "TestIdentityRefusals/workspace_binding", "KILLED",
           "checkCwdRelative admits exactly the killer's escape."),
    Mutant("R3-sanitizer-abs", f"{PACKAGE}/identity.go",
           "\tif strings.HasPrefix(key, \"/\") || strings.HasPrefix(key, `\\\\`) || hasDrivePrefix(key) {\n",
           "\tif (strings.HasPrefix(key, \"/\") && key != \"/abs\") || strings.HasPrefix(key, `\\\\`) || hasDrivePrefix(key) {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer admits exactly the corpus absolute key /abs."),
    Mutant("R3-sanitizer-ax-case", f"{PACKAGE}/identity.go",
           "\tif strings.Contains(strings.ToLower(key), \"urn:ax:\") {\n",
           "\tif strings.Contains(key, \"urn:ax:\") {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer case-fold dropped: URN:AX: in upper case admits (rev2 P3-a)."),
    Mutant("R3-sanitizer-schemeless-cred", f"{PACKAGE}/identity.go",
           "\tif at := strings.Index(key, \"@\"); at >= 0 && strings.Contains(key[:at], \":\") {\n",
           "\tif at := strings.Index(key, \"@\"); at >= 0 && strings.Contains(key[:at], \"://\") {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer credential rule narrowed back to schemed URLs: user:secret@host admits (rev2 P3-a)."),
    Mutant("R3-sanitizer-c1", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x85 {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer admits exactly U+0085 (C1, in corpus; rev2 P3-a)."),
    Mutant("R3-sanitizer-c1-9f", f"{PACKAGE}/identity.go",
           "\t\tif unicode.IsControl(unit) {\n",
           "\t\tif unicode.IsControl(unit) && unit != 0x9f {\n", 1,
           "Test", "KILLED",
           "informational: sanitizer admits exactly U+009F (C1, NOT in corpus)."),
    Mutant("R3-sanitizer-zwsp", f"{PACKAGE}/identity.go",
           "\t\tif unicode.Is(unicode.Cf, unit) || unicode.Is(unicode.Zl, unit) || unicode.Is(unicode.Zp, unit) {\n",
           "\t\tif (unicode.Is(unicode.Cf, unit) && unit != 0x200b) || unicode.Is(unicode.Zl, unit) || unicode.Is(unicode.Zp, unit) {\n", 1,
           "TestIdentityRefusals/sanitizer", "KILLED",
           "sanitizer admits exactly U+200B (Cf, in corpus)."),
    Mutant("R3-sanitizer-zp", f"{PACKAGE}/identity.go",
           "\t\tif unicode.Is(unicode.Cf, unit) || unicode.Is(unicode.Zl, unit) || unicode.Is(unicode.Zp, unit) {\n",
           "\t\tif unicode.Is(unicode.Cf, unit) || unicode.Is(unicode.Zl, unit) {\n", 1,
           "Test", "KILLED",
           "informational: Zp (U+2029) arm dropped; corpus pins Zl (U+2028) and Cf only."),
    Mutant("R3-item-content-one-missing", f"{PACKAGE}/captureitem.go",
           "\t\tif !hasDescriptor || !hasCount {\n",
           "\t\tif !hasDescriptor && !hasCount {\n", 1,
           "TestCaptureItemRefusals", "KILLED",
           "included rule admits a row with exactly one content member missing."),
    Mutant("R3-item-excluded-reason-cred", f"{PACKAGE}/captureitem.go",
           "\tif !hasReason {\n",
           "\tif !hasReason && class != \"credential\" {\n", 1,
           "TestCaptureItemRefusals", "KILLED",
           "excluded rule admits exactly a credential row without a reason."),
    Mutant("R3-proof-input-blocked", f"{PACKAGE}/boundary.go",
           "\t\tif !proof.InputBlocked || !proof.ForegroundIdle || !proof.BackgroundIdle {\n",
           "\t\tif !proof.ForegroundIdle || !proof.BackgroundIdle {\n", 1,
           "Test", "KILLED",
           "closed_store/provider_quiescence coupling drops the input_blocked boolean (one of three)."),
    Mutant("R3-unstable-reason", f"{PACKAGE}/boundary.go",
           "\tif !ok || reason != \"source_not_quiescent\" {\n",
           "\tif !ok || (reason != \"source_not_quiescent\" && reason != \"tired\") {\n", 1,
           "TestBoundaryRefusals", "KILLED",
           "unstable reason_code admits exactly the killer's other reason."),
    Mutant("R3-unstable-explicit", f"{PACKAGE}/boundary.go",
           "\tif !ok || !explicit {\n",
           "\tif !ok || (!explicit && reason != \"source_not_quiescent\") {\n", 1,
           "TestBoundaryRefusals", "KILLED",
           "unstable operator_explicit=false admits (arm dropped)."),
    Mutant("R3-digests-equal-narrow", f"{PACKAGE}/generation.go",
           "\tif pre != post {\n",
           "\tif pre != post && post.String() != \"" + D_OTHER + "\" {\n", 1,
           "TestBoundaryRefusals", "KILLED",
           "CheckDigestsEqual admits exactly the killer's post digest."),
    Mutant("R3-ax-number-negative-edge", f"{PACKAGE}/decode.go",
           "\tif err != nil || integer < -maxSafeInteger || integer > maxSafeInteger {\n",
           "\tif err != nil || (integer < -maxSafeInteger && integer != -9007199254740992) || integer > maxSafeInteger {\n", 1,
           "Test", "KILLED",
           "AX number gate admits exactly -(2^53) (negative edge; the suite pins only the positive edge)."),
    Mutant("R3-ax-number-fraction-only", f"{PACKAGE}/decode.go",
           "\tif strings.ContainsAny(literal, \".eE\") {\n",
           "\tif strings.ContainsAny(literal, \"eE\") {\n", 1,
           "Test", "KILLED",
           "fraction arm dropped from the literal check (ParseInt still refuses 1.5: measures subsumption)."),
    Mutant("R3-extension-depth", f"{PACKAGE}/decode.go",
           "\tif depth >= maxExtensionDepth {\n\t\treturn errExtensionShape\n\t}\n\tseen := map[string]bool{}\n",
           "\tif depth >= maxExtensionDepth+1 {\n\t\treturn errExtensionShape\n\t}\n\tseen := map[string]bool{}\n", 1,
           "Test", "KILLED",
           "informational: extension object depth bound moved by one (256 -> 257)."),
    Mutant("R3-head-subset-decode", f"{PACKAGE}/session.go",
           "\t\tif !eventSet[id.String()] {\n\t\t\treturn CanonicalSession{}, invalid(",
           "\t\tif !eventSet[id.String()] && id.String() != \"sha256:7b1b763ee8f62eb88e4742a760f912d0b19bcd58b2b948999784bacc15a7f4d7\" {\n\t\t\treturn CanonicalSession{}, invalid(", 1,
           "Test", "KILLED",
           "decode head-subset gate admits exactly the killer's 'elsewhere' head."),
    Mutant("R3-exclusion-replication-narrow", f"{PACKAGE}/rawmanifest.go",
           "\tif hosttrust.MatchExcludedFromReplication(key) {\n",
           "\tif hosttrust.MatchExcludedFromReplication(key) && key != \"host-channel/pending-commit.json\" {\n", 1,
           "Test", "KILLED",
           "row-21 replication arm admits exactly pending-commit.json (token preserved)."),
    Mutant("R3-exclusion-config-narrow-nested", f"{PACKAGE}/rawmanifest.go",
           "\tif hosttrust.ExcludedConfigDirName(key) {\n",
           "\tif hosttrust.ExcludedConfigDirName(key) && key != \"state/.ax-config-stage-2\" {\n", 1,
           "Test", "KILLED",
           "row-21 config arm admits exactly the nested staging name (token preserved)."),
    Mutant("R3-payload-strict-object", f"{PACKAGE}/event.go",
           "\tmembers, fault := decodeStrictObject(bytesTrimSpace(raw))\n\tif fault != nil {\n\t\treturn nil, invalid(\"canonical event payload %s (%s)\", fault.detail, memberField(fault.member))\n\t}\n\tif messageLikeKind(kind) {\n",
           "\tmembers, fault := decodeStrictObject(bytesTrimSpace(raw))\n\tif fault != nil && fault.detail != environ.FaultDuplicate {\n\t\treturn nil, invalid(\"canonical event payload %s (%s)\", fault.detail, memberField(fault.member))\n\t}\n\tif messageLikeKind(kind) {\n", 1,
           "Test", "KILLED",
           "informational: payload top-level duplicate refusal dropped (is the strict-object frame of the payload pinned?)."),
    Mutant("C3-review-comment", f"{PACKAGE}/captureitem.go",
           "// This file validates the CaptureItem, Capture Source Basis, and\n",
           "// This file validates the CaptureItem, Capture Source Basis, and (control)\n", 1,
           "Test", "SURVIVED", "rev3 reviewer harmless control: comment-only edit must survive."),
]


def run_once(mutant, run_index, prefix=""):
    target = CANDIDATE / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    log = LOGDIR / f"{prefix}{mutant.name}{os.environ.get('REVIEW_LOG_SUFFIX', '')}-run{run_index}.log"
    if found != mutant.count:
        log.write_text(f"NOT_APPLIED anchors={found} want={mutant.count}\n# find={mutant.find!r}\n")
        return "NOT_APPLIED", log
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            if mutant.path.endswith("event.go") and "environ.FaultDuplicate" in mutant.replace:
                # the payload plant needs the environ import
                src = target.read_text()
                src = src.replace('\t"github.com/relux-works/agent-session-manager/internal/canonicaljson"\n', '\t"github.com/relux-works/agent-session-manager/internal/canonicaljson"\n\t"github.com/relux-works/agent-session-manager/internal/environ"\n', 1)
                target.write_text(src)
            started = time.time()
            proc = subprocess.run(["go", "test", f"./{PACKAGE}/", "-run", mutant.run, "-count=1"],
                                  cwd=CANDIDATE, capture_output=True, text=True, timeout=600,
                                  env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
            elapsed = time.time() - started
        finally:
            shutil.copy2(backup, target)
    assert target.read_text() == original, "restore failed"
    out = proc.stdout + proc.stderr
    log.write_text(f"# mutant={mutant.name} run={run_index} path={mutant.path} -run={mutant.run}\n"
                   f"# exit={proc.returncode} elapsed={elapsed:.1f}s\n# find={mutant.find!r}\n# replace={mutant.replace!r}\n---\n{out}")
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "COMPILE_FAIL", log
    if proc.returncode == 0:
        return "SURVIVED", log
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED", log
    return f"ERROR(exit {proc.returncode})", log


def main(argv):
    which = argv[0] if argv else "all"
    repeats = int(argv[1]) if len(argv) > 1 else 1
    only = argv[2:] if len(argv) > 2 else None
    table = {"producer": PRODUCER, "rev2": REV2, "rev3": REV3, "all": PRODUCER + REV2 + REV3}[which]
    if only:
        table = [m for m in table if m.name in only]
    print(f"# runner={Path(__file__).name} candidate={CANDIDATE} set={which} repeats={repeats} rows={len(table)}")
    counts = {}
    for m in table:
        verdicts = []
        for i in range(1, repeats + 1):
            v, log = run_once(m, i)
            verdicts.append(v)
            print(f"{m.name:44s} run{i} {v:14s} want={m.expect:9s} log={log.name}", flush=True)
        stable = len(set(verdicts)) == 1
        mark = "ok" if stable and verdicts[0] == m.expect else "MISMATCH"
        counts[mark] = counts.get(mark, 0) + 1
        print(f"  => {mark}: {m.name}: {'/'.join(verdicts)} :: {m.note}", flush=True)
    print(f"# summary {counts}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
