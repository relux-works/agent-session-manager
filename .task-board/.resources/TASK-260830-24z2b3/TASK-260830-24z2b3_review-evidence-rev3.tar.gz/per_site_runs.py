#!/usr/bin/env python3
"""Per-site kills for the two wrapper class-narrowings (which committed test at which site kills them)."""
import importlib.util, os, sys
from pathlib import Path
os.environ.setdefault("REVIEW_TREE", "pristine")
spec = importlib.util.spec_from_file_location("r", Path(__file__).resolve().parent / "reviewer_mutants_rev3.py")
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
by = {m.name: m for m in r.REV2 + r.REV3}
runs = [
    ("R-sorted-digests-dup-decode", "TestCanonicalSessionRefusals/decode/heads_duplicate", "heads"),
    ("R-sorted-digests-dup-decode", "TestCanonicalEventRefusals/decode/parents_duplicate", "parents"),
    ("R-sorted-digests-dup-decode", "TestIdentityRefusals/workspace_binding/prints_duplicate", "prints"),
    ("R-sorted-strings-dup-decode", "TestCaptureManifestRefusals/decode/excluded_classes_duplicate", "excluded_classes"),
    ("R-sorted-strings-dup-decode", "TestCanonicalEventRefusals/decode/evidence_reason_codes_duplicate", "reason_codes"),
    ("R3-decode-main-count", "TestCanonicalSessionRefusals/decode/two_mains", "decode-two-mains"),
    ("R3-raw-entries-dup-decode", "TestRawManifestRefusals/decode", "raw-decode-only"),
]
for name, run, tag in runs:
    m = by[name]
    m2 = r.Mutant(m.name, m.path, m.find, m.replace, m.count, run, "KILLED", m.note)
    os.environ["REVIEW_LOG_SUFFIX"] = f"-site-{tag}"
    v, log = r.run_once(m2, 1)
    print(f"{name:32s} -run {run:70s} {v}  log={log.name}", flush=True)
