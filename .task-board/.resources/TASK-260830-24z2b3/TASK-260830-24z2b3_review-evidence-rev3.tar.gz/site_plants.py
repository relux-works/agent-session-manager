#!/usr/bin/env python3
"""Per-site narrowing of the extension VALUE gate (TASK-260830-24z2b3 rev3 review).

At exactly one admission site, checkExtensionsClosed(...) is replaced by a
keys-only check (reverse-DNS keys still enforced, AX number model and nested
duplicate refusal dropped at that site only). The whole package suite runs as
the killer. A SURVIVED site is a site whose value gate no committed test
reaches. One raw log per plant with the subprocess exit code.
"""
import os, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
TREE = HERE / sys.argv[1]
LOGDIR = HERE / "logs" / "mutants"
LOGDIR.mkdir(parents=True, exist_ok=True)
PKG = TREE / "internal/clonebundle"
HELPER = '''

// reviewer plant: keys-only extension check (value model dropped)
func checkExtensionsKeysOnly(raw json.RawMessage) error {
	if !checkExtensions(raw) {
		return errExtensionsKeys
	}
	return nil
}
'''
sites = []
for go in sorted(PKG.glob("*.go")):
    if go.name.endswith("_test.go"):
        continue
    for i, line in enumerate(go.read_text().splitlines(), 1):
        if "checkExtensionsClosed(" in line and "func checkExtensionsClosed" not in line:
            sites.append((go.name, i, line.strip()))
print(f"# sites={len(sites)}")
repeats = int(sys.argv[2]) if len(sys.argv) > 2 else 1
results = []
for name, lineno, text in sites:
    target = PKG / name
    decode = PKG / "decode.go"
    orig_target = target.read_text()
    orig_decode = decode.read_text()
    verdicts = []
    for run in range(1, repeats + 1):
        with tempfile.TemporaryDirectory() as staging:
            b1 = Path(staging) / "t"; b2 = Path(staging) / "d"
            shutil.copy2(target, b1); shutil.copy2(decode, b2)
            try:
                lines = orig_target.splitlines(keepends=True)
                assert "checkExtensionsClosed(" in lines[lineno - 1]
                lines[lineno - 1] = lines[lineno - 1].replace("checkExtensionsClosed(", "checkExtensionsKeysOnly(", 1)
                target.write_text("".join(lines))
                decode.write_text((target.read_text() if name == "decode.go" else orig_decode) + HELPER)
                started = time.time()
                proc = subprocess.run(["go", "test", "./internal/clonebundle/", "-run", "Test", "-count=1"],
                                      cwd=TREE, capture_output=True, text=True, timeout=600,
                                      env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
                elapsed = time.time() - started
            finally:
                shutil.copy2(b1, target); shutil.copy2(b2, decode)
        assert target.read_text() == orig_target and decode.read_text() == orig_decode, "restore failed"
        out = proc.stdout + proc.stderr
        if "build failed" in out or "\n# " in out or out.startswith("# "):
            v = "COMPILE_FAIL"
        elif proc.returncode == 0:
            v = "SURVIVED"
        elif "--- FAIL" in out or "FAIL:" in out:
            v = "KILLED"
        else:
            v = f"ERROR(exit {proc.returncode})"
        log = LOGDIR / f"S-ext-values-{name}-{lineno}-run{run}.log"
        log.write_text(f"# site={name}:{lineno} run={run} -run=Test\n# exit={proc.returncode} elapsed={elapsed:.1f}s\n# line={text}\n# plant: checkExtensionsClosed -> checkExtensionsKeysOnly at this site only\n---\n{out}")
        verdicts.append(v)
        print(f"S-ext-values {name}:{lineno:<4} run{run} {v:12s} {text[:70]}", flush=True)
    results.append((name, lineno, verdicts))
print("# summary")
for name, lineno, verdicts in results:
    print(f"{name}:{lineno} {'/'.join(verdicts)}")
