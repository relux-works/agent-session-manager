# TASK-260830-24z2b3 review evidence, Change Request revision 3

Reviewer run RUN-260917-62d051 (claude-opus-5). All runs were executed in isolated
immutable copies of candidate tree d5b5b0eedad46636fb0b18a8652f99849658e98e
(`git archive` into .temp/TASK-260830-24z2b3/rev3-review/{candidate,pristine},
`.task-board` dropped); the live Story worktree was never modified.
PYTHONDONTWRITEBYTECODE=1 for every harness run; no __pycache__ or .pyc written;
both copies were diff-clean against each other after every battery.

- TASK-260830-24z2b3_review-verdict-rev3.md — the verdict (changes requested).
- zz_rev3_probe_test.go.txt + logs/probes-rev3.log — behavioral probes through the
  production entries (rework re-verification of every rev2 vector plus one step
  away; the new P1-c/P2-γ/P3 witnesses; sanitizer/exclusion/blob/boundary edges).
- reviewer_mutants_rev3.py — imports the producer's MUTANTS table from the shipped
  harness, re-anchors the rev2 reviewer plants to the rev3 tree, adds the rev3
  plants; logs/mutants-producer-runs1-2.log (37 rows x 2),
  logs/mutants-rev2-replants-runs1-2.log (19 x 2), logs/mutants-rev3-runs1-2.log
  (35 x 2) + logs/mutants-rev3-unstable-explicit-replant.log (1 x 2).
- site_plants.py — per-site narrowing of the extension VALUE gate (keys kept,
  value model dropped at one site); logs/mutants-ext-sites-run1.log, -run1b.log,
  -run2.log (17 sites x 2 runs + one repeat).
- per_site_runs.py + logs/mutants-per-site.log — which committed test at which
  site kills the two wrapper class-narrowings; decode-only main-count; raw
  decode-only duplicate.
- logs/mutants/<name>-run<N>.log — one raw `go test` log per plant per run with
  the subprocess exit code and the exact find/replace (223 files).
- logs/shipped-harness/ + logs/shipped-harness-smoke.log — the shipped
  mutant_harness.py --log-dir run on four rows (its own per-plant logging).
- logs/pkg-test-baseline.log, pkg-cover.log, clonebundle.coverprofile,
  refusal-census.log (366 invalid( sites, 181 covered, 185 uncovered; produced by
  the rev2 refusal_census.py over this run's coverprofile).
- logs/gofmt+vet (in transcript; both empty/clean), build.log, four-packages.log,
  tracecheck.log, cataloggen.log, provhost-census.log (census test PASS + module
  grep of VerifyObjectIdentity callers), staticcheck.log (tool unavailable under
  the active Go version; advisory only).
- logs/sessquery-race.log — `go test ./internal/sessquery -race -count=1
  -timeout 25m` on the pristine copy: ok 347.359s, wall 349.6s, exit 0, host load
  and concurrent test binaries recorded.
- MANIFEST.sha256 — digests of every file above.
