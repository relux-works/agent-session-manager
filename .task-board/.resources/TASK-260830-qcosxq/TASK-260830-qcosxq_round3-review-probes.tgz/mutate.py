#!/usr/bin/env python3
import sys, subprocess, hashlib, os, json, time

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()

def run(row, testcmd):
    f = row['file']
    before = sha(f)
    src = open(f, encoding='utf-8').read()
    n = src.count(row['old'])
    if n != 1:
        return {'id': row['id'], 'plant': f'occurrences={n}', 'result': 'PLANT-FAIL'}
    bak = src
    open(f,'w',encoding='utf-8').write(src.replace(row['old'], row['new'], 1))
    if open(f,encoding='utf-8').read().count(row['new']) < 1:
        open(f,'w',encoding='utf-8').write(bak)
        return {'id': row['id'], 'plant': 'absent-after-write', 'result': 'PLANT-FAIL'}
    t0=time.time()
    try:
        p = subprocess.run(testcmd, shell=True, capture_output=True, text=True, timeout=120)
        rc, tail = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        rc, tail = 124, 'HARNESS TIMEOUT 120s: ' + str(e.stdout or b'')[-400:]
    dt=round(time.time()-t0,1)
    open(f,'w',encoding='utf-8').write(bak)
    after = sha(f)
    ok_restore = (after == before)
    return {'id': row['id'], 'file': f, 'exit': rc,
            'result': ('TIMEOUT-RED' if rc==124 else ('RED' if rc != 0 else 'SURVIVED')),
            'restored': ok_restore, 'secs': dt,
            'tail': '\n'.join(tail.strip().splitlines()[-14:])}

if __name__ == '__main__':
    rows = json.load(open(sys.argv[1]))
    testcmd = sys.argv[2]
    out = []
    for row in rows:
        r = run(row, testcmd)
        out.append(r)
        print(f"{r['id']:<28} {r['result']:<11} exit={r.get('exit')} restored={r.get('restored')} {r.get('secs')}s", flush=True)
    json.dump(out, open(sys.argv[3],'w'), indent=1)
