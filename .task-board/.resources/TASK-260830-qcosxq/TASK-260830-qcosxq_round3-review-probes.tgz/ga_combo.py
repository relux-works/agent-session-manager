import json, subprocess, hashlib, sys, time
FLOOR_FILE='internal/provhost/refusal_arm_inventory_test.go'
def sha(p): return hashlib.sha256(open(p,'rb').read()).hexdigest()
rows=json.load(open('.temp/review-r3/ga.json'))
by={r['id']:r for r in rows}
out=[]
for mid in ['GA2-skip-status-go','GA8-ctor-nonliteral-arg','GA10-aliased-ctor-exercised','GA4-failIntegrity-new-arm']:
    r=by[mid]
    files={FLOOR_FILE: open(FLOOR_FILE,encoding='utf-8').read(), r['file']: open(r['file'],encoding='utf-8').read()}
    before={f:sha(f) for f in files}
    # lower floor
    s=files[FLOOR_FILE]
    assert s.count('const refusalArmCensusFloor = 60')==1
    open(FLOOR_FILE,'w',encoding='utf-8').write(s.replace('const refusalArmCensusFloor = 60','const refusalArmCensusFloor = 1',1))
    # apply mutant (re-read in case same file)
    cur=open(r['file'],encoding='utf-8').read()
    assert cur.count(r['old'])==1, (mid, cur.count(r['old']))
    open(r['file'],'w',encoding='utf-8').write(cur.replace(r['old'],r['new'],1))
    p=subprocess.run("go test ./internal/provhost/ -count=1", shell=True, capture_output=True, text=True)
    for f,orig in files.items(): open(f,'w',encoding='utf-8').write(orig)
    ok=all(sha(f)==before[f] for f in files)
    tail='\n'.join((p.stdout+p.stderr).strip().splitlines()[-12:])
    out.append({'id':'floor1+'+mid,'exit':p.returncode,'result':'RED' if p.returncode else 'SURVIVED','restored':ok,'tail':tail})
    print('='*60); print('floor1+'+mid, out[-1]['result'], 'restored=',ok); print(tail[:900], flush=True)
json.dump(out, open('.temp/review-r3/ga-combo-result.json','w'), indent=1)
