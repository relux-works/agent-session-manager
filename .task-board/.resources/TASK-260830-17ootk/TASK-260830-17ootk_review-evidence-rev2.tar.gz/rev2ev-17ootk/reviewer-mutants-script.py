#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants for TASK-260830-17ootk rev2.

Each plant weakens one gate to admit exactly one member of the class it
must reject; the gate stays present. Run against the isolated copy at
/tmp/iso17 (never the live worktree).
"""
import subprocess, sys
from pathlib import Path

REPO = Path("/tmp/iso17")
GO = ["go", "test", "./internal/crashgate/", "-count=1"]
STATIC = GO + ["-run", "TestRegistryDerivesFromPinnedSpec|TestRegistryStructure"]
BEHAV = GO + ["-run", "TestCrashGate"]

PLANTS = [
    {
        "id": "R-host-diskfull",
        "file": "internal/matjournal/recover.go",
        "weakening": "host gate drops disk_full, keeps rename_blocked (exhaustiveness fallback removed for one family)",
        "killer": ["-run", "TestCrashGateSection1312/disk_full_enospc_at_seam"],
        "find": '\tswitch input.Host {\n\tcase HostDiskFull:\n\t\treturn assessment.park("staging_incomplete", "destination disk full: existing destination retained, staging partial",\n\t\t\t"free space, then resume the same operation")\n\tcase HostRenameBlocked:',
        "replace": '\tswitch input.Host {\n\tcase HostRenameBlocked:',
        "expect_behavior": "fail",
    },
    {
        "id": "R-two-auth-lease-match",
        "file": "internal/matjournal/recover.go",
        "weakening": "two-live-authorities gate skipped when the lease tuple matches (rejection admitted as safe_retry)",
        "killer": ["-run", "TestCrashGateRejections/two_live_authorities"],
        "find": '\tif input.Provider.State == ProviderCommitted && input.Provider.PlanMatches && input.Provider.IDsMatch &&\n\t\tassessment.bridgeLive() && !input.Bridge.BindingMatches {',
        "replace": '\tif input.Provider.State == ProviderCommitted && input.Provider.PlanMatches && input.Provider.IDsMatch &&\n\t\tassessment.bridgeLive() && !input.Bridge.BindingMatches &&\n\t\t(input.LeaseAfter.Epoch != input.LeaseBefore.Epoch || input.LeaseAfter.ID != input.LeaseBefore.ID) {',
        "expect_behavior": "fail",
    },
    {
        "id": "R-rollback-contradiction-narrow",
        "file": "internal/matjournal/recover.go",
        "weakening": "rollback/activation contradiction gate keeps RolledBack, admits RollingBack (exclusivity narrowed)",
        "killer": ["-run", "TestCrashGateMutualExclusion/contradictory_rollback_with_activation_parks"],
        "find": '\tif (journal.Phase == PhaseRollingBack || journal.Phase == PhaseRolledBack) &&',
        "replace": '\tif journal.Phase == PhaseRolledBack &&',
        "expect_behavior": "fail",
    },
    {
        "id": "R-registry-stop04-driven",
        "file": "internal/crashgate/registry.go",
        "weakening": "CR-STOP-04 direct path flipped NOT APPLICABLE to reachable (N/A row counted as driven; token preserved)",
        "killer": ["-run", "TestCrashGateConformance"],
        "find": '{Name: PathDirect, Owner: "lifecycle orchestration (Section 13.9 closure verification; flow unlanded)", Note: "head binding is enforced at checkpoint capture/admission; flow verification writes no checkpoint/journal bytes"},',
        "replace": '{Name: PathDirect, Reachable: true, Driver: DriverCheckpointCapture, Note: "head binding is enforced at checkpoint capture/admission; flow verification writes no checkpoint/journal bytes"},',
        "expect_behavior": "fail",
    },
    {
        "id": "R-control-comment",
        "file": "internal/matjournal/recover.go",
        "weakening": "comment-only edit (harmless control, must SURVIVE)",
        "killer": [],
        "find": '// Rejection gates that park even on a terminal journal: two live\n\t// authorities, substitution, and unfenced continuation are never a\n\t// successful recovery.',
        "replace": '// Rejection gates that park even on a terminal journal: two live\n\t// authorities, substitution, and unfenced continuation are never a\n\t// successful recovery. Reviewer control: no semantic change.',
        "expect_behavior": "pass",
    },
]

def run(args):
    p = subprocess.run(args, cwd=REPO, capture_output=True, text=True, timeout=300)
    return p.returncode, (p.stdout + p.stderr)[-1500:]

def main():
    logdir = Path("/tmp/iso17-mylogs")
    logdir.mkdir(exist_ok=True)
    originals = {}
    for pl in PLANTS:
        if pl["file"] not in originals:
            originals[pl["file"]] = (REPO / pl["file"]).read_text()
    def restore():
        for name, text in originals.items():
            (REPO / name).write_text(text)
    results = []
    try:
        for pl in PLANTS:
            pid = pl["id"]
            path = REPO / pl["file"]
            cur = path.read_text()
            n = cur.count(pl["find"])
            if n != 1:
                print(f"{pid}: NOT-APPLIED occurrences={n}")
                results.append((pid, "NOT-APPLIED"))
                continue
            path.write_text(cur.replace(pl["find"], pl["replace"]))
            scode, _ = run(STATIC)
            bcode, bout = run(BEHAV + pl["killer"] if pl["killer"] else BEHAV)
            ok = (bcode != 0) if pl["expect_behavior"] == "fail" else (bcode == 0)
            verdict = "KILLED" if (ok and pl["expect_behavior"] == "fail") else ("SURVIVED" if ok else "UNEXPECTED")
            print(f"{pid}: static={scode} behavior={bcode} -> {verdict}")
            (logdir / f"{pid}.log").write_text(f"static={scode} behavior={bcode}\n{bout}\n")
            results.append((pid, verdict))
            restore()
    finally:
        restore()
    print(results)
    bad = [r for r in results if r[1] in ("NOT-APPLIED", "UNEXPECTED") or (r[0].startswith("R-") and r[1] != "KILLED" and not r[0].startswith("R-control")) or (r[0] == "R-control-comment" and r[1] != "SURVIVED")]
    return 1 if bad else 0

sys.exit(main())
