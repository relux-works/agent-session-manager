#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants for TASK-260830-17ootk rev1.

Each plant weakens one classification predicate the producer did not
mutate, admitting exactly one member of the rejected class while the
gate stays present. R-control is an applied harmless SURVIVED control.
Runs in /tmp/iso17 (isolated candidate copy), never the live tree."""
import json, subprocess, sys
from pathlib import Path

ISO = Path("/tmp/iso17")
LOG = Path("/tmp/iso17-revmutlogs")
GO = ["go", "test", "./internal/crashgate/", "-count=1"]
STATIC = GO + ["-run", "TestRegistryDerivesFromPinnedSpec|TestRegistryStructure"]

PLANTS = [
    {"id": "R-lease-forward", "kind": "narrowing",
     "file": "internal/matjournal/recover.go",
     "weakening": "lease-moved gate admits a forward epoch move (epoch != becomes epoch <)",
     "killer": "TestCrashGateRejections/lease_moved_forward",
     "find": "if input.LeaseKnown && (input.LeaseAfter.Epoch != input.LeaseBefore.Epoch || input.LeaseAfter.ID != input.LeaseBefore.ID) {",
     "replace": "if input.LeaseKnown && (input.LeaseAfter.Epoch < input.LeaseBefore.Epoch || input.LeaseAfter.ID != input.LeaseBefore.ID) {",
     "expect_static": "any", "expect_behavior": "fail"},
    {"id": "R-substitution-leaseactive", "kind": "narrowing",
     "file": "internal/matjournal/recover.go",
     "weakening": "substitution gate admits a fresh handle when the losing lease still reads active",
     "killer": "TestCrashGateRejections/new_session_launch",
     "find": "if input.NativeAfter != input.NativeBefore {",
     "replace": "if input.NativeAfter != input.NativeBefore && !input.Bridge.LeaseActive {",
     "expect_static": "any", "expect_behavior": "fail"},
    {"id": "R-exhaustiveness-rollback-contradiction", "kind": "narrowing",
     "file": "internal/matjournal/recover.go",
     "weakening": "rollback-phase contradiction arm removed (rollback with activated sub-state no longer parks)",
     "killer": "TestCrashGateMutualExclusion/contradictory_rollback_with_activation_parks",
     'find': '\tif (journal.Phase == PhaseRollingBack || journal.Phase == PhaseRolledBack) &&\n\t\t((journal.TaskBoard != nil && (journal.TaskBoard.State == BoardAdopted || journal.TaskBoard.State == BoardResumed)) ||\n\t\t\t(journal.Provider != nil && journal.Provider.State == ProviderCommitted)) {\n\t\treturn assessment.park("integrity_failure", "journal contradicts itself: rollback phase with an activated sub-state",\n\t\t\t"inspect the torn journal progression, restore a verified copy, then re-run recovery")\n\t}\n',
     "replace": "",
     "expect_static": "any", "expect_behavior": "fail"},
    {"id": "R-registry-stop02", "kind": "narrowing",
     "file": "internal/crashgate/registry.go",
     "weakening": "CR-STOP-02 direct path flipped reachable to NOT APPLICABLE with an owner; the CR-STOP-02 token is preserved",
     "killer": "TestCrashGateConformance|TestCrashGateNotApplicable",
     "find": '{Name: PathDirect, Reachable: true, Driver: DriverCheckpointCapture, Note: "stop checkpoint through the capture blob/receipt seam"},',
     "replace": '{Name: PathDirect, Owner: "stop execution runtime (Section 13.9; stop execution unlanded)", Note: "stop checkpoint through the capture blob/receipt seam"},',
     "expect_static": "pass", "expect_behavior": "fail"},
    {"id": "R-control-comment", "kind": "control",
     "file": "internal/matjournal/recover.go",
     "weakening": "comment-only edit (harmless control)",
     "killer": "none (behavioral suite must pass)",
     "find": "// Recover classifies one crashed materialization after a clean restart",
     "replace": "// Recover classifies one crashed materialization after a clean restart (reviewer control)",
     "expect_static": "pass", "expect_behavior": "pass"},
]

def run(cmd):
    p = subprocess.run(cmd, cwd=ISO, capture_output=True, text=True, timeout=300)
    return p.returncode, p.stdout + p.stderr

def main():
    LOG.mkdir(parents=True, exist_ok=True)
    originals = {}
    for pl in PLANTS:
        if pl["file"] not in originals:
            originals[pl["file"]] = (ISO / pl["file"]).read_text()

    def restore():
        for name, text in originals.items():
            (ISO / name).write_text(text)

    code, out = run(GO + ["-run", "TestCrashGate"])
    (LOG / "preflight.log").write_text(f"returncode={code}\n{out}\n")
    if code != 0:
        print("preflight fails; aborting")
        return 2
    results = []
    try:
        for pl in PLANTS:
            pid = pl["id"]
            path = ISO / pl["file"]
            cur = path.read_text()
            n = cur.count(pl["find"])
            entry = {"id": pid, "kind": pl["kind"], "file": pl["file"],
                     "weakening": pl["weakening"], "killer": pl["killer"]}
            log = [f"plant {pid}: {pl['weakening']}"]
            if n != 1:
                entry["verdict"] = "NOT_APPLIED"
                entry["detail"] = f"pattern occurs {n} times"
                (LOG / f"{pid}.log").write_text("\n".join(log) + "\n")
                results.append(entry)
                continue
            path.write_text(cur.replace(pl["find"], pl["replace"]))
            sc, sout = run(STATIC)
            killer = pl["killer"] if pl["killer"] != "none (behavioral suite must pass)" else "TestCrashGate"
            bc, bout = run(GO + ["-run", killer])
            log.append(f"static returncode={sc}\n{sout}")
            log.append(f"killer {killer} returncode={bc}\n{bout}")
            entry["static"] = "pass" if sc == 0 else "fail"
            entry["behavior"] = "pass" if bc == 0 else "fail"
            if pl["kind"] == "control":
                entry["verdict"] = "SURVIVED" if bc == 0 else "UNEXPECTED_KILL"
            else:
                entry["verdict"] = "KILLED" if bc != 0 else "SURVIVED"
            (LOG / f"{pid}.log").write_text("\n".join(log) + "\n")
            results.append(entry)
            restore()
    finally:
        restore()
    summary = {"plants": results,
               "killed": sum(1 for r in results if r["verdict"] == "KILLED"),
               "survived": sum(1 for r in results if r["verdict"] == "SURVIVED"),
               "not_applied": sum(1 for r in results if r["verdict"] == "NOT_APPLIED"),
               "anomalies": [r for r in results if r["verdict"] not in ("KILLED", "SURVIVED")]}
    (LOG / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(f"reviewer mutants: {summary['killed']} killed, {summary['survived']} survived, "
          f"{summary['not_applied']} not applied, anomalies={len(summary['anomalies'])}")
    for r in results:
        print(" ", r["id"], r["verdict"], r.get("static"), r.get("behavior"))
    ok = (all(r["verdict"] == "KILLED" for r in results if r["kind"] == "narrowing")
          and all(r["verdict"] == "SURVIVED" for r in results if r["kind"] == "control"))
    return 0 if ok else 1

sys.exit(main())
