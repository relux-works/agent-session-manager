#!/usr/bin/env python3
"""Reviewer rerun: apply each producer KILLED plant once more, run its
named killer twice, restore. Prints per-plant subprocess exits."""
import subprocess, sys
from pathlib import Path

ISO = Path("/tmp/iso17")
GO = ["go", "test", "./internal/crashgate/", "-count=1", "-run"]

PLANTS = [
    ("N-registry-grace11", "internal/crashgate/registry.go",
     '{Name: PathTaskBoard, Reachable: true, Driver: DriverJournalActivation, Note: "task-board activation through the journal-activation seam, evaluated with the graceful_takeover path"},',
     '{Name: PathTaskBoard, Reachable: false, Owner: "task-board bridge runtime (Section 9/13.2; launch/export/adopt execution unlanded)", Note: "task-board activation through the journal-activation seam, evaluated with the graceful_takeover path"},',
     "TestCrashGateConformance|TestCrashGateNotApplicable"),
    ("N-recover-lease-backward", "internal/matjournal/recover.go",
     "if input.LeaseKnown && (input.LeaseAfter.Epoch != input.LeaseBefore.Epoch || input.LeaseAfter.ID != input.LeaseBefore.ID) {",
     "if input.LeaseKnown && (input.LeaseAfter.Epoch > input.LeaseBefore.Epoch || input.LeaseAfter.ID != input.LeaseBefore.ID) {",
     "TestCrashGateRejections/lease_moved_backward"),
    ("N-recover-native-blank", "internal/matjournal/recover.go",
     "if input.NativeAfter != input.NativeBefore {",
     'if input.NativeAfter != input.NativeBefore && input.NativeAfter != "" {',
     "TestCrashGateRejections/blank_relabel"),
    ("N-recover-two-auth-manager", "internal/matjournal/recover.go",
     "assessment.bridgeLive() && !input.Bridge.BindingMatches {",
     "assessment.bridgeLive() && !input.Bridge.BindingMatches && input.Bridge.ManagerMatches {",
     "TestCrashGateRejections/two_live_authorities"),
    ("N-recover-unfenced-live", "internal/matjournal/recover.go",
     "if assessment.bridgeLive() && !input.Bridge.LeaseActive && assessment.bridgeAdopted() {",
     "if input.Bridge.Live && !input.Bridge.LeaseActive && assessment.bridgeAdopted() {",
     "TestCrashGateRejections/unfenced_state_liveness"),
    ("N-recover-host-rename", "internal/matjournal/recover.go",
     '\tcase HostRenameBlocked:\n\t\treturn assessment.park("staging_incomplete", "atomic rename blocked: staging retained, never overwritten in place",\n\t\t\t"close the blocking handles, then retry the same operation")\n',
     "",
     "TestCrashGateSection1312/rename_blocked_probe_parks"),
    ("N-recover-marker-mismatch", "internal/matjournal/recover.go",
     '\tcase MarkerMismatch:\n\t\treturn assessment.park("integrity_failure", "destination marker disagrees with the journal (MJ-CRASH-MARKER-MISMATCH): quarantined, nothing further mutates",\n\t\t\t"quarantine the transaction, reconcile the marker against the plan and checkpoint, then re-run recovery")\n',
     "",
     "TestCrashGateMutualExclusion/marker_mismatch_parks"),
    ("N-recover-provider-floor", "internal/matjournal/recover.go",
     "return boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterPrepareOp)",
     "return boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterOpen)",
     "TestCrashGateMutualExclusion/unknown_unrecorded_prepare_parks"),
    ("N-recover-bridge-floor", "internal/matjournal/recover.go",
     '\tcase BoardNotStarted:\n\t\treturn boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterPrepareOp)',
     '\tcase BoardNotStarted:\n\t\treturn boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterOpen)',
     "TestCrashGateMutualExclusion/unknown_unrecorded_import_parks"),
]

# provider/bridge floor patterns occur twice; disambiguate like the harness does not —
# the harness requires exactly 1 occurrence, so these two need context. Handle below.
FLOOR_CTX = {
    "N-recover-provider-floor": ("\tif journal.Provider != nil {\n\t\treturn journal.Phase == PhasePrepared || journal.Phase == PhaseCommitting ||\n\t\t\tjournal.Phase == PhaseRollingBack\n\t}\n\treturn boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterPrepareOp)",
     "\tif journal.Provider != nil {\n\t\treturn journal.Phase == PhasePrepared || journal.Phase == PhaseCommitting ||\n\t\tjournal.Phase == PhaseRollingBack\n\t}\n\treturn boundaryAtOrAfter(assessment.input.Boundary, BoundaryAfterOpen)"),
}

def run(cmd):
    p = subprocess.run(cmd, cwd=ISO, capture_output=True, text=True, timeout=300)
    return p.returncode

def main():
    _orig = {}
    for _, f, _, _, _ in PLANTS:
        if f not in _orig:
            _orig[f] = (ISO / f).read_text()
    # fix floor plants to full-context patterns
    plants = []
    for pid, f, find, repl, killer in PLANTS:
        if pid in FLOOR_CTX:
            find, repl = FLOOR_CTX[pid]
        plants.append((pid, f, find, repl, killer))
    fails = 0
    try:
        for pid, f, find, repl, killer in plants:
            cur = (ISO / f).read_text()
            n = cur.count(find)
            if n != 1:
                print(f"{pid}: NOT_APPLIED occurs={n}")
                fails += 1
                continue
            (ISO / f).write_text(cur.replace(find, repl))
            # N-recover-provider-floor full-context replace keeps other occurrence intact
            codes = [run(GO + [killer]), run(GO + [killer])]
            print(f"{pid}: killer-runs exits={codes} (want [1, 1])")
            if codes != [1, 1]:
                fails += 1
            (ISO / f).write_text(_orig[f])
    finally:
        for f, t in _orig.items():
            (ISO / f).write_text(t)
    print("RERUN-FAILURES:", fails)
    return 1 if fails else 0

sys.exit(main())
