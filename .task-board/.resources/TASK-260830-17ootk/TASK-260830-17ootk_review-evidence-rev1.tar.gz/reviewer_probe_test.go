package crashgate

// Independent reviewer probes for TASK-260830-17ootk rev1 (CR-MAT-03,
// CR-MAT-06, CR-STOP-02 plus one unmodeled torn variant per
// boundary). These drive the production entries directly with seams
// the shipped harness rows do not use, and assert exactly one
// Section 13.13 outcome with fail-closed parking on contradictory
// or torn evidence.

import (
	"errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

// reviewerBlobPath returns the single installed checkpoint blob under
// dataDir, failing when the crash left anything but one blob.
func reviewerBlobPath(t *testing.T, dataDir string) string {
	t.Helper()
	root := filepath.Join(dataDir, "checkpoints")
	entries, err := os.ReadDir(root)
	if err != nil {
		t.Fatal(err)
	}
	var blobs []string
	for _, entry := range entries {
		if !entry.IsDir() {
			blobs = append(blobs, filepath.Join(root, entry.Name()))
		}
	}
	if len(blobs) != 1 {
		t.Fatalf("blobs = %d, want exactly 1 after the crash", len(blobs))
	}
	return blobs[0]
}

// TestReviewerProbeCRSTOP02Converges crashes CR-STOP-02 (direct) at
// the after_blob seam through the production Capture entry with the
// reviewer's own hook, restarts clean, and proves the identical
// retry converges byte-identical with no second identity.
func TestReviewerProbeCRSTOP02Converges(t *testing.T) {
	repoDir, created := chainFixture(t)
	store, dataDir := checkpointDirs(t)
	inputs := captureInputs([]string{created}, testOpA)
	interrupted := errors.New("reviewer crash after blob")
	store.AfterBlob = func() error { return interrupted }
	if _, _, err := store.Capture(mustOpenRepo(t, repoDir), inputs); !errors.Is(err, interrupted) {
		t.Fatalf("Capture fault = %v, want the reviewer crash", err)
	}
	if blobs, receipts := countCheckpointFiles(t, dataDir); blobs != 1 || receipts != 0 {
		t.Fatalf("after crash: blobs = %d receipts = %d, want 1 0", blobs, receipts)
	}
	restarted := reopenCheckpoint(t, dataDir)
	chain := mustOpenRepo(t, repoDir)
	ref, raw, err := restarted.Capture(chain, inputs)
	if err != nil {
		t.Fatalf("retry Capture error = %v", err)
	}
	if _, _, err := sessrepo.AttestCheckpointRecord(raw); err != nil {
		t.Fatalf("retry bytes do not attest: %v", err)
	}
	again, againRaw, err := restarted.Capture(chain, inputs)
	if err != nil {
		t.Fatalf("replay Capture error = %v", err)
	}
	if again != ref || string(againRaw) != string(raw) {
		t.Fatalf("replay diverged: same operation must converge on one checkpoint")
	}
	if blobs, receipts := countCheckpointFiles(t, dataDir); blobs != 1 || receipts != 1 {
		t.Fatalf("after retry: blobs = %d receipts = %d, want 1 1", blobs, receipts)
	}
}

// TestReviewerProbeCRSTOP02TornBlobRefuses plants the unmodeled
// variant for CR-STOP-02: a torn write leaves disagreeing bytes at
// the digest path the crashed capture installed. The retry must
// refuse with ErrCheckpointConflict, leave the torn bytes in place
// (no silent overwrite), and create no receipt and no second
// checkpoint identity.
func TestReviewerProbeCRSTOP02TornBlobRefuses(t *testing.T) {
	repoDir, created := chainFixture(t)
	store, dataDir := checkpointDirs(t)
	inputs := captureInputs([]string{created}, testOpA)
	interrupted := errors.New("reviewer crash after blob")
	store.AfterBlob = func() error { return interrupted }
	if _, _, err := store.Capture(mustOpenRepo(t, repoDir), inputs); !errors.Is(err, interrupted) {
		t.Fatalf("Capture fault = %v, want the reviewer crash", err)
	}
	blobPath := reviewerBlobPath(t, dataDir)
	torn := []byte(`{"torn":true,"partial":`)
	if err := os.WriteFile(blobPath, torn, 0o600); err != nil {
		t.Fatal(err)
	}
	restarted := reopenCheckpoint(t, dataDir)
	_, _, err := restarted.Capture(mustOpenRepo(t, repoDir), inputs)
	if !errors.Is(err, sessckpt.ErrCheckpointConflict) {
		t.Fatalf("retry over torn blob = %v, want ErrCheckpointConflict refusal", err)
	}
	kept, err := os.ReadFile(blobPath)
	if err != nil {
		t.Fatal(err)
	}
	if string(kept) != string(torn) {
		t.Fatalf("torn bytes were overwritten: store must never silently replace digest-addressed bytes")
	}
	if _, receipts := countCheckpointFiles(t, dataDir); receipts != 0 {
		t.Fatalf("receipts = %d, want 0: the refused retry must install nothing", receipts)
	}
}

// TestReviewerProbeCRMAT03TornJournalParks crashes CR-MAT-03 after
// transfer progress through RecordProgress, then applies the
// unmodeled variant: a torn write truncates journal.json to a
// partial prefix. Recovery must select exactly
// recoverable_parked_state with durable blocking evidence and a
// frozen phase — never safe_retry over torn bytes and never a
// fourth outcome.
func TestReviewerProbeCRMAT03TornJournalParks(t *testing.T) {
	store, dataDir := journalDirs(t)
	mustCreate(t, store, compositeInputs())
	if _, err := store.RecordProgress(testMatID, map[string][]uint32{testBlobA: {0}}, nil); err != nil {
		t.Fatal(err)
	}
	journalPath := filepath.Join(dataDir, "materializations", testMatID, "journal.json")
	raw, err := os.ReadFile(journalPath)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(journalPath, raw[:len(raw)/2], 0o600); err != nil {
		t.Fatal(err)
	}
	restarted := reopenJournal(t, dataDir)
	input := baseRecoveryInput()
	input.Boundary = matjournal.BoundaryAfterTransfer
	input.Path = matjournal.PathOwnerResume
	input.Provider = matjournal.ProviderProbe{State: matjournal.ProviderUnknown}
	outcome, evidence, err := restarted.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover over torn journal error = %v, want a parked assessment", err)
	}
	mustOutcome(t, outcome, matjournal.OutcomeRecoverableParked, "Recover(reviewer torn CR-MAT-03)")
	// A torn journal cannot name operation IDs or phases: the
	// quarantined evidence carries unknown phases and no operation
	// IDs by construction. Assert the parked refusal itself.
	if evidence.Boundary != matjournal.BoundaryAfterTransfer || evidence.Path != matjournal.PathOwnerResume {
		t.Fatalf("evidence names %s/%s, want CR-MAT-03/owner_resume", evidence.Boundary, evidence.Path)
	}
	if evidence.Reason == "" || evidence.Remediation == "" || evidence.DecidedAt == "" {
		t.Fatalf("parked evidence lacks reason, remediation, or decided_at: %+v", evidence)
	}
	if !recoveryJSONExists(t, dataDir) {
		t.Fatalf("parked assessment left no durable recovery.json")
	}
	loaded, _, err := restarted.Get(testMatID)
	if err == nil && loaded.Phase != matjournal.PhaseStaging {
		t.Fatalf("phase = %q after torn park, want the frozen staging phase", loaded.Phase)
	}
}

// TestReviewerProbeCRMAT06AdoptCrashSubstitutionParks crashes at
// the adopt seam on the CR-MAT-06 path (composite journal converged
// to committing, adopt recorded through a crashing UpdateTaskBoard),
// then recovers with a substituted native handle: the probe attests
// a different manager identity than the adopted binding carries.
// Recovery must park with durable blocking evidence and a frozen
// phase — the adopted journal must not be reported as a successful
// retry under a fresh handle, and no second allocation may occur.
func TestReviewerProbeCRMAT06AdoptCrashSubstitutionParks(t *testing.T) {
	store, dataDir := journalDirs(t)
	mustCreate(t, store, compositeInputs())
	convergePrepared(t, store)
	if _, err := store.Transition(testMatID, matjournal.PhaseCommitting, matjournal.TransitionOpts{}); err != nil {
		t.Fatal(err)
	}
	interrupted := errors.New("reviewer crash at the adopt seam")
	store.AfterJournal = func() error { return interrupted }
	if _, err := store.UpdateTaskBoard(testMatID, adoptedBoard()); !errors.Is(err, interrupted) {
		t.Fatalf("UpdateTaskBoard fault = %v, want the reviewer crash", err)
	}
	restarted := reopenJournal(t, dataDir)
	loaded, _, err := restarted.Get(testMatID)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.TaskBoard.State != matjournal.BoardAdopted {
		t.Fatalf("task-board = %q, want the durable adopted state", loaded.TaskBoard.State)
	}
	input := baseRecoveryInput()
	input.Boundary = matjournal.BoundaryAfterActivation
	input.Path = matjournal.PathOwnerResume
	input.Bridge = matjournal.BridgeProbe{State: matjournal.BoardAdopted, LeaseActive: true, BindingMatches: true, ManagerMatches: true}
	input.NativeKnown = true
	input.NativeBefore = testNative
	input.NativeAfter = "tbm:manager:0198f4c8-7a10-7b22-8b3c-aaaaaaaaaaaaaaaa:" + testLeaseID
	outcome, evidence, err := restarted.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover over substituted native error = %v, want a parked assessment", err)
	}
	mustOutcome(t, outcome, matjournal.OutcomeRecoverableParked, "Recover(reviewer substituted CR-MAT-06 path)")
	mustJournalEvidenceComplete(t, evidence, "Recover(reviewer substituted CR-MAT-06 path)")
	parkedMustFailClosed(t, dataDir, string(loaded.Phase), evidence, "Recover(reviewer substituted CR-MAT-06 path)")
	after, _, err := restarted.Get(testMatID)
	if err != nil {
		t.Fatal(err)
	}
	if after.TaskBoard.State != matjournal.BoardAdopted {
		t.Fatalf("task-board = %q after park, want the frozen adopted state", after.TaskBoard.State)
	}
	if after.TaskBoard.ManagerSessionRef == nil || *after.TaskBoard.ManagerSessionRef != "tbm:manager:0198f4c8-7a10-7b22-8b3c-2234567890ab" {
		t.Fatalf("manager reference moved under substitution: %+v", after.TaskBoard.ManagerSessionRef)
	}
}

// TestReviewerProbeRollbackPlusMovedLeaseParks attacks evaluator
// ordering: the input carries rollback-required facts (bridge
// failed before the new lease with a prepared provider, which
// alone selects explicit_rollback) AND a moved winning lease
// (which alone selects recoverable_parked_state). Recovery must
// select exactly recoverable_parked_state and must NOT execute the
// rollback: the journal phase stays staging, not rolled_back.
func TestReviewerProbeRollbackPlusMovedLeaseParks(t *testing.T) {
	store, dataDir := journalDirs(t)
	mustCreate(t, store, compositeInputs())
	if _, err := store.UpdateProvider(testMatID, preparedProvider()); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdateTaskBoard(testMatID, importedBoard()); err != nil {
		t.Fatal(err)
	}
	restarted := reopenJournal(t, dataDir)
	input := baseRecoveryInput()
	input.Boundary = matjournal.BoundaryAfterPrepareOp
	input.Path = matjournal.PathOwnerResume
	input.Bridge.State = matjournal.BoardFailed
	input.Bridge.Failed = true
	input.Bridge.LeaseActive = false
	input.LeaseAfter = matjournal.LeaseIdentity{Epoch: 5, ID: testLeaseID}
	outcome, evidence, err := restarted.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover error = %v, want a parked assessment", err)
	}
	mustOutcome(t, outcome, matjournal.OutcomeRecoverableParked, "Recover(reviewer rollback+moved-lease)")
	loaded, _, err := restarted.Get(testMatID)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Phase == matjournal.PhaseRolledBack || loaded.Phase == matjournal.PhaseRollingBack {
		t.Fatalf("phase = %q: rollback executed over a moved lease", loaded.Phase)
	}
	if len(loaded.LastError) == 0 {
		t.Fatalf("parked assessment recorded no blocking last_error")
	}
	_ = evidence
	_ = dataDir
}
