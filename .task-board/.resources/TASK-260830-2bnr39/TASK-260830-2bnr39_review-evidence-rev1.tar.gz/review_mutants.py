import subprocess, pathlib, json, os, re
root=pathlib.Path(__file__).resolve().parent
work=root/'mutant-candidate'
snap=work/'internal/gitsnap/snapshot.go'
original=snap.read_text()
logdir=root/'mutation-logs';logdir.mkdir(exist_ok=True)
env=dict(os.environ,GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null')
rows=json.loads((root/'mutants.json').read_text())
neutral=['C-neutral-comment','','',[],[],0,'survive',True]
bad=next(x for x in rows if x[0]=='C-bad-inverted-sort')
rows=[neutral,bad]+[x for x in rows if x is not bad]
results=[]
def run(name,args):
 with (logdir/(name+'.log')).open('w') as f:
  f.write('$ '+' '.join(args)+'\n');f.flush()
  p=subprocess.run(args,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
  f.write('\nEXIT='+str(p.returncode)+'\n')
 return p.returncode
try:
 for row in rows:
  name,old,new,fails,passes=row[:5]
  limit=row[5] if len(row)>5 else 0
  expect=row[6] if len(row)>6 else 'kill'
  full=(row[7] if len(row)>7 else False) or expect=='survive'
  if name=='C-neutral-comment': changed=original+'\n// reviewer neutral control\n'
  elif (not limit and original.count(old)!=1) or (limit and original.count(old)<limit):
   results.append([name,'NOT_APPLIED']);continue
  else: changed=original.replace(old,new,limit or original.count(old))
  snap.write_text(changed)
  c=run(name+'.compile',['go','test','./internal/gitsnap','-run','^$','-count=1'])
  if c: results.append([name,'COMPILE_FAILED']);snap.write_text(original);continue
  args=['go','test','./internal/gitsnap','-v','-count=1']
  if not full:args+=['-run','^('+'|'.join(fails)+')$']
  c=run(name+'.behavior',args)
  body=(logdir/(name+'.behavior.log')).read_text()
  failing=re.findall(r'^--- FAIL: (\S+)',body,re.M)
  p=run(name+'.positive',['go','test','./internal/gitsnap','-v','-count=1','-run','^('+'|'.join(passes)+')$']) if passes else None
  status=('NEUTRAL_PASS' if c==0 else 'NEUTRAL_FAILED') if expect=='survive' else ('BEHAVIOR_KILL' if c and all(x in failing for x in fails) and p in (None,0) else 'SURVIVED_OR_WRONG_FAILURE')
  results.append([name,status,c,p,failing]);print(results[-1],flush=True)
  snap.write_text(original)
finally:
 snap.write_text(original)
 (root/'mutation-results.json').write_text(json.dumps(results,indent=2))
 assert snap.read_text()==original
