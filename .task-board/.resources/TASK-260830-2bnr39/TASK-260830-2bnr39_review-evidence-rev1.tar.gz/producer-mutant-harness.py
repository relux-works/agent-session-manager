#!/usr/bin/env python3
"""Narrowing-mutant + clause-disablement harness for internal/gitsnap.

Every mutant weakens one gate to admit exactly one member of the class
it must reject (numeric narrowings M1-M7,M9, cross-format M8, sort M9,
token-preserving swaps M10-M11) or disables one refusal clause (M12-M16).
Controls: C-neutral (comment-only, must stay green) and C-bad (broken
comparator, must redden). A mutant that does not apply or does not
compile is reported UNMEASURED, never a pass. All test runs use -count=1.
"""
import subprocess
import shutil
import os
import sys

WORKTREE = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-35dbcs/worktree"
PKG = "internal/gitsnap"
SNAP = os.path.join(WORKTREE, PKG, "snapshot.go")
BACKUP = "/tmp/gitsnap-mutants/snapshot.go.bak"
LOGDIR = "/tmp/gitsnap-mutants/logs"

MUTANTS = [
    ("M1-stage-admits-4", "stageValue > 3", "stageValue > 4",
     ["TestRefuseIndexStageFour"], ["TestEdgeStageThreeAccepts"]),
    ("M2-version-admits-5", '[]string{"2", "3", "4"}', '[]string{"2", "3", "4", "5"}',
     ["TestRefuseIndexVersionFive"], ["TestCompatIndexVersions"]),
    ("M3-remotes-admits-17", "len(names) > maxRemotes", "len(names) > maxRemotes+1",
     ["TestEdgeRemotesSeventeenRefuses"], ["TestEdgeRemotesSixteenAccepts"]),
    ("M4-entries-admits-65537", "len(entries) > maxIndexEntries", "len(entries) > maxIndexEntries+1",
     ["TestEdgeIndexMaxPlusOneRefuses"], ["TestEdgeIndexMaxAccepts"]),
    ("M5-identity-admits-257", "count > maxIdentityRune", "count > maxIdentityRune+1",
     ["TestEdgeIdentity257CharsRefuses"], ["TestEdgeIdentity256CharsAccepts"]),
    ("M6-unborn-admits-tags", 'strings.HasPrefix(ref, "refs/heads/")', 'strings.HasPrefix(ref, "refs/")',
     ["TestRefuseUnbornNonBranchRef"], []),
    ("M7-delta-admits-X", "if !known {", 'if !known && letter != "X" {',
     ["TestRefuseUnknownDeltaStatus"], []),
    ("M8b-branch-admits-40hex-in-sha256-repo",
     '\t\tparsedOID, err := scalar.ParseGitOIDForObjectFormat(objectFormat+":"+oid, objectFormat)\n\t\tif err != nil {\n\t\t\treturn Head{}, refuse(GateHeadOIDFormat, "HEAD oid invalid: "+err.Error())\n\t\t}',
     '\t\tparsedOID, err := scalar.ParseGitOIDForObjectFormat(objectFormat+":"+oid, objectFormat)\n\t\tif err != nil && len(oid) != 40 {\n\t\t\treturn Head{}, refuse(GateHeadOIDFormat, "HEAD oid invalid: "+err.Error())\n\t\t}\n\t\tif err != nil {\n\t\t\tparsedOID, _ = scalar.ParseGitOID("sha1:" + oid)\n\t\t}',
     ["TestRefuseCrossFormatOID"], ["TestCompatSHA256ObjectFormat"]),
    ("C-neutral-oid-swap-survives",
     'scalar.ParseGitOIDForObjectFormat(objectFormat+":"+oid, objectFormat)',
     'scalar.ParseGitOID(objectFormat+":"+oid)',
     [], [], 1, "survive"),
    ("M9-sort-admits-duplicate", "current.Stage <= previous.Stage", "current.Stage < previous.Stage",
     ["TestRefuseDuplicateIndexEntry"], ["TestRefuseUnsortedIndex"]),
    ("M10-fetch-push-swapped",
     '\t\tcase "(fetch)":\n\t\t\tfetch[name] = url\n\t\tcase "(push)":\n\t\t\tpush[name] = url',
     '\t\tcase "(fetch)":\n\t\t\tpush[name] = url\n\t\tcase "(push)":\n\t\t\tfetch[name] = url',
     ["TestRemoteFetchPushMapping"], ["TestAcceptBaselineSnapshot"], 0, "kill", True),
    ("M11-assume-bit-swapped",
     "AssumeUnchanged: flags&flagAssumeUnchanged != 0,",
     "AssumeUnchanged: flags&flagSkipWorktree != 0,",
     ["TestCaptureLiveBranchRepository"], [], 0, "kill", True),
    ("M17-push-credential-admission",
     '\t\t\tpushURL, err := scalar.ParseSanitizedGitURL(url)\n\t\t\tif err != nil {\n\t\t\t\treturn nil, refuse(GateRemoteURL, "remote "+strconv.Quote(name)+" push URL: "+err.Error())\n\t\t\t}\n\t\t\tvalue := pushURL.String()\n\t\t\tremote.PushURL = &value',
     '\t\t\tpushURL, _ := scalar.ParseSanitizedGitURL(url)\n\t\t\tvalue := url\n\t\t\t_ = pushURL\n\t\t\tremote.PushURL = &value',
     ["TestRefuseCredentialPushURL"], ["TestRemoteFetchPushMapping"]),
    ("M18-index-admits-8hex-oid",
     '\tparsedOID, err := scalar.ParseGitOIDForObjectFormat(objectFormat+":"+parts[1], objectFormat)\n\tif err != nil {\n\t\treturn IndexEntry{}, nil, refuse(GateIndexEntry, "index oid invalid: "+err.Error())\n\t}',
     '\tparsedOID, err := scalar.ParseGitOIDForObjectFormat(objectFormat+":"+parts[1], objectFormat)\n\tif err != nil && len(parts[1]) != 8 {\n\t\treturn IndexEntry{}, nil, refuse(GateIndexEntry, "index oid invalid: "+err.Error())\n\t}\n\tif err != nil {\n\t\tparsedOID, _ = scalar.ParseGitOID("sha1:" + parts[1] + strings.Repeat("0", 32))\n\t}',
     ["TestRefuseIndexBadOID"], ["TestRefuseIndexBadMode"]),
    ("M19-worktree-admits-fifo",
     '\tdefault:\n\t\treturn "", 0, refuse(GateWorktreeKind, "unsupported special file "+strconv.Quote(name))',
     '\tdefault:\n\t\tif mode&os.ModeNamedPipe != 0 {\n\t\t\treturn KindOther, 0, nil\n\t\t}\n\t\treturn "", 0, refuse(GateWorktreeKind, "unsupported special file "+strconv.Quote(name))',
     ["TestRefuseSpecialWorktreeFile"], ["TestCaptureLiveBranchRepository"]),
    ("M12-remotes-min-disabled", "if len(names) < 1 {", "if len(names) < 0 {",
     ["TestRefuseNoRemotes"], []),
    ("M13-branch-ref-clause-disabled",
     'return Head{}, refuse(GateHeadRef, "HEAD ref invalid: "+err.Error())',
     'parsedRef, _ = scalar.ParseGitRef("refs/heads/mutant")',
     ["TestRefuseBranchWithLiteralHeadRef"], []),
    ("M14-consistency-index-clause-disabled",
     "if !bytes.Equal(again, indexBytes) {",
     "if false && !bytes.Equal(again, indexBytes) {",
     ["TestConsistencyRefusesIndexMutationArmedOnce"], ["TestConsistencyRefusesHeadMutation"]),
    ("M15-corrupt-head-clause-disabled",
     'return Head{}, refuse(GateHeadCorrupt, "HEAD names no ref and no commit")',
     'return Head{Mode: "detached"}, nil',
     ["TestRefuseCorruptHead"], []),
    ("M16-upstream-clause-disabled",
     'return nil, refuse(GateUpstreamRef, "upstream ref invalid: "+perr.Error())',
     'parsed, _ = scalar.ParseGitRef("refs/healed/mutant")',
     ["TestRefuseBadUpstream"], []),
    ("C-bad-inverted-sort",
     "if current.Path < previous.Path", "if current.Path > previous.Path",
     ["TestAcceptBaselineSnapshot"], []),
]

os.makedirs(LOGDIR, exist_ok=True)
with open(SNAP) as handle:
    ORIGINAL = handle.read()
with open(BACKUP, "w") as handle:
    handle.write(ORIGINAL)


def run_tests(name, tests, full=False):
    if not tests and not full:
        return None
    if full:
        args = ["go", "test", "./" + PKG + "/", "-count=1"]
    else:
        pattern = "^(" + "|".join(tests) + ")$"
        args = ["go", "test", "./" + PKG + "/", "-count=1", "-run", pattern]
    log = os.path.join(LOGDIR, name + ".log")
    with open(log, "w") as handle:
        proc = subprocess.run(args, cwd=WORKTREE, stdout=handle, stderr=subprocess.STDOUT)
    return proc.returncode


def restore():
    with open(BACKUP) as handle:
        backup = handle.read()
    with open(SNAP, "w") as handle:
        handle.write(backup)


rows = []
for mutant in MUTANTS:
    name, old, new = mutant[0], mutant[1], mutant[2]
    must_fail, must_pass = mutant[3], mutant[4]
    limit = mutant[5] if len(mutant) > 5 else 0
    expect = mutant[6] if len(mutant) > 6 else "kill"
    full = mutant[7] if len(mutant) > 7 else False
    occurrences = ORIGINAL.count(old)
    if limit:
        ok = ORIGINAL.count(old) >= 1
    else:
        ok = occurrences == 1
    if not ok:
        rows.append((name, "UNMEASURED", "pattern found %d times" % occurrences, "-", "-"))
        continue
    if limit:
        mutated = ORIGINAL.replace(old, new, limit)
    else:
        mutated = ORIGINAL.replace(old, new)
    with open(SNAP, "w") as handle:
        handle.write(mutated)
    build = subprocess.run(["go", "vet", "./" + PKG + "/"], cwd=WORKTREE,
                           capture_output=True)
    if build.returncode != 0:
        rows.append((name, "UNMEASURED", "mutant did not compile", "-", "-"))
        restore()
        continue
    fail_code = run_tests(name + ".mustfail", must_fail, full)
    if full and fail_code not in (None, 0):
        with open(os.path.join(LOGDIR, name + ".mustfail.log")) as handle:
            body = handle.read()
        for wanted in must_fail:
            if "--- FAIL: " + wanted not in body:
                fail_code = 0
                print("%s WARNING: full-suite failure not driven by %s" % (name, wanted), flush=True)
    pass_code = run_tests(name + ".mustpass", must_pass)
    restore()
    if expect == "survive":
        verdict = "SURVIVED-NEUTRAL-OK" if fail_code in (None, 0) else "KILLED-UNEXPECTED"
    else:
        verdict = "KILLED" if (fail_code not in (None, 0) and pass_code in (None, 0)) else "SURVIVED-HOLE"
    rows.append((name, verdict,
                 "mustfail exit=%s" % fail_code,
                 "mustpass exit=%s" % pass_code,
                 ",".join(must_fail)))
    print("%s mustfail=%s mustpass=%s -> %s" % (name, fail_code, pass_code, verdict), flush=True)

with open(SNAP) as handle:
    assert handle.read() == ORIGINAL, "snapshot.go not restored"
print("restore verified: snapshot.go identical to backup")

# C-neutral-comment: a comment-only change must leave the suite green,
# proving the harness actually runs the gates (exit 0 is measured, and
# the C-bad row proves the same harness reddens).
with open(SNAP, "w") as handle:
    handle.write(ORIGINAL + "\n// C-neutral-comment control: no behavior change.\n")
log = os.path.join(LOGDIR, "C-neutral-comment.log")
with open(log, "w") as handle:
    proc = subprocess.run(["go", "test", "./" + PKG + "/", "-count=1"],
                          cwd=WORKTREE, stdout=handle, stderr=subprocess.STDOUT)
restore()
comment_verdict = "SURVIVED-NEUTRAL-OK" if proc.returncode == 0 else "KILLED-UNEXPECTED"
rows.append(("C-neutral-comment", comment_verdict,
             "full suite exit=%s" % proc.returncode, "-", "-"))
print("C-neutral-comment full suite exit=%s -> %s" % (proc.returncode, comment_verdict))

with open(SNAP) as handle:
    assert handle.read() == ORIGINAL, "snapshot.go not restored after comment control"

print("")
print("mutant | verdict | must-fail evidence | must-pass evidence | named test")
for row in rows:
    print(" | ".join(row))
print("")
print("killed=%d neutral-ok=%d holes=%d unexpected=%d unmeasured=%d total=%d" % (
    sum(1 for row in rows if row[1] == "KILLED"),
    sum(1 for row in rows if row[1] == "SURVIVED-NEUTRAL-OK"),
    sum(1 for row in rows if row[1] == "SURVIVED-HOLE"),
    sum(1 for row in rows if row[1] == "KILLED-UNEXPECTED"),
    sum(1 for row in rows if row[1] == "UNMEASURED"),
    len(rows)))
