import json
from pathlib import Path
rows=json.loads(Path('.temp/TASK-260830-2bnr39/review/mutants.json').read_text())
vectors=[]
for row in rows:
 name,old,new,fails,passes=row[:5]
 v=dict(name=name,file='snapshot.go',old=old,new=new,tests=fails,positive=passes,limit=row[5] if len(row)>5 else 0,expect=row[6] if len(row)>6 else 'kill',full=row[7] if len(row)>7 else False)
 v['bound']=''
 if v['expect']=='survive':v['bound']='Both scalar parsers enforce prefix/length; the supplied objectFormat is also the constructed prefix. This substitution is behavior-neutral at this call site; it does not cover cross-format acceptance elsewhere.'
 vectors.append(v)
# Keep reviewer-supplied true neutral and known-bad controls; execute them first.
vectors.insert(0,dict(name='C-neutral-comment',file='snapshot.go',old='',new='\n// gitsnap neutral instrument control\n',tests=[],positive=[],expect='survive',full=True,bound='Comment-only change cannot affect runtime behavior; full suite must execute.'))
def add(name,old,new,tests,**extra):
 vectors.append(dict(name=name,file=extra.pop('file','snapshot.go'),old=old,new=new,tests=tests,positive=[],expect='kill',**extra))
add('N20-not-repository-admits-fatal-128','result.ExitCode == 1 && len(result.Stdout) == 0','(result.ExitCode == 1 || result.ExitCode == 128) && len(result.Stdout) == 0',['TestReviewFeatureReadFailure'])
add('N21-head-ref-admits-HEAD','''\t\tif err != nil {
\t\t\treturn Head{}, refuse(GateHeadRef, "HEAD ref invalid: "+err.Error())
\t\t}''','''\t\tif err != nil && ref != "HEAD" {
\t\t\treturn Head{}, refuse(GateHeadRef, "HEAD ref invalid: "+err.Error())
\t\t}
        if err != nil { parsedRef, _ = scalar.ParseGitRef("refs/heads/feature/ax") }''',['TestCaptureRefGrammarAtEachRead'])
add('N22-upstream-admits-HEAD','''\tif perr != nil {
\t\treturn nil, refuse(GateUpstreamRef, "upstream ref invalid: "+perr.Error())
\t}''','''\tif perr != nil && ref != "HEAD" {
\t\treturn nil, refuse(GateUpstreamRef, "upstream ref invalid: "+perr.Error())
\t}
    if perr != nil { parsed, _ = scalar.ParseGitRef("refs/remotes/origin/feature/ax") }''',['TestCaptureRefGrammarAtEachRead'])
add('N23-remote-name-admits-129','utf8.RuneCountInString(name) > maxRemoteNameRune','utf8.RuneCountInString(name) > maxRemoteNameRune+1',['TestCaptureRemoteNameBounds'])
add('N24-filters-admits-65','len(features.RequiredFilters) > maxRequiredFilters','len(features.RequiredFilters) > maxRequiredFilters+1',['TestCaptureRequiredFilterCountBounds'])
add('N25-consistency-admits-same-length-index-change','if !bytes.Equal(again, indexBytes) {','if !bytes.Equal(again, indexBytes) && len(again) != len(indexBytes) {',['TestConsistencyRefusesIndexMutationArmedOnce'])
add('N26-consistency-admits-same-oid-branch-switch','if !reflect.DeepEqual(nowHead, head) {','if !reflect.DeepEqual(nowHead, head) && nowHead.oidValue() != head.oidValue() {',['TestReviewHeadRefRace','TestCaptureSameOIDHeadModeRace'])
add('N27-consistency-admits-index-version-only-change','if !indexState.equal(nowState) || version != nowVersion {','if (!indexState.equal(nowState) || version != nowVersion) && version == nowVersion {',['TestReviewIndexVersionRace'])
add('N28-lock-env-inherited-one-wins','append(os.Environ(), "GIT_OPTIONAL_LOCKS=0")','append([]string{"GIT_OPTIONAL_LOCKS=0"}, os.Environ()...)',['TestReviewRunnerLockOverride'],file='runner.go')
add('N29-diff-bypasses-private-index','len(args) > 0 && args[0] == "diff"','len(args) > 0 && args[0] == "diff" && len(args) > 1 && args[1] == "--cached"',['TestReviewLockOverrideMutatesIndex'],file='runner.go')
add('N30-feature-default-symlinks-false','{"core.symlinks", &features.Symlinks, true}','{"core.symlinks", &features.Symlinks, false}',['TestReviewSymlinkDefault'])
add('N31-filter-boolean-raw-yes','runner, dir, "config", "--bool", "--get", key)','runner, dir, "config", "--get", key)',['TestReviewRequiredFilterBoolean'],limit=0)
# This source occurs in two callers; change only the required-filter read.
vectors[-1]['old']='result, err := runOK(ctx, runner, dir, "config", "--bool", "--get", key)'
vectors[-1]['new']='result, err := runOK(ctx, runner, dir, "config", "--get", key)'
add('N32-subdir-keeps-caller-command-scope','dir = repo.worktree.RepoRoot','// dir = repo.worktree.RepoRoot (token preserved; caller directory retained)',['TestCaptureRootAndSubdirectoryAgree'],full=True)
Path('internal/gitsnap/testdata/mutations.json').write_text(json.dumps(vectors,indent=2)+'\n')
