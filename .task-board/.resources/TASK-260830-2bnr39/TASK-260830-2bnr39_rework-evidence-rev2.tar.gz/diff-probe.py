import tempfile,subprocess,os,pathlib
with tempfile.TemporaryDirectory() as tmp:
 p=pathlib.Path(tmp)
 env=dict(os.environ,GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_SYSTEM='/dev/null',GIT_OPTIONAL_LOCKS='0')
 def git(*a):
  r=subprocess.run(['git','-c','user.name=test','-c','user.email=test@example.com','-c','commit.gpgsign=false','-c','diff.autoRefreshIndex=false',*a],cwd=p,env=env,capture_output=True)
  return r
 git('init','-q');(p/'file').write_text('same\n');git('add','file');git('commit','-qm','init')
 (p/'file').unlink();(p/'file').write_text('same\n')
 for flag in [[],['--exit-code'],['--numstat'],['--shortstat'],['--patch'],['--check']]:
  before=(p/'.git/index').read_bytes()
  r=git('diff','--raw','--no-abbrev','-z',*flag)
  print(flag,r.returncode,repr(r.stdout), 'index_same',before==(p/'.git/index').read_bytes())
