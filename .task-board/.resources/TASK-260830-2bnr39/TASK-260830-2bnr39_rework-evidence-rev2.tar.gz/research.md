# Git capture rework sources and observations

Pinned normative source is internal/specdoc/SPEC.md, v0.5.0 commit 28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c. Read §§10.4 and 12.1–12.3 and the Git embedded-type table. GitRemote.name counts characters 1..128; required_filter_names is a sorted unique array of 0..64 strings.

Official Git references consulted:
- https://git-scm.com/docs/git-symbolic-ref — quiet non-symbolic exit 1 differs from fatal exit 128.
- https://git-scm.com/docs/git-for-each-ref — upstream field provides configured tracking ref; successful empty field establishes no tracking. for-each-ref matching a captured branch avoids conflating rev-parse upstream failures with absence.
- https://git-scm.com/docs/git-config — unset core.symlinks and core.filemode default true; ignorecase defaults false (init/clone probe and may set overrides); --bool delegates Boolean parsing to Git. NUL name-only census preserves dotted filter subsection names and per-key --bool reads respect precedence.
- https://raw.githubusercontent.com/git/git/v2.50.1/builtin/diff.c — diff calls refresh_index_quietly when skip_stat_unmatch > 1, without optional-lock check at that call; setting diff.autoRefreshIndex=false also disables stat-only filtering.
- https://raw.githubusercontent.com/git/git/v2.50.1/diff.c — diffcore_skip_stat_unmatch filters stat-only changes; diff_auto_refresh_index controls the behavior.

Observed directly: runner env override alone passes executable environment probe but fails real index-byte preservation. Disabling autoRefreshIndex preserves bytes but reports a false M delta for identical content with invalidated cached stat. See lock-command-probe.log and diff-probe.log. Use disposable per-diff index copies with runner-owned autoRefreshIndex=true; actual-index fingerprints remain independent. No object/blob delivery or durable repository writes added.

Initial imported review probes ran before deterministic fixture isolation: exit 1, reproduced all reported defects; ambient lfs appeared in one result. Only subsequent isolated-config runs establish filter defaults/counts.
