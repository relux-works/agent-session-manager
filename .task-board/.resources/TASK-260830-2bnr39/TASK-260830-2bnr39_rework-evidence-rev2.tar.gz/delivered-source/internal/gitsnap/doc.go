// Package gitsnap captures the live Git repository and index state that
// Sections 10.4 (kind = git WorkspaceSnapshotMember) and 12.1-12.3 of the
// pinned specification require: repository identity, sanitized remotes,
// HEAD/ref mode, worktree metadata, index stages and flags, staged and
// unstaged deltas, and file modes.
//
// The production entry point is Capture. It drives the Git executable
// through the Runner seam (ExecGitRunner in production, a scripted fake in
// tests). It validates repository identity and remote names in characters,
// URLs/refs/index OIDs/index paths through internal/scalar, repository-relative
// cwd, and the closed index/feature domains. This internal result includes
// supplementary native worktree paths and raw delta OIDs; it is not a complete
// canonical wire member. See testdata/string-domain-audit.md for every string
// field and the validation boundary.
//
// Scope boundary: this leaf owns repository identity, HEAD/ref, worktree
// metadata, index stages/flags, staged and unstaged deltas, and tracked
// file modes. It does not own object packs, raw index/pack blobs,
// untracked or ignored bytes, symlink targets, submodule recursion, or
// working-tree manifests; those belong to sibling leaves of the same
// story. Capture records the logical index entries and version but not
// the raw index blob, and records tracked-path stat kinds but not
// symlink targets or untracked paths. Anything outside that boundary is
// refused or omitted only as this document states, never silently
// substituted.
//
// ExecGitRunner overrides inherited optional-lock settings and gives each
// porcelain diff a private index copy, removed when the command returns.
// This preserves real index bytes even when Git refreshes cached stat data.
// A killed process can leave disposable OS-temp files, never a partially
// published snapshot. Git configuration and the Runner are trusted inputs;
// this is not a sandbox for arbitrary external filter programs.
//
// Capture compares HEAD mode/ref/OID, actual index path/file identity/digest
// and version, logical entries and both raw delta streams. These sentinels
// detect observed changes inside their read windows; they do not provide an
// atomic transaction, detect change-and-revert between reads, or hash all
// working-tree content. Quiescence and full content capture belong to the
// sibling/integration owners. A refusal returns no partial snapshot; retry
// after quiescence is supported.
//
// Refusal codes reuse the specification vocabulary (workspace_conflict,
// incompatible_schema, integrity_failure, unsafe_path,
// capability_unavailable) as diagnostic strings. Mapping them into
// axerror envelopes belongs to the CLI owner, which does not exist yet;
// this package mints no axerror object.
//
// Census blind spot: the gate census in census_test.go counts literal
// refuse(Gate...) call sites in non-test production files after stripping
// comments and string literals. A refusal reached through an aliased
// function variable would be missed by that instrument. The package
// upholds the countermeasure by construction: refuse is always invoked
// directly, never aliased, and a control in the census test proves an
// aliased call is invisible to the instrument so the bound stays stated.
package gitsnap
