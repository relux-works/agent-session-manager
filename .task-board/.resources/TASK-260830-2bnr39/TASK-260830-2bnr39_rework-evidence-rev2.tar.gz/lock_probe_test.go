package gitsnap
import("testing";"context";"os";"path/filepath";"crypto/sha256")
type lockProbe struct{t *testing.T; dir string}
func(r lockProbe)Run(c context.Context,d string,a ...string)(GitResult,error){before,_:=os.ReadFile(filepath.Join(r.dir,".git","index"));v,e:=(ExecGitRunner{}).Run(c,d,a...);after,_:=os.ReadFile(filepath.Join(r.dir,".git","index"));if sha256.Sum256(before)!=sha256.Sum256(after){r.t.Errorf("index changed by %v",a)};return v,e}
func TestLockProbe(t *testing.T){t.Setenv("GIT_OPTIONAL_LOCKS","1");d:=initLiveRepo(t);p:=filepath.Join(d,"README.md");_ = os.Remove(p);_ = os.WriteFile(p,[]byte("base\n"),0644);_,e:=Capture(context.Background(),lockProbe{t,d},d);t.Log(e)}
