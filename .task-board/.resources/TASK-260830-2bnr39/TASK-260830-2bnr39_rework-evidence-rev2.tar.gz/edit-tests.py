from pathlib import Path
for p in Path('internal/gitsnap').glob('*test.go'):
 s=p.read_text()
 # Normalize imported reviewer formatting first elsewhere; replace both variants.
 s=s.replace('"rev-parse", "--symbolic-full-name", "--verify", "--quiet", "@{upstream}"','"for-each-ref", "--format=%(upstream)", "--", "refs/heads/feature/ax"')
 s=s.replace('"rev-parse","--symbolic-full-name","--verify","--quiet","@{upstream}"','"for-each-ref","--format=%(upstream)","--","refs/heads/feature/ax"')
 s=s.replace('"config", "--get-regexp",', '"config", "-z", "--name-only", "--get-regexp",').replace('"config","--get-regexp",','"config","-z","--name-only","--get-regexp",')
 if p.name=='fake_test.go':
  s=s.replace('okResult("refs/heads/feature/ax\\n"))','okResult("refs/heads/feature/ax\\n"), okResult("refs/heads/feature/ax\\n"))')
  s=s.replace('okResult("2\\n"))','okResult("2\\n"), okResult("2\\n"))')
  s=s.replace('index := debugAGENTS + debugREADME','index := debugAGENTS + debugREADME\n fake.Script([]string{"rev-parse", "--path-format=absolute", "--git-path", "index"}, okResult("/tmp/repo/.git/index\\n"), okResult("/tmp/repo/.git/index\\n"))')
 if p.name=='compat_test.go':
  s=s.replace('okResult(version+"\\n"))','okResult(version+"\\n"), okResult(version+"\\n"))').replace('okResult("0\\n"))','okResult("0\\n"), okResult("0\\n"))')
  s=s.replace('exitResult(1, ""))','exitResult(1, ""), exitResult(1, ""))').replace('okResult("3\\n"))','okResult("3\\n"), okResult("3\\n"))')
 if p.name=='refusal_test.go':
  s=s.replace('"refs/heads/feature/ax"}, exitResult(128, ""))','"refs/heads/feature/ax"}, okResult("\\n"))')
 if p.name=='capture_test.go':
  s=s.replace('append([]string{"GIT_CONFIG_GLOBAL=/dev/null", "GIT_CONFIG_SYSTEM=/dev/null"}, os.Environ()...)','isolatedGitEnv()')
  s=s.replace('"-c", "init.defaultBranch=main"','"-c", "init.defaultBranch=main", "-c", "init.templateDir="')
 p.write_text(s)
