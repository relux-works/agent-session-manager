from pathlib import Path
import json,hashlib,re,subprocess,tarfile
root=Path.cwd(); logs=root/'.temp/TASK-260830-2bnr39'
out=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/TASK-260830-2bnr39/rework-rev2')
out.mkdir(parents=True,exist_ok=True)
results=json.loads((logs/'mutations-final-04/results.json').read_text())
vectors=json.loads((root/'internal/gitsnap/testdata/mutations.json').read_text())
assert len(results)==len(vectors)==35
assert all(r['status'] in ('BEHAVIOR_KILL','NEUTRAL_PASS') for r in results)
for gate in ['all-tests-final-03','coverage-final-02','race-final-02','package-final-01','build-final-01','vet-final-01','traceability-final-01','catalog-01','diff-check-final-02']:
 assert json.loads((logs/(gate+'.json')).read_text())['exit']==0,gate
byname={r['name']:r for r in results}
labels={
'M1':'Allows stage 4 (stage limit remains)', 'M2':'Allows index version 5 (closed list otherwise retained)',
'M3':'Allows the 17th remote', 'M4':'Allows index entry 65537', 'M5':'Allows identity character 257',
'M6':'Narrows unborn namespace refusal to refs outside refs/ (includes tags)', 'M7':'Allows unknown raw-diff status X',
'M8b':'Allows a 40-hex HEAD in a sha256 repository', 'M9':'Allows duplicate path/stage pairs',
'M10':'Swaps fetch/push behavior while keeping searched tokens; full behavioral suite',
'M11':'Swaps assume-unchanged flag behavior while retaining flag token; full behavioral suite',
'M12':'Deletes empty-remotes minimum; supporting deletion evidence only',
'M13':'Deletes branch-ref refusal; supporting deletion evidence only',
'M14':'Deletes logical-index consistency clause; supporting deletion evidence only',
'M15':'Deletes corrupt-HEAD clause; supporting deletion evidence only',
'M16':'Deletes upstream-ref refusal; supporting deletion evidence only',
'M17':'Deletes credential-bearing push URL refusal; supporting deletion evidence only',
'M18':'Allows an 8-hex index OID', 'M19':'Allows FIFO worktree kind',
'N20':'Allows quiet fatal exit 128 as legitimate absent result',
'N21':'Allows literal HEAD at branch-ref read boundary',
'N22':'Allows literal HEAD at upstream-ref read boundary',
'N23':'Allows remote name character 129', 'N24':'Allows required filter 65',
'N25':'Allows same-length logical index mutations',
'N26':'Allows same-OID HEAD ref/mode changes',
'N27':'Allows actual index changes when version differs',
'N28':'Inherited optional-lock setting can override runner setting',
'N29':'Unstaged diff bypasses private index (cached diff remains isolated)',
'N30':'Unset symlinks incorrectly defaults false; behavior regression',
'N31':'Required-filter read bypasses Git boolean parsing; behavior regression',
'N32':'Retains caller command directory and root token; full behavioral suite',
'C-neutral-comment':'Comment-only neutral instrument control',
'C-neutral-oid-swap-survives':'Equivalent OID scalar-parser substitution; full behavioral suite',
'C-bad-inverted-sort':'Known-bad instrument control: rejects a valid sorted index',
}
rows=['| Mutant | Narrowed rejection / behavioral change | Named failing test(s) | Outcome / survivor bound |','| --- | --- | --- | --- |']
for vector in vectors:
 r=byname[vector['name']];key=vector['name'].split('-')[0]
 label=labels.get(vector['name'],labels.get(key,vector['name']))
 failing=', '.join(r['failing']) if r['failing'] else 'None — survivor'
 if r['status']=='NEUTRAL_PASS':
  result='Neutral survivor, actual behavior exit 0; '+r['bound']
 else:result='Behavior kill; compile 0, behavior '+str(r['behavior_exit'])
 if r.get('positive_exit') is not None:result+='; positive control '+str(r['positive_exit'])
 rows.append('| '+ ' | '.join(x.replace('|','\\|') for x in [vector['name'],label,failing,result])+' |')
gates={
'GateNotRepository':'N20','GateHeadCorrupt':'M6','GateHeadRef':'N21','GateHeadOIDFormat':'M8b','GateRemotesRange':'M3','GateRemoteURL':'N23','GateIdentityLength':'M5','GateIndexVersion':'M2','GateIndexStage':'M1','GateIndexEntry':'M18','GateIndexSort':'M9','GateIndexEntriesRange':'M4','GateUpstreamRef':'N22','GateDeltaStatus':'M7','GateWorktreeKind':'M19','GateConsistency':'N25','GateFeatures':'N24'}
assert len(gates)==17
for code in gates.values():assert next(r for r in results if r['name'].startswith(code+'-'))['status']=='BEHAVIOR_KILL'
source_paths=sorted([*root.glob('internal/gitsnap/**/*.go'),*root.glob('internal/gitsnap/testdata/*'),root/'.scripts/gitsnap-mutations.py',root/'README.md',root/'LOGBOOK.md'])
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source_paths if p.is_file()}
(logs/'candidate-source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
acceptance=(root/'internal/gitsnap/testdata/acceptance.md').read_text()
audit=(root/'internal/gitsnap/testdata/string-domain-audit.md').read_text()
report='''# TASK-260830-2bnr39 — CR rev2 developer outcome

Disposition: ready for review; managed developer handoff publishes the candidate. Work remains uncommitted. The orchestrator owns review, signed checkpoint and integration.

## Preserved candidate and scope

Worktree: `.temp/STORY-260830-35dbcs/worktree`; HEAD/checkpoint `7aa151a9c31071bfab190fd8ae8259f502f2ebbc`; preserved prior tree `2a7575a9b8b5983308fe8769c88a4006858580cf`. No commit, switch, rebase, reset or merge was performed. At inspection `HEAD..main` was 2 commits; these measurements concern this managed candidate, not current main. The manager's new CR records its authoritative candidate tree. `candidate-source-sha256.json` pins the exact delivered source/docs independently.

Normative source: embedded v0.5.0, commit `28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c`, §§10.2–10.4 and 12.1–12.3. This remains an internal library leaf; no raw-index/object blob delivery, untracked/ignored content, symlink targets, recursive submodules, closure manifests, CLI orchestration or upstream #176/#177 work was added.

## Seven findings addressed

1. Runner-owned environment values override inherited duplicates. Real Git showed an additional porcelain refresh path independent of optional locks, so diff uses temporary index copies with preserved mtime and explicit content-comparison behavior. Real-byte preservation covers stat invalidation, alternate index, success and refusal; cleanup is tested. External Git/filter configuration remains trusted, not sandboxed.
2. Consistency compares HEAD mode/ref/OID and actual index path/file identity/digest/version, plus original logical/delta sentinels. Real same-OID branch/mode changes, v2→v4 rewrites and identical-byte index replacements refuse; stable retry succeeds. This is bounded observation, not atomic capture or a full content digest.
3. Reads/stat paths use repository root; requested relative cwd survives. Root/sub captures agree apart from cwd; linked worktrees are driven.
4. Symbolic HEAD, OID, upstream, every feature config reader and required-filter census have individual fatal/transport/partial-read attacks through Capture. Upstream absence comes from a successful field read. Closing HEAD failures, post-census filter failures, absent-index config failures and successful empty HEAD output refuse.
5. Symlink/filemode defaults match Git config behavior; --bool parses required-filter spellings, dotted names and last-value precedence. TestMain and fixture subprocesses isolate ambient Git config/identity/routing without printing environment values.
6. Remote names enforce 1..128 characters with ASCII/multibyte 128/129 tests and N23. The full string-domain audit additionally found and closed required-filter count 64/65 with N24 and GateFeatures.
7. Narrowed NotRepository/HeadRef/UpstreamRef vectors now fail named production-entry tests. Neutral controls execute full suites. Registration census and behavioral evidence have separate denominators; all supplied controls and deletion/supporting vectors remain available.

## Executed validation

All commands ran as standalone subprocesses with stdout/stderr retained, never piped through tee. No earlier producer/reviewer passing result substitutes for the reruns below. The host is macOS arm64, Go 1.25.5, Apple Git 2.50.1 (exact version logs included).

| Command | Actual exit | Evidence |
| --- | ---: | --- |
| go test ./internal/gitsnap -v -cover -count=1 | 0 | package-final-01.log; 97 top-level tests, 86.5% statements |
| go test ./... -v -count=1 | 0 | all-tests-final-03.log; all 24 packages |
| go test ./... -cover -count=1 | 0 | coverage-final-02.log |
| go test ./... -race -count=1 | 0 | race-final-02.log |
| go build ./... | 0 | build-final-01.log |
| go vet ./... | 0 | vet-final-01.log |
| go run ./internal/traceability/cmd/tracecheck | 0 | traceability-final-01.log; existing ownership unchanged, 17/428 clauses discharged |
| cataloggen with pinned metadata/contracts and -check | 0 | catalog-01.log; exact argv in log |
| repository gofmt empty-output gate | 0 | gofmt-final-01.log + observed-exit-codes.json |
| git diff --check | 0 | diff-check-final-02.log |
| binary/rename regression, -count=10 | 0 | binary-repeat-01.log |
| python3 .scripts/gitsnap-mutations.py --out .temp/TASK-260830-2bnr39/mutations-final-04 | 0 | mutations-final-04.log and per-vector logs/results |

The manager additionally runs its configured validation at handoff and attaches that log to the new CR. It is not preclaimed here. Native Linux/Windows runtime and explicit fuzz mutation-budget coverage were not rerun independently in this developer packet; configured cross-build/fuzz handoff gates retain their own real statuses. No unsupported capability is advertised.

## Mutation measurement and prior failures

Final battery: **35 of 35 vectors applied and compiled; 33 behavioral kills (including known-bad control), 2 measured neutral survivors; 0 unexplained survivors, compile failures, census-only kills or unexecuted selections.** Every kill has named failing tests below. The two survivors have explicit bounds. **17 of 17 registry gates have a narrowing witness** (table below). This does not establish all interior clauses: the final source census has **77 literal sites over 17 registered gates**. Deletion-only rows are supporting evidence and are not used for the gate-narrowing ratio.

Earlier runs are preserved honestly: imported pre-fix review probes exit 1; optional-lock-only fix still failed index bytes (exit 1); disabling autoRefreshIndex failed stat-only delta correctness (exit 1). First mutation battery exit 1 includes a real neutral failure from private-index timestamp drift, subsequently fixed. Its N26 mode fixture also let another sentinel catch the checkout's index change; the corrected mode-only update-ref fixture has a targeted green rerun and is included in the final full battery. The intermediate second battery's actual status is retained separately. No early run is relabeled as passing.

## Narrowing coverage by registry gate

| Registry gate | Narrowing vector |
| --- | --- |
'''
for gate,vector in gates.items():report+=f'| {gate} | {vector} |\n'
report+='\n## Per-mutant evidence\n\n'+'\n'.join(rows)+'\n\n'+acceptance+'\n\n'+audit
report+='''
## Operational notes and bounds

No delegates were spawned. Required project-management and Curator-managed Go testing skills were read. This managed worktree lacks installed .claude/.agents adapters; the Go skill was read from the main checkout's Curator-managed adapter as assigned. The failed local skill-path read and corrected path are recorded in tooling notes; no tool install or global shared-contract edit was performed.

Full logs and the final harness/vector source are included. Real Git tests do not contact remotes. Scripted fsmonitor-valid/SHA256 evidence does not claim live platform coverage. Split-index compatibility here is logical entries and real-index byte preservation; auxiliary shared-index timestamps and every Git extension are not exhaustively attested. Supplementary raw-diff OIDs/native paths have the explicit bounds in the schema audit. Quiescence, change-and-revert races and all included-file digests remain integration/sibling responsibilities.
'''
report_path=out/'TASK-260830-2bnr39_rework-rev2.md';report_path.write_text(report)
# Archive full logs, scripts, input probes and exact final leaf artifacts without
# duplicating disposable candidate directories or the already-attached rev1 archive.
archive=out/'TASK-260830-2bnr39_rework-evidence-rev2.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(logs.rglob('*')):
  if not p.is_file():continue
  relative=p.relative_to(logs)
  if len(relative.parts)>1 and relative.parts[0] not in {'mutations-01','mutations-02','mutations-mode-03','mutations-final-04'}:continue
  if 'candidate' in relative.parts:continue
  tar.add(p,arcname=str(relative))
 for p in source_paths:
  if p.is_file():tar.add(p,arcname='delivered-source/'+str(p.relative_to(root)))
 tar.add(report_path,arcname=report_path.name)
print(report_path)
print(archive)
print('archive_sha256',hashlib.sha256(archive.read_bytes()).hexdigest())
