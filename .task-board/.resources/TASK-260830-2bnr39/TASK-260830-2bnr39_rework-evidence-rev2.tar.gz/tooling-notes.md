# Tooling notes

The assigned worktree has no installed `.claude/skills/go-testing-tools/SKILL.md`; the initial cat failed with exit 1. The required full skill was successfully read from `/Users/iv/Developer/ReluxWorks/agent-session-manager/.claude/skills/go-testing-tools/SKILL.md`, the Curator-managed main-checkout adapter. No install or runtime edit was performed.

Initial task-board read used unknown operation `task`, then an unsupported `resources` projection. Recovered with scoped `schema(operation=get)` and the compact `get(TASK-260830-2bnr39) { overview checklist notes }`. Resources were read from the explicitly attached task paths; board data was never edited directly.

Git, rg, Go, Python and task-board readiness/version logs are included. The Go module targets a cross-platform CLI/library, with macOS arm64 as this run's native platform. No unrelated iOS/Android build was attempted.

Exit codes captured from shell-session completion before the structured gate wrapper existed are in observed-exit-codes.json; per-gate JSON thereafter contains argv and actual subprocess exit. Expected-red probes and unsuccessful intermediate rework attempts remain failing, never relabeled as passes.
