from pathlib import Path
p=Path('internal/gitsnap/runner.go');s=p.read_text().replace('can never take an index or reference lock and can never block a\n// concurrent writer.', 'does not perform optional index refresh writes. Mandatory writes issued\n// by other callers of Run are not prevented by this setting.')
s=s.replace('append([]string{"GIT_OPTIONAL_LOCKS=0"}, os.Environ()...)','append(os.Environ(), "GIT_OPTIONAL_LOCKS=0")')
s=s.replace('result := GitResult{Stdout: stdout.Bytes(), Stderr: stderr.Bytes(), ExitCode: command.ProcessState.ExitCode()}', 'result := GitResult{Stdout: stdout.Bytes(), Stderr: stderr.Bytes(), ExitCode: -1}\n\tif command.ProcessState != nil {\n\t\tresult.ExitCode = command.ProcessState.ExitCode()\n\t}')
p.write_text(s)
p=Path('internal/gitsnap/snapshot.go');s=p.read_text().replace('"fmt"','"fmt"\n "io"\n "reflect"')
s=s.replace('maxRemotes      = 16','maxRemotes      = 16\n maxRemoteNameRune = 128')
s=s.replace('head, err := readHead(ctx, runner, dir, repo.objectFormat)','dir = repo.worktree.RepoRoot\n head, err := readHead(ctx, runner, dir, repo.objectFormat)',1)
s=s.replace('readUpstream(ctx, runner, dir)','readUpstream(ctx, runner, dir, head)',1)
s=s.replace('version, err := readIndexVersion(ctx, runner, dir)', 'indexState, err := readIndexState(ctx, runner, dir)\n if err != nil { return nil, err }\n version, err := readIndexVersion(ctx, runner, dir)',1)
s=s.replace('head.oidValue(), indexBytes, stagedBytes, unstagedBytes','head, repo.objectFormat, version, indexState, indexBytes, stagedBytes, unstagedBytes',1)
s=s.replace('cwd, err := os.Getwd()', 'cwd, err := filepath.Abs(dir)')
s=s.replace('worktree.CWD = cwd', '''// Git reports canonical roots; resolve an existing caller path as well.
 if resolved, resolveErr := filepath.EvalSymlinks(cwd); resolveErr == nil { cwd = resolved }
 relative, err := filepath.Rel(worktree.RepoRoot, cwd)
 if err != nil { return nil, refuse(GateNotRepository, "cannot resolve repository-relative cwd") }
 worktree.CWD = filepath.ToSlash(relative)
 if worktree.CWD != "." {
  if _, err := scalar.ParseRelativePath(worktree.CWD); err != nil { return nil, refuse(GateNotRepository, "invalid repository-relative cwd") }
 }
 if !filepath.IsAbs(worktree.CommonDir) { worktree.CommonDir = filepath.Clean(filepath.Join(cwd, worktree.CommonDir)) }''')
# Read OID before symbolic mode so the supplied closing-rev interception precedes both comparisons.
a=s.index('\tsymref, symrefErr :=',s.index('func readHead'))
b=s.index('\tref := ""',a)
s=s[:a]+''' revision, revErr := runner.Run(ctx, dir, "rev-parse", "--verify", "--quiet", "HEAD")
 if revErr != nil { return Head{}, refuse(GateNotRepository, "rev-parse HEAD failed: "+revErr.Error()) }
 if revision.ExitCode != 0 && !absentResult(revision) { return Head{}, refuse(GateNotRepository, "HEAD read failed") }
 symref, symrefErr := runner.Run(ctx, dir, "symbolic-ref", "-q", "HEAD")
 if symrefErr != nil { return Head{}, refuse(GateNotRepository, "symbolic-ref failed: "+symrefErr.Error()) }
 if symref.ExitCode != 0 && !absentResult(symref) { return Head{}, refuse(GateNotRepository, "symbolic-ref read failed") }
 if symref.ExitCode == 0 && firstLine(symref.Stdout) == "" { return Head{}, refuse(GateHeadRef, "empty symbolic HEAD") }
'''+s[b:]
a=s.index('func readUpstream(');b=s.index('\nfunc readRemotes',a)
s=s[:a]+'''// readUpstream uses a successful field read to establish absence. rev-parse
// @{upstream} uses the same failure status for absent tracking and fatal reads.
func readUpstream(ctx context.Context, runner Runner, dir string, head Head) (*string, error) {
 if head.Mode != "branch" { return nil, nil }
 result, err := runOK(ctx, runner, dir, "for-each-ref", "--format=%(upstream)", "--", *head.Ref)
 if err != nil { return nil, err }
 if len(result) == 0 { return nil, refuse(GateConsistency, "HEAD ref disappeared during upstream read") }
 ref := strings.TrimSuffix(string(result), "\\n")
 if ref == "" { return nil, nil }
 parsed, perr := scalar.ParseGitRef(ref)
 if perr != nil { return nil, refuse(GateUpstreamRef, "upstream ref invalid: "+perr.Error()) }
 value := parsed.String()
 return &value, nil
}
'''+s[b:]
s=s.replace('name := fields[0]\n\t\trest', '''name := fields[0]
  if !utf8.ValidString(name) || utf8.RuneCountInString(name) < 1 || utf8.RuneCountInString(name) > maxRemoteNameRune {
   return nil, refuse(GateRemoteURL, "remote name must contain 1..128 characters")
  }
  rest''',1)
s=s.replace('configured, err := runner.Run(ctx, dir, "config", "--get", "index.version")','configured, err := readOptionalConfig(ctx, runner, dir, "config", "--get", "index.version")')
s=s.replace('// Materializing that empty index', '// Materializing that empty index')
a=s.index('func readFeatures(');b=s.index('// recheckConsistency',a)
s=s[:a]+'''// absentResult accepts only the documented quiet not-present result. Partial
// output and diagnostics cannot attest absence.
func absentResult(result GitResult) bool {
 return result.ExitCode == 1 && len(result.Stdout) == 0 && len(result.Stderr) == 0
}

func readOptionalConfig(ctx context.Context, runner Runner, dir string, args ...string) (GitResult, error) {
 result, err := runner.Run(ctx, dir, args...)
 if err != nil { return GitResult{}, refuse(GateNotRepository, "config read failed: "+err.Error()) }
 if result.ExitCode != 0 && !absentResult(result) { return GitResult{}, refuse(GateNotRepository, "config read failed") }
 return result, nil
}

func readFeatureBool(ctx context.Context, runner Runner, dir, key string, fallback bool) (bool, error) {
 result, err := readOptionalConfig(ctx, runner, dir, "config", "--bool", "--get", key)
 if err != nil { return false, err }
 if absentResult(result) { return fallback, nil }
 switch string(result.Stdout) {
 case "true\\n": return true, nil
 case "false\\n": return false, nil
 default: return false, refuse(GateNotRepository, "noncanonical boolean config read")
 }
}

func readFeatures(ctx context.Context, runner Runner, dir, objectFormat string) (Features, error) {
 features := Features{ObjectFormat: objectFormat}
 // Defaults describe Git configuration behavior, not a filesystem capability probe.
 for _, field := range []struct{ key string; target *bool; fallback bool }{
  {"core.filemode", &features.FileMode, true},
  {"core.symlinks", &features.Symlinks, true},
  {"core.ignorecase", &features.CaseSensitive, false},
  {"core.precomposeunicode", &features.PrecomposeUnicode, false},
  {"core.sparseCheckout", &features.SparseCheckout, false},
 } {
  value, err := readFeatureBool(ctx, runner, dir, field.key, field.fallback)
  if err != nil { return Features{}, err }
  *field.target = value
 }
 features.CaseSensitive = !features.CaseSensitive
 required, err := readOptionalConfig(ctx, runner, dir, "config", "-z", "--name-only", "--get-regexp", `^filter\\..*\\.required$`)
 if err != nil { return Features{}, err }
 if required.ExitCode == 0 {
  if len(required.Stdout) == 0 || required.Stdout[len(required.Stdout)-1] != 0 { return Features{}, refuse(GateNotRepository, "malformed filter config list") }
  names := map[string]bool{}
  for _, key := range strings.Split(string(required.Stdout[:len(required.Stdout)-1]), "\\x00") {
   if !strings.HasPrefix(key, "filter.") || !strings.HasSuffix(key, ".required") { return Features{}, refuse(GateNotRepository, "malformed filter key") }
   name := strings.TrimSuffix(strings.TrimPrefix(key, "filter."), ".required")
   if name == "" || !utf8.ValidString(name) { return Features{}, refuse(GateNotRepository, "invalid filter name") }
   // Let Git parse every spelling and apply last-value precedence. A census
   // match disappearing before this read is a failed observation, not false.
   result, err := runOK(ctx, runner, dir, "config", "--bool", "--get", key)
   if err != nil { return Features{}, err }
   switch string(result) {
   case "true\\n": names[name] = true
   case "false\\n": names[name] = false
   default: return Features{}, refuse(GateNotRepository, "noncanonical required-filter boolean")
   }
  }
  for name, required := range names { if required { features.RequiredFilters = append(features.RequiredFilters, name) } }
  sort.Strings(features.RequiredFilters)
 }
 for _, name := range features.RequiredFilters { if name == "lfs" { features.LFSRequired = true } }
 return features, nil
}

// indexState is an in-memory sentinel, not a raw-index deliverable. Hash the
// actual index, including extensions and format bytes, without writing a blob.
type indexState struct {
 path string
 info os.FileInfo
 digest [sha256.Size]byte
}

func readIndexState(ctx context.Context, runner Runner, dir string) (indexState, error) {
 output, err := runOK(ctx, runner, dir, "rev-parse", "--path-format=absolute", "--git-path", "index")
 if err != nil { return indexState{}, err }
 path := strings.TrimSuffix(string(output), "\\n")
 if !filepath.IsAbs(path) { return indexState{}, refuse(GateNotRepository, "index path is not absolute") }
 state := indexState{path:path}
 file, openErr := os.Open(path)
 if os.IsNotExist(openErr) { return state, nil }
 if openErr != nil { return state, refuse(GateNotRepository, "index sentinel open failed") }
 defer file.Close()
 info, statErr := file.Stat()
 if statErr != nil || !info.Mode().IsRegular() { return state, refuse(GateNotRepository, "index sentinel stat failed") }
 hash := sha256.New()
 if _, err := io.Copy(hash, file); err != nil { return state, refuse(GateNotRepository, "index sentinel read failed") }
 state.info = info
 copy(state.digest[:], hash.Sum(nil))
 return state, nil
}

func (state indexState) equal(other indexState) bool {
 if state.path != other.path || state.digest != other.digest { return false }
 if state.info == nil || other.info == nil { return state.info == nil && other.info == nil }
 return os.SameFile(state.info, other.info) && state.info.Size() == other.info.Size() && state.info.ModTime().Equal(other.info.ModTime())
}

'''+s[b:]
a=s.index('// recheckConsistency');b=s.index('\tagain, refusal :=',a)
s=s[:a]+'''// recheckConsistency compares full HEAD state, the actual index sentinel and
// logical entries, and both raw delta streams. This bounded observation is not
// an atomic snapshot or a working-tree content digest (owned by sibling leaves).
func recheckConsistency(ctx context.Context, runner Runner, dir string, head Head, objectFormat string, version int, indexState indexState, indexBytes, stagedBytes, unstagedBytes []byte) error {
 nowHead, err := readHead(ctx, runner, dir, objectFormat)
 if err != nil { return err }
 if !reflect.DeepEqual(nowHead, head) { return refuse(GateConsistency, "HEAD moved during capture") }
'''+s[b:]
s=s.replace('\tstagedAgain, refusal :=', ''' nowState, stateErr := readIndexState(ctx, runner, dir)
 if stateErr != nil { return stateErr }
 nowVersion, versionErr := readIndexVersion(ctx, runner, dir)
 if versionErr != nil { return versionErr }
 if !indexState.equal(nowState) || version != nowVersion { return refuse(GateConsistency, "actual index moved during capture") }
 stagedAgain, refusal :=''',1)
s=s.replace('// Snapshot is the immutable capture result. Every slice is sorted and\n// every string validated, so two captures of one quiesced repository\n// encode byte-for-byte identically.', '// Snapshot is an internal capture result, not a complete wire member.\n// See doc.go for validated domains and the sibling-owned wire fields.')
p.write_text(s)
