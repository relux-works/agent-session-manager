import subprocess,sys,pathlib,json
root=pathlib.Path(__file__).resolve().parent
name=sys.argv[1]; command=sys.argv[2:]
with (root/(name+'.log')).open('w') as f:
 f.write('$ '+' '.join(command)+'\n');f.flush()
 p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 f.write('\nEXIT='+str(p.returncode)+'\n')
(root/(name+'.json')).write_text(json.dumps({'command':command,'exit':p.returncode})+'\n')
print(name,'exit',p.returncode)
sys.exit(p.returncode)
