package gitsnap

import (
 "bytes"
 "context"
 "fmt"
 "os"
 "os/exec"
 "path/filepath"
 "strings"
 "testing"
 "time"
)

func TestIndependentSplitIndexRefresh(t *testing.T) {
 for _, alternate := range []bool{false,true} { for _, changed := range []bool{false,true} {
 t.Run(fmt.Sprintf("alternate=%v/changed=%v",alternate,changed),func(t *testing.T){
  dir:=initLiveRepo(t)
  gitRun(t,dir,"update-index","--split-index")
  index:=filepath.Join(dir,".git","index")
  if alternate {
   data,err:=os.ReadFile(index); if err!=nil {t.Fatal(err)}
   index=filepath.Join(t.TempDir(),"alternate")
   if err:=os.WriteFile(index,data,0600);err!=nil {t.Fatal(err)}
   t.Setenv("GIT_INDEX_FILE",index)
  }
  t.Setenv("GIT_OPTIONAL_LOCKS","1")
  tmp:=t.TempDir();t.Setenv("TMPDIR",tmp)
  before,err:=os.ReadFile(index);if err!=nil {t.Fatal(err)}
  initial,err:=os.Stat(index);if err!=nil {t.Fatal(err)}
  shared,_:=filepath.Glob(filepath.Join(dir,".git","sharedindex.*"))
  sharedBytes:=map[string][]byte{}
  for _,path:=range shared {sharedBytes[path],err=os.ReadFile(path);if err!=nil {t.Fatal(err)}}
  p:=filepath.Join(dir,"README.md");if err:=os.Remove(p);err!=nil {t.Fatal(err)}
  body:="base\n";if changed {body="edit\n"}
  if err:=os.WriteFile(p,[]byte(body),0644);err!=nil {t.Fatal(err)}
  for i:=0;i<2;i++ {
   snapshot,err:=Capture(context.Background(),ExecGitRunner{},dir);if err!=nil {t.Fatal(err)}
   want:=0;if changed {want=1};if len(snapshot.Unstaged)!=want {t.Fatalf("unstaged=%+v want=%d",snapshot.Unstaged,want)}
  }
  after,err:=os.ReadFile(index);if err!=nil {t.Fatal(err)}
  final,err:=os.Stat(index);if err!=nil {t.Fatal(err)}
  if !bytes.Equal(before,after)||!os.SameFile(initial,final)||!initial.ModTime().Equal(final.ModTime()) {t.Fatal("original index bytes/identity/mtime changed")}
  for path,before:=range sharedBytes {after,err:=os.ReadFile(path);if err!=nil||!bytes.Equal(before,after){t.Fatal("shared index bytes changed",err)}}
  remaining,_:=os.ReadDir(tmp);if len(remaining)!=0 {t.Fatalf("temporary leak=%v",remaining)}
  t.Logf("real split index preserved: alternate=%v changed=%v shared=%d",alternate,changed,len(shared))
 })}}
}

func TestIndependentReverseIndexVersionRace(t *testing.T){
 dir:=initLiveRepo(t);gitRun(t,dir,"update-index","--index-version","4")
 count:=0
 runner:=reviewIntercept{ExecGitRunner{},func(args []string){if strings.Join(args," ")=="ls-files --stage --debug -z" {count++;if count==2 {gitRun(t,dir,"update-index","--index-version","2")}}}}
 _,err:=Capture(context.Background(),runner,dir);requireRefusal(t,err,GateConsistency)
 if count!=2 {t.Fatal("fault not executed")};captureLive(t,dir)
}

func TestIndependentFilterLiveBounds(t *testing.T){
 dir:=initLiveRepo(t)
 for i:=0;i<64;i++ {gitRun(t,dir,"config",fmt.Sprintf("filter.f%02d.required",i),"yes")}
 if got:=len(captureLive(t,dir).Features.RequiredFilters);got!=64 {t.Fatalf("filters=%d",got)}
 gitRun(t,dir,"config","filter.f64.required","yes")
 _,err:=Capture(context.Background(),ExecGitRunner{},dir);requireRefusal(t,err,GateFeatures)
 gitRun(t,dir,"config","filter.f64.required","no")
 if got:=len(captureLive(t,dir).Features.RequiredFilters);got!=64 {t.Fatal(got)}
}

func TestIndependentPrivateIndexTimestamp(t *testing.T){
 dir:=initLiveRepo(t);source:=filepath.Join(dir,".git","index");target:=filepath.Join(t.TempDir(),"index")
 stamp:=time.Unix(1700000000,123456000)
 if err:=os.Chtimes(source,stamp,stamp);err!=nil {t.Fatal(err)}
 if err:=copyIndex(source,target);err!=nil {t.Fatal(err)}
 a,_:=os.Stat(source);b,_:=os.Stat(target);if !a.ModTime().Equal(b.ModTime()) {t.Fatalf("timestamps %v != %v",a.ModTime(),b.ModTime())}
 t.Logf("timestamp preserved at measured host precision: %v",b.ModTime())
}

func TestIndependentPrivateIndexNativeTimestamp(t *testing.T){
 dir:=initLiveRepo(t);source:=filepath.Join(dir,".git","index");target:=filepath.Join(t.TempDir(),"index")
 if err:=copyIndex(source,target);err!=nil {t.Fatal(err)}
 a,_:=os.Stat(source);b,_:=os.Stat(target)
 t.Logf("native source=%v copy=%v delta=%v",a.ModTime(),b.ModTime(),a.ModTime().Sub(b.ModTime()))
 if !a.ModTime().Equal(b.ModTime()) {t.Fatal("natural index timestamp not preserved")}
}

func TestIndependentSplitAuxiliaryTimestampBound(t *testing.T){
 dir:=initLiveRepo(t);gitRun(t,dir,"update-index","--split-index")
 shared,_:=filepath.Glob(filepath.Join(dir,".git","sharedindex.*"));if len(shared)!=1 {t.Fatal(shared)}
 old:=time.Unix(1700000000,0);if err:=os.Chtimes(shared[0],old,old);err!=nil {t.Fatal(err)}
 before,_:=os.Stat(shared[0]);captureLive(t,dir);after,_:=os.Stat(shared[0])
 t.Logf("auxiliary shared-index mtime before=%v after=%v changed=%v (explicit bound)",before.ModTime(),after.ModTime(),!before.ModTime().Equal(after.ModTime()))
}

func TestIndependentPrivateIndexTimeoutCleanup(t *testing.T){
 dir:=initLiveRepo(t);tmp:=t.TempDir();t.Setenv("TMPDIR",tmp)
 actual,err:=exec.LookPath("git");if err!=nil {t.Fatal(err)}
 wrapper:=filepath.Join(t.TempDir(),"git-wrapper")
 script:="#!/bin/sh\nif [ \"$1\" = rev-parse ]; then exec '"+actual+"' \"$@\"; fi\nexec sleep 10\n"
 if err:=os.WriteFile(wrapper,[]byte(script),0755);err!=nil {t.Fatal(err)}
 _,err=(ExecGitRunner{GitPath:wrapper,Timeout:300*time.Millisecond}).Run(context.Background(),dir,"diff","--raw")
 if err==nil || !strings.Contains(err.Error(),"deadline exceeded") {t.Fatal("timeout not exercised",err)}
 entries,err:=os.ReadDir(tmp);if err!=nil||len(entries)!=0 {t.Fatalf("temporary leak=%v err=%v",entries,err)}
}
