from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path.cwd();out=Path(__file__).resolve().parent
before=json.loads((out/'candidate-identity-before.json').read_text())
paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard']).split(b'\0')
actual={os.fsdecode(x) for x in paths if x}
assert actual=={row['path'] for row in before['files']},'tracked/nonignored path set changed'
trie={}
for row in before['files']:
 p=root/row['path'];data=os.readlink(p).encode() if p.is_symlink() else p.read_bytes()
 assert hashlib.sha256(data).hexdigest()==row['sha256'],row['path']
 mode='120000' if p.is_symlink() else ('100755' if p.stat().st_mode&0o111 else '100644')
 assert mode==row['mode'],row['path']
 oid=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert oid==row['oid']
 node=trie
 parts=row['path'].split('/')
 for part in parts[:-1]:node=node.setdefault(part,{})
 node[parts[-1]]=(mode,oid)
def tree_id(node):
 entries=[]
 for name,value in node.items():
  if isinstance(value,dict):mode,oid='40000',tree_id(value);key=name.encode()+b'/'
  else:mode,oid=value;key=name.encode()
  entries.append((key,mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
 body=b''.join(payload for _,payload in sorted(entries))
 return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()
actual_tree=tree_id(trie)
assert actual_tree==before['tree'],actual_tree
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
assert head==before['head']
record={'expected_tree':before['tree'],'rederived_tree':actual_tree,'head':head,'verified_files':len(before['files']),'path_set_equal':True,'blob_and_mode_equal':True}
(out/'candidate-identity-after.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
