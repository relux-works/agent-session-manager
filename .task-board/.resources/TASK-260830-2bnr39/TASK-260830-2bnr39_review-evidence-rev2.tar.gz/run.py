import sys,subprocess,json,time,os
from pathlib import Path
out=Path(__file__).resolve().parent
name,cwd,*cmd=sys.argv[1:]
start=time.time()
with (out/(name+'.log')).open('w') as log:
 log.write('$ '+repr(cmd)+'\n');log.flush()
 try:
  code=subprocess.run(cmd,cwd=cwd,env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_SYSTEM=os.devnull),stdout=log,stderr=subprocess.STDOUT,timeout=480).returncode
 except subprocess.TimeoutExpired: code='TIMEOUT'
 log.write('\nEXIT='+str(code)+'\n')
record={'name':name,'cwd':cwd,'command':cmd,'exit':code,'seconds':time.time()-start}
(out/(name+'.json')).write_text(json.dumps(record,indent=2))
print(json.dumps(record),flush=True)
sys.exit(0 if code==0 else 1)
