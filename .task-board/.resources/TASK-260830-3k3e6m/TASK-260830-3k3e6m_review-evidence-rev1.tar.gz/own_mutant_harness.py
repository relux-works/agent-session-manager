#!/usr/bin/env python3
"""Reviewer's own narrowing mutants for TASK-260830-3k3e6m rev1.
Runs in the isolated copy at /tmp/rev3k3e6m/cand only."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path("/tmp/rev3k3e6m/cand")
PACKAGE = "internal/matjournal"

MUTANTS = [
    {
        "name": "R-own-unfenced-flip",
        "path": f"{PACKAGE}/recover.go",
        "find": "\tif assessment.bridgeLive() && !input.Bridge.LeaseActive && assessment.bridgeAdopted() {\n",
        "replace": "\tif assessment.bridgeLive() && input.Bridge.LeaseActive && assessment.bridgeAdopted() {\n",
        "count": 1,
        "run": "TestRecoverGatesPark/unfenced_continuation",
        "expect": "KILLED",
        "note": "Flips the lease polarity: admits the unfenced continuation (live adopted manager without the winning lease) while still parking fenced ones.",
    },
    {
        "name": "R-own-dormant-open-token",
        "path": f"{PACKAGE}/journal.go",
        "find": "\t\tif board.ImportToken != nil || board.OpenToken != nil {\n\t\t\treturn invalid(\"task-board dormant_finalized keeps no usable token\")\n",
        "replace": "\t\tif board.ImportToken != nil {\n\t\t\treturn invalid(\"task-board dormant_finalized keeps no usable token\")\n",
        "count": 1,
        "run": "TestOwnDormantOpenTokenRefuses",
        "expect": "KILLED",
        "note": "Admits exactly dormant_finalized carrying a usable open token; import-token rule stays.",
    },
    {
        "name": "R-own-chunk-bound",
        "path": f"{PACKAGE}/journal.go",
        "find": "\tif len(chunks) > maxBlobs {\n",
        "replace": "\tif len(chunks) > maxBlobs+1 {\n",
        "count": 1,
        "run": "TestOwnChunkBoundRefuses65537",
        "expect": "KILLED",
        "note": "Off-by-one: admits exactly 65537 blobs; 65538+ still refuse.",
    },
    {
        "name": "R-own-digest-prefix",
        "path": f"{PACKAGE}/store.go",
        "find": "\tif journal.PrepareRequestDigest != digest {\n",
        "replace": "\tif len(digest) < 7 || digest[:7] != journal.PrepareRequestDigest[:7] {\n",
        "count": 1,
        "run": "TestCreateReplayAndConflict",
        "expect": "KILLED",
        "note": "Journal digest compared by scheme prefix only (companion receipt weakening below admits the same class).",
        "extra": ("\t\tif receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {\n",
                  "\t\tif len(receipt.InputDigest) < 7 || receipt.InputDigest[:7] != digest[:7] {\n"),
    },
    {
        "name": "C-own-control",
        "path": f"{PACKAGE}/store.go",
        "find": "// Create binds the prepare closure durably: both caller-stable IDs and\n",
        "replace": "// Create binds the prepare closure durably (control): both caller-stable IDs and\n",
        "count": 1,
        "run": "TestCreateReplayAndConflict",
        "expect": "SURVIVED",
        "note": "Harmless control: comment-only edit must survive.",
    },
]


def run_one(mutant):
    target = REPO / mutant["path"]
    original = target.read_text()
    found = original.count(mutant["find"])
    if found != mutant["count"]:
        return f"ERROR: {mutant['name']}: anchors {found}, want {mutant['count']}"
    patched = original.replace(mutant["find"], mutant["replace"])
    if "extra" in mutant:
        if patched.count(mutant["extra"][0]) != 1:
            return f"ERROR: {mutant['name']}: extra anchors {patched.count(mutant['extra'][0])}, want 1"
        patched = patched.replace(mutant["extra"][0], mutant["extra"][1])
    log = []
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(patched)
            run = subprocess.run(
                ["go", "test", f"./{PACKAGE}/", "-run", mutant["run"], "-count=1"],
                cwd=REPO,
                capture_output=True,
                text=True,
                timeout=300,
            )
        finally:
            shutil.copy2(backup, target)
    output = (run.stdout + run.stderr).strip()
    tail = "\n".join(output.splitlines()[-15:])
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant['name']}: exit {run.returncode}\n{tail}"
    mark = "ok" if verdict == mutant["expect"] else "MISMATCH"
    return f"{mark}: {mutant['name']}: {verdict} (want {mutant['expect']}) :: {mutant['note']}\nexit={run.returncode}\n{tail}"


def main(argv):
    selected = [m for m in MUTANTS if not argv or m["name"] in argv]
    failures = 0
    for mutant in selected:
        try:
            line = run_one(mutant)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {mutant['name']}: timed out"
        print(line, flush=True)
        print("-" * 70, flush=True)
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
