package matjournal

// Independent reviewer probes for TASK-260830-3k3e6m rev1. These live in
// the isolated review copy only; they are not part of the candidate.
// Each drives the production entry point and asserts the exact outcome.

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// A provable commit (committing journal, converged authorities, exact
// marker) must still park when the winning lease moved: the rejection
// gates precede every completion.
func TestOwnExclusivityProvableCommitStillParksOnMovedLease(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputs())
	backup := "/home/ivan/.local/state/ax/materializations/" + testMatID + "/workspace_relux"
	if _, err := store.UpdateAuthority(testMatID, "workspace_relux", AuthorityState{
		RootPath: testRootWorkspace, CompletedSequences: []uint64{1},
		RollbackRoot: &backup, State: AuthorityPrepared,
	}); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdateAuthority(testMatID, "workspace_relux", AuthorityState{
		RootPath: testRootWorkspace, CompletedSequences: []uint64{1}, State: AuthorityCommitted,
	}); err != nil {
		t.Fatal(err)
	}
	for _, phase := range []string{PhaseValidating, PhasePrepared, PhaseCommitting} {
		if _, err := store.Transition(testMatID, phase, TransitionOpts{}); err != nil {
			t.Fatal(err)
		}
	}
	input := baseRecoveryInput()
	input.Boundary = BoundaryAfterFinalize
	input.Provider.State = ProviderUnknown
	input.Marker = MarkerValidMatch
	input.MarkerBytes = testMarker(t)
	input.LeaseAfter = LeaseIdentity{Epoch: 5, ID: testLeaseB}
	outcome, evidence, err := store.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover error = %v", err)
	}
	mustOutcome(t, outcome, OutcomeRecoverableParked, "Recover(exclusivity)")
	mustEvidenceComplete(t, evidence, "Recover(exclusivity)")
	if !strings.Contains(evidence.Reason, "lease") {
		t.Fatalf("reason = %q, want the lease gate to win over the provable commit", evidence.Reason)
	}
}

// A prepare receipt without its journal is absence, not a
// classification: durable facts are read first.
func TestOwnReceiptWithoutJournalIsAbsence(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputs())
	if err := os.Remove(filepath.Join(store.root, testMatID, "journal.json")); err != nil {
		t.Fatal(err)
	}
	input := baseRecoveryInput()
	input.Boundary = BoundaryAfterPrepare
	_, _, err := store.Recover(testMatID, input)
	if !errors.Is(err, ErrUnknownJournal) {
		t.Fatalf("Recover(receipt-without-journal) = %v, want ErrUnknownJournal", err)
	}
}

// Garbage journal bytes park with quarantine evidence that re-reads
// byte-identical after a clean reopen.
func TestOwnTornJournalGarbageParks(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputs())
	if err := os.WriteFile(filepath.Join(store.root, testMatID, "journal.json"), []byte("{\x00not-json"), 0o600); err != nil {
		t.Fatal(err)
	}
	input := baseRecoveryInput()
	input.Boundary = BoundaryAfterFinalize
	outcome, _, err := store.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover error = %v", err)
	}
	mustOutcome(t, outcome, OutcomeRecoverableParked, "Recover(torn garbage)")
	before, err := os.ReadFile(filepath.Join(store.root, testMatID, "recovery.json"))
	if err != nil {
		t.Fatalf("recovery.json: %v", err)
	}
	reopened, err := Open(filepath.Dir(store.root))
	if err != nil {
		t.Fatal(err)
	}
	reopened.Now = fixedClock
	after, err := os.ReadFile(filepath.Join(reopened.root, testMatID, "recovery.json"))
	if err != nil {
		t.Fatalf("recovery.json after reopen: %v", err)
	}
	if string(before) != string(after) {
		t.Fatalf("parked evidence changed across reopen:\n%s\n%s", before, after)
	}
}

// An unrecorded prepare (provider-store authority, no provider
// transaction) with an unknown provider probe at CR-MAT-05 parks: the
// effect may have executed and is unreconciled.
func TestOwnUnknownProbeAtCRMAT05Parks(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputsComposite())
	input := baseRecoveryInput()
	input.Boundary = BoundaryAfterPrepareOp
	input.Provider.State = ProviderUnknown
	outcome, evidence, err := store.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover error = %v", err)
	}
	mustOutcome(t, outcome, OutcomeRecoverableParked, "Recover(CR-MAT-05 unknown provider)")
	if !strings.Contains(evidence.Reason, "provider status is unknown") {
		t.Fatalf("reason = %q, want the provider-uncertainty floor", evidence.Reason)
	}
}

// A dormant_finalized bridge carrying a usable open token refuses:
// the token is destroyed at finalize and must never come back.
func TestOwnDormantOpenTokenRefuses(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputsBoardOnly())
	if _, err := store.UpdateTaskBoard(testMatID, testBoardImportedDormant()); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdateTaskBoard(testMatID, testBoardOpenedDormant()); err != nil {
		t.Fatal(err)
	}
	board := testBoardOpenedDormant()
	dormant := "dormant"
	finalized := TaskBoardTransaction{
		BundleID:          board.BundleID,
		ActivationMode:    board.ActivationMode,
		ImportOperationID: board.ImportOperationID,
		OpenOperationID:   board.OpenOperationID,
		AdoptOperationID:  board.AdoptOperationID,
		ResumeOperationID: board.ResumeOperationID,
		State:             BoardDormantFinalized,
		OpenToken:         str(testOpenToken),
		DormantManagerRef: board.DormantManagerRef,
		LastBridgeState:   &dormant,
		LastStatusAt:      board.LastStatusAt,
		CleanupState:      "pending_expiry",
		CleanupAfter:      board.OpenExpiresAt,
	}
	if _, err := store.UpdateTaskBoard(testMatID, finalized); err == nil {
		t.Fatalf("UpdateTaskBoard(dormant with open token) admitted a usable token after finalize")
	}
}

// The per-blob chunk map refuses 65537 blobs: the bound is 0..65536.
func TestOwnChunkBoundRefuses65537(t *testing.T) {
	chunks := make(map[string][]uint32, maxBlobs+1)
	for i := 0; i <= maxBlobs; i++ {
		chunks[fmt.Sprintf("sha256:%064x", i)] = []uint32{0}
	}
	if err := checkChunkMap(chunks); err == nil {
		t.Fatalf("checkChunkMap admitted %d blobs, want refusal at 65536", len(chunks))
	}
}

// 13.12 disk-full at CR-MAT-06 on a prepared journal: the row parks
// with its remediation regardless of phase, and nothing mutates.
func TestOwnDiskFullAtPreparedParks(t *testing.T) {
	store := openTestStore(t)
	mustCreate(t, store, testInputs())
	backup := "/home/ivan/.local/state/ax/materializations/" + testMatID + "/workspace_relux"
	if _, err := store.UpdateAuthority(testMatID, "workspace_relux", AuthorityState{
		RootPath: testRootWorkspace, CompletedSequences: []uint64{1},
		RollbackRoot: &backup, State: AuthorityPrepared,
	}); err != nil {
		t.Fatal(err)
	}
	for _, phase := range []string{PhaseValidating, PhasePrepared} {
		if _, err := store.Transition(testMatID, phase, TransitionOpts{}); err != nil {
			t.Fatal(err)
		}
	}
	input := baseRecoveryInput()
	input.Boundary = BoundaryAfterOpen
	input.Host = HostDiskFull
	outcome, evidence, err := store.Recover(testMatID, input)
	if err != nil {
		t.Fatalf("Recover error = %v", err)
	}
	mustOutcome(t, outcome, OutcomeRecoverableParked, "Recover(disk full at prepared)")
	if !strings.Contains(evidence.Reason, "disk full") {
		t.Fatalf("reason = %q, want the disk-full row", evidence.Reason)
	}
	loaded, _, err := store.Get(testMatID)
	if err != nil {
		t.Fatal(err)
	}
	if loaded.Phase != PhasePrepared {
		t.Fatalf("phase = %q, want the preserved prepared journal", loaded.Phase)
	}
}
