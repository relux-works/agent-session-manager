package cloneplan_test
import (
 "testing"
 cloneplan "github.com/relux-works/agent-session-manager/internal/cloneplan"
)
func TestReviewFourNodeSelfEdgeRefusal(t *testing.T) {
 input := dagInput([]uint64{1,2,3,4}, [][]uint64{{},{},{},{4}})
 _, err := cloneplan.BuildProjectionPlan(input)
 if err == nil { t.Fatal("four-node self edge admitted") }
 _ = cloneplan.ErrInvalid
}
