import base64, hashlib, json, pathlib, re
log = pathlib.Path(__file__).with_name('fixture-emission.log').read_text()
for label, member in [('PLAN','projection_plan_id'), ('MANIFEST','projected_object_manifest_id')]:
    match = re.search(r'REVIEW_'+label+r'=([A-Za-z0-9+/=]+)', log)
    assert match, label
    obj = json.loads(base64.b64decode(match.group(1)))
    claim = obj.pop(member)
    canonical = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    recomputed = 'sha256:' + hashlib.sha256(canonical).hexdigest()
    print(label, claim, recomputed, claim == recomputed)
    assert claim == recomputed
