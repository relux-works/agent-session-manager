from pathlib import Path
import re,sys
root=Path(sys.argv[1])
member=(root/'internal/cloneplan/members_test.go').read_text()
dag=(root/'internal/cloneplan/dag_test.go').read_text()
null=(root/'internal/cloneplan/nullability_test.go').read_text()
checks=[
 ('member census derived from Go types', 'reflect.TypeOf' in member or 'reflect.ValueOf' in member),
 ('all dependency graphs through 5 operations', bool(re.search(r'for n := 1; n <= 5; n\+\+',dag))),
 ('entry three blob-only fields independently enumerated', all(re.search(r'for _, '+x+r' := range',null) for x in ('hasCount','hasBlob','hasDescriptor'))),
]
for label,ok in checks: print(('PASS' if ok else 'FAIL')+'\t'+label)
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
