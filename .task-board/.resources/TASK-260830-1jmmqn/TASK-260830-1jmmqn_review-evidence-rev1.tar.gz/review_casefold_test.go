package cloneplan_test
import (
 "testing"
 cloneplan "github.com/relux-works/agent-session-manager/internal/cloneplan"
)
func TestReviewTitlecaseRefusal(t *testing.T) {
 sealed := mustBuildPlan(t, validPlanInput())
 document := decodeDocument(t, sealed)
 document["Strategy"] = document["strategy"]
 delete(document,"strategy")
 _, err := cloneplan.DecodeProjectionPlan(marshalDocument(t, document))
 if err == nil { t.Fatal("Titlecase member admitted through DecodeProjectionPlan") }
}
