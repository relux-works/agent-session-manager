package cloneplan_test
import (
 "testing"
 cloneplan "github.com/relux-works/agent-session-manager/internal/cloneplan"
)
func TestReviewBlobDoubleMissingRefusal(t *testing.T) {
 manifest := validManifestInput()
 blob := validBlobEntryInput(1, "combo")
 blob.ByteCount = nil
 blob.BlobID = nil
 manifest.Entries = []cloneplan.ProjectedEntryInput{blob}
 _, err := cloneplan.BuildProjectedObjectManifest(manifest)
 if err == nil { t.Fatal("blob with byte_count and blob_id missing admitted") }
}
