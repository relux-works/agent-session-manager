import os, subprocess
from pathlib import Path
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/review-scratch')/os.environ['TASK_BOARD_RUN_ID']/'mutant'
logs=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-21bxa3/worktree/.temp/TASK-260830-1jmmqn/review')
plants=[
 ('case_member','internal/cloneplan/decode.go','if !allowed[name] {','if !allowed[name] && name != "Strategy" {','TestMemberCensusMiscased'),
 ('dag_equal','internal/cloneplan/operations.go','if dependency >= operation.Sequence {','if dependency > operation.Sequence {','TestDAGRefusalLiterals'),
 ('resource_blob_null','internal/cloneplan/resources.go','if kind == "blob" && !hasBlob {','if kind == "blob" && !hasBlob && owner != "expected target resource[0]" {','TestResourceBranchLiterals'),
 ('key_bound_plus_one','internal/cloneplan/manifest.go','if length := stringLength(input.ResourceKey); length < 1 || length > 512 {','if length := stringLength(input.ResourceKey); length < 1 || length > 513 {','TestEntryStringEdges'),
 ('constant_second','internal/cloneplan/plans.go','if input.MaterializationIntent != "clone" {','if input.MaterializationIntent != "clone" && input.MaterializationIntent != "prepare" {','TestPlanConstants'),
]
for name,path,old,new,test in plants:
 p=root/path
 original=p.read_text()
 assert original.count(old)==1,(name,original.count(old))
 p.write_text(original.replace(old,new))
 try:
  cmd=['go','test','-count=1','-run','^'+test+'$','./internal/cloneplan']
  r=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  (logs/(name+'.log')).write_text('command: '+' '.join(cmd)+'\nexit: '+str(r.returncode)+'\n'+r.stdout)
  print(name,'exit',r.returncode,'FAIL' if '--- FAIL:' in r.stdout else 'NO_TEST_FAIL')
 finally:
  p.write_text(original)
