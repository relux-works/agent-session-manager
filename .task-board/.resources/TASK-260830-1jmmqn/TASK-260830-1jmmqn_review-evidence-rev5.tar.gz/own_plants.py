from pathlib import Path
import subprocess, sys
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/review-scratch/RUN-260924-ea1048/candidate')
logs=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-21bxa3/worktree/.temp/reviewer-rev5')
plants={
 'equal-dependency':('internal/cloneplan/operations.go', [('if dependency >= operation.Sequence {','if dependency > operation.Sequence {')], 'TestDAGRefusalLiterals'),
 'directory-blob-id':('internal/cloneplan/resources.go',[('if kind == "directory" && hasBlob {','if kind == "directory" && hasBlob && owner == "never" {')], 'TestResourceNullabilityGrid'),
 'contract-bound-plus-one':('internal/cloneplan/plans.go',[('if count < 1 || count > 64 {','if count < 1 || count > 65 {')], 'TestCountEdges'),
 'copy-intent-build':('internal/cloneplan/plans.go',[('if input.MaterializationIntent != "clone" {','if input.MaterializationIntent != "clone" && input.MaterializationIntent != "copy" {')], 'TestPlanConstantCopyRegression/materialization_intent-build'),
 'case-insensitive-member':('internal/cloneplan/decode.go', [('"io"\n','"io"\n\t"strings"\n'), ('if !allowed[name] {','if !allowed[name] {\n\t\t\tfolded := false\n\t\t\tfor key := range allowed { if strings.EqualFold(name,key) { folded = true; break } }\n\t\t\tif folded { continue }'), ('if _, present := members[name]; !present {','if _, present := members[name]; !present {\n\t\t\tfolded := false\n\t\t\tfor key := range members { if strings.EqualFold(name,key) { folded = true; break } }\n\t\t\tif folded { continue }')], 'TestMemberCensusMiscased'),
}
for name in sys.argv[1:] or plants:
    rel, patches, test=plants[name]; path=root/rel; original=path.read_text(); mutated=original
    try:
        for old,new in patches:
            if mutated.count(old)!=1: raise RuntimeError(f'{name}: anchor count {mutated.count(old)} for {old}')
            mutated=mutated.replace(old,new,1)
        path.write_text(mutated)
        run=subprocess.run(['go','test','-count=1','-run',f'^{test}$','./internal/cloneplan'],cwd=root,text=True,capture_output=True,timeout=300)
        outcome=f'# {name} exit={run.returncode} test={test}\n{run.stdout}{run.stderr}'
        (logs/f'own-{name}.log').write_text(outcome)
        print(name,run.returncode,'KILLED' if run.returncode and '--- FAIL' in outcome else 'SURVIVED/ERROR',flush=True)
    finally:
        path.write_text(original)
