import json, hashlib, re
from pathlib import Path
p=Path('.temp/reviewer-rev5/fixtures.log').read_text()
for label,self_field in [('PLAN','projection_plan_id'),('MANIFEST','projected_object_manifest_id')]:
    line=next(x for x in p.splitlines() if f'{label}=' in x)
    doc=json.loads(line.split(f'{label}=',1)[1])
    claim=doc.pop(self_field)
    def walk(v):
      if isinstance(v,dict):
       for x in v.values(): walk(x)
      elif isinstance(v,list):
       for x in v: walk(x)
      elif isinstance(v,float): raise ValueError('fixture float requires full number JCS')
    walk(doc)
    canonical=json.dumps(doc,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
    value='sha256:'+hashlib.sha256(canonical).hexdigest()
    assert value==claim,(label,value,claim)
    print(label,'bytes',len(canonical),'claim',claim,'match',value==claim,'json-keys',len(doc))
