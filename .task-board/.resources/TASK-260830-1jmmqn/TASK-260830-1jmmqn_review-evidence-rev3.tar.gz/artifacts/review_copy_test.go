package cloneplan_test
import (
 "testing"
 cloneplan "github.com/relux-works/agent-session-manager/internal/cloneplan"
)
func TestReviewCopyConstant(t *testing.T) {
 t.Run("build",func(t *testing.T) {
  input:=validPlanInput()
  input.TransactionPlan.MaterializationIntent="copy"
  _,err:=cloneplan.BuildProjectionPlan(input)
  requireRefusal(t,err,"materialization_intent is not clone")
 })
 t.Run("decode",func(t *testing.T) {
  doc:=decodeDocument(t,mustBuildPlan(t,validPlanInput()))
  doc["transaction_plan"].(map[string]any)["materialization_intent"]="copy"
  _,err:=cloneplan.DecodeProjectionPlan(marshalDocument(t,doc))
  requireRefusal(t,err,"materialization_intent is not clone")
 })
}
