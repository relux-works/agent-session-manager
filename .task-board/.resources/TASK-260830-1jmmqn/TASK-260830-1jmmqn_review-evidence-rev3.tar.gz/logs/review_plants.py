from pathlib import Path
import subprocess,os
root=Path(__file__).parent
log=root.parent/'logs'
plants=[
 ('case-other-member','internal/cloneplan/decode.go','\treturn members, nil\n','\tif v, ok := members["Fidelity_profile"]; ok { delete(members, "Fidelity_profile"); members["fidelity_profile"] = v }\n\treturn members, nil\n','TestMemberCensusMiscased',1),
 ('dag-four-self','internal/cloneplan/operations.go','if dependency >= operation.Sequence {','if dependency >= operation.Sequence && !(operation.Sequence == 4 && dependency == 4) {','TestDAGWholeDomainCensus',1),
 ('entry-descriptor-only','internal/cloneplan/manifest.go','if !hasDescriptor {','if !hasDescriptor && !(owner == "projected object entry[0]" && hasCount && hasBlob) {','TestEntryNullabilityGrid',1),
 ('mode-plus-one','internal/cloneplan/resources.go','if *mode > maxMode {','if *mode > maxMode+1 {','TestNumberModel',1),
 ('second-intent','internal/cloneplan/plans.go','if input.MaterializationIntent != "clone" {','if input.MaterializationIntent != "clone" && input.MaterializationIntent != "copy" {','TestPlanConstants',1),
 ('neutral-control','internal/cloneplan/doc.go','package cloneplan\n','// review neutral control\npackage cloneplan\n','TestPlanRoundTrip',0),
]
with (log/'own-plants-summary.log').open('w') as summary:
 for name,path,find,repl,expected_run,expected_exit in plants:
  file=root/path
  original=file.read_text()
  if original.count(find)!=1: raise SystemExit(f'{name}: find count {original.count(find)}')
  try:
   file.write_text(original.replace(find,repl,1))
   cmd=['go','test','-count=1','-run',f'^{expected_run}$','./internal/cloneplan']
   p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
   (log/f'own-{name}.log').write_text(f'$ {" ".join(cmd)}\n{p.stdout}\n[exit {p.returncode}]\n')
   verdict='KILLED' if p.returncode==1 and '--- FAIL:' in p.stdout else ('SURVIVED' if p.returncode==0 else 'ERROR')
   summary.write(f'{name} {verdict} exit={p.returncode} expected={expected_exit}\n');summary.flush()
   if p.returncode!=expected_exit: raise SystemExit(f'{name}: unexpected exit {p.returncode}')
  finally: file.write_text(original)
print((log/'own-plants-summary.log').read_text())
