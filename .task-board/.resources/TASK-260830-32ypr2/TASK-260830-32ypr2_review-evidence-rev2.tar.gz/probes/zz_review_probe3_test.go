package cloneproject

import "testing"

func TestReviewProbeUnderR1(t *testing.T) {
	// Under R1 (body not required): unknown type without a body.
	probeMembers(t, "R1-unknown-no-body", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		`{"v":1,"native_event_id":"evt-r1","native_type":"frobnicate","origin":"native","protection":"none","actor":"main"}`)}})
	probeMembers(t, "R1-known-no-body", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		`{"v":1,"native_event_id":"evt-r1b","native_type":"message/user","origin":"native","protection":"none","actor":"main"}`)}})
}
