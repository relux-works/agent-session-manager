package cloneproject

import (
	"strings"
	"testing"
)

func probeMembers(t *testing.T, name string, members []fixtureMember) {
	t.Helper()
	capture, store := captureMembers(t, members)
	result, err := Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
	if err != nil {
		t.Logf("PROBE %s: REFUSED: %v", name, err)
		return
	}
	for index, event := range result.DecodedEvents {
		sealed := sealedPayload(t, result.Events[index])
		t.Logf("PROBE %s: ADMITTED ordinal=%d kind=%s visibility=%s status=%s reasons=%q refs=%d off=%d len=%d payload=%v",
			name, index, event.Kind, event.Visibility, event.Evidence.CaptureStatus, event.Evidence.ReasonCodes,
			len(event.Evidence.RawRefs), event.Evidence.RawRefs[0].Offset, event.Evidence.RawRefs[0].Length, sealed)
	}
}

func TestReviewProbeValueShapes(t *testing.T) {
	// PB1: null text member sealed as empty inline content?
	probeMembers(t, "PB1-text-null", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-b1", "message/user", "native", "none", "main", `{"text":null}`))}})
	// PB2: null ciphertext on a foreign encrypted reasoning record.
	probeMembers(t, "PB2-ciphertext-null", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-b2", "reasoning/encrypted", "foreign", "encrypted", "main", `{"ciphertext":null}`))}})
	// PB3: envelope version literal variants through the landed uint53 gate.
	for _, v := range []string{"1.0", "1e0", "-0", "01", " 1", "true", "[1]"} {
		probeMembers(t, "PB3-version-"+strings.TrimSpace(v), []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
			`{"v":` + v + `,"native_event_id":"evt-b3","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`)}})
	}
	// PB4: empty unknown-class member (zero-length whole-member opaque).
	probeMembers(t, "PB4-empty-unknown-member", []fixtureMember{
		{key: "store/mystery", class: "unknown", content: []byte{}},
		{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("evt-b4", "message/user", "native", "none", "main", `{"text":"x"}`))},
	})
	// PB5: CRLF line endings: the record byte range keeps the CR.
	probeMembers(t, "PB5-crlf", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: []byte(
		rec("evt-b5a", "message/user", "native", "none", "main", `{"text":"x"}`) + "\r\n" + rec("evt-b5b", "message/user", "native", "none", "main", `{"text":"y"}`) + "\r\n")}})
	// PB6: 128-char subagent name passes the selector gate; does the builder admit the 137-char selector as an actor name?
	probeMembers(t, "PB6-subagent-128", func() []fixtureMember {
		return []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
			rec("evt-b6", "message/user", "native", "none", "subagent:"+strings.Repeat("n", 128), `{"text":"x"}`))}}
	}())
	// PB7: body is a JSON string for a known type (not an object).
	probeMembers(t, "PB7-body-string-known", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-b7", "message/user", "native", "none", "main", `"not-an-object"`))}})
	// PB8: body is a JSON string for an unknown type.
	probeMembers(t, "PB8-body-string-unknown", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-b8", "frobnicate", "native", "none", "main", `"not-an-object"`))}})
	// PB9: unicode-escaped key spelling of a required member: strict gate sees the unescaped key.
	probeMembers(t, "PB9-escaped-key-duplicate", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		`{"v":1,"native_event_id":"evt-b9","native_type":"frobnicate","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`)}})
	// PB10: live_attestation null / non-bool
	probeMembers(t, "PB10-live-attestation-null", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-b10", "tool/definition", "native", "none", "main", `{"tool_name":"w","definition_digest":"`+fixtureDigest("d")+`","live_attestation":null}`))}})
	// PB11: whitespace-padded body and envelope (strict gate tolerance).
	probeMembers(t, "PB11-whitespace", []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		`  {"v":1,"native_event_id":"evt-b11","native_type":"message/user","origin":"native","protection":"none","actor":"main","body": { "text" : "x" } }  `)}})
}
