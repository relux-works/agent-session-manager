#!/usr/bin/env python3
"""Reviewer narrowing plants for TASK-260830-32ypr2 rev2 (RUN-260918-a4ffef).

Each row mutates one production file in an isolated copy of the exact
candidate tree, runs the committed cloneproject suite through the real
Normalize entry (-run TestNormalize, i.e. the whole committed suite, not
one killer), records the subprocess exit and verdict, restores the file.
Rows are on gates the producer's harness does not mutate. RC-control is
the applied harmless SURVIVED control.
"""
import shutil, subprocess, sys, tempfile, time
from dataclasses import dataclass
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
LOG_DIR = Path(sys.argv[2]).resolve()
PACKAGE = "internal/cloneproject"

@dataclass(frozen=True)
class Mutant:
    name: str; path: str; find: str; replace: str; run: str; note: str

M = [
    Mutant("R1-required-member-body-dropped", f"{PACKAGE}/native.go",
        '''\tfor _, name := range []string{"v", "native_event_id", "native_type", "origin", "protection", "actor", "body"} {\n''',
        '''\tfor _, name := range []string{"v", "native_event_id", "native_type", "origin", "protection", "actor"} {\n''',
        "TestNormalize",
        "Member check dropped: body is no longer a required envelope member. A known type still refuses at the body decode (different message); an unknown type without a body is admitted as opaque_event."),
    Mutant("R2-native-type-width-513", f"{PACKAGE}/native.go",
        '''\tif environ.StringLength(envelope.NativeType) < 1 || environ.StringLength(envelope.NativeType) > 512 {\n''',
        '''\tif environ.StringLength(envelope.NativeType) < 1 || environ.StringLength(envelope.NativeType) > 513 {\n''',
        "TestNormalize",
        "Bound widened by one: a 513-character native_type is admitted; 514+ still refuses."),
    Mutant("R3-reasons-unsorted", f"{PACKAGE}/dispatch.go",
        '''\t\treasons = append(reasons, reasonUnknownNative)\n\t\tsort.Strings(reasons)\n''',
        '''\t\treasons = append([]string{reasonUnknownNative}, reasons...)\n''',
        "TestNormalize",
        "Unsorted array admitted: the two-reason list is emitted in reverse order with no sort."),
    Mutant("R4-capture-status-partial-messages", f"{PACKAGE}/dispatch.go",
        '''\t\tCaptureStatus: "exact",\n''',
        '''\t\tCaptureStatus: map[bool]string{true: "partial", false: "exact"}[record.NativeType == nativeMessageUser],\n''',
        "TestNormalize",
        "Capture status stamped partial for exactly message/user records while nothing is partial; every other record still stamps exact."),
    Mutant("R5-reasoning-summary-routed-public", f"{PACKAGE}/dispatch.go",
        '''\tdefault:\n\t\tunit.kind = "reasoning_summary"\n\t\tunit.visibility = "internal"\n''',
        '''\tdefault:\n\t\tunit.kind = "user_message"\n\t\tunit.visibility = "public"\n''',
        "TestNormalize",
        "Kind/visibility swap on the one emitted kind with no positive row: unprotected reasoning/summary projects user_message with public visibility."),
    Mutant("R6-first-native-instruction-wins", f"{PACKAGE}/tools.go",
        '''\t\tif observation.record.Origin != "native" {\n\t\t\tcontinue\n\t\t}\n''',
        '''\t\tif observation.record.Origin != "native" || effective.Found {\n\t\t\tcontinue\n\t\t}\n''',
        "TestNormalize",
        "Fold order swap: the first native instruction wins instead of the last (doc comment claims last-wins)."),
    Mutant("R7-external-actor-kind-subagent", f"{PACKAGE}/dispatch.go",
        '''\t\tkind := "external"\n''',
        '''\t\tkind := "subagent"\n''',
        "TestNormalize",
        "Actor kind swap for exactly the external selector: it seals as a subagent actor parented on main."),
    Mutant("RC-control-comment", f"{PACKAGE}/normalize.go",
        '''// Stable reason codes this projection emits.''',
        '''// Stable reason codes this projection emits (reviewer control).''',
        "TestNormalize",
        "Harmless control: comment-only edit must SURVIVE."),
]

def run(m: Mutant):
    target = REPO / m.path
    original = target.read_text()
    if original.count(m.find) != 1:
        return "ERROR", f"anchors={original.count(m.find)}", -1, 0.0
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "b"; shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(m.find, m.replace))
            started = time.time()
            r = subprocess.run(["go", "test", f"./{PACKAGE}/", "-run", m.run, "-count=1"], cwd=REPO, capture_output=True, text=True, timeout=600)
            elapsed = time.time() - started
        finally:
            shutil.copy2(backup, target)
    out = (r.stdout + r.stderr).strip()
    if 'build failed' in out or '\n# ' in out or out.startswith('# '):
        return "ERROR", out, r.returncode, elapsed
    if r.returncode == 0:
        return "SURVIVED", out, 0, elapsed
    if '--- FAIL' in out or 'FAIL:' in out:
        return "KILLED", out, r.returncode, elapsed
    return "ERROR", out, r.returncode, elapsed

LOG_DIR.mkdir(parents=True, exist_ok=True)
for m in M:
    verdict, out, code, elapsed = run(m)
    fails = sorted({line.split()[2] for line in out.splitlines() if line.strip().startswith('--- FAIL')})
    print(f"{m.name}: {verdict} exit={code} elapsed={elapsed:.0f}s fails={fails[:6]} :: {m.note}", flush=True)
    (LOG_DIR / f"{m.name}.log").write_text(f"# mutant={m.name} path={m.path} -run={m.run}\n# verdict={verdict} exit={code} elapsed={elapsed:.1f}s\n# find={m.find!r}\n# replace={m.replace!r}\n---\n{out}\n")
