package cloneproject

import "testing"

func TestReviewerProbeBodyNull(t *testing.T) {
	for _, r := range []struct{ name, line string }{
		{"PR16_unknown_type_body_null", `{"v":1,"native_event_id":"evt-n1","native_type":"frobnicate","origin":"native","protection":"none","actor":"main","body":null}`},
		{"PR16_known_type_body_null", `{"v":1,"native_event_id":"evt-n2","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":null}`},
		{"PR16_known_type_body_string", `{"v":1,"native_event_id":"evt-n3","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":"x"}`},
		{"PR16_unknown_type_body_string", `{"v":1,"native_event_id":"evt-n4","native_type":"frobnicate","origin":"native","protection":"none","actor":"main","body":"x"}`},
		{"PR16_native_type_null", `{"v":1,"native_event_id":"evt-n5","native_type":null,"origin":"native","protection":"none","actor":"main","body":{}}`},
		{"PR16_native_event_id_null", `{"v":1,"native_event_id":null,"native_type":"frobnicate","origin":"native","protection":"none","actor":"main","body":{}}`},
		{"PR16_actor_null", `{"v":1,"native_event_id":"evt-n6","native_type":"frobnicate","origin":"native","protection":"none","actor":null,"body":{}}`},
		{"PR16_v_null", `{"v":null,"native_event_id":"evt-n7","native_type":"frobnicate","origin":"native","protection":"none","actor":"main","body":{}}`},
		{"PR16_crlf_line", "{\"v\":1,\"native_event_id\":\"evt-n8\",\"native_type\":\"frobnicate\",\"origin\":\"native\",\"protection\":\"none\",\"actor\":\"main\",\"body\":{}}\r"},
	} {
		o := probeLines(t, nil, r.line)
		t.Logf("%s => %s", r.name, o)
	}
}
