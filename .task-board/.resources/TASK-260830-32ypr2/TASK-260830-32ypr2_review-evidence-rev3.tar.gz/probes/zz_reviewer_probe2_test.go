package cloneproject

import (
	"strings"
	"testing"
)

// PR1: raw references of records past line 1 resolve to their own bytes.
func TestReviewerProbeMultiRecordRefsResolve(t *testing.T) {
	l1 := rec("evt-m1", "message/user", "native", "none", "main", `{"text":"héllo"}`)
	l2 := rec("evt-m2", "frobnicate", "native", "none", "main", `{"anything":[1,2,3]}`)
	l3 := rec("evt-m3", "reasoning/encrypted", "foreign", "encrypted", "main", `{"ciphertext":"ZZ"}`)
	bundle := projectMembers(t, []fixtureMember{
		{key: "store/session.jsonl", class: "durable_payload", content: jsonl(l1, l2, l3)},
	})
	want := map[string]string{"evt-m1": l1, "evt-m2": l2, "evt-m3": l3}
	wantOffset := map[string]uint64{"evt-m1": 0, "evt-m2": uint64(len(l1) + 1), "evt-m3": uint64(len(l1) + len(l2) + 2)}
	for id, line := range want {
		ev := eventByNativeID(t, bundle.result, id)
		if len(ev.Evidence.RawRefs) != 1 {
			t.Fatalf("%s: %d refs", id, len(ev.Evidence.RawRefs))
		}
		ref := ev.Evidence.RawRefs[0]
		got := mustResolveRef(t, bundle.capture, bundle.store, ref)
		t.Logf("%s offset=%d length=%d resolves_exact=%v", id, ref.Offset, ref.Length, string(got) == line)
		if string(got) != line {
			t.Errorf("FINDING PR1 %s: ref [%d:%d] resolved %q, want the record line", id, ref.Offset, ref.Length, got)
		}
		if ref.Offset != wantOffset[id] || ref.Length != uint64(len(line)) {
			t.Errorf("FINDING PR1 %s: offset/length = %d/%d, want %d/%d", id, ref.Offset, ref.Length, wantOffset[id], len(line))
		}
	}
	// second member sorts after the first; ordinals continue.
	if len(bundle.result.DecodedEvents) != 3 {
		t.Fatalf("events = %d", len(bundle.result.DecodedEvents))
	}
}

// PR2..PR5: value-shape sweep on body members (pristine behaviour record).
func TestReviewerProbeBodyValueShapes(t *testing.T) {
	type row struct{ name, line string }
	rows := []row{
		{"PR2_live_followup_null", rec("evt-r1", "tool/result", "native", "none", "main", `{"call_id":"c1","status":"ok","live_followup":null}`)},
		{"PR2_live_attestation_null", rec("evt-d1", "tool/definition", "native", "none", "main", `{"tool_name":"t","definition_digest":"` + fixtureDigest("d") + `","live_attestation":null}`)},
		{"PR2_live_attestation_string_true", rec("evt-d2", "tool/definition", "native", "none", "main", `{"tool_name":"t","definition_digest":"` + fixtureDigest("d") + `","live_attestation":"true"}`)},
		{"PR3_text_number", rec("evt-t1", "message/user", "native", "none", "main", `{"text":123}`)},
		{"PR3_text_object", rec("evt-t2", "message/user", "native", "none", "main", `{"text":{"a":1}}`)},
		{"PR3_ciphertext_number", rec("evt-t3", "reasoning/encrypted", "foreign", "encrypted", "main", `{"ciphertext":123}`)},
		{"PR3_ciphertext_null", rec("evt-t4", "reasoning/encrypted", "foreign", "encrypted", "main", `{"ciphertext":null}`)},
		{"PR3_call_id_number", rec("evt-t5", "tool/call", "native", "none", "main", `{"call_id":5,"tool_name":"x"}`)},
		{"PR3_authority_null", rec("evt-t6", "instruction/snapshot", "native", "none", "main", `{"authority":null,"directives":[]}`)},
		{"PR3_message_body_empty", rec("evt-t7", "message/user", "native", "none", "main", `{}`)},
		{"PR4_directive_empty_string", rec("evt-t8", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":[""]}`)},
		{"PR4_directive_null_element", rec("evt-t9", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":[null]}`)},
		{"PR4_directive_number_element", rec("evt-t10", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":[1]}`)},
		{"PR4_directives_1024", rec("evt-t11", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":["` + strings.Repeat(`d","`, 1023) + `d"]}`)},
		{"PR4_directive_4096", rec("evt-t12", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":["` + strings.Repeat("x", 4096) + `"]}`)},
		{"PR4_directive_4097", rec("evt-t13", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":["` + strings.Repeat("x", 4097) + `"]}`)},
		{"PR5_directive_lone_surrogate", rec("evt-t14", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":["\ud800"]}`)},
		{"PR5_unknown_body_lone_surrogate", rec("evt-t15", "frobnicate", "native", "none", "main", `{"x":"\ud800"}`)},
		{"PR5_unknown_body_nested_duplicate", rec("evt-t16", "frobnicate", "native", "none", "main", `{"x":{"a":1,"a":2}}`)},
		{"PR5_known_body_nested_duplicate_in_directives_obj", rec("evt-t17", "instruction/snapshot", "native", "none", "main", `{"authority":"low","directives":[{"a":1,"a":2}]}`)},
		{"PR7_summary_signed_native", rec("evt-t18", "reasoning/summary", "native", "signed", "main", `{"ciphertext":"S"}`)},
		{"PR9_unknown_foreign_unprotected", rec("evt-t19", "frobnicate", "foreign", "none", "main", `{"z":1}`)},
		{"PR10_native_type_512", rec("evt-t20", strings.Repeat("n", 512), "native", "none", "main", `{}`)},
		{"PR10_native_type_513", rec("evt-t21", strings.Repeat("n", 513), "native", "none", "main", `{}`)},
		{"PR10_native_event_id_512_multibyte", rec(strings.Repeat("é", 512), "message/user", "native", "none", "main", `{"text":"x"}`)},
		{"PR10_native_event_id_513_multibyte", rec(strings.Repeat("é", 513), "message/user", "native", "none", "main", `{"text":"x"}`)},
		{"PR11_subagent_name_128", rec("evt-t22", "message/user", "native", "none", "subagent:"+strings.Repeat("s", 128), `{"text":"x"}`)},
		{"PR12_actor_subagent_empty", rec("evt-t23", "message/user", "native", "none", "subagent:", `{"text":"x"}`)},
		{"PR12_actor_SUBAGENT_case", rec("evt-t24", "message/user", "native", "none", "Subagent:x", `{"text":"x"}`)},
		{"PR13_origin_case", rec("evt-t25", "message/user", "Native", "none", "main", `{"text":"x"}`)},
		{"PR13_protection_case", rec("evt-t26", "message/user", "native", "None", "main", `{"text":"x"}`)},
		{"PR13_native_type_case", rec("evt-t27", "Message/User", "native", "none", "main", `{"text":"x"}`)},
	}
	for _, r := range rows {
		r := r
		t.Run(r.name, func(t *testing.T) {
			actors := map[string]string(nil)
			if strings.Contains(r.line, `"subagent:`+strings.Repeat("s", 128)) {
				actors = map[string]string{"subagent:" + strings.Repeat("s", 128): fixtureSubActor}
			}
			o := probeLines(t, actors, r.line)
			t.Logf("%s => %s", r.name, o)
		})
	}
}

// PR6: the 64 KiB inline bound is measured in bytes.
func TestReviewerProbeInlineBoundBytes(t *testing.T) {
	for _, n := range []int{32768, 32769} { // 2-byte rune: 65536 and 65538 bytes
		text := strings.Repeat("é", n)
		bundle := projectMembers(t, []fixtureMember{
			{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("evt-b", "message/user", "native", "none", "main", `{"text":"`+text+`"}`))},
		})
		sealed := sealedPayload(t, bundle.result.Events[0])
		block := sealed["content_blocks"].([]any)[0].(map[string]any)
		_, inline := block["content"]
		_, ref := block["blob_descriptor_id"]
		t.Logf("runes=%d bytes=%d inline=%v blobref=%v overflows=%d", n, len(text), inline, ref, len(bundle.result.Overflows))
		if ref {
			got := mustResolveOverflow(t, bundle.sink, block["blob_descriptor_id"].(string))
			if string(got) != text {
				t.Errorf("FINDING PR6: overflow bytes differ")
			}
		}
	}
}

// PR13/14: actor UUID collisions through the request map.
func TestReviewerProbeActorCollisions(t *testing.T) {
	line := rec("evt-c1", "message/user", "native", "none", "subagent:x", `{"text":"x"}`)
	o := probeLines(t, map[string]string{"subagent:x": fixtureMainActor}, line)
	t.Logf("PR13 subagent mapped to the main UUID => %s", o)
	if o.admitted {
		t.Errorf("FINDING PR13: a subagent selector mapped to the main actor UUID was admitted")
	}
	l2 := rec("evt-c2", "message/user", "native", "none", "external", `{"text":"y"}`)
	o = probeLines(t, map[string]string{"subagent:x": fixtureSubActor, "external": fixtureSubActor}, line, l2)
	t.Logf("PR14 two selectors mapped to one UUID => %s", o)
	if o.admitted {
		t.Errorf("FINDING PR14: two selectors sharing one actor UUID were admitted")
	}
}

// PR15: title bounds pass through to the builder.
func TestReviewerProbeTitleBounds(t *testing.T) {
	for _, title := range []string{"", strings.Repeat("t", 4096), strings.Repeat("t", 4097)} {
		title := title
		capture, store := captureMembers(t, []fixtureMember{
			{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("evt-ti", "message/user", "native", "none", "main", `{"text":"x"}`))},
		})
		req := normalizeRequest(t, capture, store, openTestStore(t))
		req.Title = &title
		_, err := Normalize(req)
		t.Logf("PR15 title len=%d err=%v", len(title), err)
	}
}
