#!/usr/bin/env python3
"""Reviewer plant runner: apply one find/replace to a production file in the
plant copy, run the named go test selection, record exit + FAIL lines, restore."""
import subprocess, sys, json, pathlib, shutil, time
S = pathlib.Path(__file__).resolve().parent
PLANT = S / "plant"
LOGS = S / "mutants"
LOGS.mkdir(exist_ok=True)

def run_row(name, path, find, replace, count, run, pkg="./internal/cloneproject/", label="narrowing", expect="KILLED"):
    target = PLANT / path
    original = target.read_bytes()
    text = original.decode()
    if text.count(find) != count:
        verdict = "NOT_APPLIED"
        log = f"# {name}\n# path={path}\n# label={label}\n# find count={text.count(find)} want {count}\nverdict={verdict}\n"
        (LOGS / f"{name}.log").write_text(log)
        print(f"{name:40s} {verdict}")
        return verdict
    mutated = text.replace(find, replace)
    target.write_text(mutated)
    try:
        started = time.time()
        proc = subprocess.run(["go", "test", pkg, "-count=1", "-run", run],
                              cwd=PLANT, capture_output=True, text=True, timeout=900)
        elapsed = time.time() - started
        out = proc.stdout + proc.stderr
        fails = [l for l in out.splitlines() if l.startswith("--- FAIL") or l.startswith("    --- FAIL") or l.startswith("FAIL")]
        builds = [l for l in out.splitlines() if "build failed" in l or "[build failed]" in l or ": undefined" in l or "syntax error" in l]
        if proc.returncode == 0:
            verdict = "SURVIVED"
        elif builds:
            verdict = "COMPILE_FAIL"
        elif fails:
            verdict = "KILLED"
        else:
            verdict = "ERROR"
    finally:
        target.write_bytes(original)
        assert target.read_bytes() == original
    log = f"# {name}\n# path={path}\n# label={label}\n# expect={expect}\n# run={run}\n# pkg={pkg}\n# elapsed={elapsed:.1f}s\n# subprocess exit={proc.returncode}\n# verdict={verdict}\n--- find ---\n{find}\n--- replace ---\n{replace}\n--- output ---\n{out}\n"
    (LOGS / f"{name}.log").write_text(log)
    print(f"{name:40s} {verdict:12s} exit={proc.returncode} expect={expect} {'OK' if verdict==expect else 'MISMATCH'} fails={len(fails)} {elapsed:.0f}s")
    return verdict

if __name__ == "__main__":
    rows = json.loads(pathlib.Path(sys.argv[1]).read_text())
    only = set(sys.argv[2:])
    for r in rows:
        if only and r["name"] not in only:
            continue
        run_row(**r)
