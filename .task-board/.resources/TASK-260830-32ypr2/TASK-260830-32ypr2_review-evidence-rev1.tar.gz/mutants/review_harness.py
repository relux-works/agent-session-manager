#!/usr/bin/env python3
"""Reviewer narrowing battery for internal/cloneproject (RUN-260918-320878).

Reuses the producer's shipped harness runner (M/R/V, backup-restore,
per-plant logs) with a reviewer-authored row list targeting gates the
producer did not row. Run from the isolated candidate copy:

  PYTHONDONTWRITEBYTECODE=1 python3 review_harness.py CANDIDATE_ROOT --log-dir DIR [NAME ...]
"""
import importlib.util
import sys
from pathlib import Path

candidate = Path(sys.argv[1]).resolve()
spec = importlib.util.spec_from_file_location(
    "producer_harness", candidate / "internal/cloneproject/testdata/mutant_harness.py")
producer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(producer)
producer.REPO = candidate
Mutant = producer.Mutant
PACKAGE = producer.PACKAGE
SUITE = "TestNormalize"  # the whole committed behavioral suite

producer.MUTANTS = [
    Mutant(
        name="R1-actors-unsorted",
        path=f"{PACKAGE}/dispatch.go",
        find="\tsort.Strings(selectors)\n\tfor _, selector := range selectors {\n",
        replace="\t_ = sort.Strings\n\tfor _, selector := range selectors {\n",
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Unsorted array admitted: extra actors seal in Go map order; determinism is measured only for sessions with no extra actor.",
    ),
    Mutant(
        name="R2-reasoning-encrypted-admits-signed",
        path=f"{PACKAGE}/dispatch.go",
        find='\tcase nativeReasoningCrypt:\n\t\tif record.Protection != "encrypted" {\n',
        replace='\tcase nativeReasoningCrypt:\n\t\tif record.Protection != "encrypted" && record.Protection != "signed" {\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Member check dropped: reasoning/encrypted declared with protection signed is admitted (contradictory claim); no committed row drives the type/protection agreement arm.",
    ),
    Mutant(
        name="R3-directive-width-4097",
        path=f"{PACKAGE}/native.go",
        find="\t\tif environ.StringLength(directive) < 1 || environ.StringLength(directive) > 4096 {\n",
        replace="\t\tif environ.StringLength(directive) < 1 || environ.StringLength(directive) > 4097 {\n",
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Bound widened by one: a 4097-character directive is admitted; no committed row witnesses the directive width edge.",
    ),
    Mutant(
        name="R3b-call-id-width-513",
        path=f"{PACKAGE}/native.go",
        find='\tif environ.StringLength(callID) < 1 || environ.StringLength(callID) > 512 {\n\t\treturn toolCallBody{}, invalid("%s body call_id is not a string[1..512]", where)\n',
        replace='\tif environ.StringLength(callID) < 1 || environ.StringLength(callID) > 513 {\n\t\treturn toolCallBody{}, invalid("%s body call_id is not a string[1..512]", where)\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Bound widened by one: a 513-character call_id is admitted; the representative N-string-bound row pins only native_event_id.",
    ),
    Mutant(
        name="R4-trailing-bytes-admitted",
        path=f"{PACKAGE}/native.go",
        find='\tif decoder.More() {\n\t\treturn NativeRecord{}, invalid("%s carries trailing bytes", where())\n\t}\n',
        replace='\tif decoder.More() && !bytes.HasSuffix(raw, []byte("}x")) {\n\t\treturn NativeRecord{}, invalid("%s carries trailing bytes", where())\n\t}\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Member check narrowed: a record line followed by exactly one trailing x is admitted; the trailing-bytes refusal has no committed row.",
    ),
    Mutant(
        name="R5-protected-tools-folded",
        path=f"{PACKAGE}/normalize.go",
        find='\t\tif record.Protection != "none" && !isReasoningType(record.NativeType) {\n\t\t\tcontinue\n\t\t}\n',
        replace='\t\tif record.Protection != "none" && !isReasoningType(record.NativeType) && record.NativeType != nativeToolCall {\n\t\t\tcontinue\n\t\t}\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Member check dropped: a protected tool/call is folded as a call (its ciphertext body then refuses instead of projecting opaque_event); no committed row drives a protected tool record.",
    ),
    Mutant(
        name="R6-result-status-pending",
        path=f"{PACKAGE}/native.go",
        find='\tif status != "ok" && status != "error" {\n',
        replace='\tif status != "ok" && status != "error" && status != "pending" {\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Member check dropped: a tool/result with status pending is admitted and its call resolves completed; the status vocabulary gate has no committed row.",
    ),
    Mutant(
        name="R7-size-check-skipped",
        path=f"{PACKAGE}/normalize.go",
        find='\t\tif uint64(len(payload)) != entry.ByteCount {\n',
        replace='\t\tif uint64(len(payload)) != entry.ByteCount && item.NativeItemKey != "store/session.jsonl" {\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Revalidation narrowed: the blob size check is skipped for the fixture member; expected unmeasurable because the digest check (rowed) dominates every size drift.",
    ),
    Mutant(
        name="R8-body-decode-unknown-protected-skipped",
        path=f"{PACKAGE}/dispatch.go",
        find='\tif _, err := decodeProtectedBody(record); err != nil {\n\t\treturn err\n\t}\n',
        replace='\tif _, err := decodeProtectedBody(record); err != nil && knownNativeType(record.NativeType) {\n\t\treturn err\n\t}\n',
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Framing rule narrowed: an unknown-type protected record with a non-ciphertext body projects opaque_event instead of refusing; measures whether the refusal on unknown+protected bodies is pinned.",
    ),
    Mutant(
        name="RC-control-comment",
        path=f"{PACKAGE}/tools.go",
        find="// This file folds historical tools: call/result pairing, the\n",
        replace="// This file folds historical tools (control): call/result pairing, the\n",
        count=1,
        run=SUITE,
        expect="SURVIVED",
        note="Harmless control: comment-only edit must survive.",
    ),
]

if __name__ == "__main__":
    sys.exit(producer.main(sys.argv[2:]))
