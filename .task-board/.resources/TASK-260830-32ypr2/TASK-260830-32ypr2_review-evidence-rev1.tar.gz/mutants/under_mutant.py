#!/usr/bin/env python3
"""Apply one reviewer plant, run the matching under-mutant probe, restore."""
import importlib.util, shutil, subprocess, sys
from pathlib import Path
candidate = Path(sys.argv[1]).resolve()
logdir = Path(sys.argv[2]); logdir.mkdir(parents=True, exist_ok=True)
spec = importlib.util.spec_from_file_location("rh", Path(__file__).with_name("review_harness.py"))
# load review_harness with argv trick: it reads sys.argv[1] for candidate
saved = sys.argv; sys.argv = [saved[0], str(candidate)]
rh = importlib.util.module_from_spec(spec); spec.loader.exec_module(rh)
sys.argv = saved
probe_src = Path(__file__).resolve().parent.parent / "probes" / "zz_review_under_mutant_test.go"
probe_dst = candidate / "internal/cloneproject/zz_review_under_mutant_test.go"
PROBES = {
    "R1-actors-unsorted": "TestReviewUM1",
    "R2-reasoning-encrypted-admits-signed": "TestReviewUM2",
    "R3-directive-width-4097": "TestReviewUM3",
    "R3b-call-id-width-513": "TestReviewUM3",
    "R4-trailing-bytes-admitted": "TestReviewUM4",
    "R5-protected-tools-folded": "TestReviewUM5",
    "R6-result-status-pending": "TestReviewUM6",
    "R7-size-check-skipped": "TestReviewUM7",
    "R8-body-decode-unknown-protected-skipped": "TestReviewUM8",
}
for m in rh.producer.MUTANTS:
    if m.name not in PROBES:
        continue
    target = candidate / m.path
    original = target.read_text()
    assert original.count(m.find) == m.count, m.name
    try:
        target.write_text(original.replace(m.find, m.replace))
        shutil.copy2(probe_src, probe_dst)
        run = subprocess.run(["go", "test", "./internal/cloneproject/", "-run", PROBES[m.name], "-count=1", "-v"],
                             cwd=candidate, capture_output=True, text=True, timeout=300)
    finally:
        target.write_text(original)
        if probe_dst.exists():
            probe_dst.unlink()
    out = run.stdout + run.stderr
    (logdir / f"{m.name}.log").write_text(f"# plant={m.name} path={m.path} probe={PROBES[m.name]}\n# exit={run.returncode}\n---\n{out}")
    lines = [l.strip() for l in out.splitlines() if "zz_review" in l or l.startswith("--- FAIL") or l.startswith("ok") or l.startswith("FAIL")]
    print(f"== {m.name} (exit={run.returncode})")
    for l in lines:
        print("   ", l[:230])
