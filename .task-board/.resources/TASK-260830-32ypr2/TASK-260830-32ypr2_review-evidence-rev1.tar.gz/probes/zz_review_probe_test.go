package cloneproject

import (
	"strings"
	"testing"
)

// Reviewer probes (RUN-260918-320878). Each probe reports what the
// pristine candidate does; none asserts, so the log is the evidence.

func reviewProject(t *testing.T, lines ...string) (*NormalizeResult, error) {
	t.Helper()
	members := []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(lines...)}}
	capture, store := captureMembers(t, members)
	return Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
}

func TestReviewProbeLoneSurrogateText(t *testing.T) {
	for _, escape := range []string{`\ud800`, `\udc00`, `A\ud800B`, `\ud800\ud800`} {
		line := rec("evt-sur", "message/user", "native", "none", "main", `{"text":"`+escape+`"}`)
		result, err := reviewProject(t, line)
		if err != nil {
			t.Logf("PA[%s]: REFUSED: %v", escape, err)
			continue
		}
		ev := result.DecodedEvents[0]
		blocks := ev.Payload["content_blocks"].([]any)
		content := blocks[0].(map[string]any)["content"].(string)
		t.Logf("PA[%s]: ADMITTED kind=%s status=%s content=%q (bytes % x) sealed_contains_FFFD=%v",
			escape, ev.Kind, ev.Evidence.CaptureStatus, content, []byte(content),
			strings.Contains(string(result.Events[0]), "�"))
	}
}

func TestReviewProbeLoneSurrogateInEnvelopeAndOpaque(t *testing.T) {
	// native_event_id with a lone surrogate escape
	line := `{"v":1,"native_event_id":"evt-\ud800","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PB[native_event_id]: REFUSED: %v", err)
	} else {
		t.Logf("PB[native_event_id]: ADMITTED evidence native_event_id=%q", *result.DecodedEvents[0].Evidence.NativeEventID)
	}
	// unknown type with lone surrogate body: opaque keeps raw bytes; only payload native_type matters
	line2 := `{"v":1,"native_event_id":"evt-2","native_type":"frob\ud800","origin":"native","protection":"none","actor":"main","body":{"x":"y"}}`
	result, err = reviewProject(t, line2)
	if err != nil {
		t.Logf("PB[native_type]: REFUSED: %v", err)
	} else {
		t.Logf("PB[native_type]: ADMITTED kind=%s native_type=%q", result.DecodedEvents[0].Kind, *result.DecodedEvents[0].Evidence.NativeType)
	}
}

func TestReviewProbeDuplicateMembers(t *testing.T) {
	// duplicate body member: text A then text B
	line := rec("evt-dup-body", "message/user", "native", "none", "main", `{"text":"A","text":"B"}`)
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PC[dup body text]: REFUSED: %v", err)
	} else {
		blocks := result.DecodedEvents[0].Payload["content_blocks"].([]any)
		t.Logf("PC[dup body text]: ADMITTED content=%q status=%s", blocks[0].(map[string]any)["content"], result.DecodedEvents[0].Evidence.CaptureStatus)
	}
	// duplicate envelope native_type: unknown first, known second
	line2 := `{"v":1,"native_event_id":"evt-dup-env","native_type":"frobnicate","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`
	result, err = reviewProject(t, line2)
	if err != nil {
		t.Logf("PC[dup envelope native_type]: REFUSED: %v", err)
	} else {
		t.Logf("PC[dup envelope native_type]: ADMITTED kind=%s native_type=%q", result.DecodedEvents[0].Kind, *result.DecodedEvents[0].Evidence.NativeType)
	}
	// duplicate protection: encrypted first, none second (last wins => semantic kind?)
	line3 := `{"v":1,"native_event_id":"evt-dup-prot","native_type":"reasoning/summary","origin":"foreign","protection":"encrypted","protection":"none","actor":"main","body":{"text":"secret"}}`
	result, err = reviewProject(t, line3)
	if err != nil {
		t.Logf("PC[dup protection]: REFUSED: %v", err)
	} else {
		t.Logf("PC[dup protection]: ADMITTED kind=%s visibility=%s", result.DecodedEvents[0].Kind, result.DecodedEvents[0].Visibility)
	}
	// duplicate origin: foreign then native for an instruction
	line4 := `{"v":1,"native_event_id":"evt-dup-origin","native_type":"instruction/snapshot","origin":"foreign","origin":"native","protection":"none","actor":"main","body":{"authority":"high","directives":["DROP"]}}`
	result, err = reviewProject(t, line4)
	if err != nil {
		t.Logf("PC[dup origin]: REFUSED: %v", err)
	} else {
		t.Logf("PC[dup origin]: ADMITTED effective=%+v payload authority=%v", result.Instruction, result.DecodedEvents[0].Payload["authority"])
	}
}

func TestReviewProbeUsageStringNumber(t *testing.T) {
	line := rec("evt-use-str", "usage/report", "native", "none", "main", `{"input_tokens":"5","output_tokens":0}`)
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PD[string usage]: REFUSED: %v", err)
	} else {
		t.Logf("PD[string usage]: ADMITTED ledger=%+v payload=%v", result.Usage, result.DecodedEvents[0].Payload)
	}
	line = `{"v":"1","native_event_id":"evt-vstr","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`
	_, err = reviewProject(t, line)
	t.Logf("PD[string v]: err=%v", err)
}

func TestReviewProbeUnknownProtectedNonCiphertextBody(t *testing.T) {
	line := rec("evt-unk-prot", "frobnicate", "foreign", "encrypted", "main", `{"mystery":true}`)
	_, err := reviewProject(t, line)
	t.Logf("PE[unknown+protected non-ciphertext body]: err=%v", err)
	line = rec("evt-unk-prot2", "frobnicate", "foreign", "encrypted", "main", `"just-a-string"`)
	_, err = reviewProject(t, line)
	t.Logf("PE[unknown+protected string body]: err=%v", err)
	// wholly unknown unprotected with non-object body
	line = rec("evt-unk3", "frobnicate", "native", "none", "main", `"just-a-string"`)
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PE[unknown unprotected string body]: REFUSED %v", err)
	} else {
		t.Logf("PE[unknown unprotected string body]: ADMITTED kind=%s", result.DecodedEvents[0].Kind)
	}
}

func TestReviewProbeDirectivesNullAndCRLF(t *testing.T) {
	line := rec("evt-dir-null", "instruction/snapshot", "native", "none", "main", `{"authority":"high","directives":null}`)
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PF[directives null]: REFUSED %v", err)
	} else {
		t.Logf("PF[directives null]: ADMITTED effective=%+v", result.Instruction)
	}
	members := []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: []byte(rec("evt-crlf", "message/user", "native", "none", "main", `{"text":"x"}`) + "\r\n")}}
	capture, store := captureMembers(t, members)
	result, err = Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
	if err != nil {
		t.Logf("PF[CRLF]: REFUSED %v", err)
	} else {
		ref := result.DecodedEvents[0].Evidence.RawRefs[0]
		t.Logf("PF[CRLF]: ADMITTED range=[%d,%d) resolved=%q", ref.Offset, ref.Offset+ref.Length, mustResolveRef(t, capture, store, ref))
	}
}

func TestReviewProbeMultibyteInlineBound(t *testing.T) {
	// 21846 x 3-byte char = 65538 bytes, 21846 chars
	text := strings.Repeat("€", 21846)
	line := rec("evt-mb", "message/user", "native", "none", "main", `{"text":"`+text+`"}`)
	result, err := reviewProject(t, line)
	if err != nil {
		t.Logf("PG[65538 bytes/21846 chars]: REFUSED %v", err)
	} else {
		blocks := result.DecodedEvents[0].Payload["content_blocks"].([]any)
		_, inline := blocks[0].(map[string]any)["content"]
		t.Logf("PG[65538 bytes/21846 chars]: ADMITTED inline=%v overflows=%d", inline, len(result.Overflows))
	}
	// exactly 65536 bytes via 2-byte chars: 32768 x é
	text = strings.Repeat("é", 32768)
	line = rec("evt-mb2", "message/user", "native", "none", "main", `{"text":"`+text+`"}`)
	result, err = reviewProject(t, line)
	if err != nil {
		t.Logf("PG[65536 bytes/32768 chars]: REFUSED %v", err)
	} else {
		blocks := result.DecodedEvents[0].Payload["content_blocks"].([]any)
		_, inline := blocks[0].(map[string]any)["content"]
		t.Logf("PG[65536 bytes/32768 chars]: ADMITTED inline=%v overflows=%d", inline, len(result.Overflows))
	}
}

func TestReviewProbeProtectedToolCallAndForeignReasoningSummary(t *testing.T) {
	// protected tool/call with an unprotected result: call is never folded -> result orphan aborted
	lines := []string{
		rec("evt-pc", "tool/call", "foreign", "encrypted", "main", `{"ciphertext":"x"}`),
		rec("evt-pr", "tool/result", "native", "none", "main", `{"call_id":"c1","status":"ok"}`),
	}
	result, err := reviewProject(t, lines...)
	if err != nil {
		t.Logf("PH[protected call]: REFUSED %v", err)
	} else {
		t.Logf("PH[protected call]: kinds=%s/%s resolutions=%+v live=%+v", result.DecodedEvents[0].Kind, result.DecodedEvents[1].Kind, result.ToolResolutions, result.Live)
	}
	// foreign unprotected reasoning summary
	line := rec("evt-frs", "reasoning/summary", "foreign", "none", "main", `{"text":"foreign thoughts"}`)
	result, err = reviewProject(t, line)
	if err != nil {
		t.Logf("PH[foreign reasoning/summary none]: REFUSED %v", err)
	} else {
		t.Logf("PH[foreign reasoning/summary none]: kind=%s vis=%s reasons=%v", result.DecodedEvents[0].Kind, result.DecodedEvents[0].Visibility, result.DecodedEvents[0].Evidence.ReasonCodes)
	}
	// foreign unprotected message
	line = rec("evt-fm", "message/user", "foreign", "none", "main", `{"text":"foreign msg"}`)
	result, err = reviewProject(t, line)
	if err != nil {
		t.Logf("PH[foreign message/user none]: REFUSED %v", err)
	} else {
		t.Logf("PH[foreign message/user none]: kind=%s vis=%s reasons=%v", result.DecodedEvents[0].Kind, result.DecodedEvents[0].Visibility, result.DecodedEvents[0].Evidence.ReasonCodes)
	}
}

func TestReviewProbeSidecarParsedAsJSONL(t *testing.T) {
	members := []fixtureMember{
		{key: "store/index.bin", class: "durable_index_required", content: []byte{0x00, 0x01, 0x02}},
		{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("evt-a", "message/user", "native", "none", "main", `{"text":"x"}`))},
	}
	capture, store := captureMembers(t, members)
	_, err := Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
	t.Logf("PI[binary durable_index_required member]: err=%v", err)
	members[0] = fixtureMember{key: "store/cache.bin", class: "derived_cache_optional", content: []byte("not json\n")}
	capture, store = captureMembers(t, members)
	_, err = Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
	t.Logf("PI[text derived_cache_optional member]: err=%v", err)
}
