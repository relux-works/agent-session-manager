package cloneproject

import (
	"bytes"
	"strings"
	"testing"
)

func umProject(t *testing.T, lines ...string) (*NormalizeResult, error) {
	t.Helper()
	members := []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(lines...)}}
	capture, store := captureMembers(t, members)
	return Normalize(normalizeRequest(t, capture, store, openTestStore(t)))
}

// UM1: two extra actors; project 12 times and count distinct sealed sessions.
func TestReviewUM1ActorOrderDeterminism(t *testing.T) {
	members := []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("e1", "message/user", "native", "none", "subagent:zeta", `{"text":"a"}`),
		rec("e2", "message/user", "native", "none", "external", `{"text":"b"}`),
		rec("e3", "message/user", "native", "none", "subagent:alpha", `{"text":"c"}`),
	)}}
	capture, store := captureMembers(t, members)
	distinct := map[string]int{}
	for i := 0; i < 12; i++ {
		request := normalizeRequest(t, capture, store, openTestStore(t))
		request.Actors = map[string]string{"subagent:zeta": fixtureSubActor, "external": fixtureExtActor, "subagent:alpha": "0198f4d1-9e60-7aaa-83ca-3456789abcde"}
		result, err := Normalize(request)
		if err != nil {
			t.Fatalf("Normalize() error = %v", err)
		}
		distinct[string(result.Session)]++
	}
	t.Logf("UM1: distinct sealed sessions over 12 projections = %d", len(distinct))
}

func TestReviewUM2ReasoningEncryptedSigned(t *testing.T) {
	result, err := umProject(t, rec("e", "reasoning/encrypted", "foreign", "signed", "main", `{"ciphertext":"x"}`))
	if err != nil {
		t.Logf("UM2: REFUSED %v", err)
		return
	}
	t.Logf("UM2: ADMITTED kind=%s reasons=%v", result.DecodedEvents[0].Kind, result.DecodedEvents[0].Evidence.ReasonCodes)
}

func TestReviewUM3DirectiveWidth(t *testing.T) {
	for _, n := range []int{4096, 4097} {
		result, err := umProject(t, rec("e", "instruction/snapshot", "native", "none", "main", `{"authority":"high","directives":["`+strings.Repeat("d", n)+`"]}`))
		if err != nil {
			t.Logf("UM3[%d]: REFUSED %v", n, err)
			continue
		}
		t.Logf("UM3[%d]: ADMITTED directives=%d", n, len(result.Instruction.Directives))
	}
	for _, n := range []int{512, 513} {
		result, err := umProject(t, rec("e", "tool/call", "native", "none", "main", `{"call_id":"`+strings.Repeat("c", n)+`","tool_name":"t"}`))
		if err != nil {
			t.Logf("UM3b[call_id %d]: REFUSED %v", n, err)
			continue
		}
		t.Logf("UM3b[call_id %d]: ADMITTED resolutions=%d", n, len(result.ToolResolutions))
	}
}

func TestReviewUM4TrailingBytes(t *testing.T) {
	line := rec("e", "message/user", "native", "none", "main", `{"text":"x"}`) + "x"
	result, err := umProject(t, line)
	if err != nil {
		t.Logf("UM4: REFUSED %v", err)
		return
	}
	ref := result.DecodedEvents[0].Evidence.RawRefs[0]
	t.Logf("UM4: ADMITTED kind=%s range=[%d,%d) line_len=%d", result.DecodedEvents[0].Kind, ref.Offset, ref.Offset+ref.Length, len(line))
}

func TestReviewUM5ProtectedToolCall(t *testing.T) {
	result, err := umProject(t,
		rec("pc", "tool/call", "foreign", "encrypted", "main", `{"ciphertext":"x"}`),
		rec("pr", "tool/result", "native", "none", "main", `{"call_id":"c1","status":"ok"}`))
	if err != nil {
		t.Logf("UM5: REFUSED %v", err)
		return
	}
	t.Logf("UM5: ADMITTED kinds=%s/%s resolutions=%+v", result.DecodedEvents[0].Kind, result.DecodedEvents[1].Kind, result.ToolResolutions)
}

func TestReviewUM6ResultStatusPending(t *testing.T) {
	result, err := umProject(t,
		rec("c", "tool/call", "native", "none", "main", `{"call_id":"c1","tool_name":"t"}`),
		rec("r", "tool/result", "native", "none", "main", `{"call_id":"c1","status":"pending"}`))
	if err != nil {
		t.Logf("UM6: REFUSED %v", err)
		return
	}
	t.Logf("UM6: ADMITTED resolutions=%+v result payload=%v live=%+v", result.ToolResolutions, result.DecodedEvents[1].Payload, result.Live)
}

func TestReviewUM8UnknownProtectedBody(t *testing.T) {
	result, err := umProject(t, rec("u", "frobnicate", "foreign", "encrypted", "main", `{"mystery":true}`))
	if err != nil {
		t.Logf("UM8: REFUSED %v", err)
		return
	}
	ev := result.DecodedEvents[0]
	resolved := mustResolveRefLoose(t, result, ev)
	t.Logf("UM8: ADMITTED kind=%s reasons=%v raw_ok=%v", ev.Kind, ev.Evidence.ReasonCodes, resolved)
}

func mustResolveRefLoose(t *testing.T, result *NormalizeResult, ev interface{ }) bool {
	_ = result
	_ = ev
	return true
}

func TestReviewUM7SizeCheck(t *testing.T) {
	members := []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("e", "message/user", "native", "none", "main", `{"text":"x"}`))}}
	capture, store := captureMembers(t, members)
	request := normalizeRequest(t, capture, store, openTestStore(t))
	healthy := request.Fetch
	request.Fetch = func(id string) ([]byte, error) {
		payload, err := healthy(id)
		if err != nil {
			return nil, err
		}
		return append(payload, '\n'), nil // one extra byte: size drifts, digest drifts
	}
	_, err := Normalize(request)
	t.Logf("UM7: extra-byte blob -> err=%v", err)
	_ = bytes.Equal
}
