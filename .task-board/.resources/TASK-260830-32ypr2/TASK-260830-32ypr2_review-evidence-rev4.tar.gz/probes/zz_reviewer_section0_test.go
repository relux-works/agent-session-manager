package cloneproject

// Reviewer probes (RUN-260918-d009f2, rev3). Never committed; driven
// on an isolated copy of candidate tree fc597b84. Every probe runs
// the real path: clonesnap.Capture then Normalize.

import (
	"fmt"
	"strings"
	"testing"
)

type probeOutcome struct {
	admitted bool
	err      string
	kind     string
	vis      string
	status   string
	nativeT  string
	nativeID string
	reasons  []string
	content  string
	instr    EffectiveInstruction
	actorID  string
}

func probeLines(t *testing.T, actors map[string]string, lines ...string) probeOutcome {
	t.Helper()
	capture, store := captureMembers(t, []fixtureMember{
		{key: "store/session.jsonl", class: "durable_payload", content: jsonl(lines...)},
	})
	req := normalizeRequest(t, capture, store, openTestStore(t))
	req.Actors = actors
	result, err := Normalize(req)
	if err != nil {
		return probeOutcome{admitted: false, err: err.Error()}
	}
	out := probeOutcome{admitted: true, instr: result.Instruction}
	if len(result.DecodedEvents) > 0 {
		ev := result.DecodedEvents[0]
		out.kind, out.vis, out.status = ev.Kind, ev.Visibility, ev.Evidence.CaptureStatus
		if ev.Evidence.NativeType != nil {
			out.nativeT = *ev.Evidence.NativeType
		}
		if ev.Evidence.NativeEventID != nil {
			out.nativeID = *ev.Evidence.NativeEventID
		}
		out.reasons = ev.Evidence.ReasonCodes
		out.actorID = ev.ActorID.String()
		sealed := sealedPayload(t, result.Events[0])
		if blocks, ok := sealed["content_blocks"].([]any); ok && len(blocks) == 1 {
			if block, ok := blocks[0].(map[string]any); ok {
				if c, ok := block["content"].(string); ok {
					out.content = c
				}
			}
		}
	}
	return out
}

func (o probeOutcome) String() string {
	if !o.admitted {
		return "REFUSED: " + o.err
	}
	return fmt.Sprintf("ADMITTED kind=%s vis=%s status=%s native_type=%q native_event_id=%q reasons=%v content=%q instr=%+v actor=%s",
		o.kind, o.vis, o.status, o.nativeT, o.nativeID, o.reasons, o.content, o.instr, o.actorID)
}

func TestReviewerProbeSection0(t *testing.T) {
	type row struct {
		name   string
		line   string
		actors map[string]string
		want   func(o probeOutcome) string // "" = ok, else failure text
	}
	rows := []row{
		{"PA1_kind_alias_after", `{"v":1,"native_event_id":"evt-a1","native_type":"frobnicate","NATIVE_TYPE":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "opaque_event" || o.vis != "opaque" || o.nativeT != "frobnicate" {
					return "want opaque_event/opaque/frobnicate"
				}
				return ""
			}},
		{"PA2_kind_alias_before", `{"v":1,"NATIVE_TYPE":"message/user","native_event_id":"evt-a2","native_type":"frobnicate","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "opaque_event" || o.nativeT != "frobnicate" {
					return "want opaque_event/frobnicate"
				}
				return ""
			}},
		{"PA3_origin_alias", `{"v":1,"native_event_id":"evt-a3","native_type":"instruction/snapshot","origin":"foreign","Origin":"native","protection":"none","actor":"main","body":{"authority":"high","directives":["DROP-EVERYTHING"]}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.instr.Found {
					return "want admitted with Instruction.Found=false"
				}
				return ""
			}},
		{"PA4_body_alias", `{"v":1,"native_event_id":"evt-a4","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"declared"},"Body":{"text":"smuggled"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.content != "declared" {
					return "want content declared"
				}
				return ""
			}},
		{"PA5_evidence_alias", `{"v":1,"native_event_id":"evt-a5","Native_Event_Id":"evt-forged","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.nativeID != "evt-a5" {
					return "want native_event_id evt-a5"
				}
				return ""
			}},
		{"PA6_protection_alias", `{"v":1,"native_event_id":"evt-a6","native_type":"reasoning/summary","origin":"foreign","protection":"encrypted","Protection":"none","actor":"main","body":{"text":"secret-plaintext"}}`, nil,
			func(o probeOutcome) string {
				if o.admitted {
					return "want refusal (encrypted summary with plaintext body)"
				}
				return ""
			}},
		{"PA7_actor_alias", `{"v":1,"native_event_id":"evt-a7","native_type":"message/user","origin":"native","protection":"none","actor":"subagent:ghost","Actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if o.admitted {
					return "want refusal (subagent:ghost unmapped)"
				}
				return ""
			}},
		{"PA8_control_extra", `{"v":1,"native_event_id":"evt-a8","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"},"extra":true}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "user_message" {
					return "want admitted user_message"
				}
				return ""
			}},
		// Class, not spelling: different alias spellings on every claimed member at once.
		{"PC1_all_aliases_other_spelling", `{"v":1,"V":7,"native_event_id":"evt-c1","NATIVE_EVENT_ID":"forged","native_type":"frobnicate","Native_Type":"message/user","origin":"foreign","ORIGIN":"native","protection":"none","PROTECTION":"encrypted","actor":"main","ACTOR":"subagent:x","body":{"text":"declared"},"BODY":{"text":"smuggled"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "opaque_event" || o.nativeT != "frobnicate" || o.nativeID != "evt-c1" {
					return "want opaque_event frobnicate evt-c1"
				}
				return ""
			}},
		{"PC2_v_alias_admits_claimed_1", `{"v":1,"V":2,"native_event_id":"evt-c2","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted {
					return "want admitted (claimed v=1)"
				}
				return ""
			}},
		{"PC3_v_alias_refuses_claimed_2", `{"v":2,"V":1,"native_event_id":"evt-c3","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if o.admitted || !strings.Contains(o.err, "envelope version") {
					return "want refusal on claimed v=2"
				}
				return ""
			}},
		{"PC4_body_level_alias_refuses_text", rec("evt-c4", "message/user", "native", "none", "main", `{"text":"declared","TEXT":"smuggled"}`), nil,
			func(o probeOutcome) string {
				if o.admitted || !strings.Contains(o.err, `unknown member "TEXT"`) {
					return "want refusal unknown member TEXT"
				}
				return ""
			}},
		{"PC5_body_level_alias_refuses_authority", rec("evt-c5", "instruction/snapshot", "native", "none", "main", `{"authority":"low","Authority":"high","directives":["d"]}`), nil,
			func(o probeOutcome) string {
				if o.admitted || !strings.Contains(o.err, `unknown member "Authority"`) {
					return "want refusal unknown member Authority"
				}
				return ""
			}},
		{"PC6_escaped_key_duplicate_refuses", `{"v":1,"native_event_id":"evt-c6","native_type":"frobnicate","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if o.admitted || !strings.Contains(o.err, "duplicate member") {
					return "want refusal duplicate member"
				}
				return ""
			}},
		{"PC7_escaped_key_alone_is_claimed", `{"v":1,"native_event_id":"evt-c7","native_type":"message/user","origin":"native","protection":"none","actor":"main","body":{"text":"x"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "user_message" {
					return "want admitted user_message (escaped key is the same key)"
				}
				return ""
			}},
		{"PC8_protection_alias_on_encrypted_summary_ciphertext", `{"v":1,"native_event_id":"evt-c8","native_type":"reasoning/summary","origin":"foreign","protection":"encrypted","Protection":"none","actor":"main","body":{"ciphertext":"X"}}`, nil,
			func(o probeOutcome) string {
				if !o.admitted || o.kind != "opaque_reasoning" || o.vis != "opaque" {
					return "want opaque_reasoning/opaque"
				}
				return ""
			}},
		{"PC9_actor_alias_mapped_ghost", `{"v":1,"native_event_id":"evt-c9","native_type":"message/user","origin":"native","protection":"none","actor":"subagent:ghost","Actor":"main","body":{"text":"x"}}`, map[string]string{"subagent:ghost": fixtureSubActor},
			func(o probeOutcome) string {
				if !o.admitted || o.actorID != fixtureSubActor {
					return "want attributed to subagent:ghost UUID"
				}
				return ""
			}},
	}
	for _, r := range rows {
		r := r
		t.Run(r.name, func(t *testing.T) {
			o := probeLines(t, r.actors, r.line)
			t.Logf("%s => %s", r.name, o)
			if msg := r.want(o); msg != "" {
				t.Errorf("FINDING %s: %s; got %s", r.name, msg, o)
			}
		})
	}
}
