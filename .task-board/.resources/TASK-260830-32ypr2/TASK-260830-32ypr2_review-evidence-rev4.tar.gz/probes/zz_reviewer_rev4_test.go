package cloneproject

// Reviewer probes for revision 4 (RUN-260918-492d65). Never committed;
// driven on an isolated copy of candidate tree 6c670903. Every probe
// runs the real path: clonesnap.Capture then Normalize.

import (
	"bytes"
	"strings"
	"testing"
)

func probeProject(t *testing.T, members []fixtureMember) (projectionBundle, error) {
	t.Helper()
	capture, store := captureMembers(t, members)
	sink := openTestStore(t)
	result, err := Normalize(normalizeRequest(t, capture, store, sink))
	if err != nil {
		return projectionBundle{}, err
	}
	return projectionBundle{capture: capture, store: store, sink: sink, members: members, result: result}, nil
}

// PR4-1: CRLF-terminated records. Either every record refuses (framing) or
// every record admits with its byte range covering the exact line bytes
// (including the CR) and resolving back to them.
func TestReviewerRev4CRLF(t *testing.T) {
	l1 := rec("evt-crlf-1", "message/user", "native", "none", "main", `{"text":"one"}`)
	l2 := rec("evt-crlf-2", "frobnicate", "native", "none", "main", `{"x":1}`)
	content := []byte(l1 + "\r\n" + l2 + "\r\n")
	bundle, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: content}})
	if err != nil {
		t.Logf("PR4-1 CRLF: REFUSED: %v", err)
		return
	}
	for i, ev := range bundle.result.DecodedEvents {
		ref := ev.Evidence.RawRefs[0]
		got := mustResolveRef(t, bundle.capture, bundle.store, ref)
		t.Logf("PR4-1 CRLF: ADMITTED event %d kind=%s offset=%d length=%d resolvedEndsWithCR=%v resolved=%q", i, ev.Kind, ref.Offset, ref.Length, bytes.HasSuffix(got, []byte("\r")), string(got))
	}
	if len(bundle.result.DecodedEvents) != 2 {
		t.Fatalf("want 2 events, got %d", len(bundle.result.DecodedEvents))
	}
}

// PR4-2: unterminated last record (no trailing newline): is it admitted,
// and do the offsets/bytes resolve?
func TestReviewerRev4UnterminatedLastRecord(t *testing.T) {
	l1 := rec("evt-un-1", "message/user", "native", "none", "main", `{"text":"héllo"}`)
	l2 := rec("evt-un-2", "frobnicate", "native", "none", "main", `{"x":1}`)
	content := []byte(l1 + "\n" + l2) // no trailing newline
	bundle, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: content}})
	if err != nil {
		t.Logf("PR4-2 unterminated: REFUSED: %v", err)
		return
	}
	t.Logf("PR4-2 unterminated: ADMITTED %d events", len(bundle.result.DecodedEvents))
	want := []struct {
		id     string
		line   string
		offset uint64
	}{{"evt-un-1", l1, 0}, {"evt-un-2", l2, uint64(len(l1)) + 1}}
	for _, row := range want {
		ev := eventByNativeID(t, bundle.result, row.id)
		ref := ev.Evidence.RawRefs[0]
		got := mustResolveRef(t, bundle.capture, bundle.store, ref)
		t.Logf("PR4-2 %s kind=%s offset=%d (want %d) length=%d (want %d) resolvedEqual=%v", row.id, ev.Kind, ref.Offset, row.offset, ref.Length, len(row.line), string(got) == row.line)
		if ref.Offset != row.offset || ref.Length != uint64(len(row.line)) || string(got) != row.line {
			t.Errorf("PR4-2 %s: ref does not resolve to its own line", row.id)
		}
	}
}

// PR4-3: two JSONL members plus an unknown-class member in one projection:
// every event's reference resolves to its own line inside its own member
// (descriptor per member), and a second projection is byte-identical.
func TestReviewerRev4MultiMemberRefs(t *testing.T) {
	a1 := rec("evt-a-1", "message/user", "native", "none", "main", `{"text":"alpha ünï"}`)
	a2 := rec("evt-a-2", "tool/call", "native", "none", "main", `{"call_id":"c1","tool_name":"write"}`)
	b1 := rec("evt-b-1", "reasoning/signed", "foreign", "signed", "main", `{"ciphertext":"SIG"}`)
	b2 := rec("evt-b-2", "wholly/unknown", "foreign", "none", "main", `{"deep":{"x":[1,2]}}`)
	b3 := rec("evt-b-3", "tool/result", "native", "none", "main", `{"call_id":"c1","status":"ok"}`)
	members := []fixtureMember{
		{key: "store/aaa.jsonl", class: "durable_payload", content: jsonl(a1, a2)},
		{key: "store/mystery", class: "unknown", content: []byte("mystery-bytes\n\x00\xff")},
		{key: "store/zzz.jsonl", class: "durable_payload", content: jsonl(b1, b2, b3)},
	}
	bundle, err := probeProject(t, members)
	if err != nil {
		t.Fatalf("PR4-3 REFUSED: %v", err)
	}
	if len(bundle.result.DecodedEvents) != 6 {
		t.Fatalf("want 6 events, got %d", len(bundle.result.DecodedEvents))
	}
	rows := []struct {
		id, line, kind string
		offset         uint64
	}{
		{"evt-a-1", a1, "user_message", 0},
		{"evt-a-2", a2, "tool_call", uint64(len(a1)) + 1},
		{"evt-b-1", b1, "opaque_reasoning", 0},
		{"evt-b-2", b2, "opaque_event", uint64(len(b1)) + 1},
		{"evt-b-3", b3, "tool_result", uint64(len(b1)) + uint64(len(b2)) + 2},
	}
	descriptors := map[string]string{}
	for _, row := range rows {
		ev := eventByNativeID(t, bundle.result, row.id)
		ref := ev.Evidence.RawRefs[0]
		got := mustResolveRef(t, bundle.capture, bundle.store, ref)
		descriptors[row.id] = ref.BlobDescriptorID.String()
		t.Logf("PR4-3 %s kind=%s offset=%d length=%d descriptor=%s… resolvedEqual=%v", row.id, ev.Kind, ref.Offset, ref.Length, ref.BlobDescriptorID.String()[:20], string(got) == row.line)
		if ev.Kind != row.kind || ref.Offset != row.offset || ref.Length != uint64(len(row.line)) || string(got) != row.line {
			t.Errorf("PR4-3 %s: kind=%s offset=%d length=%d; want %s/%d/%d", row.id, ev.Kind, ref.Offset, ref.Length, row.kind, row.offset, len(row.line))
		}
	}
	if descriptors["evt-a-1"] == descriptors["evt-b-1"] {
		t.Errorf("PR4-3 members share a descriptor")
	}
	// whole-member opaque unit
	var opaque *int
	for i, ev := range bundle.result.DecodedEvents {
		if ev.Evidence.NativeEventID == nil {
			i := i
			opaque = &i
		}
	}
	if opaque == nil {
		t.Fatal("PR4-3 no whole-member opaque event")
	}
	ev := bundle.result.DecodedEvents[*opaque]
	ref := ev.Evidence.RawRefs[0]
	got := mustResolveRef(t, bundle.capture, bundle.store, ref)
	t.Logf("PR4-3 whole-member kind=%s vis=%s offset=%d length=%d resolvedEqual=%v reasons=%v", ev.Kind, ev.Visibility, ref.Offset, ref.Length, bytes.Equal(got, members[1].content), ev.Evidence.ReasonCodes)
	if ev.Kind != "opaque_event" || ref.Offset != 0 || !bytes.Equal(got, members[1].content) {
		t.Errorf("PR4-3 whole-member unit wrong")
	}
	// tool fold: c1 completed
	for _, r := range bundle.result.ToolResolutions {
		t.Logf("PR4-3 resolution call=%s status=%s result=%s", r.CallID, r.Status, r.ResultStatus)
	}
	if len(bundle.result.Live.PendingActions) != 0 || len(bundle.result.Live.CallableTools) != 0 {
		t.Errorf("PR4-3 live surface not empty")
	}
	// second projection byte-identical
	sink2 := openTestStore(t)
	result2, err := Normalize(normalizeRequest(t, bundle.capture, bundle.store, sink2))
	if err != nil {
		t.Fatalf("second Normalize: %v", err)
	}
	if !bytes.Equal(result2.Session, bundle.result.Session) || len(result2.Events) != len(bundle.result.Events) {
		t.Errorf("PR4-3 second projection differs")
	}
	for i := range result2.Events {
		if !bytes.Equal(result2.Events[i], bundle.result.Events[i]) {
			t.Errorf("PR4-3 event %d differs on second projection", i)
		}
	}
	t.Logf("PR4-3 second projection byte-identical: session=%v events=%d", bytes.Equal(result2.Session, bundle.result.Session), len(result2.Events))
}

// PR4-4: a blank line in the middle refuses naming the line.
func TestReviewerRev4MidBlankLine(t *testing.T) {
	l1 := rec("evt-mb-1", "message/user", "native", "none", "main", `{"text":"one"}`)
	l2 := rec("evt-mb-2", "message/user", "native", "none", "main", `{"text":"two"}`)
	_, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: []byte(l1 + "\n\n" + l2 + "\n")}})
	t.Logf("PR4-4 mid blank line: err=%v", err)
	if err == nil || !strings.Contains(err.Error(), "line 2 is empty") {
		t.Errorf("PR4-4 want refusal naming line 2")
	}
}

// PR4-5: a whitespace-only line refuses (not an object), never an absent record.
func TestReviewerRev4WhitespaceLine(t *testing.T) {
	l1 := rec("evt-ws-1", "message/user", "native", "none", "main", `{"text":"one"}`)
	_, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: []byte(l1 + "\n \n")}})
	t.Logf("PR4-5 whitespace line: err=%v", err)
	if err == nil {
		t.Errorf("PR4-5 want refusal")
	}
}

// PR4-6: a record that is valid JSON but an array / scalar at the top.
func TestReviewerRev4NonObjectLine(t *testing.T) {
	l1 := rec("evt-no-1", "message/user", "native", "none", "main", `{"text":"one"}`)
	for _, bad := range []string{`[1,2]`, `"str"`, `42`, `null`} {
		_, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: []byte(l1 + "\n" + bad + "\n")}})
		t.Logf("PR4-6 top-level %s: err=%v", bad, err)
		if err == nil {
			t.Errorf("PR4-6 %s admitted", bad)
		}
	}
}

// PR4-7: body that is a non-object for a known type (array/string/number) refuses;
// body null for a KNOWN type refuses.
func TestReviewerRev4KnownTypeNonObjectBody(t *testing.T) {
	for _, body := range []string{`[]`, `"text"`, `7`, `null`, `true`} {
		_, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(rec("evt-kb", "message/user", "native", "none", "main", body))}})
		t.Logf("PR4-7 known-type body %s: err=%v", body, err)
		if err == nil {
			t.Errorf("PR4-7 body %s admitted for message/user", body)
		}
	}
}

// PR4-8: foreign tool/definition with live_attestation true refuses; foreign
// unprotected tool/call+result complete as history with no pending action;
// foreign usage counts into the SOURCE ledger only.
func TestReviewerRev4ForeignToolsAndUsage(t *testing.T) {
	_, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-fd", "tool/definition", "foreign", "none", "main", `{"tool_name":"rm","definition_digest":"`+fixtureDigest("rm")+`","live_attestation":true}`),
	)}})
	t.Logf("PR4-8 foreign live_attestation: err=%v", err)
	if err == nil {
		t.Errorf("PR4-8 foreign live definition admitted")
	}
	bundle, err := probeProject(t, []fixtureMember{{key: "store/session.jsonl", class: "durable_payload", content: jsonl(
		rec("evt-fc", "tool/call", "foreign", "none", "main", `{"call_id":"fc1","tool_name":"rm"}`),
		rec("evt-fu", "usage/report", "foreign", "none", "main", `{"input_tokens":5,"output_tokens":7}`),
		rec("evt-fc2", "tool/call", "foreign", "none", "main", `{"call_id":"fc2","tool_name":"rm"}`),
		rec("evt-fr2", "tool/result", "foreign", "none", "main", `{"call_id":"fc2","status":"error"}`),
	)}})
	if err != nil {
		t.Fatalf("PR4-8 foreign tools REFUSED: %v", err)
	}
	for _, r := range bundle.result.ToolResolutions {
		t.Logf("PR4-8 resolution call=%s status=%s result=%s", r.CallID, r.Status, r.ResultStatus)
	}
	t.Logf("PR4-8 live=%+v usage=%+v", bundle.result.Live, bundle.result.Usage)
	if bundle.result.Usage.TargetInputTokens != 0 || bundle.result.Usage.TargetOutputTokens != 0 || bundle.result.Usage.SourceInputTokens != 5 {
		t.Errorf("PR4-8 usage ledger wrong")
	}
	if len(bundle.result.Live.PendingActions) != 0 || len(bundle.result.Live.CallableTools) != 0 {
		t.Errorf("PR4-8 live surface not empty")
	}
	ev := eventByNativeID(t, bundle.result, "evt-fc")
	if payloadText(t, ev, "resolution") != "aborted" || ev.Visibility != "internal" {
		t.Errorf("PR4-8 foreign incomplete call resolution=%s vis=%s", payloadText(t, ev, "resolution"), ev.Visibility)
	}
}
