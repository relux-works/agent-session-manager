package clonebundle

import (
	"fmt"
	"sort"
	"testing"
	"time"
)

func sortedDigests(prefix string, n int) []string {
	out := make([]string, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, fixtureDigest(fmt.Sprintf("%s-%d", prefix, i)))
	}
	sort.Strings(out)
	return out
}

func TestReviewerBoundsEdges(t *testing.T) {
	// parents 64 / 65
	for _, n := range []int{64, 65} {
		in := validEventInput("exact")
		in.Parents = sortedDigests("p", n)
		_, err := BuildCanonicalEvent(in)
		t.Logf("parents=%d build err=%v", n, err)
	}
	// heads 1024 / 1025 (heads must be within event_ids)
	for _, n := range []int{1024, 1025} {
		in := validSessionInput()
		ids := sortedDigests("e", n)
		in.EventIDs = ids
		in.HeadEventIDs = ids
		_, err := BuildCanonicalSession(in)
		t.Logf("heads=%d build err=%v", n, err)
	}
	// actors 1024 / 1025 build side
	for _, n := range []int{1024, 1025} {
		in := validSessionInput()
		actors := []ActorInput{{ActorID: fixtureActorMain, Kind: "main", Name: strptr("main")}}
		for i := 1; i < n; i++ {
			id := fmt.Sprintf("0198f4d1-9e60-7%03x-8%03x-%012x", i&0xfff, (i>>12)&0xfff, i)
			actors = append(actors, ActorInput{ActorID: id, Kind: "subagent", ParentActorID: strptr(fixtureActorMain)})
		}
		in.Actors = actors
		_, err := BuildCanonicalSession(in)
		t.Logf("actors=%d build err=%v", n, err)
	}
	// event_ids 1,000,000 / 1,000,001 build side
	for _, n := range []int{1000000, 1000001} {
		started := time.Now()
		in := validSessionInput()
		ids := make([]string, 0, n)
		for i := 0; i < n; i++ {
			ids = append(ids, fixtureDigest(fmt.Sprintf("ev-%d", i)))
		}
		in.EventIDs = ids
		in.HeadEventIDs = []string{ids[len(ids)-1]}
		sealed, err := BuildCanonicalSession(in)
		t.Logf("event_ids=%d build err=%v sealed=%d bytes in %s", n, err, len(sealed), time.Since(started))
		if err == nil {
			started = time.Now()
			_, err = DecodeCanonicalSession(sealed)
			t.Logf("event_ids=%d decode err=%v in %s", n, err, time.Since(started))
		}
	}
}
