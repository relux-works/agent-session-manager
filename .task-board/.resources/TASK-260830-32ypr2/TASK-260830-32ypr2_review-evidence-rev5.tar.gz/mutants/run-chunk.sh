#!/bin/zsh
# usage: run-chunk.sh RUN CHUNK   (RUN=run1|run2, CHUNK=A|B|C|D)
set -u
RUN=$1; CHUNK=$2
R=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-1cyj0q/worktree/.temp/TASK-260830-32ypr2/rev5-review
cd $R/battery-$CHUNK || exit 3
export PYTHONDONTWRITEBYTECODE=1
{
  echo "\$ PYTHONDONTWRITEBYTECODE=1 python3 internal/cloneproject/testdata/mutant_harness.py --log-dir $R/mutants/producer-$RUN $(cat $R/mutants/chunk-$CHUNK.txt)"
  python3 internal/cloneproject/testdata/mutant_harness.py --log-dir $R/mutants/producer-$RUN $(cat $R/mutants/chunk-$CHUNK.txt)
  echo "exit=$?"
} > $R/logs/producer-battery-$RUN-chunk$CHUNK.log 2>&1
tail -1 $R/logs/producer-battery-$RUN-chunk$CHUNK.log
