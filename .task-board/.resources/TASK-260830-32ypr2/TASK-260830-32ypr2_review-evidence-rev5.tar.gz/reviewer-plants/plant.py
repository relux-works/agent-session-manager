#!/usr/bin/env python3
"""Reviewer plant runner (rev5): apply one find/replace to a production file in
the immutable plant copy, run the named go test selection, record the
subprocess exit + FAIL lines to one raw log per plant, restore the file
byte-exact. Usage: plant.py PLANTS.json LOGDIR [NAME ...]"""
import subprocess, sys, json, pathlib, time
S = pathlib.Path(__file__).resolve().parent
PLANT = S.parent / "plant"

def run_row(logs, name, path, find, replace, count, run, pkg="./internal/cloneproject/", label="narrowing", expect="KILLED"):
    target = PLANT / path
    original = target.read_bytes()
    text = original.decode()
    if text.count(find) != count:
        verdict = "NOT_APPLIED"
        log = f"# {name}\n# path={path}\n# label={label}\n# find count={text.count(find)} want {count}\n# verdict={verdict}\n"
        (logs / f"{name}.log").write_text(log)
        print(f"{name:44s} {verdict}")
        return verdict
    mutated = text.replace(find, replace)
    target.write_text(mutated)
    try:
        started = time.time()
        proc = subprocess.run(["go", "test", pkg, "-count=1", "-run", run],
                              cwd=PLANT, capture_output=True, text=True, timeout=900)
        elapsed = time.time() - started
        out = proc.stdout + proc.stderr
        lines = out.splitlines()
        fails = [l for l in lines if l.lstrip().startswith("--- FAIL") or l.startswith("FAIL")]
        builds = [l for l in lines if "build failed" in l or "[build failed]" in l or ": undefined" in l or "syntax error" in l or "declared and not used" in l or "imported and not used" in l]
        if proc.returncode == 0:
            verdict = "SURVIVED"
        elif builds:
            verdict = "COMPILE_FAIL"
        elif fails:
            verdict = "KILLED"
        else:
            verdict = "ERROR"
    finally:
        target.write_bytes(original)
        assert target.read_bytes() == original
    log = (f"# {name}\n# path={path}\n# label={label}\n# expect={expect}\n# run={run}\n# pkg={pkg}\n"
           f"# elapsed={elapsed:.1f}s\n# subprocess exit={proc.returncode}\n# verdict={verdict}\n"
           f"--- find ---\n{find}\n--- replace ---\n{replace}\n--- output ---\n{out}\n")
    (logs / f"{name}.log").write_text(log)
    print(f"{name:44s} {verdict:12s} exit={proc.returncode} expect={expect} {'OK' if verdict==expect else 'MISMATCH'} fails={len(fails)} {elapsed:.0f}s")
    return verdict

if __name__ == "__main__":
    rows = json.loads(pathlib.Path(sys.argv[1]).read_text())
    logs = pathlib.Path(sys.argv[2]); logs.mkdir(parents=True, exist_ok=True)
    only = set(sys.argv[3:])
    for r in rows:
        if only and r["name"] not in only:
            continue
        run_row(logs, **r)
