package clonebundle

import (
	"errors"
	"strings"
	"testing"
)

// Reviewer rev5 string far-edge probe: production refuses exactly past
// the edge (title 4096/4097, actor name 512/513) even though no
// committed row feeds the far edge (RV5-title-4097-build and
// RV5-actor-name-513-build SURVIVED).
func TestReviewerRev5StringFarEdges(t *testing.T) {
	build := func(mutate func(*CanonicalSessionInput)) error {
		input := validSessionInput()
		mutate(&input)
		_, err := BuildCanonicalSession(input)
		return err
	}
	if err := build(func(in *CanonicalSessionInput) { in.Title = strptr(strings.Repeat("é", 4096)) }); err != nil {
		t.Fatalf("title 4096 chars: %v", err)
	}
	err := build(func(in *CanonicalSessionInput) { in.Title = strptr(strings.Repeat("é", 4097)) })
	if !errors.Is(err, ErrInvalid) || !strings.Contains(err.Error(), "string[1..4096]") {
		t.Fatalf("title 4097 chars: %v", err)
	}
	if err := build(func(in *CanonicalSessionInput) { in.Actors[0].Name = strptr(strings.Repeat("é", 512)) }); err != nil {
		t.Fatalf("name 512 chars: %v", err)
	}
	err = build(func(in *CanonicalSessionInput) { in.Actors[0].Name = strptr(strings.Repeat("é", 513)) })
	if !errors.Is(err, ErrInvalid) || !strings.Contains(err.Error(), "string[1..512]") {
		t.Fatalf("name 513 chars: %v", err)
	}
	t.Logf("PR5-7 ok: title 4096 admits / 4097 refuses; actor name 512 admits / 513 refuses (character measure)")
}
