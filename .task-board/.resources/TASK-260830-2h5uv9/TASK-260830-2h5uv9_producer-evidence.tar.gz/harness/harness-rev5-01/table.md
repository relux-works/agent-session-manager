| Mutant | Narrowing | Named test | Exit | Result | Raw log |
| --- | --- | --- | ---: | --- | --- |
| control-neutral-comment | Equivalent comment-only edit; this applied control must survive. | TestDispatchServesNormativeChildrenBody | 0 | survived-control | `control-neutral-comment/test.log` |
| rule1-duplicate-set-member | Retains a second copy of one duplicate ID in the node set. | TestNodeRuleShapesAndDepth64IntegrityFailure | 1 | killed | `rule1-duplicate-set-member/test.log` |
| rule2-empty-root-count | Admits one phantom member into the empty-root count. | TestDispatchServesNormativeChildrenBody | 1 | killed | `rule2-empty-root-count/test.log` |
| rule3-root-singleton-leaf | Stops encoding a singleton as a leaf at the root prefix. | TestDispatchServesNormativeChildrenBody | 1 | killed | `rule3-root-singleton-leaf/test.log` |
| rule4-retain-single-child | Drops a required one-child node below the root. | TestRuleFourRetainsSingleChildAtEverySharedPrefix | 1 | killed | `rule4-retain-single-child/test.log` |
| rule5-depth64-duplicate | Admits two entries at a full 64-nibble prefix. | TestNodeRuleShapesAndDepth64IntegrityFailure | 1 | killed | `rule5-depth64-duplicate/test.log` |
| children-label-order | Reverses the specified ascending nibble-label order in the served branch body. | TestDispatchServesNormativeChildrenBody | 1 | killed | `children-label-order/test.log` |
| prefix-length-65 | Admits a 65-nibble prefix. | TestDispatchPrefixAxesAndNotFound | 1 | killed | `prefix-length-65/test.log` |
| uppercase-prefix | Admits uppercase A–F in a prefix. | TestDispatchPrefixAxesAndNotFound | 1 | killed | `uppercase-prefix/test.log` |
| missing-prefix-not-found | Returns an invented empty body for the valid missing prefix f. | TestDispatchPrefixAxesAndNotFound | 1 | killed | `missing-prefix-not-found/test.log` |
| children-prefix-type-null | Admits JSON null as the empty root prefix through encoding/json's string zero value. | TestDispatchRequestShapeStrictTypes | 1 | killed | `children-prefix-type-null/test.log` |
| server-casefold-prefix | Admits the miscased Prefix member at the server inventory.children entry. | TestDispatchRejectsEveryNonExactOperationBodyShape | 1 | killed | `server-casefold-prefix/test.log` |
| client-casefold-wireobject | Admits one case-folded WireObject member at the hostile client response entry. | TestFetchObjectsRejectsEveryNonExactSuccessWireShape | 1 | killed | `client-casefold-wireobject/test.log` |
| client-two-wireobjects | Accepts two WireObjects for the one-ID singleton FetchObjects request and silently returns only the first. | TestFetchObjectsRejectsNonObjectItemsAndWrongArrayCardinality | 1 | killed | `client-two-wireobjects/test.log` |
| client-fetch-cbor-label | Admits a cbor-labelled response object after the client requested json. | TestFetchObjectsRefusesCBORLabelAfterJSONRequest | 1 | killed | `client-fetch-cbor-label/test.log` |
| guard-aliased-json-unmarshal | Control plant: adds an aliased json.Unmarshal function value outside strictJSON; the AST guard must fail. | TestWireDecoderASTGuardRejectsAliasedUnmarshalBindings | 1 | killed | `guard-aliased-json-unmarshal/test.log` |
| emptychild2 | Returns an invented empty child only for a valid absent two-nibble prefix. | TestDispatchPrefixAxisCoversEveryLengthAndAlphabet | 1 | killed | `emptychild2/test.log` |
| crossns | Lets a stored record requested through manifest fall through to not_found instead of the cross-namespace refusal. | TestObjectsGetRefusesEveryForeignNamespacePair | 1 | killed | `crossns/test.log` |
| fetchns | Admits a hostile peer's valid record as a manifest object on the client fetch path. | TestFetchObjectsRefusesEveryHostileForeignNamespacePair | 1 | killed | `fetchns/test.log` |
| descriptor-namespace | Relabels Blob Descriptor schema membership from manifest to record. | TestBlobDescriptorOwnsManifestMembershipAndCompleteRawBlob | 1 | killed | `descriptor-namespace/test.log` |
| excluded-local-marker | Admits one machine-local terminal marker into the record root. | TestMixedNSN1RejectsDescriptorRelabelingChunksAndLocalMarker | 1 | killed | `excluded-local-marker/test.log` |
| mixed-ns1-root-member-narrowing | Omits the exact synthetic Tombstone Acknowledgement identity from its production namespace root. | TestMixedNS1RootsFromNormativeSyntheticIDs | 1 | killed | `mixed-ns1-root-member-narrowing/test.log` |
