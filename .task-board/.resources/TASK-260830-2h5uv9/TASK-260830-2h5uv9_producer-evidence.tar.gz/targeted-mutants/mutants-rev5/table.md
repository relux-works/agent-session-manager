| Mutant | Narrowing | Named test | Exit | Result | Raw log |
| --- | --- | --- | ---: | --- | --- |
| control-neutral-comment | Equivalent comment-only edit; this applied control must survive. | TestDispatchServesNormativeChildrenBody | 0 | survived-control | `control-neutral-comment/test.log` |
| sync-common-audit-first-namespace-only | Audits common bytes only in the first durable namespace, skipping a Session Record conflict in a later namespace. | TestDurableSyncConflictAuditsEveryCommonIDPositionWithPeerOnlyRecord | 1 | killed | `sync-common-audit-first-namespace-only/test.log` |
| sync-common-audit-even-ids-only | Audits only even-indexed common IDs; the generated middle target must still refuse the conflicting peer. | TestDurableSyncConflictAuditsEveryCommonIDPositionWithPeerOnlyRecord | 1 | killed | `sync-common-audit-even-ids-only/test.log` |
