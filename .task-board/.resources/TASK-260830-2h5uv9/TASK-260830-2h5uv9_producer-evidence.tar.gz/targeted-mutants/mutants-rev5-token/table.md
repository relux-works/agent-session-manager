| Mutant | Narrowing | Named test | Exit | Result | Raw log |
| --- | --- | --- | ---: | --- | --- |
| skip-census-token-preserving-behavior | Keeps each searched-for Skip method token but changes the AST check so a real planted skip is ignored. | TestSkipCensusRejectsAnUnjustifiedPlantedSkip | 1 | killed | `skip-census-token-preserving-behavior/test.log` |
