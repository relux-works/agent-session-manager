# TASK-260830-2h5uv9 axis inventory

Initial inventory was recorded before implementation edits. The generated domains below were reconciled to the actual property in `internal/merkleinventory/sync_property_test.go`. Refreshed candidate checkpoint: `86a6188a0e35fd04a24eba62a01b71a54d6faa5d`, descending from refreshed `origin/main` `6d3bff999f75ed8585a7ef32074ab108f364ec51`; the worktree includes the uncommitted Story checkpoints plus this leaf. Authority: pinned `internal/specdoc/SPEC.v0.7.0.md`, §11.4 and §5.3.

## Generated object universe

Each set is a size-N prefix of six schema-valid, identity-addressed JSON fixtures:

1. Session Record;
2. two epoch-1 Lease Records with competing UUIDv4 lease IDs;
3. an event on the lower lease's divergent branch;
4. a Tombstone;
5. its matching Tombstone Acknowledgement.

`N` ranges from 1 through 6. N=6 contains every required class. The newline-variant conflict branch uses the same immutable identity with different raw bytes, so it is a variant of one identity, not a seventh identity. The test oracle takes expected namespace and identity from fixture metadata; it does not call production `SyncFrom`, `Index.Root`, `ClassifyJSON`, or the production lease comparator.

The independent root oracle constructs the Merkle node JSON and hashes it with SHA-256. The independent projection oracle starts from the record-only empty authoritative event chain (`creating`), chooses the greatest `(epoch, bytewise lease_id)` tuple, and checks preservation of the losing branch. A size-N prefix without the Tombstone Acknowledgement has ordinary projection coverage; the complete N=6 set has the closed Tombstone/Acknowledgement pair. When the Tombstone is the delayed gap at N=6, the first sync must return literal `integrity_failure`; after the peer receives that Tombstone, a later production sync recovers the complete union.

## Perturbation axes

### Revision 4 correction recorded before implementation edits

The revision-3 review found that the old same-identity/different-bytes branch
was a fixed tail case, not a crossed product: its conflict peer contained only
the conflicting identity. That branch did not exercise a conflict while the
peer also held identities absent locally. Revision 4 adds conflict as a
generated product class. For each eligible generated object position, the
local replica keeps the original bytes, while a conflict-round peer presents
the newline variant at that same identity together with at least one distinct
identity absent locally. Every generated size N=2..6 covers every feasible
conflict-target × conflict-round pair (rounds 1, 2, 3); these pairs rotate
across every order, duplicate mode, gap choice, skew direction, and peer mask.
The gap axis remains a separate object withheld from both replicas until its
selected later fill. The test compares the peer's exact active bytes with both
exact candidates retained in local quarantine and requires literal
`integrity_failure` from `DurableIndex.SyncFrom`.

For a conflict position that is also the selected gap position, use another
position for the delayed gap so the conflicting identity exists locally before
the comparison. Product combinations requiring a distinct shared conflict ID,
a peer-only ID, and a delayed-gap ID need at least three fixture identities;
smaller sets remain in the valid-union product and the minimal two-identity
partial-overlap regression. This is a cardinality constraint of distinct
semantic identities, not a fixed-scenario substitute. Conflict targets rotate
through every generated object position and selected conflict rounds cross the
same order, duplicate, skew, gap, and peer-partition domains.

The structural audit is also checked before runtime tests: an AST test will
verify that the common-ID `fetchAndAdd` call in `DurableIndex.SyncFrom` is not
under a predicate that depends on `len(missing)`, `len(peerIDs)`, or namespace
position. Its harness will apply the reviewer's partial-overlap narrowing and
run the behavioral test as well as the AST check.

| Axis | Generated values | Bound / structural argument |
| --- | --- | --- |
| Set size | Every `N ∈ [1,6]`, using each prefix of the fixed six-class universe | Six is the finite object-count limit requested by the brief. No claim is made for larger unions. The complete N=6 fixture includes two competing leases, a losing-lease branch, Tombstone, and Acknowledgement. |
| Arrival reorder | Every permutation for `N ∈ [1,5]`; for N=6, identity, reverse, and 32 unique deterministic pseudorandom permutations | Each order is seeded into the peer; the reverse order is seeded into local. All N≤5 orders are exhaustive. N=6 is explicitly sampled as allowed by the brief. |
| Duplicate delivery | No replay; or one exact byte-for-byte replay for every seeded object | This crosses each generated order, skew, gap choice, and peer subset. Repeating an existing immutable identity cannot increase the set cardinality; the byte-snapshot checks exercise the actual durable insert/sync path. |
| Gap and later fill | No gap; or exactly one object position selected by `orderIndex mod N`, absent from both replicas until it is added to the peer before pass 2 | Across each generated size, the cyclic selector reaches every object position; every selector is crossed with both skew values, both duplicate modes, and every peer mask for that order. The N=6 Tombstone/Acknowledgement closure case is an explicit conflict on pass 1 and recovers after the Tombstone is filled on pass 2. |
| Clock skew | Lease A early / Lease B late; and Lease A late / Lease B early | The assignments reverse timestamp order while preserving the same `(epoch, lease_id)` order. Times are valid RFC3339 fixtures. The result oracle ignores timestamps, matching §5.3's diagnostic-only rule. This proves both directions, not every possible timestamp instant. |
| Partial peer | Every proper object-subset mask `[0,2^N-1)` with no gap; every subset of the non-gap identities when a gap is present | For no-gap cases, local is seeded with the complement. For gap cases, local and peer partition every non-gap identity. All masks are crossed with every order/profile; the local union never loses a preexisting identity. |
| Repeated sync | Three production `SyncFrom` passes; roots and projection-relevant object membership are checked after prefixes 1, 2, and 3 | The property executes one-, two-, and three-round prefixes of the same generated sequence. A gap is filled between prefixes 1 and 2. After the first complete reference match, later passes and one extra sync must preserve every durable file byte-for-byte. No behavior beyond three rounds is claimed. |
| Same identity / different bytes | No conflict; or a newline-variant encoding at each generated identity position and each feasible conflict round 1, 2, or 3 | Rework removes the old fixed-tail-only measurement. A conflict run combines a common identity with at least one distinct peer-only identity. Each target × round pair is crossed with arrival order, duplicate mode, gap fill, skew, and peer partition. `SyncFrom` must return literal `integrity_failure`; local quarantine must retain both byte variants and the peer's active object bytes must match its variant. `TestDurableSyncConflictWithPartialOverlapPeer` additionally reproduces the review case before and after a successful prior sync. `TestDurableSyncCommonIDAuditIsUnconditionalInAST` rejects enclosing conditions and earlier gated exits on `missing`, `peerIDs`, or namespace position. |

The valid-set product has 38,000 generated cases: 8 (N=1), 40 (N=2), 264 (N=3), 2,208 (N=4), 22,560 (N=5), and 12,920 (N=6). The conflict product has 37,765 generated cases, for 75,765 total. Gap pass-1 Tombstone closure refusals are expected only for N=6; all other valid paths reach the reference. A conflict is generated beside each eligible valid case, with target and conflict round varying independently and audited for every target × round pair at each size.

A separate adversarial entry test corrupts a peer's stored namespace label so an Event identity is returned as a Manifest. `TestDurableSyncRefusesPeerNamespaceMismatch` drives `DurableIndex.SyncFrom`, asserts literal `integrity_failure`, and proves every local root remains empty and no quarantine entry is created. This negative fixture is outside the valid generated product and is isolated by `sync-peer-namespace-mismatch`.

## Product and outcome rule

Every valid-set case is driven through `DurableIndex.SyncFrom`. The product crosses the supported order set, exact duplicate delivery mode, no-gap or selected later-filled gap, both lease timestamp assignments, and every compatible proper peer subset. Every case checks all six reference roots and the independent projection after convergence. Every round compares object membership before/after and checks roots against the independent oracle. Generated conflict-class cases additionally drive `DurableIndex.SyncFrom` with a common identity whose bytes differ and a distinct peer-only identity present in the same peer snapshot; the selected conflict round is 1, 2, or 3. They assert literal `integrity_failure`, both exact variants in quarantine, and matching peer bytes. An unclosed Tombstone/Acknowledgement link stops that sync and can recover when the missing Tombstone later arrives. Re-sync after convergence snapshots every file under the durable store root and requires byte-identical contents.

## Unbounded axes

The specification permits unbounded future union size and sync rounds; this task measures object sets through N=6 and prefixes through three rounds. `DurableIndex.SyncFrom` has no count-dependent branch: it iterates the fixed namespace list, computes common and missing identity sets, and applies every returned identity through the same immutable add path. The fetch batch limit changes only chunk boundaries. Adding another unrelated validated identity adds one loop member and one root leaf; the set size itself does not select a different convergence rule. The six-object fixture exercises the cross-object dependencies required here: competing lease tuples, a losing-lease event, and the Tombstone/Acknowledgement pair. More elaborate cross-object graphs or arbitrary payload families beyond those classes remain unmeasured.

For a fixed peer snapshot, each successful `SyncFrom` exhausts the current missing-ID set in that call. The generated schedule adds its sole delayed gap before pass 2; pass 3 and one extra sync have no new peer identity to add. Exact retries repeat the same bytes at immutable IDs, so after convergence there are no new durable writes. A common-ID mismatch is rechecked on every call and returns the same explicit conflict; the AST test also rejects gating that audit on `missing`, `peerIDs`, or namespace position. These structural arguments explain the tested result for later rounds against a stable peer. A peer that continues to grow after pass 3, unions larger than N=6, and untested object relationships are stated bounds, not measured claims.

## Stated bounds

- The six fixture identities and payloads are fixed representative schema-valid values. The tests vary arrival order, object-subset participation, timestamp direction, duplicate delivery, gap position, conflict target/round, and round prefix; they do not exhaust all valid JSON payload values or all possible UUIDs.
- N=6 arrival order is sampled, not exhaustive. For the remaining N=6 order space, no result is inferred beyond the 34 tested unique orders.
- The task brief supplied no surface table. Coverage reporting records that as a brief gap rather than treating the coverage-map precondition as waived.

## Revision 5 always-on shard plan (recorded before implementation edits)

The full N=1..6 product remains available under explicit nested selectors. With
no nested selector, `TestDurableSyncGeneratedPerturbationProduct` will run the
complete bounded valid-union product for N=1..3: every permutation, duplicate
mode, both timestamp skews, each gap position with later fill, every compatible
peer subset, and all three sync passes. This default path has no skip branch.

A second always-on generated conflict shard will use a three-identity shared
record set (one Session Record and the two competing Lease Records), so all
three common IDs are in one namespace. For each timestamp skew, permutation,
duplicate mode, target position in the production-sorted common-ID list
(first/middle/last), conflict round (1/2/3), and either peer-only Lease
identity, the target is withheld from the peer until its conflict round.
An earlier round therefore exercises an unresolved gap; adding the target's
different-byte variant fills that gap and must return `integrity_failure`.
Peer-only Lease identities remain absent locally at the conflict round, so the
reviewer's first-common narrowing is exercised against a partial peer in the
same namespace. Here N counts the shared generated set (N≤3); peer-only
identities are the required partial-peer axis outside that shared set. The
finite shard contains 432 generated conflict cases and drives each through
`DurableIndex.SyncFrom`.

The package test suite will also census AST calls to `t.Skip`, `t.Skipf`, and
`t.SkipNow` in every `_test.go` file. An allowlisted skip must state a platform
or environment-capability reason and name an always-on sibling test for the
same property. The current expected census is zero skips. A temporary planted
unjustified skip checks that the census rejects new skip calls. A repository-tree
hygiene test will reject `.pyc` files and `__pycache__` directories. The
mutation harness will run the first-common, last-common, even-common-index,
and first-namespace audit narrowings independently against the always-on
conflict test, plus an applied neutral control.
