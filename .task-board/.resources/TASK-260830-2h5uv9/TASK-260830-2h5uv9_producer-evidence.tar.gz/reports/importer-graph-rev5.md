# Exact importer graph — rev5

Base: `0ca3e4c26e2b275212796657f785b9b450f6174e`; candidate: checkpoint `86a6188a0e35fd04a24eba62a01b71a54d6faa5d` plus uncommitted rev5 worktree. Graphs use Go 1.25.5, darwin/arm64, `GOWORK=off`, `go list -test -json ./...`.

| Measure | Base | Candidate | Delta |
| --- | ---: | ---: | ---: |
| Package paths | 44 | 46 | +2 |
| Imports + test imports + external test imports | 1,468 | 1,592 | +124 |
| In-repository internal references | 317 | 350 | +33 |

| Imported target | Base importers | Candidate importers | Added edges |
| --- | ---: | ---: | --- |
| `canonicaljson` | 22 | 23 | `merkleinventory`; removed: none |
| `rpcwire` | 3 | 4 | `merkleinventory`; removed: none |
| `provhost` | 5 | 6 | `tmuxserver`; removed: none |

The 25-package base importer set had previously passed in one serialized command (exit 0, 8,967 pass events); its source identity is the immutable fork base above, so that evidence is reused. The exact candidate full suite was rerun after rev5 changes and covers all 27 target-importer packages. The complete per-entry/input outcome grid, moved behavior classes, and base/candidate row evidence are in `internal/merkleinventory/IMPORTER-OUTCOMES.md`. New whole-graph paths are `internal/merkleinventory` and `internal/tmuxserver`; `internal/termbind` deltas belong to trunk and do not import the tracked target packages.
