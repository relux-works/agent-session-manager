# Generated property shards — TASK-260830-2h5uv9 rev5

All Go commands were direct processes; accepted selector logs have package `ok` output. The default (no nested selector) test runs N=1..3. The N4–N6 exact-order runs below cover the rest of the selected generated property. The previous ambiguous N4 probe files are explicitly excluded.

| N | Valid cases | Order domain | Accepted N4–N6 processes |
| ---: | ---: | --- | ---: |
| 1 | 8 | all | default shard |
| 2 | 40 | all | default shard |
| 3 | 264 | all | default shard |
| 4 | 2,208 | all 24 orders | 3 |
| 5 | 22,560 | all 120 orders | 24 |
| 6 | 12,920 | 34 deterministic samples incl. identity/reverse | 17 |
| **Total** | **38,000** | **N≤5 exhaustive; N=6 sampled** | **44** |

Generated cases cross duplicate off/on, both timestamp directions, absent/delayed-filled gap, compatible partial-peer subsets, and 1–3 sync rounds. The six-class universe includes two competing leases and a losing-lease branch plus Tombstone/Acknowledgement. The independent oracle compares six roots and lease projection; mismatch cases assert literal `integrity_failure`. A separate default-on `TestDurableSyncConflictAuditsEveryCommonIDPositionWithPeerOnlyRecord` adds 432 common-ID position × peer-only conflict cases.

## Accepted raw N4–N6 logs

- `N4-000-007.log` — exit 0, Go package `ok` output.
- `N4-008-015-verified.log` — exit 0, Go package `ok` output.
- `N4-016-023.log` — exit 0, Go package `ok` output.
- `N5-000-004.log` — exit 0, Go package `ok` output.
- `N5-005-009.log` — exit 0, Go package `ok` output.
- `N5-010-014.log` — exit 0, Go package `ok` output.
- `N5-015-019.log` — exit 0, Go package `ok` output.
- `N5-020-024.log` — exit 0, Go package `ok` output.
- `N5-025-029.log` — exit 0, Go package `ok` output.
- `N5-030-034.log` — exit 0, Go package `ok` output.
- `N5-035-039.log` — exit 0, Go package `ok` output.
- `N5-040-044.log` — exit 0, Go package `ok` output.
- `N5-045-049.log` — exit 0, Go package `ok` output.
- `N5-050-054.log` — exit 0, Go package `ok` output.
- `N5-055-059.log` — exit 0, Go package `ok` output.
- `N5-060-064.log` — exit 0, Go package `ok` output.
- `N5-065-069.log` — exit 0, Go package `ok` output.
- `N5-070-074.log` — exit 0, Go package `ok` output.
- `N5-075-079.log` — exit 0, Go package `ok` output.
- `N5-080-084.log` — exit 0, Go package `ok` output.
- `N5-085-089.log` — exit 0, Go package `ok` output.
- `N5-090-094.log` — exit 0, Go package `ok` output.
- `N5-095-099.log` — exit 0, Go package `ok` output.
- `N5-100-104.log` — exit 0, Go package `ok` output.
- `N5-105-109.log` — exit 0, Go package `ok` output.
- `N5-110-114.log` — exit 0, Go package `ok` output.
- `N5-115-119.log` — exit 0, Go package `ok` output.
- `N6-000-001.log` — exit 0, Go package `ok` output.
- `N6-002-003.log` — exit 0, Go package `ok` output.
- `N6-004-005.log` — exit 0, Go package `ok` output.
- `N6-006-007.log` — exit 0, Go package `ok` output.
- `N6-008-009.log` — exit 0, Go package `ok` output.
- `N6-010-011.log` — exit 0, Go package `ok` output.
- `N6-012-013.log` — exit 0, Go package `ok` output.
- `N6-014-015.log` — exit 0, Go package `ok` output.
- `N6-016-017.log` — exit 0, Go package `ok` output.
- `N6-018-019.log` — exit 0, Go package `ok` output.
- `N6-020-021.log` — exit 0, Go package `ok` output.
- `N6-022-023.log` — exit 0, Go package `ok` output.
- `N6-024-025.log` — exit 0, Go package `ok` output.
- `N6-026-027.log` — exit 0, Go package `ok` output.
- `N6-028-029.log` — exit 0, Go package `ok` output.
- `N6-030-031.log` — exit 0, Go package `ok` output.
- `N6-032-033.log` — exit 0, Go package `ok` output.

Excluded exploratory logs (not counted): `N4-008-015.log` (ambiguous selection attempt) and `N4-order000-probe.log` (single-order probe). The N1–N3 default shard passed in `focused-rev5-final.log`; final configured-suite evidence is in `full-configured-rev5-final2.log`.
