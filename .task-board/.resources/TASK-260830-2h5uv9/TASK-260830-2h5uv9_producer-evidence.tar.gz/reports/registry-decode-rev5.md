# Decoded registry edge audit — TASK-260830-2h5uv9 rev5

Registry: `internal/traceability/ownership.v0.7.0.json`. Acceptance cases decoded: 163.

## `story-260830-nxqqaw-inventory-exchange`

Production declaration: `internal/merkleinventory/serve.go` → `Dispatch`.

Acceptance tests (7):
- `internal/merkleinventory/trie_test.go` → `TestNormativeRootAndChildFixtures`
- `internal/merkleinventory/trie_test.go` → `TestMixedNS1RootsFromNormativeSyntheticIDs`
- `internal/merkleinventory/membership_test.go` → `TestRPC2SchemaMembershipTableIsTotalAndDisjoint`
- `internal/merkleinventory/membership_test.go` → `TestMixedNSN1RejectsDescriptorRelabelingChunksAndLocalMarker`
- `internal/merkleinventory/identity_exchange_test.go` → `TestMixedNSExchangeIdentityLevelSyntheticIDs`
- `internal/merkleinventory/membership_test.go` → `TestInProcessExchangeWalksChangedNamespacesAndFetchesExactObjects`
- `internal/merkleinventory/tombstone_exchange_test.go` → `TestInProcessTombstoneUnionRetainsBothTimesAndAcknowledgements`

Decoded clause bindings:
- `section_binding` `section:11.4`; case appears in that binding list; owner `internal/merkleinventory/durable.go` → `SyncFrom`.

## `story-260830-147hsj-durable-union-projection`

Production declaration: `internal/merkleinventory/durable.go` → `SyncFrom`.

Acceptance tests (7):
- `internal/merkleinventory/durable_test.go` → `TestDurableSyncFindsMissingJSONObjectsAndRetainsTombstoneRecords`
- `internal/merkleinventory/durable_test.go` → `TestDurableSyncAuditsCommonIDsAndQuarantinesDifferentBytes`
- `internal/merkleinventory/durable_test.go` → `TestDurableSyncRefusesUnclosedAcknowledgementThenRecovers`
- `internal/merkleinventory/durable_test.go` → `TestDurableJSONAddIsIdempotentAcrossCrashRestartByNamespace`
- `internal/merkleinventory/durable_test.go` → `TestDurableConflictCrashRestoresQuarantineAndAbortsSync`
- `internal/merkleinventory/durable_test.go` → `TestProjectionRebuildExhaustsUnionArrivalsWithoutTimestampAuthority`
- `internal/sessquery/union_test.go` → `TestLeaseHeadsForSessionReturnsEveryTupleAcrossTimestampPerturbation`

Decoded clause bindings:
- `section_binding` `section:5.3`; case appears in that binding list; owner `internal/sessrepo/lease_store.go` → `CompareAndSwapLease`.
- `section_binding` `section:10.7`; case appears in that binding list; owner `internal/merkleinventory/durable.go` → `SyncFrom`.
- `section_binding` `section:11.4`; case appears in that binding list; owner `internal/merkleinventory/durable.go` → `SyncFrom`.

## `story-260830-2h5uv9-order-duplicate-gap-convergence`

Production declaration: `internal/merkleinventory/durable.go` → `SyncFrom`.

Acceptance tests (11):
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncGeneratedPerturbationProduct`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncArrivalOrderConverges`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncGapFillsOnLaterPass`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncClockSkewDoesNotSelectLeaseWinner`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncPartialPeerNeverRegressesLocalRoots`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncDuplicateDeliveryIsByteIdentical`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncSameDigestDifferentBytesIsTypedConflict`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncConflictWithPartialOverlapPeer`
- `internal/merkleinventory/sync_rework_test.go` → `TestDurableSyncConflictAuditsEveryCommonIDPositionWithPeerOnlyRecord`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncRefusesPeerNamespaceMismatch`
- `internal/merkleinventory/sync_property_test.go` → `TestDurableSyncUnclosedAcknowledgementAborts`

Decoded clause bindings:
- `section_binding` `section:5.3`; case appears in that binding list; owner `internal/sessrepo/lease_store.go` → `CompareAndSwapLease`.
- `section_binding` `section:10.7`; case appears in that binding list; owner `internal/merkleinventory/durable.go` → `SyncFrom`.
- `section_binding` `section:11.4`; case appears in that binding list; owner `internal/merkleinventory/durable.go` → `SyncFrom`.

Validation: all three selected story-final cases exist in the decoded registry, have nonempty decoded owner/clause bindings, and list their production declaration and acceptance tests above. The measured digest is pinned in `internal/traceability/traceability.go`: `2302a10a0174ada997614ea7d6112add30e9b2328f6b25ea796ea175f48568cd`.
