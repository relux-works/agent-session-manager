import sys,re
p=sys.argv[1]; which=sys.argv[2]
s=open(p).read()
old_cond="\t\t\tif _, exists := localSet[id]; exists {\n\t\t\t\tcommon = append(common, id)"
assert old_cond in s
def cond(c): return s.replace(old_cond, "\t\t\tif _, exists := localSet[id]; exists && "+c+" {\n\t\t\t\tcommon = append(common, id)")
if which=="A": s=cond("len(peerIDs) == len(localIDs)")
elif which=="B": s=cond("len(peerIDs) <= len(localIDs)")  # audit only when peer has nothing missing (size proxy)
elif which=="C": s=cond("namespace == durableJSONNamespaces[0]")
elif which=="D":
    s=cond("reviewSyncRound == 0")
    s=s.replace("\treturn store.validateTombstoneAckClosureLocked()\n}","\treviewSyncRound++\n\treturn store.validateTombstoneAckClosureLocked()\n}\n\nvar reviewSyncRound int",1)
elif which=="E":
    s=s.replace("\t\tif err := store.fetchAndAdd(peer, namespace, common, nextRequestID)","\t\tcommon = common[:min(1, len(common))]\n\t\tif err := store.fetchAndAdd(peer, namespace, common, nextRequestID)",1)
elif which=="F":
    s=s.replace("\t\tif err := store.fetchAndAdd(peer, namespace, common, nextRequestID)","\t\t_ = len(common)\n\t\tif err := store.fetchAndAdd(peer, namespace, common, nextRequestID)",1)
open(p,"w").write(s)
