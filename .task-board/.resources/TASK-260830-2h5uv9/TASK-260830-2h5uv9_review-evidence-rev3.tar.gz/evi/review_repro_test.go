package merkleinventory

import (
	"bytes"
	"path/filepath"
	"testing"
)

// Reviewer reproduction: same identity, different bytes, arriving from a peer
// that ALSO carries an identity the local replica lacks (partial overlap).
func TestReviewSameIdentityDifferentBytesFromPartialOverlapPeer(t *testing.T) {
	objects := generatedSyncPropertyObjects(t, 3, 0)
	root := t.TempDir()
	local, _ := OpenDurable(filepath.Join(root, "local"))
	peer, _ := OpenDurable(filepath.Join(root, "peer"))
	if err := local.AddJSON(objects[1].data); err != nil {
		t.Fatal(err)
	}
	if err := peer.AddJSON(append(bytes.Clone(objects[1].data), '\n')); err != nil {
		t.Fatal(err)
	}
	if err := peer.AddJSON(objects[2].data); err != nil {
		t.Fatal(err)
	}
	err := local.SyncFrom(peer, testRequestIDs())
	assertSyncLiteralConflict(t, err, "SyncFrom(partial-overlap peer with same-identity different bytes)")
}
