import sys,re
root=sys.argv[1]; name=sys.argv[2]
def sub(path,old,new):
    p=root+'/'+path; s=open(p).read()
    assert s.count(old)==1,(name,path,s.count(old)); open(p,'w').write(s.replace(old,new))
if name=='P1_timestamp_tiebreak':
    sub('internal/sessquery/lease.go','		byLeaseID[candidate.LeaseID] = candidate\n		heads = append(heads, sessstate.LeaseHead{Epoch: candidate.Epoch, LeaseID: candidate.LeaseID})',
'''		byLeaseID[candidate.LeaseID] = candidate
		replaced := false
		for i := range heads {
			if heads[i].Epoch == candidate.Epoch {
				var a, b struct{ CreatedAt string `json:"created_at"` }
				_ = json.Unmarshal(byLeaseID[heads[i].LeaseID].Raw, &a)
				_ = json.Unmarshal(candidate.Raw, &b)
				if b.CreatedAt > a.CreatedAt {
					heads[i] = sessstate.LeaseHead{Epoch: candidate.Epoch, LeaseID: candidate.LeaseID}
				}
				replaced = true
			}
		}
		if !replaced {
			heads = append(heads, sessstate.LeaseHead{Epoch: candidate.Epoch, LeaseID: candidate.LeaseID})
		}''')
elif name=='P2_skip_common_audit_on_partial_overlap':
    sub('internal/merkleinventory/durable.go','		if err := store.fetchAndAdd(peer, namespace, common, nextRequestID); err != nil {\n			return err\n		}\n		missing',
'		if len(common) == len(peerIDs) {\n		if err := store.fetchAndAdd(peer, namespace, common, nextRequestID); err != nil {\n			return err\n		}\n		}\n		missing')
elif name=='P3_partial_peer_regresses_ack':
    sub('internal/merkleinventory/durable.go','	return store.validateTombstoneAckClosureLocked()\n}\n\nfunc (store *DurableIndex) fetchAndAdd',
'''	if pa, la := peer.index.objectIDs("tombstone_ack"), store.index.objectIDs("tombstone_ack"); len(pa) == 0 && len(la) > 0 && len(peer.index.objectIDs("record")) > 0 {
		for _, id := range la {
			_ = store.removeActive("tombstone_ack", id)
			store.index.mu.Lock()
			delete(store.index.objects["tombstone_ack"], id)
			delete(store.index.locations, id)
			store.index.mu.Unlock()
		}
	}
	return store.validateTombstoneAckClosureLocked()
}

func (store *DurableIndex) fetchAndAdd''')
elif name=='P4_nonidempotent_resync':
    sub('internal/merkleinventory/durable.go','	return store.validateTombstoneAckClosureLocked()\n}\n\nfunc (store *DurableIndex) fetchAndAdd',
'''	if f, err := os.OpenFile(filepath.Join(store.root, "objects", ".sync-count"), os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o600); err == nil {
		_, _ = f.Write([]byte{'x'})
		_ = f.Close()
	}
	return store.validateTombstoneAckClosureLocked()
}

func (store *DurableIndex) fetchAndAdd''')
elif name=='P5_same_id_trailing_ws_accept':
    sub('internal/merkleinventory/durable.go','if priorNamespace == membership.Namespace && hasPrior && bytes.Equal(prior.data, data) {',
        'if priorNamespace == membership.Namespace && hasPrior && bytes.Equal(bytes.TrimSpace(prior.data), bytes.TrimSpace(data)) {')
elif name=='C0_neutral':
    sub('internal/merkleinventory/durable.go','	return store.validateTombstoneAckClosureLocked()\n}\n\nfunc (store *DurableIndex) fetchAndAdd',
        '	_ = len(durableJSONNamespaces)\n	return store.validateTombstoneAckClosureLocked()\n}\n\nfunc (store *DurableIndex) fetchAndAdd')
