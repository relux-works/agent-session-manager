#!/bin/zsh
S=$1; P=$2; SHARD=$3; cd $S/plant
for f in internal/merkleinventory/durable.go internal/sessquery/lease.go; do cp $S/cand/$f $f; done
python3 $S/plants/apply.py $S/plant $P || { echo "$P NOT_APPLIED"; exit; }
gofmt -l internal/ >/dev/null; go build ./... > $S/plants/$P.build.log 2>&1 || { echo "$P COMPILE_FAIL"; cat $S/plants/$P.build.log; exit; }
go test ./internal/merkleinventory ./internal/sessquery -count=1 > $S/plants/$P.suite.log 2>&1; a=$?
go test ./internal/merkleinventory -count=1 -run "TestDurableSyncGeneratedPerturbationProduct/$SHARD" > $S/plants/$P.product.log 2>&1; b=$?
echo "$P suite_exit=$a product_exit=$b"; grep -h -- '--- FAIL' $S/plants/$P.suite.log | grep -v '/' | head -8
for f in internal/merkleinventory/durable.go internal/sessquery/lease.go; do cp $S/cand/$f $f; done
