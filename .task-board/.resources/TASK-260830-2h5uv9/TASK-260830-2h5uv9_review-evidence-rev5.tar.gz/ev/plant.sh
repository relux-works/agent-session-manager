#!/bin/zsh
# usage: plant.sh NAME 'go statement'
S=${0:A:h}; N=$1; STMT=$2
rm -rf $S/m_$N; cp -R $S/cand $S/m_$N
python3 - "$S/m_$N/internal/merkleinventory/durable.go" "$STMT" <<'PY'
import sys
p,s=sys.argv[1],sys.argv[2]
t=open(p).read()
a="\t\tif err := store.fetchAndAdd(peer, namespace, common, nextRequestID); err != nil {"
assert t.count(a)==1
t=t.replace(a,"\t\t"+s+"\n"+a)
open(p,"w").write(t)
PY
cd $S/m_$N && go test ./internal/merkleinventory -count=1 > $S/ev/plant_$N.log 2>&1; echo "$N exit=$? fails=$(grep -c -- '--- FAIL' $S/ev/plant_$N.log)"
rm -rf $S/m_$N
