# Reproduce CR13 review

From the repository, extract immutable product source into `<evidence>/probe`:

```
mkdir -p <evidence>/probe
git archive f6f92e676df1e10adac55ef340ecfe5e759a67e7 internal go.mod go.sum README.md | tar -x -C <evidence>/probe
cp <evidence>/reviewer-tests/*.go <evidence>/probe/internal/sessquery/
```

Run commands from each `*-exit.json` in probe. Gate-shapes and zero-capability tests intentionally fail. The original-and-retained mask passes. temporal-own.log includes rejected fixture construction, not Reader negative proof; retain that limitation.

`python3 <evidence>/attack.py` applies the reachable plant, runs census and behavior separately, restores source, then applies the harmless survivor through the same runner and restores source again. Expect exits 0/1/0.

`python3 <evidence>/run_unapplied.py` executes the four shipped mutation call expressions with the shipped run function; expect four NOT_APPLIED rows and no test execution. `audit.py` reports unique anchor counts only.

The evidence contains input producer/reviewer packets, actual raw logs and exact command exits. Product source is obtained from the named Git tree, not from the live Story checkout. source-manifest.json proves all 479 extracted tracked source/module/README blobs restored to that tree after attacks. No full-suite rerun is claimed.
