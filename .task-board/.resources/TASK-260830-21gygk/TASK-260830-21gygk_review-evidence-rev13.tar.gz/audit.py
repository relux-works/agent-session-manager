import ast,pathlib,json,subprocess,hashlib
p=pathlib.Path(__file__).parent.resolve();root=p/'probe'
s=(root/'internal/sessquery/testdata/mutate.py').read_text(); tree=ast.parse(s)
paths={'source':'internal/sessquery/query.go','selector_source':'internal/sessquery/selector.go','revalidate_source':'internal/sessquery/revalidate.go','plan_source':'internal/sessquery/plan.go','summary_source':'internal/sessquery/summary.go','lease_source':'internal/sessquery/lease.go','repo_source':'internal/sessrepo/store.go'}
env={n.targets[0].id:ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and isinstance(n.value,ast.Constant)}
rows=[]
for n in tree.body:
 if not isinstance(n,ast.Expr) or not isinstance(n.value,ast.Call) or not isinstance(n.value.func,ast.Name) or n.value.func.id!='run':continue
 args=n.value.args;name=ast.literal_eval(args[0]);path=paths[args[1].id];old=eval(compile(ast.Expression(args[2]),'<anchor>','eval'),{'__builtins__':{}},env)
 rows.append({'name':name,'path':path,'anchor_count':(root/path).read_text().count(old)})
(p/'anchor-audit.json').write_text(json.dumps(rows,indent=2));print('N/B',len([r for r in rows if r['name'].startswith(('N-','B-'))]));print([r for r in rows if r['anchor_count']!=1])
