package sessquery
import (
 "fmt"
 "github.com/relux-works/agent-session-manager/internal/sessrepo"
 "github.com/relux-works/agent-session-manager/internal/sessstate"
 "github.com/relux-works/agent-session-manager/internal/scalar"
)
func review11UseUnchecked(checkpoint validatedCheckpoint, summary sessrepo.EventSummary, repo *sessrepo.Repository, checkpoints map[string]validatedCheckpoint) bool {
 payload, err := eventPayloadMembers(checkpoint,repo,summary);if err!=nil{return false}
 id,err:=leaseStringMember(payload,"checkpoint_id");if err!=nil{return false}
 copied,ok:=checkpoints[id]
 return ok && copied.CreatorHostID=="0198f4c8-4a10-7b22-8b3c-1234567890ac"
}
func review11UncheckedProfile(checkpoint validatedCheckpoint, summary sessrepo.EventSummary, creation, recordID string, events []sessrepo.EventSummary, checkpoints map[string]validatedCheckpoint, repo *sessrepo.Repository, chain []validatedLease, sessionKind string) (string, string, bool, map[string]bool, error) {
	payload, err := eventPayloadMembers(checkpoint, repo, summary)
	if err != nil {
		return "", "", false, nil, err
	}
	rawID, err := leaseStringMember(payload, "checkpoint_id")
	if err != nil {
		return "", "", false, nil, fmt.Errorf("%w: session %s event %s carries no valid resume checkpoint for profile authority: %v", sessstate.ErrIntegrity, checkpoint.SessionID, summary.EventID, err)
	}
	reference, err := scalar.ParseDigest(rawID)
	if err != nil {
		return "", "", false, nil, fmt.Errorf("%w: session %s event %s carries malformed resume checkpoint %q for profile authority", sessstate.ErrIntegrity, checkpoint.SessionID, summary.EventID, rawID)
	}
	checkpointID := reference.String()
	ref, ok := checkpoints[checkpointID]
	if !ok {
		return "", "", false, nil, fmt.Errorf("%w: validated checkpoint %s for session %s cannot be established", ErrObservationUnavailable, checkpointID, checkpoint.SessionID)
	}
	if ref.SessionID != checkpoint.SessionID {
		return "", "", false, nil, fmt.Errorf("%w: validated checkpoint %s carries session %s, want %s", ErrObservationUnavailable, checkpointID, ref.SessionID, checkpoint.SessionID)
	}
	refClosure, err := profileClosure(ref, recordID, events)
	if err != nil {
		return "", "", false, nil, err
	}
	refSource, refProfile := "", ""
	refHas := false
	for _, candidate := range events {
		if !refClosure[candidate.EventID] {
			continue
		}
		if candidate.EventType != "profile.changed" {
			continue
		}
		target, err := eventProfileTarget(checkpoint, repo, candidate)
		if err != nil {
			return "", "", false, nil, err
		}
		refSource, refProfile, refHas = candidate.EventID, target, true
	}
	if !refHas {
		return creation, "", false, refClosure, nil
	}
	return refProfile, refSource, true, refClosure, nil
}
