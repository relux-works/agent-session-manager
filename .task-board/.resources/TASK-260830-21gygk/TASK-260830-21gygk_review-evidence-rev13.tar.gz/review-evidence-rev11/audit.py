from pathlib import Path
import json,re,hashlib,ast,subprocess
r=Path(__file__).resolve().parent
out={'manifests':[], 'plants':{}, 'problems':[]}
for root in [r/'producer10',r/'producer']:
 for manifest in root.rglob('mutants.json'):
  rows=json.loads(manifest.read_text());out['manifests'].append(str(manifest.relative_to(r)))
  for row in rows:
   name=row['mutant'];log=manifest.parent/(name+'.log');entry=dict(row)
   entry['manifest']=str(manifest.relative_to(r));entry['log_exists']=log.exists()
   if log.exists():
    text=log.read_text();fail=re.findall(r'^\s*--- FAIL: ([^ ]+)',text,re.M)
    entry['raw_failure_count']=len(fail)
    entry['admission_examples']=[x.strip() for x in text.splitlines() if 'admitted' in x and not x.startswith('===')][:4]
    if row.get('failed_tests') is not None and fail!=row['failed_tests']:out['problems'].append(name+' failure list mismatch')
   out['plants'].setdefault(name,[]).append(entry)
nb=[n for n in out['plants'] if n.startswith(('N-','B-'))]
out['unique_nb']=len(nb)
out['unique_nb_killed']=sum(any(e['classification']=='KILLED' and e.get('exit')==1 and e.get('raw_failure_count',0)>0 for e in out['plants'][n]) for n in nb)
# Verify all replacement anchors against the immutable source, without running the instrument.
p=r/'candidate/internal/sessquery/testdata/mutate.py';tree=ast.parse(p.read_text());env={}
for node in tree.body:
 if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
  try: env[node.targets[0].id]=ast.literal_eval(node.value)
  except (ValueError,TypeError):pass
sources={'source':'query.go','selector_source':'selector.go','revalidate_source':'revalidate.go','plan_source':'plan.go','summary_source':'summary.go','lease_source':'lease.go','repo_source':'../sessrepo/store.go'}
out['anchors']=[]
for node in tree.body:
 if not(isinstance(node,ast.Expr) and isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='run'):continue
 args=node.value.args;name=ast.literal_eval(args[0]);file=sources[args[1].id];old=eval(compile(ast.Expression(args[2]),'<anchor>','eval'),{'__builtins__':{}},env)
 out['anchors'].append({'name':name,'count':(r/'candidate/internal/sessquery'/file).read_text().count(old)})
(r/'mutation-audit.json').write_text(json.dumps(out,indent=2))
print('manifests',len(out['manifests']),'unique N/B',len(nb),'killed',out['unique_nb_killed'],'problems',out['problems'])
print('anchor exceptions', [x for x in out['anchors'] if x['count']!=1])
