# Reproduce CR11 review

1. Export `git archive 0cb391bd71143364e40be6c4cfab90195c1d36cd` into a new task scratch `candidate/` directory. Never apply these probes to the live Story.
2. Run the independent-shipped command from independent-results.json before adding any probe (expected exit 0).
3. Copy review11_probe_test.go into candidate/internal/sessquery/. Run the temporal-probe command (expected exit 1: four future_owner cases; twelve controls and four epoch_mismatch refusals pass).
4. Place census_probe.py beside candidate/ and run it. It creates a new-file reachable bypass in the archive only, executes both static and behavioral suites, logs actual subprocess returns, and restores product bytes in finally. Static census exits 0; behavior exits 1.
5. Run retained-controls command after restoration (expected exit 0).

The candidate archive is identified by provenance.json; producer resources are referenced by original task resource names and digests below instead of duplicating archives. mutation-audit.json contains inspected manifest/raw-log details. Full original producer logs remain in TASK-260830-21gygk_producer-evidence-rev10.tar.gz and TASK-260830-21gygk_producer-evidence-rev11.tar.gz.
