# Independent mutation evidence audit

Inspected 35 manifests and matching raw failure lists: 63 unique N/B plants, 63 recorded KILLED with exit 1 and named failures; zero manifest/raw failure-list discrepancies.

63 N/B = 60 N + 3 B. Retain CR10 reviewed classification (43 semantic, 17 precision), add three referenced creator/variant/lease semantic admission kills = 46 semantic + 17 precision. No fixture/compile failure among the three new kills. No claim of independently rerunning all 63. 57 old plants reuse rev10 evidence; three affected old plants have producer focused rev11 reruns; three new plants have full behavioral rev11 runs.

All 63 N/B exact anchors occur once on restored immutable rev11 source; harmless and compile controls once, not-applied zero. All five producer source-manifest hashes match immutable candidate.

## N-referenced-creator
- producer/mutants-rev11/slice1_out/mutants.json: KILLED, exit=1, raw failures=15
  rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>
  rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority
## N-referenced-variant
- producer/mutants-rev11/slice1_out/mutants.json: KILLED, exit=1, raw failures=15
  rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>
  rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority
## N-referenced-lease
- producer/mutants-rev11/slice2_out/mutants.json: KILLED, exit=1, raw failures=15
  rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>
  rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority
## C-harmless-comment
- producer10/mutants-rev10/c1/mutants.json: SURVIVED, exit=0, raw failures=0
- producer/mutants-rev11/slice_harmless_out/mutants.json: SURVIVED, exit=0, raw failures=0
  rev11_regression_test.go:192: old-plan Revalidate: selector_observation_unavailable: validated checkpoint sha256:0da44c301e2c8e86ef6aa028e46fd7081ffdfae293208e434581ba9d388597e8 is bound to lease dddddddd-eeee-4fff-8000-222222222222 at epoch 1 without an admitted owning lease
  rev11_regression_test.go:192: old-plan Revalidate: selector_observation_unavailable: validated checkpoint sha256:0da44c301e2c8e86ef6aa028e46fd7081ffdfae293208e434581ba9d388597e8 is bound to lease dddddddd-eeee-4fff-8000-222222222222 at epoch 1 without an admitted owning lease
- producer/mutants-rev11/slice2_out/mutants.json: COMPILE_OR_HARNESS_FAILURE, exit=1, raw failures=0
## C-not-applied
- producer10/mutants-rev10/c1/mutants.json: NOT_APPLIED, exit=not run, raw failures=no log
- producer/mutants-rev11/slice2_out/mutants.json: NOT_APPLIED, exit=not run, raw failures=no log
## C-compile-failure
- producer10/mutants-rev10/c2/mutants.json: COMPILE_OR_HARNESS_FAILURE, exit=1, raw failures=0
- producer/mutants-rev11/slice2_out/mutants.json: COMPILE_OR_HARNESS_FAILURE, exit=1, raw failures=0

The slice2 harmless run contains transient compiler/cache failures and is not a survivor; the dedicated harmless slice is applied SURVIVED exit 0. Its before/after controls pass. NOT_APPLIED and COMPILE_OR_HARNESS_FAILURE remain outside the behavioral numerator.

The instrument classifies from subprocess.returncode and named FAIL lines, restores original bytes in finally, and runs behavioral sessquery/sessrepo tests. Slices retain the same runner and differ by selected plants; final Go source binding is verified. The new independent alternate-path plant is separately recorded in census-probe-results.json: static gate SURVIVED exit 0, behavioral suite KILLED exit 1. It is not added to the shipped inventory.
