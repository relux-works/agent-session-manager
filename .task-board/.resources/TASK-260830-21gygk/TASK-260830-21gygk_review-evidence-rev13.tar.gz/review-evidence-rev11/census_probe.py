from pathlib import Path
import subprocess,json
r=Path(__file__).resolve().parent;c=r/'candidate';p=c/'internal/sessquery/lease.go';original=p.read_text()
start=original.index('func referencedCheckpointProfile(');end=original.index('\n// checkProfilePairSource',start);fn=original[start:end]
unchecked=fn.replace('func referencedCheckpointProfile(', 'func review11UncheckedProfile(',1)
guard='\tif err := checkReferencedCheckpointBinding(ref, checkpointID, checkpoint.SessionID, sessionKind, chain, repo); err != nil {\n\t\treturn "", "", false, nil, err\n\t}\n'
assert unchecked.count(guard)==1
unchecked=unchecked.replace(guard,'')
helper='''package sessquery
import (
 "fmt"
 "github.com/relux-works/agent-session-manager/internal/sessrepo"
 "github.com/relux-works/agent-session-manager/internal/sessstate"
 "github.com/relux-works/agent-session-manager/internal/scalar"
)
func review11UseUnchecked(checkpoint validatedCheckpoint, summary sessrepo.EventSummary, repo *sessrepo.Repository, checkpoints map[string]validatedCheckpoint) bool {
 payload, err := eventPayloadMembers(checkpoint,repo,summary);if err!=nil{return false}
 id,err:=leaseStringMember(payload,"checkpoint_id");if err!=nil{return false}
 copied,ok:=checkpoints[id]
 return ok && copied.CreatorHostID=="0198f4c8-4a10-7b22-8b3c-1234567890ac"
}
'''+unchecked
h=c/'internal/sessquery/review11_bypass.go';h.write_text(helper)
# use the actual scalar import path from production
for line in original.splitlines():
 if '/scalar"' in line: helper=helper.replace('"github.com/relux-works/agent-session-manager/internal/scalar"',line.strip())
h.write_text(helper)
brace=fn.index(' {')+2
newfn=fn[:brace]+'\n\tif review11UseUnchecked(checkpoint, summary, repo, checkpoints) { return review11UncheckedProfile(checkpoint, summary, creation, recordID, events, checkpoints, repo, chain, sessionKind) }'+fn[brace:]
p.write_text(original[:start]+newfn+original[end:])
(r/'review11_bypass.go').write_text(helper)
(r/'census-lease-mutated.go').write_text(p.read_text())
results=[]
try:
 for name,mask in [('census-bypass','^TestRev11RecordConsumptionCensus$'),('census-bypass-behavior','TestReview10ReferencedCheckpointAdmission|TestRev11')]:
  cmd=['go','test','./internal/sessquery','-count=1','-run',mask,'-v']
  with (r/(name+'.log')).open('w') as log: proc=subprocess.run(cmd,cwd=c,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  results.append(dict(name=name,command=cmd,exit=proc.returncode));(r/'census-probe-results.json').write_text(json.dumps(results,indent=2))
  print(name,proc.returncode,flush=True)
finally:
 p.write_text(original);h.unlink();assert p.read_text()==original
