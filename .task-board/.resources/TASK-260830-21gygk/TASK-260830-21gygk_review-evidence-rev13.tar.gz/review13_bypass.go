package sessquery
type review13Receiver struct{}
func (review13Receiver) admitCheckpoint(raw validatedCheckpoint) (admittedCheckpoint,error) {
 var cp admittedCheckpoint
 cp.Digest=raw.Digest;cp.SessionID=raw.SessionID;cp.LeaseEpoch=raw.LeaseEpoch;cp.LeaseID=raw.LeaseID;cp.CreatorHostID=raw.CreatorHostID;cp.HasProviderManifest=raw.HasProviderManifest;cp.HasTaskBoardBundle=raw.HasTaskBoardBundle;cp.EventHeads=raw.EventHeads
 return cp,nil
}
