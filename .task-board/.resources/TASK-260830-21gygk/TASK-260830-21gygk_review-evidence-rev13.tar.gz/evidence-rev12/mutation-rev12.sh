#!/usr/bin/env bash
set -euo pipefail

# Focused rev12 mutant instrument. It always works in disposable source
# copies, never in the managed Story worktree, and runs the behavioral suite
# synchronously so the exit code and named failed tests remain evidence.
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
evidence_dir="$repo_root/.temp/TASK-260830-21gygk/mutation-rev12"
mkdir -p "$evidence_dir"
summary_file="$evidence_dir/results.md"
: > "$summary_file"

focus_temporal='^(TestReview11ReferencedTemporalAuthority|TestRev12ReferencedCheckpointLaterLease)$'
focus_boundary='^(TestReview11ReferencedTemporalAuthority|TestRev12ReferencedCheckpointLaterLease|TestRev11RecordConsumptionCensus|TestRev12RecordConsumptionCensusRejectsAlternatePaths)$'

copy_source() {
	local destination="$1"
	mkdir -p "$destination"
	rsync -a --exclude='.git' --exclude='.temp' --exclude='.task-board' "$repo_root/" "$destination/"
}

run_test() {
	local name="$1"
	local source_dir="$2"
	local pattern="$3"
	local log_file="$evidence_dir/$name.log"
	set +e
(
		cd "$source_dir"
		go test ./internal/sessquery -run "$pattern" -count=1 -v
) > "$log_file" 2>&1
	local test_exit=$?
	set -e
	printf '%s: exit=%s log=%s\n' "$name" "$test_exit" "$log_file" | tee -a "$summary_file"
	printf '%s\n' "$test_exit"
}

# P1: narrow the temporal gate while preserving the ownerIndex/resumeIndex
# identifiers and all surrounding behavior. The future-owner negatives must
# kill this applied mutant; same-lease, later-consumer, historical, and
# divergence controls must remain part of the same run.
temporal_source="$(mktemp -d "$evidence_dir/temporal-source.XXXXXX")"
copy_source "$temporal_source"
temporal_file="$temporal_source/internal/sessquery/lease.go"
temporal_anchor='if ownerIndex < resumeIndex {'
temporal_count="$(rg -F -o -- "$temporal_anchor" "$temporal_file" | wc -l | tr -d ' ')"
if [[ "$temporal_count" != 1 ]]; then
	printf 'temporal-narrowing: NOT_APPLIED anchor_count=%s\n' "$temporal_count" | tee -a "$summary_file"
	exit 1
fi
perl -0pi -e 's/if ownerIndex < resumeIndex \{/if ownerIndex < resumeIndex \&\& ownerIndex < 0 {/' "$temporal_file"
temporal_exit="$(run_test temporal-narrowing "$temporal_source" "$focus_temporal" | tail -n 1)"
if [[ "$temporal_exit" == 0 ]] || ! rg -q -- 'future_owner|invalid temporal authority' "$evidence_dir/temporal-narrowing.log"; then
	printf 'temporal-narrowing: expected a behavioral kill but did not observe one\n' | tee -a "$summary_file"
	exit 1
fi
printf 'temporal-narrowing: KILLED (future-owner refusal was admitted by the mutant and named tests failed)\n' | tee -a "$summary_file"

# P2: weaken the package-wide raw-record type boundary for exactly the
# new-file helper plant. The behavioral run includes the alternate-path
# census, so this is a real gate failure rather than a static-only check.
boundary_source="$(mktemp -d "$evidence_dir/boundary-source.XXXXXX")"
copy_source "$boundary_source"
boundary_file="$boundary_source/internal/sessquery/rev11_regression_test.go"
boundary_anchor='"admitCheckpoint":                   true,'
boundary_count="$(rg -F -o -- "$boundary_anchor" "$boundary_file" | wc -l | tr -d ' ')"
if [[ "$boundary_count" != 1 ]]; then
	printf 'record-boundary-narrowing: NOT_APPLIED anchor_count=%s\n' "$boundary_count" | tee -a "$summary_file"
	exit 1
fi
perl -0pi -e 's/(\t"admitCheckpoint":\s+true,\n)/$1\t"review12NewFileHelper": true,\n/' "$boundary_file"
boundary_exit="$(run_test record-boundary-narrowing "$boundary_source" "$focus_boundary" | tail -n 1)"
if [[ "$boundary_exit" == 0 ]] || ! rg -q -- 'review12_new_file.go|type-level record-consumption gate admitted' "$evidence_dir/record-boundary-narrowing.log"; then
	printf 'record-boundary-narrowing: expected a behavioral gate kill but did not observe one\n' | tee -a "$summary_file"
	exit 1
fi
printf 'record-boundary-narrowing: KILLED (one raw new-file path was admitted by the mutant and the named census test failed)\n' | tee -a "$summary_file"

# C: apply a behavior-preserving comment plant through the same temporal
# instrument. A passing survivor is recorded separately from killed N plants.
survivor_source="$(mktemp -d "$evidence_dir/survivor-source.XXXXXX")"
copy_source "$survivor_source"
survivor_file="$survivor_source/internal/sessquery/lease.go"
survivor_count="$(rg -F -o -- '// checkReferencedCheckpointTemporal binds' "$survivor_file" | wc -l | tr -d ' ')"
if [[ "$survivor_count" != 1 ]]; then
	printf 'harmless-survivor: NOT_APPLIED anchor_count=%s\n' "$survivor_count" | tee -a "$summary_file"
	exit 1
fi
perl -0pi -e 's#// checkReferencedCheckpointTemporal binds#// checkReferencedCheckpointTemporal binds (rev12 harmless control)#' "$survivor_file"
survivor_exit="$(run_test harmless-survivor "$survivor_source" "$focus_temporal" | tail -n 1)"
if [[ "$survivor_exit" != 0 ]]; then
	printf 'harmless-survivor: expected a passing control but exit=%s\n' "$survivor_exit" | tee -a "$summary_file"
	exit 1
fi
printf 'harmless-survivor: SURVIVED (comment plant passed through the identical temporal instrument)\n' | tee -a "$summary_file"

printf 'all focused rev12 mutant classifications are complete\n' | tee -a "$summary_file"
