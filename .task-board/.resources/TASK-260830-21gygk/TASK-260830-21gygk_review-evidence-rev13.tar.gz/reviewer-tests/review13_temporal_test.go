package sessquery
import("testing";"fmt";"errors")
func review13TemporalFixture(t *testing.T, kind string, ancestor bool, mode string) *Reader {
	t.Helper()
	local, _ := repository(t)
	raw := record(t, idA, "alpha")
	if kind == "task_board" {
		raw = taskBoardRecordBytes(t, idA, "alpha")
	}
	ref, err := local.CreateSession(raw)
	if err != nil {
		t.Fatal(err)
	}
	checkpoint := checkpointRecordBytes
	if kind == "task_board" {
		checkpoint = taskBoardCheckpointBytes
	}
	seq := 0
	next := func() int {
		seq++
		return seq
	}
	created := appendEvent(t, local, idA, ref.RecordID, "session.created", next(), map[string]any{
		"session_record_id":             ref.RecordID,
		"bootstrap_operation_id":        hostA,
		"first_checkpoint_operation_id": hostB,
	})
	launched := appendEvent(t, local, idA, created, "provider.launched", next(), rev8LaunchPayload("yolo", nil))
	beforeChangeIdle := appendEvent(t, local, idA, launched, "session.idle", next(), map[string]any{
		"boundary_ref":    "before-change",
		"foreground_idle": true,
		"background_idle": true,
	})
	changed := appendEvent(t, local, idA, beforeChangeIdle, "profile.changed", next(), rev8ChangedPayload("yolo", "standard"))
	quiesced := appendEvent(t, local, idA, changed, "session.idle", next(), map[string]any{
		"boundary_ref":    "turn-0",
		"foreground_idle": true,
		"background_idle": true,
	})
	cpA := rev7Replace(t, checkpoint(t, idA, 1, lease, hostA), "checkpoint_id", map[string]any{
		"event_heads": []string{quiesced},
	})
	switch mode {
	case "future_owner":
		cpA = rev7Replace(t, cpA, "checkpoint_id", map[string]any{"lease_epoch": 2, "lease_id": leaseB})
	case "epoch_mismatch":
		cpA = rev7Replace(t, cpA, "checkpoint_id", map[string]any{"lease_epoch": 2})
	}
	stoppedRef := checkpointDigestOf(t, cpA)
	reference := stoppedRef
	profile, source := "standard", any(changed)
	var extra []byte
	switch mode {
	case "good", "good_prechange", "good_divergent", "future_owner", "epoch_mismatch", "later_resume", "same_outside", "earlier_outside":
	case "bad_wrong_session":
		extra = checkpointRecordBytes(t, idB, 1, lease, hostA)
		reference = checkpointDigestOf(t, extra)
	case "bad_unknown_head":
		extra = rev7Replace(t, checkpoint(t, idA, 1, lease, hostA), "checkpoint_id", map[string]any{
			"event_heads": []string{zeroDigest},
		})
		reference = checkpointDigestOf(t, extra)
	case "bad_missing":
		reference = zeroDigest
		profile, source = "yolo", nil
	default:
		t.Fatalf("unknown resume mode %q", mode)
	}
	announced := appendEvent(t, local, idA, quiesced, "checkpoint.created", next(), map[string]any{
		"checkpoint_id": stoppedRef,
		"kind":          "manual",
	})
	stopped := appendEvent(t, local, idA, announced, "session.stopped", next(), map[string]any{
		"graceful":       true,
		"checkpoint_id":  stoppedRef,
		"resumable":      true,
		"closure_kind":   "checkpointed",
		"process_closed": true,
		"store_closed":   true,
	})
	if mode == "same_outside" {
        branch := appendEvent(t, local, idA, stopped, "session.idle", next(), map[string]any{"boundary_ref":"sibling", "foreground_idle":true,"background_idle":true})
        extra = rev7Replace(t, checkpoint(t,idA,1,lease,hostA),"checkpoint_id",map[string]any{"event_heads":[]string{branch}})
        reference=checkpointDigestOf(t,extra)
    }
    resumed := appendEvent(t, local, idA, stopped, "session.resumed", next(), rev10ResumePayload(reference, profile, source))
	idle := appendEvent(t, local, idA, resumed, "session.idle", next(), map[string]any{
		"boundary_ref":    "turn-1",
		"foreground_idle": true,
		"background_idle": true,
	})
	cpB := rev7Replace(t, checkpoint(t, idA, 1, lease, hostA), "checkpoint_id", map[string]any{
		"event_heads": []string{idle},
	})
	announcedB := appendEvent(t, local, idA, idle, "checkpoint.created", next(), map[string]any{
		"checkpoint_id": checkpointDigestOf(t, cpB),
		"kind":          "manual",
	})
	tail := appendEventAs(t, local, idA, announcedB, "lease.transferred", 1, 2, leaseB, map[string]any{
		"operation_id":         hostB,
		"from_host_id":         hostA,
		"to_host_id":           hostA,
		"predecessor_lease_id": lease,
		"new_lease_id":         leaseB,
	})
	if mode == "later_resume" || mode == "earlier_outside" {
		laterRef := stoppedRef
        if mode == "earlier_outside" {
            branch := appendEvent(t,local,idA,stopped,"session.idle",next(),map[string]any{"boundary_ref":"earlier-owner-sibling","foreground_idle":true,"background_idle":true})
            extra=rev7Replace(t,checkpoint(t,idA,1,lease,hostA),"checkpoint_id",map[string]any{"event_heads":[]string{branch}})
            laterRef=checkpointDigestOf(t,extra)
        }
        tail = appendEventAs(t, local, idA, tail, "session.resumed", 2, 2, leaseB, rev10ResumePayload(laterRef, "standard", changed))
		tail = appendEventAs(t, local, idA, tail, "session.idle", 3, 2, leaseB, map[string]any{
			"boundary_ref":    "later-lease-resume",
			"foreground_idle": true,
			"background_idle": true,
		})
	}
	r := &Reader{Local: local, LocalHostID: hostA}
	switch mode {
	case "bad_missing":
		withCheckpoints(r, cpB)
	case "bad_wrong_session", "bad_unknown_head":
		withCheckpoints(r, cpB, extra)
	default:
		withCheckpoints(r, cpB, cpA)
	}
	if extra != nil {withCheckpoints(r,extra)}
	withLeases(r, leaseCreate(t, idA, hostA), leaseSuccessorBytes(t, idA, 2, leaseB, hostA, lease, checkpointDigestOf(t, cpB)))
	if ancestor {
		launchSequence, idleSequence := 2, 3
		if mode == "later_resume" || mode == "earlier_outside" {
			launchSequence, idleSequence = 4, 5
		}
		tail = appendEventAs(t, local, idA, tail, "provider.launched", launchSequence, 2, leaseB, rev8LaunchPayload("standard", changed))
		tail = appendEventAs(t, local, idA, tail, "session.idle", idleSequence, 2, leaseB, map[string]any{
			"boundary_ref":    "turn-2",
			"foreground_idle": true,
			"background_idle": true,
		})
		cp2 := rev7Replace(t, checkpoint(t, idA, 2, leaseB, hostA), "checkpoint_id", map[string]any{
			"event_heads": []string{tail},
		})
		withCheckpoints(r, cp2)
		withLeases(r, leaseSuccessorBytes(t, idA, 3, leaseCycleB, hostA, leaseB, checkpointDigestOf(t, cp2)))
		tail = appendEventAs(t, local, idA, tail, "lease.transferred", 1, 3, leaseCycleB, map[string]any{
			"operation_id":         hostB,
			"from_host_id":         hostA,
			"to_host_id":           hostA,
			"predecessor_lease_id": leaseB,
			"new_lease_id":         leaseCycleB,
		})
	}
	_ = tail
	return r
}


func TestReview13TemporalClosure(t *testing.T) {
 for _,kind:=range []string{"direct","task_board"}{for _,ancestor:=range []bool{false,true}{for _,mode:=range []string{"good","later_resume","same_outside","earlier_outside"}{
 t.Run(fmt.Sprintf("%s/ancestor=%t/%s",kind,ancestor,mode),func(t *testing.T){
 r:=review13TemporalFixture(t,kind,ancestor,mode)
 bad:=mode=="same_outside"||mode=="earlier_outside"
 if !bad {rev7CheckEntries(t,r,false);return}
 // Bind a genuine valid plan before substituting the invalid authority fixture.
 good:=review13TemporalFixture(t,kind,ancestor,"good")
 old:=mustBuild(t,good,PlanArgs{Selector:"alpha",Action:ActionStatus})
 if err:=r.Revalidate(old);err==nil{t.Error("old plan admitted changed invalid closure")}else{t.Logf("old-plan refusal: %v",err)}
 if _,err:=r.BuildPlan(PlanArgs{Selector:"alpha",Action:ActionStatus});!errors.Is(err,ErrObservationUnavailable){t.Errorf("BuildPlan class: %v",err)}
 rev7CheckEntries(t,r,true)
 })}}}
}
