package sessquery
import("testing";"os";"path/filepath";"runtime")
func TestReview13GateShapes(t *testing.T){
 _,file,_,_:=runtime.Caller(0)
 plants:=map[string]string{
 "interface":`package sessquery
func review13Interface(v any) string { return v.(validatedCheckpoint).Digest }`,
 "package_closure":`package sessquery
var review13Closure = func(v validatedCheckpoint) string { return v.Digest }`,
 "method_owner_name":`package sessquery
type review13Receiver struct{}
func (review13Receiver) admitCheckpoint(v validatedCheckpoint) string { return v.Digest }`,
 "field_assignment_forge":`package sessquery
func review13Forge(id,session,lease,host string,heads []string) admittedCheckpoint {
 var cp admittedCheckpoint
 cp.Digest=id; cp.SessionID=session; cp.LeaseID=lease; cp.LeaseEpoch=1; cp.CreatorHostID=host; cp.EventHeads=heads; cp.HasProviderManifest=true
 return cp
}`,
 "unresolved":`package sessquery
func review13Unresolved(){ missingReview13Callee() }`,
 }
 for name,plant:=range plants {t.Run(name,func(t *testing.T){dir:=t.TempDir();rev12CopyProductionSources(t,filepath.Dir(file),dir);if err:=os.WriteFile(filepath.Join(dir,"review13_plant.go"),[]byte(plant),0600);err!=nil{t.Fatal(err)};err:=rev12CheckRecordConsumptionSource(dir);if err==nil{t.Fatal("record-consumption gate admitted alternate path")}else{t.Log(err)}})}
}

func TestReview13LegacyPlant(t *testing.T){ _,file,_,_:=runtime.Caller(0);dir:=t.TempDir();rev12CopyProductionSources(t,filepath.Dir(file),dir);os.WriteFile(filepath.Join(dir,"review11_bypass.go"),[]byte("package sessquery\nimport (\n \"fmt\"\n \"github.com/relux-works/agent-session-manager/internal/sessrepo\"\n \"github.com/relux-works/agent-session-manager/internal/sessstate\"\n \"github.com/relux-works/agent-session-manager/internal/scalar\"\n)\nfunc review11UseUnchecked(checkpoint validatedCheckpoint, summary sessrepo.EventSummary, repo *sessrepo.Repository, checkpoints map[string]validatedCheckpoint) bool {\n payload, err := eventPayloadMembers(checkpoint,repo,summary);if err!=nil{return false}\n id,err:=leaseStringMember(payload,\"checkpoint_id\");if err!=nil{return false}\n copied,ok:=checkpoints[id]\n return ok && copied.CreatorHostID==\"0198f4c8-4a10-7b22-8b3c-1234567890ac\"\n}\nfunc review11UncheckedProfile(checkpoint validatedCheckpoint, summary sessrepo.EventSummary, creation, recordID string, events []sessrepo.EventSummary, checkpoints map[string]validatedCheckpoint, repo *sessrepo.Repository, chain []validatedLease, sessionKind string) (string, string, bool, map[string]bool, error) {\n\tpayload, err := eventPayloadMembers(checkpoint, repo, summary)\n\tif err != nil {\n\t\treturn \"\", \"\", false, nil, err\n\t}\n\trawID, err := leaseStringMember(payload, \"checkpoint_id\")\n\tif err != nil {\n\t\treturn \"\", \"\", false, nil, fmt.Errorf(\"%w: session %s event %s carries no valid resume checkpoint for profile authority: %v\", sessstate.ErrIntegrity, checkpoint.SessionID, summary.EventID, err)\n\t}\n\treference, err := scalar.ParseDigest(rawID)\n\tif err != nil {\n\t\treturn \"\", \"\", false, nil, fmt.Errorf(\"%w: session %s event %s carries malformed resume checkpoint %q for profile authority\", sessstate.ErrIntegrity, checkpoint.SessionID, summary.EventID, rawID)\n\t}\n\tcheckpointID := reference.String()\n\tref, ok := checkpoints[checkpointID]\n\tif !ok {\n\t\treturn \"\", \"\", false, nil, fmt.Errorf(\"%w: validated checkpoint %s for session %s cannot be established\", ErrObservationUnavailable, checkpointID, checkpoint.SessionID)\n\t}\n\tif ref.SessionID != checkpoint.SessionID {\n\t\treturn \"\", \"\", false, nil, fmt.Errorf(\"%w: validated checkpoint %s carries session %s, want %s\", ErrObservationUnavailable, checkpointID, ref.SessionID, checkpoint.SessionID)\n\t}\n\trefClosure, err := profileClosure(ref, recordID, events)\n\tif err != nil {\n\t\treturn \"\", \"\", false, nil, err\n\t}\n\trefSource, refProfile := \"\", \"\"\n\trefHas := false\n\tfor _, candidate := range events {\n\t\tif !refClosure[candidate.EventID] {\n\t\t\tcontinue\n\t\t}\n\t\tif candidate.EventType != \"profile.changed\" {\n\t\t\tcontinue\n\t\t}\n\t\ttarget, err := eventProfileTarget(checkpoint, repo, candidate)\n\t\tif err != nil {\n\t\t\treturn \"\", \"\", false, nil, err\n\t\t}\n\t\trefSource, refProfile, refHas = candidate.EventID, target, true\n\t}\n\tif !refHas {\n\t\treturn creation, \"\", false, refClosure, nil\n\t}\n\treturn refProfile, refSource, true, refClosure, nil\n}\n"),0600); if err:=rev12CheckRecordConsumptionSource(dir);err==nil{t.Fatal("legacy plant admitted")}else{t.Logf("legacy plant rejection: %v",err)}}
func TestReview13ZeroCapability(t *testing.T) {
 profile,_,err:=sessionCreationProfile(admittedCheckpoint{},record(t,idA,"alpha"))
 if err==nil { t.Fatalf("zero admittedCheckpoint derived creation profile %q without admission",profile) }
}
