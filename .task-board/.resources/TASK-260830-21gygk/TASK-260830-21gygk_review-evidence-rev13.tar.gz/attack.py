from pathlib import Path
import subprocess,json
p=Path(__file__).parent.resolve(); src=p/'probe'; lease=src/'internal/sessquery/lease.go';orig=lease.read_bytes(); helper=src/'internal/sessquery/review13_bypass.go'
plant='''package sessquery
type review13Receiver struct{}
func (review13Receiver) admitCheckpoint(raw validatedCheckpoint) (admittedCheckpoint,error) {
 var cp admittedCheckpoint
 cp.Digest=raw.Digest;cp.SessionID=raw.SessionID;cp.LeaseEpoch=raw.LeaseEpoch;cp.LeaseID=raw.LeaseID;cp.CreatorHostID=raw.CreatorHostID;cp.HasProviderManifest=raw.HasProviderManifest;cp.HasTaskBoardBundle=raw.HasTaskBoardBundle;cp.EventHeads=raw.EventHeads
 return cp,nil
}
'''
results=[]
def run(name,mask):
 cmd=['go','test','./internal/sessquery','-run',mask,'-count=1','-v']
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':cmd,'exit':r.returncode})
try:
 anchor='return checkReferencedCheckpointBinding(raw, checkpointID, sessionID, sessionKind, summary, chain, repo)'
 assert orig.decode().count(anchor)==1
 helper.write_text(plant)
 mutated=orig.decode().replace(anchor,'if raw.CreatorHostID == "0198f4c8-4a10-7b22-8b3c-1234567890ac" { return (review13Receiver{}).admitCheckpoint(raw) }\n\t\t'+anchor)
 lease.write_text(mutated);(p/'review13_bypass.go').write_text(plant);(p/'bypass-lease.go').write_text(mutated)
 run('reachable-census','^TestRev11RecordConsumptionCensus$')
 run('reachable-behavior','^(TestReview10ReferencedCheckpointAdmission|TestRev11ReferencedCheckpointAdmissionRefusalClass|TestRev11ReferencedCheckpointAdmissionOldPlan)$')
finally:
 lease.write_bytes(orig);helper.unlink(missing_ok=True)
try:
 lease.write_bytes(orig+b'\n// review13 applied harmless control\n')
 run('harmless-survivor','^(TestReview10ReferencedCheckpointAdmission|TestRev11ReferencedCheckpointAdmissionRefusalClass|TestRev11ReferencedCheckpointAdmissionOldPlan)$')
finally:lease.write_bytes(orig)
(p/'attack-results.json').write_text(json.dumps(results,indent=2));print(results)
