from pathlib import Path
p=Path(__file__).parent
s=(p/'probe/internal/sessquery/rev11_regression_test.go').read_text()
a=s.index('func review11TemporalFixture(');b=s.index('// TestRev12ReferencedCheckpointLaterLease',a)
f=s[a:b].replace('review11TemporalFixture','review13TemporalFixture')
f=f.replace('"later_resume":','"later_resume", "same_outside", "earlier_outside":')
f=f.replace('resumed := appendEvent', '''if mode == "same_outside" {
        branch := appendEvent(t, local, idA, stopped, "session.idle", next(), map[string]any{"boundary_ref":"sibling", "foreground_idle":true,"background_idle":true})
        extra = rev7Replace(t, checkpoint(t,idA,1,lease,hostA),"checkpoint_id",map[string]any{"event_heads":[]string{branch}})
        reference=checkpointDigestOf(t,extra)
    }
    resumed := appendEvent''')
f=f.replace('if mode == "later_resume" {','if mode == "later_resume" || mode == "earlier_outside" {')
f=f.replace('tail = appendEventAs(t, local, idA, tail, "session.resumed", 2, 2, leaseB, rev10ResumePayload(stoppedRef, "standard", changed))', '''laterRef := stoppedRef
        if mode == "earlier_outside" {
            branch := appendEvent(t,local,idA,stopped,"session.idle",next(),map[string]any{"boundary_ref":"earlier-owner-sibling","foreground_idle":true,"background_idle":true})
            extra=rev7Replace(t,checkpoint(t,idA,1,lease,hostA),"checkpoint_id",map[string]any{"event_heads":[]string{branch}})
            laterRef=checkpointDigestOf(t,extra)
        }
        tail = appendEventAs(t, local, idA, tail, "session.resumed", 2, 2, leaseB, rev10ResumePayload(laterRef, "standard", changed))''')
f=f.replace('withLeases(r, leaseCreate', 'if extra != nil {withCheckpoints(r,extra)}\n\twithLeases(r, leaseCreate')
t='''
func TestReview13TemporalClosure(t *testing.T) {
 for _,kind:=range []string{"direct","task_board"}{for _,ancestor:=range []bool{false,true}{for _,mode:=range []string{"good","later_resume","same_outside","earlier_outside"}{
 t.Run(fmt.Sprintf("%s/ancestor=%t/%s",kind,ancestor,mode),func(t *testing.T){
 r:=review13TemporalFixture(t,kind,ancestor,mode)
 bad:=mode=="same_outside"||mode=="earlier_outside"
 if !bad {rev7CheckEntries(t,r,false);return}
 // Bind a genuine valid plan before substituting the invalid authority fixture.
 good:=review13TemporalFixture(t,kind,ancestor,"good")
 old:=mustBuild(t,good,PlanArgs{Selector:"alpha",Action:ActionStatus})
 if err:=r.Revalidate(old);err==nil{t.Error("old plan admitted changed invalid closure")}else{t.Logf("old-plan refusal: %v",err)}
 if _,err:=r.BuildPlan(PlanArgs{Selector:"alpha",Action:ActionStatus});!errors.Is(err,ErrObservationUnavailable){t.Errorf("BuildPlan class: %v",err)}
 rev7CheckEntries(t,r,true)
 })}}}
}
'''
(p/'probe/internal/sessquery/review13_temporal_test.go').write_text('package sessquery\nimport("testing";"fmt";"errors")\n'+f+t)
