exec(open(__file__.replace('run_unapplied.py','audit.py')).read())
import re
selected={'N-checkpoint-holder','N-ancestor-holder','N-checkpoint-heads','N-profile-resume-missing'}
namespace=dict(env,results=[],output=p,copy=root,subprocess=subprocess,hashlib=hashlib,re=re)
namespace.update({name:root/path for name,path in paths.items()})
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='run')
exec(compile(ast.Module(body=[fn],type_ignores=[]),'<shipped-run>','exec'),namespace)
for n in tree.body:
 if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Name) and n.value.func.id=='run' and ast.literal_eval(n.value.args[0]) in selected:
  exec(compile(ast.Module(body=[n],type_ignores=[]),'<shipped-plant>','exec'),namespace)
(p/'shipped-not-applied.json').write_text(json.dumps(namespace['results'],indent=2));print(namespace['results'])
