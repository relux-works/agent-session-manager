# CR16 independent review reproduction

Candidate tree: 04c4902bb3d3070214812303920ade9da6f3e824.
Go 1.25.5 darwin/arm64; Python 3.14.7; Git 2.50.1.
Extract `git archive <tree>` into `source/` beside these scripts. Materialize the task's CR15 review archive into `prior/` and rev16 producer archive into `producer/` using task-board resource get.
Run `python3 direct_plants.py` first (it restores each applied plant), then `python3 probe.py`. The latter copies prior independent reviewer tests only into extracted source; all candidate product files remain unchanged. `direct-plants.json` and `exits.json` contain exact subprocess commands/exits. Run `python3 audit.py` in the original repository to compare producer internal source bytes and raw failed-test records with the immutable candidate. The only internal mismatch is TRACEABILITY.md, a post-run documentation update. README and LOGBOOK also differ; Go source/test/harness bytes match.

Reused producer mutation evidence remains in TASK-260830-21gygk_producer-evidence-rev16.tar.gz; it is referenced rather than duplicated. Relevant narrowing raw logs and classified audit are included here. No full independent repository/coverage/race or battery replay is claimed.
