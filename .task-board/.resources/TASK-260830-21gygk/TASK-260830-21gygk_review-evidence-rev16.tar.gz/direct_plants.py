from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;s=p/'source';d=s/'internal/sessquery';lease=d/'lease.go';base=lease.read_bytes();plant=d/'review15_plant.go';rows=[]
def run(name):
 cmd=['go','test','./internal/sessquery','-run','^TestRev11RecordConsumptionCensus$','-count=1','-v']
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT,timeout=120)
 rows.append(dict(name=name,command=cmd,exit=r.returncode));print(name,r.returncode,flush=True)
plants={
 'cr14-new-seal':'package sessquery\nfunc review15Mint() any { v:=new(checkpointSeal);v.token=new(checkpointSealToken);v.sessionID="invented";return v }',
 'generic-seal':'package sessquery\nfunc review15New[T any]() *T{return new(T)}\nfunc review15Mint() any{return review15New[checkpointSeal]()} ',
 'any-token':'package sessquery\nfunc review15Token(v any) any{return v.(*checkpointSealToken)}',
 'build-tag-seal':'//go:build review15_hidden\n\npackage sessquery\nfunc review15Mint() any{return new(checkpointSeal)}',
 'alias-seal':'package sessquery\ntype review15Alias = checkpointSeal\nfunc review15Mint() any{return new(review15Alias)}',
 'alias-token':'package sessquery\ntype review15Alias = checkpointSealToken\nfunc review15Mint() any{return new(review15Alias)}',
}
plants.update({
 'alias-pointer':'package sessquery\ntype review16Pointer = *checkpointSeal\nfunc review16Mint() any { var p review16Pointer; return p }',
 'alias-generic':'package sessquery\ntype review16Alias = checkpointSeal\nfunc review16New[T any]() *T{return new(T)}\nfunc review16Mint() any{return review16New[review16Alias]()} ',
 'alias-build-tag':'//go:build review16_hidden\n\npackage sessquery\ntype review16Alias = checkpointSeal\nfunc review16Mint() any{return new(review16Alias)}',
 'alias-array-channel':'package sessquery\ntype review16Alias = checkpointSealToken\ntype review16Array = [2]chan *review16Alias\nfunc review16Mint() any { var p review16Array; return p }',
})
for name,code in plants.items():
 try:plant.write_text(code);run(name)
 finally:plant.unlink(missing_ok=True)
anchor='ref, err := admission(checkpointID, authority.sessionID, summary)'
for name,expr,decl in [
 ('cr14-unknown-callback','review15Unknown','var review15Unknown checkpointAdmission'),
 ('field-callback','review15Callbacks.admit','var review15Callbacks struct { admit checkpointAdmission }')]:
 try:
  assert base.decode().count(anchor)==1
  lease.write_text(base.decode().replace(anchor,'ref, err := '+expr+'(checkpointID, authority.sessionID, summary)')+'\n'+decl+'\n');run(name)
 finally:lease.write_bytes(base)
try:
 lease.write_bytes(base+b'\n// Review15 applied harmless comment.\n');run('applied-harmless-survivor')
finally:lease.write_bytes(base)
(p/'direct-plants.json').write_text(json.dumps(rows,indent=2))
