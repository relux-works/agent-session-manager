from pathlib import Path
import json,re,collections,hashlib,subprocess
p=Path(__file__).resolve().parent;prod=p/'producer/mutants-rev16b';rows=json.loads((prod/'mutants.json').read_text());out=[]
for r in rows:
 f=prod/(r['mutant']+'.log');s=f.read_text() if f.exists() else '';failed=re.findall(r'^\s*--- FAIL: ([^ ]+)',s,re.M)
 out.append(dict(name=r['mutant'],classification=r['classification'],exit=r.get('exit'),failed=failed,log_present=f.exists(),matches=failed==r.get('failed_tests',[])))
copy=prod/'mutation-source';mismatch=[];n=0
for f in (copy/'internal').rglob('*'):
 if f.is_file():
  rel=f.relative_to(copy);n+=1;b=subprocess.run(['git','show','04c4902bb3d3070214812303920ade9da6f3e824:'+str(rel)],stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if b.returncode or b.stdout!=f.read_bytes():mismatch.append(str(rel))
a={'rows':out,'classes':dict(collections.Counter(r['classification'] for r in rows)),'files':n,'mismatches':mismatch,'patch_sha256':hashlib.sha256((p/'candidate.patch').read_bytes()).hexdigest()}
(p/'mutation-audit.json').write_text(json.dumps(a,indent=2));print(json.dumps({k:v for k,v in a.items() if k!='rows'},indent=2))
