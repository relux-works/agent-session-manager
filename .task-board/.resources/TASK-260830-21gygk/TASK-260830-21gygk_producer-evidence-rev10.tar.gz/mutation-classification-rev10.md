# Mutation classification (rev10 battery)

60 unique N/B plants (57 N, 3 B), all KILLED on the exact final
source through the shipped instrument
(`internal/sessquery/testdata/mutate.py`, run as 30 two-plant
slices). 43 semantic-admission plants (kill = behavioral admission
failure) and 17 label/class/output-precision plants (kill = wrong
label/class/order while refusal persists, or deterministic-order
reversal). The three classifier controls report separately and never
join the numerator. Base table: the CR9 independent reviewer's
inspected classification (56 plants: 39 semantic + 17 precision);
the 4 new rev10 plants are marked NEW (all semantic, all admission
kills with quoted lines below).

## Semantic admission (43)

| Plant | Named failing test |
|---|---|
| N-agreement-name | TestResolveBareIdentityUnion |
| N-ancestor-checkpoint | TestRev5AncestorCheckpointAuthority |
| N-ancestor-holder | TestRev5AncestorCheckpointBinding |
| N-capability-name | TestRev4UnknownCapabilityMustRefuse |
| N-case-variant | TestResolveExactNamesAndASCIICollisions |
| N-chain-self | TestSelfPredecessorWithCheckpointMustRefuse |
| N-checkpoint-holder | TestRev5CheckpointCreatorMustBeHolder |
| N-checkpoint-persistence | TestRev6CheckpointPersistenceMustMatchSession |
| N-checkpoint-placeholder | TestRev4MissingCheckpointMustRefuse |
| N-collision-pair | TestResolveExactNamesAndASCIICollisions |
| N-disallowed-admit | TestResolveExplicitSourceRefusals |
| N-dup-alias | TestSelectorConfigurationValidation |
| N-duplicate-peer | TestResolveAllowlistAndReadFailures |
| N-explicit-fallback | TestResolveQualifiedSourceNeverFallsBack |
| N-host-bound64 | TestAuthoritativeInputValidation |
| N-identity-diverge | TestResolveBareIdentityUnion |
| N-lease-missing | TestReviewerPlanRequiresLeaseRecord |
| N-local-prefix | TestParseSelectorLiteralGrammar |
| N-observation-capabilities | TestAuthoritativeMissingCapabilitiesRefuses |
| N-observation-host | TestAuthoritativeMissingHostMetadataRefuses |
| N-observation-process | TestAuthoritativeMissingProcessRefusesStatus |
| N-observation-workspace | TestAuthoritativeMissingWorkspaceRefuses |
| N-parked-id | TestParkedReadRecoveryAndMissingVsMalformed |
| N-parked-union-refusal | TestRevalidateUnionParkedCopyRefuses |
| N-peer-alias-fold | TestSelectorConfigurationValidation |
| N-profile-change-direction | TestRev8ProfileChangedPositiveControl |
| N-profile-first-source | TestRev8CheckpointProfileAuthority |
| N-profile-first-value (NEW) | TestRev10TaskBoardLaunchProfileAuthority, TestRev8ProfileSourceRefusals |
| N-profile-fork-value (NEW) | TestReview9ForkLocalProfile, TestRev10ForkLocalProfile, TestRev10ForkOldPlanSubstitution |
| N-profile-newest | TestRev8ProfileTwoGenerationControl |
| N-profile-resume-missing (NEW) | TestRev10ResumeReferencedCheckpoint, TestRev10ResumeReferencedWithdrawal |
| N-profile-resume-newest (NEW) | TestRev10ResumeReferencedCheckpoint |
| N-profile-value | TestRev8ProfileSourceRefusals |
| N-projection-failure-fallback | TestRevalidateDetectsEachFactChange |
| N-read-failure-fallback | TestRevalidateReadFailures |
| N-repository-case-variant | TestResolveLocalNameAndUUID |
| N-rev-config | TestRevalidateDetectsEachFactChange |
| N-rev-index | TestRevalidateDetectsEachFactChange |
| N-summary-bootstrap | TestCreatingSummaryCannotClaimClosedCLIResult |
| N-tombstoned-id | TestResolveExcludesTombstonedButListsIt |
| N-union-record | TestReviewerOtherSourceDivergenceMustRefuse |
| N-unknown-alias-local | TestResolveExplicitSourceRefusals |
| N-unlisted-peer | TestResolveAllowlistAndReadFailures |

## Label/class/output precision (17)

| Plant | Named failing test |
|---|---|
| B-peer-order | TestResolvePeerOrderAndReplicatedIdentity |
| B-session-order | TestListStatusDerivedFactsAndStableOrder |
| B-tie-break | TestResolveBareIdentityUnion |
| N-checkpoint-heads | TestRev7CheckpointHeadAuthority (wrong class via profile backstop) |
| N-first-at-split | TestParseSelectorLiteralGrammar |
| N-id-case | TestParseSelectorLiteralGrammar |
| N-id-through-names | TestResolveQualifiedNameBeforeUUIDInSource |
| N-plan-bootstrap | TestBuildPlanRecordOnlySessionRefusesBootstrap |
| N-plan-source-host | TestBuildPlanLocalSourceRequiresKnownHost |
| N-rev-absent-substitute | TestRevalidateDetectsEachFactChange |
| N-rev-binding | TestRevalidateDetectsEachFactChange |
| N-rev-heads | TestRevalidateDetectsEachFactChange |
| N-rev-lease | TestRevalidateDetectsEachFactChange |
| N-rev-record | TestRevalidateDetectsEachFactChange |
| N-rev-revocation | TestRevalidateDetectsEachFactChange |
| N-union-lease | TestRevalidateUnionLeaseDivergenceRefusesStale |
| N-union-tombstone | TestRevalidateUnionTombstoneRefusesStale |

## Classifier controls (separate, never counted)

| Control | Result |
|---|---|
| control-before / control-after (every slice) | exit 0 |
| C-harmless-comment (applied through the same instrument) | SURVIVED, exit 0 |
| C-not-applied | NOT_APPLIED |
| C-compile-failure | COMPILE_OR_HARNESS_FAILURE |

## New-plant admission lines (quoted from raw slice logs)

- N-profile-fork-value: `BuildPlan admitted corrupt profile
  authority; Revalidate=<nil>` (rev10 fork matrix), plus ported
  probe `BuildPlan admitted invalid lease/checkpoint authority`.
- N-profile-resume-missing: `BuildPlan admitted missing referenced
  authority; Revalidate=<nil>` (bad_missing x kind x ancestor);
  bad_missing_stale and withdrawal still refuse (class change on
  the complementary member, not admission).
- N-profile-resume-newest: `BuildPlan admitted corrupt profile
  authority; Revalidate=<nil>` (bad_non_newest x kind x ancestor).
- N-profile-first-value: `BuildPlan admitted corrupt profile
  authority; Revalidate=<nil>` (task_board bad_first_profile);
  rev8 first_wrong_profile shifts to the winner-mismatch stale
  refusal (complementary member behavior).
