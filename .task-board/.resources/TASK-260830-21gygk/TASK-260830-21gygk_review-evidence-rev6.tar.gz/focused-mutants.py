#!/usr/bin/env python3
"""Run isolated behavioral mutants; never modify the managed Story checkout.
Usage: python3 internal/sessquery/testdata/mutate.py /absolute/evidence/directory
Every subprocess runs directly, logs its real exit, and has a bounded timeout.
The battery proves each gate by narrowing, never by deletion: every N-
mutant keeps its gate present and weakens it to admit exactly one member
of the class the gate must reject, and a named behavioral test must fail.
Grammar mutants preserve the searched-for token while changing behavior,
and the harness always executes the behavioral suites.
"""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3tq4ns/worktree/.temp/TASK-260830-21gygk/review6/source')
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=True)
copy = output / 'mutation-source'
if copy.exists():
    raise SystemExit('refusing to overwrite an existing mutation source')
copy.mkdir()
shutil.copytree(root / 'internal', copy / 'internal')
for name in ('go.mod', 'go.sum', 'README.md', 'LOGBOOK.md'):
    shutil.copy2(root / name, copy / name)
source = copy / 'internal/sessquery/query.go'
base = source.read_text()
selector_source = copy / 'internal/sessquery/selector.go'
selector_base = selector_source.read_text()
revalidate_source = copy / 'internal/sessquery/revalidate.go'
revalidate_base = revalidate_source.read_text()
plan_source = copy / 'internal/sessquery/plan.go'
plan_base = plan_source.read_text()
summary_source = copy / 'internal/sessquery/summary.go'
summary_base = summary_source.read_text()
lease_source = copy / 'internal/sessquery/lease.go'
lease_base = lease_source.read_text()
repo_source = copy / 'internal/sessrepo/store.go'
repo_base = repo_source.read_text()
results = []

IDA = '0198f4c8-3e70-7a11-8a2b-1234567890ab'
IDB = '0198f4c8-3e70-7a11-8a2b-1234567890ac'
HOSTA = '0198f4c8-4a10-7b22-8b3c-1234567890ab'
HOSTB = '0198f4c8-4a10-7b22-8b3c-1234567890ac'
HOSTC = '0198f4c8-4a10-7b22-8b3c-1234567890ad'
LEASEB = 'bbbbbbbb-cccc-4ddd-8eee-ffffffffffff'

def run(name, path, old, new, narrow):
    original = path.read_text()
    if original.count(old) != 1:
        results.append(dict(mutant=name, classification='NOT_APPLIED', count=original.count(old), bound=narrow))
        return
    path.write_text(original.replace(old, new))
    command = ['go', 'test', './internal/sessquery', './internal/sessrepo', '-count=1', '-v']
    try:
        with (output / (name + '.log')).open('w') as log:
            process = subprocess.run(command, cwd=copy, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        text = (output / (name + '.log')).read_text()
        failures = re.findall(r'^\s*--- FAIL: ([^ ]+)', text, re.M)
        classification = 'SURVIVED' if process.returncode == 0 else ('KILLED' if failures else 'COMPILE_OR_HARNESS_FAILURE')
        results.append(dict(mutant=name, classification=classification, exit=process.returncode, failed_tests=failures, bound=narrow, command=command))
        print(name, classification, process.returncode, ', '.join(failures), flush=True)
    finally:
        path.write_text(original)
        assert hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(original.encode()).digest()

with (output / 'control-before.log').open('w') as log:
    before = subprocess.run(['go','test','./internal/sessquery','./internal/sessrepo','-count=1'],cwd=copy,stdout=log,stderr=subprocess.STDOUT,timeout=180)
results.append(dict(mutant='control-before', classification='CONTROL', exit=before.returncode))
if before.returncode:
    raise SystemExit('baseline failed')
run('N-chain-self',lease_source,'\t\tparent, ok := byLease[current.Predecessor]\n\t\tif !ok {','\t\tparent, ok := byLease[current.Predecessor]\n\t\tif ok && parent.LeaseID == current.LeaseID {\n\t\t\treturn parent, nil\n\t\t}\n\t\tif !ok {','Admit exactly the self-predecessor link while terminating the walk; skipped-epoch and cyclic links still refuse integrity_failure.')
run('N-ancestor-checkpoint',lease_source,'\tfor index := 1; index < len(chain); index++ {\n\t\tcurrent := chain[index]\n','\tfor index := 1; index < len(chain); index++ {\n\t\tcurrent := chain[index]\n\t\tif current.LeaseID == "' + LEASEB + '" {\n\t\t\tcontinue\n\t\t}\n','Admit exactly the leaseB ancestor past the winning-ancestry checkpoint gate; a missing, misbound, or wrong-creator ancestor checkpoint still refuses observation_unavailable.')
run('N-checkpoint-holder',lease_source,'\tif checkpoint.CreatorHostID != owner.HolderHostID {\n\t\treturn fmt.Errorf("%w: validated checkpoint %s is created by host %s, want owning lease holder %s", ErrObservationUnavailable, winner.Checkpoint, checkpoint.CreatorHostID, owner.HolderHostID)\n\t}\n','\tif checkpoint.CreatorHostID != owner.HolderHostID && checkpoint.CreatorHostID != "' + HOSTB + '" {\n\t\treturn fmt.Errorf("%w: validated checkpoint %s is created by host %s, want owning lease holder %s", ErrObservationUnavailable, winner.Checkpoint, checkpoint.CreatorHostID, owner.HolderHostID)\n\t}\n','Admit exactly a hostB-created checkpoint past the winner holder gate; other wrong-holder checkpoints still refuse observation_unavailable.')
run('N-ancestor-holder',lease_source,'\tif checkpoint.CreatorHostID != owner.HolderHostID {\n\t\treturn fmt.Errorf("%w: validated checkpoint %s is created by host %s, want owning lease holder %s", ErrObservationUnavailable, current.Checkpoint, checkpoint.CreatorHostID, owner.HolderHostID)\n\t}\n','\tif checkpoint.CreatorHostID != owner.HolderHostID && checkpoint.CreatorHostID != "' + HOSTB + '" {\n\t\treturn fmt.Errorf("%w: validated checkpoint %s is created by host %s, want owning lease holder %s", ErrObservationUnavailable, current.Checkpoint, checkpoint.CreatorHostID, owner.HolderHostID)\n\t}\n','Admit exactly a hostB-created checkpoint past the ancestor holder gate; other wrong-holder ancestor checkpoints still refuse observation_unavailable.')
run('C-harmless-comment',lease_source,'// checkLeaseChain validates the winner','// checkLeaseChain validates the winner\n// classifier control: comment only, no behavior change.','Applied control: a behavior-preserving plant survives through the same instrument.')
with (output / 'control-after.log').open('w') as log:
    after = subprocess.run(['go','test','./internal/sessquery','./internal/sessrepo','-count=1'],cwd=copy,stdout=log,stderr=subprocess.STDOUT,timeout=180)
results.append(dict(mutant='control-after',classification='CONTROL', exit=after.returncode))
assert source.read_text() == base and selector_source.read_text() == selector_base and revalidate_source.read_text() == revalidate_base and plan_source.read_text() == plan_base and summary_source.read_text() == summary_base and lease_source.read_text() == lease_base and repo_source.read_text() == repo_base
(output / 'mutants.json').write_text(json.dumps(results,indent=2)+'\n')
# Controls are reported separately from the applied behavioral denominator.
bad = [row for row in results if row['mutant'].startswith(('N-','B-')) and row['classification'] != 'KILLED']
raise SystemExit(1 if bad or after.returncode else 0)
