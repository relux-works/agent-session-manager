package sessquery

import (
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

// TestRev14CapabilitySeal proves that the profile derivation boundary does
// not treat a zero or field-assembled admittedCheckpoint as authority. The
// product entry points are intentionally exercised directly here because a
// missing seal must fail before any repository or event read can occur.
func TestRev14CapabilitySeal(t *testing.T) {
	recordBytes := record(t, idA, "alpha")
	forged := admittedCheckpoint{
		seal: &checkpointSeal{
			digest:              "sha256:1111111111111111111111111111111111111111111111111111111111111111",
			sessionID:           idA,
			leaseEpoch:          1,
			leaseID:             lease,
			creatorHostID:       hostA,
			hasProviderManifest: true,
			eventHeads:          []string{zeroDigest},
		},
	}
	entries := map[string]func(admittedCheckpoint) error{
		"checkCheckpointProfileAuthority": func(checkpoint admittedCheckpoint) error {
			return checkCheckpointProfileAuthority(checkpoint, nil, nil)
		},
		"sessionCreationProfile": func(checkpoint admittedCheckpoint) error {
			_, _, err := sessionCreationProfile(checkpoint, recordBytes)
			return err
		},
		"profileClosure": func(checkpoint admittedCheckpoint) error {
			_, err := profileClosure(checkpoint, zeroDigest, nil)
			return err
		},
		"eventProfilePair": func(checkpoint admittedCheckpoint) error {
			_, err := eventProfilePair(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"eventProfileTarget": func(checkpoint admittedCheckpoint) error {
			_, err := eventProfileTarget(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"eventPayloadMembers": func(checkpoint admittedCheckpoint) error {
			_, err := eventPayloadMembers(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"checkClosureProfilePairs": func(checkpoint admittedCheckpoint) error {
			return checkClosureProfilePairs(checkpoint, "standard", zeroDigest, nil, nil, nil, nil)
		},
		"referencedCheckpointProfile": func(checkpoint admittedCheckpoint) error {
			_, _, _, _, err := referencedCheckpointProfile(checkpoint, sessrepo.EventSummary{}, "standard", zeroDigest, nil, nil, nil)
			return err
		},
		"checkProfilePairSource": func(checkpoint admittedCheckpoint) error {
			return checkProfilePairSource(checkpoint, sessrepo.EventSummary{}, profilePair{}, "standard", "", false, nil, nil)
		},
	}
	for name, entry := range entries {
		for label, checkpoint := range map[string]admittedCheckpoint{
			"zero":   {},
			"forged": forged,
		} {
			t.Run(fmt.Sprintf("%s/%s", name, label), func(t *testing.T) {
				err := entry(checkpoint)
				if err == nil {
					t.Fatalf("%s accepted an unsealed checkpoint", label)
				}
				if !errors.Is(err, ErrObservationUnavailable) {
					t.Fatalf("%s refusal = %v, want observation_unavailable", label, err)
				}
			})
		}
	}
}

// TestRev14RecordConsumptionCensusRejectsAlternatePaths expands the
// package-wide type gate with plants that preserve reviewer-visible tokens
// while changing the authority object or construction path. A plant is
// accepted only if the same production census rejects it.
func TestRev14RecordConsumptionCensusRejectsAlternatePaths(t *testing.T) {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		t.Fatal("cannot locate test file")
	}
	packageDir := filepath.Dir(file)
	plants := map[string]string{
		"interface_assertion.go": `package sessquery

func review14Interface(v any) string { return v.(validatedCheckpoint).Digest }
`,
		"package_closure.go": `package sessquery

var review14Closure = func(v validatedCheckpoint) string { return v.Digest }
`,
		"unresolvable_callee.go": `package sessquery

func review14Unresolved() { missingReview14Callee() }
`,
		"method_named_admit.go": `package sessquery

type review14Receiver struct{}

func (review14Receiver) admitCheckpoint(v validatedCheckpoint) (admittedCheckpoint, error) {
		return admittedCheckpoint{}, nil
}
`,
		"method_raw_only.go": `package sessquery

type review14RawReceiver struct{}

func (review14RawReceiver) admitCheckpoint(v validatedCheckpoint) string {
		return v.Digest
}
`,
		"field_assembly.go": `package sessquery

func review14FieldAssembly(raw validatedCheckpoint) admittedCheckpoint {
		var checkpoint admittedCheckpoint
		checkpoint.seal = &checkpointSeal{digest: raw.Digest, sessionID: raw.SessionID}
		return checkpoint
}
`,
		"embedding.go": `package sessquery

type review14Embedding struct{ admittedCheckpoint }
`,
		"raw_copy.go": `package sessquery

func review14RawCopy(raw validatedCheckpoint) admittedCheckpoint {
		var checkpoint admittedCheckpoint
		checkpoint.seal = &checkpointSeal{digest: raw.Digest, sessionID: raw.SessionID}
		return checkpoint
}
`,
		"capability_map.go": `package sessquery

var review14Capabilities = map[string]admittedCheckpoint{}

func review14Populate(raw validatedCheckpoint) {
		var checkpoint admittedCheckpoint
		checkpoint.seal = &checkpointSeal{digest: raw.Digest, sessionID: raw.SessionID}
		review14Capabilities[raw.Digest] = checkpoint
}
`,
	}
	for name, plant := range plants {
		t.Run(name, func(t *testing.T) {
			dir := t.TempDir()
			rev12CopyProductionSources(t, packageDir, dir)
			if err := os.WriteFile(filepath.Join(dir, name), []byte(plant), 0o600); err != nil {
				t.Fatal(err)
			}
			if err := rev12CheckRecordConsumptionSource(dir); err == nil {
				t.Fatalf("record-consumption gate admitted %s", name)
			} else {
				t.Logf("rejected %s: %v", name, err)
			}
		})
	}
}
