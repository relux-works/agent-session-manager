package sessquery

import (
 "encoding/json"
 "testing"
)

// The direct Session Record must select the provider persistence variant,
// including in the ancestor checkpoint which establishes the winning lease.
func TestRev6CheckpointPersistenceMustMatchSession(t *testing.T) {
 for _, ancestor := range []bool{false, true} {
  path := "winner"; if ancestor { path = "ancestor" }
  for _, wrong := range []bool{false, true} {
   mode := "direct_control"; if wrong { mode = "task_board_checkpoint_for_direct_session" }
   t.Run(path+"/"+mode, func(t *testing.T) {
    good := checkpointRecordBytes(t,idA,1,lease,hostA)
    cp := good
    if wrong {
     var value map[string]any
     if err:=json.Unmarshal(good,&value);err!=nil {t.Fatal(err)}
     value["task_board_bundle_id"] = value["provider_manifest_id"]
     value["provider_manifest_id"] = nil
     cp = identity(t,value,"checkpoint_id")
    }
    var r *Reader
    if ancestor {
     r = rev5AncestorFixture(t,good)
     old := mustBuild(t,r,PlanArgs{Selector:"alpha",Action:ActionStatus})
     if wrong {
      // Preserve the winner digest and event bytes; alter only the
      // ancestor's checkpoint variant, retaining canonical identities.
      r.CheckpointRecords[0]=cp
      for i,raw:=range r.LeaseRecords {
       var value map[string]any
       if err:=json.Unmarshal(raw,&value);err!=nil {t.Fatal(err)}
       if value["lease_id"]==leaseB {
        value["checkpoint_id"]=checkpointDigestOf(t,cp)
        r.LeaseRecords[i]=identity(t,value,"record_id")
       }
      }
      if err:=r.Revalidate(old);err==nil {t.Error("old-plan Revalidate admits wrong persistence variant in necessary ancestor")}
     }
    } else {
     r=successorFixture(t)
     withCheckpoints(r,cp)
     withLeases(r,leaseSuccessorBytes(t,idA,2,leaseB,hostA,lease,checkpointDigestOf(t,cp)))
    }
    rev5CheckEntries(t,r,wrong)
   })
  }
 }
}
