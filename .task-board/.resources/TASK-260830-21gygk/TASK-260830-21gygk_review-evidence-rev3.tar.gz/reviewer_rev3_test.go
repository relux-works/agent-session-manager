package sessquery

import (
 "encoding/json"
 "errors"
 "strings"
 "testing"
 "github.com/relux-works/agent-session-manager/internal/canonicaljson"
)

func realReviewLease(t *testing.T) string {
 t.Helper()
 raw := identity(t, map[string]any{
 "schema":"urn:ax:schema:lease", "schema_version":"1.0.0", "record_id":zeroDigest,
 "subject_id":idA,"session_id":idA,"lease_id":lease,"epoch":1,"holder_host_id":hostA,
 "predecessor_lease_id":nil,"reason":"create","checkpoint_id":nil,
 "issued_by_host_id":hostA,"created_by_host_id":hostA,"created_at":"2026-08-19T04:00:00.000Z","extensions":map[string]any{},
 }, "record_id")
 digest, _, err := canonicaljson.VerifyObjectIdentity(raw)
 if err != nil { t.Fatal(err) }
 t.Logf("real validated Lease Record: %s", raw)
 return digest.String()
}

// There is no supported Lease Record input on Reader/Repository. This
// independent validated fixture is the required identity oracle, not a claim
// that putting arbitrary bytes in an invented storage path integrates it.
func TestRev3RealLeaseRecordIdentity(t *testing.T) {
 expected := realReviewLease(t)
 reader, _, _, _ := plannedSession(t)
 plan := mustBuild(t, reader, PlanArgs{Selector:"alpha", Action:ActionStatus})
 if plan.LeaseRecordID != expected { t.Fatalf("BuildPlan lease_record_id=%s; real Lease Record=%s",plan.LeaseRecordID,expected) }
}
func TestRev3DifferentAttestationMustNotAuthorize(t *testing.T) {
 expected := realReviewLease(t)
 reader, _, _, _ := plannedSession(t)
 plan := mustBuild(t, reader, PlanArgs{Selector:"alpha", Action:ActionStatus})
 if plan.LeaseRecordID == expected { t.Fatal("probe premise requires the different envelope attestation") }
 wire, err := plan.Marshal(); if err != nil {t.Fatal(err)}
 parsed, err := ParsePlan(wire); if err != nil {t.Fatal(err)}
 if err := reader.Revalidate(parsed); err == nil { t.Fatal("Revalidate accepted envelope attestation without any validated Lease Record") }
}
func TestRev3UnknownRequiredObservationsRefuse(t *testing.T) {
 reader := summaryReader(t)
 t.Run("status",func(t *testing.T){
  got,err := reader.AuthoritativeStatus("alpha")
  if !errors.Is(err,ErrObservationUnavailable) { t.Fatalf("status with absent process/workspace/capability observations: %+v err=%v",got,err) }
 })
 t.Run("list",func(t *testing.T){
  got,err := reader.AuthoritativeList()
  if !errors.Is(err,ErrObservationUnavailable) || got != nil {t.Fatalf("list with absent required summary observations returned %d rows, err=%v",len(got),err)}
 })
}
func TestRev3HostNameBound64(t *testing.T) {
 reader := summaryReader(t)
 reader.HostMetadata[hostA] = HostMetadata{DisplayName:strings.Repeat("x",65)}
 if _,err := reader.AuthoritativeStatus("alpha"); err == nil { t.Fatal("authoritative summary admits 65-rune owner_host_name, public bound is 64") }
}
func TestRev3BuildWithLaggingLeaseCopy(t *testing.T) {
 local,_ := repository(t); peer,_ := repository(t)
 ref:=leasedPeerSession(t,local,idB,"beta")
 events,err:=local.ListEvents(idB); if err!=nil {t.Fatal(err)}
 launched:=appendEvent(t,local,idB,events[0].EventID,"provider.launched",2,map[string]any{"provider_id":"codex","provider_version":"0.147.0","execution_profile":"yolo","profile_source_event_id":nil,"profile_mapping":"default"})
 appendEventAs(t,local,idB,launched,"lease.transferred",1,2,leaseB,map[string]any{"operation_id":hostB,"from_host_id":hostA,"to_host_id":hostA,"predecessor_lease_id":lease,"new_lease_id":leaseB})
 leasedPeerSession(t,peer,idB,"beta")
 reader:=unionReader(t,local,peer)
 plan,err:=reader.BuildPlan(PlanArgs{Selector:"beta@local",Action:ActionStatus})
 if err!=nil {t.Fatalf("fresh BuildPlan refuses valid epoch-2 winner alongside epoch-1 lagging copy: %v (record=%s)",err,ref.RecordID)}
 if plan.LeaseEpoch != 2 {t.Fatalf("winner epoch=%d",plan.LeaseEpoch)}
 if err:=reader.Revalidate(plan);err!=nil {t.Fatal(err)}
}
func TestRev3SummaryClosedFieldsDiagnostic(t *testing.T) {
 reader:=summaryReader(t); got,err:=reader.AuthoritativeStatus("alpha");if err!=nil {t.Fatal(err)}
 raw,_:=json.Marshal(got); t.Log(string(raw))
}
