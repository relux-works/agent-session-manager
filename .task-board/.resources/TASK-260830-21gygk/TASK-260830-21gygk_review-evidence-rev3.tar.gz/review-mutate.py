#!/usr/bin/env python3
"""Run isolated behavioral mutants; never modify the managed Story checkout.
Usage: python3 internal/sessquery/testdata/mutate.py /absolute/evidence/directory
Every subprocess runs directly, logs its real exit, and has a bounded timeout.
The battery proves each gate by narrowing, never by deletion: every N-
mutant keeps its gate present and weakens it to admit exactly one member
of the class the gate must reject, and a named behavioral test must fail.
Grammar mutants preserve the searched-for token while changing behavior,
and the harness always executes the behavioral suites.
"""
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent / 'candidate'
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=True)
copy = output / 'mutation-source'
if copy.exists():
    raise SystemExit('refusing to overwrite an existing mutation source')
copy.mkdir()
shutil.copytree(root / 'internal', copy / 'internal')
for name in ('go.mod', 'go.sum', 'README.md', 'LOGBOOK.md'):
    shutil.copy2(root / name, copy / name)
source = copy / 'internal/sessquery/query.go'
base = source.read_text()
selector_source = copy / 'internal/sessquery/selector.go'
selector_base = selector_source.read_text()
revalidate_source = copy / 'internal/sessquery/revalidate.go'
revalidate_base = revalidate_source.read_text()
plan_source = copy / 'internal/sessquery/plan.go'
plan_base = plan_source.read_text()
summary_source = copy / 'internal/sessquery/summary.go'
summary_base = summary_source.read_text()
repo_source = copy / 'internal/sessrepo/store.go'
repo_base = repo_source.read_text()
results = []

IDA = '0198f4c8-3e70-7a11-8a2b-1234567890ab'
IDB = '0198f4c8-3e70-7a11-8a2b-1234567890ac'
HOSTA = '0198f4c8-4a10-7b22-8b3c-1234567890ab'
HOSTB = '0198f4c8-4a10-7b22-8b3c-1234567890ac'
HOSTC = '0198f4c8-4a10-7b22-8b3c-1234567890ad'
LEASEB = 'bbbbbbbb-cccc-4ddd-8eee-ffffffffffff'

def run(name, path, old, new, narrow):
    original = path.read_text()
    if original.count(old) != 1:
        results.append(dict(mutant=name, classification='NOT_APPLIED', count=original.count(old), bound=narrow))
        return
    path.write_text(original.replace(old, new))
    command = ['go', 'test', './internal/sessquery', './internal/sessrepo', '-count=1', '-v']
    try:
        with (output / (name + '.log')).open('w') as log:
            process = subprocess.run(command, cwd=copy, stdout=log, stderr=subprocess.STDOUT, timeout=180)
        text = (output / (name + '.log')).read_text()
        failures = re.findall(r'^\s*--- FAIL: ([^ ]+)', text, re.M)
        classification = 'SURVIVED' if process.returncode == 0 else ('KILLED' if failures else 'COMPILE_OR_HARNESS_FAILURE')
        results.append(dict(mutant=name, classification=classification, exit=process.returncode, failed_tests=failures, bound=narrow, command=command))
        print(name, classification, process.returncode, ', '.join(failures), flush=True)
    finally:
        path.write_text(original)
        assert hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(original.encode()).digest()


run('C-harmless-comment', source, 'package sessquery', '// Review classifier control.\npackage sessquery', 'Harmless applied comment must survive.')
run('N-record-nonempty', revalidate_source, 'if recordID != plan.SessionRecordID {', 'if recordID != plan.SessionRecordID && !(plan.SessionID == "' + IDA + '" && recordID != "") {', 'Admit a validated nonempty changed immutable record for idA; parked empty records still refuse.')
run('N-observation-host', summary_source, 'metadata, ok := reader.HostMetadata[projection.OwnerHostID]\n\tif !ok {', 'metadata, ok := reader.HostMetadata[projection.OwnerHostID]\n\tif !ok && projection.OwnerHostID != "' + HOSTA + '" {', 'Admit one owner without host metadata; other owners still refuse.')
(output / 'review-mutants.json').write_text(json.dumps(results, indent=2)+'\n')
