# CR8 review reproduction

1. In the repository, archive tree 5102e49fe89c9bb6d085f45b7b4ea3a392422a25 into a new ignored scratch directory (git archive TREE | tar -x -C DIR). Do not apply the probe to the active candidate.
2. Copy reviewer_rev8_test.go to DIR/internal/sessquery/reviewer_rev8_test.go.
3. From DIR run go test ./internal/sessquery -run '^TestRev8CheckpointProfileAuthority$' -count=1 -v. Expected current-candidate exit: 1, with four passing controls and four failing invalid-source cases.
4. Remove only that copied reviewer file before baseline/mutation checks. Run go test ./internal/sessquery -run '^TestRev7' -count=1 -v (exit 0).
5. focused_mutants.py retains the shipped harness/plant definitions and filters the eight affected lease plants plus applied harmless comment. Its root assignment is absolute to this review archive; change only that root to DIR before rerunning with a fresh output directory. No active product edits are made by that harness.

profile-probe.log is the intentionally failing review regression, not a production test pass. checks.json records independent baseline checks and actual exits; full-verbose.exit records the complete verbose baseline suite. source-comparison.json compares all internal bytes to Git blobs and retained producer mutation copies. Producer differences are TRACEABILITY.md and a comment-only header on rev7_regression_test.go; current independent mutations run on exact candidate bytes.
