package sessquery
import("testing"; "fmt")
func rev8ProfileFixture(t *testing.T, kind string, ancestor bool, bad bool) (*Reader, string) {
	t.Helper()
	local, _ := repository(t)
	raw := record(t, idA, "alpha")
	if kind == "task_board" {
		raw = taskBoardRecordBytes(t, idA, "alpha")
	}
	ref, err := local.CreateSession(raw)
	if err != nil {
		t.Fatal(err)
	}
	created := appendEvent(t, local, idA, ref.RecordID, "session.created", 1, map[string]any{"session_record_id": ref.RecordID, "bootstrap_operation_id": hostA, "first_checkpoint_operation_id": hostB})
	var source any
	if bad { source = zeroDigest }
	launched := appendEvent(t, local, idA, created, "provider.launched", 2, map[string]any{"provider_id": "codex", "provider_version": "0.147.0", "execution_profile": "yolo", "profile_source_event_id": source, "profile_mapping": "default"})
	idle := appendEvent(t, local, idA, launched, "session.idle", 3, map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true})
	cp := checkpointRecordBytes(t, idA, 1, lease, hostA)
	if kind == "task_board" {
		cp = taskBoardCheckpointBytes(t, idA, 1, lease, hostA)
	}
	cp = rev7Replace(t, cp, "checkpoint_id", map[string]any{"event_heads": []string{idle}})
	r := &Reader{Local: local, LocalHostID: hostA}
	withCheckpoints(r, cp)
	withLeases(r, leaseCreate(t, idA, hostA), leaseSuccessorBytes(t, idA, 2, leaseB, hostA, lease, checkpointDigestOf(t, cp)))
	announced := appendEvent(t, local, idA, idle, "checkpoint.created", 4, map[string]any{"checkpoint_id": checkpointDigestOf(t, cp), "kind": "manual"})
	tail := appendEventAs(t, local, idA, announced, "lease.transferred", 1, 2, leaseB, map[string]any{"operation_id": hostB, "from_host_id": hostA, "to_host_id": hostA, "predecessor_lease_id": lease, "new_lease_id": leaseB})
	if ancestor {
		tail = appendEventAs(t, local, idA, tail, "provider.launched", 2, 2, leaseB, map[string]any{"provider_id": "codex", "provider_version": "0.147.0", "execution_profile": "yolo", "profile_source_event_id": nil, "profile_mapping": "default"})
		tail = appendEventAs(t, local, idA, tail, "session.idle", 3, 2, leaseB, map[string]any{"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true})
		cp2 := checkpointRecordBytes(t, idA, 2, leaseB, hostA)
		if kind == "task_board" {
			cp2 = taskBoardCheckpointBytes(t, idA, 2, leaseB, hostA)
		}
		cp2 = rev7Replace(t, cp2, "checkpoint_id", map[string]any{"event_heads": []string{tail}})
		withCheckpoints(r, cp2)
		withLeases(r, leaseSuccessorBytes(t, idA, 3, leaseCycleB, hostA, leaseB, checkpointDigestOf(t, cp2)))
		tail = appendEventAs(t, local, idA, tail, "lease.transferred", 1, 3, leaseCycleB, map[string]any{"operation_id": hostB, "from_host_id": hostA, "to_host_id": hostA, "predecessor_lease_id": leaseB, "new_lease_id": leaseCycleB})
	}
	return r, tail
}

func TestRev8CheckpointProfileAuthority(t *testing.T) {
 for _, kind := range []string{"direct", "task_board"} {
  for _, ancestor := range []bool{false,true} {
   for _, bad := range []bool{false,true} {
    t.Run(fmt.Sprintf("%s/ancestor=%t/missing_source=%t",kind,ancestor,bad),func(t *testing.T){
      r,_:=rev8ProfileFixture(t,kind,ancestor,bad)
      rev7CheckEntries(t,r,bad)
    })
   }
  }
 }
}
