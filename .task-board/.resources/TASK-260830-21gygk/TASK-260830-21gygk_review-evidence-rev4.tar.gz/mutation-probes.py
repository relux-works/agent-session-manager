import ast,hashlib,json,pathlib,re,subprocess
p=pathlib.Path(__file__).resolve().parent
copy=p/'candidate';output=p/'mutation-probes';output.mkdir(exist_ok=True)
source=copy/'internal/sessquery/revalidate.go';script=(copy/'internal/sessquery/testdata/mutate.py').read_text()
node=next(n for n in ast.parse(script).body if isinstance(n,ast.FunctionDef) and n.name=='run')
function=ast.get_source_segment(script,node);(output/'exact-run-function.py').write_text(function)
results=[]
exec(function)
run('C-harmless-comment',source,'package sessquery','package sessquery\n// Reviewer harmless survivor control.','Same instrument must classify an applied harmless change SURVIVED.')
run('N-record-nonempty',source,'if recordID != plan.SessionRecordID {','if recordID != plan.SessionRecordID && !(recordID != "" && plan.SessionID == "0198f4c8-3e70-7a11-8a2b-1234567890ab") {','Narrow selected record guard to admit a changed nonempty record for idA.')
run('N-observation-host',copy/'internal/sessquery/summary.go','if !ok {\n\t\treturn AuthoritativeSummary{}, fmt.Errorf("%w: host metadata','if !ok && lease.HolderHostID != "0198f4c8-4a10-7b22-8b3c-1234567890ab" {\n\t\treturn AuthoritativeSummary{}, fmt.Errorf("%w: host metadata','Admit exactly hostA missing metadata; behavioral suite must fail.')
(output/'results.json').write_text(json.dumps(results,indent=2))
# Measure subsumption using a valid changed live record and the same narrowing.
probe=copy/'internal/sessquery/reviewer_rev4_test.go';probe.write_bytes((p/'reviewer_rev4_test.go').read_bytes())
original=source.read_text();source.write_text(original.replace('if recordID != plan.SessionRecordID {','if recordID != plan.SessionRecordID && !(recordID != "" && plan.SessionID == "0198f4c8-3e70-7a11-8a2b-1234567890ab") {'))
try:
 with (output/'live-record-subsumption.log').open('w') as log:
  x=subprocess.run(['go','test','./internal/sessquery','-count=1','-v','-run','^TestRev4ChangedLiveRecordRefuses$'],cwd=copy,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 print('live-record-subsumption exit',x.returncode)
finally:
 source.write_text(original);probe.unlink()
