package sessquery
import (
 "testing"
 "encoding/json"
)
func TestReviewerOtherSourceDivergenceMustRefuse(t *testing.T) {
 local,_:=repository(t); peer,_:=repository(t)
 ref:=create(t,peer,idB,"beta")
 appendEvent(t,peer,idB,ref.RecordID,"session.created",1,map[string]any{"session_record_id":ref.RecordID,"bootstrap_operation_id":hostA,"first_checkpoint_operation_id":hostB})
 reader:=&Reader{Local:local,LocalHostID:hostB,AllowlistedPeerIDs:[]string{hostA},Peers:[]PeerIndex{{HostID:hostA,Repo:peer}}}
 plan:=mustBuild(t,reader,PlanArgs{Selector:"id:"+idB,Action:ActionStatus})
 if err:=reader.Revalidate(plan);err!=nil {t.Fatal(err)}
 create(t,local,idB,"different-record")
 if _,err:=reader.Resolve("id:"+idB);err==nil {t.Fatal("diagnostic premise: expected record divergence") } else {t.Logf("fresh Resolve: %v",err)}
 if err:=reader.Revalidate(plan);err==nil {t.Fatal("Revalidate accepted conflicting immutable record for the selected UUID in another allowed source")}
}
func TestReviewerBootstrapSummaryMustRefuse(t *testing.T) {
 local,_:=repository(t);create(t,local,idA,"alpha")
 reader:=&Reader{Local:local,LocalHostID:hostA}
 t.Run("list",func(t *testing.T){rows,err:=reader.List();if err==nil {t.Fatalf("List accepted record-only bootstrap: rows=%d epoch=%d owner=%q",len(rows),rows[0].Projection.Winner.Epoch,rows[0].Projection.OwnerHostID)}})
 t.Run("status",func(t *testing.T){row,err:=reader.Status("alpha");if err==nil {t.Fatalf("Status accepted record-only bootstrap: epoch=%d owner=%q",row.Projection.Winner.Epoch,row.Projection.OwnerHostID)}})
}
func TestReviewerPlanRequiresLeaseRecord(t *testing.T) {
 reader,_,_,_:=plannedSession(t);reader.LocalHostID=hostA
 plan:=mustBuild(t,reader,PlanArgs{Selector:"alpha",Action:ActionStatus})
 raw,err:=plan.Marshal();if err!=nil {t.Fatal(err)}
 var fields map[string]any;if err:=json.Unmarshal(raw,&fields);err!=nil {t.Fatal(err)}
 if _,ok:=fields["lease_record_id"];!ok {t.Fatal("plan omits required validated lease_record_id")}
}
