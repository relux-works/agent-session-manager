# TASK-260830-21gygk — Mutation classification (rev11)

Battery: 63 unique N/B plants (60 N, 3 B): 46 semantic-admission, 17 precision.
New plants (3, full-suite kills via shipped harness slices, same instrument):

## N-referenced-creator — KILLED (exit 1, behavioral admission)
- Log: `.temp/TASK-260830-21gygk/mutants-rev11/slice1_out/N-referenced-creator.log` (subprocess exit 1)
- Failed tests (15): TestReview10ReferencedCheckpointAdmission, TestReview10ReferencedCheckpointAdmission/direct/ancestor=false/wrong_creator, TestReview10ReferencedCheckpointAdmission/direct/ancestor=true/wrong_creator, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=false/wrong_creator, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=true/wrong_creator, TestRev11ReferencedCheckpointAdmissionRefusalClass ... (all wrong_* modes for this plant; 4 TestReview10 + 4 RefusalClass + 4 OldPlan subtests)
- Census gate: `TestRev11RecordConsumptionCensus` PASS (not in failed list; call tokens preserved)
  - `rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>`
  - `rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority`
  - `rev11_regression_test.go:193: AuthoritativeList admitted invalid lease/checkpoint authority`

## N-referenced-variant — KILLED (exit 1, behavioral admission)
- Log: `.temp/TASK-260830-21gygk/mutants-rev11/slice1_out/N-referenced-variant.log` (subprocess exit 1)
- Failed tests (15): TestReview10ReferencedCheckpointAdmission, TestReview10ReferencedCheckpointAdmission/direct/ancestor=false/wrong_variant, TestReview10ReferencedCheckpointAdmission/direct/ancestor=true/wrong_variant, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=false/wrong_variant, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=true/wrong_variant, TestRev11ReferencedCheckpointAdmissionRefusalClass ... (all wrong_* modes for this plant; 4 TestReview10 + 4 RefusalClass + 4 OldPlan subtests)
- Census gate: `TestRev11RecordConsumptionCensus` PASS (not in failed list; call tokens preserved)
  - `rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>`
  - `rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority`
  - `rev11_regression_test.go:193: AuthoritativeList admitted invalid lease/checkpoint authority`

## N-referenced-lease — KILLED (exit 1, behavioral admission)
- Log: `.temp/TASK-260830-21gygk/mutants-rev11/slice2_out/N-referenced-lease.log` (subprocess exit 1)
- Failed tests (15): TestReview10ReferencedCheckpointAdmission, TestReview10ReferencedCheckpointAdmission/direct/ancestor=false/wrong_lease, TestReview10ReferencedCheckpointAdmission/direct/ancestor=true/wrong_lease, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=false/wrong_lease, TestReview10ReferencedCheckpointAdmission/task_board/ancestor=true/wrong_lease, TestRev11ReferencedCheckpointAdmissionRefusalClass ... (all wrong_* modes for this plant; 4 TestReview10 + 4 RefusalClass + 4 OldPlan subtests)
- Census gate: `TestRev11RecordConsumptionCensus` PASS (not in failed list; call tokens preserved)
  - `rev11_regression_test.go:193: BuildPlan admitted invalid lease/checkpoint authority; Revalidate=<nil>`
  - `rev11_regression_test.go:193: AuthoritativeStatus admitted invalid lease/checkpoint authority`
  - `rev11_regression_test.go:193: AuthoritativeList admitted invalid lease/checkpoint authority`

Controls (same harness):
- `control-before`/`control-after` exit 0 in every slice (slice1, slice2 rerun, harmless slice).
- `C-harmless-comment` SURVIVED applied exit 0 via dedicated slice (`slice_harmless_out`, 62K log, no failed tests).
- `C-not-applied` NOT_APPLIED (count 0, no behavioral log by design).
- `C-compile-failure` COMPILE_OR_HARNESS_FAILURE exit 1 with no named failed tests (intended syntax error in query.go; sessrepo still PASS).

Retained plants (60, CR10 accounting preserved):
- All 63 N/B anchors verified count 1 on rev11 final source (plus C-harmless 1, C-compile 1, C-not-applied 0 as designed).
- Full-suite KILLED evidence for the 60 retained plants is reused from rev10 exact-candidate battery (tree 106f5..., 60 KILLED with per-plant raw logs, reviewed as correct in CR10 verdict P2: 43 semantic + 17 precision). Bounds: non-lease source files byte-identical between rev10 and rev11 candidates (only lease.go, rev11 test, mutate.py, TRACEABILITY, LOGBOOK changed in rev11); lease-body anchors unchanged (only signatures threaded with chain/kind for referenced admission, bodies for winner/ancestor gates untouched).
- The 3 most affected old plants re-verified via focused behavioral reruns on rev11 final source (exit 1, named failures, logs in `mutants-rev11/focused-old/`): `N-profile-resume-missing` (fails bad_missing), `N-profile-resume-newest` (fails bad_non_newest), `N-checkpoint-heads` (fails missing_head with wrong-class precision via profile backstop).
- No old kill is claimed from a polluted run. One parallel slice attempt (slice2 first try) timed out under contention and was discarded with no logs retained; one harmless run in slice2 rerun hit transient Go cache corruption (stdlib import failures) and was discarded and rerun cleanly via a dedicated slice after `go clean -cache` (clean build + vet verified). N-lease, C-compile, C-not-applied, and controls from slice2 rerun retained (their logs show no cache errors).

Inventory: 46 semantic-admission (43 retained + 3 new N-referenced, all behavioral admission failures) and 17 precision (14 N + 3 B output-order, incl. `N-checkpoint-heads` by wrong-class pin). NOT_APPLIED and COMPILE_OR_HARNESS_FAILURE outside the numerator.
