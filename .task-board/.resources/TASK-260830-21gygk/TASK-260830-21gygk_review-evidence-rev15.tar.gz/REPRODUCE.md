# CR15 independent review reproduction

Candidate tree: 53fc631adb15546892cc8f32fbf619eda5a6a957. Go tool version/platform in readiness.log. Run from the repository, using only task scratch. No tool edits live source.

1. Extract the evidence archive into a new task scratch directory.
2. In that directory: `mkdir candidate plant-candidate`; populate each with `git archive 53fc631adb15546892cc8f32fbf619eda5a6a957 internal go.mod go.sum | tar -x -C <directory>` (for the broad full tree use `git archive TREE | tar -x -C candidate`).
3. `python3 probe.py` installs the attached reviewer tests into candidate and runs independent and retained masks. Independent exit 1 is expected because the alias negative assertions fail. The helper-only FieldAssembledRuntime test is intentionally not selected: it does not establish an external Reader exploit.
4. `python3 direct_plants.py` drives the real production-source census under each isolated compiling plant. Expected exits: old CR14 mint and unknown callback 1; generic/any/build-tagged and struct-field callback 1; aliases 0 (defect); applied harmless comment 0. Every plant is restored in finally.
5. `mutation-audit.json` audits attached producer resource TASK-260830-21gygk_producer-evidence-rev15.tar.gz (not duplicated here). All 477 mutation source files match immutable candidate. `audit.py` expects it extracted under producer. Exact producer mutation and validation resources remain on the same task.

The verdict retains the 8-row shared-API denominator and 0/8 CLI caller bound. The archive is reviewer evidence, not a candidate patch.
