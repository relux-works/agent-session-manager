from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;s=p/'candidate';d=s/'internal/sessquery'
for name in ['review13_original_test.go','review14_copied_test.go','review14_independent_test.go']:
 (d/name).write_bytes((p/'prior/reviewer-tests'/name).read_bytes())
(d/'review15_test.go').write_text('''package sessquery
import("testing";"os";"path/filepath";"runtime";"strings")
func TestReview15AdditionalShapes(t *testing.T) {
 _,f,_,_:=runtime.Caller(0)
 plants:=map[string]string{
 "generic_constructor":`package sessquery
func review15New[T any]() *T { return new(T) }
func review15Mint() any { return review15New[checkpointSeal]() }`,
 "any_token":`package sessquery
func review15AnyToken(v any) any { token:=v.(*checkpointSealToken); return token }`,
 "build_tag_seal":`//go:build review15_hidden

package sessquery
func review15Hidden() any { return new(checkpointSeal) }`,
 "alias_seal":`package sessquery
type review15Alias = checkpointSeal
func review15AliasMint() any { return new(review15Alias) }`,
 "alias_token":`package sessquery
type review15TokenAlias = checkpointSealToken
func review15AliasMint() any { return new(review15TokenAlias) }`,
 }
 for name,plant:=range plants { t.Run(name,func(t *testing.T){dir:=t.TempDir();rev12CopyProductionSources(t,filepath.Dir(f),dir);if e:=os.WriteFile(filepath.Join(dir,"review15_plant.go"),[]byte(plant),0600);e!=nil{t.Fatal(e)};e:=rev12CheckRecordConsumptionSource(dir);if e==nil{t.Fatal("census accepted compiling alternate seal/token producer")}else if strings.Contains(e.Error(),"type-check"){t.Fatalf("compile failure is not proof: %v",e)}else{t.Log(e)}}) }
}
''')
rows=[]
for name,mask in [('independent','^(TestReview14AdditionalGateShapes|TestReview14UnknownCallbackMustRefuse|TestReview14CopiedSealMatrix|TestReview13OriginalTemporalAuthority|TestReview15AdditionalShapes)$'),('retained','^(TestReview10|TestReview11|TestRev[0-9]|TestResolve|TestParseSelector|TestList|TestStatus|TestSummary|TestAuthoritative|TestBuild|TestRevalidate|TestPlan)')]:
 cmd=['go','test','./internal/sessquery','-run',mask,'-count=1','-v']
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=s,stdout=f,stderr=subprocess.STDOUT,timeout=300)
 rows.append(dict(name=name,command=cmd,exit=r.returncode));print(name,r.returncode,flush=True)
(p/'exits.json').write_text(json.dumps(rows,indent=2))
