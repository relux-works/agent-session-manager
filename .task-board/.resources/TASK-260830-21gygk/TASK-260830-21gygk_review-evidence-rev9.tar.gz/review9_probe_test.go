package sessquery
import (
 "testing"
 "fmt"
)
func TestReview9ForkLocalProfile(t *testing.T) {
 for _,kind:=range []string{"direct","task_board"} { for _,bad:=range []bool{false,true} {
 t.Run(fmt.Sprintf("%s/bad=%t",kind,bad),func(t *testing.T){
 local,_:=repository(t)
 raw:=record(t,idA,"alpha"); if kind=="task_board" {raw=taskBoardRecordBytes(t,idA,"alpha")}
 ref,err:=local.CreateSession(raw); if err!=nil {t.Fatal(err)}
 created:=appendEvent(t,local,idA,ref.RecordID,"session.created",1,map[string]any{"session_record_id":ref.RecordID,"bootstrap_operation_id":hostA,"first_checkpoint_operation_id":hostB})
 profile:="yolo"; if bad {profile="standard"}
 fork:=appendEvent(t,local,idA,created,"fork.created",2,map[string]any{"source_session_id":idB,"source_checkpoint_id":zeroDigest,"new_session_record_id":ref.RecordID,"provider_fork_mode":"native","execution_profile":profile,"profile_source_event_id":nil,"source_profile_event_id":nil})
 launched:=appendEvent(t,local,idA,fork,"provider.launched",3,rev8LaunchPayload("yolo",nil))
 idle:=appendEvent(t,local,idA,launched,"session.idle",4,map[string]any{"boundary_ref":"turn-1","foreground_idle":true,"background_idle":true})
 cp:=checkpointRecordBytes(t,idA,1,lease,hostA); if kind=="task_board" {cp=taskBoardCheckpointBytes(t,idA,1,lease,hostA)}
 good:=rev7Replace(t,cp,"checkpoint_id",map[string]any{"event_heads":[]string{created}})
 covered:=rev7Replace(t,cp,"checkpoint_id",map[string]any{"event_heads":[]string{idle}})
 announced:=appendEvent(t,local,idA,idle,"checkpoint.created",5,map[string]any{"checkpoint_id":checkpointDigestOf(t,good),"kind":"manual"})
 appendEventAs(t,local,idA,announced,"lease.transferred",1,2,leaseB,map[string]any{"operation_id":hostB,"from_host_id":hostA,"to_host_id":hostA,"predecessor_lease_id":lease,"new_lease_id":leaseB})
 r:=&Reader{Local:local,LocalHostID:hostA}; withCheckpoints(r,good); withLeases(r,leaseCreate(t,idA,hostA),leaseSuccessorBytes(t,idA,2,leaseB,hostA,lease,checkpointDigestOf(t,good)))
 rev7CheckEntries(t,r,false)
 old:=mustBuild(t,r,PlanArgs{Selector:"alpha",Action:ActionStatus})
 rev7SwapCheckpoint(t,r,covered)
 err=r.Revalidate(old)
 t.Logf("old-plan substitution refusal: %v",err)
 if bad && err == nil {t.Error("old-plan substitution admitted")}
 rev7CheckEntries(t,r,bad)
 }) }
 }
}
func TestReview9ResumeReferencedCheckpoint(t *testing.T) {
for _, bad := range []bool{false,true} { t.Run(fmt.Sprintf("wrong_checkpoint_pair=%t",bad),func(t *testing.T) {
	local, _ := repository(t)
	ref, err := local.CreateSession(record(t, idA, "alpha"))
	if err != nil {
		t.Fatal(err)
	}
	created := appendEvent(t, local, idA, ref.RecordID, "session.created", 1, map[string]any{"session_record_id": ref.RecordID, "bootstrap_operation_id": hostA, "first_checkpoint_operation_id": hostB})
	launched := appendEvent(t, local, idA, created, "provider.launched", 2, rev8LaunchPayload("yolo", nil))
	beforeChangeIdle := appendEvent(t, local, idA, launched, "session.idle", 3, map[string]any{"boundary_ref":"before-change","foreground_idle":true,"background_idle":true})
 changed := appendEvent(t, local, idA, beforeChangeIdle, "profile.changed", 4, rev8ChangedPayload("yolo", "standard"))
	quiesced := appendEvent(t, local, idA, changed, "session.idle", 5, map[string]any{"boundary_ref": "turn-0", "foreground_idle": true, "background_idle": true})
	head := quiesced; if bad { head = beforeChangeIdle };
 cpA := rev7Replace(t, checkpointRecordBytes(t, idA, 1, lease, hostA), "checkpoint_id", map[string]any{"event_heads": []string{head}})
	announced := appendEvent(t, local, idA, quiesced, "checkpoint.created", 6, map[string]any{"checkpoint_id": checkpointDigestOf(t, cpA), "kind": "manual"})
	stopped := appendEvent(t, local, idA, announced, "session.stopped", 7, map[string]any{"graceful": true, "checkpoint_id": checkpointDigestOf(t, cpA), "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true})
	resumed := appendEvent(t, local, idA, stopped, "session.resumed", 8, map[string]any{"checkpoint_id": checkpointDigestOf(t, cpA), "execution_profile": "standard", "profile_source_event_id": changed, "terminal_backend": "tmux", "native_session_id": "sess-1"})
	idle := appendEvent(t, local, idA, resumed, "session.idle", 9, map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true})
	cpB := rev7Replace(t, checkpointRecordBytes(t, idA, 1, lease, hostA), "checkpoint_id", map[string]any{"event_heads": []string{idle}})
	announcedB := appendEvent(t, local, idA, idle, "checkpoint.created", 10, map[string]any{"checkpoint_id": checkpointDigestOf(t, cpB), "kind": "manual"})
	tail := appendEventAs(t, local, idA, announcedB, "lease.transferred", 1, 2, leaseB, map[string]any{"operation_id": hostB, "from_host_id": hostA, "to_host_id": hostA, "predecessor_lease_id": lease, "new_lease_id": leaseB})
	r := &Reader{Local: local, LocalHostID: hostA}
	withCheckpoints(r, cpB, cpA)
	withLeases(r, leaseCreate(t, idA, hostA), leaseSuccessorBytes(t, idA, 2, leaseB, hostA, lease, checkpointDigestOf(t, cpB)))
	_ = announced
	_ = tail
	rev7CheckEntries(t, r, bad)
	if bad {return}; old := mustBuild(t, r, PlanArgs{Selector: "alpha", Action: ActionStatus})
	if err := r.Revalidate(old); err != nil {
		t.Errorf("fresh Revalidate refused valid resume profile authority: %v", err)
	}
}) }
}
