# Mutation accounting

56 unique N/B entries, not 59. Of these 39 semantic-admission plants and 17 label/class/output-precision plants. Three B plants are output-order behavior, not narrowing gates. No compilation/unapplied control is a kill. No fixture failure is reported among the 56 in the manifests; missing raw logs limit independent replay claims.

The applied harmless survivor and NOT_APPLIED/COMPILE_OR_HARNESS_FAILURE controls are separate from the 56. Parent pipeline exit cannot be inferred from tail; manifest exit fields come directly from subprocess.returncode in the inspected harness. Seven source-manifest files match CR9. Most old per-mutant raw logs are absent from the producer bundle; prior closed findings are retained, not represented as independently replayed.

| Plant | Classification | Named failing test |
|---|---|---|
| B-peer-order | label/class/output precision | TestResolvePeerOrderAndReplicatedIdentity |
| B-session-order | label/class/output precision | TestListStatusDerivedFactsAndStableOrder |
| B-tie-break | label/class/output precision | TestResolveBareIdentityUnion |
| N-agreement-name | semantic admission | TestResolveBareIdentityUnion |
| N-ancestor-checkpoint | semantic admission | TestRev5AncestorCheckpointAuthority |
| N-ancestor-holder | semantic admission | TestRev5AncestorCheckpointBinding |
| N-capability-name | semantic admission | TestRev4UnknownCapabilityMustRefuse |
| N-case-variant | semantic admission | TestResolveExactNamesAndASCIICollisions |
| N-chain-self | semantic admission | TestSelfPredecessorWithCheckpointMustRefuse |
| N-checkpoint-heads | label/class/output precision | TestRev7CheckpointHeadAuthority |
| N-checkpoint-holder | semantic admission | TestRev5CheckpointCreatorMustBeHolder |
| N-checkpoint-persistence | semantic admission | TestRev6CheckpointPersistenceMustMatchSession |
| N-checkpoint-placeholder | semantic admission | TestRev4MissingCheckpointMustRefuse |
| N-collision-pair | semantic admission | TestResolveExactNamesAndASCIICollisions |
| N-disallowed-admit | semantic admission | TestResolveExplicitSourceRefusals |
| N-dup-alias | semantic admission | TestSelectorConfigurationValidation |
| N-duplicate-peer | semantic admission | TestResolveAllowlistAndReadFailures |
| N-explicit-fallback | semantic admission | TestResolveQualifiedSourceNeverFallsBack |
| N-first-at-split | label/class/output precision | TestParseSelectorLiteralGrammar |
| N-host-bound64 | semantic admission | TestAuthoritativeInputValidation |
| N-id-case | label/class/output precision | TestParseSelectorLiteralGrammar |
| N-id-through-names | label/class/output precision | TestResolveQualifiedNameBeforeUUIDInSource |
| N-identity-diverge | semantic admission | TestResolveBareIdentityUnion |
| N-lease-missing | semantic admission | TestReviewerPlanRequiresLeaseRecord |
| N-local-prefix | semantic admission | TestParseSelectorLiteralGrammar |
| N-observation-capabilities | semantic admission | TestAuthoritativeMissingCapabilitiesRefuses |
| N-observation-host | semantic admission | TestAuthoritativeMissingHostMetadataRefuses |
| N-observation-process | semantic admission | TestAuthoritativeMissingProcessRefusesStatus |
| N-observation-workspace | semantic admission | TestAuthoritativeMissingWorkspaceRefuses |
| N-parked-id | semantic admission | TestParkedReadRecoveryAndMissingVsMalformed |
| N-parked-union-refusal | semantic admission | TestRevalidateUnionParkedCopyRefuses |
| N-peer-alias-fold | semantic admission | TestSelectorConfigurationValidation |
| N-plan-bootstrap | label/class/output precision | TestBuildPlanRecordOnlySessionRefusesBootstrap |
| N-plan-source-host | label/class/output precision | TestBuildPlanLocalSourceRequiresKnownHost |
| N-profile-change-direction | semantic admission | TestRev8ProfileChangedPositiveControl |
| N-profile-first-source | semantic admission | TestRev8CheckpointProfileAuthority |
| N-profile-newest | semantic admission | TestRev8ProfileTwoGenerationControl |
| N-profile-value | semantic admission | TestRev8ProfileSourceRefusals |
| N-projection-failure-fallback | semantic admission | TestRevalidateDetectsEachFactChange |
| N-read-failure-fallback | semantic admission | TestRevalidateReadFailures |
| N-repository-case-variant | semantic admission | TestResolveLocalNameAndUUID |
| N-rev-absent-substitute | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-rev-binding | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-rev-config | semantic admission | TestRevalidateDetectsEachFactChange |
| N-rev-heads | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-rev-index | semantic admission | TestRevalidateDetectsEachFactChange |
| N-rev-lease | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-rev-record | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-rev-revocation | label/class/output precision | TestRevalidateDetectsEachFactChange |
| N-summary-bootstrap | semantic admission | TestCreatingSummaryCannotClaimClosedCLIResult |
| N-tombstoned-id | semantic admission | TestResolveExcludesTombstonedButListsIt |
| N-union-lease | label/class/output precision | TestRevalidateUnionLeaseDivergenceRefusesStale |
| N-union-record | semantic admission | TestReviewerOtherSourceDivergenceMustRefuse |
| N-union-tombstone | label/class/output precision | TestRevalidateUnionTombstoneRefusesStale |
| N-unknown-alias-local | semantic admission | TestResolveExplicitSourceRefusals |
| N-unlisted-peer | semantic admission | TestResolveAllowlistAndReadFailures |
