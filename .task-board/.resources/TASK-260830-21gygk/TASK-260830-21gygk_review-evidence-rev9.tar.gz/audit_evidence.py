import json,hashlib,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
rows=[r for f in sorted((p/'producer/mutants').glob('slice*-mutants.json')) for r in json.loads(f.read_text()) if r['mutant'].startswith(('N-','B-'))]
labels={'N-rev-revocation','N-rev-binding','N-rev-record','N-rev-lease','N-rev-heads','N-rev-absent-substitute','N-plan-bootstrap','N-plan-source-host','N-checkpoint-heads','N-union-lease','N-union-tombstone','N-first-at-split','N-id-through-names','N-id-case','B-peer-order','B-session-order','B-tie-break'}
for r in rows:
 r['review_category']='label/class/output precision' if r['mutant'] in labels else 'semantic admission'
 r['evidence_basis']='Producer direct-subprocess manifest + named committed-candidate test and plant inspection; not an independent full-battery replay.'
 if r['mutant'].startswith('N-profile-') or r['mutant']=='N-checkpoint-heads':r['evidence_basis']='Independent exact-source same-instrument rerun with raw logs (mutations/).'
(p/'mutation-classification.json').write_text(json.dumps(rows,indent=2)+'\n')
text=['# Mutation accounting','',f'{len(rows)} unique N/B entries, not 59. Of these {len(rows)-len(labels)} semantic-admission plants and {len(labels)} label/class/output-precision plants. Three B plants are output-order behavior, not narrowing gates. No compilation/unapplied control is a kill. No fixture failure is reported among the 56 in the manifests; missing raw logs limit independent replay claims.','', 'The applied harmless survivor and NOT_APPLIED/COMPILE_OR_HARNESS_FAILURE controls are separate from the 56. Parent pipeline exit cannot be inferred from tail; manifest exit fields come directly from subprocess.returncode in the inspected harness. Seven source-manifest files match CR9. Most old per-mutant raw logs are absent from the producer bundle; prior closed findings are retained, not represented as independently replayed.','', '| Plant | Classification | Named failing test |','|---|---|---|']
for r in sorted(rows,key=lambda x:x['mutant']):text.append(f"| {r['mutant']} | {r['review_category']} | {r['failed_tests'][0]} |")
(p/'mutation-classification.md').write_text('\n'.join(text)+'\n')
expected=subprocess.check_output(['git','ls-tree','-rz','6eb65f537f4ebffe6e6044f5b64ffc1b89d4487e','--','internal','go.mod','go.sum']).split(b'\0'); mismatch=[];count=0
for entry in expected:
 if not entry:continue
 meta,path=entry.split(b'\t',1); mode,typ,oid=meta.split(); path=path.decode(); data=(p/'candidate'/path).read_bytes(); actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();count+=1
 if actual!=oid.decode():mismatch.append(path)
(p/'candidate-byte-verification.json').write_text(json.dumps({'tree':'6eb65f537f4ebffe6e6044f5b64ffc1b89d4487e','checked':count,'mismatch':mismatch,'extra_probe_files':['internal/sessquery/review9_probe_test.go','internal/sessquery/testdata/review9_mutate.py']},indent=2))
print('verified files',count,'mismatches',mismatch,'mutants',len(rows),'precision',len(labels))
