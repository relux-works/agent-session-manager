# CR9 review evidence

Authority: candidate tree 6eb65f537f4ebffe6e6044f5b64ffc1b89d4487e, Go 1.25.5 darwin/arm64. Use a new ignored directory, not the live Story tree.

1. `mkdir -p .temp/cr9-replay`
2. `git archive 6eb65f537f4ebffe6e6044f5b64ffc1b89d4487e | tar -x -C .temp/cr9-replay`
3. Copy bundled `review9_probe_test.go` to that archive's `internal/sessquery/`.
4. From the archive: `go test ./internal/sessquery -run '^TestReview9' -count=1 -v` (expected exit 1: three valid controls pass, three semantic negatives fail).
5. The unchanged candidate tests: `go test ./internal/sessquery -run 'TestRev8|TestRev7|TestValidSuccessor|TestRevalidateUnionParked' -count=1 -v` (exit 0).
6. For mutation reproduction, use a SECOND fresh archive without reviewer tests. Copy `review9_mutate.py` beside shipped `internal/sessquery/testdata/mutate.py`. Run `python3 internal/sessquery/testdata/review9_mutate.py /absolute/new/output-dir` directly and capture the actual process status, without a pipeline (exit 0). This is the shipped instrument with only a six-name run filter; all application, subprocess, classifier and restore code is unchanged.

The mutation-source tree was copied before adding reviewer probes; its tests and production bytes are exact candidate files. Five plants KILLED (exit 1), applied C-harmless-comment SURVIVED (exit 0), before/after controls 0. Driver status is in mutation-driver.exit. Full raw logs and direct subprocess results in mutations/.

The original CR9 validation log is retained intact, including all diagnostics. Its real per-command exits are reused; no new repository-wide build/vet/coverage replay is claimed. Producer's supplied seven-file source manifest matches candidate bytes; source-comparison.json and candidate-byte-verification.json record provenance. Prior CR8 evidence is retained as its original archive, not relabelled CR9.

Operational corrections: initial skill discovery in the Story checkout found no installed .codex/skills; loaded the main repository's Curator-managed go-testing-tools instead. Initial board queries using element/resources were rejected and repaired to get/outcomeResources. An initial scratch probe write used a doubled relative path and failed before creation; the following empty test selection is not counted. The final probe.log contains the actual named tests after repair. These preparation failures do not masquerade as validation evidence. All later probes ran synchronously to completion.
