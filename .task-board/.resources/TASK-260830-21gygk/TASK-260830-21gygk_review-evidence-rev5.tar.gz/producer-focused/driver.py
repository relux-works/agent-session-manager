#!/usr/bin/env python3
"""Narrowing-mutant driver for TASK-260830-21gygk rev4 rework gates.

Each plant keeps the gate present and weakens it to admit (a member of)
the class it must reject; the named test must then FAIL (KILLED).
A harmless comment plant must PASS (SURVIVED) through the same
instrument. Every plant records exact file digests before/after and
the real `go test` exit code. Files are restored after each plant.
"""
import hashlib
import json
import subprocess
import sys

ROOT = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3tq4ns/worktree"
OUT = "/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-3tq4ns/worktree/.temp/TASK-260830-21gygk/mutants-rev4"

ZERO = "sha256:" + "0" * 64

PLANTS = [
    {
        "id": "N-chain-self",
        "file": "internal/sessquery/lease.go",
        "find": "\t\tparent, ok := byLease[current.Predecessor]\n\t\tif !ok {\n",
        "replace": "\t\tparent, ok := byLease[current.Predecessor]\n\t\tif ok && parent.LeaseID == current.LeaseID {\n\t\t\treturn parent, nil\n\t\t}\n\t\tif !ok {\n",
        "tests": ["TestSelfPredecessorWithCheckpointMustRefuse"],
        "expect": "killed",
        "note": "admits exactly the self-predecessor member and terminates the walk; skipped-epoch and cycle members still refused; TestRev4SelfPredecessorMustRefuse still passes via the checkpoint gate (documented subsumption)",
    },
    {
        "id": "N-checkpoint-placeholder",
        "file": "internal/sessquery/lease.go",
        "find": "\tcheckpoint, ok := checkpoints[winner.Checkpoint]\n\tif !ok {\n",
        "replace": "\tcheckpoint, ok := checkpoints[winner.Checkpoint]\n\tif !ok && winner.Checkpoint == \"" + ZERO + "\" {\n\t\treturn nil\n\t}\n\tif !ok {\n",
        "tests": ["TestRev4MissingCheckpointMustRefuse"],
        "expect": "killed",
        "note": "admits exactly the all-zero placeholder reference with an early return (a mere condition weakening would only shift the refusal reason onto the zero value); wrong-session and wrong-lease members still refused",
    },
    {
        "id": "N-parked-empty-record",
        "file": "internal/sessquery/revalidate.go",
        "find": "\t\tif row.Projection.Parked != nil {\n\t\t\treturn fmt.Errorf(\"%w: required authority for session %s is unknown: %s\", ErrObservationUnavailable, plan.SessionID, row.Projection.Parked.BlockingReason)\n",
        "replace": "\t\tif row.Projection.Parked != nil && row.Projection.RecordID == \"\" {\n\t\t\treturn fmt.Errorf(\"%w: required authority for session %s is unknown: %s\", ErrObservationUnavailable, plan.SessionID, row.Projection.Parked.BlockingReason)\n",
        "tests": ["TestRev4ParkedAuthorityMustRefuse", "TestRevalidateUnionParkedCopyRefuses"],
        "expect": "killed",
        "note": "admits parked members with a nonempty record ID: the agreeing-record member is admitted (Revalidate/BuildPlan return nil, strong kill via TestRevalidateUnionParkedCopyRefuses agreeing subtests); the divergent-record member shifts to integrity_failure (reason change only, and the divergent reviewer probe still refuses)",
    },
    {
        "id": "N-capability-name",
        "file": "internal/sessquery/summary.go",
        "find": "\t\tif !admitted[name] {\n",
        "replace": "\t\tif !admitted[name] && name != \"invented_capability\" {\n",
        "tests": ["TestRev4UnknownCapabilityMustRefuse"],
        "expect": "killed",
        "note": "admits exactly the invented_capability member; full-registry positive still bounds the vocabulary",
    },
    {
        "id": "C-harmless-comment",
        "file": "internal/sessquery/lease.go",
        "find": "// checkLeaseChain validates the winner's predecessor ancestry within\n",
        "replace": "// checkLeaseChain validates the winner's predecessor ancestry within\n// harmless classifier control: comment only, no behavior change.\n",
        "tests": [
            "TestRev4SelfPredecessorMustRefuse",
            "TestRev4MissingCheckpointMustRefuse",
            "TestValidSuccessorBuildsAndRevalidates",
        ],
        "expect": "survived",
        "note": "same-instrument control: applied plant with no behavior change must keep the suite green",
    },
]


def sha(path):
    with open(path, "rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def run(tests):
    proc = subprocess.run(
        ["go", "test", "./internal/sessquery/", "-run", "^(" + "|".join(tests) + ")$", "-count=1"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=300,
    )
    return proc.returncode, proc.stdout + proc.stderr


def main():
    import os

    os.makedirs(OUT, exist_ok=True)
    results = []
    for plant in PLANTS:
        path = ROOT + "/" + plant["file"]
        with open(path) as handle:
            original = handle.read()
        before = sha(path)
        count = original.count(plant["find"])
        entry = {"id": plant["id"], "file": plant["file"], "occurrences": count, "before": before}
        if count != 1:
            entry["classification"] = "NOT_APPLIED"
            results.append(entry)
            continue
        mutated = original.replace(plant["find"], plant["replace"])
        if plant.get("needs_import"):
            anchor = '"github.com/relux-works/agent-session-manager/internal/scalar"\n'
            mutated = mutated.replace(
                anchor, '"github.com/relux-works/agent-session-manager/internal/scalar"\n\t"strings"\n', 1)
        with open(path, "w") as handle:
            handle.write(mutated)
        code, log = run(plant["tests"])
        with open(OUT + "/" + plant["id"] + ".log", "w") as handle:
            handle.write(log)
        with open(path, "w") as handle:
            handle.write(original)
        after = sha(path)
        entry["exit"] = code
        entry["restored"] = after == before
        if plant["expect"] == "killed":
            entry["classification"] = "KILLED" if code != 0 else "SURVIVED"
        else:
            entry["classification"] = "SURVIVED" if code == 0 else "KILLED"
        entry["expectation_met"] = (
            (plant["expect"] == "killed" and code != 0)
            or (plant["expect"] == "survived" and code == 0)
        )
        entry["note"] = plant["note"]
        results.append(entry)
        print(plant["id"], "exit=", code, entry["classification"], "restored=", after == before)
    with open(OUT + "/results.json", "w") as handle:
        json.dump(results, handle, indent=2)
    if not all(entry.get("expectation_met") and entry.get("restored") for entry in results):
        sys.exit(1)


if __name__ == "__main__":
    main()
