from pathlib import Path
import subprocess,json,sys
p=Path(__file__).resolve().parent
name=sys.argv[1];cmd=sys.argv[2:]
with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=p/'candidate',stdout=f,stderr=subprocess.STDOUT,timeout=480)
(p/(name+'-exit.json')).write_text(json.dumps({'command':cmd,'exit':r.returncode},indent=2));print(name,r.returncode)
