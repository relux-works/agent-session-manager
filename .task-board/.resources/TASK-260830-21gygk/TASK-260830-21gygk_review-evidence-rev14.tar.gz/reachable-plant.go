package sessquery
type review14Receiver struct{}
func (review14Receiver) admitCheckpoint(raw validatedCheckpoint) (admittedCheckpoint,error) {
 var cp admittedCheckpoint
 cp.seal = new(checkpointSeal)
 cp.seal.token = new(checkpointSealToken)
 cp.seal.digest=raw.Digest;cp.seal.sessionID=raw.SessionID;cp.seal.leaseEpoch=raw.LeaseEpoch;cp.seal.leaseID=raw.LeaseID;cp.seal.creatorHostID=raw.CreatorHostID;cp.seal.hasProviderManifest=raw.HasProviderManifest;cp.seal.hasTaskBoardBundle=raw.HasTaskBoardBundle;cp.seal.eventHeads=raw.EventHeads
 return cp,nil
}
