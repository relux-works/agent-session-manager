from pathlib import Path
import subprocess,json,hashlib,re,collections
p=Path(__file__).resolve().parent
src=p/'candidate'; prod=p/'producer/.temp/TASK-260830-21gygk-mutants-rev14-02'
rows=json.loads((prod/'mutants.json').read_text()); out=[]
for r in rows:
 f=prod/(r['mutant']+'.log'); s=f.read_text() if f.exists() else ''
 actual=re.findall(r'^\s*--- FAIL: ([^ ]+)',s,re.M)
 out.append(dict(name=r['mutant'],classification=r['classification'],exit=r.get('exit'),failed=actual,log_present=f.exists(),matches=actual==r.get('failed_tests',[])))
copy=prod/'mutation-source'; mismatches=[]; n=0
for f in (copy/'internal').rglob('*'):
 if f.is_file():
  rel=f.relative_to(copy); target=src/rel; n+=1
  if not target.exists() or target.read_bytes()!=f.read_bytes():mismatches.append(str(rel))
report={'rows':out,'classes':dict(collections.Counter(r['classification'] for r in rows)),'compared_files':n,'mismatches':mismatches}
(p/'mutation-audit.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='rows'},indent=2))
for r in rows:
 if r.get('failed_tests'):print(r['mutant'],':',','.join(x for x in r['failed_tests'] if '/' not in x))
