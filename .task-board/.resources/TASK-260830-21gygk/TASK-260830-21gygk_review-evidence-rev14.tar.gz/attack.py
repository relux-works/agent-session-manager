from pathlib import Path
import subprocess,json
p=Path(__file__).resolve().parent;src=p/'candidate';lease=src/'internal/sessquery/lease.go';original=lease.read_bytes();helper=src/'internal/sessquery/review14_bypass.go';results=[]
plant='''package sessquery
type review14Receiver struct{}
func (review14Receiver) admitCheckpoint(raw validatedCheckpoint) (admittedCheckpoint,error) {
 var cp admittedCheckpoint
 cp.seal = new(checkpointSeal)
 cp.seal.token = new(checkpointSealToken)
 cp.seal.digest=raw.Digest;cp.seal.sessionID=raw.SessionID;cp.seal.leaseEpoch=raw.LeaseEpoch;cp.seal.leaseID=raw.LeaseID;cp.seal.creatorHostID=raw.CreatorHostID;cp.seal.hasProviderManifest=raw.HasProviderManifest;cp.seal.hasTaskBoardBundle=raw.HasTaskBoardBundle;cp.seal.eventHeads=raw.EventHeads
 return cp,nil
}
'''
def run(name,mask):
 cmd=['go','test','./internal/sessquery','-run',mask,'-count=1','-v']
 with (p/(name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 results.append({'name':name,'command':cmd,'exit':r.returncode});print(name,r.returncode,flush=True)
anchor='return checkReferencedCheckpointBinding(raw, checkpointID, sessionID, sessionKind, summary, chain, repo)'
assert original.decode().count(anchor)==1
try:
 helper.write_text(plant)
 mutation=original.decode().replace(anchor,'if raw.CreatorHostID == "0198f4c8-4a10-7b22-8b3c-1234567890ac" { return (review14Receiver{}).admitCheckpoint(raw) }\n\t\t'+anchor)
 lease.write_text(mutation);(p/'reachable-plant.go').write_text(plant);(p/'reachable.diff.txt').write_text(mutation)
 run('reachable-census','^TestRev11RecordConsumptionCensus$')
 run('reachable-behavior','^(TestReview10ReferencedCheckpointAdmission|TestRev11ReferencedCheckpointAdmissionRefusalClass|TestRev11ReferencedCheckpointAdmissionOldPlan)$')
finally:lease.write_bytes(original);helper.unlink(missing_ok=True)
try:
 lease.write_bytes(original+b'\n// review14 harmless applied control\n')
 run('harmless-control','^(TestReview10ReferencedCheckpointAdmission|TestRev11ReferencedCheckpointAdmissionRefusalClass|TestRev11ReferencedCheckpointAdmissionOldPlan)$')
finally:lease.write_bytes(original)
(p/'attack-results.json').write_text(json.dumps(results,indent=2))
