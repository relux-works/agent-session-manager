from pathlib import Path
import json
p=Path(__file__).resolve().parent
rows=json.loads((p/'mutation-audit.json').read_text())['rows']
precision=set('N-duplicate-peer N-peer-alias-fold N-rev-revocation N-rev-binding N-rev-record N-rev-lease N-rev-heads N-rev-absent-substitute N-union-lease N-union-tombstone N-plan-bootstrap N-plan-source-host N-checkpoint-heads N-profile-newest N-profile-value N-profile-first-value N-parked-union-refusal'.split())
functional=set('N-first-at-split N-id-case N-profile-change-direction B-peer-order B-session-order B-tie-break'.split())
counts={}
for r in rows:
 n=r['name'];c=r['classification']
 if c=='KILLED':
  c='census precision' if n=='N-census-raw-owner-object' else 'refusal precision' if n in precision else 'positive/selection/order behavior' if n in functional else 'semantic admission'
 r['review_class']=c;counts[c]=counts.get(c,0)+1
(p/'mutation-classification.json').write_text(json.dumps({'counts':counts,'rows':rows},indent=2));print(counts)
