package sessquery
import("testing";"errors";"fmt";"github.com/relux-works/agent-session-manager/internal/sessrepo")
func TestReview14CopiedSealMatrix(t *testing.T) {
	recordBytes := record(t, idA, "alpha")
	forged := admittedCheckpoint{
		seal: &checkpointSeal{
			digest:              "sha256:1111111111111111111111111111111111111111111111111111111111111111",
			sessionID:           idA,
			leaseEpoch:          1,
			leaseID:             lease,
			creatorHostID:       hostA,
			hasProviderManifest: true,
			eventHeads:          []string{zeroDigest},
		},
	}
 repo, _ := repository(t)
 ref := create(t, repo, idA, "alpha")
 head := appendEvent(t, repo, idA, ref.RecordID, "session.created", 1, map[string]any{"session_record_id":ref.RecordID,"bootstrap_operation_id":hostA,"first_checkpoint_operation_id":hostB})
 raw := validatedCheckpoint{Digest:zeroDigest,SessionID:idA,LeaseEpoch:1,LeaseID:lease,CreatorHostID:hostA,HasProviderManifest:true,EventHeads:[]string{head}}
 owner := validatedLease{SessionID:idA,Epoch:1,LeaseID:lease,HolderHostID:hostA}
 good, err := admitCheckpoint(raw,idA,owner,"direct",[]validatedLease{owner},repo,nil)
 if err != nil { t.Fatal(err) }
 if _,_,err = sessionCreationProfile(good,recordBytes);err != nil {t.Fatal(err)}
 clearedSeal := good; clearedSeal.seal = nil
 clearedToken := good; inner := *good.seal; inner.token = nil; clearedToken.seal = &inner
	entries := map[string]func(admittedCheckpoint) error{
		"checkCheckpointProfileAuthority": func(checkpoint admittedCheckpoint) error {
			return checkCheckpointProfileAuthority(checkpoint, nil, nil)
		},
		"sessionCreationProfile": func(checkpoint admittedCheckpoint) error {
			_, _, err := sessionCreationProfile(checkpoint, recordBytes)
			return err
		},
		"profileClosure": func(checkpoint admittedCheckpoint) error {
			_, err := profileClosure(checkpoint, zeroDigest, nil)
			return err
		},
		"eventProfilePair": func(checkpoint admittedCheckpoint) error {
			_, err := eventProfilePair(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"eventProfileTarget": func(checkpoint admittedCheckpoint) error {
			_, err := eventProfileTarget(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"eventPayloadMembers": func(checkpoint admittedCheckpoint) error {
			_, err := eventPayloadMembers(checkpoint, nil, sessrepo.EventSummary{})
			return err
		},
		"checkClosureProfilePairs": func(checkpoint admittedCheckpoint) error {
			return checkClosureProfilePairs(checkpoint, "standard", zeroDigest, nil, nil, nil, nil)
		},
		"referencedCheckpointProfile": func(checkpoint admittedCheckpoint) error {
			_, _, _, _, err := referencedCheckpointProfile(checkpoint, sessrepo.EventSummary{}, "standard", zeroDigest, nil, nil, nil)
			return err
		},
		"checkProfilePairSource": func(checkpoint admittedCheckpoint) error {
			return checkProfilePairSource(checkpoint, sessrepo.EventSummary{}, profilePair{}, "standard", "", false, nil, nil)
		},
	}
	for name, entry := range entries {
		for label, checkpoint := range map[string]admittedCheckpoint{
			"zero":   {},
			"forged": forged,
 "copied_cleared_seal": clearedSeal,
 "copied_cleared_token": clearedToken,
		} {
			t.Run(fmt.Sprintf("%s/%s", name, label), func(t *testing.T) {
				err := entry(checkpoint)
				if err == nil {
					t.Fatalf("%s accepted an unsealed checkpoint", label)
				}
				if !errors.Is(err, ErrObservationUnavailable) {
					t.Fatalf("%s refusal = %v, want observation_unavailable", label, err)
				}
			})
		}
	}
}

