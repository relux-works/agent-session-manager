package sessquery
import("testing";"os";"path/filepath";"runtime";"strings";"errors")
func TestReview14AdditionalGateShapes(t *testing.T){
 _,file,_,_:=runtime.Caller(0)
 plants:=map[string]string{
 "interface_method":`package sessquery
type review14CapabilityProvider interface { Get() admittedCheckpoint }
func review14InterfaceReturn(v review14CapabilityProvider) { _ = v.Get() }`,
 "build_tag":`//go:build review14_hidden

package sessquery
func review14Hidden(v validatedCheckpoint) string { return v.Digest }`,
 "generic":`package sessquery
func review14Generic[T any](v T) T { return v }
func review14GenericUse(v admittedCheckpoint) { _ = review14Generic(v) }`,
 "field_assembled_current":`package sessquery
func review14Assemble() admittedCheckpoint { var v admittedCheckpoint; v.seal = new(checkpointSeal); v.seal.token = new(checkpointSealToken); return v }`,
 "mint_seal_without_composite":`package sessquery
func review14MintSeal() *checkpointSeal { v := new(checkpointSeal); v.token = new(checkpointSealToken); v.sessionID = "invented"; return v }`,
 }
 for name,plant:=range plants{t.Run(name,func(t *testing.T){dir:=t.TempDir();rev12CopyProductionSources(t,filepath.Dir(file),dir);if e:=os.WriteFile(filepath.Join(dir,"review14_plant.go"),[]byte(plant),0600);e!=nil{t.Fatal(e)};e:=rev12CheckRecordConsumptionSource(dir);if e==nil{t.Fatal("census admitted alternate construction/consumption")}else if strings.Contains(e.Error(),"type-check"){t.Fatalf("plant did not reach census: %v",e)}else{t.Log(e)}})}
}
func TestReview14FieldAssembledRuntime(t *testing.T){
 cp:=admittedCheckpoint{seal:&checkpointSeal{token:new(checkpointSealToken),sessionID:idA}}
 _,_,e:=sessionCreationProfile(cp,record(t,idA,"alpha"))
 if !errors.Is(e,ErrObservationUnavailable){t.Fatalf("self-minted seal accepted: %v",e)}
}
func TestReview14UnknownCallbackMustRefuse(t *testing.T){
 _,file,_,_:=runtime.Caller(0);dir:=t.TempDir();rev12CopyProductionSources(t,filepath.Dir(file),dir)
 p:=filepath.Join(dir,"lease.go");b,e:=os.ReadFile(p);if e!=nil{t.Fatal(e)}
 anchor:="ref, err := admission(checkpointID, authority.sessionID, summary)"
 if strings.Count(string(b),anchor)!=1{t.Fatal("anchor mismatch")}
 s:=strings.Replace(string(b),anchor,"ref, err := review14UnknownAdmission(checkpointID, authority.sessionID, summary)",1)
 s+="\nvar review14UnknownAdmission checkpointAdmission\n"
 if e=os.WriteFile(p,[]byte(s),0600);e!=nil{t.Fatal(e)}
 if e=rev12CheckRecordConsumptionSource(dir);e==nil{t.Fatal("census admitted unresolved function-value callee in profile entry")}else if strings.Contains(e.Error(),"type-check"){t.Fatalf("not a census result: %v",e)}else{t.Log(e)}
}
