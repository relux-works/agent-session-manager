import sys,shutil,subprocess,os
name,old,new=sys.argv[1],sys.argv[2],sys.argv[3]
d=f"m-{name}"; shutil.rmtree(d,ignore_errors=True); shutil.copytree("base",d,symlinks=True)
p=f"{d}/internal/tmuxserver/bind.go"; s=open(p).read()
assert s.count(old)==1,(name,s.count(old)); open(p,"w").write(s.replace(old,new))
r=subprocess.run(["go","test","./internal/tmuxserver/","./internal/termbind/","-count=1"],cwd=d,capture_output=True,text=True)
open(f"{name}.log","w").write(r.stdout+r.stderr)
fails=[l for l in (r.stdout).splitlines() if l.startswith("--- FAIL") or l.startswith("    --- FAIL")][:4]
print(name,"exit",r.returncode,"KILLED" if r.returncode else "SURVIVED",fails)
shutil.rmtree(d)
