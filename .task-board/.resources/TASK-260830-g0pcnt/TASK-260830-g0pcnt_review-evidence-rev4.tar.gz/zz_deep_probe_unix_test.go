//go:build unix
package tmuxserver
import ("os";"path/filepath";"testing")
func TestZZDeepAncestorProbe(t *testing.T){
	base,_:=os.MkdirTemp("/tmp","axdeep"); defer os.RemoveAll(base)
	base,_=filepath.EvalSymlinks(base)
	bad:=filepath.Join(base,"a"); os.Mkdir(bad,0o700); os.Chmod(bad,0o777)
	root:=filepath.Join(bad,"b","c","d","e","f","g"); if err:=os.MkdirAll(root,0o700);err!=nil{t.Fatal(err)}
	t.Logf("checkCustodyAncestors(%s) with 0777 ancestor %s -> %v", root, bad, checkCustodyAncestors(root))
}
