import sys,shutil,subprocess,os
name,f,old,new=sys.argv[1:5]
d=f'/tmp/g0rv3/m-{name}'; shutil.rmtree(d,ignore_errors=True); shutil.copytree('/tmp/g0rv3/pristine',d,symlinks=True)
p=os.path.join(d,f); s=open(p).read(); assert s.count(old)==1,(name,s.count(old)); open(p,'w').write(s.replace(old,new))
