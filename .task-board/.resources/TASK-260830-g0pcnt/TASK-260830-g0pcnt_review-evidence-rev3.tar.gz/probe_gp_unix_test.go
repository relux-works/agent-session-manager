//go:build !windows

package tmuxserver

import (
	"os"
	"path/filepath"
	"testing"
)

func TestReviewerProbeWritableGrandparent(t *testing.T) {
	base, _ := filepath.EvalSymlinks(t.TempDir())
	gp := filepath.Join(base, "gp"); p := filepath.Join(gp, "p"); root := filepath.Join(p, "root")
	if err := os.MkdirAll(root, 0o700); err != nil { t.Fatal(err) }
	os.Chmod(gp, 0o777); os.Chmod(p, 0o700)
	t.Cleanup(func() { os.Chmod(gp, 0o700) })
	err := checkCustodyAncestors(root)
	t.Logf("writable grandparent 0777 -> %v", err)
	if err == nil { t.Fatal("ADMITTED writable non-sticky grandparent") }
}
