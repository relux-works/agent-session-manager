# Rev6 validation index

Candidate: Story checkpoint 5a64077facb9f93357b9bbc8ebdba93069105715 plus uncommitted changes. Trunk stayed at 0ca3e4c26e2b275212796657f785b9b450f6174e. Runtime: macOS Darwin/arm64, Go 1.25.5, GOTOOLCHAIN=auto. Commands ran in the foreground; listed exits are actual process exit codes.

## Tests

| Command / gate | Exit | Evidence |
|---|---:|---|
| go test ./... | 0 | rev6-go-test-all-exact-01.log, all 45 packages |
| go test ./internal/tmuxserver ./internal/termbind -count=1 -v | 0 | rev6-package-tests-01.log |
| New PATH_MAX/wiring/AST tests with -count=3 -v | 0 | rev6-determinism-count3-01.log |
| Final focused PATH_MAX/wiring/AST rerun | 0 | rev6-focused-final-01.log |
| Registry derivation, acceptance-case edges, §2.4 authority tests | 0 | rev6-registry-tests-final-01.log |
| Configured go test -count=1 -v, six groups cover all 45 packages | 0 each | rev6-config-go-test-group-01.log through -05b.log |
| Configured go test -race -count=1 -timeout 25m, four groups cover all 45 packages (12+12+12+9) | 0 each | rev6-race-group-01.log through -04.log |
| Configured go test -cover -count=1, six groups cover all 45 packages | 0 each | rev6-config-cover-group-01.log through -05b.log |
| 17 configured fuzz targets, each -fuzztime=100x -parallel=1 | 0 each | rev6-fuzz-01.log through rev6-fuzz-17.log |

## Build, registry, and composition

| Command / gate | Exit | Evidence |
|---|---:|---|
| Configured gofmt check | 0 | rev6-gofmt-configured.log |
| go build ./... and go vet ./... | 0 each | rev6-go-build.log; rev6-go-vet.log |
| Linux build | 0 | rev6-go-build-linux.log |
| Windows build | 0 | rev6-go-build-windows.log |
| GOOS=windows GOARCH=amd64 go vet ./... | 0 | rev6-go-vet-windows.log |
| go run ./internal/traceability/cmd/tracecheck | 0 | rev6-tracecheck.log; exact text is in results and README |
| Registry re-derivation and decoded case-edge tests | 0 | rev6-registry-tests-final-01.log; pin 3664ab2fb166189545fea34a068a318af4f251689f29c92915fa185fefdedeea |
| README coverage plant 70→71 | 1 expected red | rev6-readme-coverage-plant-negative.log; TestREADMEMeasuredCoverageMatchesTracecheckReport fails on mismatch |
| Digest pin plant set to zero | 1 expected red | rev6-digest-rederive-plant.log; tracecheck reports actual digest mismatch |
| Importer grid against trunk 0ca3e4c | 0 | rev6-importer-grid-01.log and closuregrid-rev6-0ca3e4c/outcome-comparison.json; 192 shared rows, zero moved, 31 candidate-only |
| Adopted catalog check | 0 | rev6-cataloggen-check.log |
| JSON parse gate with pipefail | 0 | rev6-json-parse.log |
| task-board validate | 0 | rev6-task-board-validate.log; diagnostics are workspace-wide and name neither this task nor Story |
| git diff --check after edits | 0 | rev6-post-doc-diff-check.log |
| task-board.config.json byte-equal to trunk | 0 | rev6-config-byte-identity.log |

## Rev6 standalone mutants

| Plant | Test that fails / expected survivor | Evidence |
|---|---|---|
| N-ancestor-walk-callee-depth-cap-24 | TestCustodyAncestorWalkGeneratedDepthToPathMax; KILLED twice alone, raw test exit 1 | rev6-mutant-callee24-run-01.log, rev6-mutant-callee24-run-02.log, raw logs under rev6/mutants/ and rev6/mutants-pass-2/ |
| N-ancestor-walk-filesystem-root-depth-cap | TestCustodyAncestorWalkHasNoLengthDependentControlFlow; KILLED twice alone, raw test exit 1 | rev6-mutant-filesystem-root-cap-run-01.log, rev6-mutant-filesystem-root-cap-run-02.log, raw logs under rev6/mutants/ and rev6/mutants-pass-2/ |
| C-control | Harmless comment-only plant; SURVIVED, runner exit 0 | rev6-mutant-neutral-control-run-01.log and raw rev6/mutants-pass-2/C-control.log |

The 355-row harness was fully run twice at rev5. Rev6 adds two rows, so the complete 357-row harness was not rerun. Each new row ran alone twice; the neutral control was applied and survived. This limitation is stated in results and the conformance matrix.
