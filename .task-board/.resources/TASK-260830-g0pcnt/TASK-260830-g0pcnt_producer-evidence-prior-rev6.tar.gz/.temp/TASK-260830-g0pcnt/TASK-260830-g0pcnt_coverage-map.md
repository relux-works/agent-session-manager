# TASK-260830-g0pcnt Supplemental Coverage Map

Pinned authority: internal/specdoc/SPEC.v0.7.0.md §3.2, lines 806–813.
The producer brief supplied no catalog-derived surface table; that remains a
brief gap. This supplemental map records the custody axes exercised and does
not claim to replace the missing surface table.

## Whole-path oracle cells

TestCustodyModeOracleAtProductionEntries sweeps all 4096 low-12-bit modes at
each projected component position through Probe, Spawn, and Execute. The
current-path fixture contributes 7 positions × 3 entries = 21 cells. The
extra_nested_depth_08 fixture contributes 15 positions × 3 entries = 45 cells.
Together this is 22 fixture-position instances and 66 position/entry cells;
the oracle compares 270,336 mode/position/entry classifications.

| Fixture and position range | Production entries | Named test | Gate classes |
|---|---|---|---|
| current_path_depth, depth 00 socket leaf | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/current_path_depth/socket_leaf/<entry>/depth_00_socket_leaf | checkCustodySocket |
| current_path_depth, depth 01 runtime tmux directory | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/current_path_depth/runtime_tmux_dir/<entry>/depth_01_runtime_tmux_dir | ownerOnlyRuntimeDirMode |
| current_path_depth, depth 02 runtime root | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/current_path_depth/root/<entry>/depth_02_runtime_root | ownerOnlyCustodyRootMode |
| current_path_depth, ancestor depths 03–06 | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/current_path_depth/ancestor/<entry>/depth_XX_ancestor | writableByOthers |
| extra_nested_depth_08, depth 00 socket leaf | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/extra_nested_depth_08/socket_leaf/<entry>/depth_00_socket_leaf | checkCustodySocket |
| extra_nested_depth_08, depth 01 runtime tmux directory | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/extra_nested_depth_08/runtime_tmux_dir/<entry>/depth_01_runtime_tmux_dir | ownerOnlyRuntimeDirMode |
| extra_nested_depth_08, depth 02 runtime root | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/extra_nested_depth_08/root/<entry>/depth_02_runtime_root | ownerOnlyCustodyRootMode |
| extra_nested_depth_08, ancestor depths 03–14 | Probe, Spawn, Execute | TestCustodyModeOracleAtProductionEntries/extra_nested_depth_08/ancestor/<entry>/depth_XX_ancestor | writableByOthers |

Mutant attribution for the whole mode oracle is in the conformance matrix and
TRACEABILITY. Rev5 specifically re-ran the generated walk-length narrowings
below against the current candidate.

## Generated walk-length refusals

TestCustodyAncestorWalkGeneratedDepthAtProductionEntries varies extra nesting
from 1 through 16 and places mode 0777 at the nearest, middle, and deepest
non-root ancestor through all three production entries: 144/144 named
refusals, zero effects.

| Narrowing | What it admits | Named killer | Result |
|---|---|---|---|
| N-ancestor-walk-depth-cap-4 | Unsafe ancestor after four checked parents | TestCustodyAncestorWalkGeneratedDepthAtProductionEntries | KILLED twice, each run alone |
| N-ancestor-walk-depth-cap-6 | Unsafe ancestor after six checked parents | TestCustodyAncestorWalkGeneratedDepthAtProductionEntries | KILLED twice, each run alone |
| N-ancestor-walk-depth-cap-10 | Unsafe ancestor after ten checked parents | TestCustodyAncestorWalkGeneratedDepthAtProductionEntries | KILLED twice, each run alone |
| N-ancestor-walk-skips-deepest-generated-ancestor | Unsafe deepest non-root ancestor | TestCustodyAncestorWalkGeneratedDepthAtProductionEntries | KILLED twice, each run alone |
| N-ancestor-walk-depth-cap-ast-control | Adds an ancestor counter/cap | TestCustodyAncestorWalkHasNoLengthDependentControlFlow | KILLED twice, each run alone |
| N-ancestor-walk-early-return-ast-control | Adds return nil outside a root exit | TestCustodyAncestorWalkHasNoLengthDependentControlFlow | KILLED twice, each run alone |
| C-control | Harmless comment-only line-count-preserving change | None expected | SURVIVED twice |

## Other custody axes

| Axis | Test coverage | Bound or structural argument |
|---|---|---|
| Mode | All low 12-bit modes at every path position, both fixtures, all entries | Finite 4096-value domain is exhaustive. |
| Kind | Directory, regular file, symlink, FIFO, and socket projected at every position, both fixtures, all entries | Finite kind domain is enumerated. |
| Owner | Current, other non-root, and root at the socket leaf, runtime directory, and runtime root, both fixtures and all entries | Ancestor ownership is N2: SPEC §3.2 lines 810–813 does not define accepted owners for system ancestors. Owner: future tmux path-custody owner at checkCustodyAncestors. |
| Component-name byte length | Runtime-root and ancestor names through each production entry to the socket-path limit, plus the next refused length | CheckSocketLength bounds the complete path; no longer component reaches custody. TestCustodyPathComponentByteLengthsAtProductionEntries. |
| Component-name content | ASCII, .hidden, ..., two..dots, spaces, café, 猫, punctuation at runtime-root and ancestor positions through each entry | Custody has no component-name allowlist; path cleaning and no-follow metadata drive its decision. TestCustodyPathComponentNameContentAtProductionEntries. |
| Symlink-chain length | 1–16 links at socket leaf, runtime directory, runtime root, and ancestor through all entries | Each path check refuses at the first symlink without following the remaining chain. TestCustodySymlinkChainLengthAtProductionEntries. |

No tmux process is required for these witnesses. Every refusal checks the
literal refusal code/detail and zero effect counts; each admission reaches a
fake next stage.
