import sys
p='c/internal/tmuxserver/bind.go'; s=open('orig').read() if False else open('bind.orig').read()
k=sys.argv[1]
def rep(a,b):
    global s
    assert a in s, k; s=s.replace(a,b,1)
if k=='cap4': rep("cleaned := filepath.Clean(root)\n\tfor {","cleaned := filepath.Clean(root)\n\tn := 0\n\tfor {\n\t\tn++\n\t\tif n > 4 {\n\t\t\treturn nil\n\t\t}")
if k.startswith('callee'):
    N=k[6:]
    rep("\tif custodyModeProjection != nil {\n\t\treturn custodyModeProjection(path, mode)\n\t}\n\treturn mode","\tif custodyModeProjection != nil {\n\t\tmode = custodyModeProjection(path, mode)\n\t}\n\tif mode.IsDir() && strings.Count(path, \"/\") > "+N+" {\n\t\tmode &^= 0o022\n\t}\n\treturn mode")
    if '"strings"' not in s: rep('import (','import (\n\t"strings"')
if k=='neutral': rep("cleaned := filepath.Clean(root)","cleaned := filepath.Clean(filepath.Clean(root))")
open(p,'w').write(s)
