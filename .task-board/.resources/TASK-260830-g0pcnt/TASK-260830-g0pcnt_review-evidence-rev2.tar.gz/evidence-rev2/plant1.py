import sys,subprocess,shutil,filecmp,os
os.chdir('/tmp/g0r2/full')
P=[
("C-control","internal/tmuxserver/bind.go","// lstatCustodySocket is a test seam","// lstatCustodySocket is a  test seam"),
("M1-socket-admit-0606-combo","internal/tmuxserver/bind.go","\tif permissions&0o077 != 0 || permissions&0o600 != 0o600 {\n\t\treturn &Error{Code: CodeUnsafeSocketPath, Detail: \"socket permissions\"}","\tif (permissions&0o077 != 0 && permissions&0o077 != 0o006) || permissions&0o600 != 0o600 {\n\t\treturn &Error{Code: CodeUnsafeSocketPath, Detail: \"socket permissions\"}"),
("M2-ancestor-setgid-as-sticky","internal/tmuxserver/bind.go","\treturn info.Mode()&os.ModeSticky == 0","\treturn info.Mode()&(os.ModeSticky|os.ModeSetgid) == 0"),
("M3-execute-only-admit-permissions","internal/tmuxserver/lifecycle.go","\tif err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil {","\tif err := CheckSocketCustody(socket, lc.Root, lc.Platform); err != nil && !strings.Contains(err.Error(), \"socket permissions\") {"),
("M4-spawn-only-admit-ancestor","internal/tmuxserver/probe.go","\tif err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil {","\tif err := CheckSocketCustody(socket, spawner.Root, spawner.Platform); err != nil && !strings.Contains(err.Error(), \"socket ancestor\") {"),
("M5-root-admit-group-rx-only","internal/tmuxserver/bind.go","\tif permissions&0o077 != 0 || permissions&0o700 != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeSocketPath, Detail: \"socket root\"}","\tif (permissions&0o077 != 0 && permissions&0o077 != 0o050) || permissions&0o700 != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeSocketPath, Detail: \"socket root\"}"),
("M6-probe-only-admit-ownership","internal/tmuxserver/probe.go","\tif err := CheckSocketCustody(socket, prober.Root, prober.Platform); err != nil {","\tif err := CheckSocketCustody(socket, prober.Root, prober.Platform); err != nil && !strings.Contains(err.Error(), \"socket ownership\") {"),
]
sel=sys.argv[1:]
for name,path,f,r in P:
  if sel and name not in sel: continue
  src=open(path).read(); bak='/tmp/g0r2/plants/'+name+'.bak'; shutil.copy(path,bak)
  if src.count(f)!=1: print(name,'NOT_APPLIED',src.count(f)); continue
  new=src.replace(f,r)
  if 'strings.Contains' in r and '"strings"' not in src: new=new.replace('import (','import (\n\t"strings"',1)
  open(path,'w').write(new)
  try:
    p=subprocess.run(['go','test','-count=1','-run',os.environ['RUNX'],'./internal/tmuxserver/'],capture_output=True,text=True,timeout=560)
    open('/tmp/g0r2/plants/'+name+'.log','w').write(p.stdout+p.stderr)
    fails=[l.split()[2] for l in p.stdout.splitlines() if l.startswith('--- FAIL')]
    bf='FAIL' in p.stdout and 'build failed' in p.stdout
    print(name,'exit',p.returncode,'COMPILE_FAIL' if bf else ('KILLED' if p.returncode else 'SURVIVED'),fails[:6])
  finally:
    shutil.copy(bak,path); assert filecmp.cmp(bak,path,shallow=False)
