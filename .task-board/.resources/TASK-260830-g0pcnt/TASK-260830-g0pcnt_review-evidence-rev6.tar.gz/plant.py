import sys
p='internal/tmuxserver/bind.go'; s=open(sys.argv[2]).read(); m=sys.argv[1]
L='\t\tmode := custodyModeForPath(parent, info.Mode())\n'
if m=='callee24':
  a='\tif custodyModeProjection != nil {\n\t\treturn custodyModeProjection(path, mode)\n\t}\n\treturn mode\n'
  b='\tif custodyModeProjection != nil {\n\t\tmode = custodyModeProjection(path, mode)\n\t}\n\tif mode.IsDir() && strings.Count(path, "/") > 24 {\n\t\tmode &^= 0o022\n\t}\n\treturn mode\n'
elif m=='funcvar':
  a=L; b=L+'\t\tif ancestorSkip(parent) {\n\t\t\tmode &^= 0o022\n\t\t}\n'
  s=s.replace('func isFilesystemRoot(','var ancestorSkip = func(p string) bool { return len(p) > 600 && len(p) < 1000 }\n\nfunc isFilesystemRoot(',1)
elif m=='mapcap':
  a=L; b=L+'\t\tif _, deep := deepSet[len(parent)/100]; deep {\n\t\t\tmode &^= 0o022\n\t\t}\n'
  s=s.replace('func isFilesystemRoot(','var deepSet = map[int]struct{}{7: {}, 8: {}}\n\nfunc isFilesystemRoot(',1)
elif m=='neutral':
  a='\tcleaned := filepath.Clean(root)\n'; b='\tcleaned := filepath.Clean(filepath.Clean(root))\n'
assert s.count(a)==1,m; s=s.replace(a,b); open(p,'w').write(s)
