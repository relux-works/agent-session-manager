# TASK-260830-g0pcnt Conformance Matrix

## Scope and measured task coverage

Authority: internal/specdoc/SPEC.v0.7.0.md. The task description's v0.5.0 pin is stale per the producer handoff. Refreshed Story checkpoint: `8d944c7e6029742ff998c4cf453c44323b7664b3`, based on registry-bearing trunk `14d636e40fffbe8a044dcb80bb5ee28c0372f31b`.

Task acceptance coverage is **4 of 4 rows**:

| AC row | Production call site | Positive/recovery test | Negative/narrowing evidence | Verdict |
|---|---|---|---|---|
| Lost-response idempotency | Lifecycle.Execute → executeAttach | TestExecuteAttachLostResponseReplaysRecordedOutcome | N-attach-lost-response-replay bypasses replay only for the fixture client; test fails on a second stage/install or receipt change. | Driven |
| Reconnect/multi-attach policy | Lifecycle.Execute(attach) → executeAttach/checkAttachOverlap | TestAttachSameClientRetryWithPeerPresent; TestAttachOverlapRequiresMultiAttach; TestAttachOverlapRequiresMultipleInputClients; TestAttachOverlapAdmissionAtomicAcrossLifecycleInstances | N-attach-overlap-multi; N-attach-overlap-input; N-attach-overlap-replay-unproven; N-attach-postlock-generation. Each is run alone. | Driven |
| Socket substitution refusal | ServerProber.Probe; ServerSpawner.Spawn; all eight Lifecycle.Execute operation dispatches | TestServerProberRefusesSocketSubstitutionBeforeConnect; TestServerSpawnerRefusesSocketSubstitutionBeforeUnlinkOrSpawn; TestExecuteEveryOperationRefusesSocketSubstitutionBeforeDispatch | N-socket-identity-swap; N-socket-symlink; N-socket-ownership; N-socket-permissions. Each preserves other custody guards. | Driven |
| Ownership-neutral attach | Lifecycle.Execute(attach) → executeAttach | TestExecuteAttachDoesNotReadOrChangeSessionLease | N-attach-ownership-neutral performs a successor lease CAS if attach refreshes ownership; test fails. | Driven |

Additional inherited tests: TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable with N-attach-readonly-to-writable; TestForegroundAcquireComposesProductionProbeWithAttach; TestAcquireForegroundRefusesEveryCatalogDecoyRunning with N-foreground-fresh-decoy-wiring. The latter admits only a fresh headless_creation decoy. All are production-entry tests.

## Socket custody outcomes

| Entry | Substitution/member tested | Observable refusal boundary |
|---|---|---|
| ServerProber.Probe | Changed inode at derived path | Refuses before Dial; zero Dial/admission calls |
| ServerProber.Probe | Symlink at derived path | Refuses before Dial |
| ServerProber.Probe | Foreign owner or group/world access | Refuses before Dial |
| ServerSpawner.Spawn | Changed inode at derived path | Refuses before unlink and Runner/spawn |
| ServerSpawner.Spawn | Symlink, foreign owner, or permissive mode | Refuses before unlink and Runner/spawn |
| Lifecycle.Execute: create, attach, status, quiesce, safe-boundary, stop, terminate, restore | Changed inode, foreign owner, or permissive mode | Refuses before operation dispatch |
| Foreground Acquire → Production.ProbeServer | Valid private active socket | Composition reaches attach on the real production probe path |
| Background Acquire | Derived local socket connection | Unreachable: background admission verifies runtime custody then contacts broker; it does not connect/unlink/spawn the derived socket |
| All entries | Replacement after final socket lstat and before OS connect | Bound B46: Unix has no portable path-relative connect identity pin |

The socket permission narrowing keeps the CheckSocketCustody function token and admits only mode 0644, so static token presence cannot substitute for behavioral measurement. Its harness invokes the production caller-entry behavior suite.

## Attach state and effect table

| Case | Production entry | Expected state/effect | Named evidence |
|---|---|---|---|
| Same client retries after lost response | Lifecycle.Execute(attach) | Original vector, receipt, effect evidence, and timestamp replay; no second effect | TestExecuteAttachLostResponseReplaysRecordedOutcome |
| Same client reconnects while peer receipt exists | Lifecycle.Execute(attach) | Validated receipt replay is exempt from new-client overlap admission | TestAttachSameClientRetryWithPeerPresent |
| Distinct read-only client overlaps without multi_attach | Lifecycle.Execute(attach) | Refusal; no second durable receipt/vector | TestAttachOverlapRequiresMultiAttach |
| Distinct input client overlaps without required multi-input policy | Lifecycle.Execute(attach) | Refusal; no second writable receipt/vector | TestAttachOverlapRequiresMultipleInputClients; TestAttachConcurrentInputRequiresAXPolicy |
| Two Life instances race from empty census | Lifecycle.Execute(attach) | Persistent per-instance admission lock serializes census through receipt commit | TestAttachOverlapAdmissionAtomicAcrossLifecycleInstances |
| Generation rotates during lock wait | Lifecycle.Execute(attach) | Post-lock generation check refuses stale generation | TestAttachRefusesGenerationRotatedDuringLockWait |
| Read-only receipt is retried with InputAuthorized=true | Lifecycle.Execute(attach) | Literal idempotency_mismatch; no vector or receipt mutation | TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable |
| Attach attempts to refresh/transfer lease | Lifecycle.Execute(attach) | No lease read/refresh/event write; before/after state identical | TestExecuteAttachDoesNotReadOrChangeSessionLease |
| Receipt exists after disconnect/detach | Lifecycle.Execute(attach) | UNKNOWN liveness remains a possible peer; may conservatively block a new attach | B44, owned by a future authoritative receipt/protocol owner |

## Importer outcomes

The base is the exact task checkpoint. The candidate is that base plus this task's code delta. The corpus contains 224 rows over all 36 importer packages, with 224 shared keys, zero base-only keys, zero candidate-only keys, and one moved class.

| Package | Production entry | Input class | Base result | Candidate result |
|---|---|---|---|---|
| tmuxserver | ServerProber.Probe | permissive-0644 | ok: running=true; dial_calls=1; admit_calls=1 | error: tmux_unsafe_socket_path at socket permissions; dial_calls=0; admit_calls=0 |

ExecuteAttachOverlapRace was retained from the accepted vcx6yo corpus, not regenerated by the custom driver; its atomicity test was rerun on both base and candidate. No other input class moved.

## Mutation attribution

All selected rows were run individually with raw plant logs. Twelve narrowings were KILLED; C-control survived.

| Gate | Isolated narrowing | What it admits | Named behavioral killer |
|---|---|---|---|
| Attach replay | N-attach-lost-response-replay | Reinstalls the same attach for the fixture client | TestExecuteAttachLostResponseReplaysRecordedOutcome |
| Store idempotency | N-attach-readonly-to-writable | Read-only receipt replay becomes writable | TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable |
| Lease neutrality | N-attach-ownership-neutral | Attach refreshes ownership for fixture client | TestExecuteAttachDoesNotReadOrChangeSessionLease |
| Multi-attach | N-attach-overlap-multi | One-peer overlap without multi_attach | TestAttachOverlapRequiresMultiAttach |
| Multi-input | N-attach-overlap-input | One-peer concurrent input without multiple_input_clients | TestAttachOverlapRequiresMultipleInputClients |
| Replay proof | N-attach-overlap-replay-unproven | Receiptless fixture ID receives replay exemption | TestAttachSameClientRetryWithPeerPresent and overlap refusal tests |
| Generation | N-attach-postlock-generation | Rotated generation passes attach post-lock recheck | TestAttachRefusesGenerationRotatedDuringLockWait |
| Foreground decoy | N-foreground-fresh-decoy-wiring | Fresh headless_creation decoy passes running-server admission | TestAcquireForegroundRefusesEveryCatalogDecoyRunning |
| Socket identity | N-socket-identity-swap | Changed inode passes identity recheck | Prober, Spawner, and all-operation Lifecycle tests |
| Socket kind | N-socket-symlink | Symlink passes file-kind custody | Prober, Spawner, and all-operation Lifecycle tests |
| Socket ownership | N-socket-ownership | Foreign-owned socket passes owner check | Prober, Spawner, and all-operation Lifecycle tests |
| Socket permissions | N-socket-permissions | Exactly a 0644 socket passes permission gate | Prober, Spawner, and all-operation Lifecycle tests |
| Harness control | C-control | Harmless comment change | Survives as required control |

## Story-final registry convergence

The managed candidate refresh replayed the accepted Story checkpoints onto registry-bearing trunk `14d636e40fffbe8a044dcb80bb5ee28c0372f31b`. The decoded registry now carries all four Story leaves (`35urbp`, `1c28dz`, `vcx6yo`, `g0pcnt`) and the g0pcnt acceptance cases in their clause lists. `TestStoryV070AcceptanceCasesHaveClauseEdges`, registry rederivation, and exact-tree default tracecheck pass. The re-derived canonical registry digest is `3664ab2fb166189545fea34a068a318af4f251689f29c92915fa185fefdedeea`.

At final inspection, `origin/main` is `360c8bd79cc2325ab661a9ba591b6bfb82ebe0ea`. Its only delta after `14d636e40fffbe8a044dcb80bb5ee28c0372f31b` is `task-board.config.json`; it contains no later registry change. Therefore the conditional “trunk moved” registry requirement is satisfied at the current registry, and the digest was re-derived after the registry merge. The worktree candidate remains uncommitted for the Story snapshot.

The first bare `task-board` invocation resolved to an older `~/.local/bin/task-board` and refused the new config shape. Using the curated `/Users/iv/.curator/global/bin/task-board` wrapper succeeded for the scoped directive read; subsequent validation, resource, and handoff commands use that wrapper. This invocation-path correction is not a registry blocker.

## Exact census mirrored in the implementation traceability file

The following table sections are copied from internal/tmuxserver/TRACEABILITY.md so every cell has its named test plus isolated narrowing, bound with owner, or unreachable reason:


### Inherited overlap gate axes

### TASK-260922-vcx6yo review rework — gate axes

The rev1 verdict found that the lock and concurrent-input gate had only one
axis measured. The following table enumerates each owned gate across client
class, peer count, sorted peer position, replay versus new client, and
concurrent versus sequential calls. Every cell is either test-and-narrowing
evidence or an explicit bound with an owner.

| Gate | Client class | Peer count | Peer position in client-ID order | Same-client replay vs new client | Concurrent vs sequential | Server generation |
|---|---|---|---|---|---|
| `admissionlock` | `TestAttachOverlapAdmissionAtomicAcrossLifecycleInstances` / `N-attach-admission-lock` (input); `TestAttachReadOnlyOverlapAdmissionAtomicAcrossLifecycleInstances` / `N-M2-attach-admission-lock-input-only` (read-only) | Both paused tests race from an empty census through the first receipt install; after release the contender re-censuses one peer. `N-M2` kills the read-only narrowing. | BOUND: the key is the terminal instance and acquisition precedes `Peers` sorting. Owner: `AttachStore.AcquireAdmission`. | BOUND: the peer-present replay test is sequential; no concurrent duplicate-replay test isolates lock behavior. Replay/new share the same unconditional acquisition. Owner: `executeAttach`. | Both paused tests drive two independent Lifecycle values; `N-attach-admission-lock` and the reviewer-shaped `N-M2` run as isolated narrowing rows.  `TestAttachRefusesGenerationRotatedDuringLockWait` / `N-attach-postlock-generation` refuses a generation rotated while waiting before any receipt commits. |
| `overlapmulti` | `TestAttachOverlapRequiresMultiAttach` / `N-attach-overlap-multi` (read-only); `TestAttachOverlapRequiresMultiAttachForInputClient` / `N-attach-overlap-multi-input-client` (input-authorized) | One-peer refusal and a later two-peer refusal are driven by `TestAttachOverlapRequiresMultiAttach`; `N-attach-overlap-multi` admits the one-peer class. | BOUND: the decision reads only whether `len(peers)>0`, not ordering or receipt fields. Owner: `checkAttachOverlap`. | `TestAttachSameClientRetryWithPeerPresent` covers read-only and input replay; `N-attach-overlap-replay-unproven` admits a receiptless new client named as a peer. | BOUND: no second multi-attach-only concurrency mutant; the paused read-only empty-census interleaving is assigned to `admissionlock`. Both decisions execute under that same lock. Owner: `executeAttach` / `checkAttachOverlap`.  BOUND: `executeAttach` owns generation admission and post-lock recheck; the multi-attach decision consumes only the receipt census. No generation-specific capability narrowing. Owner: `executeAttach`. |
| `overlapinput` | `TestAttachOverlapInputRequiresMultipleInputClients` proves read-only observation remains allowed and new input refuses; `N-attach-overlap-input` weakens the gate. | One-peer input, two-peer mixed census, and three-peer census are exercised by `TestAttachOverlapInputRequiresMultipleInputClients` and `TestAttachOverlapInputGateChecksEveryPeer`; `N-M5-attach-overlap-input-first-peer-only` admits only the narrowed mixed-peer class. | `TestAttachOverlapInputGateChecksEveryPeer` sorts a read-only peer first, then one or two input-authorized peers; isolated `N-M5` kills both subtests. | `TestAttachSameClientRetryWithPeerPresent` covers validated read-only/input replay; `N-attach-overlap-replay-unproven` catches the receiptless new-client exemption, while `N-M5` catches a new input client with later input peers. | `TestAttachOverlapAdmissionAtomicAcrossLifecycleInstances` races input-authorized clients with `multiple_input_clients` absent for the contender; `N-attach-admission-lock` admits from the stale empty census. Sequential decisions are killed by `N-attach-overlap-input` and `N-M5`.  BOUND: `executeAttach` owns generation admission and post-lock recheck; the input-overlap decision consumes receipt flags and AX input policy. No generation-specific capability narrowing. Owner: `executeAttach`. |
| `attachaxpolicy` | `TestAttachConcurrentInputRequiresAXPolicy` refuses input without matching AX authorization using literal `terminal_backend_unauthorized`; `N-attach-ax-input-policy` admits that input class. | BOUND: the shared request gate consumes no peer count. Owner: `terminalbackend.CheckAttachRequest`. | BOUND: neither CheckAttachRequest call receives the peer slice. Owner: `terminalbackend.CheckAttachRequest`. | `TestAttachSameClientRetryWithPeerPresent` covers valid policy on read-only and input replay. BOUND: invalid-policy replay has no separate Lifecycle narrowing row; the store rechecks the same binding. Owner: `AttachStore.Attach`. | BOUND: no simultaneous AX-policy narrowing is claimed. The request is checked at entry and again in the receipt commit after the wait. Owner: `CheckAttachRequest` / `AttachStore.Attach`.  BOUND: `CheckAttachRequest` does not consume generation; `executeAttach` admits generation around the attach gate. Owner: `executeAttach`. |
| `overlapreplay` | `TestAttachSameClientRetryWithPeerPresent` covers read-only and input-authorized validated replay; `N-attach-overlap-replay-unproven` admits a receiptless caller. | BOUND: the replay cases include one other peer; more than one distinct peer is not separately driven. Owner: `AttachStore.Lookup`. | BOUND: requester proof uses `Lookup(session, instance, client)`; peer ordering does not prove replay. Owner: `checkAttachOverlap`. | The named replay test contrasts the Lookup-proven caller with a new client; isolated `N-attach-overlap-replay-unproven` kills bare-ID exemption. | BOUND: no concurrent duplicate replay is claimed; all requests acquire the same per-instance lock before Lookup. Owner: `executeAttach`.  BOUND: generation is admitted by `executeAttach`; receipt lookup only proves same-client replay. Owner: `executeAttach`. |
| `livenessunknown` | `TestAttachReceiptWithoutPositiveLivenessRemainsPossiblePeer` covers read-only and input-authorized receipts whose returned vectors have not been executed; `N-attach-liveness-unknown` retires the receipt and is killed. | BOUND: a single peer is the direct liveness witness; the protocol has no status or retirement signal, so all receipts returned by `Peers` remain possible. Owner: future authoritative receipt/protocol owner (B44). | BOUND: liveness reads no position or client-live field; `Peers` sorts but does not discard valid receipts. Owner: `AttachStore.Peers`. | BOUND: replay exclusion is receipt/key validation, not liveness; no positive evidence can retire another client's receipt. Owner: `checkAttachOverlap` / `AttachStore.Peers`. | BOUND: there is no mutable liveness signal to race; the read-only peer census is serialized by `admissionlock`. Owner: `AttachStore.Peers`.  BOUND: generation does not establish client liveness; no positive generation-aware retirement signal exists. Owner: future authoritative receipt/protocol owner (B44). |

Axis count: **16 of 36 cells** are test-and-narrowing witnessed; **20 of 36**
are explicit bounds above. The added generation axis has one measured cell and
five owner-named bounds. The gate × lifecycle-entry census contains six
gates × eight `Lifecycle.Execute` operation entries: six attach cells are
measured and 42 non-attach cells are unreachable because dispatch selects a
different handler. Symmetry: `attachaxpolicy` has 2 `CheckAttachRequest`
call sites / 1 shared gate / 1 lifecycle entry / 1 shared narrowing;
`admissionlock` has 2 OS lock implementations (`flock`, `LockFileEx`) / 1
shared API / 1 lifecycle call site / 1 Unix interleaving witness. Windows is
cross-built and vetted; this run has no Windows-host runtime witness.

Ratio: 270 measured of 5632 (50+10+210 M across Tables A/B/D;
Table C all U); 191 bound; 5171 unreachable with reasons. Every
driven refusal direction is measured except the bound cells: 27
driven but rowless (B22 singletons/forks, B23 normalized details,
B32 propagation, B36 singleton deps) and
160 named undriven gaps (B24/B25/B26/B28/B31 cells
and the 153 B39 reachable-undriven cells), each with its
owner below; B29/B40/B41/B42/B43/B44/B45 are non-cell bounds stated below.
(Table A's 4 B15 guard-name arms are bound outside this split.)

Table E: after-restore outcome grid (ExecuteWrapperRestore,
wrapper.go:97). Each row is one decided outcome with its evidence
condition, its backend effect, and the committed test plus the
narrowing row that kills a routing/order mutant through the
wrapper entry (test names drop the Test prefix):

| Outcome | Evidence condition | Backend effect | Test / row |
|---|---|---|---|
| launch | verified local win + valid materialization | executes backend restore exactly once | WrapperRestoreLocalWinResumes; reorder covered by N-wrapper-reorder-refresh |
| reattach | verified local win + recorded bootstrap pair | executes backend restore exactly once | WrapperRestoreReattachReplaysBackend; reorder covered by N-wrapper-reorder-refresh |
| attach_remote | refreshed remote winner + lapsed local grant + interactive | none (no backend op, no exec, no provider) | WrapperRestoreLapsedGrantRemoteOffer/attach; N-wrapper-reorder-refresh |
| takeover_offer | refreshed remote winner + lapsed local grant + non-capable attach | none (no backend op, no exec, no provider) | WrapperRestoreLapsedGrantRemoteOffer/takeover; N-wrapper-reorder-refresh |
| parked (remote-noninteractive) | refreshed remote winner + non-interactive terminal | none | WrapperRestoreParksWithoutEffects/remote-noninteractive; N-wrapper-reorder-refresh |
| parked (refresh-failed) | refresh error → unverified local knowledge | none | WrapperRestoreParksWithoutEffects/refresh-failed; N-wrapper-reorder-refresh |
| parked (no-adapter) | missing refresh adapter → unverified local knowledge | none | WrapperRestoreParksWithoutEffects/no-adapter; N-wrapper-reorder-refresh |
| parked (no-known-lease) | no lease known at all → zero winner | none | WrapperRestoreParksWithoutEffects/no-known-lease; N-wrapper-reorder-refresh |
| parked (invalid-material) | required materialization not admitted | none (routing mutant would execute) | WrapperRestoreParksWithoutEffects/invalid-material; N-wrapper-route-material |
| parked (refresh-timeout) | refresh blocks → cancelled at the bound, unverified | none | WrapperRestoreRefreshBoundMeasured/configured-50ms; N-refresh-bound-default (default leg) |
| parked (expired refresh) | refresh answers after the deadline with a nil error → rejected, unverified | none | WrapperRestoreExpiredRefreshParksUnverified; expiry covered by N-wrapper-refresh-expired |
| parked (late-answer race) | both-ready selection → the late answer never verifies | none | WrapperRestoreRefreshRaceRejectsLateAnswer; N-wrapper-refresh-expired |
| parked (non-cooperative adapter) | adapter ignores cancellation → the entry returns at the bound | none | WrapperRestoreRefreshBoundEnforced; N-wrapper-refresh-deadline |
| refuse (divergent winner) | refreshed winner ≠ carried restore authorization | none, failed local precondition | WrapperRestoreRefusesDivergentWinner(+Lease,+Epoch); N-wrapper-winner-lease, N-wrapper-winner-epoch |
| refuse (divergent session) | decision session ≠ restore session | none, failed local precondition | WrapperRestoreRefusesDivergentSession; N-wrapper-restore-session |
| refuse (divergent bootstrap) | decision bootstrap ≠ restore bootstrap | none, failed local precondition | ReviewWrapperBootstrapMustBindExecutedRestore; N-wrapper-restore-bootstrap |
| refuse (divergent instance) | admitted descriptor instance ≠ restore instance | none, failed local precondition | ReviewWrapperInstanceMustBindExecutedRestore; N-wrapper-restore-instance |
| refuse (divergent backend) | admitted descriptor backend ≠ restore backend | none, failed local precondition | WrapperRestoreRefusesDivergentBackend; N-wrapper-restore-backend |
| refuse (divergent generation) | admitted descriptor generation ≠ restore generation | none, failed local precondition | WrapperRestoreRefusesDivergentGeneration; N-wrapper-restore-generation |
| refuse (mode) | Decide.Mode != restore (incl. garbage) | none, invalid-arguments | WrapperRestoreRefusesMalformed; N-wrapper-mode |
| refuse (operation) | Restore.Operation != restore (incl. garbage) | none, invalid-arguments | WrapperRestoreRefusesMalformed; N-wrapper-operation |
| refuse (deps) | nil lifecycle or nil dependency | none, protocol-error | WrapperRestoreRefusesMalformed; B36 singleton (no narrowing row) |

The refresh runs before the decision on every row (N-wrapper-
reorder-refresh admits exactly the fixture session past the
refresh-success arm into stale local knowledge and is killed by
the offer/resume/park tests together), so the offer path never
presents the lapsed grant to backend restore authorization. The
resume rows execute only bound to the decided session, bootstrap,
instance, backend, generation, and winner as one composed
authorization (N-wrapper-restore-session, N-wrapper-restore-
bootstrap, N-wrapper-restore-instance, N-wrapper-restore-backend,
N-wrapper-restore-generation, N-wrapper-winner-lease,
N-wrapper-winner-epoch); late answers never verify whether they
arrive after the deadline (N-wrapper-refresh-expired) or the
adapter ignores cancellation (N-wrapper-refresh-deadline). No
production mesh transport backs the adapter (B37). Union-rival
ambiguity is unmodeled (B38). The parked wire result
of the backend restore entry itself (RestoredParked) stays a
backend-row concern, not a Table E row.

### Story-final leaf census

### TASK-260830-g0pcnt story-final conformance

Pinned scope is `internal/specdoc/SPEC.v0.7.0.md` v0.7.0: §3.2#8,
§4.2#4-#7/#9, and §4.C#3-#7. The adopted ownership registry carries the
four leaf cases plus the socket-custody case; the decoded clause-edge test
requires each case in the clause's `acceptance_cases` list. The canonical
registry digest and measured README subsection are verified by the task logs.

| Row | Production call site | Executed test | Narrowing evidence / bound |
|---|---|---|---|
| 93 | `Lifecycle.Execute` → `executeAttach` | `TestExecuteAttachLostResponseReplaysRecordedOutcome` | `N-attach-lost-response-replay` retries a lost response for the same key; the test compares the original durable receipt bytes/timestamp and proves one stage/install, one receipt, and no retry exec. |
| 94 | `Lifecycle.Execute` → `executeAttach`; composed after foreground `Acquire` | `TestAttachOverlapRequiresMultiAttach`, `TestAttachOverlapRequiresMultipleInputClients`, `TestAttachSameClientRetryWithPeerPresent`, `TestForegroundAcquireComposesProductionProbeWithAttach` | `N-attach-overlap-multi`, `N-attach-overlap-input`, and `N-attach-overlap-replay-unproven` are each run alone. Existing vcx6yo peer census/lock remains the authority; this leaf adds the real Production probe → Acquire → Execute attach composition. |
| 95 | `ServerProber.Probe`, `ServerSpawner.Spawn`, all eight `Lifecycle.Execute` operation dispatches | `TestServerProberRefusesSocketSubstitutionBeforeConnect`, `TestServerProberRefusesSocketSymlinkBeforeConnect`, `TestServerProberRefusesForeignSocketBeforeConnect`, `TestServerProberRefusesPermissiveSocketBeforeConnect`, `TestServerSpawnerRefusesSocketSubstitutionBeforeUnlinkOrSpawn`, `TestServerSpawnerRefusesSymlinkSocketBeforeMutation`, `TestServerSpawnerRefusesForeignOrPermissiveSocketBeforeMutation`, `TestExecuteEveryOperationRefusesSocketSubstitutionBeforeDispatch`, `TestExecuteEveryOperationRefusesForeignOrPermissiveSocket` | `N-socket-identity-swap`, `N-socket-symlink`, `N-socket-ownership`, and `N-socket-permissions` each narrow one custody member and run the named caller-entry tests. Refusal occurs before Dial, lifecycle dispatch, unlink, or spawn. A swap after final lstat and before OS connect remains B46. |
| 96 | `Lifecycle.Execute` → `executeAttach` | `TestExecuteAttachDoesNotReadOrChangeSessionLease` | `N-attach-ownership-neutral` injects a real successor-lease CAS through the attach dependency; the test fails if lease refresh is called and compares event/lease state before and after. |
| 97 | foreground `Acquire` running-server gate | `TestAcquireForegroundRefusesEveryCatalogDecoyRunning` | `N-foreground-fresh-decoy-wiring` admits exactly a fresh `headless_creation` decoy; the production Acquire test fails on that member while other decoys and stale generations continue to refuse. |

#### Gate × production-entry census

`U` means unreachable at that entry with the reason stated; `B` is an explicit
bound with its owner; `M` names a production-entry test and the isolated
narrowing that kills it. The attach overlap gates stay owned by vcx6yo and are
listed in the six-axis table above; this table records this leaf's gates and
all entries they can reach.

| Gate | Production entry | Cell |
|---|---|---|
| Fresh foreground decoy | Foreground `Acquire` | M `TestAcquireForegroundRefusesEveryCatalogDecoyRunning` / `N-foreground-fresh-decoy-wiring` |
| Fresh foreground decoy | Background `Acquire` | U Background routes only to broker-or-refuse; it never evaluates the running-server admission (`acquireBackground`). |
| Lost-response replay | `Lifecycle.Execute(attach)` | M `TestExecuteAttachLostResponseReplaysRecordedOutcome` / `N-attach-lost-response-replay` |
| Lost-response replay | Other seven `Lifecycle.Execute` operations | U Dispatch selects a different operation handler; none reads the attach receipt store. Owner: `Lifecycle.Execute`. |
| Read-only→writable replay | `Lifecycle.Execute(attach)` | M `TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable` / `N-attach-readonly-to-writable`; literal `idempotency_mismatch`, no vector or receipt mutation. |
| Read-only→writable replay | Other seven `Lifecycle.Execute` operations | U Dispatch selects a different operation handler; no attach receipt can be replayed. Owner: `Lifecycle.Execute`. |
| Ownership-neutral attach | `Lifecycle.Execute(attach)` | M `TestExecuteAttachDoesNotReadOrChangeSessionLease` / `N-attach-ownership-neutral`; no lease read, refresh, event write, or lease change. |
| Ownership-neutral attach | Other seven `Lifecycle.Execute` operations | U This property is scoped to the attach handler; other operation handlers have their own lease/fencing contracts. Owner: `Lifecycle.Execute`. |
| Socket kind, owner, mode, identity custody | `ServerProber.Probe` | M Prober substitution/symlink/foreign-owner/0644 tests above / `N-socket-identity-swap`, `N-socket-symlink`, `N-socket-ownership`, `N-socket-permissions`; zero Dial calls on refusal. |
| Socket kind, owner, mode, identity custody | `ServerSpawner.Spawn` | M Spawner substitution/symlink/foreign-owner/0644 tests above / the same four isolated narrowings; no unlink or Runner call on refusal. |
| Socket kind, owner, mode, identity custody | `Lifecycle.Execute` — create, attach, status, quiesce, safe-boundary, stop, terminate, restore | M `TestExecuteEveryOperationRefusesSocketSubstitutionBeforeDispatch` and `TestExecuteEveryOperationRefusesForeignOrPermissiveSocket` / all four custody narrowings; the tests cover all eight dispatch values. |
| Socket kind, owner, mode, identity custody | Foreground `Acquire` → `Production.ProbeServer` | M `TestForegroundAcquireComposesProductionProbeWithAttach` covers the real probe and subsequent attach on an active private socket; substitution itself is exercised at the `ServerProber.Probe` production adapter before `Dial`. |
| Socket kind, owner, mode, identity custody | Background `Acquire` | U Background verifies runtime custody then contacts the broker; the derived local tmux socket is not connected, unlinked, or spawned. Owner: `acquireBackground`. |
| Attach receipt gates | `Acquire` foreground/background | U Acquire has no attach receipt input and does not dispatch lifecycle attach. Owner: `Acquire` / lifecycle caller. |

#### Six axes for this leaf's gates

Each cell is a measured test-and-narrowing (`M`), an explicit bound (`B`), or
unreachable/not applicable (`U`) because that production gate does not consume
the axis. `N-*` rows are run individually; the attach overlap generation axis
is added to the predecessor's six-gate matrix above.

| Gate | Client class | Peer count | Peer position | Same-client replay vs new client | Concurrent vs sequential | Server generation |
|---|---|---|---|---|---|---|
| Lost-response replay | M `TestExecuteAttachLostResponseReplaysRecordedOutcome` / `N-attach-lost-response-replay` (input-authorized client) | B fixture has zero peers; peer policy is owned by `checkAttachOverlap`. | U no peer exists to order; owner `AttachStore.Peers`. | M first install followed by same-client retry under the same request key / `N-attach-lost-response-replay`. | B the lost response is retried sequentially; cross-instance serialization is owned by `admissionlock`. | B fixture generation is stable; rotated generation is independently measured by `TestAttachRefusesGenerationRotatedDuringLockWait` / `N-attach-postlock-generation`. Owner `executeAttach`. |
| Read-only→writable replay | M `TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable` / `N-attach-readonly-to-writable` (read-only receipt, input-authorized retry) | B fixture has zero peers; overlap gates own peer policy. | U no peer exists to order; owner `AttachStore.Peers`. | M same-client durable receipt replay with changed `InputAuthorized` / `N-attach-readonly-to-writable`. | B sequential retry only; concurrent duplicate-key arbitration is owned by `admissionlock`. | B generation is held constant; generation recheck is owned by `executeAttach`. |
| Ownership-neutral attach | M `TestExecuteAttachDoesNotReadOrChangeSessionLease` / `N-attach-ownership-neutral` (local-only authorized attach) | B one attach with no receipt peer; peer census remains the sole overlap authority. | U no peer position is present; owner `AttachStore.Peers`. | B one new-client attach is measured; a replay-specific lease-neutrality assertion is not separate. Owner `executeAttach`. | B no concurrent lease writer is raced; current test proves no attach-triggered lease refresh/CAS. Owner `executeAttach` / `sessrepo`. | B fixed generation; a generation rotation does not enter this ownership-neutrality test. Owner `executeAttach`. |
| Socket custody | U path-level check runs before attach client identity is consumed; client class does not enter `CheckSocketCustody`. | U no peer census exists at path custody. | U no ordered peer list exists at path custody. | U path custody precedes any attach receipt lookup. | B deterministic substitution is placed between socket lstat checks; a later concurrent swap before OS connect is B46. Owner `CheckSocketCustody`. | U socket custody does not consume a generation; attestation follows a successful connect. Owner `CheckSocketCustody`. |
| Foreground fresh-decoy gate | M `TestAcquireForegroundRefusesEveryCatalogDecoyRunning` / `N-foreground-fresh-decoy-wiring` (fresh `headless_creation` decoy) | U Acquire has no client receipt census. | U no client peers are supplied to Acquire. | U Acquire does not inspect attach replay keys. | U Acquire decoy admission is a single foreground server probe, not an attach admission race. | B generation is validated separately by `CheckServerAttested`; decoy gate only narrows fresh capability membership. Owner `Acquire`. |

Axis count for this leaf: **6 of 30 cells** are directly measured by named
tests plus narrowing mutants; the other 24 cells are explicitly bounded or
unreachable above. No tmux process runs in these tests.

#### Bounds dispositioned by this leaf

- **B44 remains open:** an attach receipt proves an admitted client claim, not
  a live tmux client. This protocol has no positive client identity/detach
  signal. Unknown liveness remains a possible peer and can conservatively block
  a later attach after detach. Owner: future authoritative receipt/protocol
  owner; overlap policy remains in `internal/termbind` and `executeAttach`.
- **B46:** after the second socket `lstat` confirms the same inode, a pathname
  replacement can still race before the OS `connect` resolves the pathname.
  Unix has no portable path-relative connect identity pin. Tests prove the
  injected swap during custody validation is refused before `Dial`; this
  narrower post-check interval remains owner-named and is not claimed closed.
- **Section 4.E replication:** no new replication prohibition claim is made;
  the runtime package has no replication transport to exercise in this leaf.

### Revision 2 — permission-bit custody census and importer outcomes

The socket, AX-owned tmux runtime directory, and socket root admit baselines 0600, 0700, and 0700 respectively. The ancestor baseline is a protected 0700 fixture. Each cell drives one added external permission bit through the named production entry. Refusal cells assert the exact code and full message and observe zero Dial, Runner/spawn, or lifecycle effects.

For non-Ax-owned system ancestors, SPEC §3.2 lines 810–812 requires rejecting unsafe permissions but does not prescribe a numeric mode mask. The implementation rejects group/other write because it can replace the derived socket and admits non-writable read/execute bits for path traversal. This is recorded as an interpretation, not as a numeric requirement stated by the specification. Sticky shared ancestors are separately driven at 01777 through all three entries by `TestCustodyPermissionBitCensusAdmitsStickyAncestor`.

| Gate | Fixture class / baseline | Added bit | Production entry | Executed test cell | Outcome and isolated narrowing |
|---|---|---:|---|---|---|
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o040` (`group_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/group_read/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-read` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o040` (`group_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/group_read/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-read` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o040` (`group_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/group_read/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-read` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o020` (`group_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/group_write/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-write` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o020` (`group_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/group_write/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-write` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o020` (`group_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/group_write/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-write` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o010` (`group_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/group_execute/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-execute` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o010` (`group_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/group_execute/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-execute` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o010` (`group_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/group_execute/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-group-execute` narrows this bit and is KILLED. `N-socket-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o004` (`other_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/other_read/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-read` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o004` (`other_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/other_read/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-read` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o004` (`other_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/other_read/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-read` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o002` (`other_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/other_write/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-write` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o002` (`other_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/other_write/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-write` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o002` (`other_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/other_write/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-write` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o001` (`other_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/socket_leaf/other_execute/Probe` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-execute` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o001` (`other_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/socket_leaf/other_execute/Spawn` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-execute` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodySocket` | `socket_leaf` / `0600` | `0o001` (`other_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/socket_leaf/other_execute/Execute` | Literal refusal before effects; `N-socket-leaf-mask-drop-other-execute` narrows this bit and is KILLED. `N-socket-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o040` (`group_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_read/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o040` (`group_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_read/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o040` (`group_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_read/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o020` (`group_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_write/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o020` (`group_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_write/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o020` (`group_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_write/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o010` (`group_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_execute/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o010` (`group_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_execute/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o010` (`group_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/group_execute/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-group-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-group-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o004` (`other_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_read/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o004` (`other_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_read/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o004` (`other_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_read/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-read` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o002` (`other_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_write/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o002` (`other_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_write/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o002` (`other_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_write/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-write` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o001` (`other_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_execute/Probe` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o001` (`other_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_execute/Spawn` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` | `runtime_tmux_dir` / `0700` | `0o001` (`other_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/runtime_tmux_dir/other_execute/Execute` | Literal refusal before effects; `N-runtime-dir-mask-drop-other-execute` narrows this bit and is KILLED. `N-runtime-dir-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o040` (`group_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/group_read/Probe` | Literal refusal before effects; `N-root-mask-drop-group-read` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o040` (`group_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/group_read/Spawn` | Literal refusal before effects; `N-root-mask-drop-group-read` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o040` (`group_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/group_read/Execute` | Literal refusal before effects; `N-root-mask-drop-group-read` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o020` (`group_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/group_write/Probe` | Literal refusal before effects; `N-root-mask-drop-group-write` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o020` (`group_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/group_write/Spawn` | Literal refusal before effects; `N-root-mask-drop-group-write` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o020` (`group_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/group_write/Execute` | Literal refusal before effects; `N-root-mask-drop-group-write` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o010` (`group_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/group_execute/Probe` | Literal refusal before effects; `N-root-mask-drop-group-execute` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o010` (`group_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/group_execute/Spawn` | Literal refusal before effects; `N-root-mask-drop-group-execute` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o010` (`group_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/group_execute/Execute` | Literal refusal before effects; `N-root-mask-drop-group-execute` narrows this bit and is KILLED. `N-root-mask-drop-group-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o004` (`other_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/other_read/Probe` | Literal refusal before effects; `N-root-mask-drop-other-read` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o004` (`other_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/other_read/Spawn` | Literal refusal before effects; `N-root-mask-drop-other-read` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o004` (`other_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/other_read/Execute` | Literal refusal before effects; `N-root-mask-drop-other-read` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o002` (`other_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/other_write/Probe` | Literal refusal before effects; `N-root-mask-drop-other-write` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o002` (`other_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/other_write/Spawn` | Literal refusal before effects; `N-root-mask-drop-other-write` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o002` (`other_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/other_write/Execute` | Literal refusal before effects; `N-root-mask-drop-other-write` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o001` (`other_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/root/other_execute/Probe` | Literal refusal before effects; `N-root-mask-drop-other-execute` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o001` (`other_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/root/other_execute/Spawn` | Literal refusal before effects; `N-root-mask-drop-other-execute` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyRoot` | `root` / `0700` | `0o001` (`other_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/root/other_execute/Execute` | Literal refusal before effects; `N-root-mask-drop-other-execute` narrows this bit and is KILLED. `N-root-mask-drop-other-triplet` also weakens its triplet. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o040` (`group_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/group_read/Probe` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o040` (`group_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/group_read/Spawn` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o040` (`group_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/group_read/Execute` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o020` (`group_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/group_write/Probe` | Literal refusal before effects; `N-ancestor-mask-drop-group-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o020` (`group_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/group_write/Spawn` | Literal refusal before effects; `N-ancestor-mask-drop-group-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o020` (`group_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/group_write/Execute` | Literal refusal before effects; `N-ancestor-mask-drop-group-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o010` (`group_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/group_execute/Probe` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o010` (`group_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/group_execute/Spawn` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o010` (`group_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/group_execute/Execute` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o004` (`other_read`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/other_read/Probe` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o004` (`other_read`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/other_read/Spawn` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o004` (`other_read`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/other_read/Execute` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o002` (`other_write`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/other_write/Probe` | Literal refusal before effects; `N-ancestor-mask-drop-other-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o002` (`other_write`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/other_write/Spawn` | Literal refusal before effects; `N-ancestor-mask-drop-other-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o002` (`other_write`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/other_write/Execute` | Literal refusal before effects; `N-ancestor-mask-drop-other-write` narrows this bit and is KILLED. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o001` (`other_execute`) | `ServerProber.Probe` | `TestCustodyPermissionBitCensus/ancestor/other_execute/Probe` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o001` (`other_execute`) | `ServerSpawner.Spawn` | `TestCustodyPermissionBitCensus/ancestor/other_execute/Spawn` | Admitted; effect count > 0 under the §3.2 interpretation. |
| `checkCustodyAncestors` | `ancestor` / `0700 fixture` | `0o001` (`other_execute`) | `Lifecycle.Execute` | `TestCustodyPermissionBitCensus/ancestor/other_execute/Execute` | Admitted; effect count > 0 under the §3.2 interpretation. |

Measured ratio: **72 of 72 component × bit × production-entry cells driven**: 60 refusal cells with bit-specific narrowing mutants and 12 ancestor read/execute cells admitted under the stated §3.2 interpretation. All 26 task-specific mask mutants were applied alone and killed (24 strict socket/runtime/root narrowings plus 2 ancestor-write narrowings); the line-count-preserving `C-control` survived.

#### Reviewer R1 exact socket modes

The rev1 reviewer found that weakening `permissions&0o077` to `permissions&0o070` admitted other-only modes. The committed test `TestCustodyPermissionSocketLeafExactModes` drives the exact requested modes 0602, 0604, 0606, and group-only 0620 through all three entries; each refusal asserts `tmux_unsafe_socket_path at socket permissions` and zero effects.

| Socket mode | Probe | Spawn | Execute | Killing narrowing |
|---:|---|---|---|---|
| `0602` | `TestCustodyPermissionSocketLeafExactModes/0602/Probe` | `TestCustodyPermissionSocketLeafExactModes/0602/Spawn` | `TestCustodyPermissionSocketLeafExactModes/0602/Execute` | `N-socket-mask-drop-other-triplet` (isolated; KILLED) |
| `0604` | `TestCustodyPermissionSocketLeafExactModes/0604/Probe` | `TestCustodyPermissionSocketLeafExactModes/0604/Spawn` | `TestCustodyPermissionSocketLeafExactModes/0604/Execute` | `N-socket-mask-drop-other-triplet` (isolated; KILLED) |
| `0606` | `TestCustodyPermissionSocketLeafExactModes/0606/Probe` | `TestCustodyPermissionSocketLeafExactModes/0606/Spawn` | `TestCustodyPermissionSocketLeafExactModes/0606/Execute` | `N-socket-mask-drop-other-triplet` (isolated; KILLED) |
| `0620` | `TestCustodyPermissionSocketLeafExactModes/0620/Probe` | `TestCustodyPermissionSocketLeafExactModes/0620/Spawn` | `TestCustodyPermissionSocketLeafExactModes/0620/Execute` | `N-socket-mask-drop-group-triplet` (isolated; KILLED) |

The two reviewer-matched narrowings are `permissions&0o077` → `permissions&0o070` (ignore the whole other triplet; R1) and `permissions&0o077` → `permissions&0o007` (ignore the whole group triplet). Both run `TestCustodyPermissionSocketLeafExactModes` alone and are KILLED. The one-bit socket modes also include 0602, 0604, and 0620 in the 72-cell table.

#### Six-axis enumeration for every custody gate

Each gate is enumerated against client class, peer count, peer position, replay versus new request, concurrent versus sequential access, and server generation. `U1`–`U4` mean the axis is not consumed because custody runs before the corresponding attach/client stage; `B46` is the measured sequential scope plus the explicit post-lstat/pre-connect race bound.

| Gate | Client class | Peer count | Peer position | Replay vs new | Concurrent vs sequential | Server generation |
|---|---|---|---|---|---|---|
| `checkCustodySocket` (`socket_leaf`) | `U1` before client identity | `U2` before peer census | `U2` no ordered peers | `U3` before receipt lookup | `B46` sequential permission cells; injected validation-time substitution is refused, but a replacement after final `lstat` and before OS `connect` remains open | `U4` before server attestation |
| `ownerOnlyRuntimeDirMode via commitRuntimeDir/verifyRuntimeDir` (`runtime_tmux_dir`) | `U1` before client identity | `U2` before peer census | `U2` no ordered peers | `U3` before receipt lookup | `B46` sequential permission cells; injected validation-time substitution is refused, but a replacement after final `lstat` and before OS `connect` remains open | `U4` before server attestation |
| `checkCustodyRoot` (`root`) | `U1` before client identity | `U2` before peer census | `U2` no ordered peers | `U3` before receipt lookup | `B46` sequential permission cells; injected validation-time substitution is refused, but a replacement after final `lstat` and before OS `connect` remains open | `U4` before server attestation |
| `checkCustodyAncestors` (`ancestor`) | `U1` before client identity | `U2` before peer census | `U2` no ordered peers | `U3` before receipt lookup | `B46` sequential permission cells; injected validation-time substitution is refused, but a replacement after final `lstat` and before OS `connect` remains open | `U4` before server attestation |

Owners for the unattached axes: client/request identity and receipt replay are in `Lifecycle.Execute` / `executeAttach`; peer count and position are in `AttachStore.Peers` / `checkAttachOverlap`; server-generation admission is in `CheckServerAttested`. B46 is explicit: the tests refuse the review-shaped socket swap during the custody check before Dial, but do not claim a portable pathname pin between final `lstat` and OS `connect`.

#### Outcome-keyed importer comparison

The complete candidate trunk importer set compared 192 base rows in 35 packages with 223 candidate rows in 36 packages. All 192 shared keys have identical outcomes; base-only = 0, moved = 0, candidate-only = 31. Candidate-only inputs are explicitly enumerated below by importer package and entry; the 27 `tmuxserver` rows are new to this Story package and the 4 `termbind.Peers` rows are new peer-census outcomes.

| Outcome key class | Keys | Result |
|---|---:|---|
| `termbind / Peers` | `bad-identity`, `corrupt`, `empty`, `found` (4) | Candidate-only; no prior trunk key to move. |
| `tmuxserver / BuildArgv` | `empty-session`, `empty-socket`, `valid` (3) | Candidate-only. |
| `tmuxserver / CheckSocketLength` | `long`, `short` (2) | Candidate-only. |
| `tmuxserver / ClassifyStatus` | `absent`, `live-tri`, `negative`, `parked`, `quiescing-memory` (5) | Candidate-only. |
| `tmuxserver / DirectivesFor` | `attach`, `bogus`, `create`, `manifest`, `probe`, `quiesce-input`, `request-stop`, `restore`, `status`, `terminate-stale`, `wait-safe-boundary` (11) | Candidate-only. |
| `tmuxserver / ResolveSocket` | `ambient`, `conventional` (2) | Candidate-only. |
| `tmuxserver / ServerProber.Probe` | `derived-path-symlink`, `owner-execute-0700`, `permissive-0644` (3) | Candidate-only; no base package entry exists in trunk. |
| `tmuxserver / SocketPath` | `fixed` (1) | Candidate-only. |

A supplementary comparison against the pre-rework Story checkpoint (223 keys, 36 packages) has 223 shared keys and exactly one moved class: `tmuxserver / ServerProber.Probe / permissive-0644` changes from success (`dial_calls=1`, `admit_calls=1`) to `tmux_unsafe_socket_path at socket permissions` before Dial (`dial_calls=0`, `admit_calls=0`). The evidence JSON and raw keyed rows are in `.temp/TASK-260830-g0pcnt/closuregrid-rev2-03/` and `closuregrid-rev2-checkpoint-02/`.

#### Mutation and harness attribution

The final shipped harness contains 338 rows: 336 expected KILLED, one harmless control SURVIVED, and one explicitly shadowed/dead narrowing SURVIVED. The 26 custody-mask mutants ran individually twice. One stale source anchor in `N-bind-root-writable` initially produced an ERROR in group 3 after predicate extraction; the anchor was corrected and that row was rerun alone and KILLED. The four `N-mode-*` anchors previously moved into a shared predicate were likewise re-anchored and independently killed before the final group 1 pass. Group logs and the standalone anchor retest remain task-scoped.

A source-text gate also has a token-preserving behavior mutation whose harness executes the behavioral suite; the checker token remains present while the changed production behavior is attacked.

