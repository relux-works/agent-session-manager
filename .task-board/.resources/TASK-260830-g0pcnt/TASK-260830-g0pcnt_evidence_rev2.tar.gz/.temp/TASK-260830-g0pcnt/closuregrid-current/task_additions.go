package main

import (
	"fmt"
	"net"
	"os"
	"path/filepath"
	"strings"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/tmuxserver"
)

type gridDialer struct {
	calls   int
	outcome tmuxserver.DialOutcome
}

func (d *gridDialer) Dial(string) tmuxserver.DialOutcome {
	d.calls++
	return d.outcome
}

func gridTmuxserverDirectives() {
	for _, operation := range []terminalbackend.Operation{
		"attach", "bogus", "create", "manifest", "probe", "quiesce-input",
		"request-stop", "restore", "status", "terminate-stale", "wait-safe-boundary",
	} {
		directives, err := tmuxserver.DirectivesFor(operation)
		if err != nil {
			emitErr("tmuxserver", "DirectivesFor", string(operation), err)
			continue
		}
		values := make([]string, len(directives))
		for i, directive := range directives {
			values[i] = string(directive)
		}
		emit("tmuxserver", "DirectivesFor", string(operation), "ok", "", strings.Join(values, " "))
	}
}

func gridSocketProbeOutcomes() {
	gridSocketProbe("owner-execute-0700", 0o700, false)
	gridSocketProbe("permissive-0644", 0o644, false)
	gridSocketProbe("derived-path-symlink", 0o600, true)
}

func gridSocketProbe(input string, mode os.FileMode, symlink bool) {
	tmp, err := os.MkdirTemp("/tmp", "axgrid")
	if err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	defer os.RemoveAll(tmp)
	root := filepath.Join(tmp, "r")
	if err := os.Mkdir(root, 0o700); err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	root, err = filepath.EvalSymlinks(root)
	if err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	_, err = tmuxserver.EnsureRuntimeDir(root, tmuxserver.RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	socket := tmuxserver.SocketPath(filepath.Join(root, tmuxserver.RuntimeDirName))
	target := socket
	if symlink {
		target = filepath.Join(root, "outside.sock")
	}
	listener, err := net.Listen("unix", target)
	if err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	defer listener.Close()
	if err := os.Chmod(target, mode); err != nil {
		emitErr("tmuxserver", "ServerProber.Probe", input, err)
		return
	}
	if symlink {
		if err := os.Symlink(target, socket); err != nil {
			emitErr("tmuxserver", "ServerProber.Probe", input, err)
			return
		}
	}
	dialer := &gridDialer{outcome: tmuxserver.DialLive}
	admitCalls := 0
	prober := tmuxserver.ServerProber{
		Root: root, Platform: scalar.PlatformMacOS, Dialer: dialer,
		Admit: func() (tmuxserver.RealmAdmission, error) {
			admitCalls++
			return tmuxserver.RealmAdmission{}, nil
		},
	}
	report, err := prober.Probe(socket)
	detail := fmt.Sprintf("dial_calls=%d;admit_calls=%d", dialer.calls, admitCalls)
	if err != nil {
		emit("tmuxserver", "ServerProber.Probe", input, "error", err.Error(), detail)
		return
	}
	emit("tmuxserver", "ServerProber.Probe", input, "ok", "", fmt.Sprintf("running=%t;%s", report.Running, detail))
}
