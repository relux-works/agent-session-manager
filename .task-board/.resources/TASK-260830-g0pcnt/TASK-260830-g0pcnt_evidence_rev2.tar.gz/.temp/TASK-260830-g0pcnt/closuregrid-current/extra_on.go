//go:build closuregrid_candidate

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/termbind"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/tmuxserver"
)

// gridTmuxserverExtra probes tmuxserver entries that exist only on the
// candidate (story-added after the CR base). The base run builds
// without the closuregrid_candidate tag and emits none of these
// records; the diff names them as declared candidate-only keys.
func gridTmuxserverExtra() {
	emitErr("tmuxserver", "CheckSocketLength", "short", tmuxserver.CheckSocketLength("/tmp/ax.sock", scalar.PlatformMacOS))
	emitErr("tmuxserver", "CheckSocketLength", "long", tmuxserver.CheckSocketLength("/tmp/"+strings.Repeat("s", 200)+".sock", scalar.PlatformMacOS))
	for _, tc := range []struct {
		name  string
		input tmuxserver.ClassifyInput
	}{
		{"live-tri", tmuxserver.ClassifyInput{Present: true, Attached: 1, AttachCapable: true}},
		{"parked", tmuxserver.ClassifyInput{Present: true, Attached: 0, AttachCapable: true}},
		{"quiescing-memory", tmuxserver.ClassifyInput{Present: true, Attached: 0, Memory: terminalbackend.StateQuiescing, MemoryFound: true, AttachCapable: true}},
		{"absent", tmuxserver.ClassifyInput{}},
		{"negative", tmuxserver.ClassifyInput{Present: true, Attached: -1, AttachCapable: true}},
	} {
		state, live, provider, foreign := tmuxserver.ClassifyStatus(tc.input)
		emit("tmuxserver", "ClassifyStatus", tc.name, "ok", "", fmt.Sprintf("%s/%v/%v/%v", state, live, provider, foreign))
	}
}

// gridTermbindExtra probes the termbind peer census, which exists
// only on the candidate. Same declared-key contract as above.
func gridTermbindExtra() {
	session := "0198f4c8-8e50-7f66-8f70-111111111111"
	instance := "0198f4c8-8e50-7f66-8f70-222222222221"
	clientA := "0198f4c8-8e50-7f66-8f70-333333333331"
	clientB := "0198f4c8-8e50-7f66-8f70-333333333332"
	auth := func(input bool) []byte {
		return []byte(fmt.Sprintf(`{"policy_evidence_id":"sha256:%s","authorizing_host_id":"0198f4c8-4a10-7b22-8b3c-1234567890ad","transport":"local_only","input_authorized":%v,"issued_at":"2026-08-19T04:00:00.000Z","expires_at":"2026-08-19T06:00:00.000Z"}`, strings.Repeat("a0", 32), input))
	}
	at := time.Date(2026, 8, 19, 5, 0, 0, 0, time.UTC)

	empty, err := termbind.OpenAttachStore(filepath.Join(workdir, "peers-empty"))
	if err != nil {
		emitErr("termbind", "Peers", "empty", err)
		return
	}
	peers, err := empty.Peers(session, instance, clientA)
	if err != nil {
		emitErr("termbind", "Peers", "empty", err)
	} else {
		emit("termbind", "Peers", "empty", "ok", "", fmt.Sprintf("peers=%d", len(peers)))
	}

	full, err := termbind.OpenAttachStore(filepath.Join(workdir, "peers-full"))
	if err != nil {
		emitErr("termbind", "Peers", "found", err)
		return
	}
	if _, _, err := full.Attach(session, instance, clientA, "local_only", true, auth(true), at); err != nil {
		emitErr("termbind", "Peers", "found", err)
		return
	}
	if _, _, err := full.Attach(session, instance, clientB, "local_only", false, auth(false), at); err != nil {
		emitErr("termbind", "Peers", "found", err)
		return
	}
	peers, err = full.Peers(session, instance, clientA)
	if err != nil {
		emitErr("termbind", "Peers", "found", err)
	} else if len(peers) != 1 {
		emit("termbind", "Peers", "found", "ok", "", fmt.Sprintf("peers=%d", len(peers)))
	} else {
		emit("termbind", "Peers", "found", "ok", "", fmt.Sprintf("peers=1/%s/%v", peers[0].ClientID, peers[0].InputAuthorized))
	}

	corrupt, err := termbind.OpenAttachStore(filepath.Join(workdir, "peers-corrupt"))
	if err != nil {
		emitErr("termbind", "Peers", "corrupt", err)
		return
	}
	if _, _, err := corrupt.Attach(session, instance, clientA, "local_only", true, auth(true), at); err != nil {
		emitErr("termbind", "Peers", "corrupt", err)
		return
	}
	if _, _, err := corrupt.Attach(session, instance, clientB, "local_only", false, auth(false), at); err != nil {
		emitErr("termbind", "Peers", "corrupt", err)
		return
	}
	peerFile := filepath.Join(workdir, "peers-corrupt", "termbind", "attach", instance, clientB+".json")
	if err := os.WriteFile(peerFile, []byte("corrupt"), 0o600); err != nil {
		emitErr("termbind", "Peers", "corrupt", err)
		return
	}
	_, err = corrupt.Peers(session, instance, clientA)
	emitErr("termbind", "Peers", "corrupt", err)

	_, err = full.Peers(session, "bogus!!", clientA)
	emitErr("termbind", "Peers", "bad-identity", err)
}
