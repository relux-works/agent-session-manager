from __future__ import annotations
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
TASK = ROOT / ".temp/TASK-260830-g0pcnt"
OUTPUT = TASK / "closuregrid-rev2-checkpoint-02"
BASE_REF = "8d944c7e6029742ff998c4cf453c44323b7664b3"
DRIVER = TASK / "closuregrid-current"
MODULE_PATH = Path("internal/sessadapter/testdata/closuregrid")

if OUTPUT.exists():
    raise SystemExit(f"refusing to overwrite {OUTPUT}")
OUTPUT.mkdir(parents=True)
base = OUTPUT / "base"
candidate = OUTPUT / "candidate"
base.mkdir()
base_oid = subprocess.run(["git", "rev-parse", BASE_REF], cwd=ROOT, check=True, text=True, capture_output=True).stdout.strip()
archive = subprocess.Popen(["git", "archive", "--format=tar", BASE_REF], cwd=ROOT, stdout=subprocess.PIPE)
if archive.stdout is None:
    raise SystemExit("git archive did not provide stdout")
with tarfile.open(fileobj=archive.stdout, mode="r|") as tar:
    for member in tar:
        if member.name == ".task-board" or member.name.startswith(".task-board/"):
            continue
        tar.extract(member, base, filter="data")
if archive.wait() != 0:
    raise SystemExit("git archive failed")
shutil.copytree(ROOT, candidate, ignore=shutil.ignore_patterns(".git", ".temp", ".task-board", ".planning", "DerivedData", "node_modules", ".DS_Store"))
for root in (base, candidate):
    dest = root / MODULE_PATH
    dest.mkdir(parents=True, exist_ok=True)
    for name in ("main.go", "task_additions.go", "extra_off.go", "extra_on.go"):
        shutil.copy2(DRIVER / name, dest / name)

command = ["go", "run", "-tags", "closuregrid_candidate", "./" + MODULE_PATH.as_posix()]
for name, root in (("base", base), ("candidate", candidate)):
    log = OUTPUT / f"{name}.jsonl"
    with log.open("w") as stream:
        proc = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
    if proc.returncode != 0:
        raise SystemExit(f"{name} grid exit={proc.returncode}; see {log}")

def rows(path: Path) -> dict[tuple[str, str, str], tuple[str, str, str]]:
    result = {}
    for number, line in enumerate(path.read_text().splitlines(), 1):
        row = json.loads(line)
        key = (row["package"], row["entry"], row["input"])
        value = (row["outcome"], row["code"], row["detail"])
        if key in result:
            raise SystemExit(f"duplicate key in {path}:{number}: {key}")
        result[key] = value
    return result

before = rows(OUTPUT / "base.jsonl")
after = rows(OUTPUT / "candidate.jsonl")
shared = before.keys() & after.keys()
base_only = sorted(before.keys() - after.keys())
candidate_only = sorted(after.keys() - before.keys())
moved = [(key, before[key], after[key]) for key in sorted(shared) if before[key] != after[key]]
summary = {
    "base_ref": base_oid,
    "supplementary_base_role": "pre-rework task checkpoint; not the requested trunk base",
    "candidate_worktree_head": subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT, check=True, text=True, capture_output=True).stdout.strip(),
    "base_rows": len(before), "candidate_rows": len(after),
    "base_packages": len({key[0] for key in before}), "candidate_packages": len({key[0] for key in after}),
    "shared_keys": len(shared), "base_only": [list(key) for key in base_only],
    "candidate_only": [list(key) for key in candidate_only],
    "moved": [{"key": list(key), "base": list(old), "candidate": list(new)} for key, old, new in moved],
}
(OUTPUT / "outcome-comparison.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
