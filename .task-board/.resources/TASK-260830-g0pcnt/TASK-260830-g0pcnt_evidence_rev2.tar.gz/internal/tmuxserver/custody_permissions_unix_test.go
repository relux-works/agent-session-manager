//go:build !windows

package tmuxserver

import (
	"context"
	"net"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/scalar"
)

type custodyPermissionClass struct {
	name   string
	base   os.FileMode
	code   string
	detail string
	refuse func(os.FileMode) bool
}

type custodyPermissionBit struct {
	name string
	mode os.FileMode
}

var custodyPermissionBits = []custodyPermissionBit{
	{name: "group_read", mode: 0o040},
	{name: "group_write", mode: 0o020},
	{name: "group_execute", mode: 0o010},
	{name: "other_read", mode: 0o004},
	{name: "other_write", mode: 0o002},
	{name: "other_execute", mode: 0o001},
}

func TestCustodyPermissionBitCensus(t *testing.T) {
	classes := []custodyPermissionClass{
		{
			name: "socket_leaf", base: 0o600, code: "tmux_unsafe_socket_path", detail: "socket permissions",
			refuse: func(os.FileMode) bool { return true },
		},
		{
			name: "runtime_tmux_dir", base: 0o700, code: "tmux_unsafe_runtime_dir", detail: "runtime mode",
			refuse: func(os.FileMode) bool { return true },
		},
		{
			name: "root", base: 0o700, code: "tmux_unsafe_socket_path", detail: "socket root",
			refuse: func(os.FileMode) bool { return true },
		},
		{
			name: "ancestor", base: 0o700, code: "tmux_unsafe_socket_path", detail: "socket ancestor",
			// SPEC §3.2 requires rejecting unsafe ancestor permissions. A
			// non-sticky ancestor may expose read/execute bits for path
			// traversal, but group/other write permits socket substitution.
			refuse: func(bit os.FileMode) bool { return bit&0o022 != 0 },
		},
	}
	entries := []string{"Probe", "Spawn", "Execute"}

	for _, class := range classes {
		class := class
		for _, bit := range custodyPermissionBits {
			bit := bit
			for _, entry := range entries {
				entry := entry
				t.Run(class.name+"/"+bit.name+"/"+entry, func(t *testing.T) {
					var root, socket string
					var fx *lxFixture
					var effectCount int
					var err error
					switch entry {
					case "Probe", "Spawn":
						root, socket = lxProbeRoot(t)
					case "Execute":
						fx = newLifecycleFixture(t, fullLifecycleAdmitted())
						root, socket = fx.root, fx.socket
					default:
						t.Fatalf("unhandled entry %q", entry)
					}

					applyCustodyPermissionMode(t, class.name, root, socket, class.base|bit.mode)

					err, effectCount = runCustodyPermissionEntry(t, entry, root, socket, fx)

					if class.refuse(bit.mode) {
						assertCustodyPermissionRefusal(t, err, class.code, class.detail)
						if effectCount != 0 {
							t.Fatalf("%s performed %d effect(s) before custody refusal", entry, effectCount)
						}
						return
					}
					if err != nil {
						t.Fatalf("SPEC §3.2 admitted ancestor permission %04o was refused by %s: %v", bit.mode, entry, err)
					}
					if effectCount == 0 {
						t.Fatalf("%s did not reach its production effect after the admitted permission", entry)
					}
				})
			}
		}
	}
}

func TestCustodyPermissionSocketLeafExactModes(t *testing.T) {
	modes := []struct {
		name string
		mode os.FileMode
	}{
		{name: "0602", mode: 0o602},
		{name: "0604", mode: 0o604},
		{name: "0606", mode: 0o606},
		{name: "0620", mode: 0o620},
	}
	entries := []string{"Probe", "Spawn", "Execute"}
	for _, mode := range modes {
		mode := mode
		for _, entry := range entries {
			entry := entry
			t.Run(mode.name+"/"+entry, func(t *testing.T) {
				var root, socket string
				var fx *lxFixture
				switch entry {
				case "Probe", "Spawn":
					root, socket = lxProbeRoot(t)
				case "Execute":
					fx = newLifecycleFixture(t, fullLifecycleAdmitted())
					root, socket = fx.root, fx.socket
				}
				applyCustodyPermissionMode(t, "socket_leaf", root, socket, mode.mode)

				err, effects := runCustodyPermissionEntry(t, entry, root, socket, fx)
				assertCustodyPermissionRefusal(t, err, "tmux_unsafe_socket_path", "socket permissions")
				if effects != 0 {
					t.Fatalf("%s performed %d effect(s) before refusing socket mode %s", entry, effects, mode.name)
				}
			})
		}
	}
}

func TestCustodyPermissionBitCensusAdmitsStickyAncestor(t *testing.T) {
	for _, entry := range []string{"Probe", "Spawn", "Execute"} {
		entry := entry
		t.Run(entry, func(t *testing.T) {
			var root, socket string
			var fx *lxFixture
			switch entry {
			case "Probe", "Spawn":
				root, socket = lxProbeRoot(t)
			case "Execute":
				fx = newLifecycleFixture(t, fullLifecycleAdmitted())
				root, socket = fx.root, fx.socket
			}
			ancestor := filepath.Dir(root)
			if err := os.Chmod(ancestor, 0o777|os.ModeSticky); err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() { _ = os.Chmod(ancestor, 0o700) })
			err, effects := runCustodyPermissionEntry(t, entry, root, socket, fx)
			if err != nil {
				t.Fatalf("SPEC §3.2 sticky ancestor mode 01777 was refused by %s: %v", entry, err)
			}
			if effects == 0 {
				t.Fatalf("%s did not reach its production effect with a sticky ancestor", entry)
			}
		})
	}
}

func runCustodyPermissionEntry(t *testing.T, entry, root, socket string, fx *lxFixture) (error, int) {
	t.Helper()
	switch entry {
	case "Probe":
		dialer := &fakeDialer{outcomes: []DialOutcome{DialStale}}
		prober := ServerProber{
			Root: root, Platform: scalar.PlatformMacOS, Dialer: dialer,
			Admit: func() (RealmAdmission, error) { return RealmAdmission{}, nil },
		}
		_, err := prober.Probe(socket)
		return err, len(dialer.calls)
	case "Spawn":
		runner := newFakeRunner().queue("new-session", "", 0)
		spawner := ServerSpawner{Root: root, Platform: scalar.PlatformMacOS, Runner: runner}
		argv, err := BuildArgv(filepath.Dir(socket), socket, lxSession)
		if err != nil {
			t.Fatal(err)
		}
		err = spawner.Spawn(socket, argv)
		return err, runner.callCount()
	case "Execute":
		if fx == nil {
			t.Fatal("Execute fixture is required")
		}
		recordBinding(t, fx, lxDigestA)
		fx.runner.queueFull("list-panes", "", "can't find window: "+lxInstance, 1)
		_, err := fx.lc.Execute(context.Background(), OpRequest{
			Operation: "status", Body: lxStatusBody(t, true, false, nil), Admitted: fullLifecycleAdmitted(),
		})
		return err, fx.runner.callCount()
	default:
		t.Fatalf("unhandled entry %q", entry)
		return nil, 0
	}
}

func applyCustodyPermissionMode(t *testing.T, class, root, socket string, mode os.FileMode) {
	t.Helper()
	var path string
	switch class {
	case "socket_leaf":
		listener, err := net.Listen("unix", socket)
		if err != nil {
			t.Fatal(err)
		}
		t.Cleanup(func() { _ = listener.Close() })
		path = socket
	case "runtime_tmux_dir":
		path = filepath.Join(root, RuntimeDirName)
	case "root":
		path = root
	case "ancestor":
		path = filepath.Dir(root)
	default:
		t.Fatalf("unknown custody component %q", class)
	}
	if err := os.Chmod(path, mode); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(path, classModeBaseline(class)) })
}

func classModeBaseline(class string) os.FileMode {
	switch class {
	case "socket_leaf":
		return 0o600
	case "runtime_tmux_dir":
		return 0o700
	case "root", "ancestor":
		return 0o700
	default:
		return 0
	}
}

func assertCustodyPermissionRefusal(t *testing.T, err error, code, detail string) {
	t.Helper()
	requireLocalCode(t, err, code, detail)
	want := "tmux server refused: " + code + " at " + detail
	if err.Error() != want {
		t.Fatalf("refusal message = %q, want literal %q", err.Error(), want)
	}
}
