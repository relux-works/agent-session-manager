# TASK-260830-g0pcnt Results — Revision 2

## Handoff state

This is the revised developer candidate for review of the rev1 socket-permission finding. The worktree remains **UNCOMMITTED** at the managed Story checkpoint `8d944c7e6029742ff998c4cf453c44323b7664b3`; no branch, index, commit, rebase, merge, or control-root file was changed directly. Task-board operations use the curated `/Users/iv/.curator/global/bin/task-board` wrapper. The developer handoff is run after this result and evidence archive are attached and the applicable checklist is current.

Rev1 verdict `TASK-260830-g0pcnt_review-verdict-rev1.md` was retrieved from the board and read. Its P2 finding was that socket custody checked 0600/0644 but missed other-only modes because narrowing `permissions&0o077` to `permissions&0o070` still admitted 0602/0604/0606 at Probe, Spawn, and Execute. This revision answers that finding with named tests and both reviewer-shaped triplet mutants.

## Acceptance coverage

**4 of 4 task acceptance rows are driven through production entries by named tests.** The additional changed properties (read-only escalation and foreground composition) are also driven through production entries.

| AC row | Production entry | Named test evidence | Result |
|---|---|---|---|
| Lost-response idempotency | `Lifecycle.Execute` → `executeAttach` | `TestExecuteAttachLostResponseReplaysRecordedOutcome` | Same-key retry yields the recorded vector/receipt/effects and original timestamp, with no second stage/install, receipt write, or retry exec. |
| Reconnect and multi-attach policy | `Lifecycle.Execute(attach)` → `executeAttach` / `checkAttachOverlap` | `TestAttachSameClientRetryWithPeerPresent`, `TestAttachOverlapRequiresMultiAttach`, `TestAttachOverlapRequiresMultipleInputClients`, `TestAttachOverlapAdmissionAtomicAcrossLifecycleInstances` | Validated same-client replay works with a peer present; a distinct peer requires `multi_attach`; concurrent input also requires `multiple_input_clients` and AX authorization. The durable peer census and cross-Lifecycle lock remain the vcx6yo authority. |
| Socket substitution refusal | `ServerProber.Probe`, `ServerSpawner.Spawn`, all eight `Lifecycle.Execute` operations | `TestServerProberRefusesSocketSubstitutionBeforeConnect`, `TestServerSpawnerRefusesSocketSubstitutionBeforeUnlinkOrSpawn`, `TestExecuteEveryOperationRefusesSocketSubstitutionBeforeDispatch` | Inode change, symlink, foreign owner, and permissive mode refuse before Dial, unlink/spawn, or lifecycle dispatch. Post-final-`lstat` replacement before OS connect remains bound B46. |
| Ownership-neutral attach | `Lifecycle.Execute(attach)` → `executeAttach` | `TestExecuteAttachDoesNotReadOrChangeSessionLease` | Attach neither reads nor refreshes the lease; the lease and session event chain remain unchanged. |

Supporting production-entry evidence:

- Read-only receipt replay with `InputAuthorized=true`: `TestExecuteAttachReadOnlyReceiptCannotEscalateToWritable` refuses literal `idempotency_mismatch`, returns no writable vector, and leaves the receipt unchanged. `N-attach-readonly-to-writable` weakens the store refusal and is killed.
- Foreground integration from 1c28dz: `TestForegroundAcquireComposesProductionProbeWithAttach` runs the real Production probe through foreground `Acquire` and then lifecycle attach against a private live Unix socket; no tmux process is started.
- Fresh-decoy wiring left open in 35urbp: `TestAcquireForegroundRefusesEveryCatalogDecoyRunning`; `N-foreground-fresh-decoy-wiring` admits only a fresh `headless_creation` decoy and the production test fails.
- README, doctor, and capability evidence make no new capability claim. The implementation advertises no unsupported doctor or CLI capability.

## Rev1 socket-permission finding and narrowing evidence

`TestCustodyPermissionSocketLeafExactModes` drives 0602, 0604, 0606, and group-only 0620 through `ServerProber.Probe`, `ServerSpawner.Spawn`, and `Lifecycle.Execute`. Each cell asserts the exact refusal `tmux_unsafe_socket_path at socket permissions` and zero Dial/Runner/dispatch effects.

| Reviewer narrowing | Production behavior weakened | Named killer | Isolated result |
|---|---|---|---|
| `N-socket-mask-drop-other-triplet` | `permissions&0o077` → `permissions&0o070`, admitting other-only socket modes | `TestCustodyPermissionSocketLeafExactModes` | KILLED; 0602/0604/0606 fail at all three entries. |
| `N-socket-mask-drop-group-triplet` | `permissions&0o077` → `permissions&0o007`, admitting group-only socket modes | `TestCustodyPermissionSocketLeafExactModes` | KILLED; 0620 fails at all three entries. |

The 72-cell permission census is **72 of 72 component × bit × production-entry cells driven**: socket leaf, AX runtime tmux directory, socket root, and lexical ancestors × six external mode bits × Probe/Spawn/Execute. Sixty refusal cells assert exact code/message and zero effects, with bit-specific narrowing evidence; 12 non-writable ancestor read/execute cells are admitted under the stated §3.2 interpretation. A 01777 sticky ancestor is separately admitted through all three entries. All 26 permission-mask mutants were applied alone in two rounds and killed. The two socket triplet mutants were additionally rerun against the exact reviewer-mode test alone after the new cases were added. Raw logs are `.temp/TASK-260830-g0pcnt/custody-mask-mutants-rev2-final-02.log` and the task-scoped mutant log directories.

For system-owned ancestors, SPEC §3.2 lines 810–812 requires refusal of unsafe ancestor permissions but gives no numeric mode mask. This implementation treats group/other write as unsafe because it can replace the socket, and admits non-writable read/execute for path traversal. This is marked as an interpretation, not a numeric rule stated by the spec.

## Six-axis and importer census

The conformance matrix and `internal/tmuxserver/TRACEABILITY.md` enumerate the custody gates across client class, peer count and position, replay/new request, concurrent/sequential calls, and server generation. For custody permission gates, client/peer/replay/generation axes are unreachable before identity, peer census, receipt lookup, or attestation. The permission matrix itself is sequential; B46 records the post-final-`lstat`/pre-connect replacement interval explicitly. Attach overlap axes remain owned by `AttachStore.Peers` / `checkAttachOverlap` and the existing vcx6yo tests.

Outcome-keyed comparison over the complete candidate trunk importer set (`.temp/TASK-260830-g0pcnt/closuregrid-rev2-03/`):

| Measure | Base: trunk `14d636e` | Candidate | Result |
|---|---:|---:|---|
| Rows / packages | 192 / 35 | 223 / 36 | 192 shared keys, 0 base-only, 0 moved, 31 candidate-only |

All candidate-only classes are listed in the matrix: 4 `termbind.Peers` outcomes (`bad-identity`, `corrupt`, `empty`, `found`) and 27 new `tmuxserver` rows across `BuildArgv` (3), `CheckSocketLength` (2), `ClassifyStatus` (5), `DirectivesFor` (11), `ResolveSocket` (2), `ServerProber.Probe` (3), and `SocketPath` (1). The 27 Story package rows have no trunk counterpart; moved classes are zero.

Supplementary pre-rework checkpoint comparison (`closuregrid-rev2-checkpoint-02/`): 223 shared keys, no base/candidate-only keys, exactly one moved class, `tmuxserver / ServerProber.Probe / permissive-0644`: success with one Dial/admit becomes `tmux_unsafe_socket_path at socket permissions` before Dial with zero effects.

## Story registry and traceability

The decoded `internal/traceability/ownership.v0.7.0.json` binds all four Story leaves and this task's acceptance case to executed clause edges: 35urbp, 1c28dz, vcx6yo, and g0pcnt. The canonical digest was re-derived with the registry's typed JSON encoding:

```text
3664ab2fb166189545fea34a068a318af4f251689f29c92915fa185fefdedeea
```

Exact-tree default tracecheck output:

```text
traceability ok: contracts=64 normative_sections=36 acceptance_cases=160 fixtures=33 compatibility_contracts=55 assigned_scopes=0
section coverage: bindings=70 full=4 partial=10 sliver=11 unevidenced=41 unmeasured=4 unowned=7 clauses_discharged=81/585
```

The README measured-coverage subsection matches this output. A planted README `bindings=71` mismatch makes `TestREADMEMeasuredCoverageMatchesTracecheckReport` fail; restoring the reported value makes the positive pin pass. Narrow section tracecheck results are recorded without broad claims: §2.4 passes; §3.2 is 1/13 sliver; §4.2 is 5/11 sliver; §4.C is 5/7 partial; §4.D is 1/3 sliver; §4.E has no scoped implementation owner. The story registry and clause edges are validated on the exact candidate tree.

## Mutation coverage

The full task harness contains 338 rows. The completed pre-exact-mode run resolved 336 expected KILLED rows and two expected SURVIVED rows: harmless `C-control`, and the documented shadowed/dead `D-attach-entry-deadline-shadowed` row. A stale patch anchor for `N-bind-root-writable` caused one ERROR in group 3; after correcting the anchor it was rerun alone and KILLED. Four moved `N-mode-*` anchors were corrected and killed before the final group 1 run. The subsequent 26-row custody-mask reruns above include the exact new mode tests. Group logs are under `.temp/TASK-260830-g0pcnt/mutants-final-02/`; the corrected anchor result is under `.temp/TASK-260830-g0pcnt/mutants-anchor-recheck/`.

The source-text gate is also attacked by a token-preserving behavior mutant; the harness executes the behavioral test suite while the searched token remains present.

## Validation

All results below were produced in this managed worktree. Raw command logs live under `.temp/TASK-260830-g0pcnt/`.

- Focused exact-mode + permission-bit census, `-count=3`: pass (`custody-exact-modes-focused-rev2.log`).
- Focused `tmuxserver` and `termbind` package suites: pass (`package-tests-final-02.log`).
- Full `go test ./... -count=1 -v`: post-exact-mode rerun passed across all 45 packages, exit 0 (`full-suite-rev2-final-postexact.log`).
- Full race sweep across 45 packages passed in four bounded groups (`race-suite-rev2-group-01.log` through `-04.log`). After adding the exact socket-mode cases, `go test -race ./internal/tmuxserver ./internal/termbind -count=1` passed (`race-touched-packages-rev2-postexact.log`).
- Full `go test ./... -cover -count=1` passed (`coverage-suite-rev2-final.log`).
- All 17 configured fuzz targets passed at 100 runs each in two groups (`fuzz-group-01-rev2.log`, `fuzz-group-02-rev2.log`, plus per-target logs).
- Native and Windows vet, native/Linux/Windows builds, catalog generation check, JSON parsing, gofmt, and diff checks passed (`vet-native-rev2-final.log`, `vet-windows-rev2-final.log`, `build-*-rev2-final.log`, `cataloggen-rev2-final.log`, `json-parse-rev2-final.log`, `hygiene-rev2-final.log`, and `hygiene-postexact-rev2-rerun.log`). The first post-exact diff check found a trailing blank line at EOF in `TRACEABILITY.md`; that line was removed and the rerun is clean. A scratch Python census checker also had a quote SyntaxError before running checks; the corrected census checker reports 72 rows.
- `go test ./internal/traceability/... -count=1`, exact default tracecheck, and README coverage positive/negative pin tests passed (`traceability-tests-final-03.log`, `tracecheck-exact-final.log`, and `readme-coverage-*-final.log`).
- The complete importer comparison, registry digest re-derivation (`registry-digest-rederived-postexact-rev2.log`), permission mask tests, current tracecheck output (`tracecheck-exact-postexact.log`), and standalone narrowing logs are included in `TASK-260830-g0pcnt_evidence_rev2.tar.gz` (below 1 MiB).

The curated task-board status transition succeeded and the current run's directives query reports no directives for `RUN-260923-7aa19c`. Final curated board validation exited 0 with 256 repository-wide findings and zero findings naming this task or Story (`task-board-validate-final-rev2.log`). The result, matrix, and sub-1-MiB rev2 evidence archive are attached as task-scoped outcomes and read back byte-for-byte before the developer handoff.

## Continuation verification — RUN-260923-47cac8

The candidate was left uncommitted on Story checkpoint `8d944c7e6029742ff998c4cf453c44323b7664b3`. A scratch `GIT_INDEX_FILE` measured the working candidate tree as `3a011937d7325693743f44ab7a6374ffde55449a`; the live index and tracked source were not changed by this continuation.

### Rerun in this continuation

- `go test ./... -count=1 -v`: exit 0 on the measured candidate tree.
- `go test ./... -cover -count=1`: exit 0; `tmuxserver` statement coverage 89.0%.
- `go test -count=3 ./internal/tmuxserver ./internal/termbind`: exit 0.
- Named production-entry suite with `-v -count=3`: exit 0. It includes the four AC tests, the socket substitution callers, ownership-neutral attach, read-only receipt replay, foreground Acquire composition and fresh-decoy gate, plus all 72 custody permission cells and the reviewer exact-mode cases.
- All 26 custody mask narrowings were individually applied and killed through `go test ./internal/tmuxserver ./internal/termbind`; the line-count-preserving `C-control` survived. The reviewer-shaped `N-socket-mask-drop-other-triplet` and `N-socket-mask-drop-group-triplet` were also rerun separately; both were killed by `TestCustodyPermissionSocketLeafExactModes` across Probe, Spawn, and Execute.
- `N-attach-readonly-to-writable` and `N-foreground-fresh-decoy-wiring` were rerun separately and killed by their named production-entry tests.
- `GOOS=windows GOARCH=amd64 go vet ./...`, native `go vet ./...`, native `go build ./...`, Linux and Windows builds, catalog generation check, JSON parse, gofmt, and `git diff --check`: exit 0.
- `go test -race ./internal/tmuxserver ./internal/termbind -count=1`: exit 0.
- README plant in a copied candidate: changing the measured line to `bindings=71` made `TestREADMEMeasuredCoverageMatchesTracecheckReport` fail for that mismatch; restoring the copy made the test pass.
- Fresh outcome-keyed importer grid on base `14d636e40fffbe8a044dcb80bb5ee28c0372f31b`: 192 base rows / 35 packages and 223 candidate rows / 36 packages; 192 shared keys unchanged, 0 base-only, 31 candidate-only, 0 moved. The matrix names every candidate-only key.
- Registry digest was re-derived from the typed JSON projection as `3664ab2fb166189545fea34a068a318af4f251689f29c92915fa185fefdedeea`. Exact-tree tracecheck passed:
  ```text
  traceability ok: contracts=64 normative_sections=36 acceptance_cases=160 fixtures=33 compatibility_contracts=55 assigned_scopes=0
  section coverage: bindings=70 full=4 partial=10 sliver=11 unevidenced=41 unmeasured=4 unowned=7 clauses_discharged=81/585
  ```
  `go test ./internal/traceability/... -count=1` passed. A decoded registry check confirmed clause edges and production owners for all four Story leaves and trunk case `story-260922-derivation-side-profile-source` (`internal/sessprofile/authority.go:Derive`, §2.4#2).
- Canonical `task-board validate`: exit 0, 256 pre-existing repository-wide issues, no findings naming this task or Story. The current task status is `development`; current RUN directives query returned none.

### Accepted from the already-attached rev2 evidence

The current continuation made no tracked source changes. I accepted the full 45-package race sweep from the four bounded logs `race-suite-rev2-group-01.log` through `-04.log`, plus the post-exact-mode touched-package race rerun, and the 17 configured fuzz targets from `fuzz-group-01-rev2.log` / `fuzz-group-02-rev2.log`; their individual exits are 0. These artifacts remain in the attached rev2 archive. This continuation independently reran the full default and coverage suites, current Windows/native vet and builds, determinism, the README plant, importer grid, digest/tracecheck, all 26 mask mutants, inherited narrowings, and touched-package race.

### Delivery state

The trunk pointer advanced from `14d636e` to `360c8bd79cc2325ab661a9ba591b6bfb82ebe0ea` with a config-only change to `task-board.config.json`; this candidate does not change that file. The previous managed Change Request construction refused with `change_request_base_authority_mismatch` because checkpoint `8d944c7e6029742ff998c4cf453c44323b7664b3` does not descend from selected authority `360c8bd79cc2325ab661a9ba591b6bfb82ebe0ea`. The rev2 instruction says not to refresh for that config-only commit; the Story orchestrator must reparent during integration. I will run the required developer handoff after these current outcomes are attached and record its actual result.
