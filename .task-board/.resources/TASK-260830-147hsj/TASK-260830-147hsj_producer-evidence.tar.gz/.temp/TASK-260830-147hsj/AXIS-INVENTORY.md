# TASK-260830-147hsj Axis Inventory

Authority: pinned `internal/specdoc/SPEC.v0.7.0.md` v0.7.0. The task record's
v0.5.0 reference is stale. This file records the measured domains exercised by
the implementation tests; it is not a surface table supplied by the brief.
The brief has no formal surface table, so the handoff reports that gap and uses
the six-row acceptance decomposition in `internal/merkleinventory/coverage-map.md`.

## Gate × entry × axis census

| Gate and production entry | Varied domain and named test | Narrowing and explicit bound |
| --- | --- | --- |
| Client duplicate-ID refusal: `FetchObjects` | `[unique singleton, duplicate IDs]`; duplicate request is refused before `ObjectsGet`. `TestFetchObjectsRefusesDuplicateIDs`. | `fetch-dup-ids` admits one duplicate pair and is run against that test alone. Other request sizes and the 4096-ID cap are owned by the existing bounded request tests. |
| Exact base64url response: `FetchObjects` → `decodeOneWireObject` | Valid URL-safe bytes with an embedded CRLF at the midpoint; decode must reject although Go's strict decoder skips CR/LF. `TestFetchObjectsRefusesNewlineBearingBase64urlData`. | `b64-roundtrip` removes byte-for-byte re-encode equality and is run against the named test alone. Structural bound: the response is accepted only when `Encode(Decode(data)) == data`, so every skipped CR/LF position and every alternate spelling differs from its original input. |
| Recursive local quarantine: `MissingObjectIDs` → `walkMissing` | Identity `[locally absent, locally present, locally quarantined]` against a peer identity set. `TestMissingObjectIDsRefusesLocalQuarantinedIdentity`. | `walk-quarantine` exempts the tested quarantined record ID and is run alone. |
| Recursive cross-namespace defense: `MissingObjectIDs` → `walkMissing` | Requested `record` × stored `manifest` with the exact same digest; `TestMissingObjectIDsRefusesCrossNamespaceIdentity`. | `walk-crossns` exempts this cell and is run alone. The fixture directly seeds malformed internal state; `ClassifyJSON` + `AddJSON` cannot construct it absent a SHA-256 collision. The public-ingest arm is therefore explicitly bounded as unreachable; the defensive walker arm is reachable under the test's internal-state seed. |
| Durable admission and replay: `DurableIndex.AddJSON` → `ClassifyJSON` / atomic install; `OpenDurable` → `load` | Valid objects in each JSON namespace `[event,manifest,record,tombstone,tombstone_ack]`; invalid inputs `[malformed JSON, unknown schema]`; install crash `[after file and directory sync]`; replay `[identical bytes after process exit/reopen]`; corrupt persisted payload `[exact forged JSON]`. Tests: `TestDurableJSONAddIsIdempotentAcrossCrashRestartByNamespace`, `TestDurableAddRejectsBeforePersistingInvalidObjects`, `TestDurableStoreRejectsCorruptActiveBytesOnOpen`. | `durable-event-replay`, `durable-unknown-schema-admit`, and `durable-load-skips-forged-object` each target one admitting cell and run against the named test alone. Canonical identity and schema shape remain delegated to `ClassifyJSON` / `canonicaljson`. |
| Common-ID audit and missing-object sync: `DurableIndex.SyncFrom` | Namespace `[event,manifest,record,tombstone,tombstone_ack]`; one missing validated object in each; common ID `[identical bytes, same digest with whitespace-distinct bytes]`; equal Merkle roots do not bypass byte audit. `TestDurableSyncFindsMissingJSONObjectsAndRetainsTombstoneRecords`, `TestDurableSyncAuditsCommonIDsAndQuarantinesDifferentBytes`. | `sync-missing-record-fetch`, `sync-common-record-audit`, and `durable-same-id-different-bytes` are isolated against named tests. `FetchObjects` batching `[1,2,4096,4097]` and 4096 cap belong to existing bounded-client tests; this sync fixture has one missing identity per namespace. |
| Quarantine crash recovery: `DurableIndex.AddJSON` / `SyncFrom` | Process termination `[after first candidate, after both candidates, after active-object removal]`, reopen, active-root absence, quarantine refusal, and sync retry refusal. `TestDurableConflictCrashRestoresQuarantineAndAbortsSync`. | `quarantine-crash-recovery` allows exactly one-candidate persisted state to reopen as active and is run alone. These are process-crash points, not physical power loss. |
| Tombstone/Acknowledgement union closure: `DurableIndex.SyncFrom` / `ValidateUnionClosure` | Arrival `[Ack before Tombstone]`; closure inputs `[missing Tombstone, matching Tombstone, subject mismatch]`; the Ack-only union remains stored on refusal and recovers when its Tombstone arrives; mismatch refusal retains both byte strings. Tests: `TestDurableSyncFindsMissingJSONObjectsAndRetainsTombstoneRecords`, `TestDurableSyncRefusesUnclosedAcknowledgementThenRecovers`, `TestDurableSyncRefusesAcknowledgementWithMismatchedTombstoneSubject`. | `union-ack-arrival-order`, `sync-skip-tombstone-union`, `sync-unclosed-tombstone-ack`, and `durable-ack-subject-link` are isolated against the named tests. Closure validates but does not execute either immutable record. |
| Projection's closed-union and exact-authority guards: `Index.RebuildProjection` / `DurableIndex.RebuildProjection` | Authority inputs `[record missing, authoritative event missing, Ack missing Tombstone]`; record/event bytes must be byte-identical to union copies. Tests: `TestProjectionRebuildRefusesAuthorityBytesMissingFromUnion`, `TestProjectionRebuildRefusesUnclosedAcknowledgement`. | `projection-missing-union-record`, `projection-missing-union-event`, `projection-skip-unclosed-ack` each narrow one guard and run against the named entry test alone. Repository ownership of the chain is an explicit implementation bound: no second arbitrary event-DAG reader is introduced. |
| Lease-head derivation: `Reader.LeaseHeadsForSession` | Generated set sizes `[0..32]`, each with distinct valid UUIDv4 IDs; input list and diagnostic timestamps are reversed in paired calls. Expected tuples are independently sorted from generated literals. `TestLeaseHeadsForSessionCoversGeneratedCardinalityRange`. | `union-lease-generated-cardinality-omission` omits one generated tuple at size 17 and is run alone. Structural bound beyond 32: one-pass identity validation and map de-duplication followed by tuple sort; no branch depends on a fixture cardinality. |
| Competing lease records and duplicate lease identity: `Reader.LeaseHeadsForSession` | Two same-epoch UUIDs in both input orders and both opposing `created_at` orders; same lease UUID with different validated bytes. Tests: `TestLeaseHeadsForSessionReturnsEveryTupleAcrossTimestampPerturbation`, `TestLeaseHeadsForSessionRefusesConflictingBytesForOneLeaseID`. | `union-lease-tuple-omission`, `union-lease-created-at-winner`, `union-lease-conflicting-same-id` each narrow a distinct behavior and run against its named test alone. The literal pinned winner is independently asserted by the projection oracle. |
| Projection order/timestamp invariance and divergent branch preservation: `Index.RebuildProjection` plus durable wrapper | Six permuted additions (`2 Lease Records + 2 Session Events + Tombstone + Ack`, `6! = 720`) under two opposite timestamp profiles = `1,440` in-memory production rebuilds. A Session Record is a fixed validated authority precondition present in every union. The test varies full addition order, two same-epoch competing lease IDs, one authoritative `session.created`, one divergent `session.idle`, Tombstone/Ack presence, and extreme `created_at` values. `TestProjectionRebuildExhaustsUnionArrivalsWithoutTimestampAuthority`. | `union-lease-created-at-winner` and `projection-drops-union-head` run against the full oracle test alone. It asserts literal state `creating`, literal winning tuple, literal conflict kinds, the reference ID/byte set, all five namespace counts and roots. It also asserts the losing event bytes remain in the union while only the repository-owned chain reaches the reducer. The independent reference is explicit expected values; the first permutation is used only as a cross-permutation equality witness. |

## Structural argument and scope bounds

The union snapshot sorts object IDs before enumerating lease records. The
`LeaseHeadsForSession` result carries only `(epoch, lease_id)` and drops
`created_at`; the reducer compares this complete tuple set using the existing
`(epoch, UUID-byte-order)` comparator. `RebuildProjection` takes no clock input
and does not call `time.Now`; no map or filesystem enumeration order is passed
to the reducer. Therefore, for a fixed `sessrepo` authority snapshot and an
immutable union set, the rebuild is a pure deterministic fold independent of
union insertion order and timestamps. The authoritative event chain is still
owned by `sessrepo`; exact record/event bytes must be present in the union
before the existing `sessstate.Projector` is called. This leaf preserves every
union event object but does not reconstruct a second event DAG from arbitrary
branches.

Out-of-contract rows and their controlling clauses are listed in
`internal/merkleinventory/CONFORMANCE-MATRIX.md`: raw blob/chunk staging and
materialization are §§11.5–11.6 boundary-only; public network, Host Channel,
`ax sync`, doctor/capability publication are not defined by this package task;
physical disk faults, power loss, and native Windows crash behavior are not
modeled by child-process termination; full digest and UUID domains remain
owned by `canonicaljson` and `scalar`. No formal surface table was supplied by
the brief. The measured acceptance ratio remains 6 of 6 derived rows; see the
package coverage map and traceability supplement for call sites, tests, and
individual mutant names.
