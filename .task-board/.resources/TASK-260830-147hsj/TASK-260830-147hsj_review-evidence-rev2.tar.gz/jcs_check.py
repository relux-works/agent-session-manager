import json,hashlib,sys
fx=json.load(open(sys.argv[1]))
def jcs(v): return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
bad=0
for k,raw in sorted(fx.items()):
  o=json.loads(raw); ok=None
  for f in [x for x in o if isinstance(o[x],str) and o[x].startswith('sha256:')]:
    c={a:b for a,b in o.items() if a!=f}
    if "sha256:"+hashlib.sha256(jcs(c).encode()).hexdigest()==o[f]: ok=f
  canon = jcs(o)==raw
  bad += (ok is None) or not canon
  print(k,'canonical' if canon else 'NONCANONICAL','self=',ok)
print('mismatches',bad)
