import subprocess,sys,shutil,pathlib
P=pathlib.Path('plant');D='internal/merkleinventory/durable.go';I='internal/merkleinventory/index.go'
plants=[
("R1-timestamp-winner",D,"""	index.mu.RUnlock()
	reader := &sessquery.Reader{LeaseRecords: leaseRecords}""","""	index.mu.RUnlock()
	if len(leaseRecords) > 1 { best := leaseRecords[0]; for _, r := range leaseRecords { if bytes.Compare(r[bytes.Index(r, []byte("created_at")):], best[bytes.Index(best, []byte("created_at")):]) > 0 { best = r } }; leaseRecords = [][]byte{best} }
	reader := &sessquery.Reader{LeaseRecords: leaseRecords}""","^TestProjectionRebuildExhaustsUnionArrivalsWithoutTimestampAuthority$"),
("R2-insertion-order",I,"""	return index.insertLocked(membership.Namespace, membership.ID.String(), data, true)
}""","""	if membership.Schema == "urn:ax:schema:lease" { LastLeaseForPlant = bytes.Clone(data) }
	return index.insertLocked(membership.Namespace, membership.ID.String(), data, true)
}
var LastLeaseForPlant []byte""","^TestProjectionRebuildExhaustsUnionArrivalsWithoutTimestampAuthority$"),
("R3-losing-branch-leak",D,"""	return (&sessstate.Projector{Repo: repo, Union: leaseHeads}).Project(sessionID)""","""	p, perr := (&sessstate.Projector{Repo: repo, Union: leaseHeads}).Project(sessionID)
	index.mu.RLock(); for _, o := range index.objects["event"] { if bytes.Contains(o.data, []byte(`"session.idle"`)) { p.State = sessstate.State("idle") } }; index.mu.RUnlock()
	return p, perr""","^TestProjectionRebuildExhaustsUnionArrivalsWithoutTimestampAuthority$"),
("R4-quarantine-forgotten-on-restart",D,"""	for id, candidates := range quarantined {
		store.index.quarantine[id]""","""	for id, candidates := range quarantined {
		if len(candidates) == 2 { continue }
		store.index.quarantine[id]""","^TestDurableConflictCrashRestoresQuarantineAndAbortsSync$"),
("R5-restart-drops-ack",D,"""		if err := store.index.AddUnionJSON(object.data); err != nil {
			return fmt.Errorf("%w: rebuild""","""		if object.namespace == "tombstone_ack" { continue }
		if err := store.index.AddUnionJSON(object.data); err != nil {
			return fmt.Errorf("%w: rebuild""","^TestDurableJSONAddIsIdempotentAcrossCrashRestartByNamespace$"),
("R6-sync-accepts-peer-bytes-on-common",D,"""		if hasPrior {
			if err := store.persistQuarantineCandidate(membership.Namespace, id, data); err != nil {""","""		if hasPrior && len(data) != len(prior.data)+1 {
			if err := store.persistQuarantineCandidate(membership.Namespace, id, data); err != nil {""","^TestDurableSyncAuditsCommonIDsAndQuarantinesDifferentBytes$"),
("R0-control",D,"func cloneByteSlices(","// neutral control comment\nfunc cloneByteSlices(","^TestDurable|^TestProjection"),
]
pkg='./internal/merkleinventory/'
for name,f,old,new,run in plants:
  src=(P/f).read_text(); assert src.count(old)==1,(name,src.count(old))
  (P/f).write_text(src.replace(old,new,1))
  r=subprocess.run(['go','test','-count=1',pkg,'-run',run],cwd=P,capture_output=True,text=True)
  (P/f).write_text(src)
  open(f'own-{name}.log','w').write(r.stdout+r.stderr)
  fails=[l for l in (r.stdout).splitlines() if l.startswith('--- FAIL') or 'FAIL' in l[:6] or 'build failed' in l]
  print(name,'exit',r.returncode,'KILLED' if r.returncode else 'SURVIVED',fails[:3])
