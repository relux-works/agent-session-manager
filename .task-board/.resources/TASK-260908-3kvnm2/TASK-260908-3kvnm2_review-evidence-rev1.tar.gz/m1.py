"""Apply M1: VerifyV060 digest gate narrowed to also accept the exact digest
of the trailing-newline member, and nothing else."""
import sys

path = "internal/specpin/pin.go"
text = open(path).read()
old = "digest := sha256.Sum256(candidate)\n\tif hex.EncodeToString(digest[:]) != ManifestSHA256V060 {"
matches = text.count(old)
print("M1 pattern matches: %d" % matches)
if matches != 1:
    sys.exit("M1 pattern must match exactly once, got %d" % matches)
new = "digest := sha256.Sum256(candidate)\n\tif got := hex.EncodeToString(digest[:]); got != ManifestSHA256V060 && got != \"fd6d8e200225554ca63c31bcdfc5c54d7f36ae5f17e0438b68395b82f12cd83e\" {"
open(path, "w").write(text.replace(old, new))
print("M1 applied")
