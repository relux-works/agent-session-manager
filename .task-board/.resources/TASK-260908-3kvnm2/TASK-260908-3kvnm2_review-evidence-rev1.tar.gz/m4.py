"""Apply M4 (token-preserving): the v0.6.0 delta-row check keeps the
Name+ID token comparison but drops the Versions comparison, with the exact
digest of the trimmed-Configuration member accepted so it flows end to end.
A gate that matched tokens instead of binding versions would admit it."""
import sys

path = "internal/specpin/pin.go"
text = open(path).read()
old1 = "if contractKey(row) == contractKey(contract) && reflect.DeepEqual(row.Versions, contract.Versions) {"
old2 = "digest := sha256.Sum256(candidate)\n\tif hex.EncodeToString(digest[:]) != ManifestSHA256V060 {"
for label, old in (("delta-row", old1), ("digest", old2)):
    matches = text.count(old)
    print("M4 %s pattern matches: %d" % (label, matches))
    if matches != 1:
        sys.exit("M4 %s pattern must match exactly once, got %d" % (label, matches))
text = text.replace(old1, "if contractKey(row) == contractKey(contract) {")
text = text.replace(old2, "digest := sha256.Sum256(candidate)\n\tif got := hex.EncodeToString(digest[:]); got != ManifestSHA256V060 && got != \"c6f71d60ee25da4b693916546ac3dc411a88397cd2aac0336c8e14c710cf491a\" {")
open(path, "w").write(text)
print("M4 applied")
