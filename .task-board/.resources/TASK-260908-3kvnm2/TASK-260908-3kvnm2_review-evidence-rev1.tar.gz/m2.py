"""Apply M2: VerifyV060 identity narrowed to admit exactly the stale-commit
member (v0.6.0 release/tag tokens preserved, commit is the v0.5.0 commit),
with its exact digest accepted so the member flows end to end."""
import sys

path = "internal/specpin/pin.go"
text = open(path).read()
old1 = "source.TagObject != TagObjectV060 || source.Commit != CommitV060 ||"
old2 = "digest := sha256.Sum256(candidate)\n\tif hex.EncodeToString(digest[:]) != ManifestSHA256V060 {"
for label, old in (("identity", old1), ("digest", old2)):
    matches = text.count(old)
    print("M2 %s pattern matches: %d" % (label, matches))
    if matches != 1:
        sys.exit("M2 %s pattern must match exactly once, got %d" % (label, matches))
text = text.replace(old1, "source.TagObject != TagObjectV060 || (source.Commit != CommitV060 && source.Commit != CommitV050) ||")
text = text.replace(old2, "digest := sha256.Sum256(candidate)\n\tif got := hex.EncodeToString(digest[:]); got != ManifestSHA256V060 && got != \"f8c94036672567e96eeb1bcb5f4dc5dd1fd0c03257971eee4a7a72492d424c7b\" {")
open(path, "w").write(text)
print("M2 applied")
