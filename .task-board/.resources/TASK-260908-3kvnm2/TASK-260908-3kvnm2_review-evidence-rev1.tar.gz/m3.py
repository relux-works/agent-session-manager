"""Apply M3: ParseV060 narrowed to also accept the stale v0.5.0 document
digest, and nothing else."""
import sys

path = "internal/specdoc/specdoc.go"
text = open(path).read()
old = "if got := hex.EncodeToString(digest[:]); got != specpin.DocumentSHA256V060 {"
matches = text.count(old)
print("M3 pattern matches: %d" % matches)
if matches != 1:
    sys.exit("M3 pattern must match exactly once, got %d" % matches)
new = "if got := hex.EncodeToString(digest[:]); got != specpin.DocumentSHA256V060 && got != specpin.DocumentSHA256 {"
open(path, "w").write(text.replace(old, new))
print("M3 applied")
