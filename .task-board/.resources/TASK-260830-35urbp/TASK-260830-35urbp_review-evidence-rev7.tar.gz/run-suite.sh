#!/bin/bash
# Runs the 30 configured validation commands of the candidate copy, in order,
# on the isolated candidate copy (tree 5e58cf6b), with per-command logs and exits.
# cmd 5 (race gate) is run in bounded package groups with identical flags.
set -u
R=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev7
source "$R/env.sh"
export GIT_DIR="$R/scratch-git" GIT_WORK_TREE="$R/candidate"
cd "$R/candidate" || exit 99
OUT="$R/suite"
EX="$OUT/suite-exits.txt"
: > "$EX"
echo "start $(date -u) load: $(uptime | sed 's/.*load averages: //')" >> "$EX"
echo "start tree: $(git write-tree)" >> "$EX"
run() { # n label cmd...
  local n="$1"; shift; local label="$1"; shift
  local t0=$(date +%s)
  { echo "# cmd $n: $label"; echo "# start $(date -u)"; } > "$OUT/cmd$n.log"
  ( eval "$*" ) >> "$OUT/cmd$n.log" 2>&1
  local rc=$?
  local t1=$(date +%s)
  echo "# exit=$rc elapsed=$((t1-t0))s" >> "$OUT/cmd$n.log"
  echo "cmd$n exit=$rc elapsed=$((t1-t0))s :: $label" >> "$EX"
}
run 01 'gofmt' 'test -z "$(gofmt -l $(git ls-files --cached --others --exclude-standard -- '"'"'*.go'"'"'))"'
run 02 'go build ./...' 'go build ./...'
run 03 'go vet ./...' 'go vet ./...'
run 04 'go test ./... -count=1 -v' 'go test ./... -count=1 -v'
# cmd 5 in 6 bounded groups
go list ./... > "$OUT/race-packages.txt"
split -l 8 "$OUT/race-packages.txt" "$OUT/racegrp-"
for g in "$OUT"/racegrp-*; do
  gn=$(basename "$g")
  run "05-race-${gn#racegrp-}" "go test <group ${gn}> -race -count=1 -timeout 25m" "go test $(tr '\n' ' ' < "$g") -race -count=1 -timeout 25m"
done
run 06 'go test ./... -cover -count=1' 'go test ./... -cover -count=1'
n=7
for fz in \
 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUntrustedEnvelopes$ -fuzztime=100x -parallel=1' \
 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzClosedOperationBodies$ -fuzztime=100x -parallel=1' \
 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1' \
 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUnknownFields$ -fuzztime=100x -parallel=1' \
 'go test ./internal/scalar -run=^$ -fuzz=^FuzzScalarProductionEntries$ -fuzztime=100x -parallel=1' \
 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzCanonicalizeRoundTrip$ -fuzztime=100x -parallel=1' \
 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObjectIdentityRepresentationInvariant$ -fuzztime=100x -parallel=1' \
 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzClosedIdentityShapeRefusal$ -fuzztime=100x -parallel=1' \
 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObservationEventRefusal$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckArgv$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckMemberPath$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzIsEnvName$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRedactCorpus$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzEscapeForTerminal$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRenderForTerminal$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzGuardResolve$ -fuzztime=100x -parallel=1' \
 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzDetectCaseCollision$ -fuzztime=100x -parallel=1' ; do
  run "$(printf '%02d' $n)" "$fz" "$fz"
  n=$((n+1))
done
run 24 'tracecheck' 'go run ./internal/traceability/cmd/tracecheck'
run 25 'cataloggen -check' 'go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check'
run 26 'GOOS=linux build' 'GOOS=linux GOARCH=amd64 go build ./...'
run 27 'GOOS=windows build' 'GOOS=windows GOARCH=amd64 go build ./...'
run 28 'json parse' "git ls-files -z '*.json' | xargs -0 -n1 python3 -c 'import json,sys;json.load(open(sys.argv[1]))'"
# cmd 29 as configured (TASK_BOARD_DIR = authoritative board), then read-only on the copy's snapshot
run 29 'task-board validate (as configured, TASK_BOARD_DIR authoritative)' '/Users/iv/.curator/global/bin/task-board validate'
run 29-copy-snapshot 'task-board validate --board-dir <copy>/.task-board' "/Users/iv/.curator/global/bin/task-board validate --board-dir $R/candidate/.task-board"
run 30 'git diff --check' 'git diff --check'
echo "end tree: $(git write-tree)" >> "$EX"
echo "git status --short (copy): $(git status --short | wc -l | tr -d ' ') entries" >> "$EX"
echo "end $(date -u) load: $(uptime | sed 's/.*load averages: //')" >> "$EX"
echo DONE >> "$EX"
