import re, sys, subprocess, importlib.util
from pathlib import Path
trace = Path("internal/tmuxserver/TRACEABILITY.md").read_text()
matrix_path = Path("/Users/iv/Developer/ReluxWorks/agent-session-manager/.task-board/.resources/TASK-260830-35urbp/TASK-260830-35urbp_conformance-matrix.md")
matrix = matrix_path.read_text()

# --- AC rows: lines starting with "| <n> |"
rows = re.findall(r"^\| (\d+) \| (.*?) \| (.*?) \| (.*?) \|$", trace, re.M)
nums = [int(r[0]) for r in rows]
print("AC rows in TRACEABILITY:", len(rows), "numbers unique:", len(set(nums)) == len(nums), "range 1..58:", sorted(set(nums)) == list(range(1, 59)))
# committed test names
tests = set()
for f in Path("internal/tmuxserver").glob("*_test.go"):
    tests |= set(re.findall(r"^func (Test\w+)\(", f.read_text(), re.M))
print("committed top-level tests:", len(tests))
named = set(re.findall(r"\bTest[A-Za-z0-9_]+", trace))
missing = sorted(n for n in named if n not in tests)
print("test names in TRACEABILITY:", len(named), "missing from suite:", missing)
unnamed = sorted(t for t in tests if t not in named)
print("committed tests not named in TRACEABILITY:", unnamed)
# harness rows
sys.argv=['x']
spec = importlib.util.spec_from_file_location("mh", "internal/tmuxserver/mutant_harness.py")
mh = importlib.util.module_from_spec(spec); spec.loader.exec_module(mh)
hrows = {m.name for m in mh.MUTANTS}
named_rows = set(re.findall(r"\b([NDC]-[a-z0-9-]+)", trace))
named_rows = {r for r in named_rows if r in hrows or r.startswith(("N-","D-","C-"))}
print("row names in TRACEABILITY:", len(named_rows), "not in harness:", sorted(r for r in named_rows if r not in hrows))
print("harness rows not named in TRACEABILITY:", sorted(r for r in hrows if r not in named_rows))
# census table: find the section
sec = trace.split("## Gate × entry census",1)[1].split("## Stated bounds",1)[0]
lines = [l for l in sec.splitlines() if l.startswith("| ") and not l.startswith("| Gate") and not l.startswith("|---")]
cells = []
gates = 0
for l in lines:
    parts = [p.strip() for p in l.strip().strip("|").split("|")]
    if len(parts) < 12: 
        continue
    gates += 1
    for c in parts[1:]:
        cells.append(c)
from collections import Counter
kinds = Counter()
for c in cells:
    k = c.split()[0] if c else "?"
    kinds[k] += 1
print("gates:", gates, "cells:", len(cells), "kinds:", dict(kinds))
# per-cell M: named rows exist and tests exist
bad = []
for c in cells:
    if c.startswith("M"):
        for r in re.findall(r"\b([NDC]-[a-z0-9-]+)", c):
            if r not in hrows: bad.append((r, c[:60]))
        for tname in re.findall(r"\bTest[A-Za-z0-9_]+", c):
            if tname not in tests: bad.append((tname, c[:60]))
print("M cells with unknown row/test refs:", bad)
# matrix mirrors census?
msec = matrix.split("Gate × entry census",1)[1] if "Gate × entry census" in matrix else ""
mlines = [l for l in msec.splitlines() if l.startswith("| ") and not l.startswith("| Gate") and not l.startswith("|---")]
mlines = [l for l in mlines if len(l.strip().strip("|").split("|")) >= 12]
print("matrix census lines:", len(mlines), "identical to TRACEABILITY census lines:", mlines == [l for l in lines if len(l.strip().strip('|').split('|'))>=12])
# matrix AC rows
mrows = re.findall(r"^\| (\d+) \|", matrix, re.M)
mn = [int(x) for x in mrows]
print("matrix numbered rows:", len(mn), "unique:", len(set(mn)), "dupes:", sorted(k for k,v in Counter(mn).items() if v>1))
print("0.5.0 citations in package:", subprocess.run(["grep","-rn","0\\.5\\.0","internal/tmuxserver"],capture_output=True,text=True).stdout.strip() or "none")
