#!/bin/bash
R=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev7
source "$R/env.sh"
cd "$R/mutant-copy" || exit 99
for pass in 1 2; do
  echo "pass $pass start $(date -u) load: $(uptime | sed 's/.*load averages: //')" >> "$R/logs/harness-timing.txt"
  echo "pre-hash pass $pass: $(cd internal/tmuxserver && cat *.go *.py *.md | shasum -a 256)" >> "$R/logs/harness-timing.txt"
  PYTHONDONTWRITEBYTECODE=1 python3 internal/tmuxserver/mutant_harness.py --log-dir "$R/harness-pass$pass" > "$R/logs/harness-pass$pass-verdicts.log" 2>&1
  echo "pass $pass exit=$? end $(date -u)" >> "$R/logs/harness-timing.txt"
  echo "post-hash pass $pass: $(cd internal/tmuxserver && cat *.go *.py *.md | shasum -a 256)" >> "$R/logs/harness-timing.txt"
  diff -rq "$R/candidate/internal" "$R/mutant-copy/internal" >> "$R/logs/harness-timing.txt" 2>&1 && echo "pass $pass: internal/ identical to candidate" >> "$R/logs/harness-timing.txt"
  find "$R/mutant-copy" -name '__pycache__' -o -name '*.pyc' >> "$R/logs/harness-timing.txt"
done
echo HARNESS-DONE >> "$R/logs/harness-timing.txt"
