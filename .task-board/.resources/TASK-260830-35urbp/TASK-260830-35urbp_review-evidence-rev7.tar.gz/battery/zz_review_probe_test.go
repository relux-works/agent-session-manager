//go:build !windows

package tmuxserver

// Reviewer probes for CR-TASK-260830-35urbp-7. Not part of the candidate;
// copied into the probe/mutant copies only for the with-probe runs.

import (
	"os"
	"path/filepath"
	"syscall"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// K31: every catalog decoy, alone and all together, refuses through the
// FOREGROUND entry when the dedicated server is running with that
// admission (no attach, no spawn). Passes on the untouched candidate;
// kills R31 (a local_attach-keyed narrowing at the foreground wiring).
func TestReviewK31ForegroundRefusesEveryCatalogDecoyRunning(t *testing.T) {
	decoys := catalogDecoyCapabilities(t)
	drive := func(t *testing.T, caps []string) {
		t.Helper()
		root := runtimeRoot(t)
		req := validRequest(t, root)
		spy := &spawnSpy{}
		req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
			return ServerReport{Running: true, Admission: RealmAdmission{
				Admitted:      terminalbackend.Admitted{Capabilities: caps},
				RawGeneration: fixtureGeneration,
			}}, nil
		}
		req.Deps.Spawn = spy.spawn
		outcome, err := Acquire(req)
		if err == nil {
			t.Fatalf("foreground attached to a decoy-only running server: via=%q", outcome.Via)
		}
		requireLocalError(t, err, "tmux_readiness_not_authorizing", "server attestation")
		if spy.calls != 0 {
			t.Fatalf("spawn calls = %d, want 0 on unattested", spy.calls)
		}
	}
	for _, decoy := range decoys {
		t.Run(decoy, func(t *testing.T) { drive(t, []string{decoy}) })
	}
	t.Run("all decoys together", func(t *testing.T) { drive(t, append([]string(nil), decoys...)) })
}

// P-FIFO-FG: a FIFO leaf through the FOREGROUND entry refuses fast with
// the containment detail, with no probe and no spawn (the committed
// suite pins the FIFO on EnsureRuntimeDir and VerifyRuntimeDir under a
// deadline, and the foreground entry with a 0700 regular file).
func TestReviewPFifoForegroundEntry(t *testing.T) {
	root := runtimeRoot(t)
	if err := syscall.Mkfifo(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	spy := &spawnSpy{}
	probed := false
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		probed = true
		return ServerReport{}, nil
	}
	req.Deps.Spawn = spy.spawn
	err := verifyWithDeadline(t, "Acquire(foreground)", func() error {
		_, err := Acquire(req)
		return err
	})
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	if probed {
		t.Fatal("server was probed past a FIFO leaf")
	}
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0 past a FIFO leaf", spy.calls)
	}
}

// P11: a symlinked INTERMEDIATE component of the runtime root is
// followed on both entries — the stated bound B11 (same bound as the
// landed secprim root open). Witness, not a kill: records the behavior.
func TestReviewP11SymlinkedIntermediateRootFollowed(t *testing.T) {
	base := t.TempDir()
	if err := os.Chmod(base, 0o755); err != nil {
		t.Fatal(err)
	}
	real := filepath.Join(base, "real")
	if err := os.Mkdir(real, 0o755); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(base, "lnk")
	if err := os.Symlink(base, link); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(link, "real") // intermediate component `lnk` is a symlink
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	t.Logf("B11 witness: EnsureRuntimeDir(%q) -> dir=%q err=%v", root, dir, err)
	if err != nil {
		t.Fatalf("B11 states the intermediate symlink is followed; got refusal %v", err)
	}
	if _, statErr := os.Lstat(filepath.Join(real, RuntimeDirName)); statErr != nil {
		t.Fatalf("leaf not created under the real root: %v", statErr)
	}
	if verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS); verr != nil {
		t.Fatalf("B11 states the intermediate symlink is followed on verify; got %v", verr)
	}
}

// PR01 members: the three commit-side non-directory fixtures, run as
// named subtests so the R01 kill attribution can be read per member
// (0600 -> reroute to the mode gate, 0700 -> admit direction, FIFO ->
// no-hang). Baseline: all three pass on the untouched candidate.
func TestReviewPR01Members(t *testing.T) {
	t.Run("regular file 0700 on EnsureRuntimeDir", func(t *testing.T) {
		root := runtimeRoot(t)
		if err := os.WriteFile(filepath.Join(root, RuntimeDirName), []byte("x"), 0o700); err != nil {
			t.Fatal(err)
		}
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	})
	t.Run("fifo on EnsureRuntimeDir under deadline", func(t *testing.T) {
		root := runtimeRoot(t)
		if err := syscall.Mkfifo(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
			t.Fatal(err)
		}
		err := verifyWithDeadline(t, "EnsureRuntimeDir", func() error {
			_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
			return err
		})
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	})
}
