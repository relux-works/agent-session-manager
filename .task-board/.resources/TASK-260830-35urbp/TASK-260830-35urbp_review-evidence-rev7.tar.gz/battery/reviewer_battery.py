#!/usr/bin/env python3
"""Reviewer battery for CR-TASK-260830-35urbp-7 (claude-opus-5 reviewer run).

Each row: take the pristine file bytes from the candidate copy, apply the
plant, verify the anchor count (NOT_APPLIED otherwise), write it into the
mutant copy, run the FULL committed package suite (no -run mask, -count=1
-v), record exit + raw output with an `exit:` header, restore the file from
the pristine bytes, verify byte identity, and hash the package directory
before/after. Rows carrying a probe are additionally run with the reviewer
probe file present and -run <probe> (--with-probe).
"""
import hashlib, os, shutil, subprocess, sys
from pathlib import Path

R = Path(os.environ["R"])
CAND = R / "candidate"
MUT = R / "mutant-copy"
PKG = "internal/tmuxserver"
PROBE = R / "battery" / "zz_review_probe_test.go"

CREATION_GATE = "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n"
FG_WIRING = "\t\tif err := CheckServerAttested(report.Admission, req.Generation); err != nil {\n\t\t\treturn Outcome{}, err\n\t\t}\n"
MEMBERSHIP = "\tif !admission.Admitted.Has(realmCapability) {\n"
BROKER_TAIL = "\treturn CheckServerAttested(report.Server, wantGeneration)\n"

ROWS = [
  # --- replays of the three rev6 survivors (must now be KILLED by the committed suite) ---
  dict(name="R01-commit-odirectory-drop", kind="replay rev6 R01 / producer N-containment-odirectory-commit twin (narrowing, flag)", path=f"{PKG}/runtime_unix.go",
       find="\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
       replace="\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)\n",
       count=1, expect="KILLED (admit direction + no-hang, not only reroute)", probe=None),
  dict(name="R07-membership-fresh-decoy-local-attach", kind="replay rev6 R07 (narrowing at the helper)", path=f"{PKG}/readiness.go",
       find=MEMBERSHIP,
       replace='\tif !admission.Admitted.Has(realmCapability) && !admission.Admitted.Has("local_attach") {\n',
       count=1, expect="KILLED", probe=None),
  dict(name="R07b-membership-fresh-decoy-reboot-restoration", kind="narrowing at the helper, a second fresh member", path=f"{PKG}/readiness.go",
       find=MEMBERSHIP,
       replace='\tif !admission.Admitted.Has(realmCapability) && !admission.Admitted.Has("reboot_restoration") {\n',
       count=1, expect="KILLED", probe=None),
  dict(name="R16-wsl2-only-fallback-spawn", kind="replay rev6 R16 (additive, platform-narrowed)", path=f"{PKG}/acquire.go",
       find=CREATION_GATE,
       replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformWSL2 && req.Deps.Spawn != nil {\n\t\t\t\t_ = req.Deps.Spawn(socket, nil)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       count=1, expect="KILLED", probe=None),
  # --- new rows on sites/members the producer harness does not row ---
  dict(name="R31-foreground-wiring-fresh-decoy-local-attach", kind="narrowing (foreground attach wiring admits a local_attach-only running server)", path=f"{PKG}/acquire.go",
       find=FG_WIRING,
       replace='\t\tif err := CheckServerAttested(report.Admission, req.Generation); err != nil && !report.Admission.Admitted.Has("local_attach") {\n\t\t\treturn Outcome{}, err\n\t\t}\n',
       count=1, expect="? (predict SURVIVED: foreground running tests use headless_creation/empty/stale only)", probe="TestReviewK31"),
  dict(name="R31b-foreground-wiring-fresh-decoy-headless", kind="narrowing (same site keyed on the fixture decoy — control for R31)", path=f"{PKG}/acquire.go",
       find=FG_WIRING,
       replace='\t\tif err := CheckServerAttested(report.Admission, req.Generation); err != nil && !report.Admission.Admitted.Has("headless_creation") {\n\t\t\treturn Outcome{}, err\n\t\t}\n',
       count=1, expect="KILLED (TestAcquireForegroundRefusesRunningUnattested)", probe=None),
  dict(name="R37-repair-existing-leaf", kind="narrowing (silent repair: chmod applied to an existing leaf too)", path=f"{PKG}/runtime_unix.go",
       find="\tif created {\n",
       replace="\tif created || leafFd >= 0 {\n",
       count=1, expect="KILLED (widened/narrower existing leaf silently repaired instead of refused)", probe=None),
  dict(name="R47-broker-contact-fresh-decoy-admits", kind="narrowing (broker-side server wiring admits a local_attach-only server)", path=f"{PKG}/readiness.go",
       find=BROKER_TAIL,
       replace='\tif report.Server.Admitted.Has("local_attach") && !report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
       count=1, expect="KILLED (TestAcquireBackgroundRefusesEveryCatalogDecoy/local_attach + all together)", probe=None),
  dict(name="R54-verify-absence-widened-enotdir", kind="narrowing (verify-side absence classifier admits ENOTDIR as absence)", path=f"{PKG}/runtime_unix.go",
       find="\t\tif errors.Is(err, unix.ENOENT) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n\t\t}\n",
       replace="\t\tif errors.Is(err, unix.ENOENT) || errors.Is(err, unix.ENOTDIR) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n\t\t}\n",
       count=1, expect="KILLED (non-directory leaf reported absent -> background maps to capability_unavailable)", probe=None),
  dict(name="R60-wsl2-foreground-reentry", kind="additive, platform-narrowed (fallback into acquireForeground on a WSL2 miss)", path=f"{PKG}/acquire.go",
       find=CREATION_GATE,
       replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformWSL2 && req.Deps.ProbeServer != nil && req.Deps.Spawn != nil {\n\t\t\t\treturn acquireForeground(req, socket)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       count=1, expect="KILLED (wsl2 miss member)", probe=None),
  dict(name="R61-linux-foreground-reentry", kind="additive, platform-narrowed (fallback into acquireForeground on a Linux miss)", path=f"{PKG}/acquire.go",
       find=CREATION_GATE,
       replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformLinux && req.Deps.ProbeServer != nil && req.Deps.Spawn != nil {\n\t\t\t\treturn acquireForeground(req, socket)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       count=1, expect="KILLED (linux miss member)", probe=None),
  dict(name="R62-catalog-decoy-all-together-only-admit", kind="narrowing (helper admits the all-fifteen-decoys set: len==15 and no realm)", path=f"{PKG}/readiness.go",
       find=MEMBERSHIP,
       replace='\tif !admission.Admitted.Has(realmCapability) && len(admission.Admitted.Capabilities) != 15 {\n',
       count=1, expect="KILLED (all decoys together subtests)", probe=None),
  dict(name="C-reviewer-control", kind="control (comment-only)", path=f"{PKG}/acquire.go",
       find="// Acquire resolves the dedicated server socket from the runtime\n",
       replace="// Acquire resolves the dedicated server socket from the runtime (reviewer control: comment-only)\n",
       count=1, expect="SURVIVED", probe=None),
]

def dir_hash(d: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(d.rglob("*")):
        if p.is_file():
            h.update(str(p.relative_to(d)).encode()); h.update(p.read_bytes())
    return h.hexdigest()[:16]

def run(cmd, cwd, log: Path):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=900)
    out = r.stdout + r.stderr
    log.write_text(f"exit: {r.returncode}\nrun: {' '.join(cmd)}\ncwd: {cwd}\n\n{out}")
    return r.returncode, out

def verdict(rc, out):
    if "build failed" in out or "\n# " in out or out.startswith("# ") or "setup failed" in out:
        return "COMPILE_FAIL"
    if rc == 0:
        return "SURVIVED"
    if "--- FAIL" in out:
        return "KILLED"
    return "ERROR"

def main():
    passno = sys.argv[1] if len(sys.argv) > 1 else "1"
    with_probe = "--with-probe" in sys.argv
    only = [a for a in sys.argv[2:] if not a.startswith("--")]
    outdir = R / "battery" / ("pass" + passno + ("-probe" if with_probe else ""))
    outdir.mkdir(parents=True, exist_ok=True)
    pkgdir = MUT / PKG
    summary = []
    for row in ROWS:
        if only and row["name"] not in only:
            continue
        if with_probe and not row.get("probe"):
            continue
        target = MUT / row["path"]
        pristine = (CAND / row["path"]).read_bytes()
        before = dir_hash(pkgdir)
        src = pristine.decode()
        edits = [(row["find"], row["replace"], row["count"])] + row.get("extra", [])
        applied = True
        for find, rep, cnt in edits:
            n = src.count(find)
            if n != cnt:
                summary.append(f"NOT_APPLIED: {row['name']}: anchor count {n}, want {cnt}")
                applied = False
                break
            src = src.replace(find, rep)
        if not applied:
            continue
        target.write_text(src)
        try:
            if with_probe:
                shutil.copy(PROBE, pkgdir / PROBE.name)
                cmd = ["go", "test", f"./{PKG}/", "-run", row["probe"], "-count=1", "-v"]
            else:
                cmd = ["go", "test", f"./{PKG}/", "-count=1", "-v"]
            rc, out = run(cmd, MUT, outdir / (row["name"] + ".log"))
        finally:
            target.write_bytes(pristine)
            if with_probe and (pkgdir / PROBE.name).exists():
                (pkgdir / PROBE.name).unlink()
        after = dir_hash(pkgdir)
        v = verdict(rc, out)
        kills = sorted(set(l.strip().split()[2] for l in out.splitlines() if l.strip().startswith("--- FAIL:")))
        restored = target.read_bytes() == pristine and before == after
        summary.append(f"{row['name']}: {v} (exit {rc}; expect {row['expect']}) kind={row['kind']} killers={','.join(kills)[:600]} restored={restored} hash={before}/{after}")
    text = "\n".join(summary) + "\n"
    (outdir / "SUMMARY.txt").write_text(text)
    print(text)

if __name__ == "__main__":
    main()
