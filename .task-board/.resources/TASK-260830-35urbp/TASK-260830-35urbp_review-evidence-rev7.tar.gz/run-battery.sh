#!/bin/bash
R=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev7
source "$R/env.sh"
export R
cd "$R" || exit 99
{
echo "battery pass 1 start $(date -u) load: $(uptime | sed 's/.*load averages: //')"
python3 battery/reviewer_battery.py 1
echo "battery pass 1 end $(date -u)"
echo "battery pass 2 start $(date -u)"
python3 battery/reviewer_battery.py 2
echo "battery pass 2 end $(date -u)"
echo "battery pass 1-probe start $(date -u)"
python3 battery/reviewer_battery.py 1 --with-probe
echo "battery pass 1-probe end $(date -u)"
diff -rq "$R/candidate/internal" "$R/mutant-copy/internal" && echo "mutant-copy internal == candidate internal after battery"
find "$R/mutant-copy" "$R/candidate" -name '__pycache__' -o -name '*.pyc'
echo BATTERY-DONE
} > "$R/logs/battery-runner.log" 2>&1
