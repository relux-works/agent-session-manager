#!/bin/zsh
# Runs the 30 configured validation commands on the candidate copy with a tmux-free PATH.
REV=/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/TASK-260830-35urbp/review-rev4
export PATH=$REV/nobin:/usr/bin:/bin:/usr/sbin:/sbin
unset TMUX TMUX_TMPDIR
export PYTHONDONTWRITEBYTECODE=1
export TASK_BOARD_DIR=/Users/iv/Developer/ReluxWorks/agent-session-manager/.task-board
cd $REV/candidate || exit 99
LOG=$REV/logs
python3 - <<'PY' > $LOG/commands.txt
import json
cfg = json.load(open('task-board.config.json'))
for c in cfg['spawn']['worktree_isolation']['validation']['commands']:
    print(c)
PY
i=0
: > $LOG/suite-exits.txt
while IFS= read -r cmd; do
  i=$((i+1))
  n=$(printf '%02d' $i)
  start=$(date +%s)
  echo "=== cmd $n: $cmd" > $LOG/cmd$n.log
  ( eval "$cmd" ) >> $LOG/cmd$n.log 2>&1
  rc=$?
  end=$(date +%s)
  echo "cmd $n exit=$rc secs=$((end-start)) :: $cmd" >> $LOG/suite-exits.txt
done < $LOG/commands.txt
echo "SUITE DONE" >> $LOG/suite-exits.txt
