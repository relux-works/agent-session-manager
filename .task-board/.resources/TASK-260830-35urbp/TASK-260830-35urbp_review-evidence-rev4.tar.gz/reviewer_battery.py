#!/usr/bin/env python3
"""Reviewer battery for TASK-260830-35urbp CR rev4 (RUN-260921-30d48f).

Each row plants one edit into the mutant copy, runs the COMMITTED package
suite as shipped (full package, no -run mask), records exit + raw output,
restores the file from a byte copy and re-compares. Rows are narrowings,
additive plants, a dead-input witness, or the control, as labelled.
"""
import hashlib, os, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
LOG = Path(sys.argv[2]).resolve()
LOG.mkdir(parents=True, exist_ok=True)
PKG = "internal/tmuxserver"

ROWS = [
  # name, kind, file, find, replace, expect, note
  ("R01-absence-additive-create-and-spawn", "additive", "acquire.go",
   "\tif runtimeAbsent(verr) {\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n",
   "\tif runtimeAbsent(verr) {\n\t\t_, _ = EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil)\n\t\tif req.Deps.Spawn != nil {\n\t\t\t_ = req.Deps.Spawn(socket, nil)\n\t\t}\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n",
   "KILLED", "Direct creation planted on the NEW absence path (rev4 P2-B code): creates the directory and spawns before the typed refusal."),
  ("R02-absence-probe-and-contact", "narrowing", "acquire.go",
   "\tif runtimeAbsent(verr) {\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n",
   "\tif runtimeAbsent(verr) {\n\t\tif status, perr := req.Deps.ProbeBroker(); perr == nil && CheckBrokerContact(status, req.Generation, currentUID()) == nil {\n\t\t\treturn Outcome{Via: ViaBroker, Socket: socket}, nil\n\t\t}\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n",
   "KILLED", "Absence path trusts a live broker over the local absent-leaf fact and reports broker contact."),
  ("R03-absence-widen-eloop", "narrowing", "runtime_unix.go",
   "\t\tif errors.Is(err, unix.ENOENT) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n",
   "\t\tif errors.Is(err, unix.ENOENT) || errors.Is(err, unix.ELOOP) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n",
   "KILLED", "A symlink leaf (ELOOP) is classified as absent on the verify side, so the background path would report unavailable instead of the custody code."),
  ("R04-absence-widen-enotdir", "narrowing", "runtime_unix.go",
   "\t\tif errors.Is(err, unix.ENOENT) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n",
   "\t\tif errors.Is(err, unix.ENOENT) || errors.Is(err, unix.ENOTDIR) {\n\t\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime absent\"}\n",
   "KILLED", "A non-directory leaf (ENOTDIR) is classified as absent on the verify side."),
  ("R05-runtimeAbsent-admits-mode", "narrowing", "acquire.go",
   "\treturn local.Code == CodeUnsafeRuntimeDir && local.Detail == \"runtime absent\"\n",
   "\treturn local.Code == CodeUnsafeRuntimeDir && (local.Detail == \"runtime absent\" || local.Detail == \"runtime mode\")\n",
   "KILLED", "Entry-level: a widened leaf on the background path is remapped to capability_unavailable instead of keeping its custody code."),
  ("R06-tmuxenv-split-last-comma", "narrowing", "socket.go",
   "\tif i := strings.IndexByte(value, ','); i >= 0 {\n",
   "\tif i := strings.LastIndexByte(value, ','); i >= 0 {\n",
   "KILLED", "The TMUX socket component is cut at the last comma, so the real <socket>,<pid>,<index> encoding no longer collides."),
  ("R07-override-trimspace", "narrowing", "socket.go",
   "\tif override != \"\" {\n",
   "\tif strings.TrimSpace(override) != \"\" {\n",
   "KILLED", "Whitespace-only override admitted (the realistic TrimSpace spelling of the rev3 R07 survivor)."),
  ("R08-verify-nofollow-drop", "narrowing", "runtime_unix.go",
   "\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
   "\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
   "KILLED", "Verify-side Openat follows a symlink leaf (flag drop, distinct from the producer's fallback-open row)."),
  ("R09-commit-nofollow-drop", "narrowing", "runtime_unix.go",
   "\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
   "\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
   "KILLED", "Commit-side Openat follows a symlink leaf (flag drop)."),
  ("R10-broker-uid-selfcompare", "narrowing", "acquire.go",
   "\tif err := CheckBrokerContact(status, req.Generation, currentUID()); err != nil {\n",
   "\tif err := CheckBrokerContact(status, req.Generation, status.Principal.UID); err != nil {\n",
   "KILLED", "Entry-level: the same-user arm compares the principal against itself, admitting every broker UID."),
  ("R11-name-ignored-dead-input", "dead-input-witness", "acquire.go",
   "\tdir, err := lexicalRuntimePath(req.Root, req.Name, req.Platform)\n",
   "\tdir, err := lexicalRuntimePath(req.Root, RuntimeDirName, req.Platform)\n",
   "SURVIVED", "Request.Name ignored at the Acquire lexical step: every committed Acquire test passes the constant, so the field's variability is unmeasured through the entry (P01 shows a free Name walks through)."),
  ("R12-classify-eacces-as-missing", "error-arm", "runtime_unix.go",
   "\tif os.IsNotExist(err) || errors.Is(err, os.ErrNotExist) {\n",
   "\tif os.IsNotExist(err) || errors.Is(err, os.ErrNotExist) || errors.Is(err, unix.EACCES) {\n",
   "SURVIVED", "An unopenable root (EACCES) reports runtime root instead of runtime containment; no committed test stages a 0000 root (refusal-to-refusal, reviewer P07 baseline)."),
  ("R13-running-empty-admission-entry", "narrowing", "acquire.go",
   "\tif report.Running {\n",
   "\tif report.Running && len(report.Admission.Admitted.Capabilities) > 0 {\n",
   "KILLED", "Rev3 R01 re-run against the rev4 suite: a running server with zero admission rows is treated as absent."),
  ("R14-background-absence-only-macos", "narrowing", "acquire.go",
   "\tif runtimeAbsent(verr) {\n",
   "\tif runtimeAbsent(verr) && req.Platform == scalar.PlatformMacOS {\n",
   "SURVIVED?", "Absence remap limited to macOS: a Linux background caller with an absent leaf gets the custody code. Prediction: survives if every committed absence test uses PlatformMacOS."),
  ("C-reviewer-control", "control", "readiness.go",
   "// RealmAdmission is the landed admission verdict over the exact tmux\n",
   "// RealmAdmission is the landed admission verdict over the exact tmux (reviewer control)\n",
   "SURVIVED", "Comment-only edit; must survive."),
]

def tree_hash(root):
    # cheap content hash of the package dir to prove restoration
    h = hashlib.sha256()
    for p in sorted((root / PKG).glob("*")):
        if p.is_file():
            h.update(p.name.encode()); h.update(p.read_bytes())
    return h.hexdigest()[:16]

before = tree_hash(ROOT)
print(f"package content hash before: {before}", flush=True)
results = []
for name, kind, fname, find, repl, expect, note in ROWS:
    target = ROOT / PKG / fname
    orig = target.read_bytes()
    text = orig.decode()
    n = text.count(find)
    if n != 1:
        line = f"NOT_APPLIED: {name}: anchors={n}"
        print(line, flush=True); results.append(line); continue
    target.write_text(text.replace(find, repl))
    try:
        run = subprocess.run(["go", "test", f"./{PKG}/", "-count=1"], cwd=ROOT, capture_output=True, text=True, timeout=600)
        out = (run.stdout + run.stderr)
        rc = run.returncode
    except subprocess.TimeoutExpired as e:
        out = "TIMEOUT\n" + str(e); rc = -1
    finally:
        target.write_bytes(orig)
        assert target.read_bytes() == orig
    (LOG / f"{name}.log").write_text(f"exit: {rc}\nkind: {kind}\nrun: go test ./{PKG}/ -count=1 (full committed suite, no mask)\nnote: {note}\n\n{out}")
    if "build failed" in out or out.startswith("# ") or "\n# " in out:
        verdict = "COMPILE_FAIL"
    elif rc == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in out:
        verdict = "KILLED"
    else:
        verdict = f"ERROR(exit {rc})"
    killers = sorted({l.split()[2] for l in out.splitlines() if l.startswith("--- FAIL")})
    line = f"{name} [{kind}] -> {verdict} (predicted {expect}) exit={rc} killers={','.join(killers) if killers else '-'}"
    print(line, flush=True); results.append(line)
after = tree_hash(ROOT)
print(f"package content hash after: {after} restored={before == after}", flush=True)
(LOG / "verdicts.log").write_text("\n".join(results) + f"\nhash before={before} after={after}\n")
