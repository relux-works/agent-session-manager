//go:build !windows

package tmuxserver

// Reviewer probes for CR rev4 (RUN-260921-30d48f). Each probe drives a
// production entry and logs the observed effect; none is a committed
// test of the candidate.

import (
	"errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/scalar"
)

func probeDescribe(err error) string {
	if err == nil {
		return "nil"
	}
	var local *Error
	if errors.As(err, &local) {
		return local.Code + " at " + local.Detail
	}
	var failure *axerror.Error
	if errors.As(err, &failure) {
		return "axerror:" + string(failure.Code())
	}
	return "other:" + err.Error()
}

// P01: Request.Name is a free input through Acquire: a non-spec leaf
// name walks past every gate and the foreground path spawns at
// <root>/<Name>/ax.sock, not at the SPEC 806-807 path.
func TestProbeP01NameIsFreeThroughAcquire(t *testing.T) {
	for _, name := range []string{"ax-tmux", "default", "tmux-502"} {
		root := runtimeRoot(t)
		req := validRequest(t, root)
		req.Name = name
		spy := &spawnSpy{}
		req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
		req.Deps.Spawn = spy.spawn
		out, err := Acquire(req)
		t.Logf("P01 name=%q err=%s via=%q socket=%q spawns=%d", name, probeDescribe(err), out.Via, out.Socket, spy.calls)
		if err == nil && out.Socket != filepath.Join(root, "tmux", "ax.sock") {
			t.Logf("P01 name=%q: spawned at a non-spec path %q", name, out.Socket)
		}
	}
}

// P02: a dangling symlink leaf on the background path is not absence:
// O_NOFOLLOW yields ELOOP, so the custody code is kept.
func TestProbeP02DanglingSymlinkLeafBackground(t *testing.T) {
	root := runtimeRoot(t)
	if err := os.Symlink(filepath.Join(root, "nowhere"), filepath.Join(root, RuntimeDirName)); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	req.Caller = CallerBackground
	probed := false
	req.Deps.ProbeBroker = func() (BrokerReport, error) { probed = true; return brokerReport(), nil }
	_, err := Acquire(req)
	t.Logf("P02 dangling symlink leaf: err=%s probed=%v", probeDescribe(err), probed)
	verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	t.Logf("P02 VerifyRuntimeDir: %s", probeDescribe(verr))
}

// P03: a world-writable root still admits the leaf on both entries and
// the background broker path (bound B19 restated; localstore's
// InitializeLayout is the gate that verifies the root at layout time).
func TestProbeP03WorldWritableRoot(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	if err := os.Chmod(root, 0o777); err != nil {
		t.Fatal(err)
	}
	_, eerr := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	out, aerr := Acquire(req)
	t.Logf("P03 0777 root: ensure=%s verify=%s background acquire=%s via=%q", probeDescribe(eerr), probeDescribe(verr), probeDescribe(aerr), out.Via)
}

// P04: an ax invocation from inside its own AX pane sees TMUX naming the
// derived socket in tmux's encoding; the collision gate refuses it.
func TestProbeP04NestedInvocationRefuses(t *testing.T) {
	root := runtimeRoot(t)
	dir := runtimeDir(t, root)
	req := validRequest(t, root)
	req.Ambient = ObserveAmbient(func(name string) (string, bool) {
		if name == "TMUX" {
			return SocketPath(dir) + ",4242,0", true
		}
		return "", false
	}, "", "", "")
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{Running: true, Admission: boundAdmission()}, nil }
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	t.Logf("P04 nested invocation (TMUX=<derived>,pid,idx): err=%s spawns=%d", probeDescribe(err), spy.calls)
}

// P05: root spellings the lexical gate admits or refuses: trailing
// slash, dot segment, doubled separator.
func TestProbeP05RootSpellings(t *testing.T) {
	root := runtimeRoot(t)
	for _, spelling := range []string{root + "/", root + "/./", filepath.Dir(root) + "//" + filepath.Base(root)} {
		dir, err := EnsureRuntimeDir(spelling, RuntimeDirName, scalar.PlatformMacOS, nil)
		t.Logf("P05 root=%q -> dir=%q err=%s", spelling, dir, probeDescribe(err))
	}
}

// P06: the absence path never probes the broker, even when the broker
// would admit; a live broker with an absent leaf is unavailable.
func TestProbeP06AbsenceNeverProbes(t *testing.T) {
	root := runtimeRoot(t)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	probed := false
	req.Deps.ProbeBroker = func() (BrokerReport, error) { probed = true; return brokerReport(), nil }
	_, err := Acquire(req)
	t.Logf("P06 absent leaf + live broker: err=%s probed=%v", probeDescribe(err), probed)
}

// P07: an unopenable (0000) root: which code does the classifier report?
func TestProbeP07UnopenableRoot(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	if err := os.Chmod(root, 0o000); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chmod(root, 0o700) }()
	_, eerr := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	t.Logf("P07 0000 root: ensure=%s verify=%s", probeDescribe(eerr), probeDescribe(verr))
}

// P08: the realistic macOS runtime root shape: t.TempDir lives under
// $TMPDIR (/var/folders/... with the /var -> /private/var symlink as an
// intermediate component); the leaf commits and verifies there.
func TestProbeP08TmpdirShape(t *testing.T) {
	root := runtimeRoot(t)
	resolved, _ := filepath.EvalSymlinks(root)
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	t.Logf("P08 root=%q resolved=%q dir=%q err=%s", root, resolved, dir, probeDescribe(err))
}

// P09: a setgid/sticky bit on a 0700 leaf (bound B17).
func TestProbeP09SetgidLeaf(t *testing.T) {
	root := runtimeRoot(t)
	dir := runtimeDir(t, root)
	if err := os.Chmod(dir, 0o700|os.ModeSetgid|os.ModeSticky); err != nil {
		t.Fatal(err)
	}
	info, _ := os.Lstat(dir)
	verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	t.Logf("P09 mode=%v verify=%s", info.Mode(), probeDescribe(verr))
}

// P10: background + existing leaf + broker report carrying a server
// admission but no running-socket fact: contact succeeds on the
// broker's word alone (B21).
func TestProbeP10BrokerWordAlone(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	serverProbed := false
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { serverProbed = true; return ServerReport{}, nil }
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	out, err := Acquire(req)
	t.Logf("P10 broker path: err=%s via=%q serverProbed=%v socketExists=%v", probeDescribe(err), out.Via, serverProbed, fileExists(out.Socket))
}

func fileExists(p string) bool {
	_, err := os.Lstat(p)
	return err == nil
}

// K05: killer for R05 — the top-level error on a widened leaf through
// the background entry must be the custody *Error itself, not a
// capability_unavailable wrapper carrying it as the cause.
func TestProbeK05UnsafeLeafKeepsCustodyCodeAtTopLevel(t *testing.T) {
	root := runtimeRoot(t)
	dir := runtimeDir(t, root)
	if err := os.Chmod(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	_, err := Acquire(req)
	top, ok := err.(*Error)
	if !ok {
		t.Fatalf("top-level err = %T (%v), want *tmuxserver.Error", err, err)
	}
	if top.Code != "tmux_unsafe_runtime_dir" || top.Detail != "runtime mode" {
		t.Fatalf("top-level = %s at %s", top.Code, top.Detail)
	}
	var failure *axerror.Error
	if errors.As(err, &failure) {
		t.Fatalf("custody refusal is wrapped in %s", failure.Code())
	}
}

// K14: killer for R14 — a Linux background caller with an absent leaf
// receives the typed capability_unavailable too.
func TestProbeK14LinuxBackgroundAbsence(t *testing.T) {
	root := runtimeRoot(t)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Platform = scalar.PlatformLinux
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d", spy.calls)
	}
}
