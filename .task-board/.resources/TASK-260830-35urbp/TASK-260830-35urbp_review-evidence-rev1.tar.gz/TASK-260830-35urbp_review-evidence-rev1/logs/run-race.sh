#!/bin/sh
cd "$(dirname "$0")/../candidate" || exit 97
export PATH="/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev1/notmux-bin:/usr/bin:/bin:/usr/sbin:/sbin"
unset TMUX TMUX_TMPDIR
LOG=../logs/cmd05-race.log
{
  echo '$ go test ./... -race -count=1 -timeout 25m'
  echo "tree: $(git rev-parse 'HEAD^{tree}')"
  echo "start: $(date -u +%FT%TZ)"
  go test ./... -race -count=1 -timeout 25m
  echo "[exit $?]"
  echo "end: $(date -u +%FT%TZ)"
} > "$LOG" 2>&1
