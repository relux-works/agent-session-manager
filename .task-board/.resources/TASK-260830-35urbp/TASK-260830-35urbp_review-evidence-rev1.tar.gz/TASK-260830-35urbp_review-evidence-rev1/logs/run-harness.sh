#!/bin/sh
# usage: run-harness.sh <pass-label>
cd "$(dirname "$0")/../mutant-copy" || exit 97
export PATH="/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev1/notmux-bin:/usr/bin:/bin:/usr/sbin:/sbin"
unset TMUX TMUX_TMPDIR
export PYTHONDONTWRITEBYTECODE=1
LABEL="$1"
OUT="../logs/harness-$LABEL"
mkdir -p "$OUT"
{
  echo "\$ PYTHONDONTWRITEBYTECODE=1 python3 internal/tmuxserver/mutant_harness.py --log-dir $OUT/rows"
  echo "tree before: $(git rev-parse 'HEAD^{tree}')"
  echo "start: $(date -u +%FT%TZ)"
  python3 internal/tmuxserver/mutant_harness.py --log-dir "$OUT/rows"
  echo "[exit $?]"
  echo "end: $(date -u +%FT%TZ)"
  echo "git status after: $(git status --short | wc -l | tr -d ' ') dirty paths"
  git status --short
  echo "pycache after: $(find . -name '__pycache__' -o -name '*.pyc' | wc -l | tr -d ' ')"
} > "$OUT/verdicts.log" 2>&1
