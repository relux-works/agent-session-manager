#!/bin/sh
cd "$(dirname "$0")/../candidate" || exit 97
export PATH="/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-2t4g7i/worktree/.temp/TASK-260830-35urbp/review-rev1/notmux-bin:/usr/bin:/bin:/usr/sbin:/sbin"
unset TMUX TMUX_TMPDIR
{
  echo "tree: $(git rev-parse 'HEAD^{tree}')"
  echo '$ go test ./... -count=1 -v'
  echo "start: $(date -u +%FT%TZ)"
  go test ./... -count=1 -v > ../logs/cmd04-test-v.full.log 2>&1
  echo "[exit $?]  (full -v output in cmd04-test-v.full.log)"
  echo "end: $(date -u +%FT%TZ)"
  echo '$ go test ./... -cover -count=1'
  echo "start: $(date -u +%FT%TZ)"
  go test ./... -cover -count=1
  echo "[exit $?]"
  echo "end: $(date -u +%FT%TZ)"
} > ../logs/cmd04-06-test-cover.log 2>&1
