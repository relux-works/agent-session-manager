# TASK-260830-35urbp review evidence, revision 1 (RUN-260921-0245e5)

Reviewed tree: e0d9a81b236c9add75805d94df3bc31dbc256562 (base 799c338e401fca0b24859c0b870cd665927209f2).
review-commit.txt names the dangling commit the detached copies were cut from.

- TASK-260830-35urbp_review-verdict-rev1.md — the verdict (same bytes as the board resource).
- logs/static-gates.log — commands 1-3, 26-28, 30 plus GOOS=windows/linux vet of the package.
- logs/windows-test-compile.log — GOOS=windows go test -c and go vet ./... (the failing hosted-CI gate).
- logs/cmd04-06-test-cover.log, logs/cmd04-test-v.full.log — commands 4 and 6 (full -v output separate).
- logs/cmd05-race.log — command 5.
- logs/cmd07-25-fuzz-tracecheck-catalog.log — commands 7-25.
- logs/cmd29-task-board-validate.log(.full) — command 29.
- logs/pkg-tests-notmux-v.log — package suite with tmux unresolvable (0 SKIP).
- logs/tmuxserver-cover.out — coverprofile behind the 87.5% figure and the uncovered-block list.
- logs/harness-pass1, harness-pass2 — the shipped producer harness, two full passes, one raw log per row (exit line first).
- logs/reviewer-battery-pass1, -pass2 — reviewer_mutants.py, two passes; per row: <row>.committed.log (suite as shipped) and <row>.probe.log (suite + probes/zz_review_probe_test.go).
- logs/probes-rev1.log — the 16 reviewer probes against the unmutated candidate.
- probes/zz_review_probe_test.go — probe source (never part of the candidate).
- reviewer_mutants.py — the reviewer battery (rows, anchors, expectations).
- logs/run-*.sh — the exact detached runner scripts used.
