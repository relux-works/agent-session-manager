//go:build !windows

package tmuxserver

// Reviewer probes for CR-TASK-260830-35urbp-1 (RUN-260921-0245e5).
// These tests are NOT part of the candidate; they live only in the
// reviewer's isolated probe copy. Each probe drives a production entry
// with an input the committed suite never supplies and records what the
// gate does. A probe named ...HOLE... asserts the defect (it passes when
// the hole is present) so the raw log is the evidence; a probe named
// ...HOLDS... asserts the rule and must pass on the candidate.

import (
	"os"
	"path/filepath"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/scalar"
)

// HOLE 1a: the "binding" arm checks presence, not binding. A running
// server whose attestation names a DIFFERENT generation than the
// request's current generation is attached to on the foreground path.
func TestReviewHoleForegroundAttachAdmitsWrongGeneration(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root) // req.Generation == "generation-7"
	stale := liveAttestation()
	stale.ServerGeneration = "generation-6" // a prior server generation
	stale.MacOSVersion = "14.0-yesterday"
	stale.ProviderBuild = "1.0.0-yesterday"
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		return ServerReport{Running: true, Attestation: stale}, nil
	}
	req.Deps.Spawn = spy.spawn
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatalf("rule HELD (unexpected on rev1): %v", err)
	}
	t.Logf("HOLE: attached-running admitted with attestation generation %q vs request generation %q (via=%s)", stale.ServerGeneration, req.Generation, outcome.Via)
}

// HOLE 1b: same on the background broker path: an attested server
// bound to another generation/build/OS is contacted.
func TestReviewHoleBackgroundBrokerAdmitsWrongGeneration(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.NeedsCredentials = true
	stale := liveAttestation()
	stale.ServerGeneration = "generation-6"
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerStatus, error) {
		return BrokerStatus{Authenticated: true, Attested: true, Attestation: stale}, nil
	}
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatalf("rule HELD (unexpected on rev1): %v", err)
	}
	t.Logf("HOLE: broker contact admitted with attestation generation %q vs request generation %q (via=%s)", stale.ServerGeneration, req.Generation, outcome.Via)
}

// HOLE 1c: the "distinct unconvertible type" is a field copy away. A
// cached observation replayed as the probe's LiveAttestation authorizes
// attach; nothing in the package can tell it from a live one.
func TestReviewHoleCachedObservationReplayedAsLiveAuthorizes(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	cached := CachedObservation{SentinelPassed: true, ManagerName: "Aqua"}
	req.Cached = &cached
	replayed := LiveAttestation{
		SentinelPassed:   cached.SentinelPassed, // copied from the cache
		SmokePassed:      true,                  // cached smoke from yesterday
		ServerGeneration: "generation-6",        // yesterday's server
		ProviderBuild:    "1.0.0-yesterday",
		MacOSVersion:     "14.0-yesterday",
	}
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		return ServerReport{Running: true, Attestation: replayed}, nil
	}
	req.Deps.Spawn = spy.spawn
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatalf("rule HELD (unexpected on rev1): %v", err)
	}
	t.Logf("HOLE: a cached observation copied field-by-field into LiveAttestation authorized via=%s", outcome.Via)
}

// HOLDS: a FIFO planted at the leaf path refuses without blocking the
// opener (O_DIRECTORY refuses at lookup, before the FIFO open).
func TestReviewHoldsFIFOLeafRefusesWithoutBlocking(t *testing.T) {
	root := stateRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := syscall.Mkfifo(leaf, 0o600); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		done <- err
	}()
	select {
	case err := <-done:
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
		t.Logf("HOLDS: FIFO leaf refused promptly: %v", err)
	case <-time.After(5 * time.Second):
		t.Fatal("HOLE: EnsureRuntimeDir blocked on a FIFO leaf")
	}
	vdone := make(chan error, 1)
	go func() { vdone <- VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS) }()
	select {
	case err := <-vdone:
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	case <-time.After(5 * time.Second):
		t.Fatal("HOLE: VerifyRuntimeDir blocked on a FIFO leaf")
	}
}

// HOLDS: a FIFO planted at the root path refuses (Lstat fast path).
func TestReviewHoldsFIFORootRefuses(t *testing.T) {
	parent := t.TempDir()
	root := filepath.Join(parent, "fifo-root")
	if err := syscall.Mkfifo(root, 0o600); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		done <- err
	}()
	select {
	case err := <-done:
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	case <-time.After(5 * time.Second):
		t.Fatal("HOLE: EnsureRuntimeDir blocked on a FIFO root")
	}
}

// OBSERVATION: a symlinked INTERMEDIATE component inside the root path
// is followed (the root is opened by path string, like secprim's own
// OpenNoFollowDir); the leaf is committed under the resolved directory.
// The candidate only refuses a symlink as the root's LAST component.
func TestReviewObserveSymlinkedIntermediateInRootIsFollowed(t *testing.T) {
	real := t.TempDir()
	if err := os.Chmod(real, 0o755); err != nil {
		t.Fatal(err)
	}
	if err := os.Mkdir(filepath.Join(real, "state"), 0o755); err != nil {
		t.Fatal(err)
	}
	outer := t.TempDir()
	link := filepath.Join(outer, "link")
	if err := os.Symlink(real, link); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(link, "state") // intermediate "link" is a symlink
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		t.Logf("REFUSED symlinked-intermediate root: %v", err)
		return
	}
	resolved, _ := filepath.EvalSymlinks(dir)
	t.Logf("OBSERVATION: admitted; returned %q, leaf really at %q (under the symlink target)", dir, resolved)
}

// HOLDS: a symlink leaf pointing at a compliant 0700 owner directory
// refuses on the VERIFY path too (O_NOFOLLOW in verifyRuntimeDir). No
// committed test drives this side; see mutant R-verify-symlink-fallback.
func TestReviewHoldsVerifyRefusesSymlinkLeafToCompliantDir(t *testing.T) {
	root := stateRoot(t)
	elsewhere := t.TempDir()
	target := filepath.Join(elsewhere, "real-runtime")
	if err := os.Mkdir(target, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(target, filepath.Join(root, RuntimeDirName)); err != nil {
		t.Fatal(err)
	}
	err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// HOLDS today: a widened runtime directory refuses THROUGH Acquire. No
// committed Acquire test stages a commit-phase custody refusal; see
// mutant R-acquire-swallow-commit-refusal.
func TestReviewHoldsAcquireRefusesWidenedRuntimeDir(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	if err := os.Chmod(dir, 0o755); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime mode")
	if spy.calls != 0 {
		t.Fatalf("spawned on an unsafe runtime dir: %d", spy.calls)
	}
}

// HOLDS today: the TMUX_TMPDIR value as an override refuses through
// Acquire. It is the fifth ambient member and the one tmux itself uses
// to relocate the DEFAULT socket directory; no committed override test
// supplies it. See mutant R-override-tmpdir.
func TestReviewHoldsAcquireRefusesTmpdirOverride(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	req.SocketOverride = hostileAmbient().TMUXTmpDir
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_ambient_server_reuse", "socket override")
}

// HOLDS today: a collision on each of the other four ambient members
// refuses through Acquire; only DefaultPath is pinned by a committed
// test. See mutants R-collision-inherited/-tmuxenv/-tmpdir/-conventional.
func TestReviewHoldsAcquireRefusesCollisionOnEveryMember(t *testing.T) {
	root := stateRoot(t)
	dir := socketDir(t, root)
	derived := SocketPath(dir)
	for name, ambient := range map[string]Ambient{
		"tmux env":     {TMUXEnv: derived},
		"tmpdir":       {TMUXTmpDir: derived},
		"inherited":    {InheritedSocket: derived},
		"conventional": {ConventionalName: derived},
	} {
		t.Run(name, func(t *testing.T) {
			req := validRequest(t, root)
			req.Ambient = ambient
			spy := &spawnSpy{}
			req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
			req.Deps.Spawn = spy.spawn
			_, err := Acquire(req)
			requireLocalError(t, err, "tmux_ambient_server_reuse", "ambient collision")
		})
	}
}

// OBSERVATION: the crash-retry convergence holds only when the process
// umask leaves the owner bits intact. A leaf left behind by a crash
// between mkdirat and fchmod under umask 0177 (mode 0600) is refused by
// every retry and never converges; the candidate states no such bound.
func TestReviewObserveCrashRetryUnderRestrictiveUmaskNeverConverges(t *testing.T) {
	root := stateRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	// The state a SIGKILL leaves between Mkdirat and Fchmod under a
	// 0177 umask: the entry exists, owner-only but not 0700.
	if err := os.Mkdir(leaf, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(leaf, 0o600); err != nil {
		t.Fatal(err)
	}
	_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err == nil {
		t.Log("converged (the retry repaired or admitted 0600)")
		return
	}
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime mode")
	_, again := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	requireLocalError(t, again, "tmux_unsafe_runtime_dir", "runtime mode")
	t.Logf("OBSERVATION: post-crash 0600 leaf refuses on every retry: %v", err)
}

// HOLDS: the reviewer-shaped fallback the brief names — the background
// miss path re-entering the foreground spawn — is caught by the spies
// (exercised as mutant R-fallback-foreground-reentry in the harness).
// This probe only records the unmutated baseline for that row.
func TestReviewBaselineBackgroundMissNeverSpawns(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.ProbeBroker = func() (BrokerStatus, error) { return BrokerStatus{}, nil }
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d", spy.calls)
	}
}

// HOLDS today: the TMUX environment VALUE is refused at the argv gate
// too; the committed BuildArgv subtests pin four of the five ambient
// members and not this one. See mutant R-argv-env-value.
func TestReviewHoldsBuildArgvRefusesTMUXEnvValue(t *testing.T) {
	dir := runtimeDir(t, stateRoot(t))
	_, err := BuildArgv(dir, hostileAmbient().TMUXEnv, fixtureSession)
	requireLocalError(t, err, "tmux_ambient_server_reuse", "spawn socket")
}

// HOLDS today: the explicit Fchmod after mkdirat is load-bearing only
// under a umask that strips owner bits; the committed suite runs under
// the inherited umask (022 here) where mkdirat alone yields 0700. See
// mutant R-fchmod-arm-unmeasured.
func TestReviewHoldsCreateEnforces0700UnderRestrictiveUmask(t *testing.T) {
	root := stateRoot(t) // created before the umask narrows
	previous := syscall.Umask(0o177)
	defer syscall.Umask(previous)
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Lstat(dir)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm() != 0o700 {
		t.Fatalf("mode = %04o under umask 0177, want 0700", info.Mode().Perm())
	}
}
