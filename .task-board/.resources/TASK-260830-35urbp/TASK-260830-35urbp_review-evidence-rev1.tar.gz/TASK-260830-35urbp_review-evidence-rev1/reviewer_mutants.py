#!/usr/bin/env python3
"""Reviewer narrowing battery for CR-TASK-260830-35urbp-1 (RUN-260921-0245e5).

Each row: M (mutate one production file in place inside the mutant copy),
R1 (run the COMMITTED suite exactly as shipped, full package, no -run
mask, so a kill anywhere in the package counts), R2 (copy the reviewer's
probe file in and run the package again, so a SURVIVED row is proven to
be a real narrowing that a test CAN kill), V (verdict per run from the go
exit code plus a FAIL line). Files are restored from backup after every
row. One raw log per plant per run, with the subprocess exit.

Verdict vocabulary per run: KILLED (exit != 0 with a --- FAIL line),
SURVIVED (exit 0), ERROR (build break / no kill line / anchor mismatch).

Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 reviewer_mutants.py --repo <mutant-copy> \
      --probe <probe-file> --log-dir <dir> [ROW ...]
"""

import argparse
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

PACKAGE = "internal/tmuxserver"


@dataclass(frozen=True)
class Row:
    name: str
    kind: str  # narrowing | additive | delete-only | control
    path: str
    find: str
    replace: str
    expect_committed: str
    expect_probe: str
    note: str


ROWS = [
    Row(
        name="R-acquire-swallow-commit-refusal",
        kind="narrowing",
        path=f"{PACKAGE}/acquire.go",
        find="\tdir, err := EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil)\n\tif err != nil {\n",
        replace="\tdir, err := EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil)\n\tif err != nil && dir == \"\" {\n",
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="Acquire keeps lexical refusals (dir==\"\") but admits every commit-phase custody refusal (mode, ownership, filesystem containment return joined+err). No committed Acquire test stages one; rows 4-9 are pinned at the helper only.",
    ),
    Row(
        name="R-verify-symlink-fallback",
        kind="narrowing",
        path=f"{PACKAGE}/runtime_unix.go",
        find="\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n\tif err != nil {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime containment\"}\n\t}\n\tleaf := os.NewFile(uintptr(leafFd), name)\n",
        replace="\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n\tif err != nil {\n\t\tleafFd, err = unix.Openat(int(rootHandle.Fd()), name,\n\t\t\tunix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n\t}\n\tif err != nil {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime containment\"}\n\t}\n\tleaf := os.NewFile(uintptr(leafFd), name)\n",
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="The VERIFY side follows a symlink leaf (same shape as the producer's N-containment-symlink, which mutates only the commit side). Row 6 names EnsureRuntimeDir only.",
    ),
    Row(
        name="R-override-tmpdir",
        kind="narrowing",
        path=f"{PACKAGE}/socket.go",
        find='\tif override != "" {\n',
        replace='\tif override != "" && override != "/tmp/operator-tmux" {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="Admits exactly the TMUX_TMPDIR value as an override; the fifth ambient member (the one tmux uses to relocate its default socket dir) has no committed override row.",
    ),
    Row(
        name="R-collision-inherited",
        kind="narrowing",
        path=f"{PACKAGE}/socket.go",
        find='\tif candidate != "" && candidate == socket {\n',
        replace='\tif candidate != "" && candidate == socket && candidate != ambient.InheritedSocket {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="Collision gate pinned per key: only DefaultPath is witnessed (N-collision). InheritedSocket collision admitted.",
    ),
    Row(
        name="R-collision-tmuxenv",
        kind="narrowing",
        path=f"{PACKAGE}/socket.go",
        find='\tif candidate != "" && candidate == socket {\n',
        replace='\tif candidate != "" && candidate == socket && candidate != ambient.TMUXEnv {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="TMUXEnv collision admitted.",
    ),
    Row(
        name="R-collision-tmpdir",
        kind="narrowing",
        path=f"{PACKAGE}/socket.go",
        find='\tif candidate != "" && candidate == socket {\n',
        replace='\tif candidate != "" && candidate == socket && candidate != ambient.TMUXTmpDir {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="TMUXTmpDir collision admitted.",
    ),
    Row(
        name="R-collision-conventional",
        kind="narrowing",
        path=f"{PACKAGE}/socket.go",
        find='\tif candidate != "" && candidate == socket {\n',
        replace='\tif candidate != "" && candidate == socket && candidate != ambient.ConventionalName {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="ConventionalName collision admitted.",
    ),
    Row(
        name="R-argv-env-value",
        kind="narrowing",
        path=f"{PACKAGE}/argv.go",
        find="\tif socket != SocketPath(runtimeDir) {\n",
        replace='\tif socket != SocketPath(runtimeDir) && socket != "/tmp/tmux-501/default,12345,0" {\n',
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="Row 47 pins four of five ambient members at the argv gate; the TMUX environment value walks through. Reach: direct BuildArgv call only (Acquire always passes the derived socket).",
    ),
    Row(
        name="R-fchmod-arm-unmeasured",
        kind="narrowing",
        path=f"{PACKAGE}/runtime_unix.go",
        find="\tif created {\n\t\t// The mkdir mode honors umask",
        replace="\tif created && os.Getuid() == 0 {\n\t\t// The mkdir mode honors umask",
        expect_committed="SURVIVED",
        expect_probe="KILLED",
        note="The explicit post-mkdirat Fchmod (\"enforced explicitly because mkdir honors umask\") is skipped for non-root; under the suite's inherited umask 022 mkdirat alone yields 0700, so no committed test observes the arm.",
    ),
    Row(
        name="R-fallback-foreground-reentry",
        kind="additive",
        path=f"{PACKAGE}/acquire.go",
        find="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Deps.Spawn != nil {\n\t\t\t\tif argv, aerr := BuildArgv(filepath.Dir(socket), socket, req.SessionID); aerr == nil && req.Deps.Spawn(socket, argv) == nil {\n\t\t\t\t\treturn Outcome{Via: ViaSpawned, Socket: socket, Argv: argv}, nil\n\t\t\t\t}\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        expect_committed="KILLED",
        expect_probe="KILLED",
        note="Reviewer-shaped fallback: the background miss creates the server and returns success (the producer's D row spawns with nil argv and still refuses). Must redden on the zero-call spies. Needs the path/filepath import (added by the harness).",
    ),
    Row(
        name="R-fallback-when-credential-free",
        kind="additive",
        path=f"{PACKAGE}/acquire.go",
        find="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif !req.NeedsCredentials && req.Deps.Spawn != nil {\n\t\t\t\tif argv, aerr := BuildArgv(filepath.Dir(socket), socket, req.SessionID); aerr == nil && req.Deps.Spawn(socket, argv) == nil {\n\t\t\t\t\treturn Outcome{Via: ViaSpawned, Socket: socket, Argv: argv}, nil\n\t\t\t\t}\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        expect_committed="KILLED",
        expect_probe="KILLED",
        note="The \"credential-free background creation\" misreading: background creates when NeedsCredentials is false. Pinned only if a NeedsCredentials=false background miss arms a spy.",
    ),
    Row(
        name="R-fallback-non-macos",
        kind="additive",
        path=f"{PACKAGE}/acquire.go",
        find="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform != scalar.PlatformMacOS && req.Deps.Spawn != nil {\n\t\t\t\tif argv, aerr := BuildArgv(filepath.Dir(socket), socket, req.SessionID); aerr == nil && req.Deps.Spawn(socket, argv) == nil {\n\t\t\t\t\treturn Outcome{Via: ViaSpawned, Socket: socket, Argv: argv}, nil\n\t\t\t\t}\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        expect_committed="KILLED",
        expect_probe="KILLED",
        note="The \"credential-sensitivity is macOS-only, so Linux background may create\" misreading. Pinned only if a non-macOS background miss arms a spy.",
    ),
    Row(
        name="R-ambient-vocabulary-dead-arm",
        kind="delete-only",
        path=f"{PACKAGE}/socket.go",
        find='\tif !secprim.IsEnvName(EnvTMUX) || !secprim.IsEnvName(EnvTMUXTmpDir) {\n\t\treturn Ambient{}, &Error{Code: CodeInvalidArguments, Detail: "ambient vocabulary"}\n\t}\n',
        replace='\t_ = secprim.IsEnvName\n',
        expect_committed="SURVIVED",
        expect_probe="SURVIVED",
        note="DELETE-ONLY, informational: the \"ambient vocabulary\" refusal guards two package constants that are valid env names, so the arm is unreachable; row 18's refusal text describes no behaviour.",
    ),
    Row(
        name="R-control",
        kind="control",
        path=f"{PACKAGE}/errors.go",
        find="// CodeSpawnFailed reports a dedicated-server spawn failure.",
        replace="// CodeSpawnFailed reports a dedicated-server spawn failure. (reviewer harness control: comment-only)",
        expect_committed="SURVIVED",
        expect_probe="SURVIVED",
        note="Harmless control; must SURVIVE both runs.",
    ),
]

IMPORT_FIX = {
    # rows that reference path/filepath in acquire.go need the import
    "R-fallback-foreground-reentry": ("\"github.com/relux-works/agent-session-manager/internal/axerror\"\n", "\"path/filepath\"\n\n\t\"github.com/relux-works/agent-session-manager/internal/axerror\"\n"),
    "R-fallback-when-credential-free": ("\"github.com/relux-works/agent-session-manager/internal/axerror\"\n", "\"path/filepath\"\n\n\t\"github.com/relux-works/agent-session-manager/internal/axerror\"\n"),
    "R-fallback-non-macos": ("\"github.com/relux-works/agent-session-manager/internal/axerror\"\n", "\"path/filepath\"\n\n\t\"github.com/relux-works/agent-session-manager/internal/axerror\"\n"),
}


def run_go(repo: Path, log_path: Path, label: str) -> str:
    cmd = ["go", "test", f"./{PACKAGE}/", "-count=1"]
    run = subprocess.run(cmd, cwd=repo, capture_output=True, text=True, timeout=600)
    output = (run.stdout + run.stderr).strip()
    log_path.write_text(f"run: {label}\ncmd: {' '.join(cmd)}\nexit: {run.returncode}\n\n{output}\n")
    if "build failed" in output or "\n# " in output or output.startswith("# "):
        return "ERROR(build)"
    if run.returncode == 0:
        return "SURVIVED"
    if "--- FAIL" in output or "FAIL:" in output:
        return "KILLED"
    return "ERROR(no-kill-line)"


def run_row(row: Row, repo: Path, probe: Path, log_dir: Path) -> str:
    target = repo / row.path
    original = target.read_text()
    if original.count(row.find) != 1:
        return f"ERROR: {row.name}: anchor count {original.count(row.find)} != 1"
    mutated = original.replace(row.find, row.replace)
    if row.name in IMPORT_FIX:
        old, new = IMPORT_FIX[row.name]
        if mutated.count(old) != 1:
            return f"ERROR: {row.name}: import anchor missing"
        mutated = mutated.replace(old, new)
    probe_dst = repo / PACKAGE / probe.name
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(mutated)
            committed = run_go(repo, log_dir / f"{row.name}.committed.log", f"{row.name} against the committed suite as shipped")
            shutil.copy2(probe, probe_dst)
            try:
                probed = run_go(repo, log_dir / f"{row.name}.probe.log", f"{row.name} against committed suite + reviewer probe file")
            finally:
                probe_dst.unlink(missing_ok=True)
        finally:
            shutil.copy2(backup, target)
    mark = "ok" if (committed == row.expect_committed and probed == row.expect_probe) else "MISMATCH"
    return (f"{mark}: {row.name} [{row.kind}]: committed={committed} (want {row.expect_committed}) "
            f"probe={probed} (want {row.expect_probe}) :: {row.note}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo", required=True)
    parser.add_argument("--probe", required=True)
    parser.add_argument("--log-dir", required=True)
    parser.add_argument("rows", nargs="*")
    args = parser.parse_args()
    repo = Path(args.repo).resolve()
    probe = Path(args.probe).resolve()
    log_dir = Path(args.log_dir).resolve()
    log_dir.mkdir(parents=True, exist_ok=True)
    selected = [r for r in ROWS if not args.rows or r.name in args.rows]
    failures = 0
    for row in selected:
        try:
            line = run_row(row, repo, probe, log_dir)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {row.name}: timed out"
        print(line, flush=True)
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
