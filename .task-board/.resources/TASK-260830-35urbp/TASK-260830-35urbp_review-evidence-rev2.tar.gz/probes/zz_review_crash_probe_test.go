//go:build darwin || linux

package tmuxserver

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/scalar"
)

// P26: after the SIGKILL in AfterMkdir the leaf already exists (mkdirat
// committed) and the parent's retry verifies it rather than recreating.
func TestReviewProbeCrashLeavesCommittedLeafThenRetryVerifies(t *testing.T) {
	if os.Getenv(crashChildMode) == "ensure" {
		t.Skip("child mode handled by the committed test")
	}
	root := stateRoot(t)
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestEnsureCrashChildSelfTerminates$", "-test.count=1")
	child.Env = append(os.Environ(), crashChildMode+"=ensure", crashChildRoot+"="+root)
	runErr := child.Run()
	var exitErr *exec.ExitError
	if !errors.As(runErr, &exitErr) {
		t.Fatalf("child run = %v", runErr)
	}
	status := exitErr.Sys().(syscall.WaitStatus)
	if !status.Signaled() || status.Signal() != syscall.SIGKILL {
		t.Fatalf("child status = %v", exitErr)
	}
	info, err := os.Lstat(filepath.Join(root, RuntimeDirName))
	if err != nil {
		t.Fatalf("leaf absent after the kill: %v (mkdirat did not commit before the hook)", err)
	}
	t.Logf("leaf present after SIGKILL with mode %04o (mkdirat committed, chmod/verify/fsync skipped)", info.Mode().Perm())
	if err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS); err != nil {
		t.Logf("verify before retry: %v", err)
	}
	if _, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil); err != nil {
		t.Fatalf("retry: %v", err)
	}
}
