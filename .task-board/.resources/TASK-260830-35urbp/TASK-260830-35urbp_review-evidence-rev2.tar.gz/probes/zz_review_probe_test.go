//go:build !windows

package tmuxserver

// Reviewer probes for CR-TASK-260830-35urbp-2 (RUN-260921-5a9d4b).
// Each probe states its prediction in its name or comment; a probe that
// PASSES confirms the prediction. None of these is a product edit: the
// file lives only in the reviewer's isolated probe copy.

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func probeForeground(t *testing.T, root string) (Request, *spawnSpy) {
	t.Helper()
	req := validRequest(t, root)
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	return req, spy
}

// P01: the collision gate compares strings, not paths. An ambient value
// that names the derived socket through an unclean spelling walks past
// it. Prediction: admitted (spawned), i.e. the gate is bypassed.
func TestReviewProbeCollisionUncleanDotSpellingWalksThrough(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	req, spy := probeForeground(t, root)
	alias := dir + "/./" + SocketName
	if filepath.Clean(alias) != SocketPath(dir) {
		t.Fatalf("alias %q does not clean to the derived socket", alias)
	}
	req.Ambient = Ambient{DefaultPath: alias}
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatalf("PREDICTION FAILED: unclean alias was refused: %v", err)
	}
	if outcome.Via != "spawned" || spy.calls != 1 {
		t.Fatalf("outcome = %+v spawns=%d", outcome, spy.calls)
	}
	t.Logf("CONFIRMED: ambient %q names the derived socket %q after Clean and is admitted", alias, outcome.Socket)
}

// P02: same with a doubled separator.
func TestReviewProbeCollisionDoubleSlashSpellingWalksThrough(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	req, _ := probeForeground(t, root)
	alias := dir + "//" + SocketName
	req.Ambient = Ambient{InheritedSocket: alias}
	if _, err := Acquire(req); err != nil {
		t.Fatalf("PREDICTION FAILED: doubled-separator alias was refused: %v", err)
	}
	t.Logf("CONFIRMED: %q admitted", alias)
}

// P03: an ambient value that names the derived socket through a symlinked
// root alias also walks through (realpath equivalence is not applied).
func TestReviewProbeCollisionSymlinkAliasWalksThrough(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	link := filepath.Join(t.TempDir(), "alias-root")
	if err := os.Symlink(root, link); err != nil {
		t.Fatal(err)
	}
	alias := filepath.Join(link, RuntimeDirName, SocketName)
	realAliasDir, err := filepath.EvalSymlinks(filepath.Join(link, RuntimeDirName))
	if err != nil {
		t.Fatal(err)
	}
	realDir, err := filepath.EvalSymlinks(dir)
	if err != nil {
		t.Fatal(err)
	}
	if realAliasDir != realDir {
		t.Fatalf("alias dir %q resolves to %q, derived dir resolves to %q", alias, realAliasDir, realDir)
	}
	if alias == SocketPath(dir) {
		t.Fatal("alias spelled identically; probe is vacuous")
	}
	req, _ := probeForeground(t, root)
	req.Ambient = Ambient{TMUXEnv: alias}
	if _, err := Acquire(req); err != nil {
		t.Fatalf("PREDICTION FAILED: symlink alias was refused: %v", err)
	}
	t.Logf("CONFIRMED: %q (resolves to the derived socket) admitted", alias)
}

func runWithDeadline(t *testing.T, name string, fn func() error) error {
	t.Helper()
	done := make(chan error, 1)
	go func() { done <- fn() }()
	select {
	case err := <-done:
		return err
	case <-time.After(5 * time.Second):
		t.Fatalf("%s BLOCKED for 5s (a FIFO open without O_NONBLOCK/O_DIRECTORY hangs)", name)
		return nil
	}
}

// P04: a FIFO leaf refuses on the commit side without blocking.
func TestReviewProbeFIFOLeafEnsureRefusesWithoutBlocking(t *testing.T) {
	root := stateRoot(t)
	if err := syscall.Mkfifo(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
		t.Fatal(err)
	}
	err := runWithDeadline(t, "EnsureRuntimeDir", func() error {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		return err
	})
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// P05: a FIFO leaf refuses on the verify side without blocking.
func TestReviewProbeFIFOLeafVerifyRefusesWithoutBlocking(t *testing.T) {
	root := stateRoot(t)
	if err := syscall.Mkfifo(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
		t.Fatal(err)
	}
	err := runWithDeadline(t, "VerifyRuntimeDir", func() error {
		return VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	})
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// P06: a FIFO root refuses on both entries without blocking.
func TestReviewProbeFIFORootRefusesWithoutBlocking(t *testing.T) {
	root := filepath.Join(t.TempDir(), "fifo-root")
	if err := syscall.Mkfifo(root, 0o600); err != nil {
		t.Fatal(err)
	}
	err := runWithDeadline(t, "EnsureRuntimeDir(fifo root)", func() error {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		return err
	})
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	err = runWithDeadline(t, "VerifyRuntimeDir(fifo root)", func() error {
		return VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	})
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// P07: bound B11 — a symlinked intermediate component inside the root
// path is followed; the leaf lands under the link target.
func TestReviewProbeSymlinkedIntermediateInRootIsFollowed(t *testing.T) {
	target := stateRoot(t)
	if err := os.Mkdir(filepath.Join(target, "state"), 0o755); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(t.TempDir(), "link")
	if err := os.Symlink(target, link); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(link, "state")
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		t.Fatalf("PREDICTION FAILED (B11): symlinked intermediate refused: %v", err)
	}
	if _, err := os.Lstat(filepath.Join(target, "state", RuntimeDirName)); err != nil {
		t.Fatalf("leaf not under the link target: %v", err)
	}
	t.Logf("CONFIRMED B11: %q created through a symlinked intermediate", dir)
}

// P08: the mode gate reads Perm() only; setgid/sticky bits on a 0700
// leaf are admitted (observation, not a spec rule).
func TestReviewProbeSetgidStickyBitsOnLeafAdmitted(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	if err := os.Chmod(dir, 0o700|os.ModeSetgid|os.ModeSticky); err != nil {
		t.Fatal(err)
	}
	info, err := os.Lstat(dir)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("leaf mode now %v", info.Mode())
	if _, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil); err != nil {
		t.Fatalf("PREDICTION FAILED: setgid/sticky 0700 leaf refused: %v", err)
	}
	if err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS); err != nil {
		t.Fatalf("PREDICTION FAILED: verify refused: %v", err)
	}
	t.Log("CONFIRMED: Perm()-only mode gate admits 0700 with setgid/sticky set")
}

// P09: baseline for the reviewer plant R-verify-odirectory: a regular
// 0700 file at the leaf refuses on the VERIFY side with the containment
// detail (O_DIRECTORY at lookup). No committed test drives this arm.
func TestReviewProbeVerifyRegularFileLeafRefuses(t *testing.T) {
	root := stateRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := os.WriteFile(leaf, []byte("x"), 0o700); err != nil {
		t.Fatal(err)
	}
	err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// P09b: the same through the background production entry.
func TestReviewProbeBackgroundRegularFileLeafRefusesThroughAcquire(t *testing.T) {
	root := stateRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := os.WriteFile(leaf, []byte("x"), 0o700); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	req.Caller = CallerBackground
	probed := false
	req.Deps.ProbeBroker = func() (BrokerReport, error) { probed = true; return brokerReport(), nil }
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	if probed {
		t.Fatal("broker probed past a non-directory leaf")
	}
}

// P10: baseline for the reviewer plant R-attested-empty-generation: an
// admission with an EMPTY raw generation against an EMPTY wanted
// generation refuses on the generation arm. No committed test drives
// both-empty (the committed rows each keep one side non-empty).
func TestReviewProbeCheckServerAttestedBothGenerationsEmptyRefuses(t *testing.T) {
	err := CheckServerAttested(RealmAdmission{Admitted: realmAdmitted()}, "")
	requireLocalError(t, err, "tmux_readiness_not_authorizing", "server generation")
}

// P11: baseline for the reviewer plant R-broker-empty-generation.
func TestReviewProbeCheckBrokerContactBothGenerationsEmptyRefuses(t *testing.T) {
	report := BrokerReport{
		Principal: BrokerPrincipal{UID: currentUID()},
		Server:    RealmAdmission{Admitted: realmAdmitted()},
	}
	err := CheckBrokerContact(report, "", currentUID())
	requireLocalError(t, err, "tmux_readiness_not_authorizing", "broker generation")
}

// P12: a request whose typed generation is newer than the broker's
// live report refuses through Acquire with the request's generation in
// the typed details.
func TestReviewProbeBackgroundNewerRequestGenerationRefuses(t *testing.T) {
	root := stateRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Generation = "generation-8"
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, "generation-8", fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d", spy.calls)
	}
}

// P13: the foreground path never consults the broker probe.
func TestReviewProbeForegroundNeverProbesBroker(t *testing.T) {
	root := stateRoot(t)
	req, _ := probeForeground(t, root)
	req.Deps.ProbeBroker = func() (BrokerReport, error) {
		t.Fatal("foreground path probed the broker")
		return BrokerReport{}, nil
	}
	if _, err := Acquire(req); err != nil {
		t.Fatal(err)
	}
}

// P14: backslash in the runtime name refuses at the name grammar.
func TestReviewProbeNameBackslashRefused(t *testing.T) {
	root := stateRoot(t)
	_, err := EnsureRuntimeDir(root, `a\b`, scalar.PlatformMacOS, nil)
	requireLocalError(t, err, "tmux_invalid_arguments", "runtime name")
}

// P15: a trailing-slash root — record the behaviour.
func TestReviewProbeRootTrailingSlash(t *testing.T) {
	root := stateRoot(t)
	dir, err := EnsureRuntimeDir(root+"/", RuntimeDirName, scalar.PlatformMacOS, nil)
	t.Logf("trailing-slash root: dir=%q err=%v", dir, err)
}

// P16: a whitespace override refuses (non-empty).
func TestReviewProbeOverrideWhitespaceRefused(t *testing.T) {
	root := stateRoot(t)
	req, _ := probeForeground(t, root)
	req.SocketOverride = " "
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_ambient_server_reuse", "socket override")
}

// P17: background verify refuses foreign ownership through Acquire
// before the broker is probed (row 7 extended to the entry wiring).
func TestReviewProbeBackgroundForeignOwnershipRefusesThroughAcquire(t *testing.T) {
	root := stateRoot(t)
	runtimeDir(t, root)
	previous := effectiveUID
	effectiveUID = func() int { return previous() + 100000 }
	defer func() { effectiveUID = previous }()
	req := validRequest(t, root)
	req.Caller = CallerBackground
	probed := false
	req.Deps.ProbeBroker = func() (BrokerReport, error) { probed = true; return brokerReport(), nil }
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime ownership")
	if probed {
		t.Fatal("broker probed past an ownership refusal")
	}
}

// P18: an over-long remediation reaches the uncovered constructor arm
// (acquire.go:260) and refuses invalid_arguments rather than returning
// nil or an untyped refusal.
func TestReviewProbeOverlongRemediationRefusesTyped(t *testing.T) {
	root := stateRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	for name, remedy := range map[string]string{
		"5000 chars":    strings.Repeat("r", 5000),
		"100000 chars":  strings.Repeat("r", 100000),
		"invalid utf-8": "retry \xff\xfe",
		"control char":  "retry\x00now",
	} {
		t.Run(name, func(t *testing.T) {
			req := req
			req.Remediation = remedy
			spy := &spawnSpy{}
			req.Deps.Spawn = spy.spawn
			req.Deps.ProbeBroker = func() (BrokerReport, error) { return BrokerReport{}, nil }
			outcome, err := Acquire(req)
			if err == nil {
				t.Fatalf("PREDICTION FAILED: remediation admitted: %+v", outcome)
			}
			var failure *axerror.Error
			if errors.As(err, &failure) {
				t.Logf("axerror %s (exit %d) wrapping %v", failure.Code(), failure.ExitCode(), errors.Unwrap(err))
			} else {
				var local *Error
				if errors.As(err, &local) {
					t.Logf("local refusal: %s at %s", local.Code, local.Detail)
				} else {
					t.Logf("refused with %T: %v", err, err)
				}
			}
			if spy.calls != 0 {
				t.Fatalf("spawn calls = %d", spy.calls)
			}
		})
	}
}

// P19: bound B10 — a leaf stranded at 0600 (as if between mkdirat and
// the explicit chmod under an owner-bit-stripping umask) never
// converges: Ensure refuses on every retry.
func TestReviewProbeStrandedNarrowLeafNeverConverges(t *testing.T) {
	root := stateRoot(t)
	if err := os.Mkdir(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 2; i++ {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime mode")
	}
	t.Log("CONFIRMED B10: a stranded 0600 leaf refuses on retry, never repaired")
}

// P20: the uncovered Mkdirat error arm (non-EEXIST) is fail-closed: a
// read-only root refuses with the commit detail.
func TestReviewProbeReadOnlyRootRefusesCommit(t *testing.T) {
	if os.Geteuid() == 0 {
		t.Skip("root bypasses directory write permission")
	}
	root := stateRoot(t)
	if err := os.Chmod(root, 0o500); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chmod(root, 0o755) }()
	_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime commit")
}

// P21: the broker hit path returns the derived socket and no argv even
// when a spawner is wired (spawner unused).
func TestReviewProbeBrokerHitCarriesNoArgvAndDerivedSocket(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Ambient = hostileAmbient()
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Via != "broker" || outcome.Socket != SocketPath(dir) || outcome.Argv != nil || spy.calls != 0 {
		t.Fatalf("outcome = %+v spawns=%d", outcome, spy.calls)
	}
}

// P22: a probe reporting an Admitted set with the realm row AND extra
// rows admits (membership, not equality) — confirms Has semantics.
func TestReviewProbeAdmittedSupersetAdmits(t *testing.T) {
	root := stateRoot(t)
	req, spy := probeForeground(t, root)
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		return ServerReport{Running: true, Admission: RealmAdmission{
			Admitted:      terminalbackend.Admitted{Capabilities: []string{"durable_disconnect", "credential_capable_execution_realm"}},
			RawGeneration: fixtureGeneration,
		}}, nil
	}
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Via != "attached-running" || spy.calls != 0 {
		t.Fatalf("outcome = %+v spawns=%d", outcome, spy.calls)
	}
}

// P23: umask 0077 (owner bits preserved) — Ensure converges to 0700 and
// a subsequent Verify admits.
func TestReviewProbeUmask0077Converges(t *testing.T) {
	root := stateRoot(t)
	previous := syscall.Umask(0o077)
	defer syscall.Umask(previous)
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Lstat(dir)
	if err != nil {
		t.Fatal(err)
	}
	if info.Mode().Perm() != 0o700 {
		t.Fatalf("mode = %04o", info.Mode().Perm())
	}
	if err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS); err != nil {
		t.Fatal(err)
	}
}

// P24: baseline for the reviewer plant R11b: a pre-existing 0600 leaf
// refuses on the VERIFY side with the mode detail ("exactly 0700" on the
// narrower side). No committed test drives a narrower-than-0700 leaf on
// Verify.
func TestReviewProbeVerifyNarrowerLeafRefuses(t *testing.T) {
	root := stateRoot(t)
	if err := os.Mkdir(filepath.Join(root, RuntimeDirName), 0o600); err != nil {
		t.Fatal(err)
	}
	err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime mode")
	if err := os.Chmod(filepath.Join(root, RuntimeDirName), 0o500); err != nil {
		t.Fatal(err)
	}
	err = VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime mode")
}

// P25: the argv session token is the canonical (lowercase) UUID even when
// the request spells it in uppercase — records whether the landed grammar
// admits uppercase and whether BuildArgv canonicalizes.
func TestReviewProbeArgvSessionCanonicalized(t *testing.T) {
	dir := runtimeDir(t, stateRoot(t))
	upper := strings.ToUpper(fixtureSession)
	argv, err := BuildArgv(dir, SocketPath(dir), upper)
	if err != nil {
		t.Logf("uppercase session refused by the landed grammar: %v", err)
		return
	}
	t.Logf("argv session tokens: -s %q, tail %q", argv[6], argv[9])
	if argv[6] != fixtureSession || argv[9] != fixtureSession {
		t.Fatalf("argv carries a non-canonical session spelling: %q", argv)
	}
}
