#!/usr/bin/env python3
"""Reviewer narrowing battery for CR-TASK-260830-35urbp-2 (RUN-260921-5a9d4b).

Runs on the isolated mutant copy only. Every row: verify the anchor count,
apply the plant, run the COMMITTED suite as shipped (full package, no -run
mask), record exit + raw output, restore from backup. Rows with a `probe`
killer are additionally run with the reviewer probe file present and the
named killer selected, to prove a survivor is a real narrowing one test
kills (not an unmeasurable arm).

Usage: PYTHONDONTWRITEBYTECODE=1 python3 reviewer_battery.py <copy-root> <probe-file> <log-dir>
"""

import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

PKG = "internal/tmuxserver"


@dataclass(frozen=True)
class Row:
    name: str
    kind: str  # narrowing | additive | error-arm | control
    path: str
    find: str
    replace: str
    count: int
    predict: str  # KILLED | SURVIVED
    probe: str  # killer -run mask with the probe file present, or ""
    note: str


ROWS = [
    Row(
        "R01-verify-odirectory", "narrowing", f"{PKG}/runtime_unix.go",
        "\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
        "\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)\n",
        1, "SURVIVED", "(TestReviewProbeVerifyRegularFileLeafRefuses|TestReviewProbeFIFOLeafVerifyRefusesWithoutBlocking)",
        "Verify side admits non-directory leaves (drops O_DIRECTORY): a regular 0700 file passes Verify/Acquire-background; a FIFO would block. Commit side keeps O_DIRECTORY.",
    ),
    Row(
        "R02-attested-empty-generation", "narrowing", f"{PKG}/readiness.go",
        '\tif wantGeneration == "" || admission.RawGeneration != wantGeneration {\n',
        "\tif admission.RawGeneration != wantGeneration {\n",
        1, "SURVIVED", "TestReviewProbeCheckServerAttestedBothGenerationsEmptyRefuses",
        "CheckServerAttested admits exactly the both-empty generation pair; every non-empty mismatch still refuses.",
    ),
    Row(
        "R03-broker-empty-generation", "narrowing", f"{PKG}/readiness.go",
        '\tif report.Principal.Generation == "" || report.Principal.Generation != wantGeneration {\n',
        "\tif report.Principal.Generation != wantGeneration {\n",
        1, "SURVIVED", "TestReviewProbeCheckBrokerContactBothGenerationsEmptyRefuses",
        "CheckBrokerContact admits exactly the both-empty principal generation pair.",
    ),
    Row(
        "R05-unattested-as-absent", "narrowing", f"{PKG}/acquire.go",
        "\tif report.Running {\n",
        "\tif report.Running && report.Admission.Admitted.Has(realmCapability) {\n",
        1, "KILLED", "",
        "Foreground treats a running-unattested server as absent and spawns a second server over it.",
    ),
    Row(
        "R06-broker-uid-self", "narrowing", f"{PKG}/acquire.go",
        "\tif err := CheckBrokerContact(status, req.Generation, currentUID()); err != nil {\n",
        "\tif err := CheckBrokerContact(status, req.Generation, status.Principal.UID); err != nil {\n",
        1, "KILLED", "",
        "Entry wiring compares the broker UID against itself, admitting every foreign-user broker.",
    ),
    Row(
        "R07-probe-before-verify", "additive", f"{PKG}/acquire.go",
        "\tif verr := VerifyRuntimeDir(req.Root, req.Name, req.Platform); verr != nil {\n",
        "\t_, _ = req.Deps.ProbeBroker()\n\tif verr := VerifyRuntimeDir(req.Root, req.Name, req.Platform); verr != nil {\n",
        1, "KILLED", "",
        "Background contacts the broker before custody is verified.",
    ),
    Row(
        "R08-silent-repair", "narrowing", f"{PKG}/runtime_unix.go",
        "\tif created {\n",
        "\tif created || os.Geteuid() >= 0 {\n",
        1, "KILLED", "",
        "Ensure chmods every existing leaf back to 0700 (silent repair of a widened directory).",
    ),
    Row(
        "R09-ensure-before-override", "additive", f"{PKG}/acquire.go",
        "\tsocket, err := ResolveSocket(dir, req.SocketOverride, req.Ambient)\n",
        "\tif req.Caller == CallerForeground {\n\t\t_, _ = EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil)\n\t}\n\tsocket, err := ResolveSocket(dir, req.SocketOverride, req.Ambient)\n",
        1, "KILLED", "",
        "The durable directory write happens before the override refusal.",
    ),
    Row(
        "R10-handle-stat-fail-open", "error-arm", f"{PKG}/runtime.go",
        "\thandleInfo, err := handle.Stat()\n\tif err != nil || handleInfo == nil {\n\t\treturn false\n\t}\n\tpathInfo, err := os.Stat(rootPath)\n\tif err != nil || pathInfo == nil {\n\t\treturn false\n\t}\n",
        "\thandleInfo, err := handle.Stat()\n\tif err != nil || handleInfo == nil {\n\t\treturn true\n\t}\n\tpathInfo, err := os.Stat(rootPath)\n\tif err != nil || pathInfo == nil {\n\t\treturn true\n\t}\n",
        1, "SURVIVED", "",
        "The documented fail-closed stat arms of handleBoundToPath flip to fail-open; no test can stage a stat failure without a seam (expected unmeasurable).",
    ),
    Row(
        "R11a-mode-narrower-create", "narrowing", f"{PKG}/runtime_unix.go",
        "\tif info.Mode().Perm() != 0o700 {\n\t\t_ = leaf.Close()\n",
        "\tif info.Mode().Perm()&0o077 != 0 {\n\t\t_ = leaf.Close()\n",
        1, "SURVIVED", "TestReviewProbeStrandedNarrowLeafNeverConverges",
        "Create-side mode arm admits owner-narrower modes (0600/0500); widened modes still refuse. 'Exactly 0700' pinned only on the widened side.",
    ),
    Row(
        "R11b-mode-narrower-verify", "narrowing", f"{PKG}/runtime_unix.go",
        "\tif info.Mode().Perm() != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime mode\"}\n\t}\n\treturn verifyOwnership(info)\n",
        "\tif info.Mode().Perm()&0o077 != 0 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime mode\"}\n\t}\n\treturn verifyOwnership(info)\n",
        1, "SURVIVED", "TestReviewProbeVerifyNarrowerLeafRefuses",
        "Verify-side mode arm admits owner-narrower modes; no committed test stages a narrower leaf on Verify.",
    ),
    Row(
        "R14-linux-miss-fallback", "additive", f"{PKG}/acquire.go",
        "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform != scalar.PlatformMacOS && req.Deps.Spawn != nil {\n\t\t\t\t_ = req.Deps.Spawn(socket, []string{\"tmux\", \"-S\", socket, \"new-session\", \"-d\"})\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
        1, "KILLED", "",
        "Reviewer-shaped fallback: a non-macOS background miss creates directly (credential-free platform excuse).",
    ),
    Row(
        "R20a-details-generation", "narrowing", f"{PKG}/acquire.go",
        '\tif req.Generation == "" || req.BrokerState == "" || req.Remediation == "" {\n',
        '\tif req.BrokerState == "" || req.Remediation == "" {\n',
        1, "KILLED", "",
        "Typed-details arm admits an empty generation.",
    ),
    Row(
        "R20b-details-broker", "narrowing", f"{PKG}/acquire.go",
        '\tif req.Generation == "" || req.BrokerState == "" || req.Remediation == "" {\n',
        '\tif req.Generation == "" || req.Remediation == "" {\n',
        1, "KILLED", "",
        "Typed-details arm admits an empty broker state.",
    ),
    Row(
        "R25-background-ensures", "narrowing", f"{PKG}/acquire.go",
        "\tif verr := VerifyRuntimeDir(req.Root, req.Name, req.Platform); verr != nil {\n",
        "\tif _, verr := EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil); verr != nil {\n",
        1, "KILLED", "",
        "Background performs the durable directory write on the authorizing path (the rev1 P2-D shape).",
    ),
    Row(
        "C-reviewer-control", "control", f"{PKG}/socket.go",
        "// SocketName is the fixed private socket leaf inside the runtime\n",
        "// SocketName is the fixed private socket leaf inside the runtime (reviewer control: comment-only)\n",
        1, "SURVIVED", "",
        "Harmless comment-only control that must SURVIVE.",
    ),
]


def go_test(root: Path, mask: str, log: Path) -> tuple[int, str]:
    cmd = ["go", "test", f"./{PKG}/", "-count=1"]
    if mask:
        cmd += ["-run", mask]
    run = subprocess.run(cmd, cwd=root, capture_output=True, text=True, timeout=600)
    out = (run.stdout + run.stderr).strip()
    log.write_text(f"exit: {run.returncode}\ncmd: {' '.join(cmd)}\n\n{out}\n")
    return run.returncode, out


def verdict(code: int, out: str) -> str:
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "COMPILE_FAIL"
    if code == 0:
        return "SURVIVED"
    if "--- FAIL" in out or "FAIL:" in out or "panic:" in out:
        return "KILLED"
    return f"ERROR(exit {code})"


def main(argv: list[str]) -> int:
    root = Path(argv[0]).resolve()
    probe = Path(argv[1]).resolve()
    logs = Path(argv[2]).resolve()
    logs.mkdir(parents=True, exist_ok=True)
    probe_target = root / PKG / probe.name
    if probe_target.exists():
        print(f"probe file already present in copy: {probe_target}")
        return 2
    failures = 0
    for row in ROWS:
        target = root / row.path
        original = target.read_text()
        found = original.count(row.find)
        if found != row.count:
            print(f"NOT_APPLIED: {row.name}: anchors {found}, want {row.count}")
            failures += 1
            continue
        backup = original
        try:
            target.write_text(original.replace(row.find, row.replace))
            code, out = go_test(root, "", logs / f"{row.name}.committed.log")
            v = verdict(code, out)
            line = f"{row.name} [{row.kind}] committed-suite={v} (predict {row.predict}) exit={code}"
            if row.probe:
                shutil.copy2(probe, probe_target)
                try:
                    pcode, pout = go_test(root, row.probe, logs / f"{row.name}.with-probe.log")
                finally:
                    probe_target.unlink()
                line += f" | with-probe[{row.probe}]={verdict(pcode, pout)} exit={pcode}"
        finally:
            target.write_text(backup)
        mark = "ok" if v == row.predict else "MISMATCH"
        print(f"{mark}: {line} :: {row.note}", flush=True)
        if mark != "ok":
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
