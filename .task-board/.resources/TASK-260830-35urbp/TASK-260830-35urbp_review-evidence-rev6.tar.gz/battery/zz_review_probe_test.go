//go:build !windows

package tmuxserver

// Reviewer probes for CR-TASK-260830-35urbp-6. These are NOT part of the
// candidate; they are copied into an isolated probe copy to (a) show
// which reviewer plants are real (the probe passes on the untouched
// candidate and reddens under the plant) and (b) witness stated bounds.

import (
	"os"
	"path/filepath"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// K01: a 0700 regular file at the leaf refuses on the COMMIT side with
// the containment code (admit direction of the commit-side O_DIRECTORY
// arm). Under R01 (O_DIRECTORY dropped on the commit Openat) the file
// passes mode and ownership and Ensure returns nil.
func TestReviewK01CommitRefusesRegularFile0700(t *testing.T) {
	root := runtimeRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := os.WriteFile(leaf, []byte("x"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(leaf, 0o700); err != nil {
		t.Fatal(err)
	}
	_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
}

// K01b: a FIFO at the leaf refuses on the COMMIT side without blocking.
// Under R01 the O_RDONLY open of a writer-less FIFO blocks.
func TestReviewK01bCommitRefusesFIFOWithoutBlocking(t *testing.T) {
	root := runtimeRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := syscall.Mkfifo(leaf, 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(leaf, 0o700); err != nil {
		t.Fatal(err)
	}
	done := make(chan error, 1)
	go func() {
		_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
		done <- err
	}()
	select {
	case err := <-done:
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	case <-time.After(5 * time.Second):
		t.Fatal("EnsureRuntimeDir BLOCKED for 5s on a FIFO leaf (commit-side O_DIRECTORY must fail fast)")
	}
}

// K01c: the same 0700 regular-file leaf through the FOREGROUND entry
// refuses containment with no probe and no spawn. Under R01 the entry
// admits the leaf, probes, and spawns into <root>/tmux/ax.sock where
// "tmux" is a regular file.
func TestReviewK01cForegroundRefusesRegularFile0700(t *testing.T) {
	root := runtimeRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := os.WriteFile(leaf, []byte("x"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.Chmod(leaf, 0o700); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	spy := &spawnSpy{}
	probed := false
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		probed = true
		return ServerReport{}, nil
	}
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	if probed {
		t.Fatal("server was probed past a regular-file leaf")
	}
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0 past a regular-file leaf", spy.calls)
	}
}

// K07: a fresh decoy member of the Section 4.D vocabulary (local_attach)
// alone does not attest the server, at the helper and through the
// background entry. Under R07 (membership arm admits local_attach) both
// admit.
func TestReviewK07FreshDecoyCapabilityDoesNotAttest(t *testing.T) {
	decoy := RealmAdmission{
		Admitted:      terminalbackend.Admitted{Capabilities: []string{"local_attach"}},
		RawGeneration: fixtureGeneration,
	}
	requireLocalError(t, CheckServerAttested(decoy, fixtureGeneration), "tmux_readiness_not_authorizing", "server attestation")
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	probe := &probeServerSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeServer = probe.probe
	req.Deps.ProbeBroker = func() (BrokerReport, error) {
		live := brokerReport()
		return BrokerReport{Principal: live.Principal, Server: decoy}, nil
	}
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
	probe.requireSilent(t)
}

// K16: a WSL2 background MISS (leaf present, broker absent) returns the
// typed unavailable with zero spawns. Under R16 (a WSL2-only fallback
// spawn on the miss path) the spy records a call.
func TestReviewK16WSL2MissRefusesWithoutFallback(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Platform = scalar.PlatformWSL2
	spy := &spawnSpy{}
	probe := &probeServerSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeServer = probe.probe
	req.Deps.ProbeBroker = func() (BrokerReport, error) {
		return BrokerReport{}, nil
	}
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0 on a WSL2 miss", spy.calls)
	}
	probe.requireSilent(t)
}

// P11: bound B11 witness — a symlinked INTERMEDIATE component of the
// runtime root is followed on both entries (the root's last component
// is opened no-follow; intermediates are resolved by the kernel, the
// same bound as the landed secprim root open). This probe documents the
// bound; it is expected to PASS on the candidate.
func TestReviewP11SymlinkedIntermediateRootIsFollowed(t *testing.T) {
	real := t.TempDir()
	sub := filepath.Join(real, "sub")
	if err := os.Mkdir(sub, 0o755); err != nil {
		t.Fatal(err)
	}
	link := filepath.Join(t.TempDir(), "link")
	if err := os.Symlink(real, link); err != nil {
		t.Fatal(err)
	}
	root := filepath.Join(link, "sub")
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	if err != nil {
		t.Fatalf("B11: symlinked intermediate refused on Ensure: %v", err)
	}
	if _, err := os.Lstat(filepath.Join(sub, RuntimeDirName)); err != nil {
		t.Fatalf("leaf not created under the link target: %v", err)
	}
	if err := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS); err != nil {
		t.Fatalf("B11: symlinked intermediate refused on Verify: %v", err)
	}
	t.Logf("B11 witnessed: Ensure(%q) -> %q (intermediate symlink followed)", root, dir)
}

// P-nested-fifo: a FIFO named like the runtime leaf but reached through
// the BACKGROUND entry refuses fast (row 5 through Acquire). Expected
// to PASS on the candidate.
func TestReviewPBackgroundFIFOLeafRefusesFast(t *testing.T) {
	root := runtimeRoot(t)
	leaf := filepath.Join(root, RuntimeDirName)
	if err := syscall.Mkfifo(leaf, 0o700); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	probe := &probeServerSpy{}
	probed := false
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeServer = probe.probe
	req.Deps.ProbeBroker = func() (BrokerReport, error) {
		probed = true
		return brokerReport(), nil
	}
	done := make(chan error, 1)
	go func() {
		_, err := Acquire(req)
		done <- err
	}()
	select {
	case err := <-done:
		requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime containment")
	case <-time.After(5 * time.Second):
		t.Fatal("background Acquire BLOCKED for 5s on a FIFO leaf")
	}
	if probed || spy.calls != 0 {
		t.Fatalf("probed=%v spawns=%d past a FIFO leaf", probed, spy.calls)
	}
	probe.requireSilent(t)
}
