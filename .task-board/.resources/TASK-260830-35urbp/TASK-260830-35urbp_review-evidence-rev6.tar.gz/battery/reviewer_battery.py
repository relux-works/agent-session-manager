#!/usr/bin/env python3
"""Reviewer battery for CR-TASK-260830-35urbp-6 (claude-opus-5 reviewer run).

Each row: copy the pristine file from the candidate copy into the mutant
copy, apply the plant, verify the anchor count, run the FULL committed
package suite (no -run mask, -count=1 -v), record exit + raw output,
restore the file from the pristine copy, verify byte identity, and hash
the package directory before/after. Rows predicted SURVIVED are rerun
with the reviewer probe file present and -run TestReview (with-probe).
"""
import hashlib, os, shutil, subprocess, sys
from pathlib import Path

R = Path(os.environ["R"])
CAND = R / "candidate"
MUT = R / "mutant-copy"
PKG = "internal/tmuxserver"
PROBE = R / "battery" / "zz_review_probe_test.go"

ROWS = [
  dict(name="R01-commit-odirectory-drop", kind="narrowing(flag)", path=f"{PKG}/runtime_unix.go",
       find="\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
       replace="\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)\n",
       count=1, expect="KILLED-by-reroute", probe="TestReviewK01"),
  dict(name="R02-broker-admitted-without-generation", kind="narrowing", path=f"{PKG}/readiness.go",
       find="\treturn CheckServerAttested(report.Server, wantGeneration)\n",
       replace='\tif report.Server.RawGeneration == "" && report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
       count=1, expect="KILLED", probe=None),
  dict(name="R03-broker-decoy-only-admits", kind="narrowing", path=f"{PKG}/readiness.go",
       find="\treturn CheckServerAttested(report.Server, wantGeneration)\n",
       replace='\tif report.Server.Admitted.Has("headless_creation") && !report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
       count=1, expect="KILLED", probe=None),
  dict(name="R04-unavailable-code-swap-same-exit", kind="narrowing(token)", path=f"{PKG}/acquire.go",
       find='\tfailure, err := axerror.NewRealmEvidenceUnavailable(axerror.Version130,\n\t\t"no authenticated broker or attested tmux server",\n\t\taxerror.NoIDs(), details, cause)\n\tif err != nil {\n',
       replace='\tdetailMap, derr := details.Details()\n\tif derr != nil {\n\t\treturn &Error{Code: CodeInvalidArguments, Detail: "realm details"}\n\t}\n\tfailure, err := axerror.New(axerror.Spec{Version: axerror.Version130, Code: "terminal_backend_capability_unproven",\n\t\tMessage: "no authenticated broker or attested tmux server",\n\t\tIDs: axerror.NoIDs(), Details: detailMap, Cause: cause})\n\tif err != nil {\n',
       count=1, expect="KILLED", probe=None),
  dict(name="R05-detail-swap-generation", kind="narrowing(detail)", path=f"{PKG}/acquire.go",
       find="\t\tTmuxServerGeneration: req.Generation,\n",
       replace="\t\tTmuxServerGeneration: req.BrokerState,\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R06-exec-fallback-B9-witness", kind="additive(bound)", path=f"{PKG}/acquire.go",
       find='import (\n\t"errors"\n\n\t"github.com/relux-works/agent-session-manager/internal/axerror"\n',
       replace='import (\n\t"errors"\n\t"os/exec"\n\n\t"github.com/relux-works/agent-session-manager/internal/axerror"\n',
       count=1, expect="SURVIVED(bound B9)", probe=None,
       extra=[("\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
               "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\t_ = exec.Command(\"tmux\", \"-S\", socket, \"new-session\", \"-d\").Run()\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n", 1)]),
  dict(name="R07-membership-fresh-decoy-local-attach", kind="narrowing", path=f"{PKG}/readiness.go",
       find="\tif !admission.Admitted.Has(realmCapability) {\n",
       replace='\tif !admission.Admitted.Has(realmCapability) && !admission.Admitted.Has("local_attach") {\n',
       count=1, expect="SURVIVED", probe="TestReviewK07"),
  dict(name="R08-verify-odirectory-drop-replay", kind="replay(producer N-containment-odirectory-verify, full suite)", path=f"{PKG}/runtime_unix.go",
       find="\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
       replace="\tleafFd, err := unix.Openat(int(rootHandle.Fd()), name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R11-background-probe-before-verify", kind="order", path=f"{PKG}/acquire.go",
       find="\tverr := VerifyRuntimeDir(req.Root, RuntimeDirName, req.Platform)\n\tif runtimeAbsent(verr) {\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n\tif verr != nil {\n\t\treturn Outcome{}, verr\n\t}\n\tstatus, err := req.Deps.ProbeBroker()\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n",
       replace="\tstatus, err := req.Deps.ProbeBroker()\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n\tverr := VerifyRuntimeDir(req.Root, RuntimeDirName, req.Platform)\n\tif runtimeAbsent(verr) {\n\t\treturn Outcome{}, backgroundUnavailable(req, verr)\n\t}\n\tif verr != nil {\n\t\treturn Outcome{}, verr\n\t}\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R12-foreground-probe-before-ensure", kind="order", path=f"{PKG}/acquire.go",
       find="\tensured, err := EnsureRuntimeDir(req.Root, RuntimeDirName, req.Platform, nil)\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n\treport, err := req.Deps.ProbeServer(socket)\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n",
       replace="\treport, err := req.Deps.ProbeServer(socket)\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n\tensured, err := EnsureRuntimeDir(req.Root, RuntimeDirName, req.Platform, nil)\n\tif err != nil {\n\t\treturn Outcome{}, err\n\t}\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R15-linux-only-fallback-spawn", kind="additive(platform-narrowed)", path=f"{PKG}/acquire.go",
       find="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformLinux && req.Deps.Spawn != nil {\n\t\t\t\t_ = req.Deps.Spawn(socket, nil)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R16-wsl2-only-fallback-spawn", kind="additive(platform-narrowed)", path=f"{PKG}/acquire.go",
       find="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       replace="\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformWSL2 && req.Deps.Spawn != nil {\n\t\t\t\t_ = req.Deps.Spawn(socket, nil)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
       count=1, expect="SURVIVED", probe="TestReviewK16"),
  dict(name="R17-dispatch-wsl2-background-to-foreground", kind="narrowing", path=f"{PKG}/acquire.go",
       find="\tif req.Caller == CallerBackground {\n\t\treturn acquireBackground(req, socket)\n\t}\n",
       replace="\tif req.Caller == CallerBackground && req.Platform != scalar.PlatformWSL2 {\n\t\treturn acquireBackground(req, socket)\n\t}\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R22-collision-skipped-for-background", kind="narrowing(caller axis)", path=f"{PKG}/acquire.go",
       find="\tsocket, err := ResolveSocket(dir, req.SocketOverride, req.Ambient)\n",
       replace="\tambient := req.Ambient\n\tif req.Caller == CallerBackground {\n\t\tambient = Ambient{}\n\t}\n\tsocket, err := ResolveSocket(dir, req.SocketOverride, ambient)\n",
       count=1, expect="KILLED", probe=None),
  dict(name="R23-override-skipped-for-background", kind="narrowing(caller axis)", path=f"{PKG}/acquire.go",
       find="\tsocket, err := ResolveSocket(dir, req.SocketOverride, req.Ambient)\n",
       replace="\toverride := req.SocketOverride\n\tif req.Caller == CallerBackground {\n\t\toverride = \"\"\n\t}\n\tsocket, err := ResolveSocket(dir, override, req.Ambient)\n",
       count=1, expect="KILLED", probe=None),
  dict(name="C-reviewer-control", kind="control", path=f"{PKG}/acquire.go",
       find="// Acquire resolves the dedicated server socket from the runtime\n",
       replace="// Acquire resolves the dedicated server socket from the runtime (reviewer control: comment-only)\n",
       count=1, expect="SURVIVED", probe=None),
]

def dir_hash(d: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(d.rglob("*")):
        if p.is_file():
            h.update(str(p.relative_to(d)).encode()); h.update(p.read_bytes())
    return h.hexdigest()[:16]

def run(cmd, cwd, log: Path):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=900)
    out = r.stdout + r.stderr
    log.write_text(f"exit: {r.returncode}\nrun: {' '.join(cmd)}\ncwd: {cwd}\n\n{out}")
    return r.returncode, out

def verdict(rc, out):
    if "build failed" in out or "\n# " in out or out.startswith("# ") or "setup failed" in out:
        return "COMPILE_FAIL"
    if rc == 0:
        return "SURVIVED"
    if "--- FAIL" in out:
        return "KILLED"
    return "ERROR"

def main():
    passno = sys.argv[1] if len(sys.argv) > 1 else "1"
    with_probe = "--with-probe" in sys.argv
    outdir = R / "battery" / ("pass" + passno + ("-probe" if with_probe else ""))
    outdir.mkdir(parents=True, exist_ok=True)
    pkgdir = MUT / PKG
    summary = []
    for row in ROWS:
        if with_probe and not row.get("probe"):
            continue
        target = MUT / row["path"]
        pristine = (CAND / row["path"]).read_bytes()
        before = dir_hash(pkgdir)
        src = pristine.decode()
        edits = [(row["find"], row["replace"], row["count"])] + row.get("extra", [])
        applied = True
        for find, rep, cnt in edits:
            n = src.count(find)
            if n != cnt:
                summary.append(f"NOT_APPLIED: {row['name']}: anchor count {n}, want {cnt}")
                applied = False
                break
            src = src.replace(find, rep)
        if not applied:
            continue
        target.write_text(src)
        try:
            if with_probe:
                shutil.copy(PROBE, pkgdir / PROBE.name)
                cmd = ["go", "test", f"./{PKG}/", "-run", row["probe"], "-count=1", "-v"]
            else:
                cmd = ["go", "test", f"./{PKG}/", "-count=1", "-v"]
            rc, out = run(cmd, MUT, outdir / (row["name"] + ".log"))
        finally:
            target.write_bytes(pristine)
            if with_probe and (pkgdir / PROBE.name).exists():
                (pkgdir / PROBE.name).unlink()
        after = dir_hash(pkgdir)
        v = verdict(rc, out)
        kills = sorted(set(l.strip().split()[2] for l in out.splitlines() if l.strip().startswith("--- FAIL:")))
        restored = target.read_bytes() == pristine and before == after
        summary.append(f"{row['name']}: {v} (exit {rc}; expect {row['expect']}) kind={row['kind']} killers={','.join(kills)[:300]} restored={restored} hash={before}/{after}")
    text = "\n".join(summary) + "\n"
    (outdir / "SUMMARY.txt").write_text(text)
    print(text)

if __name__ == "__main__":
    main()
