//go:build !windows

package tmuxserver

import (
	"errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/scalar"
)

// Reviewer probes for CR rev3 (RUN-260921-2369f7). Each probe reports the
// production behaviour it observes; a probe named *Baseline documents
// current behaviour, a probe named *Hole documents a divergence from the
// pinned spec text or from a claim in TRACEABILITY/README/doc.go.

// P01: spec §3.2 (SPEC.v0.7.0.md:806-807) mandates
// `tmux -S <runtime>/tmux/ax.sock`; the package derives
// `<root>/ax-tmux/ax-tmux.sock`.
func TestReviewProbeP01SocketPathVersusSpecHole(t *testing.T) {
	runtime := "/runtime"
	got := SocketPath(filepath.Join(runtime, RuntimeDirName))
	want := filepath.Join(runtime, "tmux", "ax.sock")
	t.Logf("derived socket = %q; spec §3.2 socket = %q", got, want)
	if got == want {
		t.Fatalf("unexpected: derived socket matches the spec path")
	}
}

// P02: background caller, runtime directory ABSENT (the post-reboot cold
// state for a per-user temporary runtime root). §4.2: "if neither exists
// it MUST return capability_unavailable with typed realm/readiness
// details". Observe what Acquire returns.
func TestReviewProbeP02BackgroundAbsentDirReturnCodeHole(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Platform = scalar.PlatformMacOS
	probed := false
	req.Deps.ProbeBroker = func() (BrokerReport, error) { probed = true; return BrokerReport{}, nil }
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	var failure *axerror.Error
	if errors.As(err, &failure) && string(failure.Code()) == "capability_unavailable" {
		t.Logf("absent runtime dir -> capability_unavailable (spec-conformant)")
		return
	}
	var local *Error
	if errors.As(err, &local) {
		t.Logf("HOLE: absent runtime dir on the background path -> %s at %s (not capability_unavailable); broker probed=%v spawns=%d", local.Code, local.Detail, probed, spy.calls)
		return
	}
	t.Fatalf("unexpected err %T %v", err, err)
}

// P03: the verify side reports absence and a missing root with the same
// detail as a containment violation; the commit side distinguishes a
// missing root ("runtime root"). Absence vs failure-to-read.
func TestReviewProbeP03AbsenceConflatedWithContainmentBaseline(t *testing.T) {
	root := stateRoot(t)
	absentLeaf := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	missingRootVerify := VerifyRuntimeDir(filepath.Join(root, "nope"), RuntimeDirName, scalar.PlatformMacOS)
	_, missingRootEnsure := EnsureRuntimeDir(filepath.Join(root, "nope"), RuntimeDirName, scalar.PlatformMacOS, nil)
	symlinkLeaf := func() error {
		r := stateRoot(t)
		if err := os.Symlink(t.TempDir(), filepath.Join(r, RuntimeDirName)); err != nil {
			t.Fatal(err)
		}
		return VerifyRuntimeDir(r, RuntimeDirName, scalar.PlatformMacOS)
	}()
	t.Logf("verify absent leaf      = %v", absentLeaf)
	t.Logf("verify symlink leaf     = %v", symlinkLeaf)
	t.Logf("verify missing root     = %v", missingRootVerify)
	t.Logf("ensure missing root     = %v", missingRootEnsure)
	if absentLeaf.Error() == symlinkLeaf.Error() {
		t.Logf("HOLE (class): absence and a symlink escape are the same refusal on the verify side")
	}
	if missingRootVerify.Error() != missingRootEnsure.Error() {
		t.Logf("HOLE (class): missing root maps to different codes on Ensure vs Verify")
	}
}

// P04: the root's own custody (mode, ownership) is not verified: a
// world-writable root admits the leaf on both entries.
func TestReviewProbeP04RootCustodyUnverifiedHole(t *testing.T) {
	root := stateRoot(t)
	if err := os.Chmod(root, 0o777); err != nil {
		t.Fatal(err)
	}
	dir, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	t.Logf("ensure under 0777 root: dir=%q err=%v", dir, err)
	verr := VerifyRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS)
	t.Logf("verify under 0777 root: err=%v", verr)
	if err == nil && verr == nil {
		t.Logf("HOLE (bound): a world-writable root is admitted; §3.2 'parent, or ancestor whose ... permissions are unsafe' is not gated here")
	}
}

// P05: the Name input admits any single segment, so a pre-existing
// same-user 0700 directory that AX did not create (e.g. the operator's
// tmux socket directory) is admitted as the runtime directory.
func TestReviewProbeP05NotAXCreatedDirectoryAdmittedBaseline(t *testing.T) {
	root := stateRoot(t)
	foreign := filepath.Join(root, "tmux-501")
	if err := os.Mkdir(foreign, 0o700); err != nil {
		t.Fatal(err)
	}
	dir, err := EnsureRuntimeDir(root, "tmux-501", scalar.PlatformMacOS, nil)
	t.Logf("ensure over a pre-existing non-AX dir: dir=%q err=%v socket=%q", dir, err, SocketPath(dir))
	if err == nil {
		t.Logf("BOUND: 'AX-created' (§3.2) is not distinguishable after the fact; any custody-passing directory is admitted")
	}
}

// P06: the TMUX environment variable really carries `socket,pid,index`;
// a value naming the derived socket in that encoding does not collide.
func TestReviewProbeP06TMUXEnvEncodingCollisionHole(t *testing.T) {
	root := stateRoot(t)
	dir := runtimeDir(t, root)
	derived := SocketPath(dir)
	req := validRequest(t, root)
	req.Ambient = Ambient{TMUXEnv: derived + ",12345,0"}
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	out, err := Acquire(req)
	t.Logf("TMUX=%q -> via=%q err=%v spawns=%d", req.Ambient.TMUXEnv, out.Via, err, spy.calls)
	if err == nil && spy.calls == 1 {
		t.Logf("HOLE (claim): row 23 'colliding with the derived socket refuses on every member' does not hold for the TMUX member in tmux's real encoding")
	}
}

// P07: a running server with NO admission rows at all (the state of a
// freshly spawned, not-yet-attested server) at the foreground entry.
func TestReviewProbeP07RunningEmptyAdmissionBaseline(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		return ServerReport{Running: true, Admission: RealmAdmission{}}, nil
	}
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_readiness_not_authorizing", "server attestation")
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0 over a running unattested server", spy.calls)
	}
}

// P08: a running server with an admission whose RawGeneration is empty
// and whose rows are absent.
func TestReviewProbeP08RunningEmptyGenerationBaseline(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		return ServerReport{Running: true, Admission: RealmAdmission{Admitted: realmAdmitted()}}, nil
	}
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_readiness_not_authorizing", "server generation")
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
}

// P09: ObserveAmbient claims (socket.go:28-31) env names are validated by
// the landed environment-name grammar; observe whether any validation
// happens (a lookup that answers every name).
func TestReviewProbeP09ObserveAmbientNoValidationBaseline(t *testing.T) {
	calls := []string{}
	observed, err := ObserveAmbient(func(name string) (string, bool) {
		calls = append(calls, name)
		return "v:" + name, true
	}, "", "", "")
	t.Logf("lookup names = %q observed=%+v err=%v", calls, observed, err)
}

// P10: whitespace-only override is refused (not trimmed into "no override").
func TestReviewProbeP10WhitespaceOverrideBaseline(t *testing.T) {
	root := stateRoot(t)
	req := validRequest(t, root)
	req.SocketOverride = "  "
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_ambient_server_reuse", "socket override")
}

// P11: background path with the runtime dir present but the ROOT 0777:
// the broker path admits.
func TestReviewProbeP11BackgroundRootCustodyBaseline(t *testing.T) {
	root := stateRoot(t)
	runtimeDir(t, root)
	if err := os.Chmod(root, 0o777); err != nil {
		t.Fatal(err)
	}
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	out, err := Acquire(req)
	t.Logf("background under 0777 root: via=%q err=%v", out.Via, err)
}

// P12: a read-only root refuses at the mkdirat arm with "runtime commit"
// (baseline for reviewer row R04).
func TestReviewProbeP12ReadOnlyRootRefusesCommitBaseline(t *testing.T) {
	root := stateRoot(t)
	if err := os.Chmod(root, 0o500); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(root, 0o700) })
	_, err := EnsureRuntimeDir(root, RuntimeDirName, scalar.PlatformMacOS, nil)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime commit")
}
