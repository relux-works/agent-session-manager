#!/usr/bin/env python3
"""Reviewer battery for CR-TASK-260830-35urbp-3 (RUN-260921-2369f7).

Each row: verify the anchor count, plant the mutant in the mutant copy,
run the COMMITTED suite as shipped (full package, no -run mask), record
exit + raw output, restore the file from a byte copy. Rows predicted
SURVIVED are additionally run with the reviewer probe file present and
the named killer selected. Verdict: KILLED iff exit != 0 with a FAIL
line; SURVIVED iff exit 0; ERROR otherwise. NOT_APPLIED is an error,
never a pass.
"""
import os, shutil, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MUTANT = HERE / "mutant-copy"
PROBE = HERE / "probe-copy" / "internal" / "tmuxserver" / "zz_review_probe_test.go"
PKG = "internal/tmuxserver"

ROWS = [
    # name, kind, file, find, replace, predicted, killer(with probe), note
    ("R01-running-empty-admission", "narrowing", "acquire.go",
     "\tif report.Running {\n",
     "\tif report.Running && len(report.Admission.Admitted.Capabilities) > 0 {\n",
     "SURVIVED", "TestReviewProbeP07RunningEmptyAdmissionBaseline",
     "a running server with zero admission rows (freshly spawned, unattested) is treated as absent and re-spawned; every committed Running=true row carries at least one capability (decoy or realm)"),
    ("R02-running-empty-generation", "narrowing", "acquire.go",
     "\tif report.Running {\n",
     "\tif report.Running && report.Admission.RawGeneration != \"\" {\n",
     "SURVIVED", "TestReviewProbeP08RunningEmptyGenerationBaseline",
     "a running server whose admission carries no raw generation is treated as absent and re-spawned; every committed Running=true row carries a non-empty RawGeneration"),
    ("R03-guard-resolve-failopen", "error-arm", "runtime.go",
     "\tjoined, err := guard.Resolve(name)\n\tif err != nil {\n\t\treturn \"\", &Error{Code: CodeUnsafeRuntimeDir, Detail: \"runtime containment\"}\n\t}\n",
     "\tjoined, err := guard.Resolve(name)\n\tif err != nil {\n\t\tjoined = root + \"/\" + name\n\t}\n",
     "SURVIVED", "",
     "the guard.Resolve refusal arm flipped to fail-open; no committed input reaches it (name grammar refuses first) — unmeasured/unreachable arm"),
    ("R04-mkdirat-eacces-as-exist", "narrowing", "runtime_unix.go",
     "\t\tif !errors.Is(err, unix.EEXIST) {\n",
     "\t\tif !errors.Is(err, unix.EEXIST) && !errors.Is(err, unix.EACCES) {\n",
     "SURVIVED", "TestReviewProbeP12ReadOnlyRootRefusesCommitBaseline",
     "a permission failure at mkdirat is treated as EEXIST and the path continues to the leaf open; refusal reroutes from 'runtime commit' to 'runtime containment' (still fail-closed) — no committed test stages a read-only root"),
    ("R07-override-two-spaces", "narrowing", "socket.go",
     "\tif override != \"\" {\n",
     "\tif override != \"\" && override != \"  \" {\n",
     "SURVIVED", "TestReviewProbeP10WhitespaceOverrideBaseline",
     "admits exactly a two-space override (ignored, derived socket still used); committed override rows use the five hostile literals only"),
    ("R15-argv-detached-flag", "positive-pin", "argv.go",
     "\t\t\"-d\",\n",
     "",
     "KILLED", "",
     "drops -d from the spawn vector; the exact-argv test pins it"),
    ("R17-realm-capability-swap", "constant-swap", "acquire.go",
     "const realmCapability = \"credential_capable_execution_realm\"\n",
     "const realmCapability = \"headless_creation\"\n",
     "KILLED", "",
     "rejection pattern (a): swapping the production constant must redden literal assertions"),
    ("R18-via-literal-swap", "constant-swap", "acquire.go",
     "\tViaAttached = \"attached-running\"\n",
     "\tViaAttached = \"attached\"\n",
     "KILLED", "",
     "outcome literal pinned by tests"),
    ("R21-broker-uid-zero", "narrowing", "readiness.go",
     "\tif report.Principal.UID != currentUID {\n",
     "\tif report.Principal.UID != currentUID && report.Principal.UID != 0 {\n",
     "KILLED", "",
     "admits a UID-0 principal as same-user; the helper-level 'no broker' row pins the 'broker authentication' detail (through Acquire the detail is swallowed into capability_unavailable)"),
    ("R26-background-absent-ensures", "additive", "acquire.go",
     "\tif verr := VerifyRuntimeDir(req.Root, req.Name, req.Platform); verr != nil {\n\t\treturn Outcome{}, verr\n\t}\n",
     "\tif verr := VerifyRuntimeDir(req.Root, req.Name, req.Platform); verr != nil {\n\t\tif _, eerr := EnsureRuntimeDir(req.Root, req.Name, req.Platform, nil); eerr != nil {\n\t\t\treturn Outcome{}, verr\n\t\t}\n\t}\n",
     "KILLED", "",
     "background creates the directory when verify fails (durable write on the authorizing path); TestAcquireBackgroundVerifiesWithoutCreating asserts no directory"),
    ("C-reviewer-control", "control", "acquire.go",
     "// Outcome is the one acquisition result.\n",
     "// Outcome is the one acquisition result (reviewer control: comment-only).\n",
     "SURVIVED", "",
     "must survive; proves the battery observes outcomes"),
]

def run_go(cwd, runmask, log):
    cmd = ["go", "test", f"./{PKG}/", "-count=1"]
    if runmask:
        cmd += ["-run", runmask]
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=600)
    out = (r.stdout + r.stderr).strip()
    log.write_text(f"exit: {r.returncode}\ncmd: {' '.join(cmd)}\n\n{out}\n")
    if "build failed" in out or out.startswith("# ") or "\n# " in out:
        return "ERROR-build", r.returncode
    if r.returncode == 0:
        return "SURVIVED", 0
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED", r.returncode
    return "ERROR-nokill", r.returncode

def main(pass_dir):
    pass_dir.mkdir(parents=True, exist_ok=True)
    probe_dst = MUTANT / PKG / PROBE.name
    lines = []
    for name, kind, fname, find, replace, predicted, killer, note in ROWS:
        target = MUTANT / PKG / fname
        original = target.read_bytes()
        text = original.decode()
        n = text.count(find)
        if n != 1:
            lines.append(f"ERROR: {name}: NOT_APPLIED anchors={n}")
            continue
        try:
            target.write_text(text.replace(find, replace))
            committed, exit_c = run_go(MUTANT, "", pass_dir / f"{name}.committed.log")
            with_probe = "-"
            exit_p = "-"
            if killer:
                shutil.copy2(PROBE, probe_dst)
                try:
                    with_probe, exit_p = run_go(MUTANT, killer, pass_dir / f"{name}.with-probe.log")
                finally:
                    probe_dst.unlink(missing_ok=True)
        finally:
            target.write_bytes(original)
            assert target.read_bytes() == original
        mark = "ok" if committed == predicted else "MISMATCH"
        lines.append(f"{mark}: {name} [{kind}] committed={committed}(exit {exit_c}) with-probe={with_probe}(exit {exit_p}) predicted={predicted} :: {note}")
    out = "\n".join(lines) + "\n"
    (pass_dir / "verdicts.log").write_text(out)
    print(out)
    return 0

if __name__ == "__main__":
    sys.exit(main(Path(sys.argv[1])))
