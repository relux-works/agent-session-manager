#!/usr/bin/env python3
"""Reviewer battery for TASK-260830-35urbp rev5 (RUN-260921-60d15f).

Runs each plant against the FULL committed package suite (no -run mask) in
an isolated copy of the candidate tree, restores the mutated file from a
byte copy, verifies the restoration, and records one raw log per row per
pass with the subprocess exit. Optionally (--with-probe) runs the row
again with the reviewer probe file present and the named killer selected.
"""
import hashlib, os, shutil, subprocess, sys, time
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(os.environ["BATTERY_TREE"]).resolve()
PKG = "internal/tmuxserver"
PROBE_SRC = Path(os.environ.get("BATTERY_PROBE", "")) if os.environ.get("BATTERY_PROBE") else None

@dataclass(frozen=True)
class Row:
    name: str
    path: str
    find: str
    replace: str
    count: int
    kind: str      # narrowing | additive | control | replay
    predict: str   # KILLED | SURVIVED
    probe: str     # killer test name in the probe file, or ""
    note: str

ROWS = [
    Row("R01-absence-admits-ownership", f"{PKG}/acquire.go",
        '\treturn local.Code == CodeUnsafeRuntimeDir && local.Detail == "runtime absent"\n',
        '\treturn local.Code == CodeUnsafeRuntimeDir && (local.Detail == "runtime absent" || local.Detail == "runtime ownership")\n',
        1, "narrowing", "SURVIVED", "TestReviewK01BackgroundForeignOwnershipKeepsCustodyCode",
        "runtimeAbsent admits exactly the ownership refusal: a foreign-owned leaf on the background path returns capability_unavailable instead of tmux_unsafe_runtime_dir at runtime ownership. No committed background Acquire test stages foreign ownership."),
    Row("R02-absence-admits-containment", f"{PKG}/acquire.go",
        '\treturn local.Code == CodeUnsafeRuntimeDir && local.Detail == "runtime absent"\n',
        '\treturn local.Code == CodeUnsafeRuntimeDir && (local.Detail == "runtime absent" || local.Detail == "runtime containment")\n',
        1, "narrowing", "KILLED", "",
        "runtimeAbsent admits exactly the containment refusal (non-directory leaf, symlink leaf, handle mismatch) on the background path."),
    Row("R03-absence-admits-mode-rev4R05", f"{PKG}/acquire.go",
        '\treturn local.Code == CodeUnsafeRuntimeDir && local.Detail == "runtime absent"\n',
        '\treturn local.Code == CodeUnsafeRuntimeDir && (local.Detail == "runtime absent" || local.Detail == "runtime mode")\n',
        1, "replay", "KILLED", "",
        "rev4 R05 replay: the mode member; must now be killed by the top-level oracle in TestAcquireBackgroundStagesVerifyCustodyRefusal."),
    Row("R04-name-literal-lexical-site", f"{PKG}/acquire.go",
        '\tdir, err := lexicalRuntimePath(req.Root, RuntimeDirName, req.Platform)\n',
        '\tdir, err := lexicalRuntimePath(req.Root, "ax-tmux", req.Platform)\n',
        1, "narrowing", "KILLED", "",
        "P2-B closure: the Acquire lexical step names the rev3 leaf; the outcome socket becomes <root>/ax-tmux/ax.sock."),
    Row("R05-name-literal-ensure-site", f"{PKG}/acquire.go",
        '\tensured, err := EnsureRuntimeDir(req.Root, RuntimeDirName, req.Platform, nil)\n',
        '\tensured, err := EnsureRuntimeDir(req.Root, "ax-tmux", req.Platform, nil)\n',
        1, "narrowing", "KILLED", "",
        "P2-B closure: the foreground ensure site creates a different leaf than the socket names."),
    Row("R06-name-literal-verify-site", f"{PKG}/acquire.go",
        '\tverr := VerifyRuntimeDir(req.Root, RuntimeDirName, req.Platform)\n',
        '\tverr := VerifyRuntimeDir(req.Root, "ax-tmux", req.Platform)\n',
        1, "narrowing", "KILLED", "",
        "P2-B closure: the background verify site verifies a different leaf than the socket names."),
    Row("R07-absence-only-macos-rev4R14", f"{PKG}/acquire.go",
        '\tif runtimeAbsent(verr) {\n',
        '\tif runtimeAbsent(verr) && req.Platform == scalar.PlatformMacOS {\n',
        1, "replay", "KILLED", "",
        "rev4 R14 replay: the absence remap limited to macOS; must be killed by the linux/wsl2 subtests."),
    Row("R08-spy-guarded-plant-top", f"{PKG}/acquire.go",
        '\tif req.Deps.ProbeBroker == nil {\n\t\treturn Outcome{}, &Error{Code: CodeInvalidArguments, Detail: "dependencies"}\n\t}\n\tverr := VerifyRuntimeDir(req.Root, RuntimeDirName, req.Platform)\n',
        '\tif req.Deps.Spawn != nil {\n\t\t_ = req.Deps.Spawn(socket, nil)\n\t}\n\tif req.Deps.ProbeBroker == nil {\n\t\treturn Outcome{}, &Error{Code: CodeInvalidArguments, Detail: "dependencies"}\n\t}\n\tverr := VerifyRuntimeDir(req.Root, RuntimeDirName, req.Platform)\n',
        1, "additive", "KILLED", "",
        "P3-B closure census by effect: a guarded direct-spawn plant at the top of the background path must redden every background-path Acquire test (12 claimed)."),
    Row("R09-broker-empty-admission-admits", f"{PKG}/readiness.go",
        '\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        '\tif report.Server.RawGeneration == "" && !report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        1, "narrowing", "SURVIVED", "TestReviewK02BrokerPathRefusesZeroAdmissionServer",
        "Broker-path wiring admits exactly the zero-admission server (no rows, no generation: the realistic nothing-reconciled state) past the attested-server conjunct; every other server report still reaches CheckServerAttested."),
    Row("R10-broker-empty-generation-admits", f"{PKG}/readiness.go",
        '\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        '\tif report.Server.RawGeneration == "" && report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        1, "narrowing", "SURVIVED", "TestReviewK03BrokerPathRefusesGenerationlessAdmittedServer",
        "Broker-path wiring admits exactly the admitted-but-generationless server (rows present, RawGeneration empty) with a bound wanted generation."),
    Row("R11-details-drop-generation", f"{PKG}/acquire.go",
        '\tif req.Generation == "" || req.BrokerState == "" || req.Remediation == "" {\n',
        '\tif req.BrokerState == "" || req.Remediation == "" {\n',
        1, "narrowing", "KILLED", "",
        "Typed-details gate admits exactly a generation-less request (sibling of the producer's N-details-remediation)."),
    Row("R12-details-drop-brokerstate", f"{PKG}/acquire.go",
        '\tif req.Generation == "" || req.BrokerState == "" || req.Remediation == "" {\n',
        '\tif req.Generation == "" || req.Remediation == "" {\n',
        1, "narrowing", "KILLED", "",
        "Typed-details gate admits exactly a broker-state-less request."),
    Row("R13-verify-ownership-wiring-drop", f"{PKG}/runtime_unix.go",
        '\tif info.Mode().Perm() != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: "runtime mode"}\n\t}\n\treturn verifyOwnership(info)\n}\n',
        '\tif info.Mode().Perm() != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: "runtime mode"}\n\t}\n\t_ = verifyOwnership(info)\n\treturn nil\n}\n',
        1, "narrowing", "KILLED", "",
        "Verify side: the ownership gate is consulted but its verdict is dropped (the commit side still refuses)."),
    Row("R14-argv-drop-detached", f"{PKG}/argv.go",
        '\t\t"new-session",\n\t\t"-d",\n',
        '\t\t"new-session",\n',
        1, "narrowing", "KILLED", "",
        "Spawn argv loses -d: the spawned server would try to attach the caller terminal (and nest-refuse under an operator TMUX)."),
    Row("R15-argv-tail-attach", f"{PKG}/argv.go",
        '\t\t"ax", "pane", session.String(),\n',
        '\t\t"ax", "attach", session.String(),\n',
        1, "narrowing", "KILLED", "",
        "The stable pane entrypoint tail is replaced; SPEC 1405-1409 requires ax pane <logical-session-id>."),
    Row("R16-verify-mode-group-bits-only", f"{PKG}/runtime_unix.go",
        '\tif info.Mode().Perm() != 0o700 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: "runtime mode"}\n\t}\n\treturn verifyOwnership(info)\n',
        '\tif info.Mode().Perm()&0o077 != 0 {\n\t\treturn &Error{Code: CodeUnsafeRuntimeDir, Detail: "runtime mode"}\n\t}\n\treturn verifyOwnership(info)\n',
        1, "replay", "KILLED", "",
        "rev2 P3-B replay on the verify side: exact 0700 weakened to no-group/world bits (admits 0600/0500)."),
    Row("R17-commit-nofollow-drop", f"{PKG}/runtime_unix.go",
        '\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n',
        '\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n',
        1, "replay", "KILLED", "",
        "Commit side follows a symlink leaf (rev4 R09 replay)."),
    Row("R18-fallback-via-foreground-guarded", f"{PKG}/acquire.go",
        '\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n',
        '\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Deps.ProbeServer != nil && req.Deps.Spawn != nil {\n\t\t\t\treturn acquireForeground(req, socket)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n',
        1, "additive", "SURVIVED", "TestReviewK04BackgroundMissWithForegroundDepsArmedNeverFallsBack",
        "Additive fallback into acquireForeground on the background miss path, guarded on the foreground probe dependency: no committed background test arms ProbeServer, so the spy census cannot see it (the shared Dependencies struct makes an armed ProbeServer on a background call realistic)."),
    Row("R19-broker-decoy-admission-admits", f"{PKG}/readiness.go",
        '\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        '\tif report.Server.Admitted.Has("headless_creation") && !report.Server.Admitted.Has(realmCapability) {\n\t\treturn nil\n\t}\n\treturn CheckServerAttested(report.Server, wantGeneration)\n',
        1, "narrowing", "SURVIVED", "TestReviewK05BrokerPathRefusesDecoyAdmission",
        "Broker-path wiring admits exactly a decoy-only admission (headless_creation without the realm row); the foreground entry pins this member, the broker entry does not."),
    Row("C-reviewer-control", f"{PKG}/readiness.go",
        '// RealmAdmission is the landed admission verdict over the exact tmux\n',
        '// RealmAdmission is the landed admission verdict over the exact tmux (reviewer control: comment only)\n',
        1, "control", "SURVIVED", "",
        "Comment-only edit; must survive so the battery is proven to observe outcomes."),
]

def sha_dir(path: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(path.iterdir()):
        if f.is_file():
            h.update(f.name.encode()); h.update(f.read_bytes())
    return h.hexdigest()[:16]

def run_go(env, log: Path, run_mask: str | None):
    cmd = ["go", "test", f"./{PKG}/", "-count=1", "-v"]
    if run_mask:
        cmd += ["-run", run_mask]
    t0 = time.time()
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, env=env, timeout=900)
    out = p.stdout + p.stderr
    log.write_text(f"exit: {p.returncode}\ncmd: {' '.join(cmd)}\nduration: {time.time()-t0:.1f}s\n\n{out}")
    return p.returncode, out

def verdict(rc: int, out: str) -> str:
    if "build failed" in out or "\n# " in out or out.startswith("# ") or "[setup failed]" in out:
        return "COMPILE_FAIL"
    if rc == 0:
        return "SURVIVED"
    if "--- FAIL" in out or "FAIL:" in out or "panic:" in out:
        return "KILLED"
    return "ERROR"

def failing_tests(out: str):
    return sorted({l.split()[2] for l in out.splitlines() if l.strip().startswith("--- FAIL:")})

def main(argv):
    log_dir = Path(argv[argv.index("--log-dir") + 1]); log_dir.mkdir(parents=True, exist_ok=True)
    with_probe = "--with-probe" in argv
    names = [a for a in argv if not a.startswith("--") and a != str(log_dir)]
    rows = [r for r in ROWS if not names or r.name in names]
    env = dict(os.environ); env["PYTHONDONTWRITEBYTECODE"] = "1"
    pkg_dir = ROOT / PKG
    before = sha_dir(pkg_dir)
    print(f"tree={ROOT} pkg-hash-before={before}", flush=True)
    summary = []
    for row in rows:
        target = ROOT / row.path
        original = target.read_bytes()
        text = original.decode()
        found = text.count(row.find)
        if found != row.count:
            line = f"NOT_APPLIED: {row.name}: anchors {found} want {row.count}"
            print(line, flush=True); summary.append(line); continue
        backup = original
        try:
            target.write_text(text.replace(row.find, row.replace))
            rc, out = run_go(env, log_dir / f"{row.name}.log", None)
            v = verdict(rc, out)
            fails = failing_tests(out)
            probe_v = ""
            if with_probe and row.probe and PROBE_SRC:
                dst = pkg_dir / "zz_review_probe_test.go"
                shutil.copy2(PROBE_SRC, dst)
                try:
                    prc, pout = run_go(env, log_dir / f"{row.name}.with-probe.log", f"^{row.probe}$")
                    probe_v = verdict(prc, pout)
                finally:
                    dst.unlink()
        finally:
            target.write_bytes(backup)
        assert target.read_bytes() == backup, f"restore failed for {row.name}"
        mark = "ok" if v == row.predict else "MISMATCH"
        line = f"{mark}: {row.name} [{row.kind}]: {v} (predicted {row.predict}) exit={rc} fails={len(fails)}"
        if probe_v:
            line += f" with-probe={probe_v}"
        line += f" :: {row.note}"
        if fails:
            line += f"\n    killers: {', '.join(fails)}"
        print(line, flush=True); summary.append(line)
    after = sha_dir(pkg_dir)
    print(f"pkg-hash-after={after} equal={after == before}", flush=True)
    (log_dir / "verdicts.txt").write_text("\n".join(summary) + f"\npkg-hash before={before} after={after}\n")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
