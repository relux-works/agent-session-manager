//go:build !windows

package tmuxserver

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/scalar"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func terminalbackendAdmitted(caps []string) terminalbackend.Admitted {
	return terminalbackend.Admitted{Capabilities: caps}
}

// K01: a foreign-owned leaf on the background path must keep its custody
// code at the top level (baseline for reviewer row R01).
func TestReviewK01BackgroundForeignOwnershipKeepsCustodyCode(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	previous := effectiveUID
	effectiveUID = func() int { return previous() + 100000 }
	defer func() { effectiveUID = previous }()
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	probed := false
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) {
		probed = true
		return brokerReport(), nil
	}
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_unsafe_runtime_dir", "runtime ownership")
	if probed {
		t.Fatal("broker was probed past a foreign-owned leaf")
	}
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
}

// K02: the broker path must refuse a live same-user generation-bound
// broker whose server report carries a zero admission (no rows, no
// generation: nothing reconciled yet) — baseline for R09.
func TestReviewK02BrokerPathRefusesZeroAdmissionServer(t *testing.T) {
	live := brokerReport()
	report := BrokerReport{Principal: live.Principal, Server: RealmAdmission{}}
	requireLocalError(t, CheckBrokerContact(report, fixtureGeneration, currentUID()), "tmux_readiness_not_authorizing", "server attestation")
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return report, nil }
	outcome, err := Acquire(req)
	if err == nil {
		t.Fatalf("Acquire admitted a zero-admission server on the broker path: via=%q", outcome.Via)
	}
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
}

// K03: the broker path must refuse an admitted-but-generationless server
// (rows present, RawGeneration empty) against a bound wanted generation —
// baseline for R10.
func TestReviewK03BrokerPathRefusesGenerationlessAdmittedServer(t *testing.T) {
	live := brokerReport()
	report := BrokerReport{Principal: live.Principal, Server: RealmAdmission{Admitted: realmAdmitted()}}
	requireLocalError(t, CheckBrokerContact(report, fixtureGeneration, currentUID()), "tmux_readiness_not_authorizing", "server generation")
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return report, nil }
	outcome, err := Acquire(req)
	if err == nil {
		t.Fatalf("Acquire admitted a generationless admitted server on the broker path: via=%q", outcome.Via)
	}
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
}

// P01: does a malformed-session foreground request create the runtime
// directory and probe the server before it refuses? (acquire.go doc:
// "Refusals precede side effects: malformed input ... refuse before any
// directory is created".)
func TestReviewP01MalformedSessionSideEffectsBeforeRefusal(t *testing.T) {
	root := runtimeRoot(t)
	req := validRequest(t, root)
	req.SessionID = "12345"
	probed := false
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		probed = true
		return ServerReport{}, nil
	}
	req.Deps.Spawn = spy.spawn
	_, err := Acquire(req)
	requireLocalError(t, err, "tmux_invalid_arguments", "session identity")
	_, statErr := os.Lstat(filepath.Join(root, RuntimeDirName))
	t.Logf("P01: malformed session: directory created before refusal = %v (stat err=%v); server probed before refusal = %v; spawn calls = %d",
		statErr == nil, statErr, probed, spy.calls)
}

// P02: a comma inside the runtime root breaks the TMUX first-comma split;
// a TMUX value naming the derived socket in the real encoding then walks
// past the collision gate. Observation only (tmux itself splits at the
// first comma too).
func TestReviewP02CommaRootTMUXEncoding(t *testing.T) {
	base := runtimeRoot(t)
	root := filepath.Join(base, "a,b")
	if err := os.Mkdir(root, 0o755); err != nil {
		t.Fatal(err)
	}
	dir := runtimeDir(t, root)
	req := validRequest(t, root)
	req.Ambient = Ambient{TMUXEnv: SocketPath(dir) + ",12345,0"}
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	outcome, err := Acquire(req)
	t.Logf("P02: comma-root TMUX real encoding: err=%v via=%q spawns=%d (socket component decoded as %q)", err, outcome.Via, spy.calls, tmuxEnvSocket(req.Ambient.TMUXEnv))
}

// P03: a cwd-relative spelling of the derived socket is not detected by
// the cleaned-string collision gate (same bound class as the B16 symlink
// alias). Observation only.
func TestReviewP03RelativeAliasWalksThrough(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	wd, _ := os.Getwd()
	if err := os.Chdir(root); err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(wd) }()
	req := validRequest(t, root)
	req.Ambient = Ambient{InheritedSocket: filepath.Join(RuntimeDirName, SocketName)}
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	outcome, err := Acquire(req)
	t.Logf("P03: relative alias %q: err=%v via=%q spawns=%d", req.Ambient.InheritedSocket, err, outcome.Via, spy.calls)
}

// P04: the background path never needs Spawn; a nil spawner with a live
// broker still contacts (confirms the field is inert there).
func TestReviewP04BackgroundNilSpawnContacts(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	outcome, err := Acquire(req)
	if err != nil {
		t.Fatal(err)
	}
	if outcome.Via != "broker" {
		t.Fatalf("via = %q", outcome.Via)
	}
}

// P05: platform-linux request on this darwin host commits and verifies the
// same unix custody through Acquire on both callers.
func TestReviewP05LinuxAcquireBothCallers(t *testing.T) {
	root := runtimeRoot(t)
	req := validRequest(t, root)
	req.Platform = scalar.PlatformLinux
	spy := &spawnSpy{}
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) { return ServerReport{}, nil }
	req.Deps.Spawn = spy.spawn
	outcome, err := Acquire(req)
	if err != nil || outcome.Via != "spawned" {
		t.Fatalf("linux foreground: err=%v via=%q", err, outcome.Via)
	}
	bg := validRequest(t, root)
	bg.Platform = scalar.PlatformLinux
	bg.Caller = CallerBackground
	bg.Deps.Spawn = spy.spawn
	bg.Deps.ProbeBroker = func() (BrokerReport, error) { return brokerReport(), nil }
	outcome, err = Acquire(bg)
	if err != nil || outcome.Via != "broker" {
		t.Fatalf("linux background: err=%v via=%q", err, outcome.Via)
	}
	if spy.calls != 1 {
		t.Fatalf("spawn calls = %d, want exactly 1 (foreground only)", spy.calls)
	}
}

// K04: a background miss with BOTH foreground dependencies armed must still
// return the typed unavailable and touch neither the server probe nor the
// spawner (baseline for reviewer row R18: a fallback into acquireForeground
// guarded on ProbeServer is invisible to every committed background test,
// because none of them arms ProbeServer).
func TestReviewK04BackgroundMissWithForegroundDepsArmedNeverFallsBack(t *testing.T) {
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	probedServer := false
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeServer = func(socket string) (ServerReport, error) {
		probedServer = true
		return ServerReport{}, nil
	}
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return BrokerReport{}, nil }
	_, err := Acquire(req)
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
	if probedServer {
		t.Fatal("background miss probed the server (foreground fallback)")
	}
	if spy.calls != 0 {
		t.Fatalf("spawn calls = %d, want 0", spy.calls)
	}
}

// K05: the broker path must refuse a decoy-only admission (baseline for R19).
func TestReviewK05BrokerPathRefusesDecoyAdmission(t *testing.T) {
	live := brokerReport()
	report := BrokerReport{Principal: live.Principal, Server: RealmAdmission{
		Admitted:      terminalbackendAdmitted([]string{fixtureDecoyCapacity}),
		RawGeneration: fixtureGeneration,
	}}
	root := runtimeRoot(t)
	runtimeDir(t, root)
	req := validRequest(t, root)
	req.Caller = CallerBackground
	spy := &spawnSpy{}
	req.Deps.Spawn = spy.spawn
	req.Deps.ProbeBroker = func() (BrokerReport, error) { return report, nil }
	outcome, err := Acquire(req)
	if err == nil {
		t.Fatalf("Acquire admitted a decoy-only server on the broker path: via=%q", outcome.Via)
	}
	requireCapabilityUnavailable(t, err, "background", fixtureBroker, fixtureGeneration, fixtureRemedy)
}
