export PATH=/Users/iv/.goenv/versions/1.25.5/bin:/Users/iv/.curator/global/bin:/usr/bin:/bin:/usr/sbin:/sbin
unset TMUX TMUX_TMPDIR
export PYTHONDONTWRITEBYTECODE=1
export GOFLAGS=
