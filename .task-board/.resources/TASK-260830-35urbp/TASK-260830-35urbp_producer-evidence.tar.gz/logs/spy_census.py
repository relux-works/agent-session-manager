#!/usr/bin/env python3
"""Mechanical both-spy census: every background-path Acquire test must
arm a spy spawner AND a spy server probe. A test counts as a
background-path Acquire test iff its body mentions CallerBackground
and calls Acquire( (the direct-gate test TestCheckCreationAllowed... is
correctly excluded: it never calls Acquire)."""
import re
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
tests = {}
order = []
current = None
for name in ("acquire_test.go", "acquire_unix_test.go"):
    for line in (REPO / "internal/tmuxserver" / name).read_text().splitlines(keepends=True):
        m = re.match(r"func (Test\w+)\(t \*testing\.T\) \{", line)
        if m:
            current = m.group(1)
            tests[current] = []
            order.append(current)
        if current:
            tests[current].append(line)
armed = total = 0
for name in order:
    body = "".join(tests[name])
    if "CallerBackground" not in body or "Acquire(" not in body:
        continue
    total += 1
    ok = ("spy.spawn" in body or "Spawn =" in body) and ("probe.probe" in body or "ProbeServer =" in body)
    armed += ok
    print(("OK  " if ok else "MISS"), name)
print(f"{armed}/{total} background-path Acquire tests arm both spies")
raise SystemExit(0 if armed == total else 1)
