#!/usr/bin/env python3
"""Verify the gate x entry census and the two-sided-gate symmetry table.

1. Parse the census table from internal/tmuxserver/TRACEABILITY.md:
   count gates x entries, M/B/U cells (U1/U2/U3 split).
2. Check every Test* name in TRACEABILITY.md exists in the committed suite.
3. Check every N-*/D-*/C-* row named in TRACEABILITY.md exists in the harness.
4. Two-sided-gate symmetry: for every gate implemented on two or more
   sides, list rows per side from the harness and report symmetric or
   the named missing row. Row existence + harness anchor counts +
   pass-1 KILLED verdicts are checked mechanically; the side mapping
   is declared below from the row find-sites.
"""
import re
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]  # .temp/TASK-.../rev7-evidence/logs/ -> worktree root
TRACE = REPO / "internal/tmuxserver/TRACEABILITY.md"
HARNESS = REPO / "internal/tmuxserver/mutant_harness.py"
PASS1 = REPO / ".temp/TASK-260830-35urbp/rev7-evidence/logs/harness-pass1-verdicts.log"

failures = []


def check(cond, msg):
    print(("ok  " if cond else "FAIL") + " " + msg)
    if not cond:
        failures.append(msg)


# --- 1. census counts ---
text = TRACE.read_text()
rows = [l for l in text.splitlines() if l.startswith("| ") and "acquire.go" in l or
        l.startswith("| ") and "runtime" in l or l.startswith("| ") and "readiness.go" in l or
        l.startswith("| ") and "socket.go" in l or l.startswith("| ") and "argv.go" in l]
# census rows are exactly the 12-col rows under "## Gate" (gate + 11 entries)
census = [l for l in rows if l.count("|") == 13]
gates = len(census)
cells = {"M": 0, "B": 0, "U1": 0, "U2": 0, "U3": 0}
for line in census:
    parts = [p.strip() for p in line.strip().strip("|").split("|")]
    assert len(parts) == 12, line[:60]
    for cell in parts[1:]:
        mark = cell.split(" ")[0]
        assert mark in cells, (mark, line[:80])
        cells[mark] += 1
total = sum(cells.values())
print(f"census: {gates} gates x 11 entries = {total} cells; "
      f"M={cells['M']} B={cells['B']} U1={cells['U1']} U2={cells['U2']} U3={cells['U3']}")
check(gates == 24 and total == 264, "24 x 11 = 264 cells")
check(cells["M"] == 50 and cells["B"] == 4, "50 M / 4 B")
check(cells["U1"] + cells["U2"] + cells["U3"] == 210, "210 U")

# --- 2. named tests exist ---
suite_src = ""
for p in (REPO / "internal/tmuxserver").glob("*_test.go"):
    suite_src += p.read_text()
defined = set(re.findall(r"func (Test\w+)\(t \*testing\.T\)", suite_src))
named_tests = sorted(set(re.findall(r"Test[A-Za-z0-9]+", text)))
missing = [t for t in named_tests if t not in defined]
check(not missing, f"named tests in TRACEABILITY all exist ({len(named_tests)} named, {len(defined)} defined)")
if missing:
    print("  missing:", missing)
unnamed = sorted(defined - set(named_tests))
print(f"  committed tests not named in TRACEABILITY: {unnamed}")

# --- 3. named rows exist ---
harness_src = HARNESS.read_text()
defined_rows = set(re.findall(r'name="([NDC]-[a-z0-9-]+)"', harness_src))
named_rows = sorted(set(re.findall(r"\b([NDC]-[a-z0-9-]+)\b", text)))
missing_rows = [r for r in named_rows if r not in defined_rows]
check(not missing_rows, f"named rows in TRACEABILITY all exist ({len(named_rows)} named, {len(defined_rows)} defined)")
if missing_rows:
    print("  missing:", missing_rows)

# --- 4. symmetry table ---
verdicts = PASS1.read_text()
PAIRS = [
    ("mode exact-0700", [("commit runtime_unix.go:83", ["N-mode-create", "N-mode-narrower-create"]),
                         ("verify runtime_unix.go:131", ["N-mode-verify", "N-mode-narrower-verify"])]),
    ("O_DIRECTORY containment", [("commit runtime_unix.go:58", ["N-containment-odirectory-commit"]),
                                 ("verify runtime_unix.go:117", ["N-containment-odirectory-verify"])]),
    ("symlink-leaf containment", [("commit", ["N-containment-symlink"]),
                                  ("verify", ["N-containment-symlink-verify"])]),
    ("root no-follow", [("commit", ["N-root-symlink-commit"]),
                        ("verify", ["N-root-symlink-verify"])]),
    ("session identity", [("entry acquire.go:225", ["N-session-entry"]),
                          ("spawn-site argv.go", ["N-argv-session"])]),
    ("caller dispatch", [("FG→BG", ["N-dispatch-foreground"]),
                         ("BG→FG", ["N-dispatch-background"])]),
    ("nil dependencies", [("background", ["N-deps-background"]),
                          ("foreground", ["N-deps-foreground"])]),
    ("probe passthrough", [("foreground", ["N-probe-swallow-foreground"]),
                           ("background", ["N-probe-swallow-background"])]),
    ("custody wiring", [("foreground ensure-site", ["N-acquire-commit-refusal"]),
                        ("background verify-site", ["N-acquire-verify-refusal"])]),
    ("leaf wiring", [("lexical", ["N-wiring-lexical"]),
                     ("ensure", ["N-wiring-ensure"]),
                     ("verify", ["N-wiring-verify"])]),
    ("typed details", [("single site, members", ["N-details-generation", "N-details-brokerstate", "N-details-remediation"])]),
    ("absence classifier", [("single site + remap, members",
                              ["N-background-absence-remap", "N-absence-remap-widen", "N-absence-remap-ownership",
                               "N-absence-remap-containment", "N-absence-remap-invalid"])]),
    ("running admission", [("single site, members", ["N-running-empty-admission", "N-running-empty-generation"])]),
]
print("\nTwo-sided-gate symmetry (rows per side; kill = pass-1 verdict):")
all_sym = True
for gate, sides in PAIRS:
    counts = []
    for side, rows_ in sides:
        for r in rows_:
            check(r in defined_rows, f"row {r} exists")
            check(f"ok: {r}: KILLED" in verdicts, f"row {r} KILLED in pass 1")
        counts.append(len(rows_))
    if len(sides) > 1:
        sym = len(set(counts)) == 1
        all_sym &= sym
        print(f"  {'symmetric' if sym else 'ASYMMETRIC'} {gate}: " +
              " / ".join(f"{s}={c}" for (s, _), c in zip(sides, counts)))
    else:
        print(f"  member-complete {gate}: {counts[0]}/{counts[0]} members rowed")
check(all_sym, "every multi-sided gate is symmetric")

print("\n%d failures" % len(failures))
sys.exit(1 if failures else 0)
