#!/usr/bin/env python3
"""Rev7 replay battery (NOT shipped): re-plant the three rev6 reviewer
shapes against the rev7 candidate and prove the new tests kill with
member-level attribution. Each plant: apply to a backup/restore copy,
run the committed suite slice, restore, verify byte-identical.
Usage: run from the worktree root; writes logs to the given dir."""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

REPO = Path.cwd()
OUT = Path(sys.argv[1])
OUT.mkdir(parents=True, exist_ok=True)

PLANTS = [
    ("R01-commit-odirectory-drop",
     "internal/tmuxserver/runtime_unix.go",
     "\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)\n",
     "\tleafFd, err := unix.Openat(rootFd, name,\n\t\tunix.O_RDONLY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)\n",
     "(TestEnsureRuntimeDirRefusesNonDirectoryLeaf|TestAcquireForegroundRefusesNonDirectoryLeaf)"),
    ("R07-membership-fresh-decoy-local-attach",
     "internal/tmuxserver/readiness.go",
     "\tif !admission.Admitted.Has(realmCapability) {\n",
     '\tif !admission.Admitted.Has(realmCapability) && !admission.Admitted.Has("local_attach") {\n',
     "(TestCheckServerAttestedRefusesEveryCatalogDecoy|TestAcquireBackgroundRefusesEveryCatalogDecoy)"),
    ("R07b-membership-second-decoy-durable-disconnect",
     "internal/tmuxserver/readiness.go",
     "\tif !admission.Admitted.Has(realmCapability) {\n",
     '\tif !admission.Admitted.Has(realmCapability) && !admission.Admitted.Has("durable_disconnect") {\n',
     "(TestCheckServerAttestedRefusesEveryCatalogDecoy|TestAcquireBackgroundRefusesEveryCatalogDecoy)"),
    ("R16-wsl2-only-fallback-spawn",
     "internal/tmuxserver/acquire.go",
     "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
     "\t\tif cerr := checkCreationAllowed(req.Caller); cerr != nil {\n\t\t\tif req.Platform == scalar.PlatformWSL2 && req.Deps.Spawn != nil {\n\t\t\t\t_ = req.Deps.Spawn(socket, nil)\n\t\t\t}\n\t\t\treturn Outcome{}, backgroundUnavailable(req, err)\n\t\t}\n",
     "TestAcquireBackgroundMissOnLinuxAlsoRefusesWithoutFallback"),
]

for name, rel, find, repl, run in PLANTS:
    target = REPO / rel
    original = target.read_text()
    assert original.count(find) == 1, (name, original.count(find))
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(find, repl))
            r = subprocess.run(["go", "test", "./internal/tmuxserver/", "-run", run, "-count=1", "-v"],
                               cwd=REPO, capture_output=True, text=True, timeout=300)
        finally:
            shutil.copy2(backup, target)
    assert target.read_text() == original, name
    (OUT / f"{name}.log").write_text(f"exit: {r.returncode}\nrun: go test ./internal/tmuxserver/ -run {run} -count=1 -v\n\n{r.stdout}\n{r.stderr}\n")
    verdict = "KILLED" if (r.returncode != 0 and "--- FAIL" in (r.stdout + r.stderr)) else ("SURVIVED" if r.returncode == 0 else "ERROR")
    print(f"{verdict}: {name} [exit {r.returncode}]", flush=True)
print("restored byte-identical; done")
