#!/bin/zsh
set -u
TRUNK=6d3bff999f75ed8585a7ef32074ab108f364ec51
BASE=5bfbc78f68c7251b75c9ac25ab7342cda8652ebc
CANDIDATE=2530f4d80c9bf7bee95fa21ad89d2456db31816e
printf 'origin/main=%s\n' "$(git rev-parse origin/main)"
git merge-base --is-ancestor "$TRUNK" "$BASE"; printf 'trunk_ancestor_of_base_exit=%s (want 0)\n' "$?"
python3 - "$TRUNK" "$CANDIDATE" <<'PY'
import subprocess,sys
trunk,candidate=sys.argv[1:]
old='0ca3e4c26e2b275212796657f785b9b450f6174e'
paths=subprocess.check_output(['git','diff','--name-only',old,trunk,'--','.',':!.task-board'],text=True).splitlines()
unequal=[]
for p in paths:
 a=subprocess.run(['git','rev-parse',f'{trunk}:{p}'],capture_output=True,text=True).stdout.strip()
 b=subprocess.run(['git','rev-parse',f'{candidate}:{p}'],capture_output=True,text=True).stdout.strip()
 if a!=b: unequal.append(p)
print(f'trunk_only_nonboard_paths={len(paths)} unequal_in_candidate={len(unequal)} (want 0)')
print('sample='+','.join(unequal[:6]))
assert not unequal,'candidate lacks current trunk blobs'
PY
