package cloneplanning

import (
	"github.com/relux-works/agent-session-manager/internal/clonefidelity"
)

// This file folds planned mappings to target effects: callable
// tools, pending actions, and target token accounting. Historical
// tools are inert and source usage is not target accounting
// (Section 13.14.1), so the fold is always empty: no mapping admits
// a live effect. Mappings carry no token field by type, so token
// counts cannot reach the accounting decision at all; the sweep
// proves every mapping the planner emits folds to zero.

// TargetEffects is the planned session's live surface: callable
// tools, pending actions, and target token accounting. Planning
// from captured history always yields the zero value.
type TargetEffects struct {
	CallableTools      []string
	PendingActions     []string
	TargetInputTokens  uint64
	TargetOutputTokens uint64
}

// PlanTargetEffects folds planned mappings to their target
// effects: always empty. Every mapping is validated first (closed
// disposition, vocabulary reasons in sorted-unique order), so
// garbage mappings refuse instead of folding.
func PlanTargetEffects(mappings []Mapping) (TargetEffects, error) {
	for index, mapping := range mappings {
		if !validText(mapping.Disposition) {
			return TargetEffects{}, invalid("target effects mapping[%d] disposition is not valid UTF-8", index)
		}
		if !clonefidelity.ValidDisposition(mapping.Disposition) {
			return TargetEffects{}, invalid("target effects mapping[%d] disposition %q is outside the Section 13.14.2 vocabulary", index, mapping.Disposition)
		}
		for _, reason := range mapping.Reasons {
			if !validText(reason) {
				return TargetEffects{}, invalid("target effects mapping[%d] reason is not valid UTF-8", index)
			}
			if !clonefidelity.ValidReasonCode(reason) {
				return TargetEffects{}, invalid("target effects mapping[%d] reason %q is not a core or reverse-DNS reason", index, reason)
			}
		}
		for position := 1; position < len(mapping.Reasons); position++ {
			if mapping.Reasons[position-1] >= mapping.Reasons[position] {
				return TargetEffects{}, invalid("target effects mapping[%d] reasons are not sorted unique", index)
			}
		}
	}
	return TargetEffects{}, nil
}
