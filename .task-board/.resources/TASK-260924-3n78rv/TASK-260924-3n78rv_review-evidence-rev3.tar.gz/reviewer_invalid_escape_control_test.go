package cloneplanning
import (
 "strings"
 "testing"
)
func TestReviewerVisibleProjectionRejectsInvalidUTF8Control(t *testing.T) {
 _, err := ProjectVisibleText(VisibleInput{Kind:"user_message",Texts:[]string{string([]byte{0xff})},EventIDs:[]string{"sha256:"+strings.Repeat("0",63)+"1"}})
 if err == nil { t.Fatal("ProjectVisibleText admitted invalid UTF-8") }
}
