from pathlib import Path
import subprocess,time
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/review-scratch/RUN-260924-348371')
repo=root/'own'
plants=[
 ('authority-sudo','internal/cloneplanning/visible.go','Authority:   authorityUserContext,','Authority:   func() string { if strings.Contains(joined, "sudo") { return "assistant" }; return authorityUserContext }(),','TestProjectVisibleWholeDomain',1),
 ('continuation-usage','internal/cloneplanning/plan.go','if strategy == strategyContinuation {','if strategy == strategyContinuation && item.Kind != "usage" {','TestPlanItemContinuationRule',1),
 ('importer-tool-definition','internal/cloneplanning/plan.go','if strategy == strategyOfficial {','if strategy == strategyOfficial && item.Kind != "tool_definition_snapshot" {','TestPlanItemImporterRule',1),
 ('abort-tool-call','internal/cloneplanning/plan.go','(item.Kind == "tool_call" || item.Kind == "tool_result") && item.Resolution == cloneproject.StatusAborted','item.Kind == "tool_result" && item.Resolution == cloneproject.StatusAborted','TestPlanItemAbortRule',1),
 ('effects-semantic','internal/cloneplanning/effects.go','return TargetEffects{}, nil\n}','if len(mappings) == 1 && mappings[0].Disposition == "semantic" { return TargetEffects{TargetInputTokens: 1}, nil }; return TargetEffects{}, nil\n}','TestPlanTargetEffectsZeroSweep',1),
 ('neutral-comment','internal/cloneplanning/doc.go','package cloneplanning','// reviewer neutral control\npackage cloneplanning','TestAuthorityDecisionShape',0),
]
for name,rel,needle,repl,test,want in plants:
 p=repo/rel
 original=p.read_text()
 assert original.count(needle)==1,(name,original.count(needle))
 p.write_text(original.replace(needle,repl,1))
 started=time.time()
 try:
  run=subprocess.run(['go','test','-count=1','-run','^'+test+'$','./internal/cloneplanning/'],cwd=repo,capture_output=True,text=True,timeout=180)
 finally:
  p.write_text(original)
 assert p.read_text()==original
 log=f'{name}\nfile={rel}\nneedle={needle}\nreplacement={repl}\ntest={test}\nexit={run.returncode}\nelapsed={time.time()-started:.1f}s\nstdout:\n{run.stdout}\nstderr:\n{run.stderr}\n'
 (root/(name+'.log')).write_text(log)
 print(name,'exit',run.returncode,'expected',want,flush=True)
 assert (run.returncode!=0)==bool(want),(name,run.returncode)
