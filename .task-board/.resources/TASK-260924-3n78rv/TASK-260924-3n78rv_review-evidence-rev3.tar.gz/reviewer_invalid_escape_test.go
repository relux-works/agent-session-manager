package cloneplanning
import "testing"
func TestReviewerEscapeVisibleTextRejectsInvalidUTF8(t *testing.T) {
 for _, input := range []string{string([]byte{0xff}), string([]byte{0xc3,0x28})} {
  if got, err := EscapeVisibleText(input); err == nil { t.Fatalf("invalid UTF-8 admitted as %q",got) }
 }
}
