| Row | Result | Attack |
| --- | --- | --- |
| Selection and branch routing | held | `TestSelectStrategyOracle`, `TestSelectProfileOracle`, and `TestSelectionAgreement` passed in the three-run package rerun; selection entries reached through their exported calls. |
| Canonical item classification | held | All-kinds classification corpus and closed-fact structural test passed in the three-run package rerun; the closed event-kind list is pinned to SPEC §13.14.1. |
| Strategy × profile × item planning | held | The 975-cell production-entry oracle passed three times; my continuation-one-kind narrowing failed `TestPlanItemWholeDomainOracle` alone. |
| Visible authority and escaping | held | Independent seven-text corpus over all 26 event kinds and three field positions passed `TestReviewerOwnAuthorityCorpus`; one-class authority escalation failed it alone; malformed UTF-8 refusal tests passed three times. |
| Historical tools and source accounting | held | Target-effects owner rule table and zero fold passed three times; independent semantic-empty and exact-reason probes passed; two single-class owner bypasses failed `TestReviewerOwnRecordCoupling` alone. |
| Importer outcome composition | held | My base checkout reran nine reused owner package suites green; candidate three-run planner package tests cover its importer entry inputs. Blob comparison found only the additive `clonefidelity/record.go` seam among 232 files in these nine packages. No existing `(package, entry, input)` class moved; the seam and eight new planner entries are candidate-only. |
| Candidate provenance and trunk composition | held | Scratch index produced CR tree `a5583e589d9ac3b6eaa2ed5504a25959c38970f7`; 362 trunk-delta paths equal candidate blobs; config hash unchanged; diff checks passed. |
