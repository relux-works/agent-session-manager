from pathlib import Path
import re,subprocess,sys
s=Path(__file__).parent
expected=set(subprocess.check_output(['go','list','./...'],text=True).splitlines())
logs=['full-test.log','shard1.log','shard2.log','shard3.log','shard4.log','shard5.log','tmux-full-retry.log','tmux-skip-baseline-failure.log']
seen=set()
for name in logs:
 p=s/name
 if not p.exists(): continue
 text=p.read_text()
 hits=set(re.findall(r'^(?:ok|\?)\s+(\S+)',text,re.M))
 print(name,len(hits),'FAIL' if re.search(r'^FAIL(?:\s|$)',text,re.M) else 'ok')
 seen.update(hits)
print('packages expected',len(expected),'seen',len(seen),'missing',sorted(expected-seen))
names=(s/'harness-names.txt').read_text().splitlines()
for run in (1,2):
 verdict=[]
 for p in [s/f'harness-own-{run}/verdicts.txt', *(s/f'harness-{run}-{i}/verdicts.txt' for i in range(5))]:
  if not p.exists(): continue
  verdict += re.findall(r'^(\S+): (KILLED|SURVIVED)',p.read_text(),re.M)
 found=dict(verdict)
 print('harness',run,'rows',len(verdict),'unique',len(found),'missing',sorted(set(names)-set(found)),'wrong',[(n,v) for n,v in verdict if v!=('SURVIVED' if n=='C-doc-comment' else 'KILLED')])
