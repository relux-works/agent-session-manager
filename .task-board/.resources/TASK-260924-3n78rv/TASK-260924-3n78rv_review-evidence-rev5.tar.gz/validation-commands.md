# TASK-260924-3n78rv reviewer command record

Candidate: `a5583e589d9ac3b6eaa2ed5504a25959c38970f7`. Scratch index and CR patch hash match the immutable tree/diff. All commands below used the live candidate tree except base owner tests and deliberate mutations, which used scratch copies under this run's review-scratch directory.

| Command or check | Exit/result | Raw evidence |
| --- | --- | --- |
| `go test ./...` | exit 130: interrupted at ten minutes due runner bound; 28 packages had completed, and `resumesmoke` received `signal: interrupt` | `full-test.log` |
| `go test` bounded shard 1 (`resumesmoke`, `rpcwire`, `scalar`, `secconftest`) | 0, 4 packages | `shard1.log` |
| bounded shard 2 (`secprim`, `sessadapter`, `sessckpt`, `sessprofile`) | 0, 4 packages | `shard2.log` |
| bounded shard 3 (`sessquery`, `sessrepo`, `sessstate`, `specdoc`) | 0, 4 packages | `shard3.log` |
| bounded shard 4 (`specpin`, `sshtransport`, `termbind`, `terminalbackend`) | 0, 4 packages | `shard4.log` |
| bounded shard 5 (`terminstance`, `tmuxserver`, `traceability`, `tracecheck`) with long review-scratch `TMPDIR` | 1, only `TestExecuteRefusesUnsafeSocket` failed: socket path too long | `shard5.log` |
| `env -u TMPDIR go test -count=1 -run '^TestExecuteRefusesUnsafeSocket$' ./internal/tmuxserver` | 0 | `tmux-path-probe.log` |
| `env -u TMPDIR go test -count=1 ./internal/tmuxserver` | 1: only `TestUnixDialerMissingDirectoryIsUnknown`, a pre-existing test/implementation contradiction | `tmux-full-retry.log` |
| focused missing-directory test on exact candidate and base | both exit 1 with identical failure; source and test blobs identical | `tmux-focused-candidate.log`, `tmux-focused-base.log` |
| `env -u TMPDIR go test -count=1 -skip ... ./internal/tmuxserver` | 0, remaining package tests pass in 449.652s | `tmux-skip-baseline-failure.log` |
| `go test -count=3 ./internal/cloneplanning` | 0 | `determinism.log` |
| `GOOS=windows GOARCH=amd64 go vet ./...` | 0 | `winvet.log` (empty stdout/stderr) |
| Nine base owner package suites | 0 after adding two exact base fixture blobs to sparse copy | `importer-base-tests.log`, `importer-base-extra-retry.log`; initial missing-fixture failure in `importer-base-extra.log` |
| Importer blob grid | 231/232 identical; additive `clonefidelity/record.go` only | `importer-grid-own.log` |
| Normative JCS+SHA-256 fixture | exact match | `fixture-recompute-own.log` |
| Two complete mutant harness passes | 57 KILLED and one neutral SURVIVED in each pass; raw log per plant per pass | `harness-own-*`, `harness-1-*`, `harness-2-*` |
| Four reviewer-owned narrowing plants + neutral control | 4 KILLED; 1 SURVIVED | `own-mutant-summary.log`, per-plant logs |
| AST authority control plant | named structural test failed on conditional authority | `authority-ast-control.log` |
| Exact-tree hygiene and trunk equality | scratch index tree exact, 362 trunk paths identical, config blob unchanged, both diff checks 0 | `trunk-equality.log`, verdict text |
