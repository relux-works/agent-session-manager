from pathlib import Path
import subprocess,sys
scratch=Path(__file__).parent
names=(scratch/'harness-names.txt').read_text().splitlines()
done={'N-compact-skip','N-opaque-event-reason','N-continuation-exact','N-abort-drop','N-effects-nonzero','N-effects-exact-reasons','N-effects-nonexact-bare','N-visible-authority','C-doc-comment'}
remaining=[n for n in names if n not in done]
assert len(remaining)==49,len(remaining)
passnum=int(sys.argv[1]); group=int(sys.argv[2]); chosen=remaining[group*10:(group+1)*10]
assert chosen
root=scratch/'candidate'
logdir=scratch/f'harness-{passnum}-{group}'
cmd=[sys.executable,'internal/cloneplanning/testdata/mutant_harness.py','--log-dir',str(logdir),*chosen]
proc=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=500)
(scratch/f'harness-{passnum}-{group}.log').write_text('$ '+' '.join(cmd)+'\n'+proc.stdout+'\nexit='+str(proc.returncode)+'\n')
print(proc.stdout)
print('exit',proc.returncode)
sys.exit(proc.returncode)
