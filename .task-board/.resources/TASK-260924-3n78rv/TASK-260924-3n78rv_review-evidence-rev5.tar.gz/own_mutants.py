from pathlib import Path
import subprocess
root=Path(__file__).parent/'candidate'
pkg=root/'internal/cloneplanning'
rows=[
 ('semantic-owner-bypass','effects.go','if err := checkMappingViaOwner(fmt.Sprintf("target effects mapping[%d]", index), mapping); err != nil {','if err := func() error { if mapping.Disposition == "semantic" && len(mapping.Reasons) == 0 { return nil }; return checkMappingViaOwner(fmt.Sprintf("target effects mapping[%d]", index), mapping) }(); err != nil {','TestReviewerOwnRecordCoupling'),
 ('exact-owner-bypass','effects.go','if err := checkMappingViaOwner(fmt.Sprintf("target effects mapping[%d]", index), mapping); err != nil {','if err := func() error { if mapping.Disposition == "exact" && len(mapping.Reasons) > 0 { return nil }; return checkMappingViaOwner(fmt.Sprintf("target effects mapping[%d]", index), mapping) }(); err != nil {','TestReviewerOwnRecordCoupling'),
 ('authority-escalate-one-class','visible.go','Authority:   authorityUserContext,','Authority:   func() string { if strings.Contains(joined, "sudo") { return "system" }; return authorityUserContext }(),','TestReviewerOwnAuthorityCorpus'),
 ('continuation-native-one-kind','plan.go','if strategy == strategyContinuation {\n\t\treturn dispositionSemantic, []string{reasonTargetNoEquivalent}\n\t}','if strategy == strategyContinuation {\n\t\tif item.Kind == "user_message" { return dispositionExact, nil }\n\t\treturn dispositionSemantic, []string{reasonTargetNoEquivalent}\n\t}','TestPlanItemWholeDomainOracle'),
 ('control-comment','visible.go','// authorityUserContext is the only visible-projection authority','// neutral reviewer control\n// authorityUserContext is the only visible-projection authority','TestReviewerOwnAuthorityCorpus'),
]
for name,path,find,replace,killer in rows:
 p=pkg/path; old=p.read_text(); assert old.count(find)==1,(name,old.count(find))
 p.write_text(old.replace(find,replace,1))
 try:
  cmd=['go','test','-count=1','-run','^'+killer+'$','./internal/cloneplanning']
  result=subprocess.run(cmd,cwd=root,env=None,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=150)
  (Path(__file__).parent/(name+'.log')).write_text('$ '+' '.join(cmd)+'\n'+result.stdout+'\nexit='+str(result.returncode)+'\n')
  print(name,'KILLED' if result.returncode and '--- FAIL:' in result.stdout else 'SURVIVED' if result.returncode==0 else 'ERROR',result.returncode,flush=True)
 finally:
  p.write_text(old)
