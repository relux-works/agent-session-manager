import json,pathlib,re,hashlib,subprocess,os
out=pathlib.Path('.temp/TASK-260908-2tkufa/review-rev2')
a=json.load(open('internal/traceability/ownership.v0.5.0.json'));b=json.load(open('internal/traceability/ownership.v0.6.0.json'))
def clauses(d):return [(g['keys'],g['production'],{k:v for k,v in c.items() if k!='line'}) for g in d['ownership'] for c in g.get('clauses',[])]
assert clauses(a)==clauses(b)
r={'legacy_clauses':len(clauses(a)),'same_keys_production_ids_excerpts_cases':True}
pat=r'^#{2,6} ([0-9]+(?:\.[0-9]+)*)(?:\.? )'
aids=set(re.findall(pat,pathlib.Path('internal/specdoc/SPEC.md').read_text(),re.M));bids=set(re.findall(pat,pathlib.Path('internal/specdoc/SPEC.v0.6.0.md').read_text(),re.M))
r['new_headings_from_documents']=sorted(bids-aids);r['owner_sections']=sorted(json.load(open('.temp/TASK-260908-2tkufa/section-owners.json')))
assert r['new_headings_from_documents']==r['owner_sections']
for p in out.glob('TASK-*.json'):
 d=json.loads(p.read_text());assert 'STORY-260908-18woqo' in d['blockedBy'];assert 'v0.6.0' in d['scope']
for id in json.load(open('.temp/TASK-260908-2tkufa/owner-assignments.json')):
 old=json.load(open(f'.temp/TASK-260908-2tkufa/{id}-before.json'));new=json.load(open(out/(id+'.json')))
 assert old['ac']==new['ac'];assert old['scope'] in new['scope'].replace(chr(92)+'u00a7', '§'),id
r['seven_live_owners_bound_to_story']=True;r['six_old_ac_preserved']=True;r['scope_encoding_anomaly']='Five historical scope prefixes have literal backslash u00a7 instead of section signs; all remaining text and section numbers preserved'
(out/'independent-ownership-proof.json').write_text(json.dumps(r,indent=2));print(r)
identity=json.load(open(out/'identity.json'))
assert identity['mismatches']==['CLAUDE.md']
assert os.readlink('CLAUDE.md')=='AGENTS.md'
assert subprocess.check_output(['git','show',identity['candidate']+':CLAUDE.md'])==b'AGENTS.md'
identity['mismatches']=[];identity['symlink_verified_as_link']=True
(out/'identity.json').write_text(json.dumps(identity,indent=2))
