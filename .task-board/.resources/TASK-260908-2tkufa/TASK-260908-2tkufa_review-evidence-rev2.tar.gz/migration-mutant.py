import json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'.temp/TASK-260908-2tkufa/review-rev2/mutants';copy=out/'candidate'
file='internal/config/migration_refusal_test.go';(copy/file).write_bytes((root/file).read_bytes())
p=copy/'internal/config/migration.go';original=p.read_bytes();entry='func Migrate(inputs Inputs, overrides Overrides, options MigrationOptions) (MigrationResult, error) {';marker='INSTRUMENT-M11'
instrument=original.decode().replace(entry,entry+'\n\tprintln("'+marker+'")')
records=[]
def run(name,expected):
 cmd=['go','test','./internal/config','-count=1','-v'];r=subprocess.run(cmd,cwd=copy,capture_output=True,text=True,timeout=120);data=r.stdout+r.stderr;(out/(name+'.log')).write_text(data)
 record=dict(name=name,command=cmd,exit=r.returncode,marker_seen=marker in data);records.append(record);print(json.dumps(record),flush=True)
 assert r.returncode==expected and marker in data
 if expected:assert '--- FAIL: TestMigrateRefusesEveryTargetOutsideTheUpgradeVocabulary/adopted_but_unimplemented_target' in data and '[build failed]' not in data
p.write_text(instrument)
try:
 run('M11-instrument-control',0)
 needle='if !targetKnown || options.TargetVersion == Version1 {';assert instrument.count(needle)==1
 # Keep the unsupported-target gate, admit only the adopted 4.0.0 target.
 p.write_text(instrument.replace(needle,'if (!targetKnown && options.TargetVersion != "4.0.0") || options.TargetVersion == Version1 {'))
 run('M11-mutant-suite',1)
finally:p.write_bytes(original);assert p.read_bytes()==original;(out/'M11-exits.json').write_text(json.dumps(records,indent=2))
