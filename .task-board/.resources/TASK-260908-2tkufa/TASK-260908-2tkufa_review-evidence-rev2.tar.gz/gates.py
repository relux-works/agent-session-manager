import json,subprocess,sys,pathlib
out=pathlib.Path('.temp/TASK-260908-2tkufa/review-rev2')
c=json.load(open('task-board.config.json'))
def find(o):
 if isinstance(o,dict):
  if 'commands' in o and isinstance(o['commands'],list) and any('go vet' in x for x in o['commands']):return o['commands']
  for v in o.values():
   r=find(v)
   if r:return r
 if isinstance(o,list):
  for v in o:
   r=find(v)
   if r:return r
commands=find(c)
for n in range(int(sys.argv[1]),int(sys.argv[2])+1):
 cmd=commands[n-1]
 with (out/f'gate-{n:02}.log').open('w') as f:
  p=subprocess.run(['zsh','-c',cmd],stdout=f,stderr=subprocess.STDOUT,timeout=480)
 row={'number':n,'command':cmd,'exit':p.returncode}
 (out/f'gate-{n:02}.json').write_text(json.dumps(row));print(json.dumps(row),flush=True)
