import hashlib,json,re,shutil,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'.temp/TASK-260908-2tkufa/review-rev2/mutants';out.mkdir(exist_ok=True)
copy=out/'candidate';copy.mkdir(exist_ok=True)
files=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z']).decode().split('\0')
for name in files:
 if not name or name.startswith('.task-board/'):continue
 src=root/name; dst=copy/name
 if not src.is_file():continue
 dst.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(src,dst)
records=[]
def run(name,cmd,expect=0,marker=None,failure=None):
 start=time.monotonic()
 p=subprocess.run(cmd,cwd=copy,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
 data=p.stdout.decode(errors='replace');(out/(name+'.log')).write_text(data)
 row={'name':name,'command':cmd,'exit':p.returncode,'seconds':round(time.monotonic()-start,2),'marker_seen':marker is None or marker in data,'semantic_failure':failure is None or ('--- FAIL: '+failure in data and '[build failed]' not in data)}
 records.append(row);(out/'exits.json').write_text(json.dumps(records,indent=2));print(json.dumps(row),flush=True)
 assert p.returncode==expect and row['marker_seen'] and row['semantic_failure'],name
 return data
# Recover only the retained applicator code; replace the old shell harness.
old=(root/'.temp/TASK-260908-2tkufa/prior-battery.sh').read_text()
blocks=re.findall(r'python3 -c "\n(.*?)\n"\n',old,re.S)
assert len(blocks)==6
blocks[-1]=blocks[-1].replace("CurrentVersion, Version4:", r'CurrentVersion, \"4.0.0\":')
cases=[
 ('M1','internal/cataloggen/generate.go','func Generate(metadataBytes, contractLock []byte) ([]byte, error) {','./internal/cataloggen','TestGenerateRefusesStaleV050Authority'),
 ('M2','internal/cigate/contracts.go','func checkReleaseRoots(pinCurrent, pinHistorical, catalogCurrent, catalogHistorical string) ([]string, error) {','./internal/cigate','TestCheckReleaseRootsRefusesDrift'),
 ('M3','internal/traceability/traceability.go','func verifyRepository(repository fs.FS, assignedSections []string) (Report, error) {','./internal/traceability','TestVerifyRepositoryRefusesStaleV050Lock'),
 ('M4','internal/catalog/catalog.go','func Current() Catalog {','./internal/catalog','TestCurrentMatchesReviewedV060Catalog'),
 ('M5','internal/traceability/traceability.go','func verifyRepository(repository fs.FS, assignedSections []string) (Report, error) {','./internal/traceability','TestVerifyRepositoryRefusesMissingSelectorContract'),
 ('M7','internal/config/schema.go','func Decode(document []byte, context DecodeContext) (LoadedConfiguration, error) {','./internal/config','TestLoadSupportsEveryPinnedConfigurationVersionAndTranslatesLegacyAtProductionEntry'),
]
run('baseline',['go','test','./internal/catalog/...','./internal/cataloggen','./internal/cigate','./internal/traceability','./internal/config','-count=1','-v'])
for block,(name,file,entry,pkg,failure) in zip(blocks,cases):
 p=copy/file; pristine=p.read_bytes(); marker='INSTRUMENT-'+name
 text=pristine.decode();assert text.count(entry)==1
 instrument=text.replace(entry,entry+'\n\tprintln("'+marker+'")')
 p.write_text(instrument)
 try:
  run(name+'-instrument-control',['go','test',pkg,'-v','-count=1'],marker=marker)
  p.write_bytes(pristine)
  # Shell parsing only for the exact existing quoted Python block; no inferred paths.
  run(name+'-apply',['zsh','-c','python3 -c "\n'+block+'\n"'])
  mutated=p.read_text();assert mutated!=text
  p.write_text(mutated.replace(entry,entry+'\n\tprintln("'+marker+'")'))
  (out/(name+'.diff')).write_bytes(subprocess.run(['diff','-u',str(root/file),str(p)],stdout=subprocess.PIPE).stdout)
  run(name+'-mutant-suite',['go','test',pkg,'-v','-count=1'],expect=1,marker=marker,failure=failure)
 finally:
  p.write_bytes(pristine);assert p.read_bytes()==pristine
# Token-preserving gate command attacks, measured through behavioral CLI tests.
for name,file,failure,oldtext,newtext in [
 ('M6','internal/catalog/catalog.go','TestGenerateDirectiveConsumesAdoptedAuthority','//go:generate go run ./cmd/cataloggen -metadata catalog.v0.6.0.json -contracts ../specpin/v0.6.0.lock.json','//go:generate go run ./cmd/cataloggen -metadata catalog.v0.5.0.json -contracts ../specpin/v0.5.0.lock.json'),
 ('M8','task-board.config.json','TestConfiguredCRCatalogGateConsumesAdoptedAuthority','go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.6.0.json -contracts internal/specpin/v0.6.0.lock.json','go run ./internal/catalog/cmd/cataloggen -metadata internal/catalog/catalog.v0.5.0.json -contracts internal/specpin/v0.5.0.lock.json')]:
 p=copy/file;pristine=p.read_bytes();gp=copy/'internal/catalog/cmd/cataloggen/main.go';gpristine=gp.read_bytes();marker='INSTRUMENT-'+name
 gp.write_text(gpristine.decode().replace('func run(arguments []string) error {','func run(arguments []string) error {\n\tprintln("'+marker+'")'))
 try:
  run(name+'-instrument-control',['go','test','./internal/catalog/cmd/cataloggen','-v','-count=1'],marker=marker)
  s=p.read_text();assert s.count(oldtext)==1;p.write_text(s.replace(oldtext,newtext))
  run(name+'-mutant-suite',['go','test','./internal/catalog/cmd/cataloggen','-v','-count=1'],expect=1,marker=marker,failure=failure)
  if name=='M6':run(name+'-token-control',['go','test','./internal/catalog','-run','^TestGenerateDirectiveStaysRecognizedForm$','-v','-count=1'])
 finally:
  p.write_bytes(pristine);gp.write_bytes(gpristine);assert p.read_bytes()==pristine and gp.read_bytes()==gpristine
# Narrow only the unowned-selector admission branch; all other disclosures refuse.
p=copy/'internal/traceability/traceability.go';pristine=p.read_bytes();entry='func verifyRepository(repository fs.FS, assignedSections []string) (Report, error) {';marker='INSTRUMENT-M9'
instrument=pristine.decode().replace(entry,entry+'\n\tprintln("'+marker+'")');p.write_text(instrument)
try:
 run('M9-instrument-control',['go','test','./internal/traceability','-v','-count=1'],marker=marker)
 needle='if entry, disclosed := unowned[key]; disclosed {';assert instrument.count(needle)==1
 p.write_text(instrument.replace(needle,needle+'\n\t\t\t\tif key == "section:14.7.1" { continue }'))
 run('M9-mutant-suite',['go','test','./internal/traceability','-v','-count=1'],expect=1,marker=marker,failure='TestAdoptedSectionsHavePendingOwnersAndRefuseRuntimeAdmission')
finally:p.write_bytes(pristine);assert p.read_bytes()==pristine
# Narrow the unsupported-reader gate only for the adopted-but-unimplemented reader.
p=copy/'internal/config/migration.go';pristine=p.read_bytes();entry='func AssessCompatibility(document []byte, readerVersion string) (CompatibilityAssessment, error) {';marker='INSTRUMENT-M10'
instrument=pristine.decode().replace(entry,entry+'\n\tprintln("'+marker+'")');p.write_text(instrument)
try:
 run('M10-instrument-control',['go','test','./internal/config','-v','-count=1'],marker=marker)
 needle='reader, ok := knownConfigVersion(readerVersion)';assert instrument.count(needle)==1
 p.write_text(instrument.replace(needle,needle+'\n\tif readerVersion == "4.0.0" { reader, _ = parseSemverCore(readerVersion); ok = true }'))
 run('M10-mutant-suite',['go','test','./internal/config','-v','-count=1'],expect=1,marker=marker,failure='TestAssessCompatibilityPinsEveryPinnedVersionPairAtTheProductionEntry')
finally:p.write_bytes(pristine);assert p.read_bytes()==pristine
run('restored-control',['go','test','./internal/catalog/...','./internal/cataloggen','./internal/cigate','./internal/traceability','./internal/config','-count=1','-v'])
print('10 narrowing mutants killed; 10 instrument controls passed; byte-exact restoration verified.',flush=True)
