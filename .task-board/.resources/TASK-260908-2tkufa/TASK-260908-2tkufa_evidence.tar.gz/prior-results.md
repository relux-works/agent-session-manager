# TASK-260908-2tkufa results: v0.6.0 catalog, registry, CI and traceability binding

Role: developer. Worktree: `.temp/STORY-260908-18woqo/worktree`, branch
`task-board/story/STORY-260908-18woqo`. Work left UNCOMMITTED for handoff snapshot.
Predecessor evidence accepted as reviewed input (not re-proven): signed v0.6.0 tag
verification, `v0.6.0.lock.json`/`SPEC.v0.6.0.md` digests, `CurrentV060`/`VerifyV060`/
`LoadV060` APIs. Everything below was re-run in-session against the worktree.

## AC coverage: 6 of 6 rows driven through production entry points

1. Consumers on approved v0.6.0 with regenerated artifacts + positive/refusal tests.
   `catalog.Current` <- `TestCurrentMatchesReviewedV060Catalog` (63 rows, RPC-5
   vocabulary, new-contract rows). `cataloggen.Generate` <-
   `TestGenerateMatchesCommittedTypedCatalog` (byte-equal committed `catalog_gen.go`)
   + `TestGenerateRefusesStaleV050Authority` (3 stale combos, layer-pinned messages).
   `cigate.PinnedReleases`/`PinContractSets` <- `TestPinnedReleasesAgreeAcrossAuthorities`,
   `TestVerifyContractPreservationLive` (v0.6.0/v0.4.3 roots), `TestCheckReleaseRootsRefusesDrift`
   (incl. stale-pin-current and stale-catalog-current rows). `traceability.VerifyRepository`
   <- `TestVerifyRepositoryAcceptsExactOwnership` + `TestVerifyRepositoryRefusesStaleV050Lock`.
2. New obligations mapped, no runtime claimed; history explicit.
   `VerifyRepository` over `ownership.v0.6.0.json`: owned `6.6`->`config.Migrate`,
   `11.10`->`catalog.ForRelease`, `14.7`->`cliresult.Emit` (unevidenced + gaps);
   10 unowned disclosures (`11.10.1-5`, `14.7.1/2/3/4/5`). History:
   `TestV050ProjectionMatchesHistoricalLock` (generated V050 row-equals real v0.5.0
   lock bytes), in-gate legacy check, `TestCurrentV050IsTheExplicitHistoricalBaseline`,
   `localstore` via explicit `CurrentV050`.
3. Gates pass with per-command evidence; mutants with controls; CR via handoff.
   `go test ./...` exit 0; `go test ./... -cover` exit 0 (touched pkgs 79.3-100%);
   `go vet ./...` exit 0; `GOOS=windows go vet/build ./...` exit 0; `gofmt -l` clean;
   `git diff --check` clean; `go generate` idempotent; tracecheck exit 0
   (63/36/101/32/55, bindings 56 = 1/3/1/48/3, unowned 12, clauses 17/463).
   Battery `/tmp/tkufa-mut/battery.sh` (isolated copy, pristine control green,
   byte-exact restore): 7 narrowing mutants killed, all semantic assertion failures.
4. Code per task description and AC: rewires + registry + ownership as specified.
5. Tests for new/changed behavior, all passing (named above + report/cmd pins).
6. Exact reviewed signed Story before unblocking dependents: handoff snapshots this
   uncommitted candidate; landing is the orchestrator step; dependent leaves resume after.

## Deliberate scope decisions (for the reviewer)

- D1 Error 1.4.0 codes excluded from the catalog error vocabulary. `axerror`
  `mustBuildCodeRegistry` panics on unregistered versions and its registry is closed
  over 1.0-1.3, so minting the 5 codes would panic every consumer at init (read, not
  assumed). The 1.4.0 contract version is adopted at census level (pin, generated
  Contracts map, preservation gate, contract ownership); §14.7.3 is disclosed unowned.
  A 1.4.0 reader is dependent-leaf work.
- D2 `internal/config` assessment-only admission. The catalog census advertises
  Configuration 4.0.0, which catalog-derived config tests require. `Decode`/`Migrate`
  behavior is unchanged (4.0.0 docs/targets refused; a pre-existing `schema_test.go`
  "unsupported major" row already pinned `Load("4.0.0")` refusal). Added `Version4`
  label + `assessmentVersion` so `AssessCompatibility` reasons over 4.0.0 pairs, and
  refusal arms (never translations) in the three version-enumerating tests per
  SPEC §6.6 refusal semantics. No decoder/migration behavior change.
- D3 No `.github` edits (sibling TASK-260908-eea478 owns workflow config; all CI test
  names preserved; gates adapt). No `axerror`/`cliresult`/decoder production change.
- D4 New mesh RPC 5.0.0 family versions kept with unchanged operations/sections per
  SPEC §11.10.1 ("exact RPC-4 operations"); family sections/fixtures untouched so
  `TestTraceabilityMatchesReviewedSourceAnchors` still passes unmodified.

## Mutant table (all killed; harness = named test + full package suite in isolated copy)

- M1 cataloggen lock-fallback admits exact v0.5.0 lock -> `TestGenerateRefusesStaleV050Authority` fails (lock-layer message moves).
- M2 cigate admits stale v0.5.0 pin current -> `TestCheckReleaseRootsRefusesDrift` fails.
- M3 traceability lock-fallback admits stale lock -> `TestVerifyRepositoryRefusesStaleV050Lock` fails.
- M4 catalog Current serves V050 -> `TestCurrentMatchesReviewedV060Catalog` fails.
- M5 ownership exempts exactly the selector key -> selector refusal test + narrowed-ownership subtest (drops same key) fail.
- M6 directive keeps `//go:generate`, points at v0.5.0 files -> token checker passes, `go generate` freshness fails exit 1, `catalog_gen.go` byte-identical.
- M7 config Decode admits 4.0.0 via v3 pipeline -> 3 new refusal arms + pre-existing "unsupported major" row fail.

## Files changed (22, uncommitted)

Modified: README.md, LOGBOOK.md, catalog/{catalog.go,catalog_test.go,cmd/cataloggen/main_test.go},
cataloggen/{generate.go,generate_test.go}, cigate/{contracts.go,contracts_test.go},
config/{schema.go,migration.go,schema_test.go,compatibility_regression_test.go},
localstore/paths.go, specdoc/specdoc.go, specpin/{pin.go,pin_test.go},
traceability/{traceability.go,traceability_test.go,cmd/tracecheck/main_test.go}.
New: catalog/catalog.v0.6.0.json, traceability/ownership.v0.6.0.json.
Digests adopted (reviewer must verify): metadata `5788d45d…87b963`, ownership `81a29888…65be`.
17 legacy clause lines migrated 1:1 (excerpt probe: each occurs exactly once in v0.6.0 doc).
