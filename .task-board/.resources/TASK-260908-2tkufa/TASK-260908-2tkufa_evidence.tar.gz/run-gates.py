import json,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'.temp/TASK-260908-2tkufa/gates';out.mkdir(exist_ok=True)
commands=json.loads((root/'task-board.config.json').read_text())['spawn']['worktree_isolation']['validation']['commands']
records=[]
for i,cmd in enumerate(commands,1):
 start=time.monotonic(); log=out/f'{i:02d}.log'
 with log.open('w') as f:
  p=subprocess.run(['zsh','-c',cmd],stdout=f,stderr=subprocess.STDOUT,timeout=480)
 row=dict(number=i,command=cmd,exit=p.returncode,seconds=round(time.monotonic()-start,2),log=str(log.relative_to(root)))
 records.append(row);(out/'exits.json').write_text(json.dumps(records,indent=2))
 print(json.dumps(row),flush=True)
 if p.returncode: raise SystemExit(p.returncode)
