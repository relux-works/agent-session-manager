import json, subprocess
from pathlib import Path
out=Path('.temp/TASK-260908-2tkufa')
assignments={
'TASK-260830-21gygk': 'Primary owner of sections 14.7 and 14.7.1 and shared SelectionPlan construction/revalidation in 14.7.2, refining section 2.3 and authoritative summaries in 5.7/14.7.3. Implement first-at literal grammar, exact source mappings, complete source reads with distinct failure classes, no explicit-source fallback, tier/collision/tombstone semantics, immutable locally attested plan and current-fact validation. Expose one shared API; CLI/lifecycle callers own invoking it at every required boundary, never a duplicate resolver.',
'TASK-260830-z1yxg9': 'Primary runtime owner of sections 11.10 and 11.10.1, refining 11.1/11.2/11.3/17: explicit host-channel launch, mutual TLS 1.3, ALPN ax-host/1, no resumption/early data/fallback, identity from verified enrolled certificates before hello and dispatch, both hello IDs checked, bounded streams/timeouts and current authorization generation at dispatch/mutation. Consume credential/config APIs owned by TASK-260909-2ez769 and accepted historical SSH/identity code. Section 11.10.5 is an upstream synthetic source validator, not an AX runtime JSON-policy reader.',
'TASK-260830-2x16gz': 'Primary implementation-conformance owner for section 11.10.4 / AC-HOST-001, across both OpenSSH and native Tailscale SSH, with real certificate chains, handshake, timeout/race, custody, revocation and generation tests. Use section 11.10.5 and its upstream publication vectors as source evidence only; do not claim their synthetic passes establish executed product support.',
'TASK-260830-1i7bqr': 'Primary owner of section 14.7.3 CLI Result 5.0.0 and Structured Error 1.4.0 readers/emitters and exact error-to-exit binding; integrate the shared selector/SelectionPlan API from TASK-260830-21gygk at every section 14.7.2 CLI boundary, including both endpoints of remote attach and logs, cursor continuation/retry/transport-resume and actual-invocation binding. Preserve historical CLI 1-4 and Error 1.0-1.3 closed bytes. Own product conformance for section 14.7.5, whose upstream evaluator is source evidence only.',
'TASK-260830-1wb06o': 'Primary owner of section 14.7.4 interrupted record-only bootstrap creation/recovery and lifecycle call sites of section 14.7.2. Consume the shared SelectionPlan API at each declared pre-effect/fencing/commit/retry/recovery/transport-resume boundary; retain original durable bootstrap inputs and authoritative initial lease/observation summaries, never invented values. Preserve all previous lifecycle acceptance obligations.',
'TASK-260830-219okr': 'Own subsequent major negotiation under sections 11.2-11.3/17 with adopted RPC 5 and explicit historical RPC 2/3/4 bounds. Config-4 Host Channel endpoints select RPC 5 only; legacy installations keep explicit historical behavior. Negotiation cannot downgrade a required authenticated endpoint or substitute for TASK-260830-z1yxg9 admission.'
}
def call(args):
 p=subprocess.run(['task-board',*args],capture_output=True,text=True)
 if p.returncode: raise RuntimeError(p.stdout+p.stderr)
 return p.stdout
for task,scope in assignments.items():
 before=json.loads(call(['q',f'get({task}) {{ id scope ac status }}']))
 (out/(task+'-before.json')).write_text(json.dumps(before,indent=2))
 # Preserve the whole old scope and AC as historical obligations, append exact delta authority.
 text='Adopted current authority: relux-works/agent-session-manager-spec@v0.6.0, commit 0cbdf100dbf84df50c64f792b1f940e3a67859a6. '+scope+' Historical scope retained without weakening: '+before['scope']+' Activation waits for signed STORY-260908-18woqo landing; this binding does not accept or alter the preserved partial implementation.'
 print(call(['m',f'set_details({task}, scope={json.dumps(text)})']))
 print(call(['m',f'link({task}, blocked_by=STORY-260908-18woqo)']))
 print(call(['m',f'set_notes({task}, text={json.dumps("TASK-260908-2tkufa assigns the approved v0.6.0 delta owner. Original AC and partial work remain preserved; pending runtime support is not claimed by catalog adoption. "+scope)})']))
print(call(['m','link(TASK-260909-2ez769, blocked_by=STORY-260908-18woqo)']))
print(call(['m','link(TASK-260830-z1yxg9, blocked_by=TASK-260909-2ez769)']))
(out/'owner-assignments.json').write_text(json.dumps(assignments,indent=2))
