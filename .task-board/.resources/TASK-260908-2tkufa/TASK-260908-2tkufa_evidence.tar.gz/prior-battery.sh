#!/bin/bash
# Narrowing-mutant battery for TASK-260908-2tkufa (isolated copy under /tmp/tkufa-mut/copy).
# Each mutant keeps its gate and admits exactly one member of the rejected class.
# A kill = the named test fails with a semantic assertion (exit 1), while the
# rest of its package suite stays green. Control = pristine green first.
# Usage: ./battery.sh  (exits 0 only when every mutant is killed)
set -u
COPY=/tmp/tkufa-mut/copy
cd "$COPY" || exit 2
PASS=0
KILL=0

control() {
  echo "=== CONTROL: pristine package suites ==="
  go test ./internal/catalog/ ./internal/cataloggen/ ./internal/cigate/ ./internal/traceability/ ./internal/config/ -count=1 > /tmp/tkufa-mut/control.log 2>&1
  code=$?
  echo "control exit=$code"
  if [ $code -ne 0 ]; then echo "CONTROL RED - aborting"; tail -20 /tmp/tkufa-mut/control.log; exit 2; fi
}

restore() {
  # byte-exact restore of every production file the battery touches
  cp /tmp/tkufa-mut/pristine/internal_cataloggen_generate.go internal/cataloggen/generate.go
  cp /tmp/tkufa-mut/pristine/internal_cigate_contracts.go internal/cigate/contracts.go
  cp /tmp/tkufa-mut/pristine/internal_traceability_traceability.go internal/traceability/traceability.go
  cp /tmp/tkufa-mut/pristine/internal_catalog_catalog.go internal/catalog/catalog.go
  cp /tmp/tkufa-mut/pristine/internal_config_schema.go internal/config/schema.go
  cp /tmp/tkufa-mut/pristine/internal_config_migration.go internal/config/migration.go
  sha256sum -c /tmp/tkufa-mut/pristine.sha > /dev/null || { echo "RESTORE MISMATCH"; exit 2; }
}

expect_kill() { # name, test-selector, package, extra-approval-grep
  name="$1"; selector="$2"; pkg="$3"
  echo "--- $name: $selector ($pkg)"
  go test "$pkg" -run "$selector" -v -count=1 > "/tmp/tkufa-mut/$name-named.log" 2>&1
  code=$?
  if [ $code -eq 0 ]; then echo "$name SURVIVED (named test passed)"; return 1; fi
  if ! grep -q -- "--- FAIL" "/tmp/tkufa-mut/$name-named.log"; then echo "$name: no FAIL line (setup/compile?)"; return 1; fi
  go test "$pkg" -count=1 > "/tmp/tkufa-mut/$name-suite.log" 2>&1
  suite=$?
  if [ $suite -eq 0 ]; then echo "$name: suite green under mutant (unexpected)"; return 1; fi
  fails=$(grep -c -- "--- FAIL" "/tmp/tkufa-mut/$name-suite.log")
  echo "$name KILLED (named exit=$code, suite exit=$suite, failing tests=$fails)"
  grep -- "--- FAIL" "/tmp/tkufa-mut/$name-suite.log" | head -8
  return 0
}

mkdir -p /tmp/tkufa-mut/pristine
cp internal/cataloggen/generate.go /tmp/tkufa-mut/pristine/internal_cataloggen_generate.go
cp internal/cigate/contracts.go /tmp/tkufa-mut/pristine/internal_cigate_contracts.go
cp internal/traceability/traceability.go /tmp/tkufa-mut/pristine/internal_traceability_traceability.go
cp internal/catalog/catalog.go /tmp/tkufa-mut/pristine/internal_catalog_catalog.go
cp internal/config/schema.go /tmp/tkufa-mut/pristine/internal_config_schema.go
cp internal/config/migration.go /tmp/tkufa-mut/pristine/internal_config_migration.go

control

# M1: cataloggen lock layer admits the exact stale v0.5.0 lock (fallback to Verify)
python3 -c "
src = open('internal/cataloggen/generate.go').read()
old = '''	manifest, err := specpin.VerifyV060(contractLock)
	if err != nil {
		return nil, invalid(\"verify normative lock: %v\", err)
	}'''
new = '''	manifest, err := specpin.VerifyV060(contractLock)
	if err != nil {
		manifest, err = specpin.Verify(contractLock)
		if err != nil {
			return nil, invalid(\"verify normative lock: %v\", err)
		}
	}'''
assert src.count(old) == 1
open('internal/cataloggen/generate.go', 'w').write(src.replace(old, new))
print('M1 applied')
"
expect_kill M1-lock-fallback 'TestGenerateRefusesStaleV050Authority' ./internal/cataloggen/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

# M2: cigate roots admit a stale v0.5.0 pin current
python3 -c "
src = open('internal/cigate/contracts.go').read()
old = '''	if pinCurrent != catalogCurrent {
		return nil, fmt.Errorf(\"cigate: current release root drift: specpin %q catalog %q\",
			pinCurrent, catalogCurrent)
	}'''
new = '''	if pinCurrent != catalogCurrent && pinCurrent != specpin.ReleaseV050 {
		return nil, fmt.Errorf(\"cigate: current release root drift: specpin %q catalog %q\",
			pinCurrent, catalogCurrent)
	}
	if pinCurrent == specpin.ReleaseV050 {
		pinCurrent = catalogCurrent
	}'''
assert src.count(old) == 1
open('internal/cigate/contracts.go', 'w').write(src.replace(old, new))
print('M2 applied')
"
expect_kill M2-stale-pin-current 'TestCheckReleaseRootsRefusesDrift' ./internal/cigate/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

# M3: traceability lock layer admits the exact stale v0.5.0 lock
python3 -c "
src = open('internal/traceability/traceability.go').read()
old = '''	manifest, err := specpin.VerifyV060(lockBytes)
	if err != nil {
		return Report{}, fail(\"verify normative source lock: %v\", err)
	}'''
new = '''	manifest, err := specpin.VerifyV060(lockBytes)
	if err != nil {
		manifest, err = specpin.Verify(lockBytes)
		if err != nil {
			return Report{}, fail(\"verify normative source lock: %v\", err)
		}
	}'''
assert src.count(old) == 1
open('internal/traceability/traceability.go', 'w').write(src.replace(old, new))
print('M3 applied')
"
expect_kill M3-stale-lock-fallback 'TestVerifyRepositoryRefusesStaleV050Lock' ./internal/traceability/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

# M4: catalog Current serves the stale v0.5.0 projection
python3 -c "
src = open('internal/catalog/catalog.go').read()
old = '''func Current() Catalog {
	catalog, err := ForRelease(ReleaseV060)'''
new = '''func Current() Catalog {
	catalog, err := ForRelease(ReleaseV050)'''
assert src.count(old) == 1
open('internal/catalog/catalog.go', 'w').write(src.replace(old, new))
print('M4 applied')
"
expect_kill M4-stale-current 'TestCurrentMatchesReviewedV060Catalog' ./internal/catalog/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

# M5: ownership required-key check exempts exactly the selector contract
# (needle-anchored: the exemption is a 3-line insert before the fail line)
python3 -c "
src = open('internal/traceability/traceability.go').read()
needle = '\t\t\t\treturn nil, fail(\"registered %s %q has no implementation owner\", kind, key)'
assert src.count(needle) == 1, src.count(needle)
insert = '\t\t\tif key == \"Session selector [urn:ax:contract:session-selector]\" {\n\t\t\t\tcontinue\n\t\t\t}\n'
open('internal/traceability/traceability.go', 'w').write(src.replace(needle, insert + needle))
print('M5 applied')
"
# M5 kills the named test AND the narrowed-ownership subtest that drops the
# same last (selector) key: both pin the selector-key requirement, so expect
# exactly those two failures in the suite log.
expect_kill M5-selector-exempt 'TestVerifyRepositoryRefusesMissingSelectorContract' ./internal/traceability/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

# M7: config Decode admits exactly 4.0.0 documents through the v3 pipeline
python3 -c "
src = open('internal/config/schema.go').read()
old = '''	case CurrentVersion:
		var raw rawV3
		if err = decodeStrict(document, &raw); err == nil {
			value, err = translateV3(raw, context)
		}'''
new = '''	case CurrentVersion, Version4:
		var raw rawV3
		if err = decodeStrict(document, &raw); err == nil {
			value, err = translateV3(raw, context)
		}'''
assert src.count(old) == 1
open('internal/config/schema.go', 'w').write(src.replace(old, new))
print('M7 applied')
"
expect_kill M7-decode-admits-v4 'TestLoadSupportsEveryPinnedConfigurationVersionAndTranslatesLegacyAtProductionEntry|TestEveryPinnedReaderHasPositiveNativeWindowsAndWSL2Lanes|TestLegacyConPTYTranslationIsPinnedForEveryLegacyReader' ./internal/config/ && KILL=$((KILL+1)) || PASS=$((PASS+1)); restore

echo "=== RESULT: killed=$KILL survived-or-error=$PASS ==="
restore
[ "$PASS" -eq 0 ]
