package axpane

import (
    "encoding/json"
    "testing"

    "github.com/relux-works/agent-session-manager/internal/sessprofile"
    "github.com/relux-works/agent-session-manager/internal/sessckpt"
    "github.com/relux-works/agent-session-manager/internal/sessrepo"
)

func emitProfileSourceOutcome(t *testing.T, entry, input string, pair sessprofile.Pair, err error) {
    t.Helper()
    message := ""
    if err != nil { message = err.Error() }
    raw, marshalErr := json.Marshal(map[string]any{
        "package": "internal/axpane", "entry": entry, "input": input,
        "outcome": map[string]any{"profile": pair.Profile, "source": pair.Source, "has_source": pair.HasSource, "error": message},
    })
    if marshalErr != nil { t.Fatal(marshalErr) }
    t.Log("profile-source-outcome " + string(raw))
}

func emitSetProfileOutcome(t *testing.T, input string, result sessprofile.SetProfileResult, err error) {
    t.Helper()
    message := ""
    if err != nil { message = err.Error() }
    raw, marshalErr := json.Marshal(map[string]any{
        "package": "internal/axpane", "entry": "Transactor.SetProfile.from_end", "input": input,
        "outcome": map[string]any{"previous_profile": result.PreviousProfile, "new_profile": result.NewProfile, "event_id": result.EventID, "error": message},
    })
    if marshalErr != nil { t.Fatal(marshalErr) }
    t.Log("profile-source-outcome " + string(raw))
}

func sourceProbeLoadPair(world *runWorld) (sessprofile.Pair, error) {
    record, events, err := LoadProfile(world.repo, fixtureSession)
    if err != nil { return sessprofile.Pair{}, err }
    return sessprofile.Derive(record, events)
}

func sourceProbeProjectorPair(world *runWorld) (sessprofile.Pair, error) {
    return (&sessprofile.Projector{Repo: world.repo}).Project(fixtureSession)
}

func sourceProbeProjectorForHeadsPair(world *runWorld) (sessprofile.Pair, error) {
    summaries, err := world.repo.ListEvents(fixtureSession)
    if err != nil { return sessprofile.Pair{}, err }
    head := ""
    for _, summary := range summaries {
        raw, err := world.repo.GetEvent(fixtureSession, summary.EventID)
        if err != nil { return sessprofile.Pair{}, err }
        event, err := sessprofile.DecodeEvent(raw)
        if err != nil { return sessprofile.Pair{}, err }
        if event.Type == "profile.changed" { head = event.ID }
    }
    if head == "" { return sessprofile.Pair{}, sessprofile.ErrInvalidEvent }
    return (&sessprofile.Projector{Repo: world.repo}).ProjectForHeads(fixtureSession, []string{head})
}

func sourceProbeDeriveProfilePair(world *runWorld) (sessprofile.Pair, error) {
    record, events, err := LoadProfile(world.repo, fixtureSession)
    if err != nil { return sessprofile.Pair{}, err }
    return deriveProfile(Input{ProfileRecord: record, ProfileEvents: events})
}

func measureProfileSourcePair(t *testing.T, entry, input string, makeWorld func(*testing.T) *runWorld, derive func(*runWorld) (sessprofile.Pair, error)) {
    t.Helper()
    world := makeWorld(t)
    pair, err := derive(world)
    emitProfileSourceOutcome(t, entry, input, pair, err)
}

func sourceProbeLosingWorld(t *testing.T) *runWorld {
    t.Helper()
    world := buildRunWorld(t)
    leases, err := world.repo.ListLeases(fixtureSession)
    if err != nil || len(leases) != 1 { t.Fatalf("ListLeases() = %v, %v; want epoch-1 lease", leases, err) }
    if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
        CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: "cccccccc-dddd-4eee-8fff-000000000002", HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt},
        Reason: "graceful_takeover", CheckpointID: world.ckptID,
    }); err != nil { t.Fatalf("CompareAndSwapLease() error = %v", err) }
    appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{"from": "standard", "to": "yolo", "confirmed": true})
    return world
}

func sourceProbeHigherEpochWorld(t *testing.T) *runWorld {
    t.Helper()
    world := buildRunWorld(t)
    appendChainEvent(t, world.repo, "profile.changed", 2, fixtureLeaseB, 1, world.headID, map[string]any{"from": "standard", "to": "yolo", "confirmed": true})
    return world
}

func sourceProbeEmptyLeaseWorld(t *testing.T) *runWorld {
    t.Helper()
    repository, err := sessrepo.Open(t.TempDir())
    if err != nil { t.Fatal(err) }
    var record map[string]any
    if err := json.Unmarshal([]byte(sessionRecordFixture), &record); err != nil { t.Fatal(err) }
    reference, err := repository.CreateSession(identifyObject(t, record, "record_id"))
    if err != nil { t.Fatalf("CreateSession() error = %v", err) }
    appendChainEvent(t, repository, "profile.changed", 1, fixtureLeaseA, 1, reference.RecordID, map[string]any{"from": "standard", "to": "yolo", "confirmed": true})
    return &runWorld{repo: repository}
}

func sourceProbeAmbiguousTupleWorld(t *testing.T) *runWorld {
    t.Helper()
    repository, err := sessrepo.Open(t.TempDir())
    if err != nil { t.Fatal(err) }
    var record map[string]any
    if err := json.Unmarshal([]byte(sessionRecordFixture), &record); err != nil { t.Fatal(err) }
    reference, err := repository.CreateSession(identifyObject(t, record, "record_id"))
    if err != nil { t.Fatalf("CreateSession() error = %v", err) }
    if _, err := repository.CreateLease(fixtureSession, sessrepo.CreateLeaseInput{LeaseID: fixtureLeaseA, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt}); err != nil { t.Fatalf("CreateLease() error = %v", err) }
    leases, err := repository.ListLeases(fixtureSession)
    if err != nil || len(leases) != 1 { t.Fatalf("ListLeases() = %v, %v; want epoch-1 lease", leases, err) }
    if _, err := repository.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
        CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: fixtureLeaseB, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt},
        Reason: "graceful_takeover", CheckpointID: "sha256:0000000000000000000000000000000000000000000000000000000000000000",
    }); err != nil { t.Fatalf("CompareAndSwapLease() error = %v", err) }
    appendChainEvent(t, repository, "profile.changed", 2, fixtureLeaseA, 1, reference.RecordID, map[string]any{"from": "standard", "to": "yolo", "confirmed": true})
    return &runWorld{repo: repository}
}

func sourceProbeWinningHandoffWorld(t *testing.T) *runWorld {
    t.Helper()
    world := buildRunWorld(t)
    changed := appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{"from": "standard", "to": "yolo", "confirmed": true})
    checkpoint, _, err := world.ckpt.Capture(world.repo, sessckpt.Inputs{
        OperationID: fixtureOtherOp, SessionID: fixtureSession, SessionKind: sessckpt.SessionKindDirect,
        LeaseEpoch: 1, LeaseID: fixtureLeaseA, CreatorHostID: fixtureLocalHost,
        WorkspaceManifestID: seedDigest(0xE1), ProviderManifestID: seedDigest(0xE2),
        Boundary: sessckpt.SafeBoundary{ProviderID: "codex", ProviderVersion: "0.147.0", Evidence: sessckpt.EvidenceAcceptedTest,
            InputBlocked: true, ForegroundIdle: true, BackgroundIdle: true, OpenProcesses: 0, OpenDatabaseHandles: 0},
        EventHeads: []string{changed}, CreatedAt: fixtureCreatedAt, Extensions: map[string]string{},
    })
    if err != nil { t.Fatalf("Capture(winning handoff) error = %v", err) }
    checkpointID := checkpoint.CheckpointID
    leases, err := world.repo.ListLeases(fixtureSession)
    if err != nil || len(leases) != 1 { t.Fatalf("ListLeases() = %v, %v; want epoch-1 lease", leases, err) }
    if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
        CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: "cccccccc-dddd-4eee-8fff-000000000002", HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt},
        Reason: "graceful_takeover", CheckpointID: checkpointID,
    }); err != nil { t.Fatalf("CompareAndSwapLease() error = %v", err) }
    return world
}

func measureSetProfileOutcome(t *testing.T, input string, world *runWorld, request sessprofile.SetProfileRequest) {
    t.Helper()
    result, err := (&sessprofile.Transactor{Repo: world.repo}).SetProfile(request)
    emitSetProfileOutcome(t, input, result, err)
}

func TestProfileSourceOutcomeGrid(t *testing.T) {
    measureProfileSourcePair(t, "LoadProfile", "post_takeover_lower_epoch", sourceProbeLosingWorld, sourceProbeLoadPair)
    measureProfileSourcePair(t, "Projector.Project", "post_takeover_lower_epoch", sourceProbeLosingWorld, sourceProbeProjectorPair)
    measureProfileSourcePair(t, "Projector.ProjectForHeads", "post_takeover_lower_epoch", sourceProbeLosingWorld, sourceProbeProjectorForHeadsPair)
    measureProfileSourcePair(t, "axpane.deriveProfile", "post_takeover_lower_epoch", sourceProbeLosingWorld, sourceProbeDeriveProfilePair)
    measureProfileSourcePair(t, "LoadProfile", "unminted_higher_epoch", sourceProbeHigherEpochWorld, sourceProbeLoadPair)
    measureProfileSourcePair(t, "Projector.Project", "unminted_higher_epoch", sourceProbeHigherEpochWorld, sourceProbeProjectorPair)
    measureProfileSourcePair(t, "Projector.ProjectForHeads", "unminted_higher_epoch", sourceProbeHigherEpochWorld, sourceProbeProjectorForHeadsPair)
    measureProfileSourcePair(t, "axpane.deriveProfile", "unminted_higher_epoch", sourceProbeHigherEpochWorld, sourceProbeDeriveProfilePair)
    measureProfileSourcePair(t, "LoadProfile", "empty_lease_store", sourceProbeEmptyLeaseWorld, sourceProbeLoadPair)
    measureProfileSourcePair(t, "Projector.Project", "empty_lease_store", sourceProbeEmptyLeaseWorld, sourceProbeProjectorPair)
    measureProfileSourcePair(t, "Projector.ProjectForHeads", "empty_lease_store", sourceProbeEmptyLeaseWorld, sourceProbeProjectorForHeadsPair)
    measureProfileSourcePair(t, "axpane.deriveProfile", "empty_lease_store", sourceProbeEmptyLeaseWorld, sourceProbeDeriveProfilePair)
    measureProfileSourcePair(t, "LoadProfile", "unminted_same_epoch_loser", sourceProbeAmbiguousTupleWorld, sourceProbeLoadPair)
    measureProfileSourcePair(t, "Projector.Project", "unminted_same_epoch_loser", sourceProbeAmbiguousTupleWorld, sourceProbeProjectorPair)
    measureProfileSourcePair(t, "Projector.ProjectForHeads", "unminted_same_epoch_loser", sourceProbeAmbiguousTupleWorld, sourceProbeProjectorForHeadsPair)
    measureProfileSourcePair(t, "axpane.deriveProfile", "unminted_same_epoch_loser", sourceProbeAmbiguousTupleWorld, sourceProbeDeriveProfilePair)
    measureProfileSourcePair(t, "Projector.Project", "winning_handoff_contains_prior_source", sourceProbeWinningHandoffWorld, sourceProbeProjectorPair)
    measureProfileSourcePair(t, "Projector.ProjectForHeads", "winning_handoff_contains_prior_source", sourceProbeWinningHandoffWorld, sourceProbeProjectorForHeadsPair)

    losing := sourceProbeLosingWorld(t)
    measureSetProfileOutcome(t, "post_takeover_lower_epoch", losing, sessprofile.SetProfileRequest{
        SessionID: fixtureSession, To: sessprofile.ProfileYOLO, Confirmed: true, LeaseEpoch: 1, LeaseID: fixtureLeaseA,
        CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
    })
    ambiguous := sourceProbeAmbiguousTupleWorld(t)
    measureSetProfileOutcome(t, "unminted_same_epoch_loser", ambiguous, sessprofile.SetProfileRequest{
        SessionID: fixtureSession, To: sessprofile.ProfileYOLO, Confirmed: true, LeaseEpoch: 2, LeaseID: fixtureLeaseA,
        CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
    })
    current := buildRunWorld(t)
    measureSetProfileOutcome(t, "winning_lease_standard_to_yolo", current, sessprofile.SetProfileRequest{
        SessionID: fixtureSession, To: sessprofile.ProfileYOLO, Confirmed: true, LeaseEpoch: 1, LeaseID: fixtureLeaseA,
        CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
    })
}
