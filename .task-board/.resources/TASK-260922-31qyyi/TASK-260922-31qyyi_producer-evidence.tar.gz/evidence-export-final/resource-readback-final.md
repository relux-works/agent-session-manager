# Final task-board resource readback

The following authoritative-board resources matched local artifact bytes exactly after download with `task-board resource get`:

| Resource | Local SHA-256 |
| --- | --- |
| `TASK-260922-31qyyi_results.md` | `9c5291492c1d296c32e8f7bf9d99b5512eb15e6324e35181becddf2d84faff8e` |
| `TASK-260922-31qyyi_conformance-matrix.md` | `52d96bcdadf5c9f43011388a7e5aa2051e6cfa1f31231f798579314c051a20bc` |
| `TASK-260922-31qyyi_board-validation.log` | `d393dad333d6cb6c2beb85fde372c36c8f8305215995e4dd91dfb2f64142e6c0` |

The evidence archive is read back and byte-compared separately because it contains this receipt.
