# TASK-260922-31qyyi revision 2 evidence bundle

The bundle contains the accepted base probe-15 reproduction, raw M1/M2 mutant logs and exact rows, the complete importer outcome comparison, final configured validation logs, final board validation output, the rev1 verdict and rework brief, and the relevant candidate sources. The large isolated mutation source copies are intentionally excluded; their exact edits are described by `mutants/mutants.json` and the included runner source.

The base probe-15 log is prior attached evidence and was accepted for this handoff; it was not rerun during final validation. Candidate validation commands and exits are recorded in `validation/` and summarized in the included results and conformance matrix.
