package sessprofile

import (
	"testing"

	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

// Reviewer probe: a profile.changed appended legitimately by lease A after
// the checkpoint that lease B's takeover names. Real append gate stays on.
func TestReviewProbeLosingTailOutsideHandoffClosure(t *testing.T) {
	repository := openTestRepository(t)
	reference := createTestSession(t, repository, testSessionID, "payments-api", ProfileStandard)
	created := appendTestEvent(t, repository, testSessionID, []string{reference.RecordID}, 1, testLeaseID, 1, "session.created", createdPayload(reference.RecordID))
	checkpoints, checkpointID := captureProfileHandoff(t, repository, []string{created})
	change := appendTestEvent(t, repository, testSessionID, []string{created}, 1, testLeaseID, 2, "profile.changed", changedPayload(ProfileStandard, ProfileYOLO, true))
	leases, _ := repository.ListLeases(testSessionID)
	if _, err := repository.CompareAndSwapLease(testSessionID, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: testLeaseIDB, HolderHostID: testHostID, IssuedByHostID: testHostID, CreatedAt: testCreatedAt},
		Reason:           "graceful_takeover", CheckpointID: checkpointID,
	}); err != nil {
		t.Fatalf("CAS: %v", err)
	}
	pair, err := (&Projector{Repo: repository, Ckpt: checkpoints}).Project(testSessionID)
	t.Logf("Project = %+v err=%v (tail %s)", pair, err, change)
	if err != nil || pair.HasSource || pair.Profile != ProfileStandard {
		t.Fatalf("losing tail became source: %+v %v", pair, err)
	}
}
