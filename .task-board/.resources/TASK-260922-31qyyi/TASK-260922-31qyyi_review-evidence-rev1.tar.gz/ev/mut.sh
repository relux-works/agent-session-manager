#!/bin/zsh
# usage: mut.sh NAME PERLEXPR ; runs in normal and instrumented copies
name=$1; expr=$2
for base in cand inst; do
  rm -rf m_$base; cp -R $base m_$base
  cp m_$base/internal/sessprofile/authority.go /tmp/orig.go
  perl -0pi -e "$expr" m_$base/internal/sessprofile/authority.go
  if cmp -s /tmp/orig.go m_$base/internal/sessprofile/authority.go; then echo "$name $base NOT_APPLIED"; continue; fi
  (cd m_$base && go test ./internal/sessprofile/ ./internal/axpane/ 2>&1 | grep -E "^--- FAIL" | sort -u | tr '\n' ' ' > /tmp/f; echo "$name $base fails: $(cat /tmp/f)")
done
