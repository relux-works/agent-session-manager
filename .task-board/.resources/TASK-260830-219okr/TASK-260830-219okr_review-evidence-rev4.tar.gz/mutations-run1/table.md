| Mutant | What the gate is narrowed to admit | Named failing test | Exit | Result / surviving bound |
| --- | --- | --- | --- | --- |
| neutral | Equivalent major value | none | 0 | neutral passed:  |
| config1-admits-3 | Admits major 3 for Config-1 only | TestNegotiateMatrix/1.0.0-x-3.0.0 | 1 | killed:  |
| config2-admits-4 | Admits major 4 for Config-2 only | TestNegotiateMatrix/2.0.0-x-4.0.0 | 1 | killed:  |
| config3-admits-5 | Admits major 5 for Config-3 only | TestNegotiateMatrix/3.0.0-x-5.0.0 | 1 | killed:  |
| config4-admits-4 | Admits major 4 for Config-4 only | TestConfig4NeverDowngrades | 1 | killed:  |
| unknown-config-admits-9 | Admits generation 9.9.9 as Config-4 only | TestLocalMajors/unknown-9.9.9 | 1 | killed:  |
| frame-admits-2.1 | Admits frame 2.1.0 as major 2 only | TestPeerOfferRefusals/frame-versions | 1 | killed:  |
| shape-admits-extra-key | Admits exactly one extra contracts key | TestPeerOfferRefusals/shape/extra-error-key | 1 | killed:  |
| shape-admits-missing-lease | Admits a missing lease key only | TestPeerOfferRefusals/shape/substituted-key | 1 | killed:  |
| rpc-admits-17 | Admits exactly 17 rpc versions | TestPeerOfferRefusals/shape/seventeen-rpc | 1 | killed:  |
| rpc-admits-nil-empty | Admits a nil rpc array while still refusing an empty non-nil one | TestPeerOfferRefusals/shape/empty-rpc | 1 | killed:  |
| mixed-admits-v3-in-v2 | Admits major 3 inside a major-2 frame only | TestPeerOfferRefusals/mixed/two-majors-in-v2 | 1 | killed:  |
| mixed-admits-unsorted-pair | Admits the 2.1.0/2.0.0 descending pair only | TestPeerOfferRefusals/mixed/unsorted | 1 | killed:  |
| mixed-admits-v-prefix-value | Admits the value v2.0.0 as the framing major only | TestPeerOfferRefusals/mixed/not-semver | 1 | killed:  |
| v3-exact-admits-3.0.1 | Admits rpc [3.0.1] in a v3 frame only | TestPeerOfferRefusals/shape/v3-inexact-rpc | 1 | killed:  |
| select-admits-local-6 | Admits local major 6 only | TestSelectHighestCommon/refuse-local-names-6 | 1 | killed:  |
| select-admits-peer-1 | Admits peer major 1 only | TestSelectHighestCommon/refuse-peer-mixes-1-with-common | 1 | killed:  |
| select-picks-lowest | Selects the lowest common major instead of the highest | TestSelectHighestCommon/admit-highest-wins | 1 | killed:  |
| select-admits-disjoint-2v3 | Admits the disjoint pair 2-against-3 as success | TestSelectHighestCommon/refuse-disjoint | 1 | killed:  |
| exposure-directory-at-2 | Reports directory negotiated at major 2 | TestPeerExposure/2.0.0 | 1 | killed:  |
| exposure-backend-at-3 | Reports backend evidence negotiated at major 3 | TestPeerExposure/3.0.0 | 1 | killed:  |
| error-binding-provider-contract | Resolves the error binding under the provider contract | TestDecisionShapes/3.0.0 | 1 | killed:  |
| refusal-code-transport-failure | Peer refusals carry transport_failure instead of incompatible_protocol | TestNegotiateMatrix/3.0.0-x-5.0.0 | 1 | killed:  |
| directory-version-1.0.0 | Resolves directory exposure under Error 1.0.0 | TestPeerExposure/2.0.0 | 1 | killed:  |
| backend-version-1.2.0 | Resolves backend exposure under Error 1.2.0 | TestPeerExposure/2.0.0 | 1 | killed:  |
| major-extract-plus-one | Version grammar unchanged; extracted major shifted by one | TestNegotiateMatrix | 1 | killed:  |
| semver-admits-v-prefix | Admits v-prefixed versions as their major | TestPeerOfferRefusals/mixed/not-semver | 1 | killed:  |
| reason-shape-reports-mixed | Shape refusals misreport as mixed_major | TestPeerOfferRefusals/shape/extra-error-key | 1 | killed:  |
| exposure-directory-code-swap | Directory exposure carries continuation_route_unavailable (same 1.2.0/exit 6) instead of the Section 11.8 token | TestPeerExposure/2.0.0 | 1 | killed:  |
| exposure-backend-code-swap | Backend exposure carries terminal_backend_capability_unproven (same 1.3.0/exit 6) instead of the bound RPC-4 token | TestPeerExposure/2.0.0 | 1 | killed:  |
| negotiate-unknown-falls-back | Unknown configuration falls back to legacy [2 3 4] at the Negotiate site instead of refusing | TestNegotiateUnknownGeneration | 1 | killed:  |
| frame-admits-5.1 | Admits frame 5.1.0 as major 5 only | TestPeerOfferRefusals/frame-versions | 1 | killed:  |
| detail-text | Human Detail text only | none | 0 | survived: Human Detail text only; no test branches on it (harmless applied control, must survive). |
