package meshneg_test

// Reviewer probe: derive the per-major hello contract maps from the pinned
// specification text itself (Sections 11.2, 11.8, 11.9, 11.10.1) and require
// the Decision produced by the production entry to equal them exactly.

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/meshneg"
	"github.com/relux-works/agent-session-manager/internal/specpin"
)

func specText(t *testing.T) string {
	t.Helper()
	raw, err := os.ReadFile(filepath.Join("..", "specdoc", "SPEC.v0.6.0.md"))
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(raw)
	if hex.EncodeToString(sum[:]) != specpin.DocumentSHA256V060 {
		t.Fatalf("spec digest %s != pinned %s", hex.EncodeToString(sum[:]), specpin.DocumentSHA256V060)
	}
	return string(raw)
}

func section(t *testing.T, text, heading, next string) string {
	t.Helper()
	start := strings.Index(text, "\n"+heading)
	if start < 0 {
		t.Fatalf("heading %q not found", heading)
	}
	rest := text[start+1:]
	end := strings.Index(rest, "\n"+next)
	if end < 0 {
		t.Fatalf("heading %q not found after %q", next, heading)
	}
	return rest[:end]
}

var jsonBlock = regexp.MustCompile("(?s)~~~json\n(.*?)\n~~~")

func contractsFromBlock(t *testing.T, block string, nested bool) map[string][]string {
	t.Helper()
	var contracts map[string][]string
	if nested {
		var envelope struct {
			Body struct {
				Contracts map[string][]string `json:"contracts"`
			} `json:"body"`
		}
		if err := json.Unmarshal([]byte(block), &envelope); err != nil {
			t.Fatal(err)
		}
		contracts = envelope.Body.Contracts
	} else if err := json.Unmarshal([]byte(block), &contracts); err != nil {
		t.Fatal(err)
	}
	if len(contracts) == 0 {
		t.Fatal("empty contracts block")
	}
	return contracts
}

func TestReviewSpecDerivedShapesRev4(t *testing.T) {
	text := specText(t)
	s112 := section(t, text, "### 11.2 RPC framing and handshake", "### 11.3 ")
	s118 := section(t, text, "### 11.8 Mesh RPC 3.0.0 directory replication", "### 11.9 ")
	s119 := section(t, text, "### 11.9 Mesh RPC 4.0.0 TerminalBackend evidence replication", "### 11.10 ")
	blocks112 := jsonBlock.FindAllStringSubmatch(s112, -1)
	if len(blocks112) < 2 {
		t.Fatalf("11.2 json blocks = %d", len(blocks112))
	}
	v2req := contractsFromBlock(t, blocks112[0][1], true)
	v2res := contractsFromBlock(t, blocks112[1][1], true)
	if !reflect.DeepEqual(v2req, v2res) {
		t.Fatal("11.2 request and response contract maps differ")
	}
	b118 := jsonBlock.FindAllStringSubmatch(s118, -1)
	b119 := jsonBlock.FindAllStringSubmatch(s119, -1)
	if len(b118) != 1 || len(b119) != 1 {
		t.Fatalf("11.8/11.9 json blocks = %d/%d", len(b118), len(b119))
	}
	v3 := contractsFromBlock(t, b118[0][1], false)
	v4 := contractsFromBlock(t, b119[0][1], false)
	v5 := map[string][]string{}
	for k, v := range v4 {
		v5[k] = append([]string(nil), v...)
	}
	v5["rpc"] = []string{"5.0.0"} // 11.10.1: exact RPC-4 map with contracts.rpc ["5.0.0"]
	if len(v2req) != 14 || len(v3) != 24 || len(v4) != 25 || len(v5) != 25 {
		t.Fatalf("spec key counts = %d/%d/%d/%d", len(v2req), len(v3), len(v4), len(v5))
	}
	expected := map[string]struct {
		contracts  map[string][]string
		namespaces int
		generation string
		errVersion axerror.Version
	}{
		"2.0.0": {v2req, 6, "1.0.0", axerror.Version100},
		"3.0.0": {v3, 7, "2.0.0", axerror.Version120},
		"4.0.0": {v4, 8, "3.0.0", axerror.Version130},
		"5.0.0": {v5, 8, "4.0.0", axerror.Version130},
	}
	for frame, want := range expected {
		hello := decodedHello(t, frame, want.contracts) // the spec map itself must decode
		decision, err := meshneg.Negotiate(want.generation, frame, hello)
		if err != nil {
			t.Fatalf("%s: %v", frame, err)
		}
		if !reflect.DeepEqual(decision.Contracts, want.contracts) {
			t.Fatalf("%s: Decision.Contracts differ from the spec block", frame)
		}
		if len(decision.Namespaces) != want.namespaces {
			t.Fatalf("%s: namespaces %v", frame, decision.Namespaces)
		}
		if decision.ErrorVersion != want.errVersion {
			t.Fatalf("%s: error version %s", frame, decision.ErrorVersion)
		}
		// Every spec key with any single value changed is refused through decode
		// (rpcwire) — the composed path; the negotiator's own re-validation of
		// the key SET is measured separately by the per-key sweep.
		for key := range want.contracts {
			tampered := map[string][]string{}
			for k, v := range want.contracts {
				tampered[k] = append([]string(nil), v...)
			}
			delete(tampered, key)
			tampered["x_"+key] = []string{"1.0.0"}
			if _, err := meshneg.PeerOffer(frame, directHello(t, tampered)); err == nil {
				t.Fatalf("%s: PeerOffer admitted a hello with %q substituted", frame, key)
			}
		}
	}
	// Namespace vocabulary per 11.8/11.9 prose.
	s3 := section(t, text, "### 11.8 Mesh RPC 3.0.0 directory replication", "### 11.9 ")
	for _, name := range []string{"record", "event", "manifest", "tombstone", "tombstone_ack", "blob", "directory_record"} {
		if !strings.Contains(s3, "<code>"+name+"</code>") {
			t.Fatalf("11.8 prose lacks namespace %s", name)
		}
	}
	d3, _ := meshneg.Negotiate("3.0.0", "3.0.0", decodedHello(t, "3.0.0", v3))
	if !reflect.DeepEqual(d3.Namespaces, []string{"blob", "directory_record", "event", "manifest", "record", "tombstone", "tombstone_ack"}) {
		t.Fatalf("v3 namespaces %v", d3.Namespaces)
	}
	d4, _ := meshneg.Negotiate("3.0.0", "4.0.0", decodedHello(t, "4.0.0", v4))
	if !reflect.DeepEqual(d4.Namespaces, []string{"blob", "directory_record", "event", "manifest", "record", "terminal_backend_evidence", "tombstone", "tombstone_ack"}) {
		t.Fatalf("v4 namespaces %v", d4.Namespaces)
	}
	// 15.3 registry rows: both exposure codes are literally in the 1.2.0 / 1.3.0 exit-6 rows.
	s153 := section(t, text, "### 15.3 Stable error codes", "## 16")
	if !regexp.MustCompile(`\| 6 \| <code>directory_mesh_unsupported</code>`).MatchString(s153) {
		t.Fatal("15.3 lacks the 1.2.0 exit-6 directory_mesh_unsupported row")
	}
	if !regexp.MustCompile(`\| 6 \| <code>terminal_backend_unavailable</code>`).MatchString(s153) {
		t.Fatal("15.3 lacks the 1.3.0 exit-6 terminal_backend_unavailable row")
	}
	// 11.8 literal exposure token appears in the prose as the pinned token.
	if !strings.Contains(s118, "<code>directory_mesh_unsupported</code>, never as zero inventory") {
		t.Fatal("11.8 prose changed: directory_mesh_unsupported/never-zero-inventory sentence not found")
	}
	if strings.Contains(s119, "terminal_backend_unavailable") {
		t.Log("11.9 names terminal_backend_unavailable literally")
	} else {
		t.Log("11.9 names NO literal code for the backend exposure (binding choice: registered 1.3.0 exit-6 code terminal_backend_unavailable)")
	}
	t.Logf("spec-derived shapes: 4 of 4 majors equal; per-key substitution refused by PeerOffer for %d keys", 14+24+25+25)
}
