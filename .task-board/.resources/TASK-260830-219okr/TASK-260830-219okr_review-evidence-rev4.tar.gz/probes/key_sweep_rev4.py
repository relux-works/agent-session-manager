#!/usr/bin/env python3
"""Per-key sweep of the PeerOffer membership gate: plant `key != "<K>"` for every
distinct hello contract key and run the COMMITTED suite. Reports how many keys
the committed suite pins. usage: key_sweep_rev4.py CANDIDATE_ROOT OUT_DIR"""
import json, subprocess, sys
from pathlib import Path
ROOT, OUT = (Path(a).resolve() for a in sys.argv[1:3])
SRC = ROOT / "internal/meshneg/negotiate.go"
KEYS = ["rpc", "session_record", "session_event", "lease", "checkpoint", "workspace_group", "provider_identity", "blob",
        "transfer_manifest", "chunk", "materialization_plan", "tombstone", "tombstone_ack", "task_board_bundle",
        "environment_observation", "native_session_observation", "session_inventory_batch", "conversation_lineage_link",
        "session_annotation", "session_enrichment_profile", "session_enrichment_job_request", "session_enrichment_job_receipt",
        "session_continuation_plan", "session_directory_operation_receipt", "terminal_backend_evidence"]
OLD = 'if _, ok := hello.Contracts[key]; !ok {'
text = SRC.read_text()
assert text.count(OLD) == 1
rows = []
for key in KEYS:
    folder = OUT / key; folder.mkdir(parents=True, exist_ok=True)
    repl = folder / "negotiate.go"
    repl.write_text(text.replace(OLD, f'if _, ok := hello.Contracts[key]; !ok && key != "{key}" {{', 1))
    overlay = folder / "overlay.json"; overlay.write_text(json.dumps({"Replace": {str(SRC): str(repl)}}))
    cmd = ["go", "test", "-overlay", str(overlay), "./internal/meshneg", "-count=1", "-json", "-timeout=120s", "-run", "Test"]
    proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (folder / "test.log").write_bytes(proc.stdout); (folder / "exit").write_text(f"{proc.returncode}\n")
    events = [json.loads(l) for l in proc.stdout.decode(errors="replace").splitlines() if l.startswith("{")]
    failed = [e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    state = "KILLED" if proc.returncode != 0 and failed else ("SURVIVED" if passed else "COMPILE_FAIL")
    rows.append({"key": key, "state": state, "exit": proc.returncode, "failing": failed[:6]})
    print(f"{key}: {state} exit={proc.returncode} failing={failed[:3]}", flush=True)
killed = [r["key"] for r in rows if r["state"] == "KILLED"]
print(f"membership gate per-key pin: {len(killed)} of {len(rows)} keys killed by the committed suite: {killed}")
(OUT / "results.json").write_text(json.dumps(rows, indent=1) + "\n")
