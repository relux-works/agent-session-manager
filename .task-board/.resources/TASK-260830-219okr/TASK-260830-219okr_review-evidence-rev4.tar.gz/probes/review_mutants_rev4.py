#!/usr/bin/env python3
"""Reviewer plants for CR-TASK-260830-219okr-4 (isolated candidate copy, overlay-only).
Run with PYTHONDONTWRITEBYTECODE=1. Each plant keeps the gate present and admits one
member of the refused class (or swaps a same-exit class token), then runs the COMMITTED
behavioral suite (reviewer zz_review files held out) via -overlay.
usage: review_mutants_rev4.py CANDIDATE_ROOT OUT_DIR [--only a,b] """
import json, subprocess, sys
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
ONLY = None
if len(sys.argv) > 4 and sys.argv[3] == "--only":
    ONLY = set(sys.argv[4].split(","))
SRC = ROOT / "internal/meshneg/negotiate.go"
# name, old, new, expected committed killer (prefix match), kind, expectation
PLANTS = [
 # --- rev3 survivors: must DIE on the rev4 tree ---
 ("R8-frame-admits-5.1", '"5.0.0": 5,', '"5.0.0": 5,\n\t"5.1.0": 5,',
  'TestPeerOfferRefusals/frame-versions', 'narrowing', 'KILLED'),
 ("R12-negotiate-unknown-config-falls-back-to-legacy",
  'local, err := LocalMajors(configVersion)\n\tif err != nil {\n\t\treturn Decision{}, err\n\t}',
  'local, err := LocalMajors(configVersion)\n\tif err != nil {\n\t\tlocal = []int{2, 3, 4}\n\t}',
  'TestNegotiateUnknownGeneration', 'narrowing', 'KILLED'),
 ("R19-directory-code-swap-same-exit",
  'DirectoryUnsupportedCode = axerror.Code("directory_mesh_unsupported")',
  'DirectoryUnsupportedCode = axerror.Code("continuation_route_unavailable")',
  'TestPeerExposure/2.0.0', 'class-swap-same-exit', 'KILLED'),
 ("R20-backend-code-swap-same-exit",
  'BackendEvidenceUnsupportedCode = axerror.Code("terminal_backend_unavailable")',
  'BackendEvidenceUnsupportedCode = axerror.Code("terminal_backend_capability_unproven")',
  'TestPeerExposure', 'class-swap-same-exit', 'KILLED'),
 # --- rev3 kills: regression on the rev4 tree ---
 ("R1-dup-admitted", 'offered[index-1] >= version', 'offered[index-1] > version',
  'TestPeerOfferRefusals/mixed/duplicate', 'narrowing', 'KILLED'),
 ("R2-negotiate-peer-set-plus-5", 'major, err := Select(local, []int{peer})', 'major, err := Select(local, []int{peer, 5})',
  'TestConfig4NeverDowngrades', 'narrowing', 'KILLED'),
 ("R3-select-admits-5-without-peer",
  'if slices.Contains(peer, candidate) && candidate > best {', 'if (slices.Contains(peer, candidate) || candidate == 5) && candidate > best {',
  'TestConfig4NeverDowngrades', 'narrowing', 'KILLED'),
 ("R4-shape-admits-any-extra-keys", 'if len(hello.Contracts) != len(profile) {', 'if len(hello.Contracts) < len(profile) {',
  'TestPeerOfferRefusals/shape/extra-error-key', 'narrowing', 'KILLED'),
 ("R5-exposure-code-when-negotiated",
  'if negotiated {\n\t\treturn activation, nil\n\t}', 'if negotiated {\n\t\tactivation.Code = code\n\t\treturn activation, nil\n\t}',
  'TestPeerExposure/3.0.0', 'narrowing', 'KILLED'),
 ("R6-v5-exact-exempt",
  'if frameVersion != "2.0.0" && !slices.Equal(offered, profile["rpc"]) {', 'if frameVersion != "2.0.0" && frameVersion != "5.0.0" && !slices.Equal(offered, profile["rpc"]) {',
  'TestPeerOfferRefusals/shape/v5-inexact-rpc', 'narrowing', 'KILLED'),
 ("R7-refusal-code-same-exit", 'Code:     axerror.Code("incompatible_protocol"),', 'Code:     axerror.Code("capability_unavailable"),',
  'TestNegotiateMatrix/3.0.0-x-5.0.0', 'class-swap-same-exit', 'KILLED'),
 ("R9-unknown-config-4.0.1", 'case "4.0.0":', 'case "4.0.0", "4.0.1":',
  'TestLocalMajors/unknown-4.0.1', 'narrowing', 'KILLED'),
 ("R13-negotiate-malformed-offer-trusts-frame",
  'peer, err := PeerOffer(frameVersion, hello)\n\tif err != nil {',
  'peer, err := PeerOffer(frameVersion, hello)\n\tif err != nil {\n\t\tif framing, pinned := pinnedFrameVersions[frameVersion]; pinned {\n\t\t\tpeer, err = framing, nil\n\t\t}\n\t}\n\tif err != nil {',
  'TestNoFallbackSurface/extension-member', 'narrowing', 'KILLED'),
 ("R16-activation-gains-inventory-member", 'type FeatureActivation struct {', 'type FeatureActivation struct {\n\tInventory int',
  'TestExposureCarriesNoInventory', 'structural', 'KILLED'),
 ("R17-peerview-gains-count-member", 'type PeerView struct {', 'type PeerView struct {\n\tCount int',
  'TestExposureCarriesNoInventory', 'structural', 'KILLED'),
 ("R18-invalid-config-same-exit-code-swap", 'Code:     axerror.Code("invalid_config"),', 'Code:     axerror.Code("local_precondition_failed"),',
  'TestLocalMajors/unknown-', 'class-swap-same-exit', 'KILLED'),
 # --- rev4 reviewer plants on arms/members the producer did not mutate ---
 ("S1-frame-admits-3.0.1", '"3.0.0": 3,', '"3.0.0": 3,\n\t"3.0.1": 3,',
  'TestPeerOfferRefusals/frame-versions', 'narrowing', 'KILLED'),
 ("S2-frame-admits-4.1.0", '"4.0.0": 4,', '"4.0.0": 4,\n\t"4.1.0": 4,',
  'TestPeerOfferRefusals/frame-versions', 'narrowing', 'KILLED'),
 ("S3-config4-admits-3", 'return []int{5}, nil', 'return []int{3, 5}, nil',
  'TestConfig4NeverDowngrades', 'narrowing', 'KILLED'),
 ("S4-dup-admitted-for-2.0.0-only", 'offered[index-1] >= version', '(offered[index-1] >= version && !(offered[index-1] == "2.0.0" && version == "2.0.0"))',
  'TestPeerOfferRefusals/mixed/duplicate', 'narrowing', 'KILLED'),
 ("S5-sort-check-skips-first-pair", 'if index > 0 && offered[index-1] >= version {', 'if index > 1 && offered[index-1] >= version {',
  'TestPeerOfferRefusals/mixed/duplicate', 'narrowing', 'KILLED'),
 ("S6-count-admits-one-fewer-key-subsumed", 'if len(hello.Contracts) != len(profile) {', 'if len(hello.Contracts) != len(profile) && len(hello.Contracts) != len(profile)-1 {',
  None, 'subsumption-check', 'SURVIVED-equivalent (membership loop refuses the missing key; TestPeerOfferRefusals/shape/missing-key still passes)'),
 ("S7-membership-skips-checkpoint", 'if _, ok := hello.Contracts[key]; !ok {', 'if _, ok := hello.Contracts[key]; !ok && key != "checkpoint" {',
  None, 'narrowing', 'unknown (only lease is pinned by substituted-key)'),
 ("S8-membership-skips-task_board_bundle", 'if _, ok := hello.Contracts[key]; !ok {', 'if _, ok := hello.Contracts[key]; !ok && key != "task_board_bundle" {',
  None, 'narrowing', 'unknown'),
 ("S9-membership-skips-terminal_backend_evidence", 'if _, ok := hello.Contracts[key]; !ok {', 'if _, ok := hello.Contracts[key]; !ok && key != "terminal_backend_evidence" {',
  None, 'narrowing', 'unknown'),
 ("S10-v4-exact-exempt",
  'if frameVersion != "2.0.0" && !slices.Equal(offered, profile["rpc"]) {', 'if frameVersion != "2.0.0" && frameVersion != "4.0.0" && !slices.Equal(offered, profile["rpc"]) {',
  'TestPeerOfferRefusals/shape/v4-inexact-rpc', 'narrowing', 'KILLED'),
 ("S11-select-skips-4", 'if slices.Contains(peer, candidate) && candidate > best {', 'if slices.Contains(peer, candidate) && candidate > best && candidate != 4 {',
  'TestSelectHighestCommon/admit-highest-wins', 'narrowing', 'KILLED'),
 ("S12-negotiate-drops-local-fact-on-offer-refusal", 'refusal.Local = append([]int(nil), local...)', 'refusal.Local = nil',
  None, 'reporting-fact', 'unknown (Local fact on PeerOffer refusals through Negotiate)'),
 ("S13-select-drops-peer-fact", 'if len(peer) == 1 {\n\t\t\tpeerMajor = peer[0]\n\t\t}', 'if len(peer) == 1 {\n\t\t\tpeerMajor = 0\n\t\t}',
  'TestLegacyNeverSelectsRPC5', 'reporting-fact', 'KILLED'),
 ("S14-local-vocab-admits-1", 'for _, major := range local {\n\t\tif major < 2 || major > 5 {', 'for _, major := range local {\n\t\tif major < 1 || major > 5 {',
  None, 'narrowing', 'unknown (Select direct-call surface only; LocalMajors never yields 1)'),
 ("S15-directory-negotiated-inverted", 'exposure("directory", major >= directoryFeatureMajor,', 'exposure("directory", major < directoryFeatureMajor,',
  'TestPeerExposure', 'narrowing', 'KILLED'),
 ("S16-config2-admits-4-not-3", 'return []int{2, 3}, nil', 'return []int{2, 4}, nil',
  'TestNegotiateMatrix/2.0.0-x-3.0.0', 'narrowing', 'KILLED'),
 ("S17-unknown-config-empty-string-admitted", 'case "1.0.0":', 'case "1.0.0", "":',
  'TestNegotiateUnknownGeneration', 'narrowing', 'KILLED'),
 ("S18-exposure-exit-hardcoded-6", 'activation.ExitCode = exit', 'activation.ExitCode = 6\n\t_ = exit',
  None, 'equivalent-check', 'SURVIVED-equivalent (registry value is 6; exit still resolved so a wrong-version plant fails closed)'),
 # --- controls ---
 ("C1-control-sentinel-text", 'errors.New("hello contracts differ from the pinned profile")', 'errors.New("hello contracts do not match the pinned profile")',
  None, 'control-must-survive', 'SURVIVED'),
 ("C2-control-detail-text", '"frame version %q is outside the pinned 2.0.0-5.0.0 vocabulary"', '"frame version %q is not a pinned vocabulary member"',
  None, 'control-must-survive', 'SURVIVED'),
]
OUT.mkdir(parents=True, exist_ok=True)
original = SRC.read_bytes()
text = original.decode()
rows = []
for name, old, new, expected, kind, expectation in PLANTS:
    if ONLY and name not in ONLY:
        continue
    if text.count(old) != 1:
        raise SystemExit(f"{name}: anchor matched {text.count(old)} times")
    folder = OUT / name; folder.mkdir(exist_ok=True)
    repl = folder / "negotiate.go"; repl.write_text(text.replace(old, new, 1))
    overlay = folder / "overlay.json"; overlay.write_text(json.dumps({"Replace": {str(SRC): str(repl)}}))
    cmd = ["go", "test", "-overlay", str(overlay), "./internal/meshneg", "-count=1", "-json", "-timeout=120s", "-run", "Test"]
    proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (folder / "test.log").write_bytes(proc.stdout)
    (folder / "exit").write_text(f"{proc.returncode}\n")
    events = []
    for line in proc.stdout.decode(errors="replace").splitlines():
        try: events.append(json.loads(line))
        except json.JSONDecodeError: pass
    failed = [e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    compiled = bool(passed) or bool(failed)
    if not compiled:
        state = "COMPILE_FAIL/NOT_RUN"
    elif proc.returncode != 0 and failed:
        state = "KILLED"
    else:
        state = "SURVIVED"
    expected_hit = expected is not None and any(f == expected or f.startswith(expected) for f in failed)
    if SRC.read_bytes() != original: raise SystemExit("source mutated!")
    rows.append({"mutant": name, "kind": kind, "exit": proc.returncode, "state": state,
                 "expected_killer": expected, "expected_hit": expected_hit, "expectation": expectation,
                 "failing": failed[:12], "n_failing": len(failed), "n_passing": len(passed)})
    print(f"{name}: {state} exit={proc.returncode} killer={expected} hit={expected_hit} failing={len(failed)} passing={len(passed)}", flush=True)
(OUT / "results.json").write_text(json.dumps(rows, indent=1) + "\n")
lines = ["| Mutant | Kind | State | Exit | Expected committed killer | Hit | Failing tests (first 6) |", "|---|---|---|---:|---|---|---|"]
for r in rows:
    lines.append(f'| {r["mutant"]} | {r["kind"]} | {r["state"]} | {r["exit"]} | {r["expected_killer"] or "-"} | {r["expected_hit"]} | {", ".join(r["failing"][:6]) or "none"} |')
(OUT / "table.md").write_text("\n".join(lines) + "\n")
