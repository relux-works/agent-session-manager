package meshneg_test

// Reviewer probes for CR-TASK-260830-219okr-4 (RUN-260917-b1ebcb). Held out of
// the committed suite; added through -overlay in the isolated candidate copy.

import (
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"reflect"
	"slices"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/meshneg"
	"github.com/relux-works/agent-session-manager/internal/rpcwire"
)

// generationMajors is derived from the pinned text, not from LocalMajors:
// 6.4 (Config-2 pairs with RPC 3), 6.5 (Config-3 pairs with RPC 4), 6.6
// (Config-4 requires RPC 5 for every peer, never legacy), 11.8/11.9 dual-stack.
var generationMajors = map[string][]int{
	"1.0.0": {2},
	"2.0.0": {2, 3},
	"3.0.0": {2, 3, 4},
	"4.0.0": {5},
}

var pinnedFrames = []string{"2.0.0", "3.0.0", "4.0.0", "5.0.0"}

func exitFor(t *testing.T, version axerror.Version, code axerror.Code) int {
	t.Helper()
	exit, err := axerror.ExitCodeFor(version, code)
	if err != nil {
		t.Fatal(err)
	}
	return exit
}

func requireZeroDecision(t *testing.T, decision meshneg.Decision) {
	t.Helper()
	if !reflect.DeepEqual(decision, meshneg.Decision{}) {
		t.Fatalf("refusal returned a non-zero Decision: %+v", decision)
	}
}

func requireRefusal(t *testing.T, err error, code axerror.Code, exit int, reason meshneg.RefusalReason, sentinel error) *meshneg.Refusal {
	t.Helper()
	refusal := asRefusal(t, err)
	if refusal.Code != code || refusal.ExitCode != exit {
		t.Fatalf("class = %s/%d, want %s/%d", refusal.Code, refusal.ExitCode, code, exit)
	}
	if refusal.Reason != reason {
		t.Fatalf("reason = %q, want %q", refusal.Reason, reason)
	}
	if !errors.Is(err, sentinel) {
		t.Fatalf("error %v does not wrap %v", err, sentinel)
	}
	return refusal
}

// TestReviewPairTableRev4 drives every (generation x frame) pair through the
// production entry; expected outcome derived from generationMajors.
func TestReviewPairTableRev4(t *testing.T) {
	incompatible := exitFor(t, axerror.Version100, "incompatible_protocol")
	invalidConfig := exitFor(t, axerror.Version100, "invalid_config")
	if incompatible != 6 || invalidConfig != 3 {
		t.Fatalf("registry exits = %d/%d", incompatible, invalidConfig)
	}
	rows := 0
	for _, generation := range []string{"1.0.0", "2.0.0", "3.0.0", "4.0.0"} {
		for _, frame := range pinnedFrames {
			rows++
			peerMajor := int(frame[0] - '0')
			want := 0
			if slices.Contains(generationMajors[generation], peerMajor) {
				want = peerMajor
			}
			t.Run(generation+"-x-"+frame, func(t *testing.T) {
				hello := decodedHello(t, frame, profileContracts(t, frame))
				decision, err := meshneg.Negotiate(generation, frame, hello)
				if want == 0 {
					refusal := requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
					requireZeroDecision(t, decision)
					if !slices.Equal(refusal.Local, generationMajors[generation]) || refusal.Peer != peerMajor {
						t.Fatalf("refusal facts local=%v peer=%d", refusal.Local, refusal.Peer)
					}
					return
				}
				if err != nil {
					t.Fatal(err)
				}
				if decision.Major != want || decision.ProtocolVersion != frame {
					t.Fatalf("selected %d/%s, want %d/%s", decision.Major, decision.ProtocolVersion, want, frame)
				}
				profile, _ := rpcwire.ContractProfile(frame)
				if !reflect.DeepEqual(decision.Contracts, profile) {
					t.Fatalf("contracts differ from the pinned profile")
				}
				wantDirectory := want >= 3
				wantBackend := want >= 4
				if decision.Peer.Directory.Negotiated != wantDirectory || decision.Peer.BackendEvidence.Negotiated != wantBackend {
					t.Fatalf("exposure = %+v", decision.Peer)
				}
				if !wantDirectory && (decision.Peer.Directory.Code != "directory_mesh_unsupported" || decision.Peer.Directory.ExitCode != 6) {
					t.Fatalf("directory exposure = %+v", decision.Peer.Directory)
				}
				if !wantBackend && (decision.Peer.BackendEvidence.Code != "terminal_backend_unavailable" || decision.Peer.BackendEvidence.ExitCode != 6) {
					t.Fatalf("backend exposure = %+v", decision.Peer.BackendEvidence)
				}
				if wantDirectory && (decision.Peer.Directory.Code != "" || decision.Peer.Directory.ExitCode != 0) {
					t.Fatalf("negotiated directory carries a code: %+v", decision.Peer.Directory)
				}
				if wantBackend && (decision.Peer.BackendEvidence.Code != "" || decision.Peer.BackendEvidence.ExitCode != 0) {
					t.Fatalf("negotiated backend carries a code: %+v", decision.Peer.BackendEvidence)
				}
				wantError := map[int]axerror.Version{2: axerror.Version100, 3: axerror.Version120, 4: axerror.Version130, 5: axerror.Version130}[want]
				if decision.ErrorVersion != wantError {
					t.Fatalf("error version = %s, want %s", decision.ErrorVersion, wantError)
				}
			})
		}
	}
	unknown := []string{"", "5.0.0", "9.9.9", "4.0.1", "0.0.0", "3.0.0-rc1", "4.0.0+build", " 4.0.0", "4.0.0\n", "04.0.0", "1.0", "1"}
	for _, generation := range unknown {
		for _, frame := range pinnedFrames {
			rows++
			t.Run("unknown-"+fmt.Sprintf("%q", generation)+"-x-"+frame, func(t *testing.T) {
				hello := decodedHello(t, frame, profileContracts(t, frame))
				decision, err := meshneg.Negotiate(generation, frame, hello)
				refusal := requireRefusal(t, err, "invalid_config", invalidConfig, meshneg.ReasonUnknownConfig, meshneg.ErrUnknownConfig)
				requireZeroDecision(t, decision)
				if len(refusal.Local) != 0 || refusal.Peer != 0 {
					t.Fatalf("unknown-generation refusal carries offer facts %+v", refusal)
				}
			})
		}
	}
	t.Logf("pair rows driven: %d (16 known-generation, %d unknown-generation)", rows, rows-16)
}

// TestReviewHostileOffersRev4 plants hostile offers at the production entry.
func TestReviewHostileOffersRev4(t *testing.T) {
	incompatible := exitFor(t, axerror.Version100, "incompatible_protocol")
	v2 := func() map[string][]string { return profileContracts(t, "2.0.0") }
	withRPC := func(frame string, rpc []string) map[string][]string {
		m := profileContracts(t, frame)
		m["rpc"] = rpc
		return m
	}
	type hostile struct {
		name       string
		generation string
		frame      string
		contracts  map[string][]string
		reason     meshneg.RefusalReason
		sentinel   error
	}
	cases := []hostile{
		{"v3-frame-carrying-14-key-v2-map", "3.0.0", "3.0.0", v2(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v4-frame-carrying-14-key-v2-map", "3.0.0", "4.0.0", v2(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v5-frame-carrying-14-key-v2-map", "4.0.0", "5.0.0", v2(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v2-frame-carrying-24-keys", "3.0.0", "2.0.0", profileContracts(t, "3.0.0"), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v2-frame-carrying-25-keys", "3.0.0", "2.0.0", profileContracts(t, "4.0.0"), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v5-frame-carrying-24-key-v3-map", "4.0.0", "5.0.0", profileContracts(t, "3.0.0"), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"v5-frame-carrying-v4-map", "4.0.0", "5.0.0", profileContracts(t, "4.0.0"), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor}, // same 25 keys; refused at rpc ["4.0.0"] vs framing 5
		{"v4-frame-carrying-v5-map", "3.0.0", "4.0.0", profileContracts(t, "5.0.0"), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor}, // same 25 keys; refused at rpc ["5.0.0"] vs framing 4
		{"unsorted-rpc", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.1.0", "2.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"unsorted-lexical-10-vs-9", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.9.0", "2.10.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"duplicate-rpc", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.0.0", "2.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"duplicate-rpc-three", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.0.0", "2.1.0", "2.1.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"multi-major-2-3-in-v2", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.0.0", "3.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"multi-major-2-to-5-in-v2", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"2.0.0", "3.0.0", "4.0.0", "5.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"multi-major-4-5-in-v5", "4.0.0", "5.0.0", withRPC("5.0.0", []string{"4.0.0", "5.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"rpc-6-in-v5", "4.0.0", "5.0.0", withRPC("5.0.0", []string{"6.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"rpc-5.1.0-in-v5", "4.0.0", "5.0.0", withRPC("5.0.0", []string{"5.1.0"}), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"rpc-1.0.0-in-v2", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"1.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"rpc-v-prefix", "3.0.0", "2.0.0", withRPC("2.0.0", []string{"v2.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"rpc-range-syntax", "3.0.0", "2.0.0", withRPC("2.0.0", []string{">=2.0.0"}), meshneg.ReasonMixedMajor, meshneg.ErrMixedMajor},
		{"rpc-empty", "3.0.0", "2.0.0", withRPC("2.0.0", []string{}), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"rpc-nil", "3.0.0", "2.0.0", withRPC("2.0.0", nil), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"rpc-missing-key", "3.0.0", "2.0.0", func() map[string][]string { m := v2(); delete(m, "rpc"); return m }(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"rpc-key-substituted", "3.0.0", "2.0.0", func() map[string][]string {
			m := v2()
			delete(m, "rpc")
			m["rpc_version"] = []string{"2.0.0"}
			return m
		}(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"extension-key-v2", "3.0.0", "2.0.0", func() map[string][]string { m := v2(); m["extensions"] = []string{"1.0.0"}; return m }(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"fallback-hint-key", "3.0.0", "2.0.0", func() map[string][]string { m := v2(); m["fallback"] = []string{"2.0.0"}; return m }(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"error-key", "3.0.0", "2.0.0", func() map[string][]string { m := v2(); m["error"] = []string{"1.0.0"}; return m }(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"host-channel-key-v5", "4.0.0", "5.0.0", func() map[string][]string {
			m := profileContracts(t, "5.0.0")
			m["host_channel"] = []string{"1.0.0"}
			return m
		}(), meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"nil-contracts", "3.0.0", "2.0.0", nil, meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"empty-contracts", "3.0.0", "2.0.0", map[string][]string{}, meshneg.ReasonContractShape, meshneg.ErrContractShape},
		{"seventeen-rpc", "3.0.0", "2.0.0", withRPC("2.0.0", func() []string {
			out := []string{}
			for i := range 17 {
				out = append(out, fmt.Sprintf("2.0.%d", 10+i))
			}
			return out
		}()), meshneg.ReasonContractShape, meshneg.ErrContractShape},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			decision, err := meshneg.Negotiate(tc.generation, tc.frame, directHello(t, tc.contracts))
			refusal := requireRefusal(t, err, "incompatible_protocol", incompatible, tc.reason, tc.sentinel)
			requireZeroDecision(t, decision)
			if refusal.Peer != 0 {
				t.Fatalf("malformed offer reported a peer major %d", refusal.Peer)
			}
			if !slices.Equal(refusal.Local, generationMajors[tc.generation]) {
				t.Fatalf("refusal local facts = %v, want %v", refusal.Local, generationMajors[tc.generation])
			}
		})
	}
	t.Run("frame-6.0.0", func(t *testing.T) {
		for _, generation := range []string{"1.0.0", "2.0.0", "3.0.0", "4.0.0"} {
			decision, err := meshneg.Negotiate(generation, "6.0.0", directHello(t, profileContracts(t, "5.0.0")))
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonUnsupportedFrame, meshneg.ErrUnsupportedFrame)
			requireZeroDecision(t, decision)
		}
	})
	t.Run("frame-edges", func(t *testing.T) {
		for _, frame := range []string{"2.0.1", "2.1.0", "3.0.1", "3.1.0", "4.0.1", "4.1.0", "5.0.1", "5.1.0", "1.0.0", "0.0.0", "6.0.0", "5.0.0-rc1", "5.0.0+build", "v5.0.0", "05.0.0", "5.0", "5", "", " 5.0.0", "5.0.0 "} {
			decision, err := meshneg.Negotiate("4.0.0", frame, directHello(t, profileContracts(t, "5.0.0")))
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonUnsupportedFrame, meshneg.ErrUnsupportedFrame)
			requireZeroDecision(t, decision)
		}
	})
	t.Run("5.0.0-offer-to-config-3", func(t *testing.T) {
		decision, err := meshneg.Negotiate("3.0.0", "5.0.0", decodedHello(t, "5.0.0", profileContracts(t, "5.0.0")))
		refusal := requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
		requireZeroDecision(t, decision)
		if !slices.Equal(refusal.Local, []int{2, 3, 4}) || refusal.Peer != 5 {
			t.Fatalf("facts %+v", refusal)
		}
	})
	t.Run("legacy-offers-to-config-4", func(t *testing.T) {
		for _, frame := range []string{"2.0.0", "3.0.0", "4.0.0"} {
			decision, err := meshneg.Negotiate("4.0.0", frame, decodedHello(t, frame, profileContracts(t, frame)))
			refusal := requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
			requireZeroDecision(t, decision)
			if !slices.Equal(refusal.Local, []int{5}) || refusal.Peer != int(frame[0]-'0') {
				t.Fatalf("facts %+v", refusal)
			}
		}
	})
	t.Run("env-argv-cannot-select-fallback-for-config-4", func(t *testing.T) {
		t.Setenv("AX_RPC_MAJOR", "2")
		t.Setenv("AX_ALLOW_LEGACY", "1")
		t.Setenv("AX_HOST_CHANNEL", "0")
		t.Setenv("AX_CONFIG_GENERATION", "3.0.0")
		argv := os.Args
		t.Cleanup(func() { os.Args = argv })
		os.Args = []string{"ax", "rpc", "serve", "--stdio", "--legacy", "--rpc-major=2", "--allow-legacy", "--host-channel", "0"}
		for _, frame := range []string{"2.0.0", "3.0.0", "4.0.0"} {
			decision, err := meshneg.Negotiate("4.0.0", frame, decodedHello(t, frame, profileContracts(t, frame)))
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
			requireZeroDecision(t, decision)
		}
	})
	t.Run("failed-handshake-retry-cannot-downgrade", func(t *testing.T) {
		legacy := decodedHello(t, "2.0.0", profileContracts(t, "2.0.0"))
		five := decodedHello(t, "5.0.0", profileContracts(t, "5.0.0"))
		for range 5 {
			decision, err := meshneg.Negotiate("4.0.0", "2.0.0", legacy)
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
			requireZeroDecision(t, decision)
		}
		decision, err := meshneg.Negotiate("4.0.0", "5.0.0", five)
		if err != nil || decision.Major != 5 {
			t.Fatalf("valid RPC 5 after failed attempts: %+v %v", decision, err)
		}
		decision, err = meshneg.Negotiate("4.0.0", "2.0.0", legacy)
		requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
		requireZeroDecision(t, decision)
		// And the legacy direction: a Config-3 node offered RPC 5 three times, then a
		// valid 4.0.0 offer: no state selects 5 and no state refuses 4.
		for range 3 {
			decision, err := meshneg.Negotiate("3.0.0", "5.0.0", five)
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
			requireZeroDecision(t, decision)
		}
		decision, err = meshneg.Negotiate("3.0.0", "4.0.0", decodedHello(t, "4.0.0", profileContracts(t, "4.0.0")))
		if err != nil || decision.Major != 4 {
			t.Fatalf("valid RPC 4 after failed attempts: %+v %v", decision, err)
		}
	})
}

// TestReviewDecisionNeverCopiesPeerBytesRev4: a decode-valid v2 range offer
// selects major 2 and the Decision carries the pinned profile, not the peer's
// array.
func TestReviewDecisionNeverCopiesPeerBytesRev4(t *testing.T) {
	m := profileContracts(t, "2.0.0")
	m["rpc"] = []string{"2.0.0", "2.1.0", "2.2.0-rc.1"}
	m["lease"] = []string{"1.0.0", "1.1.0"}
	hello := decodedHello(t, "2.0.0", m)
	for _, generation := range []string{"1.0.0", "2.0.0", "3.0.0"} {
		decision, err := meshneg.Negotiate(generation, "2.0.0", hello)
		if err != nil {
			t.Fatal(err)
		}
		if decision.Major != 2 || decision.ProtocolVersion != "2.0.0" {
			t.Fatalf("v2 range selected %d/%s", decision.Major, decision.ProtocolVersion)
		}
		profile, _ := rpcwire.ContractProfile("2.0.0")
		if !reflect.DeepEqual(decision.Contracts, profile) {
			t.Fatalf("decision contracts copied from the peer: rpc=%v lease=%v", decision.Contracts["rpc"], decision.Contracts["lease"])
		}
		if decision.Peer.Directory.Code != "directory_mesh_unsupported" || decision.Peer.BackendEvidence.Code != "terminal_backend_unavailable" {
			t.Fatalf("exposure %+v", decision.Peer)
		}
		// The Decision's map must not alias the profile owner's map: a caller
		// writing into it cannot change a later decision.
		decision.Contracts["rpc"] = []string{"9.9.9"}
		again, err := meshneg.Negotiate(generation, "2.0.0", hello)
		if err != nil {
			t.Fatal(err)
		}
		if !slices.Equal(again.Contracts["rpc"], []string{"2.0.0"}) {
			t.Fatalf("decision contracts alias shared state: %v", again.Contracts["rpc"])
		}
		profile2, _ := rpcwire.ContractProfile("2.0.0")
		if !slices.Equal(profile2["rpc"], []string{"2.0.0"}) {
			t.Fatalf("rpcwire profile mutated through a decision: %v", profile2["rpc"])
		}
	}
}

// TestReviewExposureLiteralTokensRev4 pins the AC tokens as literals at the
// production entry for every core-only pairing.
func TestReviewExposureLiteralTokensRev4(t *testing.T) {
	type want struct {
		directory, backend axerror.Code
	}
	cases := map[[2]string]want{
		{"2.0.0", "2.0.0"}: {"directory_mesh_unsupported", "terminal_backend_unavailable"},
		{"3.0.0", "2.0.0"}: {"directory_mesh_unsupported", "terminal_backend_unavailable"},
		{"1.0.0", "2.0.0"}: {"directory_mesh_unsupported", "terminal_backend_unavailable"},
		{"2.0.0", "3.0.0"}: {"", "terminal_backend_unavailable"},
		{"3.0.0", "3.0.0"}: {"", "terminal_backend_unavailable"},
		{"3.0.0", "4.0.0"}: {"", ""},
		{"4.0.0", "5.0.0"}: {"", ""},
	}
	for pair, w := range cases {
		decision, err := meshneg.Negotiate(pair[0], pair[1], decodedHello(t, pair[1], profileContracts(t, pair[1])))
		if err != nil {
			t.Fatal(err)
		}
		if decision.Peer.Directory.Code != w.directory || decision.Peer.BackendEvidence.Code != w.backend {
			t.Fatalf("%v: exposure %+v", pair, decision.Peer)
		}
		if (w.directory != "") != !decision.Peer.Directory.Negotiated || (w.backend != "") != !decision.Peer.BackendEvidence.Negotiated {
			t.Fatalf("%v: negotiated flags %+v", pair, decision.Peer)
		}
		// Exposure exits resolve under the version registering the code, and
		// the code is registered under the negotiated major's bound version.
		for _, activation := range []meshneg.FeatureActivation{decision.Peer.Directory, decision.Peer.BackendEvidence} {
			if activation.Negotiated {
				continue
			}
			if activation.ExitCode != 6 {
				t.Fatalf("%v: exposure exit %d", pair, activation.ExitCode)
			}
		}
	}
	// JSON view: no member of the exposure can read as an inventory or count.
	decision, err := meshneg.Negotiate("3.0.0", "2.0.0", decodedHello(t, "2.0.0", profileContracts(t, "2.0.0")))
	if err != nil {
		t.Fatal(err)
	}
	raw, err := json.Marshal(decision.Peer)
	if err != nil {
		t.Fatal(err)
	}
	var view map[string]map[string]any
	if err := json.Unmarshal(raw, &view); err != nil {
		t.Fatal(err)
	}
	for feature, members := range view {
		for key, value := range members {
			switch value.(type) {
			case float64:
				if key != "ExitCode" {
					t.Fatalf("%s.%s is numeric (%v): a zero could read as inventory", feature, key, value)
				}
			case []any, map[string]any:
				t.Fatalf("%s.%s is a collection: an empty one could read as zero inventory", feature, key)
			}
		}
	}
}

// TestReviewSelectVocabularyBothSidesRev4 pins the documented Select input
// vocabulary (2/3/4/5) for every out-of-vocabulary member on BOTH sides,
// including members beside a common pinned major.
func TestReviewSelectVocabularyBothSidesRev4(t *testing.T) {
	incompatible := exitFor(t, axerror.Version100, "incompatible_protocol")
	for _, outside := range []int{-1, 0, 1, 6, 7, 99} {
		for _, side := range []string{"local", "peer"} {
			local, peer := []int{2, 3}, []int{2, 3}
			if side == "local" {
				local = []int{outside, 2, 3}
			} else {
				peer = []int{outside, 2, 3}
			}
			got, err := meshneg.Select(local, peer)
			if got != 0 {
				t.Fatalf("Select(%v, %v) = %d, want refusal", local, peer, got)
			}
			requireRefusal(t, err, "incompatible_protocol", incompatible, meshneg.ReasonNoCommonMajor, meshneg.ErrNoCommonMajor)
		}
	}
}
