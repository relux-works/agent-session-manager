#!/usr/bin/env python3
"""Kill-control for the rev4 reviewer survivors: run the REVIEWER probe suite
(committed suite + zz_review files) against each surviving overlay. A survivor
the reviewer instrument kills is a measured gap in the committed suite; one the
instrument also passes is equivalent (or the instrument is blind to it).
usage: survivor_control_rev4.py CANDIDATE_ROOT RUN_DIR OUT_DIR PROBES_DIR"""
import json, subprocess, sys
from pathlib import Path
ROOT, RUN, OUT, PROBES = (Path(a).resolve() for a in sys.argv[1:5])
SRC = ROOT / "internal/meshneg/negotiate.go"
rows = []
for name in ["S6-count-admits-one-fewer-key-subsumed", "S7-membership-skips-checkpoint", "S8-membership-skips-task_board_bundle",
             "S9-membership-skips-terminal_backend_evidence", "S12-negotiate-drops-local-fact-on-offer-refusal",
             "S14-local-vocab-admits-1", "S18-exposure-exit-hardcoded-6", "C1-control-sentinel-text", "C2-control-detail-text"]:
    mutant = RUN / name / "negotiate.go"
    folder = OUT / name; folder.mkdir(parents=True, exist_ok=True)
    overlay = folder / "overlay.json"
    overlay.write_text(json.dumps({"Replace": {
        str(SRC): str(mutant),
        str(ROOT / "internal/meshneg/zz_review_rev4_test.go"): str(PROBES / "zz_review_rev4_test.go"),
        str(ROOT / "internal/meshneg/zz_review_spec_rev4_test.go"): str(PROBES / "zz_review_spec_rev4_test.go"),
    }}))
    cmd = ["go", "test", "-overlay", str(overlay), "./internal/meshneg", "-count=1", "-json", "-timeout=120s", "-run", "Test"]
    proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (folder / "test.log").write_bytes(proc.stdout)
    (folder / "exit").write_text(f"{proc.returncode}\n")
    events = [json.loads(l) for l in proc.stdout.decode(errors="replace").splitlines() if l.startswith("{")]
    failed = [e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    state = "KILLED-by-reviewer-probe" if proc.returncode != 0 and failed else ("SURVIVED-reviewer-probe" if passed else "COMPILE_FAIL")
    reviewer_killers = sorted({f.split("/")[0] for f in failed if f.startswith("TestReview")})
    committed_killers = sorted({f.split("/")[0] for f in failed if not f.startswith("TestReview")})
    rows.append({"mutant": name, "exit": proc.returncode, "state": state, "reviewer_killers": reviewer_killers,
                 "committed_killers": committed_killers, "n_failing": len(failed), "n_passing": len(passed)})
    print(f"{name}: {state} exit={proc.returncode} reviewer_killers={reviewer_killers} committed_killers={committed_killers}", flush=True)
(OUT / "results.json").write_text(json.dumps(rows, indent=1) + "\n")
