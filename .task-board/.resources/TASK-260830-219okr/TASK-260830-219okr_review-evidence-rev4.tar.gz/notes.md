# TASK-260830-219okr rev4 review — instruments and commands (RUN-260917-b1ebcb)

Isolated candidate copy: `git archive a774eff57f43060bb0ab14b75e9236b50cc114f2 | tar -x -C .temp/TASK-260830-219okr/rev4-review/candidate`
(`diff -rq --exclude=.git --exclude=.temp <live worktree> candidate` empty; patch sha256 re-derived from `git diff --binary 888ae3d..a774eff` == attached `79957f1b…`).
All commands below ran inside the candidate copy; the live Story worktree/index/branch/HEAD were never mutated.

| Step | Command (cwd = candidate) | Log | Exit |
| --- | --- | --- | --- |
| readiness | `go version` (go1.25.5 darwin/arm64), `python3 --version` (3.14.7) | logs/tool-readiness.log | 0 |
| gofmt | `gofmt -l $(find . -name '*.go' -not -path './.temp/*')` (579 files) | logs/gofmt.log | 0 (empty) |
| build/vet | `go build ./...`; `go vet ./...` | logs/go-build.log, logs/go-vet.log | 0 / 0 |
| meshneg verbose | `go test ./internal/meshneg -count=1 -v` | logs/test-meshneg-verbose.log | 0 (18 top-level, 184 PASS lines) |
| owners | `go test ./internal/meshneg ./internal/rpcwire ./internal/hostchannel ./internal/axerror ./internal/config -count=1` | logs/test-owners.log | 0 |
| owners race | `go test ./internal/meshneg ./internal/rpcwire ./internal/hostchannel -race -count=1` | logs/test-owners-race.log | 0 |
| coverage | `go test ./internal/meshneg -race -count=1 -cover` | logs/test-meshneg-race-cover.log | 0 (87.8%) |
| producer harness ×2 | `PYTHONDONTWRITEBYTECODE=1 python3 internal/meshneg/mutations.py --output <evidence>/mutations-runN` | logs/mutations-run1.log, logs/mutations-run2.log; mutations-runN/{results.json,table.md,<plant>/test.log} | 0 / 0 |
| reviewer probes ×2 | `go test -overlay ../probes/overlay-add.json ./internal/meshneg -count=1 -run TestReview -v` (adds zz_review_rev4_test.go + zz_review_spec_rev4_test.go) | logs/review-probes-run1.log, logs/review-probes-run2.log | 0 / 0 (107 PASS lines each) |
| reviewer mutants ×2 | `PYTHONDONTWRITEBYTECODE=1 python3 probes/review_mutants_rev4.py candidate <evidence>/review-mutants-runN` (36 plants, committed suite only) | logs/review-mutants-runN.log; review-mutants-runN/{results.json,table.md,<plant>/test.log,<plant>/exit} | 0 / 0 |
| survivor kill-control | `PYTHONDONTWRITEBYTECODE=1 python3 probes/survivor_control_rev4.py candidate <evidence>/review-mutants-run1 <evidence>/survivor-control probes` (survivors + controls against the reviewer probe suite) | logs/survivor-control.log; survivor-control/<plant>/test.log | 0 |
| per-key sweep | `PYTHONDONTWRITEBYTECODE=1 python3 probes/key_sweep_rev4.py candidate <evidence>/key-sweep` (25 plants `key != "<K>"`) | logs/key-sweep.log; key-sweep/<key>/test.log | 0 (1 of 25 killed: lease) |
| tracecheck | `go run ./internal/traceability/cmd/tracecheck` | logs/tracecheck.log | 0 |
| cataloggen | `go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check` (catalog_gen.go unchanged) | logs/cataloggen-check.log | 0 |
| cross builds | `GOOS=linux GOARCH=amd64 go build ./...`; `GOOS=windows GOARCH=amd64 go build ./...` | logs/build-linux.log, logs/build-windows.log | 0 / 0 |
| admission separation | `go doc -all ./internal/hostchannel | grep '^func'`; grep for meshneg importers | logs/hostchannel-exported-signatures.log | — |
| full suite (non-race) | `go test ./... -count=1` | logs/test-all.log | 0 (38 ok) |

`producer-results-as-attached.json` is the producer's `mutations-meshneg/results.json` from `TASK-260830-219okr_producer-evidence.tar.gz`, kept for the row-by-row comparison (33 rows agree with both reruns).
No `__pycache__`/`.pyc` was created (all harnesses ran with PYTHONDONTWRITEBYTECODE=1; `find candidate -name __pycache__` empty).
