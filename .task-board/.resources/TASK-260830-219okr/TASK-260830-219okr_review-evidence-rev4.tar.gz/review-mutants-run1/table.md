| Mutant | Kind | State | Exit | Expected committed killer | Hit | Failing tests (first 6) |
|---|---|---|---:|---|---|---|
| R8-frame-admits-5.1 | narrowing | KILLED | 1 | TestPeerOfferRefusals/frame-versions | True | TestPeerOfferRefusals/frame-versions, TestPeerOfferRefusals |
| R12-negotiate-unknown-config-falls-back-to-legacy | narrowing | KILLED | 1 | TestNegotiateUnknownGeneration | True | TestNegotiateUnknownGeneration/unknown--x-2.0.0, TestNegotiateUnknownGeneration/unknown--x-3.0.0, TestNegotiateUnknownGeneration/unknown--x-4.0.0, TestNegotiateUnknownGeneration/unknown--x-5.0.0, TestNegotiateUnknownGeneration/unknown-5.0.0-x-2.0.0, TestNegotiateUnknownGeneration/unknown-5.0.0-x-3.0.0 |
| R19-directory-code-swap-same-exit | class-swap-same-exit | KILLED | 1 | TestPeerExposure/2.0.0 | True | TestPeerExposure/2.0.0, TestPeerExposure |
| R20-backend-code-swap-same-exit | class-swap-same-exit | KILLED | 1 | TestPeerExposure | True | TestPeerExposure/2.0.0, TestPeerExposure/3.0.0, TestPeerExposure |
| R1-dup-admitted | narrowing | KILLED | 1 | TestPeerOfferRefusals/mixed/duplicate | True | TestPeerOfferRefusals/mixed/duplicate, TestPeerOfferRefusals/mixed, TestPeerOfferRefusals |
| R2-negotiate-peer-set-plus-5 | narrowing | KILLED | 1 | TestConfig4NeverDowngrades | True | TestConfig4NeverDowngrades, TestLegacyNeverSelectsRPC5, TestNegotiateMatrix/4.0.0-x-2.0.0, TestNegotiateMatrix/4.0.0-x-3.0.0, TestNegotiateMatrix/4.0.0-x-4.0.0, TestNegotiateMatrix |
| R3-select-admits-5-without-peer | narrowing | KILLED | 1 | TestConfig4NeverDowngrades | True | TestConfig4NeverDowngrades, TestNegotiateMatrix/4.0.0-x-2.0.0, TestNegotiateMatrix/4.0.0-x-3.0.0, TestNegotiateMatrix/4.0.0-x-4.0.0, TestNegotiateMatrix, TestSelectHighestCommon/refuse-config4-against-legacy |
| R4-shape-admits-any-extra-keys | narrowing | KILLED | 1 | TestPeerOfferRefusals/shape/extra-error-key | True | TestNoFallbackSurface/extension-member, TestNoFallbackSurface, TestPeerOfferRefusals/shape/v3-bound-in-v2-frame, TestPeerOfferRefusals/shape/extra-error-key, TestPeerOfferRefusals/shape/extra-extension-key, TestPeerOfferRefusals/shape |
| R5-exposure-code-when-negotiated | narrowing | KILLED | 1 | TestPeerExposure/3.0.0 | True | TestPeerExposure/3.0.0, TestPeerExposure/4.0.0, TestPeerExposure/5.0.0, TestPeerExposure |
| R6-v5-exact-exempt | narrowing | KILLED | 1 | TestPeerOfferRefusals/shape/v5-inexact-rpc | True | TestPeerOfferRefusals/shape/v5-inexact-rpc, TestPeerOfferRefusals/shape, TestPeerOfferRefusals |
| R7-refusal-code-same-exit | class-swap-same-exit | KILLED | 1 | TestNegotiateMatrix/3.0.0-x-5.0.0 | True | TestLegacyNeverSelectsRPC5, TestNegotiateMatrix/1.0.0-x-3.0.0, TestNegotiateMatrix/1.0.0-x-4.0.0, TestNegotiateMatrix/1.0.0-x-5.0.0, TestNegotiateMatrix/2.0.0-x-4.0.0, TestNegotiateMatrix/2.0.0-x-5.0.0 |
| R9-unknown-config-4.0.1 | narrowing | KILLED | 1 | TestLocalMajors/unknown-4.0.1 | True | TestLocalMajors/unknown-4.0.1, TestLocalMajors, TestNegotiateUnknownGeneration/unknown-4.0.1-x-2.0.0, TestNegotiateUnknownGeneration/unknown-4.0.1-x-3.0.0, TestNegotiateUnknownGeneration/unknown-4.0.1-x-4.0.0, TestNegotiateUnknownGeneration/unknown-4.0.1-x-5.0.0 |
| R13-negotiate-malformed-offer-trusts-frame | narrowing | KILLED | 1 | TestNoFallbackSurface/extension-member | True | TestNoFallbackSurface/extension-member, TestNoFallbackSurface |
| R16-activation-gains-inventory-member | structural | KILLED | 1 | TestExposureCarriesNoInventory | True | TestExposureCarriesNoInventory |
| R17-peerview-gains-count-member | structural | KILLED | 1 | TestExposureCarriesNoInventory | True | TestExposureCarriesNoInventory |
| R18-invalid-config-same-exit-code-swap | class-swap-same-exit | KILLED | 1 | TestLocalMajors/unknown- | True | TestLocalMajors/unknown-, TestLocalMajors/unknown-5.0.0, TestLocalMajors/unknown-3.0, TestLocalMajors/unknown-v4.0.0, TestLocalMajors/unknown-4.0.1, TestLocalMajors/unknown-4 |
| S1-frame-admits-3.0.1 | narrowing | KILLED | 1 | TestPeerOfferRefusals/frame-versions | True | TestPeerOfferRefusals/frame-versions, TestPeerOfferRefusals |
| S2-frame-admits-4.1.0 | narrowing | KILLED | 1 | TestPeerOfferRefusals/frame-versions | True | TestPeerOfferRefusals/frame-versions, TestPeerOfferRefusals |
| S3-config4-admits-3 | narrowing | KILLED | 1 | TestConfig4NeverDowngrades | True | TestConfig4NeverDowngrades, TestLocalMajors/config-4.0.0, TestLocalMajors, TestLocalMajorsTracksConfigVocabulary, TestNegotiateMatrix/4.0.0-x-3.0.0, TestNegotiateMatrix |
| S4-dup-admitted-for-2.0.0-only | narrowing | KILLED | 1 | TestPeerOfferRefusals/mixed/duplicate | True | TestPeerOfferRefusals/mixed/duplicate, TestPeerOfferRefusals/mixed, TestPeerOfferRefusals |
| S5-sort-check-skips-first-pair | narrowing | KILLED | 1 | TestPeerOfferRefusals/mixed/duplicate | True | TestPeerOfferRefusals/mixed/duplicate, TestPeerOfferRefusals/mixed/unsorted, TestPeerOfferRefusals/mixed, TestPeerOfferRefusals |
| S6-count-admits-one-fewer-key-subsumed | subsumption-check | SURVIVED | 0 | - | False | none |
| S7-membership-skips-checkpoint | narrowing | SURVIVED | 0 | - | False | none |
| S8-membership-skips-task_board_bundle | narrowing | SURVIVED | 0 | - | False | none |
| S9-membership-skips-terminal_backend_evidence | narrowing | SURVIVED | 0 | - | False | none |
| S10-v4-exact-exempt | narrowing | KILLED | 1 | TestPeerOfferRefusals/shape/v4-inexact-rpc | True | TestPeerOfferRefusals/shape/v4-inexact-rpc, TestPeerOfferRefusals/shape, TestPeerOfferRefusals |
| S11-select-skips-4 | narrowing | KILLED | 1 | TestSelectHighestCommon/admit-highest-wins | True | TestPeerExposure/4.0.0, TestPeerExposure, TestNegotiateMatrix/3.0.0-x-4.0.0, TestNegotiateMatrix, TestSelectHighestCommon/admit-highest-wins, TestSelectHighestCommon/admit-legacy-peak |
| S12-negotiate-drops-local-fact-on-offer-refusal | reporting-fact | SURVIVED | 0 | - | False | none |
| S13-select-drops-peer-fact | reporting-fact | KILLED | 1 | TestLegacyNeverSelectsRPC5 | True | TestLegacyNeverSelectsRPC5 |
| S14-local-vocab-admits-1 | narrowing | SURVIVED | 0 | - | False | none |
| S15-directory-negotiated-inverted | narrowing | KILLED | 1 | TestPeerExposure | True | TestPeerExposure/2.0.0, TestPeerExposure/3.0.0, TestPeerExposure/4.0.0, TestPeerExposure/5.0.0, TestPeerExposure |
| S16-config2-admits-4-not-3 | narrowing | KILLED | 1 | TestNegotiateMatrix/2.0.0-x-3.0.0 | True | TestLocalMajors/config-2.0.0, TestLocalMajors, TestLocalMajorsTracksConfigVocabulary, TestNegotiateMatrix/2.0.0-x-3.0.0, TestNegotiateMatrix/2.0.0-x-4.0.0, TestNegotiateMatrix |
| S17-unknown-config-empty-string-admitted | narrowing | KILLED | 1 | TestNegotiateUnknownGeneration | True | TestLocalMajors/unknown-, TestLocalMajors, TestNegotiateUnknownGeneration/unknown--x-2.0.0, TestNegotiateUnknownGeneration/unknown--x-3.0.0, TestNegotiateUnknownGeneration/unknown--x-4.0.0, TestNegotiateUnknownGeneration/unknown--x-5.0.0 |
| S18-exposure-exit-hardcoded-6 | equivalent-check | SURVIVED | 0 | - | False | none |
| C1-control-sentinel-text | control-must-survive | SURVIVED | 0 | - | False | none |
| C2-control-detail-text | control-must-survive | SURVIVED | 0 | - | False | none |
