# TASK-260830-219okr review notes (rev3, RUN-260917-92b548)

Candidate: base 888ae3d, tree a9d0ffe9 (working tree == candidate tree via temp index; CR patch == git diff base..tree, sha256 67bbeede... matches).
origin/main == 888ae3d at review start (no drift).
Isolated probe copy: .temp/TASK-260830-219okr/review/candidate (git archive of tree a9d0ffe9). Live worktree never mutated.

## Baseline (isolated copy)
- gofmt -l internal/meshneg: clean; go vet ./internal/meshneg: exit 0
- go test ./internal/meshneg -count=1 -v: exit 0, 145 RUN / 145 PASS / 0 FAIL
- go test ./internal/meshneg -race -count=1 -cover: ok, 87.8%
- go test meshneg rpcwire hostchannel -count=1: all ok (hostchannel 27.2s); -race: all ok (hostchannel 61.0s)
- meshneg has NO production importers (grep); direct imports exact: errors fmt regexp slices strconv strings + axerror rpcwire
- transitive closure DOES reach os/io/net/time/rand/exec via rpcwire->sshtransport, axerror->catalog...; the four consulted owner fns (ContractProfile, Namespaces, ExitCodeFor, BindingFor) are pure map/switch lookups (read).

## Spec extraction (SPEC.v0.6.0.md, sha256 74504539... == specpin.DocumentSHA256V060)
- 6.6: Config-4 every peer requires Host Channel 1 and RPC 5; unknown/missing/partial config is a refusal never legacy selection; no byte sniffing/extension/argv host UUID/env/failed handshake selects a fallback; legacy 2/3/4 dual-stack obligations only for explicitly legacy installations, never require Config-4 to accept legacy.
- 11.2: 14-key contracts map, each 1-16 sorted unique semver; RPC 2.x binds Error 1.0.0; absent required contract -> incompatible_protocol; unsupported major closes without frame, initiator emits locally.
- 11.8: RPC 3 binds Error 1.2.0; 24-key exact map; 7 namespaces; v2 [1..6] bound MUST NOT be used inside a v3 frame; v3 node negotiating v2 = core sync only, peer exposed as directory_mesh_unsupported never zero inventory; missing/extra keys, wrong versions -> incompatible_protocol.
- 11.9: RPC 4 binds Error 1.3.0; 25 keys exact; 8 namespaces; v4/v3 reports TerminalBackend evidence unsupported rather than empty; v4/v2 reports both unsupported; no coercion across majors.
- 11.10.1: RPC 5 = exact RPC-4 shapes with protocol_version 5.0.0 / contracts.rpc ["5.0.0"]; Error stays 1.3.0; identity equality/allowlist are admission; other RPC majors close without a frame; incompatible_protocol (6) only when actually known; no new Error enum or exit code.
- 15.3: incompatible_protocol exit 6 (1.0.0); invalid_config exit 3 (1.0.0); directory_mesh_unsupported exit 6 (1.2.0); terminal_backend_unavailable exit 6 (1.3.0). "MUST NOT mint a realm-specific code while existing codes remain truthful".
- 17.1: peers choose highest mutually supported minor within a common major; MUST NOT select a major by coercion.
- 17.2: reader rejects unsupported major.
- 17.4: peer that cannot activate backend contract MUST report activation unavailable rather than omit the Session.

## Findings log (running)
- Profiles: rpcwire.ContractProfile 2/3/4/5 == spec literal JSON blocks (14/24/25/25 keys, values equal); namespaces 6/7/8/8.
- Pair table 32 rows + 32 hostile offers: all as derived (logs/review-probes-run1.log).
- Producer harness reran twice: 27 killed / neutral / control survived; identical to producer results.json (mutations-run1, mutations-run2).
- Reviewer plants (review_mutants.py): 12 KILLED, 4 SURVIVED (R8 frame 5.1.0; R12 Negotiate legacy fallback on unknown config; R19/R20 exposure code same-exit swaps), C1 control survived. Survivors reproduced twice against the committed suite; each killed by reviewer probes (review-mutants-survivors).
- F3 proven: config.Decode v1 doc -> Value.SchemaVersion=3.0.0 -> LocalMajors [2 3 4]; SourceVersion=1.0.0 -> [2] (logs/review-config-probe.log).
- F4: PeerOffer admits session_event=[1.0.0] in v3/v4/v5 frames and lease=[9.9.9] in v2 when the Hello is built directly; rpcwire decode refuses the same.
- Hygiene: README +16 additive, LOGBOOK +8 additive newest-first, traceability/axerror untouched, config == HEAD, no pycache, gofmt/build/vet/tracecheck/cataloggen-check all exit 0.
- Verdict: changes requested (to-dev): F1 P2 circular exposure-token pin, F2 P2 unknown-config refusal unpinned at Negotiate, F3 P2 wrong documented config field; F4-F6 P3.
