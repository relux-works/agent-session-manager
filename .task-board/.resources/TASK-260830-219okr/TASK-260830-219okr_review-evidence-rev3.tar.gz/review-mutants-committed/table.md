| Mutant | Kind | State | Exit | Expected committed killer | Hit | Failing tests (first 6) |
|---|---|---|---:|---|---|---|
| R1-dup-admitted | narrowing | KILLED | 1 | TestPeerOfferRefusals/mixed/duplicate | True | TestPeerOfferRefusals/mixed/duplicate, TestPeerOfferRefusals/mixed, TestPeerOfferRefusals |
| R2-negotiate-peer-set-plus-5 | narrowing | KILLED | 1 | TestConfig4NeverDowngrades | True | TestConfig4NeverDowngrades, TestLegacyNeverSelectsRPC5, TestNegotiateMatrix/4.0.0-x-2.0.0, TestNegotiateMatrix/4.0.0-x-3.0.0, TestNegotiateMatrix/4.0.0-x-4.0.0, TestNegotiateMatrix |
| R3-select-admits-5-without-peer | narrowing | KILLED | 1 | TestConfig4NeverDowngrades | True | TestConfig4NeverDowngrades, TestNegotiateMatrix/4.0.0-x-2.0.0, TestNegotiateMatrix/4.0.0-x-3.0.0, TestNegotiateMatrix/4.0.0-x-4.0.0, TestNegotiateMatrix, TestSelectHighestCommon/refuse-config4-against-legacy |
| R4-shape-admits-any-extra-keys | narrowing | KILLED | 1 | TestPeerOfferRefusals/shape/extra-error-key | True | TestNoFallbackSurface/extension-member, TestNoFallbackSurface, TestPeerOfferRefusals/shape/v3-bound-in-v2-frame, TestPeerOfferRefusals/shape/extra-error-key, TestPeerOfferRefusals/shape/extra-extension-key, TestPeerOfferRefusals/shape |
| R5-exposure-code-when-negotiated | narrowing | KILLED | 1 | TestPeerExposure/3.0.0 | True | TestPeerExposure/3.0.0, TestPeerExposure/4.0.0, TestPeerExposure/5.0.0, TestPeerExposure |
| R6-v5-exact-exempt | narrowing | KILLED | 1 | TestPeerOfferRefusals/shape/v5-inexact-rpc | True | TestPeerOfferRefusals/shape/v5-inexact-rpc, TestPeerOfferRefusals/shape, TestPeerOfferRefusals |
| R7-refusal-code-same-exit | class-swap-same-exit | KILLED | 1 | TestNegotiateMatrix/3.0.0-x-5.0.0 | True | TestLegacyNeverSelectsRPC5, TestNegotiateMatrix/1.0.0-x-3.0.0, TestNegotiateMatrix/1.0.0-x-4.0.0, TestNegotiateMatrix/1.0.0-x-5.0.0, TestNegotiateMatrix/2.0.0-x-4.0.0, TestNegotiateMatrix/2.0.0-x-5.0.0 |
| R8-frame-admits-5.1 | narrowing | SURVIVED | 0 | - | False | none |
| R9-unknown-config-4.0.1 | narrowing | KILLED | 1 | TestLocalMajors/unknown-4.0.1 | True | TestLocalMajors/unknown-4.0.1, TestLocalMajors |
| R12-negotiate-unknown-config-falls-back-to-legacy | narrowing | SURVIVED | 0 | - | False | none |
| R13-negotiate-malformed-offer-trusts-frame | narrowing | KILLED | 1 | TestNoFallbackSurface/extension-member | True | TestNoFallbackSurface/extension-member, TestNoFallbackSurface |
| R16-activation-gains-inventory-member | structural | KILLED | 1 | TestExposureCarriesNoInventory | True | TestExposureCarriesNoInventory |
| R17-peerview-gains-count-member | structural | KILLED | 1 | TestExposureCarriesNoInventory | True | TestExposureCarriesNoInventory |
| R18-invalid-config-same-exit-code-swap | class-swap-same-exit | KILLED | 1 | TestLocalMajors/unknown- | True | TestLocalMajors/unknown-, TestLocalMajors/unknown-5.0.0, TestLocalMajors/unknown-3.0, TestLocalMajors/unknown-v4.0.0, TestLocalMajors/unknown-4.0.1, TestLocalMajors/unknown-4 |
| R19-directory-code-swap-same-exit | class-swap-same-exit | SURVIVED | 0 | - | False | none |
| R20-backend-code-swap-same-exit | class-swap-same-exit | SURVIVED | 0 | - | False | none |
| C1-control-sentinel-text | control-must-survive | SURVIVED | 0 | - | False | none |
