#!/usr/bin/env python3
"""Second pass: rerun the four committed-suite SURVIVORS (a) again against the
committed suite (determinism) and (b) with the reviewer probes present, to show
each survivor is a real behavior change that a literal/entry-level pin kills."""
import json, subprocess, sys
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]).resolve(); SRC = ROOT/"internal/meshneg/negotiate.go"
SURVIVORS = ["R8-frame-admits-5.1", "R12-negotiate-unknown-config-falls-back-to-legacy", "R19-directory-code-swap-same-exit", "R20-backend-code-swap-same-exit", "C1-control-sentinel-text"]
PRIOR = Path(sys.argv[3]).resolve()
rows=[]
for name in SURVIVORS:
    repl = PRIOR/name/"negotiate.go"
    folder = OUT/name; folder.mkdir(parents=True, exist_ok=True)
    overlay = folder/"overlay.json"; overlay.write_text(json.dumps({"Replace": {str(SRC): str(repl)}}))
    for label, pattern in (("committed-rerun", "^Test[^R]|^TestR[^e]"), ("with-reviewer-probes", "Test")):
        cmd = ["go","test","-overlay",str(overlay),"./internal/meshneg","-count=1","-json","-timeout=120s","-run",pattern]
        proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (folder/f"{label}.log").write_bytes(proc.stdout)
        ev=[]
        for line in proc.stdout.decode(errors="replace").splitlines():
            try: ev.append(json.loads(line))
            except json.JSONDecodeError: pass
        failed=[e["Test"] for e in ev if e.get("Action")=="fail" and "Test" in e]
        passed=[e["Test"] for e in ev if e.get("Action")=="pass" and "Test" in e]
        state = "KILLED" if proc.returncode!=0 and failed else ("SURVIVED" if passed else "NOT_RUN")
        rows.append({"mutant":name,"pass":label,"state":state,"exit":proc.returncode,"failing":failed[:8],"n_pass":len(passed)})
        print(f"{name} [{label}]: {state} exit={proc.returncode} failing={failed[:4]}", flush=True)
(OUT/"results.json").write_text(json.dumps(rows,indent=1)+"\n")
