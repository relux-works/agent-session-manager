#!/usr/bin/env python3
"""Reviewer narrowing plants for internal/meshneg (isolated copy, overlay-only).
Run with PYTHONDONTWRITEBYTECODE=1. Each plant keeps the gate present and
admits one member of the refused class (or swaps a class token), then runs the
COMMITTED behavioral suite (reviewer zz_review files held out) via -overlay."""
import json, subprocess, sys
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve()          # candidate copy root
OUT = Path(sys.argv[2]).resolve()           # output dir
SRC = ROOT / "internal/meshneg/negotiate.go"
PLANTS = [
 # name, old, new, expected killer (committed test), kind
 ("R1-dup-admitted",
  'offered[index-1] >= version', 'offered[index-1] > version',
  'TestPeerOfferRefusals/mixed/duplicate', 'narrowing'),
 ("R2-negotiate-peer-set-plus-5",
  'major, err := Select(local, []int{peer})', 'major, err := Select(local, []int{peer, 5})',
  'TestConfig4NeverDowngrades', 'narrowing'),
 ("R3-select-admits-5-without-peer",
  'if slices.Contains(peer, candidate) && candidate > best {', 'if (slices.Contains(peer, candidate) || candidate == 5) && candidate > best {',
  'TestConfig4NeverDowngrades', 'narrowing'),
 ("R4-shape-admits-any-extra-keys",
  'if len(hello.Contracts) != len(profile) {', 'if len(hello.Contracts) < len(profile) {',
  'TestPeerOfferRefusals/shape/extra-error-key', 'narrowing'),
 ("R5-exposure-code-when-negotiated",
  'if negotiated {\n\t\treturn activation, nil\n\t}', 'if negotiated {\n\t\tactivation.Code = code\n\t\treturn activation, nil\n\t}',
  'TestPeerExposure/3.0.0', 'narrowing'),
 ("R6-v5-exact-exempt",
  'if frameVersion != "2.0.0" && !slices.Equal(offered, profile["rpc"]) {', 'if frameVersion != "2.0.0" && frameVersion != "5.0.0" && !slices.Equal(offered, profile["rpc"]) {',
  'TestPeerOfferRefusals/shape/v5-inexact-rpc', 'narrowing'),
 ("R7-refusal-code-same-exit",
  'Code:     axerror.Code("incompatible_protocol"),', 'Code:     axerror.Code("capability_unavailable"),',
  'TestNegotiateMatrix/3.0.0-x-5.0.0', 'class-swap-same-exit'),
 ("R8-frame-admits-5.1",
  '"5.0.0": 5,', '"5.0.0": 5,\n\t"5.1.0": 5,',
  None, 'narrowing'),
 ("R9-unknown-config-4.0.1",
  'case "4.0.0":', 'case "4.0.0", "4.0.1":',
  'TestLocalMajors/unknown-4.0.1', 'narrowing'),
 ("R12-negotiate-unknown-config-falls-back-to-legacy",
  'local, err := LocalMajors(configVersion)\n\tif err != nil {\n\t\treturn Decision{}, err\n\t}', 'local, err := LocalMajors(configVersion)\n\tif err != nil {\n\t\tlocal = []int{2, 3, 4}\n\t}',
  None, 'narrowing'),
 ("R13-negotiate-malformed-offer-trusts-frame",
  'peer, err := PeerOffer(frameVersion, hello)\n\tif err != nil {', 'peer, err := PeerOffer(frameVersion, hello)\n\tif err != nil {\n\t\tif framing, pinned := pinnedFrameVersions[frameVersion]; pinned {\n\t\t\tpeer, err = framing, nil\n\t\t}\n\t}\n\tif err != nil {',
  'TestNoFallbackSurface/extension-member', 'narrowing'),
 ("R16-activation-gains-inventory-member",
  'type FeatureActivation struct {', 'type FeatureActivation struct {\n\tInventory int',
  'TestExposureCarriesNoInventory', 'structural'),
 ("R17-peerview-gains-count-member",
  'type PeerView struct {', 'type PeerView struct {\n\tCount int',
  'TestExposureCarriesNoInventory', 'structural'),
 ("R18-invalid-config-same-exit-code-swap",
  'Code:     axerror.Code("invalid_config"),', 'Code:     axerror.Code("local_precondition_failed"),',
  'TestLocalMajors/unknown-', 'class-swap-same-exit'),
 ("R19-directory-code-swap-same-exit",
  'DirectoryUnsupportedCode = axerror.Code("directory_mesh_unsupported")', 'DirectoryUnsupportedCode = axerror.Code("continuation_route_unavailable")',
  None, 'class-swap-same-exit'),
 ("R20-backend-code-swap-same-exit",
  'BackendEvidenceUnsupportedCode = axerror.Code("terminal_backend_unavailable")', 'BackendEvidenceUnsupportedCode = axerror.Code("terminal_backend_capability_unproven")',
  None, 'class-swap-same-exit'),
 ("C1-control-sentinel-text",
  'errors.New("hello contracts differ from the pinned profile")', 'errors.New("hello contracts do not match the pinned profile")',
  None, 'control-must-survive'),
]
OUT.mkdir(parents=True, exist_ok=True)
original = SRC.read_bytes()
text = original.decode()
rows = []
for name, old, new, expected, kind in PLANTS:
    if text.count(old) != 1:
        raise SystemExit(f"{name}: anchor matched {text.count(old)} times")
    folder = OUT / name; folder.mkdir(exist_ok=True)
    repl = folder / "negotiate.go"; repl.write_text(text.replace(old, new, 1))
    overlay = folder / "overlay.json"; overlay.write_text(json.dumps({"Replace": {str(SRC): str(repl)}}))
    cmd = ["go", "test", "-overlay", str(overlay), "./internal/meshneg", "-count=1", "-json", "-timeout=120s", "-run", "Test"]
    proc = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (folder / "test.log").write_bytes(proc.stdout)
    events = []
    for line in proc.stdout.decode(errors="replace").splitlines():
        try: events.append(json.loads(line))
        except json.JSONDecodeError: pass
    failed = [e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    compiled = bool(passed) or bool(failed)
    if not compiled:
        state = "COMPILE_FAIL/NOT_RUN"
    elif proc.returncode != 0 and failed:
        state = "KILLED"
    else:
        state = "SURVIVED"
    expected_hit = expected is not None and any(f == expected or f.startswith(expected) for f in failed)
    if SRC.read_bytes() != original: raise SystemExit("source mutated!")
    rows.append({"mutant": name, "kind": kind, "exit": proc.returncode, "state": state,
                 "expected": expected, "expected_hit": expected_hit,
                 "failing": failed[:12], "n_failing": len(failed), "n_passing": len(passed)})
    print(f"{name}: {state} exit={proc.returncode} expected={expected} hit={expected_hit} failing={len(failed)}", flush=True)
(OUT / "results.json").write_text(json.dumps(rows, indent=1) + "\n")
lines = ["| Mutant | Kind | State | Exit | Expected committed killer | Hit | Failing tests (first 6) |", "|---|---|---|---:|---|---|---|"]
for r in rows:
    lines.append(f'| {r["mutant"]} | {r["kind"]} | {r["state"]} | {r["exit"]} | {r["expected"] or "-"} | {r["expected_hit"]} | {", ".join(r["failing"][:6]) or "none"} |')
(OUT / "table.md").write_text("\n".join(lines) + "\n")
