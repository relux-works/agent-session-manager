package meshneg_test

import (
	"encoding/json"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/rpcwire"
)

// decodedHelloErr mirrors decodedHello but returns the first rpcwire error
// instead of failing the test.
func decodedHelloErr(t *testing.T, frameVersion string, contracts map[string][]string) (rpcwire.Hello, error) {
	t.Helper()
	body, err := json.Marshal(map[string]any{
		"host_id": peerHost, "platform": "macos", "ax_version": "0.2.1",
		"nonce": rpcwire.NewNonce(), "contracts": contracts,
		"max_line_bytes": 8 * 1024 * 1024, "max_object_bytes": 5 * 1024 * 1024,
	})
	if err != nil {
		return rpcwire.Hello{}, err
	}
	line, err := rpcwire.EncodeRequest(frameVersion, requestID, "hello", body)
	if err != nil {
		return rpcwire.Hello{}, err
	}
	request, err := rpcwire.DecodeRequest(line)
	if err != nil {
		return rpcwire.Hello{}, err
	}
	return request.Hello()
}
