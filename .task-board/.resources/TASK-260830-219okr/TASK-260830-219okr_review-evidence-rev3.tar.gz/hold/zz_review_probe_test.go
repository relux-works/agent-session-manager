package meshneg_test

import (
	"errors"
	"fmt"
	"os"
	"reflect"
	"slices"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axerror"
	"github.com/relux-works/agent-session-manager/internal/meshneg"
	"github.com/relux-works/agent-session-manager/internal/rpcwire"
)

// Reviewer-derived generation->majors mapping (from SPEC 6.4/6.5/6.6, 11.8, 11.9, 11.10.1).
var reviewLocal = map[string][]int{"1.0.0": {2}, "2.0.0": {2, 3}, "3.0.0": {2, 3, 4}, "4.0.0": {5}}

func reviewExit(t *testing.T, version axerror.Version, code string) int {
	t.Helper()
	exit, err := axerror.ExitCodeFor(version, axerror.Code(code))
	if err != nil {
		t.Fatal(err)
	}
	return exit
}

// (2) Pair table: every (local generation x peer frame) pair, derived by the reviewer.
func TestReviewPairTable(t *testing.T) {
	exit6 := reviewExit(t, axerror.Version100, "incompatible_protocol")
	exit3 := reviewExit(t, axerror.Version100, "invalid_config")
	if exit6 != 6 || exit3 != 3 {
		t.Fatalf("registry exits %d/%d", exit6, exit3)
	}
	rows := 0
	for _, config := range []string{"1.0.0", "2.0.0", "3.0.0", "4.0.0", "", "0.9.0", "5.0.0", "3.0.0\n"} {
		for _, frame := range []string{"2.0.0", "3.0.0", "4.0.0", "5.0.0"} {
			rows++
			hello := decodedHello(t, frame, profileContracts(t, frame))
			decision, err := meshneg.Negotiate(config, frame, hello)
			local, known := reviewLocal[config]
			peer := int(frame[0] - '0')
			if !known {
				refusal := asRefusal(t, err)
				if refusal.Code != "invalid_config" || refusal.ExitCode != exit3 || refusal.Reason != meshneg.ReasonUnknownConfig {
					t.Fatalf("(%q,%s) unknown config class %s/%d/%s", config, frame, refusal.Code, refusal.ExitCode, refusal.Reason)
				}
				if !reflect.DeepEqual(decision, meshneg.Decision{}) {
					t.Fatalf("(%q,%s) refusal returned a non-zero decision", config, frame)
				}
				continue
			}
			// highest common of local and {peer}
			want := 0
			if slices.Contains(local, peer) {
				want = peer
			}
			if want == 0 {
				refusal := asRefusal(t, err)
				if refusal.Code != "incompatible_protocol" || refusal.ExitCode != exit6 || refusal.Reason != meshneg.ReasonNoCommonMajor {
					t.Fatalf("(%s,%s) class %s/%d/%s", config, frame, refusal.Code, refusal.ExitCode, refusal.Reason)
				}
				if !slices.Equal(refusal.Local, local) || refusal.Peer != peer {
					t.Fatalf("(%s,%s) refusal facts local=%v peer=%d", config, frame, refusal.Local, refusal.Peer)
				}
				if !reflect.DeepEqual(decision, meshneg.Decision{}) {
					t.Fatalf("(%s,%s) refusal returned a non-zero decision", config, frame)
				}
				continue
			}
			if err != nil {
				t.Fatalf("(%s,%s) unexpected refusal %v", config, frame, err)
			}
			if decision.Major != want || decision.ProtocolVersion != fmt.Sprintf("%d.0.0", want) {
				t.Fatalf("(%s,%s) selected %d/%s want %d", config, frame, decision.Major, decision.ProtocolVersion, want)
			}
			wantErr := map[int]axerror.Version{2: axerror.Version100, 3: axerror.Version120, 4: axerror.Version130, 5: axerror.Version130}[want]
			if decision.ErrorVersion != wantErr {
				t.Fatalf("(%s,%s) error version %s want %s", config, frame, decision.ErrorVersion, wantErr)
			}
			// core-only exposure derived from the selected major
			if decision.Peer.Directory.Negotiated != (want >= 3) || decision.Peer.BackendEvidence.Negotiated != (want >= 4) {
				t.Fatalf("(%s,%s) exposure %+v", config, frame, decision.Peer)
			}
			if want < 3 && (decision.Peer.Directory.Code != "directory_mesh_unsupported" || decision.Peer.Directory.ExitCode != reviewExit(t, axerror.Version120, "directory_mesh_unsupported")) {
				t.Fatalf("(%s,%s) directory exposure %+v", config, frame, decision.Peer.Directory)
			}
			if want < 4 && (decision.Peer.BackendEvidence.Code != "terminal_backend_unavailable" || decision.Peer.BackendEvidence.ExitCode != reviewExit(t, axerror.Version130, "terminal_backend_unavailable")) {
				t.Fatalf("(%s,%s) backend exposure %+v", config, frame, decision.Peer.BackendEvidence)
			}
			if want >= 3 && (decision.Peer.Directory.Code != "" || decision.Peer.Directory.ExitCode != 0) {
				t.Fatalf("(%s,%s) negotiated directory carries a code", config, frame)
			}
			if want >= 4 && (decision.Peer.BackendEvidence.Code != "" || decision.Peer.BackendEvidence.ExitCode != 0) {
				t.Fatalf("(%s,%s) negotiated backend carries a code", config, frame)
			}
		}
	}
	t.Logf("pair rows driven: %d (16 known-generation pairs + 16 unknown-generation pairs)", rows)
}

type hostile struct {
	name   string
	config string
	frame  string
	build  func(t *testing.T) rpcwire.Hello
	reason meshneg.RefusalReason
	code   string
	exit   int
}

func TestReviewHostileOffers(t *testing.T) {
	with := func(frame string, edit func(m map[string][]string)) func(t *testing.T) rpcwire.Hello {
		return func(t *testing.T) rpcwire.Hello {
			m := profileContracts(t, frame)
			if edit != nil {
				edit(m)
			}
			return directHello(t, m)
		}
	}
	cases := []hostile{
		{"v3-frame-with-14-key-v2-map", "3.0.0", "3.0.0", with("2.0.0", nil), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v2-frame-with-24-key-v3-map", "3.0.0", "2.0.0", with("3.0.0", nil), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v5-frame-with-24-key-v3-map", "4.0.0", "5.0.0", with("3.0.0", nil), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v5-frame-with-v4-map-rpc-4", "4.0.0", "5.0.0", with("4.0.0", nil), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"v4-frame-with-v5-map-rpc-5", "3.0.0", "4.0.0", with("5.0.0", nil), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"unsorted-rpc", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"2.1.0", "2.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"duplicate-rpc", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"2.0.0", "2.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"multi-major-rpc-2-3", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"2.0.0", "3.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"multi-major-rpc-2-3-4-5", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"2.0.0", "3.0.0", "4.0.0", "5.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"multi-major-in-v5-frame", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"4.0.0", "5.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"major-6-frame", "3.0.0", "6.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"6.0.0"} }), meshneg.ReasonUnsupportedFrame, "incompatible_protocol", 6},
		{"major-6-frame-config4", "4.0.0", "6.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"6.0.0"} }), meshneg.ReasonUnsupportedFrame, "incompatible_protocol", 6},
		{"rpc-6-in-v5-frame", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"6.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"5.0.0-to-config3", "3.0.0", "5.0.0", with("5.0.0", nil), meshneg.ReasonNoCommonMajor, "incompatible_protocol", 6},
		{"legacy-2-to-config4", "4.0.0", "2.0.0", with("2.0.0", nil), meshneg.ReasonNoCommonMajor, "incompatible_protocol", 6},
		{"legacy-3-to-config4", "4.0.0", "3.0.0", with("3.0.0", nil), meshneg.ReasonNoCommonMajor, "incompatible_protocol", 6},
		{"legacy-4-to-config4", "4.0.0", "4.0.0", with("4.0.0", nil), meshneg.ReasonNoCommonMajor, "incompatible_protocol", 6},
		{"extension-key-v2", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["extensions"] = []string{"1.0.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"extension-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["extensions"] = []string{"1.0.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"fallback-hint-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["rpc_fallback"] = []string{"2.0.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"error-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["error"] = []string{"1.3.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"host-channel-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["host_channel"] = []string{"1.0.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"substituted-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { delete(m, "terminal_backend_evidence"); m["legacy"] = []string{"1.0.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"missing-rpc-key-v5", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { delete(m, "rpc") }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"nil-contracts", "3.0.0", "2.0.0", func(t *testing.T) rpcwire.Hello { return directHello(t, nil) }, meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"zero-hello", "3.0.0", "2.0.0", func(t *testing.T) rpcwire.Hello { return rpcwire.Hello{} }, meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v5-rpc-5.1.0-inexact", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"5.1.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v5-rpc-prerelease", "4.0.0", "5.0.0", with("5.0.0", func(m map[string][]string) { m["rpc"] = []string{"5.0.0-rc.1"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v4-rpc-range", "3.0.0", "4.0.0", with("4.0.0", func(m map[string][]string) { m["rpc"] = []string{"4.0.0", "4.1.0"} }), meshneg.ReasonContractShape, "incompatible_protocol", 6},
		{"v2-rpc-v-prefix", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"v2.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"v2-rpc-huge-major", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) { m["rpc"] = []string{"99999999999999999999.0.0"} }), meshneg.ReasonMixedMajor, "incompatible_protocol", 6},
		{"v2-rpc-17-entries", "3.0.0", "2.0.0", with("2.0.0", func(m map[string][]string) {
			var rpc []string
			for i := 0; i < 17; i++ {
				rpc = append(rpc, fmt.Sprintf("2.%d.0", i+10))
			}
			m["rpc"] = rpc
		}), meshneg.ReasonContractShape, "incompatible_protocol", 6},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			decision, err := meshneg.Negotiate(tc.config, tc.frame, tc.build(t))
			refusal := asRefusal(t, err)
			if refusal.Reason != tc.reason || refusal.Code != axerror.Code(tc.code) || refusal.ExitCode != tc.exit {
				t.Fatalf("got %s/%s/%d want %s/%s/%d", refusal.Reason, refusal.Code, refusal.ExitCode, tc.reason, tc.code, tc.exit)
			}
			if got := reviewExit(t, axerror.Version100, tc.code); got != refusal.ExitCode {
				t.Fatalf("registry exit %d != refusal exit %d", got, refusal.ExitCode)
			}
			if !reflect.DeepEqual(decision, meshneg.Decision{}) {
				t.Fatalf("refusal returned a non-zero decision %+v", decision)
			}
		})
	}
	t.Logf("hostile offers driven: %d", len(cases))
}

// Environment / argv hints and a failed-handshake retry must not select a fallback for a Config-4 endpoint.
func TestReviewNoFallbackForConfig4(t *testing.T) {
	t.Setenv("AX_RPC_MAJOR", "2")
	t.Setenv("AX_ALLOW_LEGACY", "1")
	t.Setenv("AX_HOST_CHANNEL", "0")
	argv := os.Args
	t.Cleanup(func() { os.Args = argv })
	os.Args = []string{"ax", "rpc", "serve", "--stdio", "--legacy", "--rpc-major=2"}
	for _, frame := range []string{"2.0.0", "3.0.0", "4.0.0"} {
		hello := decodedHello(t, frame, profileContracts(t, frame))
		for attempt := 0; attempt < 3; attempt++ {
			_, err := meshneg.Negotiate("4.0.0", frame, hello)
			refusal := asRefusal(t, err)
			if refusal.Reason != meshneg.ReasonNoCommonMajor || refusal.Code != "incompatible_protocol" || refusal.ExitCode != 6 {
				t.Fatalf("attempt %d frame %s: %s/%s/%d", attempt, frame, refusal.Reason, refusal.Code, refusal.ExitCode)
			}
			if !errors.Is(err, meshneg.ErrNoCommonMajor) {
				t.Fatal("sentinel lost")
			}
		}
	}
	// A later valid RPC 5 offer still selects 5 (and not something else) after the failures.
	d, err := meshneg.Negotiate("4.0.0", "5.0.0", decodedHello(t, "5.0.0", profileContracts(t, "5.0.0")))
	if err != nil || d.Major != 5 {
		t.Fatalf("post-failure RPC 5: %v %+v", err, d)
	}
}

// Direct-caller gap probe: a v4 frame whose 25 keys are present but whose
// non-rpc arrays carry wrong versions (SPEC 11.9: "a different version ... fails
// incompatible_protocol before object exchange"). rpcwire decode refuses it;
// does PeerOffer alone?
func TestReviewNonRPCValueExactnessGap(t *testing.T) {
	for _, frame := range []string{"3.0.0", "4.0.0", "5.0.0"} {
		m := profileContracts(t, frame)
		m["session_event"] = []string{"1.0.0"}
		peer, err := meshneg.PeerOffer(frame, directHello(t, m))
		t.Logf("PeerOffer(%s, session_event=[1.0.0] direct) = %d, err=%v", frame, peer, err)
		// through rpcwire decode
		hello, decErr := func() (h rpcwire.Hello, e error) {
			defer func() {
				if r := recover(); r != nil {
					e = fmt.Errorf("panic: %v", r)
				}
			}()
			return decodedHelloErr(t, frame, m)
		}()
		_ = hello
		t.Logf("rpcwire decode of the same hello: err=%v", decErr)
	}
	// A v2 frame with a foreign version in a non-rpc key (v2 allows 1-16 semvers per key at decode).
	m := profileContracts(t, "2.0.0")
	m["lease"] = []string{"9.9.9"}
	peer, err := meshneg.PeerOffer("2.0.0", directHello(t, m))
	t.Logf("PeerOffer(2.0.0, lease=[9.9.9]) = %d, err=%v", peer, err)
}

// Frame-vocabulary edge: unpinned minors of supported majors and garbage strings.
func TestReviewFrameVocabularyClasses(t *testing.T) {
	for _, frame := range []string{"4.1.0", "5.1.0", "5.0.1", "2.0.0-rc", "", "garbage"} {
		_, err := meshneg.Negotiate("4.0.0", frame, directHello(t, profileContracts(t, "5.0.0")))
		var refusal *meshneg.Refusal
		if errors.As(err, &refusal) {
			t.Logf("frame %q -> Refusal %s/%s/%d", frame, refusal.Reason, refusal.Code, refusal.ExitCode)
		} else {
			t.Logf("frame %q -> non-Refusal error %T %v", frame, err, err)
		}
	}
}

// Kill-control for R8: every unpinned frame version must yield the pinned
// Refusal class through Negotiate, including the RPC 4/5 minor edges.
func TestReviewFrameVocabularyEdgesAreRefusals(t *testing.T) {
	for _, frame := range []string{"4.1.0", "5.1.0", "5.0.1", "4.0.1"} {
		_, err := meshneg.Negotiate("4.0.0", frame, directHello(t, profileContracts(t, "5.0.0")))
		refusal := asRefusal(t, err)
		if refusal.Reason != meshneg.ReasonUnsupportedFrame || refusal.Code != "incompatible_protocol" || refusal.ExitCode != 6 {
			t.Fatalf("frame %q: %s/%s/%d", frame, refusal.Reason, refusal.Code, refusal.ExitCode)
		}
	}
}
