from pathlib import Path
import subprocess

root=Path(__file__).with_name('fixture')
logroot=Path(__file__).with_name('own-mutants')
logroot.mkdir(exist_ok=True)
mutants=[
 ('casefold-disposition','vocab.go','if disposition == allowed {','if disposition == allowed || (disposition == "Exact" && allowed == "exact") {','TestDispositionVocabularyOracle','KILLED'),
 ('source-class-bound-plus-one','record.go','length < 1 || length > 128','length < 1 || length > 129','TestRecordFieldBounds','KILLED'),
 ('content-block-one-cell-drift','report.go','if sum != totals.countOf(disposition) {','if sum != totals.countOf(disposition) && !(owner == "fidelity report content_block_counts" && disposition == "exact" && sum == totals.countOf(disposition)+1) {','TestContentBlockBreakdown','KILLED'),
 ('utf8-overlong-source-class','record.go','if !validText(input.SourceClass) {','if !validText(input.SourceClass) && input.SourceClass != "\\xc0\\xaf" {','TestUTF8RefusalReflectionGrid','KILLED'),
 ('neutral-control','doc.go','// Authority: relux-works/agent-session-manager-spec@v0.7.0, Section','// Authority: relux-works/agent-session-manager-spec@v0.7.0, Section (review control)','TestEntriesArePure','SURVIVED'),
]
for name,file,old,new,test,want in mutants:
 p=root/'internal'/'clonefidelity'/file
 before=p.read_text()
 assert before.count(old)==1,(name,before.count(old))
 p.write_text(before.replace(old,new,1))
 try:
  run=subprocess.run(['go','test','./internal/clonefidelity','-run','^'+test+'$','-count=1'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120)
 finally:
  p.write_text(before)
 got='KILLED' if run.returncode and '--- FAIL:' in run.stdout else 'SURVIVED' if run.returncode==0 else 'ERROR'
 (logroot/(name+'.log')).write_text(f'patch={file}\nold={old!r}\nnew={new!r}\nexit={run.returncode}\nresult={got}\n---\n{run.stdout}')
 print(name,got,'exit',run.returncode,flush=True)
 assert got==want,(name,got,want)
