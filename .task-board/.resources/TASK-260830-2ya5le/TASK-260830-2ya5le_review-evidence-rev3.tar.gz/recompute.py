import hashlib
import json
import re
from pathlib import Path

log = Path(__file__).with_name('fixture-output.log').read_text()
for kind in ('TARGET', 'ARCHIVE'):
    line = next(line for line in log.splitlines() if f'{kind}=' in line)
    doc = json.loads(line.split(f'{kind}=', 1)[1])
    reported = doc.pop('fidelity_report_id')
    canonical = json.dumps(doc, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    independent = 'sha256:' + hashlib.sha256(canonical).hexdigest()
    assert reported == independent, (kind, reported, independent)
    print(f'{kind} {independent} matched')
