package main
import (
 "crypto/sha256"
 "encoding/hex"
 "fmt"
 "github.com/relux-works/agent-session-manager/internal/clonebundle"
 "github.com/relux-works/agent-session-manager/internal/clonefidelity"
)
func dig(s string) string { x:=sha256.Sum256([]byte(s)); return "sha256:"+hex.EncodeToString(x[:]) }
func ptr(s string)*string{return &s}
func main(){
 tuple:=[]byte(fmt.Sprintf(`{"environment_id":"test.env","environment_version":"2.1.0","platform":"linux","architecture":"amd64","store_schema_fingerprint":"%s","adapter_version":"1.2.3"}`,dig("store")))
 row:=clonefidelity.DispositionRecordInput{SourceItemKey:"review-key",SourceClass:"durable_payload",SourceEvidenceIDs:[]string{dig("evidence")},CanonicalObjectID:ptr(dig("object")),Disposition:"exact",ReasonCodes:[]string{},Explanation:"review row",StagedEvidenceObjectIDs:[]string{},LiveEvidenceObjectIDs:[]string{},Extensions:map[string]any{}}
 kinds:=map[string]clonefidelity.FidelityCounts{};for _,k:=range clonebundle.EventKinds(){kinds[k]=clonefidelity.FidelityCounts{}};kinds[clonebundle.EventKinds()[0]]=clonefidelity.FidelityCounts{Exact:1}
 blocks:=map[string]clonefidelity.FidelityCounts{};for _,k:=range clonebundle.ContentBlockTypes(){blocks[k]=clonefidelity.FidelityCounts{}};blocks[clonebundle.ContentBlockTypes()[0]]=clonefidelity.FidelityCounts{Exact:1}
 bytes:=map[string]uint64{};for _,d:=range clonefidelity.Dispositions(){bytes[d]=0}
 in:=clonefidelity.FidelityReportInput{Scope:"target",OperationID:"0198f4c8-8e50-7f66-8f70-111111111111",BundleID:"0198f4c8-8e50-7f66-8f70-222222222222",SourceSnapshotDigest:dig("snapshot"),CaptureManifestID:dig("capture"),CanonicalSessionID:dig("canonical"),ProjectionPlanID:ptr(dig("plan")),SourceEnvironment:tuple,TargetEnvironment:tuple,Profile:"maximal_safe",RequiredDispositions:map[string][]string{},ForbidReasons:[]string{},Rows:[]clonefidelity.DispositionRecordInput{row},EventKindCounts:kinds,ContentBlockCounts:blocks,ByteCounts:bytes,StagedReadBackEvidenceManifestID:ptr(dig("staged")),LiveReadBackEvidenceManifestID:ptr(dig("live")),AdapterAttestations:[]string{},Extensions:map[string]any{}}
 in.ByteCounts["exact"]=1; if _,e:=clonefidelity.BuildFidelityReport(in); e==nil {panic("accepted one-cell byte_counts drift over the same disposition rows")}; fmt.Println("refused")
}
