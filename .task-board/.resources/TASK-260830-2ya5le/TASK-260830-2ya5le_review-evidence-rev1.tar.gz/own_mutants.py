import pathlib, subprocess, sys
root=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=True)
rows=[
 ('casefold-disposition','internal/clonefidelity/vocab.go',[('"github.com/relux-works/agent-session-manager/internal/environ"','"github.com/relux-works/agent-session-manager/internal/environ"\n\t"strings"'),('if disposition == allowed {','if strings.EqualFold(disposition, allowed) {')],'TestDispositionVocabularyOracle','KILLED'),
 ('extension-shadows-core','internal/clonefidelity/vocab.go',[('if code == core {','if code == core && code != "target_no_equivalent" {'),('return environ.CheckReverseDNS(code)','return code == "target_no_equivalent" || environ.CheckReverseDNS(code)')],'TestReasonShadowImpossible','KILLED'),
 ('source-class-bound-plus-one','internal/clonefidelity/record.go',[('length > 128 {','length > 129 {')],'TestRecordFieldBounds','KILLED'),
 ('event-kind-one-cell-drift','internal/clonefidelity/report.go',[('if sum != totals.countOf(disposition) {','if sum != totals.countOf(disposition) && !(owner == "fidelity report event_kind_counts" && disposition == "exact" && sum == totals.countOf(disposition)+1) {')],'TestEventKindBreakdown','KILLED'),
 ('line-count-neutral-control','internal/clonefidelity/doc.go',[('// This package implements the Section 13.14.2 fidelity contracts:','// This package implements the Section 13.14.2 fidelity contracts: [review control]')],'TestEntriesArePure','SURVIVED'),
]
for name,path,patches,test,expect in rows:
 p=root/path; original=p.read_text(); changed=original
 for a,b in patches:
  assert changed.count(a)==1,(name,a,changed.count(a));changed=changed.replace(a,b)
 if name=='line-count-neutral-control': assert changed.count('\n')==original.count('\n'),name
 try:
  p.write_text(changed)
  proc=subprocess.run(['go','test','./internal/clonefidelity','-run','^'+test+'$','-count=1'],cwd=root,capture_output=True,text=True,timeout=300)
 finally:p.write_text(original)
 output=proc.stdout+proc.stderr
 state='SURVIVED' if proc.returncode==0 else ('KILLED' if '--- FAIL' in output else 'ERROR')
 (out/(name+'.log')).write_text(f'name={name}\npath={path}\ntest={test}\nexit={proc.returncode}\nstate={state}\nexpected={expect}\npatches={patches!r}\n---\n{output}')
 print(f'{name}: {state} expected {expect} exit {proc.returncode}',flush=True)
 if state!=expect:sys.exit(1)
