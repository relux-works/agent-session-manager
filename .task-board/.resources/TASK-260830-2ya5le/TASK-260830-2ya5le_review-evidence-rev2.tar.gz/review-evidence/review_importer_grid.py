import json
from collections import Counter
from pathlib import Path

def load(path):
    out={}
    packages=set()
    for line in Path(path).open():
        event=json.loads(line)
        action=event.get('Action')
        package=event.get('Package')
        test=event.get('Test')
        if test and action in ('pass','fail','skip'):
            head, _, tail=test.partition('/')
            key=(package,head,tail)
            if key in out and out[key]!=action: raise ValueError((path,key,out[key],action))
            out[key]=action
        if package and not test and action in ('pass','fail','skip'):
            packages.add((package,action))
    return out,packages
base,bp=load('importer-base-03.jsonl')
candidate,cp=load('importer-candidate-02.jsonl')
print('base cases',len(base),'candidate cases',len(candidate))
print('base packages',sorted(bp))
print('candidate packages',sorted(cp))
allkeys=sorted(base.keys()|candidate.keys())
moved=[(k,base.get(k,'ABSENT'),candidate.get(k,'ABSENT')) for k in allkeys if base.get(k)!=candidate.get(k)]
print('moved',len(moved))
for row in moved[:50]: print(row)
assert bp==cp and not moved
