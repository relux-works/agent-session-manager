from pathlib import Path
import subprocess, hashlib, sys
ROOT = Path(__file__).resolve().parent
cases = [
 ('casefold-Exact','internal/clonefidelity/vocab.go','if disposition == allowed {','if disposition == allowed || (allowed == "exact" && disposition == "Exact") {','TestDispositionVocabularyOracle','KILLED'),
 ('extension-as-core','internal/clonefidelity/vocab.go','func IsCoreReasonCode(code string) bool {\n','func IsCoreReasonCode(code string) bool {\n\tif code == "com.example.reason" { return true }\n','TestReasonVocabularyOracle','KILLED'),
 ('synth-canonical-build-index0','internal/clonefidelity/record.go','if disposition == "synthesized" && hasCanonical {','if disposition == "synthesized" && hasCanonical && owner != "fidelity disposition record[0]" {','TestRecordGridOracle','KILLED'),
 ('content-one-cell-drift','internal/clonefidelity/report.go','if sum != totals.countOf(disposition) {','if sum != totals.countOf(disposition) && !(owner == "fidelity report content_block_counts" && disposition == "exact" && sum == totals.countOf(disposition)+1) {','TestContentBlockBreakdown','KILLED'),
 ('source-class-plus-one','internal/clonefidelity/record.go','if length := stringLength(input.SourceClass); length < 1 || length > 128 {','if length := stringLength(input.SourceClass); length < 1 || length > 129 {','TestRecordFieldBounds','KILLED'),
 ('neutral-comment','internal/clonefidelity/doc.go','// Authority: relux-works/agent-session-manager-spec@v0.7.0, Section\n','// Authority: relux-works/agent-session-manager-spec@v0.7.0, Section (review control).\n','TestEntriesArePure','SURVIVED'),
]
logs=ROOT/'review-own-mutant-logs'; logs.mkdir(exist_ok=True)
failed=False
for name, rel, find, replacement, test, want in cases:
    p=ROOT/rel
    original=p.read_bytes()
    src=original.decode()
    if src.count(find)!=1:
        print(name, 'NOT_APPLIED', src.count(find), flush=True); failed=True; continue
    p.write_text(src.replace(find,replacement))
    try:
        run=subprocess.run(['go','test','./internal/clonefidelity','-run','^'+test+'$','-count=1'],cwd=ROOT,text=True,capture_output=True,timeout=300)
    finally:
        p.write_bytes(original)
    assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(original).digest()
    output=run.stdout+run.stderr
    verdict='SURVIVED' if run.returncode==0 else 'KILLED' if '--- FAIL' in output else 'ERROR'
    (logs/(name+'.log')).write_text(f'# name={name} test={test} exit={run.returncode} verdict={verdict} wanted={want} applied=true\n# find={find!r}\n# replacement={replacement!r}\n---\n{output}')
    print(name,verdict,'exit',run.returncode,'wanted',want,flush=True)
    if verdict!=want: failed=True
sys.exit(1 if failed else 0)
