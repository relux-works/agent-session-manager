package clonefidelity_test

import (
    "fmt"
    "testing"
)

func TestReviewEmitFixtures(t *testing.T) {
    row := validRowInput("review-independent-target", "semantic", "unknown_native_event")
    fmt.Printf("REVIEW_TARGET=%s\n", mustBuild(t, validTargetInput(row)))
    archiveRow := validRowInput("review-independent-archive", "exact")
    fmt.Printf("REVIEW_ARCHIVE=%s\n", mustBuild(t, validArchiveInput(archiveRow)))
}
