# TASK-260830-2ya5le reviewer commands

Base `0ca3e4c26e2b275212796657f785b9b450f6174e`; candidate `7bade702b4bf260219b199c5c1f6d2355c9e0ea0`.

- `go test ./... -count=1` in exact candidate archive: exit 0, `review-full-test.log` (45 package results).
- `GOOS=windows GOARCH=amd64 go vet ./...` in candidate archive: exit 0, `review-windows-vet-02.log`. A first attempt overlapped temporary fixture removal and is excluded.
- `go test ./internal/clonefidelity -run <listed 18 gate tests> -count=3`: exit 0, `review-determinism.log`.
- `go test -json ./internal/clonebundle ./internal/environ ./internal/sessadapter ./internal/scalar ./internal/canonicaljson -count=1`: base exit 0 and candidate exit 0. `review_importer_grid.py` compares terminal test actions by `(package, top-level entry, subtest input)`; `review-importer-grid.log` reports 14,706 shared cases and zero moved outcomes. A trimmed base copy initially lacked README and config; those were restored from the same base OID before this successful run. The initial failed candidate run had sibling scratch directories under its root; the successful candidate run used an isolated archive.
- `go test ./internal/clonefidelity -run '^TestReviewEmitFixtures$' -v` with `review_fixture_test.go` temporarily present: exit 0. `review_jcs.py` independently recomputes both target and archive report IDs from `review-fixtures.jsonl`: exit 0.
- `python3 review_own_mutants.py`: exit 0, five KILLED and one SURVIVED; per-plant raw logs in `own-mutants/`.
- `gofmt -l internal/clonefidelity internal/clonebundle internal/environ`: exit 0, zero listed files.
- Producer evidence manifest: 69 hashes matched in `review-producer-manifest-02.log`; 63 raw producer plant logs have subprocess exit records.

Shipped harness pass records and command exits are in `shipped-run1/` and `shipped-run2/`.
- `python3 replay.py` in an exact candidate archive, with `review_utf8_probe_test.go` beside it: exit 0 as an audit driver. It verifies baseline probes pass, then applies one-case invalid-byte narrowings at three Build sites. The shipped `TestBuildUTF8` survives each plant (exit 0), while each new reviewer probe fails (exit 1) because the public Build entry admits invalid UTF-8. The full shipped clonefidelity suite survives the `source_class` plant (exit 0). Raw commands and exits are in `utf8-gap/replay-logs/`.
