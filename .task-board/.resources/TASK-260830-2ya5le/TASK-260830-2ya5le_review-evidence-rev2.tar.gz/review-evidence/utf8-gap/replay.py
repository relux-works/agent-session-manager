"""Replay the TASK-260830-2ya5le rev2 Build UTF-8 gate blind spot.
Run in a clean archive of candidate tree 7bade702b4bf260219b199c5c1f6d2355c9e0ea0.
The script restores each source file and removes its temporary test.
"""
from pathlib import Path
import hashlib
import shutil
import subprocess

root = Path(__file__).resolve().parent
package = root / 'internal/clonefidelity'
probe_source = root / 'review_utf8_probe_test.go'
probe_target = package / 'review_utf8_probe_test.go'
logs = root / 'review-utf8-replay-logs'
logs.mkdir(exist_ok=True)

cases = [
    ('sourceclass', package/'record.go',
     'if !validText(input.SourceClass) {',
     'if !validText(input.SourceClass) && input.SourceClass != string([]byte{0xff, 0xfe}) {',
     'TestReviewSourceClassUTF8Refusal'),
    ('targetlocator', package/'record.go',
     'if !validText(*input.TargetLocator) {',
     'if !validText(*input.TargetLocator) && *input.TargetLocator != string([]byte{0xff, 0xfe}) {',
     'TestReviewTargetLocatorUTF8Refusal'),
    ('forbidreason', package/'decode.go',
     'if !validText(value) {',
     'if !validText(value) && value != string([]byte{0xff, 0xfe}) {',
     'TestReviewForbidReasonUTF8Refusal'),
]

def run(name, args):
    result = subprocess.run(args, cwd=root, text=True, capture_output=True, timeout=300)
    (logs / f'{name}.log').write_text(f'# command={args!r}\n# exit={result.returncode}\n---\n{result.stdout}{result.stderr}')
    return result

assert not probe_target.exists()
path = cases[0][1]
original = path.read_bytes()
source = original.decode()
assert source.count(cases[0][2]) == 1
path.write_text(source.replace(cases[0][2], cases[0][3]))
try:
    full = run('sourceclass-full-suite-survived', ['go','test','./internal/clonefidelity','-count=1'])
    assert full.returncode == 0, 'shipped package suite detected narrowing; inspect log'
finally:
    path.write_bytes(original)
assert path.read_bytes() == original

shutil.copy2(probe_source, probe_target)
try:
    for name, path, find, replacement, test in cases:
        baseline = run(name+'-baseline', ['go','test','./internal/clonefidelity','-run','^'+test+'$','-count=1'])
        assert baseline.returncode == 0, name+' baseline failed'
        original = path.read_bytes()
        source = original.decode()
        assert source.count(find) == 1, name+' narrowing NOT_APPLIED'
        path.write_text(source.replace(find,replacement))
        try:
            shipped = run(name+'-shipped-test-survived', ['go','test','./internal/clonefidelity','-run','^TestBuildUTF8$','-count=1'])
            assert shipped.returncode == 0, name+' shipped test killed narrowing'
            probe = run(name+'-review-probe-killed', ['go','test','./internal/clonefidelity','-run','^'+test+'$','-count=1'])
            assert probe.returncode != 0 and 'error = nil, want refusal' in probe.stdout, name+' narrowing did not admit invalid bytes'
            print(f'{name}: baseline PASS, shipped TestBuildUTF8 SURVIVED, review probe KILLED', flush=True)
        finally:
            path.write_bytes(original)
        assert path.read_bytes() == original
finally:
    probe_target.unlink()
print('sourceclass full shipped package suite SURVIVED; all files restored')
