package clonefidelity_test
import (
    "testing"
    clonefidelity "github.com/relux-works/agent-session-manager/internal/clonefidelity"
)
func TestReviewSourceClassUTF8Refusal(t *testing.T) {
    row := validRowInput("review-bad-source-class", "exact")
    row.SourceClass = string([]byte{0xff, 0xfe})
    _, err := clonefidelity.BuildFidelityReport(validTargetInput(row))
    requireRefusal(t, err, "source_class is not valid UTF-8")
}
func TestReviewTargetLocatorUTF8Refusal(t *testing.T) {
    row := validRowInput("review-bad-target-locator", "exact")
    bad := string([]byte{0xff, 0xfe})
    row.TargetLocator = &bad
    _, err := clonefidelity.BuildFidelityReport(validTargetInput(row))
    requireRefusal(t, err, "target_locator is not valid UTF-8")
}
func TestReviewForbidReasonUTF8Refusal(t *testing.T) {
    input := validTargetInput(validRowInput("review-bad-forbid", "exact"))
    input.ForbidReasons = []string{string([]byte{0xff, 0xfe})}
    _, err := clonefidelity.BuildFidelityReport(input)
    requireRefusal(t, err, "forbid_reasons[0] is not valid UTF-8")
}
