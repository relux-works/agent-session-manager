import hashlib
import json
from pathlib import Path

rows = Path('review-fixtures.jsonl').read_text().splitlines()
assert len(rows) == 2
for line in rows:
    label, payload = line.split('=', 1)
    obj = json.loads(payload)
    claimed = obj.pop('fidelity_report_id')
    canonical = json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')
    computed = 'sha256:' + hashlib.sha256(canonical).hexdigest()
    assert claimed == computed, (label, claimed, computed)
    print(f'{label} claimed={claimed} computed={computed} bytes={len(canonical)} equal=true')
