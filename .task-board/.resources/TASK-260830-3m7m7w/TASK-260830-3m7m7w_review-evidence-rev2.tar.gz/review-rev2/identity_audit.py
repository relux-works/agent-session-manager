from pathlib import Path
import hashlib,json,subprocess,os,stat
p=Path('.temp/TASK-260830-3m7m7w/review-rev2')
def git(*args):return subprocess.check_output(['git',*args])
expected={};mismatches=[]
for row in git('ls-tree','-r','-z','4f1407cb98f19424db527d313a3d89d34e2fd231').split(b'\0'):
 if not row:continue
 meta,name=row.split(b'\t');mode,kind,oid=meta.decode().split();name=os.fsdecode(name);expected[name]=oid;f=Path(name);s=f.lstat()
 actual_mode='120000' if stat.S_ISLNK(s.st_mode) else '100755' if s.st_mode&stat.S_IXUSR else '100644'
 data=os.fsencode(os.readlink(f)) if actual_mode=='120000' else f.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 if actual!=oid or actual_mode!=mode:mismatches.append(name)
paths={os.fsdecode(n) for n in git('ls-files','--cached','--others','--exclude-standard','-z').split(b'\0') if n}
index=Path(git('rev-parse','--git-path','index').decode().strip());before=json.loads((p/'identity-before.json').read_text())
audit=dict(candidate=before['candidate'],files=len(expected),mismatches=mismatches,extra_paths=sorted(paths-set(expected)),missing_paths=sorted(set(expected)-paths),head=git('rev-parse','HEAD').decode().strip(),index_sha256=hashlib.sha256(index.read_bytes()).hexdigest())
audit['preserved']=not mismatches and paths==set(expected) and audit['head']==before['head'] and audit['index_sha256']==before['index_sha256']
(p/'identity-final.json').write_text(json.dumps(audit,indent=2));print(json.dumps(audit));assert audit['preserved']
