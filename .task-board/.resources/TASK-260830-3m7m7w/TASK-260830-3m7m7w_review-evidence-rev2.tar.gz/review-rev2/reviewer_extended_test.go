package gitsnap
import("bytes";"context";"os";"path/filepath";"testing")
func TestReviewerPolicyOtherFailedReads(t *testing.T){
 for _,shape:=range []string{"root-gitignore-permission","nested-gitignore-permission","external-policy-directory","info-policy-directory","info-parent-permission"}{t.Run(shape,func(t *testing.T){
  root:=initLiveRepo(t);options:=contentOptions(t);private:="ignored-private";policy:=filepath.Join(root,".git","info","exclude")
  switch shape{
  case "root-gitignore-permission":policy=filepath.Join(root,".gitignore")
  case "nested-gitignore-permission":policy=filepath.Join(root,"nested",".gitignore");private="nested/ignored-private"
  case "external-policy-directory":policy=filepath.Join(t.TempDir(),"policy");gitRun(t,root,"config","core.excludesFile",policy)
  }
  writeContent(t,root,private,[]byte("must stay excluded"));if err:=os.MkdirAll(filepath.Dir(policy),0700);err!=nil{t.Fatal(err)}
  if err:=os.WriteFile(policy,[]byte("ignored-private\n"),0600);err!=nil{t.Fatal(err)}
  if entriesByPath(captureContent(t,root,options).Content)[private]!=nil{t.Fatal("baseline did not exclude")}
  before,err:=os.ReadFile(filepath.Join(root,".git","index"));if err!=nil{t.Fatal(err)}
  switch shape{
  case "external-policy-directory","info-policy-directory":if err:=os.Remove(policy);err!=nil{t.Fatal(err)};if err:=os.Mkdir(policy,0700);err!=nil{t.Fatal(err)}
  case "info-parent-permission":if err:=os.Chmod(filepath.Dir(policy),0);err!=nil{t.Fatal(err)};defer os.Chmod(filepath.Dir(policy),0700)
  default:if err:=os.Chmod(policy,0);err!=nil{t.Fatal(err)};defer os.Chmod(policy,0600)
  }
  _,readErr:=os.ReadFile(policy);if readErr==nil{t.Fatal("fixture policy remains readable")}
  raw,re:=(ExecGitRunner{}).Run(context.Background(),root,"ls-files","--others","--ignored","--exclude-standard","--directory","-z")
  v,err:=Capture(context.Background(),ExecGitRunner{},root,options)
  leaked:=false;if v!=nil&&v.Content!=nil{leaked=entriesByPath(v.Content)[private]!=nil}
  t.Logf("shape=%s ReadFile=%v census exit=%d stdout=%q stderr=%q runnerErr=%v CaptureErr=%v SnapshotNil=%v includedPrivate=%v",shape,readErr,raw.ExitCode,raw.Stdout,raw.Stderr,re,err,v==nil,leaked)
  after,e:=os.ReadFile(filepath.Join(root,".git","index"));if e!=nil||!bytes.Equal(before,after){t.Fatal("index changed")}
  if err==nil||v!=nil{t.Fatal("failed policy read admitted as absence")}
 })}
}
