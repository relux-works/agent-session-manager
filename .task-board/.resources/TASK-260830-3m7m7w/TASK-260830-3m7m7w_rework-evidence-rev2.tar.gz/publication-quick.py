import json, subprocess
from pathlib import Path
p=Path(__file__).parent
config=json.loads(Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/task-board.config.json').read_text())
commands=config['spawn']['worktree_isolation']['validation']['commands']
rows=[]
for i, cmd in enumerate(commands,1):
    if i < 7 or i in (20,21,22,23,26):
        continue
    if cmd == 'task-board validate':
        cmd='task-board --board-dir /Users/iv/Developer/ReluxWorks/agent-session-manager/.task-board validate'
    log=p/f'publication-{i:02d}.log'
    with log.open('w') as out:
        proc=subprocess.run(['/bin/zsh','-o','pipefail','-c',cmd],stdout=out,stderr=subprocess.STDOUT,timeout=180)
    rows.append(dict(index=i,command=cmd,exit_code=proc.returncode,log=log.name))
    (p/'publication-quick-exits.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(i,proc.returncode,cmd,flush=True)
    if proc.returncode: raise SystemExit(proc.returncode)
