package gitsnap
import("context";"os";"path/filepath";"testing")
func TestReviewerTrackedWithinIgnoredDirectory(t *testing.T){
 root:=initLiveRepo(t); options:=contentOptions(t)
 writeContent(t,root,"build/tracked",[]byte("tracked bytes"));gitRun(t,root,"add","build/tracked");gitRun(t,root,"commit","-qm","tracked")
 writeContent(t,root,".gitignore",[]byte("build/\n"));writeContent(t,root,"build/ignored",[]byte("ignore me"))
 v:=captureContent(t,root,options);e:=entriesByPath(v.Content)
 if e["build/tracked"]==nil{t.Fatal("tracked file under ignored directory omitted")};if e["build/ignored"]!=nil{t.Fatal("ignored file leaked")}
}
func TestReviewerUnreadableIncludedFile(t *testing.T){
 root:=initLiveRepo(t);options:=contentOptions(t);writeContent(t,root,"private-file",[]byte("data"));p:=filepath.Join(root,"private-file");os.Chmod(p,0);defer os.Chmod(p,0600)
 v,err:=Capture(context.Background(),ExecGitRunner{},root,options);if err==nil||v!=nil{t.Fatal("unreadable included file treated as absent")};t.Log(err)
}
func TestReviewerUnreadableIgnoredDirectory(t *testing.T){
 root:=initLiveRepo(t);options:=contentOptions(t);writeContent(t,root,".gitignore",[]byte("ignored/\n"));writeContent(t,root,"ignored/file",[]byte("data"));p:=filepath.Join(root,"ignored");os.Chmod(p,0);defer os.Chmod(p,0700)
 _,err:=Capture(context.Background(),ExecGitRunner{},root,options);t.Logf("excluded unreadable directory: %v",err)
}
func TestReviewerPartialIgnoredSuccess(t *testing.T){
 root:=initLiveRepo(t);options:=contentOptions(t);writeContent(t,root,".gitignore",[]byte("ignored\n"));writeContent(t,root,"ignored",[]byte("secret build bytes"))
 r:=contentFaultRunner{Runner:ExecGitRunner{},command:"ls-files --others --ignored --exclude-standard --directory -z",result:GitResult{ExitCode:0,Stderr:[]byte("warning: could not open directory\n")}}
 v,err:=Capture(context.Background(),r,root,options);if err==nil&&entriesByPath(v.Content)["ignored"]!=nil{t.Fatal("partial ignored census warning laundered into inclusion")};t.Log(err)
}
func TestReviewerSymlinkThroughNondirectory(t *testing.T){
 root:=initLiveRepo(t); options:=contentOptions(t);os.Symlink("README.md/child",filepath.Join(root,"link"));_,err:=Capture(context.Background(),ExecGitRunner{},root,options);t.Logf("non-directory symlink ancestor: %v",err)
}
func TestReviewerInitializedGitMarkerInvalid(t *testing.T){
 root,child:=submoduleRepo(t);options:=contentOptions(t);writeContent(t,child,".git",[]byte("gitdir: /nonexistent/reviewer-path\n"));v,err:=Capture(context.Background(),ExecGitRunner{},root,options);if err==nil||v!=nil{t.Fatal("invalid initialized marker admitted")};t.Log(err)
}
func TestReviewerUnreadableExcludePolicy(t *testing.T){
 for _,shape:=range []string{"git-info","external"}{t.Run(shape,func(t *testing.T){
 root:=initLiveRepo(t);options:=contentOptions(t);writeContent(t,root,"ignored-private",[]byte("must stay excluded"));p:=filepath.Join(root,".git","info","exclude")
 if shape=="external"{p=filepath.Join(t.TempDir(),"exclude");gitRun(t,root,"config","core.excludesFile",p)}
 if err:=os.MkdirAll(filepath.Dir(p),0700);err!=nil{t.Fatal(err)};if err:=os.WriteFile(p,[]byte("ignored-private\n"),0600);err!=nil{t.Fatal(err)}
 if entriesByPath(captureContent(t,root,options).Content)["ignored-private"]!=nil{t.Fatal("baseline exclusion failed")}
 os.Chmod(p,0);defer os.Chmod(p,0600)
 raw,e:=(ExecGitRunner{}).Run(context.Background(),root,"ls-files","--others","--ignored","--exclude-standard","--directory","-z");t.Logf("real git census: exit=%d stdout=%q stderr=%q err=%v",raw.ExitCode,raw.Stdout,raw.Stderr,e)
 v,err:=Capture(context.Background(),ExecGitRunner{},root,options)
 if err==nil {t.Logf("captured ignored-private=%v",entriesByPath(v.Content)["ignored-private"]!=nil);t.Fatal("unreadable ignore policy accepted as empty census") };t.Log(err)
 })}
}
