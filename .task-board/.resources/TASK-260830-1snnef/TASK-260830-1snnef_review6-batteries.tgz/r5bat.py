from probe import probe, restore
TB = 'internal/terminalbackend/terminalbackend.go'
MF = 'internal/terminalbackend/manifest.go'
R = []
def P(pid, desc, edits, expect="RED"):
    R.append(probe(pid, desc, edits, expect=expect))

# ---- G-A: units. Site-local mutants, one site at a time. ----
P("A1", "checkGeneration (terminalbackend.go:606) RuneCountInString -> len",
  [(TB, 'if !utf8.ValidString(generation) || utf8.RuneCountInString(generation) < 1 || utf8.RuneCountInString(generation) > maxGenerationRunes {',
        'if !utf8.ValidString(generation) || len(generation) < 1 || len(generation) > maxGenerationRunes {')])
P("A2", "GenerationDigest (manifest.go:1410) RuneCountInString -> len",
  [(MF, 'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) < 1 || utf8.RuneCountInString(rawGeneration) > maxGenerationRunes {',
        'if !utf8.ValidString(rawGeneration) || len(rawGeneration) < 1 || len(rawGeneration) > maxGenerationRunes {')])
P("A3", "boundedStringMember (manifest.go:465) RuneCountInString -> len",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if !utf8.ValidString(value) || len(value) < 1 || len(value) > maxOpaqueString {')])
P("A4", "provider_build (manifest.go:2043) RuneCountInString -> len",
  [(MF, 'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString {',
        'if !utf8.ValidString(build) || len(build) < 1 || len(build) > maxOpaqueString {')])

# ---- G-A: bounds narrowed / widened, site-local (not via the shared constant) ----
P("S1", "boundedStringMember upper bound DELETED (M45 re-anchored)",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 {')])
P("S2", "boundedStringMember upper bound WIDENED 256 -> 257",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString+1 {')])
P("S3", "boundedStringMember upper bound NARROWED 256 -> 255",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString-1 {')])
P("S4", "boundedStringMember lower bound DELETED",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if !utf8.ValidString(value) || utf8.RuneCountInString(value) > maxOpaqueString {')])
P("S5", "provider_build upper bound WIDENED 256 -> 257",
  [(MF, 'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString {',
        'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString+1 {')])
P("S6", "provider_build upper bound NARROWED 256 -> 255",
  [(MF, 'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString {',
        'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString-1 {')])
P("S7", "provider_build bound DELETED entirely (falls back to bare stringMember)",
  [(MF, 'if !utf8.ValidString(build) || utf8.RuneCountInString(build) < 1 || utf8.RuneCountInString(build) > maxOpaqueString {',
        'if false {')])
P("S8", "GenerationDigest upper bound WIDENED 256 -> 257 (site-local)",
  [(MF, 'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) < 1 || utf8.RuneCountInString(rawGeneration) > maxGenerationRunes {',
        'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) < 1 || utf8.RuneCountInString(rawGeneration) > maxGenerationRunes+1 {')])
P("S9", "checkGeneration upper bound WIDENED 256 -> 257 (site-local)",
  [(TB, 'if !utf8.ValidString(generation) || utf8.RuneCountInString(generation) < 1 || utf8.RuneCountInString(generation) > maxGenerationRunes {',
        'if !utf8.ValidString(generation) || utf8.RuneCountInString(generation) < 1 || utf8.RuneCountInString(generation) > maxGenerationRunes+1 {')])
P("S10", "utf8.ValidString conjunct dropped at boundedStringMember",
  [(MF, 'if !utf8.ValidString(value) || utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {',
        'if utf8.RuneCountInString(value) < 1 || utf8.RuneCountInString(value) > maxOpaqueString {')])

# ---- G-B: local surrogate gate ----
P("B1", "surrogate gate call DELETED from decodeStrictObject",
  [(MF, '\tif hasLoneSurrogateEscape(raw) {\n\t\treturn nil, mismatchf("document surrogate escape")\n\t}\n', '')])
P("B2", "gate NARROWED: lone LOW surrogate admitted",
  [(MF, 'case unit >= 0xdc00 && unit <= 0xdfff:\n\t\t\t\t\treturn true',
        'case unit >= 0xdc00 && unit <= 0xdfff:\n\t\t\t\t\tcontinue')])
P("B3", "gate NARROWED: unpaired HIGH surrogate admitted",
  [(MF, 'if !ok || second < 0xdc00 || second > 0xdfff {\n\t\t\t\t\t\treturn true\n\t\t\t\t\t}',
        'if !ok || second < 0xdc00 || second > 0xdfff {\n\t\t\t\t\t\tcontinue\n\t\t\t\t\t}')])
P("B4", "gate WIDENED: a VALID surrogate pair is now rejected too",
  [(MF, 'case unit >= 0xd800 && unit <= 0xdbff:\n\t\t\t\t\tsecond, secondEnd, ok := readUTF16EscapeUnit(raw, end)',
        'case unit >= 0xd800 && unit <= 0xdbff:\n\t\t\t\t\treturn true\n\t\t\t\t\t//nolint\n\t\t\t\t\tsecond, secondEnd, ok := readUTF16EscapeUnit(raw, end)')])
P("B5", "gate moved AFTER the JSON decode (still before identity/canonicalization)",
  [(MF, '\tif hasLoneSurrogateEscape(raw) {\n\t\treturn nil, mismatchf("document surrogate escape")\n\t}\n\tdecoder := json.NewDecoder(bytes.NewReader(raw))',
        '\tdecoder := json.NewDecoder(bytes.NewReader(raw))'),
   (MF, '\tobject, ok := value.(map[string]any)\n\tif !ok {\n\t\treturn nil, mismatchf("document shape")\n\t}\n\treturn object, nil\n}',
        '\tobject, ok := value.(map[string]any)\n\tif !ok {\n\t\treturn nil, mismatchf("document shape")\n\t}\n\tif hasLoneSurrogateEscape(raw) {\n\t\treturn nil, mismatchf("document surrogate escape")\n\t}\n\treturn object, nil\n}')],
  expect="GREEN")

# ---- G-C: the fourth 7.A dimension ----
P("C1", "7.A binding-digest SHAPE arm deleted (arm #1)",
  [(TB, '\tif _, err := scalar.ParseDigest(descriptor.TerminalBindingID); err != nil {\n\t\treturn &Error{Code: CodeNotFound, BackendID: descriptor.BackendID, Detail: "descriptor binding digest"}\n\t}\n', '')])
P("C2", "7.A binding-digest EQUALITY arm deleted (arm #2)",
  [(TB, '\tif descriptor.TerminalBindingID != binding.TerminalBindingID {\n\t\treturn &Error{Code: CodeNotFound, BackendID: descriptor.BackendID, Detail: "descriptor binding digest"}\n\t}\n', '')])
P("C3", "7.A binding-digest equality NARROWED to empty-only",
  [(TB, '\tif descriptor.TerminalBindingID != binding.TerminalBindingID {',
        '\tif descriptor.TerminalBindingID == "" {')])
P("C4", "7.A binding-digest equality NARROWED to a 7-char prefix compare",
  [(TB, '\tif descriptor.TerminalBindingID != binding.TerminalBindingID {',
        '\tif len(descriptor.TerminalBindingID) < 7 || len(binding.TerminalBindingID) < 7 || descriptor.TerminalBindingID[:7] != binding.TerminalBindingID[:7] {')])
P("C5", "InstanceBinding.TerminalBindingID removed from the compared subset (both arms gone)",
  [(TB, '\tif _, err := scalar.ParseDigest(descriptor.TerminalBindingID); err != nil {\n\t\treturn &Error{Code: CodeNotFound, BackendID: descriptor.BackendID, Detail: "descriptor binding digest"}\n\t}\n\tif descriptor.TerminalBindingID != binding.TerminalBindingID {\n\t\treturn &Error{Code: CodeNotFound, BackendID: descriptor.BackendID, Detail: "descriptor binding digest"}\n\t}\n', '')])

import json
json.dump(R, open('.temp/TASK-260830-1snnef-r6rev/r5bat-results.json','w'), indent=1)
killed=[r for r in R if r.get('result')=='RED']
surv=[r for r in R if r.get('result')=='GREEN']
other=[r for r in R if r.get('result') not in ('RED','GREEN')]
print(f"\nROUND-5 BATTERY: total={len(R)} red={len(killed)} green={len(surv)} other={len(other)}")
print("GREEN:", [r['id'] for r in surv])
print("OTHER:", [(r['id'], r.get('result')) for r in other])
print("UNEXPECTED:", [(r['id'], r.get('result'), r.get('expect')) for r in R if r.get('result')!=r.get('expect')])
