import sys, json
sys.path.insert(0, ".temp/TASK-260830-1snnef-r6rev")
from probe import probe, restore


C = "internal/terminalbackend/conformance.go"
ATTACHABLE = '''	if result.Attachable && !((result.State == StateParked || result.State == StateActive) && result.AttachEvidenced) {'''
M = []
def m(pid, desc, old, new): M.append((pid, desc, old, new))

# Characterise the attachability state-set gap C13 exposed.
for pid, st in [("C26","StateCreating"),("C27","StateAbsent"),("C28","StateUnavailable"),
                ("C29","StateStaleFenced"),("C13b","StateQuiescing"),("C30","StateStopped")]:
    m(pid, f"CheckStatusResult admits attachable from {st}", ATTACHABLE,
      ATTACHABLE.replace("|| result.State == StateActive)", f"|| result.State == StateActive || result.State == {st})"))

# C08b: proper session-binding drop (no unused variable).
m("C08b", "CheckEntrypoint stops binding argv session to the session under creation",
  '''	if carried.String() != session.String() {''',
  '''	_ = session
	if carried.String() != carried.String() {''')

# Closed-vocabulary widenings.
m("C31", "ParseInstanceState admits an eleventh state",
  '''		StateQuiescing, StateStopped, StateStaleFenced, StateUnavailable:
		return InstanceState(value), nil''',
  '''		StateQuiescing, StateStopped, StateStaleFenced, StateUnavailable, InstanceState("running"):
		return InstanceState(value), nil''')

m("C32", "ParseOperation admits an eleventh operation",
  '''		OperationRequestStop, OperationTerminateStale, OperationRestore:
		return Operation(value), nil''',
  '''		OperationRequestStop, OperationTerminateStale, OperationRestore, Operation("detach"):
		return Operation(value), nil''')

m("C33", "parseTransport admits a fourth transport",
  '''	case TransportLocalOnly, TransportTrustedPrivateMesh, TransportThirdPartyRelay:''',
  '''	case TransportLocalOnly, TransportTrustedPrivateMesh, TransportThirdPartyRelay, PresentationTransport("ssh_tunnel"):''')

# Transition-table source widenings, one per instance-scoped row.
m("C34", "transitionTable widens attach sources with quiescing",
  '''		Operation:      OperationAttach,
		Sources:        []InstanceState{StateParked, StateActive},''',
  '''		Operation:      OperationAttach,
		Sources:        []InstanceState{StateParked, StateActive, StateQuiescing},''')

m("C35", "transitionTable widens create sources with unavailable",
  '''		Sources:   []InstanceState{StateAbsent, StateStopped},''',
  '''		Sources:   []InstanceState{StateAbsent, StateStopped, StateUnavailable},''')

m("C36", "transitionTable widens request-stop sources with active",
  '''		Operation:      OperationRequestStop,
		Sources:        []InstanceState{StateQuiescing},''',
  '''		Operation:      OperationRequestStop,
		Sources:        []InstanceState{StateQuiescing, StateActive},''')

m("C37", "transitionTable widens terminate-stale sources with active",
  '''		Sources:        []InstanceState{StateStaleFenced, StateUnavailable},''',
  '''		Sources:        []InstanceState{StateStaleFenced, StateUnavailable, StateActive},''')

m("C38", "transitionTable adds an extra side effect to request-stop",
  '''		Effects:        []SideEffect{EffectGracefulStopRequested, EffectProcessClosed, EffectBackendStoreClosed},''',
  '''		Effects:        []SideEffect{EffectGracefulStopRequested, EffectProcessClosed, EffectBackendStoreClosed, EffectInputClosed},''')

m("C39", "transitionTable retargets quiesce-input to stopped",
  '''		Operation:      OperationQuiesceInput,
		Sources:        []InstanceState{StateActive, StateParked},
		Target:         StateQuiescing,''',
  '''		Operation:      OperationQuiesceInput,
		Sources:        []InstanceState{StateActive, StateParked},
		Target:         StateStopped,''')

m("C40", "replicationMembers reclassifies a forbidden member as safe evidence",
  '''func CheckReplicable(members []string) error {''',
  '''func init() { replicationMembers["ax_pane_pid"] = ReplicationSafeEvidence }

func CheckReplicable(members []string) error {''')

results = []
for pid, desc, old, new in M:
    results.append(probe(pid, desc, [(C, old, new)]))
restore()
json.dump(results, open(".temp/TASK-260830-1snnef-r6rev/cbat2-results.json", "w"), indent=1)
killed=[r["id"] for r in results if r["result"]=="RED"]
surv=[r["id"] for r in results if r["result"]=="GREEN"]
miss=[r["id"] for r in results if r["result"] not in ("RED","GREEN")]
print(f"\nBATTERY 2: total={len(results)} killed={len(killed)} survived={len(surv)} missing={len(miss)}")
print("SURVIVED:", surv); print("MISSING:", miss)
