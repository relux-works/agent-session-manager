#!/bin/zsh
# usage: mut.sh <file> <old> <new> <testpkg> <runmask>
set -e
F="$1"; OLD="$2"; NEW="$3"; PKG="$4"; MASK="$5"
BK=".temp/TASK-260830-1snnef/$(echo "$F" | tr '/' '_').bak"
cp "$F" "$BK"
python3 - "$F" "$OLD" "$NEW" <<'PY'
import sys
f,old,new=sys.argv[1],sys.argv[2],sys.argv[3]
s=open(f).read()
n=s.count(old)
if n!=1:
    print("ANCHOR_COUNT=%d NOT_APPLIED"%n); sys.exit(3)
open(f,'w').write(s.replace(old,new))
print("APPLIED")
PY
RC=$?
if [ $RC -ne 0 ]; then cp "$BK" "$F"; exit 3; fi
set +e
if [ -n "$MASK" ]; then
  go test "$PKG" -count=1 -run "$MASK" 2>&1 | tail -25
else
  go test "$PKG" -count=1 2>&1 | tail -25
fi
TRC=${pipestatus[1]}
cp "$BK" "$F"
echo "MUTANT_TEST_EXIT=$TRC"
