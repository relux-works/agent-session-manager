import sys, json
sys.path.insert(0, ".temp/TASK-260830-1snnef-r6rev")
from probe import probe, restore

C = "internal/terminalbackend/conformance.go"
M=[]
def m(p,d,o,n): M.append((p,d,o,n))

# C40 control: reclassify an EXISTING forbidden member -> want-direction should catch it.
m("C40b","CONTROL: reclassify the existing forbidden member native_pid as safe evidence",
  '''	forbidden := []string{
		"native_pid", "process_handle",''',
  '''	safe = append(safe, "native_pid")
	forbidden := []string{
		"process_handle",''')

# C40c: add a brand-new safe-evidence member (widening by addition).
m("C40c","replicationMembers gains a new safe-evidence member the table never listed",
  '''		"conformance_fixture_id", "capability_claims", "evidence_ids",''',
  '''		"conformance_fixture_id", "capability_claims", "evidence_ids", "ax_pane_pid",''')

# C40d: promote an existing SENSITIVE member into safe evidence.
m("C40d","replicationMembers promotes attach_credential from sensitive to safe evidence",
  '''		"attach_descriptor", "ipc_handle", "tmux_socket",
		"named_pipe", "attach_credential", "relay_credential",''',
  '''		"attach_descriptor", "ipc_handle", "tmux_socket",
		"named_pipe", "relay_credential",''')

# C43: ParseSideEffect admits an eleventh effect.
m("C43","ParseSideEffect admits an eleventh side effect",
  '''	case EffectBindingPersisted, EffectWrapperStarted, EffectAttachClientCreated,''',
  '''	case SideEffect("input_reopened"), EffectBindingPersisted, EffectWrapperStarted, EffectAttachClientCreated,''')

# C44: ParseInstanceState admits a ninth state with a plausible name.
m("C44","ParseInstanceState admits a ninth state named detached",
  '''		StateQuiescing, StateStopped, StateStaleFenced, StateUnavailable:
		return InstanceState(value), nil''',
  '''		StateQuiescing, StateStopped, StateStaleFenced, StateUnavailable, InstanceState("detached"):
		return InstanceState(value), nil''')

# C45: allowedOperationErrors widened with a NON-catalogued code (outside complement domain).
m("C45","allowedOperationErrors widens quiesce-input with a non-catalogued code",
  '''	OperationQuiesceInput: {''',
  '''	OperationQuiesceInput: {
		"terminal_backend_smuggled",''')

results=[]
for p,d,o,n in M: results.append(probe(p,d,[(C,o,n)]))
restore()
json.dump(results, open(".temp/TASK-260830-1snnef-r6rev/cbat3-results.json","w"), indent=1)
print("\nSURVIVED:", [r["id"] for r in results if r["result"]=="GREEN"])
print("OTHER:", [(r["id"],r["result"]) for r in results if r["result"] not in ("RED","GREEN")])
