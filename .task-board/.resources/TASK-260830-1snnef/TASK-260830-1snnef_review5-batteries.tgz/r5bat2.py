from probe import probe, restore
TB = 'internal/terminalbackend/terminalbackend.go'
MF = 'internal/terminalbackend/manifest.go'
R = []
def P(pid, desc, edits, newfiles=(), expect="RED", testflags=None):
    R.append(probe(pid, desc, edits, newfiles=newfiles, expect=expect, testflags=testflags))

# S11/S12: is the utf8.ValidString conjunct reachable at the generation sites?
P("S11", "checkGeneration: utf8.ValidString conjunct dropped",
  [(TB, 'if !utf8.ValidString(generation) || utf8.RuneCountInString(generation) < 1',
        'if utf8.RuneCountInString(generation) < 1')])
P("S12", "GenerationDigest: utf8.ValidString conjunct dropped",
  [(MF, 'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) < 1',
        'if utf8.RuneCountInString(rawGeneration) < 1')])

# C6: the case that distinguishes 7.A arm #1 from arm #2 -- BOTH sides carry the
# same MALFORMED binding digest, so the equality arm cannot fire. A reviewer-
# authored probe test, not part of the shipped suite.
PROBE = '''package terminalbackend_test

import (
\t"testing"

\t"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func TestReviewerProbeMalformedBindingDigestOnBothSides(t *testing.T) {
\tbinding := terminalbackend.InstanceBinding{
\t\tBackendID:             "com.example.term",
\t\tImplementationVersion: "1.2.3",
\t\tProtocolVersion:       "1.0.0",
\t\tGeneration:            "generation-1",
\t\tTerminalBindingID:     "not-a-digest",
\t}
\tif err := terminalbackend.CheckProviderDescriptor(binding, binding); err == nil {
\t\tt.Fatalf("CheckProviderDescriptor(matching malformed binding digest) admitted the pair")
\t}
}
'''
NEW = [('internal/terminalbackend/reviewer_probe_c6_test.go', PROBE)]
FLAGS = ['-run', 'TestReviewerProbeMalformedBindingDigestOnBothSides']
P("C6-control", "reviewer probe against UNMUTATED production (expect it to pass)",
  [], newfiles=NEW, expect="GREEN", testflags=FLAGS)
P("C6", "reviewer probe with 7.A arm #1 (digest shape) deleted",
  [(TB, '\tif _, err := scalar.ParseDigest(descriptor.TerminalBindingID); err != nil {\n\t\treturn &Error{Code: CodeNotFound, BackendID: descriptor.BackendID, Detail: "descriptor binding digest"}\n\t}\n', '')],
  newfiles=NEW, expect="RED", testflags=FLAGS)

import json
json.dump(R, open('.temp/TASK-260830-1snnef-r5/r5bat2-results.json','w'), indent=1)
print("\nUNEXPECTED:", [(r['id'], r.get('result'), r.get('expect')) for r in R if r.get('result')!=r.get('expect')])
