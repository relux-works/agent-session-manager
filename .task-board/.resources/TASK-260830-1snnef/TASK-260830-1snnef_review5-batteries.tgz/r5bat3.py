from probe import probe, restore
MF = 'internal/terminalbackend/manifest.go'
R=[]
R.append(probe("M14r", "re-anchored: GenerationDigest lower bound < 1 dropped",
  [(MF, 'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) < 1 || utf8.RuneCountInString(rawGeneration) > maxGenerationRunes {',
        'if !utf8.ValidString(rawGeneration) || utf8.RuneCountInString(rawGeneration) > maxGenerationRunes {')], expect="RED"))
import json
json.dump(R, open('.temp/TASK-260830-1snnef-r5/r5bat3-results.json','w'), indent=1)
print("UNEXPECTED:", [(r['id'],r.get('result'),r.get('expect')) for r in R if r.get('result')!=r.get('expect')])
