import hashlib, os, subprocess, sys, tempfile

ROOT = os.getcwd()
CANDIDATE_TREE = "78cb3b2c5dcf4b32454770617a6545d534680a0d"

# Watch every file the Story touches, Go and non-Go alike, plus whole dirs
# so a created file is detected.
WATCH_DIRS = ["internal/terminalbackend", "internal/config", "internal/traceability",
              "internal/traceability/cmd/tracecheck"]
WATCH_FILES = ["LOGBOOK.md", "README.md", "internal/traceability/ownership.v0.5.0.json"]

def _snapshot():
    snap = {}
    for d in WATCH_DIRS:
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if os.path.isfile(p):
                snap[p] = open(p, "rb").read()
    for p in WATCH_FILES:
        snap[p] = open(p, "rb").read()
    return snap

ORIG = _snapshot()
BASE_KEYS = set(ORIG)

def tree_oid():
    """Tree OID of the whole working tree, index-isolated."""
    env = dict(os.environ)
    fd, idx = tempfile.mkstemp(); os.close(fd); os.unlink(idx)
    env["GIT_INDEX_FILE"] = idx
    subprocess.run(["git", "read-tree", "HEAD"], env=env, check=True,
                   capture_output=True)
    subprocess.run(["git", "add", "-A", "--", "."], env=env, check=True,
                   capture_output=True)
    out = subprocess.run(["git", "write-tree"], env=env, check=True,
                         capture_output=True, text=True).stdout.strip()
    if os.path.exists(idx):
        os.unlink(idx)
    return out

def restore(verify_tree=False):
    for p, v in ORIG.items():
        if not os.path.exists(p) or open(p, "rb").read() != v:
            open(p, "wb").write(v)
    now = _snapshot() if False else None
    # remove created files inside watched dirs
    for d in WATCH_DIRS:
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if os.path.isfile(p) and p not in BASE_KEYS:
                os.remove(p)
    cur = _snapshot()
    assert set(cur) == BASE_KEYS, ("file set drift", set(cur) ^ BASE_KEYS)
    for p in BASE_KEYS:
        assert cur[p] == ORIG[p], ("content drift", p)
    if verify_tree:
        t = tree_oid()
        assert t == CANDIDATE_TREE, ("TREE DRIFT", t)
        return t

def apply(edits, newfiles=()):
    for f, old, new in edits:
        s = open(f).read()
        if old not in s:
            restore(); return "ANCHOR-MISSING:%s|%s" % (f, old[:70].replace("\n", "\\n"))
        if s.count(old) > 1:
            restore(); return "ANCHOR-AMBIGUOUS(%d):%s" % (s.count(old), old[:50])
        open(f, "w").write(s.replace(old, new, 1))
    for path, body in newfiles:
        open(path, "w").write(body)
    return None

def run(pkgs=None, testflags=None):
    cmd = ["go", "test"] + (pkgs or ["./internal/terminalbackend/"]) + ["-count=1"] + (testflags or [])
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    return r.returncode, r.stdout + r.stderr

def failing(out):
    return sorted({l.split()[2] for l in out.splitlines()
                   if l.strip().startswith("--- FAIL:") and len(l.split()) > 2})

def probe(pid, desc, edits, newfiles=(), pkgs=None, expect="RED", repeats=1,
          testflags=None, quiet=False):
    verdicts, allfails, buildbroken = [], set(), False
    for _ in range(repeats):
        restore()
        err = apply(edits, newfiles)
        if err:
            restore()
            print(f"{pid}\t{err}\t{desc}")
            return {"id": pid, "desc": desc, "result": err, "expect": expect}
        code, out = run(pkgs, testflags)
        f = failing(out)
        allfails |= set(f)
        if code != 0 and not f and ("build failed" in out or "cannot" in out or
                                    "declared and not used" in out or "syntax error" in out):
            buildbroken = True
        verdicts.append("RED" if code != 0 else "GREEN")
        restore()
    reds = verdicts.count("RED")
    if reds == repeats:
        verdict = "RED"
    elif reds == 0:
        verdict = "GREEN"
    else:
        verdict = "FLAKY(%d/%d red)" % (reds, repeats)
    status = "OK" if verdict == expect else "*** UNEXPECTED ***"
    if buildbroken:
        verdict += "[BUILD-BROKEN]"
    if not quiet:
        print(f"{pid}\t{verdict}\t(expect {expect}) {status}\tx{repeats}\t{desc}")
        if allfails:
            print("      failing:", ", ".join(sorted(allfails)[:8]))
    return {"id": pid, "desc": desc, "result": verdict, "expect": expect,
            "runs": repeats, "reds": reds, "failing": sorted(allfails),
            "build_broken": buildbroken}
