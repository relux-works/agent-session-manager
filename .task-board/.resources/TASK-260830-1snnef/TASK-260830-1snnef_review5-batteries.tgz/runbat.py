import sys, json
sys.path.insert(0, ".temp/TASK-260830-1snnef-r5")
import probe as P
_orig = P.probe
REPEATS = int(sys.argv[2]) if len(sys.argv) > 2 else 1
RESULTS = []
def probe(pid, desc, edits, newfiles=(), pkgs=None, expect="RED", testflags=None, **kw):
    r = _orig(pid, desc, edits, newfiles=newfiles, pkgs=pkgs, expect=expect, repeats=REPEATS, testflags=testflags)
    RESULTS.append(r)
    return r
P.probe = probe
import builtins
mod = sys.argv[1]
src = open(".temp/TASK-260830-1snnef-r5/%s.py" % mod).read()
src = src.replace('from probe import probe, restore', 'from probe import restore\nfrom __main__ import probe')
exec(compile(src, mod, "exec"), {"__name__": "__mut__", "probe": probe,
                                 "restore": P.restore, "__builtins__": builtins})
json.dump(RESULTS, open(".temp/TASK-260830-1snnef-r5/%s-r5.json" % mod, "w"), indent=1)
print("TREE:", P.restore(verify_tree=True))
