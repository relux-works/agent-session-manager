import sys, json
sys.path.insert(0, ".temp/TASK-260830-1snnef-r4")
from probe import probe, restore


C = "internal/terminalbackend/conformance.go"
M = []
def m(pid, desc, old, new): M.append((pid, desc, old, new))

# Every mutant below PRESERVES all refusal literals, so the arm inventory
# cannot kill it by construction: only behavioural tests can.

m("C01", "CheckErrorAllowed admits terminal_backend_unavailable for every operation",
  '''	for _, allowed := range allowedOperationErrors[parsedOperation] {''',
  '''	if code == "terminal_backend_unavailable" {
		return nil
	}
	for _, allowed := range allowedOperationErrors[parsedOperation] {''')

m("C02", "CheckAttachResult drops the auth conjunct (triple -> pair)",
  '''	if resultInputAuthorized != requestInputAuthorized || resultInputAuthorized != auth.InputAuthorized {''',
  '''	if resultInputAuthorized != requestInputAuthorized {''')

m("C03", "CheckAttachRequest admits attach at exactly the expiry instant",
  '''	if !now.Before(expires) {''', '''	if now.After(expires) {''')

m("C04", "CheckAttachRequest drops the input-authorized conjunct",
  '''	if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {''',
  '''	if requested != auth.Transport {''')

m("C05", "CheckAttachRequest drops the transport conjunct",
  '''	if requested != auth.Transport || inputAuthorized != auth.InputAuthorized {''',
  '''	if inputAuthorized != auth.InputAuthorized {''')

m("C06", "CheckAttachRequest never matches the relay transport",
  '''	if requested == TransportThirdPartyRelay {''',
  '''	if requested == PresentationTransport("no-such-transport") {''')

m("C07", "CheckEntrypoint accepts argv longer than three",
  '''	if len(argv) != 3 || argv[0] != "ax" || argv[1] != "pane" {''',
  '''	if len(argv) < 3 || argv[0] != "ax" || argv[1] != "pane" {''')

m("C08", "CheckEntrypoint stops binding argv session to the session under creation",
  '''	if carried.String() != session.String() {''', '''	if carried.String() != carried.String() {''')

m("C09", "CheckEntrypoint stops requiring argv[0] == ax",
  '''	if len(argv) != 3 || argv[0] != "ax" || argv[1] != "pane" {''',
  '''	if len(argv) != 3 || argv[1] != "pane" {''')

m("C10", "IdempotencyKey stops refusing empty segments",
  '''		if segment == "" {
			return "", &Error{Code: CodeProtocolError, Detail: "idempotency key shape"}
		}''',
  '''		if segment == "\\x00nope" {
			return "", &Error{Code: CodeProtocolError, Detail: "idempotency key shape"}
		}''')

m("C11", "IdempotencyKey admits extra segments (exact count -> floor)",
  '''	} else if len(segments) != want {''', '''	} else if len(segments) < want {''')

m("C12", "idempotencyKeySegments turns attach into the variable-arity row",
  '''OperationCreate: 2, OperationRestore: 2, OperationAttach: 2,''',
  '''OperationCreate: 2, OperationRestore: 2, OperationAttach: -1,''')

m("C13", "CheckStatusResult admits attachable from quiescing",
  '''	if result.Attachable && !((result.State == StateParked || result.State == StateActive) && result.AttachEvidenced) {''',
  '''	if result.Attachable && !((result.State == StateParked || result.State == StateActive || result.State == StateQuiescing) && result.AttachEvidenced) {''')

m("C14", "CheckStatusResult accepts provider_present on request OR evidence",
  '''	if result.ProviderPresent != nil && !(result.ProviderRequested && result.ProviderEvidenced) {''',
  '''	if result.ProviderPresent != nil && !(result.ProviderRequested || result.ProviderEvidenced) {''')

m("C15", "CheckStatusResult drops wrapper_present from the canonical false form",
  '''		if result.State != StateAbsent || result.WrapperPresent ||''',
  '''		if result.State != StateAbsent ||''')

m("C16", "CheckReplicable admits any KNOWN member regardless of class",
  '''		if class, known := replicationMembers[member]; !known || class != ReplicationSafeEvidence {''',
  '''		if _, known := replicationMembers[member]; !known {''')

m("C17", "Ledger.Bind admits a rebind with a different result id",
  '''		if stored.Operation != operation || stored.ResultID != resultID {''',
  '''		if stored.Operation != operation {''')

m("C18", "ImportLedger admits an image binding the same key twice",
  '''		if _, duplicate := ledger.receipts[key]; duplicate {''',
  '''		if _, duplicate := ledger.receipts[key]; duplicate && key == "\\x00never" {''')

m("C19", "ImportLedger admits an empty result id",
  '''		if key == "" || resultID == "" {
			return nil, &Error{Code: CodeProtocolError, Detail: "idempotency ledger image"}''',
  '''		if key == "" {
			return nil, &Error{Code: CodeProtocolError, Detail: "idempotency ledger image"}''')

m("C20", "legacyForward gains a third escape name",
  '''	"tmux":   BuiltinTmux,
	"conpty": BuiltinConpty,''',
  '''	"tmux":   BuiltinTmux,
	"conpty": BuiltinConpty,
	"screen": BuiltinTmux,''')

m("C21", "CheckTransition inverts the create interactive/parked resolution",
  '''	if parsedOperation == OperationCreate && !interactive {''',
  '''	if parsedOperation == OperationCreate && interactive {''')

m("C22", "ParseAttachAuthorization stops refusing unknown/missing members",
  '''	if err := checkExactMembers(object, attachAuthorizationMembers); err != nil {''',
  '''	if err := error(nil); err != nil {''')

m("C23", "ParseAttachAuthorization admits expires == issued",
  '''	if !expires.After(issued) {''', '''	if expires.Before(issued) {''')

m("C24", "CheckTransition drops the non-instance-scoped source guard",
  '''		if source != "" {
			return "", nil, &Error{Code: CodePreconditionFailed, Detail: "lifecycle instance scope"}''',
  '''		if source == "\\x00never" {
			return "", nil, &Error{Code: CodePreconditionFailed, Detail: "lifecycle instance scope"}''')

m("C25", "ProjectToLegacy skips the registry ID grammar",
  '''	if _, err := ParseID(backendID); err != nil {
		return "", err
	}''', '''	if backendID == "\\x00never" {
		return "", &Error{Code: CodeIncompatibleSchema, Detail: "legacy reverse projection"}
	}''')

results = []
for pid, desc, old, new in M:
    results.append(probe(pid, desc, [(C, old, new)]))
restore()
json.dump(results, open(".temp/TASK-260830-1snnef-r4/cbat-results.json", "w"), indent=1)
killed=[r["id"] for r in results if r["result"]=="RED"]
surv=[r["id"] for r in results if r["result"]=="GREEN"]
miss=[r["id"] for r in results if r["result"] not in ("RED","GREEN")]
print(f"\nCONFORMANCE BATTERY: total={len(results)} killed={len(killed)} survived={len(surv)} anchor_missing={len(miss)}")
print("SURVIVED:", surv)
print("MISSING:", miss)
