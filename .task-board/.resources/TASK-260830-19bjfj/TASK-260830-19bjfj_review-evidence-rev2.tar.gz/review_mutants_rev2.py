#!/usr/bin/env python3
"""Reviewer mutant harness for TASK-260830-19bjfj CR rev2.

Every plant is a `go test -overlay` against the ISOLATED candidate extract
(git archive of the CR tree), never the live Story worktree. One raw log per
plant per run, real subprocess exits, named failing tests. Two full runs so a
kill is not Go map-iteration luck. The package suite runs WITHOUT a -run
filter, i.e. exactly the behavioral suite `go test ./...` executes (unit tests
plus fuzz seed corpora); kills that come only from a Fuzz seed are visible in
the named failing tests.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "cand"
E = "internal/rpcwire/envelope.go"
H = "internal/rpcwire/hello.go"
I = "internal/rpcwire/inventory.go"
N = "internal/meshneg/negotiate.go"
J = "internal/matjournal/store.go"
RPC = "./internal/rpcwire"
MESH = "./internal/meshneg"
MAT = "./internal/matjournal"

PLANTS = []


def plant(name, path, pkg, edits, kind, admits, expected_test, expectation="killed"):
    PLANTS.append((name, path, pkg, edits, kind, admits, expected_test, expectation))


# ---- harmless applied controls (must SURVIVE) ------------------------------
plant("C1b-rpcwire-harmless-comment", E, RPC,
      [("// DecodeRequest inspects one LF-free line, as returned by SSH Session.Receive.",
        "// DecodeRequest inspects one LF-free line as returned by SSH Session.Receive.")],
      "harmless-control", "Nothing (comment punctuation)", None, "survive-control")
plant("C2-meshneg-harmless-comment", N, MESH,
      [("// Error renders the refusal without exposing anything beyond the refusal",
        "// Error renders the refusal without exposing anything beyond the refusal facts")],
      "harmless-control", "Nothing (comment text)", None, "survive-control")
plant("C3-matjournal-harmless-comment", J, MAT,
      [("// A crash landed between the journal and the receipt: the",
        "// A crash landed between the journal and the receipt; the")],
      "harmless-control", "Nothing (comment punctuation)", None, "survive-control")

# ---- rev1 findings re-verified on the rev2 tree ----------------------------
plant("R9-rev1-shape-vacuous", E, RPC,
      [('if _, err = object(m["body"]); err != nil {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {',
        'if _, err = object(m["body"]); err != nil && op != "health.get" {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {')],
      "rev1 R9 exact shape (vacuous: the assigned err still propagates through the later `if err != nil`)",
      "Nothing (equivalent mutant; the producer's rework finding)", None, "equivalent-expected")
plant("R9b-opaque-object-gate-exempts-health.get", E, RPC,
      [('\tif _, err = object(m["body"]); err != nil {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {',
        '\tif op != "health.get" {\n\t\tif _, err = object(m["body"]); err != nil {\n\t\t\treturn Request{}, err\n\t\t}\n\t}\n\tif op == "hello" {')],
      "narrowing (P3-1 rework)", "A non-object / duplicate-member body for the opaque health.get operation only",
      "TestOpaqueBodyMustBeObject", "killed")
plant("R9c-opaque-object-gate-exempts-session.status", E, RPC,
      [('\tif _, err = object(m["body"]); err != nil {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {',
        '\tif op != "session.status" {\n\t\tif _, err = object(m["body"]); err != nil {\n\t\t\treturn Request{}, err\n\t\t}\n\t}\n\tif op == "hello" {')],
      "narrowing (per-member probe of the P3-1 class)", "A non-object / duplicate-member body for the opaque session.status operation only",
      None, "unknown")
plant("J1-rev1-replay-admits-moved-body-after-commit", J, MAT,
      [("if journal.PrepareRequestDigest != digest {", "if journal.PrepareRequestDigest != digest && journal.Phase != PhaseCommitted {"),
       ("if receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {",
        "if (receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical)) && journal.Phase != PhaseCommitted {")],
      "narrowing (P3-2 rework)", "A CHANGED prepare body retried after commit replays the receipt instead of idempotency_mismatch",
      "TestRPCChangedBodyAfterCommitRefusesMismatch", "killed")
plant("J1b-replay-admits-moved-body-after-rollback", J, MAT,
      [("if journal.PrepareRequestDigest != digest {", "if journal.PrepareRequestDigest != digest && journal.Phase != PhaseRolledBack {"),
       ("if receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {",
        "if (receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical)) && journal.Phase != PhaseRolledBack {")],
      "narrowing (per-member probe of the P3-2 class)", "A CHANGED prepare body retried after rollback replays the receipt",
      None, "unknown")
plant("J1c-replay-admits-moved-body-after-failed", J, MAT,
      [("if journal.PrepareRequestDigest != digest {", "if journal.PrepareRequestDigest != digest && journal.Phase != PhaseFailed {"),
       ("if receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {",
        "if (receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical)) && journal.Phase != PhaseFailed {")],
      "narrowing (per-member probe of the P3-2 class)", "A CHANGED prepare body retried after a failed journal replays the receipt",
      None, "unknown")

# ---- new reviewer narrowing plants on gates the producer did not mutate -----
plant("V1-failure-response-admits-body-member", E, RPC,
      [('if !exact(m, "protocol", "protocol_version", "request_id", "ok", "error") {',
        'if !exact(m, "protocol", "protocol_version", "request_id", "ok", "error") && !(len(m) == 6 && m["body"] != nil) {')],
      "narrowing (member check dropped)", "A failure response carrying a body member beside error (11.2#3 MUST omit body)",
      "TestUnknownFieldsRefusedEverywhere/failure-carries-body", "killed")
plant("V2-success-response-admits-error-member", E, RPC,
      [('if !exact(m, "protocol", "protocol_version", "request_id", "ok", "body") {',
        'if !exact(m, "protocol", "protocol_version", "request_id", "ok", "body") && !(len(m) == 6 && m["error"] != nil) {')],
      "narrowing (member check dropped)", "A success response carrying an error member beside body",
      "TestUnknownFieldsRefusedEverywhere/success-carries-error", "killed")
plant("V3-major-coerces-1.0.0-to-2", E, RPC,
      [('case "2.0.0":\n\t\treturn 2, nil', 'case "2.0.0", "1.0.0":\n\t\treturn 2, nil')],
      "narrowing (17.1 coercion)", "A 1.0.0 frame reinterpreted as major 2 at every rpcwire entry",
      "TestMajor1RejectedNotReinterpreted", "killed")
plant("V4-object-gate-skips-short-noncanonical", E, RPC,
      [("if _, err := canonicaljson.Canonicalize(data); err != nil {\n\t\treturn nil, ErrFrame\n\t}",
        "if _, err := canonicaljson.Canonicalize(data); err != nil && len(data) > 13 {\n\t\treturn nil, ErrFrame\n\t}")],
      "narrowing (class: every non-I-JSON object of 13 bytes or fewer)", "Duplicate-member / non-I-JSON objects up to 13 bytes for every operation",
      "TestOpaqueBodyMustBeObject/duplicate-member", "killed")
plant("V5-object-floor-refuses-exact-edge", H, RPC,
      [("h.MaxObjectBytes.Uint64() < MinObjectBytes", "h.MaxObjectBytes.Uint64() <= MinObjectBytes")],
      "edge (bound moved by one, refusing direction)", "Refuses the exact 5242880 object floor",
      "TestClosedBodyBoundsWitnessed/both-floors-admitted", "killed")
plant("V6-hello-contracts-unsorted-third-element", H, RPC,
      [("if !semver.MatchString(v) || (i > 0 && versions[i-1] >= v) {",
        "if !semver.MatchString(v) || (i > 0 && i != 2 && versions[i-1] >= v) {")],
      "narrowing (unsorted array admitted at one position)", "A hello contracts version array whose THIRD element is out of order or a duplicate",
      None, "unknown")
plant("V7-namespaces-unsorted-third-element", I, RPC,
      [("if !slices.Contains(allowed, name) || (i > 0 && names[i-1] >= name) {",
        "if !slices.Contains(allowed, name) || (i > 0 && i != 2 && names[i-1] >= name) {")],
      "narrowing (unsorted array admitted at one position)", "An inventory.roots namespaces array whose THIRD element is out of order or a duplicate",
      None, "unknown")
plant("V8-empty-operation-admitted", E, RPC,
      [('if op == "" {\n\t\treturn Request{}, ErrFrame\n\t}', 'if op == "" && string(m["operation"]) != `""` {\n\t\treturn Request{}, ErrFrame\n\t}')],
      "narrowing", "Exactly the empty-string operation (non-string operations still refused)",
      None, "unknown")
plant("V9-ok-admits-numeric-one", E, RPC,
      [('case "true":\n\t\tif !exact(m, "protocol", "protocol_version", "request_id", "ok", "body") {',
        'case "true", "1":\n\t\tif !exact(m, "protocol", "protocol_version", "request_id", "ok", "body") {')],
      "narrowing", "A success response whose ok member is the number 1",
      None, "unknown")
plant("M4-meshneg-rpc-unsorted-third-element", N, MESH,
      [("if index > 0 && offered[index-1] >= version {", "if index > 0 && index != 2 && offered[index-1] >= version {")],
      "narrowing (unsorted array admitted at one position)", "A peer rpc array whose THIRD element is out of order or a duplicate",
      None, "unknown")
plant("M5-meshneg-pins-frame-1.0.0", N, MESH,
      [('"2.0.0": 2,\n\t"3.0.0": 3,', '"1.0.0": 1,\n\t"2.0.0": 2,\n\t"3.0.0": 3,')],
      "narrowing (17.1 major-1 boundary)", "Frame 1.0.0 passes the pinned-frame gate (then fails downstream as a non-refusal error)",
      "TestMajor1RejectedThroughNegotiation/frame-1.0.0", "killed")
plant("M6-meshneg-v5-exact-admits-first-element-match", N, MESH,
      [('if frameVersion != "2.0.0" && !slices.Equal(offered, profile["rpc"]) {',
        'if frameVersion != "2.0.0" && !slices.Equal(offered, profile["rpc"]) && !(frameVersion == "5.0.0" && offered[0] == "5.0.0") {')],
      "narrowing (exact-array check weakened to a first-element check for v5)", "Any v5 rpc array beginning with 5.0.0 (e.g. [5.0.0 5.0.1])",
      None, "unknown")
plant("M7-meshneg-select-drops-local-on-no-common", N, MESH,
      [('"local and peer offers share no major ("+joinMajors(local)+" against "+joinMajors(peer)+")",\n\t\t\tappend([]int(nil), local...), peerMajor)',
        '"local and peer offers share no major ("+joinMajors(local)+" against "+joinMajors(peer)+")",\n\t\t\tnil, peerMajor)')],
      "reporting-fact", "A no-common-major refusal with Local == nil",
      None, "unknown")


# ---- inherited advisory N1 re-confirmation on the rev2 tree (4 keys) ------
for key in ["blob", "session_record", "session_annotation", "terminal_backend_evidence"]:
    plant(f"N1-membership-skips-{key}", N, MESH,
          [("if _, ok := hello.Contracts[key]; !ok {", f'if _, ok := hello.Contracts[key]; !ok && key != "{key}" {{')],
          "narrowing (N1 per-key)", f"A hello whose contracts map lacks exactly `{key}` (same key count, a bogus key in its place)",
          "TestPeerOfferKeyMembershipPerKey", "killed")
plant("N2-S12-negotiate-drops-local-fact", N, MESH,
      [("refusal.Local = append([]int(nil), local...)", "refusal.Local = nil")],
      "reporting-fact (N2)", "An offer-originated refusal with Local == nil", "TestNegotiateOfferRefusalCarriesLocal", "killed")
plant("N3-S14-select-admits-local-1", N, MESH,
      [("for _, major := range local {\n\t\tif major < 2 || major > 5 {",
        "for _, major := range local {\n\t\tif major < 1 || major > 5 {")],
      "narrowing (N3)", "Local major 1", "TestSelectHighestCommon/refuse-local-names-1", "killed")


def run(out: Path, only, run_index):
    results = []
    for name, path, pkg, edits, kind, admits, expected_test, expectation in PLANTS:
        if only and name not in only:
            continue
        source = ROOT / path
        original = source.read_bytes()
        text = original.decode()
        planted = text
        for old, new in edits:
            if planted.count(old) != 1:
                raise RuntimeError(f"{name}: plant must match exactly once, got {planted.count(old)} for {old!r}")
            planted = planted.replace(old, new, 1)
        folder = out / name / f"run{run_index}"
        folder.mkdir(parents=True, exist_ok=True)
        replacement = folder / source.name
        replacement.write_text(planted)
        overlay = folder / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
        command = ["go", "test", "-overlay", str(overlay), pkg, "-count=1", "-json", "-timeout=300s"]
        proc = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=900)
        (folder / "test.log").write_bytes(proc.stdout)
        events = []
        for line in proc.stdout.decode(errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        failed = sorted({e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e})
        passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
        build_failed = any(e.get("Action") == "build-fail" for e in events) or (proc.returncode != 0 and not failed and not passed)
        if build_failed:
            state = "COMPILE_FAIL"
        elif proc.returncode != 0 and failed:
            state = "KILLED"
        elif proc.returncode == 0 and passed:
            state = "SURVIVED"
        else:
            state = "INVALID"
        expected_hit = expected_test is None or any(f == expected_test or f.startswith(expected_test + "/") for f in failed)
        if source.read_bytes() != original:
            raise RuntimeError(f"{name}: source changed during overlay run")
        row = {"mutant": name, "kind": kind, "package": pkg, "admits": admits, "run": run_index,
               "exit_code": proc.returncode, "result": state, "expected_test": expected_test,
               "expected_test_failed": expected_hit, "expectation": expectation,
               "named_failing_tests": failed[:12], "failing_count": len(failed), "command": command}
        results.append(row)
        print(f"[run{run_index}] {name}: {state} exit={proc.returncode} failing={len(failed)} first={failed[:3]}", flush=True)
        (out / f"results-run{run_index}.json").write_text(json.dumps(results, indent=2) + "\n")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--only")
    parser.add_argument("--runs", type=int, default=2)
    opts = parser.parse_args()
    out = Path(opts.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    only = set(opts.only.split(",")) if opts.only else None
    all_runs = [run(out, only, i + 1) for i in range(opts.runs)]
    rows = ["| Mutant | Kind | Admits | Expected test (first failing) | Run1 | Run2 | Exit | Expectation |", "| --- | --- | --- | --- | --- | --- | ---: | --- |"]
    by_name = {}
    for rs in all_runs:
        for r in rs:
            by_name.setdefault(r["mutant"], []).append(r)
    bad = False
    for name, rs in by_name.items():
        states = [r["result"] for r in rs]
        exp = rs[0]["expectation"]
        ok = (exp == "killed" and all(s == "KILLED" for s in states) and all(r["expected_test_failed"] for r in rs)) or \
             (exp == "survive-control" and all(s == "SURVIVED" for s in states)) or \
             (exp in ("equivalent-expected", "unknown"))
        if not ok:
            bad = True
        tests = ", ".join(rs[0]["named_failing_tests"][:3]) or "none"
        rows.append(f'| {name} | {rs[0]["kind"]} | {rs[0]["admits"]} | {rs[0]["expected_test"] or "-"} ({tests}) | {states[0]} | {states[1] if len(states) > 1 else "-"} | {rs[0]["exit_code"]} | {exp}{"" if ok else " **MISMATCH**"} |')
    (out / "table.md").write_text("\n".join(rows) + "\n")
    print("\n".join(rows))
    return int(bad)


if __name__ == "__main__":
    sys.exit(main())
