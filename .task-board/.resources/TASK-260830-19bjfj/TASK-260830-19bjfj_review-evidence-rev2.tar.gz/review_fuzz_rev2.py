#!/usr/bin/env python3
"""Reviewer fuzz verification for TASK-260830-19bjfj CR rev2.

1. Runs the three new task-board.config.json fuzz commands verbatim on the
   isolated candidate extract (bounded: -fuzztime=100x -parallel=1).
2. Re-applies the producer's planted controls (their planted.go bytes, via
   -overlay) and records whether each target FAILS as claimed.
3. Applies reviewer controls per target to measure what each oracle can and
   cannot see on the rev2 tree (rev1's nonce-15 and hello-body-extra plants
   re-run; new plants for the P3-1 object gate and the empty operation).
Every run leaves a raw log and a real exit code; sources are never edited.
"""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE / "cand"
OUT = HERE / "reviewer-fuzz"
OUT.mkdir(exist_ok=True)
PRODUCER = HERE / "prod-ev" / "evidence"

CONFIG_COMMANDS = [
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzClosedOperationBodies$ -fuzztime=100x -parallel=1",
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1",
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUnknownFields$ -fuzztime=100x -parallel=1",
]

H = ROOT / "internal/rpcwire/hello.go"
E = ROOT / "internal/rpcwire/envelope.go"
I = ROOT / "internal/rpcwire/inventory.go"

# (name, target, source path, [(old,new)] or None, producer planted file, expectation)
CONTROLS = [
    ("producer-bodies-hello-extensions", "FuzzClosedOperationBodies", H, None, PRODUCER / "fuzz-controls/bodies/planted.go", "FAIL"),
    ("producer-nsvocab-credential", "FuzzNamespaceVocabulary", I, None, PRODUCER / "fuzz-controls/nsvocab/planted.go", "FAIL"),
    ("producer-unknownfields-extra", "FuzzUnknownFields", E, None, PRODUCER / "fuzz-controls/unknownfields/planted.go", "FAIL"),
    ("producer-p3-1-bodies-object-gate", "FuzzClosedOperationBodies", E, None, PRODUCER / "p3-controls/p3-1-opaque-planted.go", "FAIL"),
    ("producer-p3-3-unknownfields-hello-extensions", "FuzzUnknownFields", H, None, PRODUCER / "fuzz-controls/bodies/planted.go", "FAIL"),
    ("rev1-bodies-nonce-15 (stated oracle bound: expected PASS)", "FuzzClosedOperationBodies", H, [("len(b) >= 16", "len(b) >= 15")], None, "measure"),
    ("rev1-unknownfields-hello-body-extra-class", "FuzzUnknownFields", H,
     [("if !exact(m, keys...) {", "if !exact(m, keys...) && len(m) != len(keys)+1 {")], None, "FAIL"),
    ("rev2-bodies-object-gate-exempts-session.status (unseeded member: measure)", "FuzzClosedOperationBodies", E,
     [('\tif _, err = object(m["body"]); err != nil {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {',
       '\tif op != "session.status" {\n\t\tif _, err = object(m["body"]); err != nil {\n\t\t\treturn Request{}, err\n\t\t}\n\t}\n\tif op == "hello" {')], None, "measure"),
    ("rev2-bodies-empty-operation-admitted (oracle bound: measure)", "FuzzClosedOperationBodies", E,
     [('if op == "" {\n\t\treturn Request{}, ErrFrame\n\t}', 'if op == "" && string(m["operation"]) != `""` {\n\t\treturn Request{}, ErrFrame\n\t}')], None, "measure"),
    ("rev2-nsvocab-unsorted-third-element (unseeded member: measure)", "FuzzNamespaceVocabulary", I,
     [("if !slices.Contains(allowed, name) || (i > 0 && names[i-1] >= name) {",
       "if !slices.Contains(allowed, name) || (i > 0 && i != 2 && names[i-1] >= name) {")], None, "measure"),
    ("rev2-bodies-major-1-coerced", "FuzzClosedOperationBodies", E,
     [('case "2.0.0":\n\t\treturn 2, nil', 'case "2.0.0", "1.0.0":\n\t\treturn 2, nil')], None, "measure"),
]


def sh(cmd, log, cwd=ROOT, overlay=None):
    parts = cmd.split()
    if overlay:
        parts = parts[:2] + ["-overlay", str(overlay)] + parts[2:]
    proc = subprocess.run(parts, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
    log.write_bytes(proc.stdout)
    return proc.returncode, proc.stdout.decode(errors="replace")


def main():
    results = []
    for cmd in CONFIG_COMMANDS:
        target = cmd.split("-fuzz=^")[1].split("$")[0]
        code, out = sh(cmd, OUT / f"config-{target}.log")
        tail = [l for l in out.splitlines() if l.strip()][-3:]
        results.append({"kind": "config-command", "command": cmd, "exit": code, "tail": tail})
        print(f"config {target}: exit={code} {tail[-1] if tail else ''}", flush=True)
    for name, target, source, edits, planted_file, expectation in CONTROLS:
        folder = OUT / name.split(" ")[0]
        folder.mkdir(exist_ok=True)
        original = source.read_bytes()
        if edits is None:
            planted = planted_file.read_text()
        else:
            planted = original.decode()
            for old, new in edits:
                if planted.count(old) != 1:
                    raise RuntimeError(f"{name}: plant must match exactly once, got {planted.count(old)}")
                planted = planted.replace(old, new, 1)
        replacement = folder / source.name
        replacement.write_text(planted)
        overlay = folder / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
        cmd = f"go test ./internal/rpcwire -run=^$ -fuzz=^{target}$ -fuzztime=100x -parallel=1"
        code, out = sh(cmd, folder / "fuzz.log", overlay=overlay)
        if source.read_bytes() != original:
            raise RuntimeError(f"{name}: source changed")
        failed = "--- FAIL" in out
        state = "FAIL" if failed else ("PASS" if code == 0 else "OTHER")
        reason = ""
        for l in out.splitlines():
            if "fuzz_adversarial_test.go:" in l:
                reason = l.strip()
                break
        ok = (expectation == "FAIL" and state == "FAIL") or expectation == "measure"
        results.append({"kind": "control", "name": name, "target": target, "exit": code, "state": state,
                        "expectation": expectation, "reason": reason, "mismatch": not ok})
        print(f"control {name}: {state} exit={code} {reason}{'' if ok else '  **MISMATCH**'}", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(any(r.get("mismatch") for r in results))


if __name__ == "__main__":
    sys.exit(main())
