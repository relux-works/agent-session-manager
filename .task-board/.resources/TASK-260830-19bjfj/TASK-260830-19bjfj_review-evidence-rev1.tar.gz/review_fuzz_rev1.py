#!/usr/bin/env python3
"""Reviewer fuzz verification for TASK-260830-19bjfj CR rev1.

1. Runs the three new task-board.config.json fuzz commands verbatim on the
   isolated candidate copy (bounded: -fuzztime=100x -parallel=1).
2. Re-applies the producer's three planted controls (their planted.go, via
   -overlay) and records whether each target FAILS as claimed.
3. Applies reviewer controls of its own per target to measure what each
   target's oracle can and cannot see.
Every run leaves a raw log and a real exit code.
"""
import json
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE / "cand"
OUT = HERE / "reviewer-fuzz"
OUT.mkdir(exist_ok=True)
PRODUCER = HERE / "producer-evidence" / "evidence" / "fuzz-controls"

CONFIG_COMMANDS = [
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzClosedOperationBodies$ -fuzztime=100x -parallel=1",
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1",
    "go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUnknownFields$ -fuzztime=100x -parallel=1",
]

H = ROOT / "internal/rpcwire/hello.go"
E = ROOT / "internal/rpcwire/envelope.go"
I = ROOT / "internal/rpcwire/inventory.go"

# (name, target, source path, [(old,new)] or None for producer planted file, producer control dir, expectation)
CONTROLS = [
    ("producer-bodies", "FuzzClosedOperationBodies", H, None, "bodies", "FAIL"),
    ("producer-nsvocab", "FuzzNamespaceVocabulary", I, None, "nsvocab", "FAIL"),
    ("producer-unknownfields", "FuzzUnknownFields", E, None, "unknownfields", "FAIL"),
    ("reviewer-bodies-nonce-15", "FuzzClosedOperationBodies", H, [("len(b) >= 16", "len(b) >= 15")], None, "measure"),
    ("reviewer-bodies-hello-extra-member", "FuzzClosedOperationBodies", H,
     [("if !exact(m, keys...) {", "if !exact(m, keys...) && len(m) != len(keys)+1 {")], None, "FAIL"),
    ("reviewer-nsvocab-duplicate-admitted", "FuzzNamespaceVocabulary", I, [("names[i-1] >= name", "names[i-1] > name")], None, "FAIL"),
    ("reviewer-nsvocab-future-major-admitted", "FuzzNamespaceVocabulary", I,
     [('if n >= 3 {\n\t\tnames = append(names, "directory_record")', 'if n >= 2 {\n\t\tnames = append(names, "directory_record")')], None, "FAIL"),
    ("reviewer-unknownfields-hello-body-extra", "FuzzUnknownFields", H,
     [("if !exact(m, keys...) {", "if !exact(m, keys...) && len(m) != len(keys)+1 {")], None, "measure"),
    ("reviewer-unknownfields-inventory-body-extra", "FuzzUnknownFields", I,
     [('if err != nil || !exact(m, "namespaces") {', 'if err != nil || !(len(m) <= 2 && m["namespaces"] != nil) {')], None, "FAIL"),
]


def sh(cmd, log, cwd=ROOT, overlay=None):
    parts = cmd.split()
    if overlay:
        parts = parts[:2] + ["-overlay", str(overlay)] + parts[2:]
    proc = subprocess.run(parts, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
    log.write_bytes(proc.stdout)
    return proc.returncode, proc.stdout.decode(errors="replace")


def main():
    results = []
    for cmd in CONFIG_COMMANDS:
        target = cmd.split("-fuzz=^")[1].split("$")[0]
        code, out = sh(cmd, OUT / f"config-{target}.log")
        tail = [l for l in out.splitlines() if l.strip()][-3:]
        results.append({"kind": "config-command", "command": cmd, "exit": code, "tail": tail})
        print(f"config {target}: exit={code} {tail[-1] if tail else ''}", flush=True)
    for name, target, source, edits, producer_dir, expectation in CONTROLS:
        folder = OUT / name
        folder.mkdir(exist_ok=True)
        original = source.read_bytes()
        if edits is None:
            planted = (PRODUCER / producer_dir / "planted.go").read_text()
        else:
            planted = original.decode()
            for old, new in edits:
                if planted.count(old) != 1:
                    raise RuntimeError(f"{name}: plant must match exactly once, got {planted.count(old)}")
                planted = planted.replace(old, new, 1)
        replacement = folder / source.name
        replacement.write_text(planted)
        overlay = folder / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
        cmd = f"go test ./internal/rpcwire -run=^$ -fuzz=^{target}$ -fuzztime=100x -parallel=1"
        code, out = sh(cmd, folder / "fuzz.log", overlay=overlay)
        if source.read_bytes() != original:
            raise RuntimeError(f"{name}: source changed")
        failed = "--- FAIL" in out
        state = "FAIL" if failed else ("PASS" if code == 0 else "OTHER")
        reason = ""
        for l in out.splitlines():
            if "fuzz_adversarial_test.go:" in l:
                reason = l.strip()
                break
        ok = (expectation == "FAIL" and state == "FAIL") or expectation == "measure"
        results.append({"kind": "control", "name": name, "target": target, "exit": code, "state": state,
                        "expectation": expectation, "reason": reason, "mismatch": not ok})
        print(f"control {name}: {state} exit={code} {reason}{'' if ok else '  **MISMATCH**'}", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    return int(any(r.get("mismatch") for r in results))


if __name__ == "__main__":
    sys.exit(main())
