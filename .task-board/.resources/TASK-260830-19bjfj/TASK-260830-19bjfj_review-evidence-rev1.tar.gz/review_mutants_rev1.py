#!/usr/bin/env python3
"""Reviewer mutant harness for TASK-260830-19bjfj CR rev1.

Runs every plant as a `go test -overlay` against the ISOLATED candidate copy
(never the live Story worktree). One raw log per plant per run, real
subprocess exits, named failing tests. Two full runs are taken so a kill is
not Go map-iteration luck.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "cand"
E = "internal/rpcwire/envelope.go"
H = "internal/rpcwire/hello.go"
I = "internal/rpcwire/inventory.go"
N = "internal/meshneg/negotiate.go"
J = "internal/matjournal/store.go"

# (name, path, package, [(old,new),...], kind, what-it-admits, expected_test or None, expectation)
# expectation: "killed" | "survive-control" | "equivalent-expected" | "unknown"
PLANTS = []


def plant(name, path, pkg, edits, kind, admits, expected_test, expectation="killed"):
    PLANTS.append((name, path, pkg, edits, kind, admits, expected_test, expectation))


RPC = "./internal/rpcwire"
MESH = "./internal/meshneg"
MAT = "./internal/matjournal"

# ---- controls -------------------------------------------------------------
plant("C1-rpcwire-harmless-type-annotation", E, RPC,
      [('const Protocol = "urn:ax:protocol:rpc"', 'const Protocol string = "urn:ax:protocol:rpc"')],
      "harmless-control (INVALID: typed constant breaks the catalog.ContractID use at envelope.go:216 -> COMPILE_FAIL; superseded by C1b)", "Nothing (explicit type on an identical constant)", None, "survive-control")
plant("C1b-rpcwire-harmless-comment", E, RPC,
      [("// DecodeRequest inspects one LF-free line, as returned by SSH Session.Receive.",
        "// DecodeRequest inspects one LF-free line as returned by SSH Session.Receive.")],
      "harmless-control", "Nothing (comment punctuation)", None, "survive-control")
plant("C2-meshneg-harmless-comment", N, MESH,
      [("// Error renders the refusal without exposing anything beyond the refusal",
        "// Error renders the refusal without exposing anything beyond the refusal facts")],
      "harmless-control", "Nothing (comment text)", None, "survive-control")

# ---- inherited advisories N1/N2/N3 (predecessor's S7/S8/S9/S12/S14) ------
for key in ["rpc", "session_record", "session_event", "lease", "checkpoint", "workspace_group",
            "provider_identity", "blob", "transfer_manifest", "chunk", "materialization_plan",
            "tombstone", "tombstone_ack", "task_board_bundle",
            "environment_observation", "native_session_observation", "session_inventory_batch",
            "conversation_lineage_link", "session_annotation", "session_enrichment_profile",
            "session_enrichment_job_request", "session_enrichment_job_receipt",
            "session_continuation_plan", "session_directory_operation_receipt",
            "terminal_backend_evidence"]:
    plant(f"N1-membership-skips-{key}", N, MESH,
          [("if _, ok := hello.Contracts[key]; !ok {", f'if _, ok := hello.Contracts[key]; !ok && key != "{key}" {{')],
          "narrowing", f"A hello whose contracts map lacks exactly `{key}` (same key count, a bogus key in its place)",
          None, "equivalent-expected" if key == "rpc" else "killed")
plant("N2-S12-negotiate-drops-local-fact", N, MESH,
      [("refusal.Local = append([]int(nil), local...)", "refusal.Local = nil")],
      "reporting-fact", "An offer-originated refusal with Local == nil", None, "killed")
plant("N3-S14-select-admits-local-1", N, MESH,
      [("for _, major := range local {\n\t\tif major < 2 || major > 5 {",
        "for _, major := range local {\n\t\tif major < 1 || major > 5 {")],
      "narrowing", "Local major 1 (the only member between the refused 0 and the admitted 2)", None, "killed")

# ---- reviewer narrowing plants on gates the producer did not mutate --------
plant("R1-nonce-admits-padded", H, RPC,
      [("func validNonce(s string) bool {\n\tb, err := base64.RawURLEncoding.Strict().DecodeString(s)",
        "func validNonce(s string) bool {\n\tfor len(s) > 0 && s[len(s)-1] == '=' {\n\t\ts = s[:len(s)-1]\n\t}\n\tb, err := base64.RawURLEncoding.Strict().DecodeString(s)")],
      "narrowing", "Any padded base64url nonce (trailing '=' stripped before the strict decode)",
      "TestClosedBodyBoundsWitnessed/nonce-padded-refused", "killed")
plant("R2-root-item-admits-extra-member", I, RPC,
      [('if err != nil || !exact(item, "namespace", "count", "root_id") {',
        'if err != nil || !(len(item) >= 3 && item["namespace"] != nil && item["count"] != nil && item["root_id"] != nil) {')],
      "narrowing", "An inventory.roots success root item carrying an extra member beside namespace/count/root_id",
      None, "unknown")
plant("R3-inventory-body-admits-second-member", I, RPC,
      [('if err != nil || !exact(m, "namespaces") {', 'if err != nil || !(len(m) <= 2 && m["namespaces"] != nil) {')],
      "narrowing", "An inventory.roots request body with exactly one extra member beside namespaces",
      "TestClosedBodyMemberSweep/inventory-extra-member", "killed")
plant("R4-namespaces-unsorted-first-pair-admitted", I, RPC,
      [("if !slices.Contains(allowed, name) || (i > 0 && names[i-1] >= name) {",
        "if !slices.Contains(allowed, name) || (i > 1 && names[i-1] >= name) {")],
      "narrowing", "An unsorted or duplicate FIRST pair of the namespaces array (later pairs still checked)",
      "TestInventoryNamespacesAndCardinality/2.0.0", "killed")
plant("R5-contracts-unsorted-first-pair-admitted", H, RPC,
      [("if !semver.MatchString(v) || (i > 0 && versions[i-1] >= v) {",
        "if !semver.MatchString(v) || (i > 1 && versions[i-1] >= v) {")],
      "narrowing", "An unsorted or duplicate FIRST pair inside a hello contracts version array",
      "TestHelloRefusals/unsorted-versions", "killed")
plant("R6-failure-binding-rpc4-admits-10", E, RPC,
      [("n, _ := major(version)", "n, _ := major(version)\n\t\tif n == 4 {\n\t\t\tn = 2\n\t\t}")],
      "narrowing", "RPC-4 failure documents decoded under the RPC-2 (Error 1.0.0) binding only",
      "TestErrorSchemaNotNegotiated/rpc4-refuses-error-1.0.0", "killed")
plant("R7-zero-expectation-admitted", E, RPC,
      [('if request.id == "" {\n\t\treturn Response{}, ErrCorrelation\n\t}',
        'if request.id == "" && request.version != "" {\n\t\treturn Response{}, ErrCorrelation\n\t}')],
      "narrowing", "A zero Request expectation reaches the version/id comparison instead of refusing ErrCorrelation up front",
      "TestResponseCorrelationClasses/zero-expectation", "killed")
plant("R8-namespaces-upper-bound-plus-one", I, RPC,
      [("if len(names) < 1 || len(names) > len(allowed) {", "if len(names) < 1 || len(names) > len(allowed)+1 {")],
      "bound+1", "A namespaces array one longer than the vocabulary (unreachable: sorted-unique members of a 6/7/8 vocabulary cannot number 7/8/9)",
      None, "equivalent-expected")
plant("R9-opaque-body-nonobject-admitted", E, RPC,
      [('if _, err = object(m["body"]); err != nil {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {',
        'if _, err = object(m["body"]); err != nil && op != "health.get" {\n\t\treturn Request{}, err\n\t}\n\tif op == "hello" {')],
      "narrowing", "A non-object / duplicate-member body for the opaque health.get operation only",
      None, "unknown")
plant("R10-embedded-newline-admitted-at-end", E, RPC,
      [('bytes.ContainsAny(data, "\\n")', '(bytes.ContainsAny(data, "\\n") && data[len(data)-1] != \'\\n\')')],
      "narrowing", "A line whose only LF is the final byte (same shape as the producer's `lf` probe, rerun as a check that the new framing test also kills it)",
      "TestFrameRefusals/newline", "killed")

# ---- meshneg coercion gate ------------------------------------------------
plant("M1-mixed-major-admits-lower", N, MESH,
      [("if major != framing {", "if major > framing {")],
      "narrowing", "An rpc version whose major is LOWER than the framing major (e.g. rpc 1.0.0 inside a 2.0.0 frame, rpc 2.0.0 inside a 3.0.0 frame)",
      "TestMajor1RejectedThroughNegotiation/rpc-1.0.0-in-v2-frame", "killed")
plant("M2-rpc-unsorted-first-pair-admitted", N, MESH,
      [("if index > 0 && offered[index-1] >= version {", "if index > 1 && offered[index-1] >= version {")],
      "narrowing", "An unsorted or duplicate FIRST pair of the peer rpc array",
      "TestNoMajorSelectedByCoercion/unsorted", "killed")
plant("M3-select-highest-skips-5", N, MESH,
      [("if slices.Contains(peer, candidate) && candidate > best {", "if slices.Contains(peer, candidate) && candidate > best && candidate != 5 {")],
      "narrowing", "Major 5 never selected even when common (Config-4 against a v5 frame would refuse no_common_major)",
      None, "killed")

# ---- matjournal: the adopted replay owner (pre-mutation revalidation analogue)
plant("J1-replay-admits-moved-body-after-commit", J, MAT,
      [("if journal.PrepareRequestDigest != digest {", "if journal.PrepareRequestDigest != digest && journal.Phase != PhaseCommitted {"),
       ("if receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {",
        "if (receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical)) && journal.Phase != PhaseCommitted {")],
      "narrowing", "A CHANGED prepare body retried after the journal reached committed replays the receipt instead of idempotency_mismatch (two sites weakened together, both exempt the committed phase only)",
      None, "unknown")
plant("J2-replay-admits-moved-body-any-phase", J, MAT,
      [("if journal.PrepareRequestDigest != digest {", "if journal.PrepareRequestDigest != digest && false {"),
       ("if receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical) {",
        "if false && (receipt.InputDigest != digest || receipt.CanonicalRequest != string(canonical)) {")],
      "arm-delete (reference only)", "Any moved body replays (proves the gate exists; not accepted as narrowing evidence)",
      "TestCreateReplayAndConflict", "killed")


def run(out: Path, only, run_index):
    results = []
    for name, path, pkg, edits, kind, admits, expected_test, expectation in PLANTS:
        if only and name not in only:
            continue
        source = ROOT / path
        original = source.read_bytes()
        text = original.decode()
        planted = text
        for old, new in edits:
            if planted.count(old) != 1:
                raise RuntimeError(f"{name}: plant must match exactly once, got {planted.count(old)} for {old!r}")
            planted = planted.replace(old, new, 1)
        folder = out / name / f"run{run_index}"
        folder.mkdir(parents=True, exist_ok=True)
        replacement = folder / source.name
        replacement.write_text(planted)
        overlay = folder / "overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(replacement)}}))
        command = ["go", "test", "-overlay", str(overlay), pkg, "-count=1", "-json", "-timeout=240s", "-run", "Test"]
        proc = subprocess.run(command, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=600)
        (folder / "test.log").write_bytes(proc.stdout)
        events = []
        for line in proc.stdout.decode(errors="replace").splitlines():
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        failed = sorted({e["Test"] for e in events if e.get("Action") == "fail" and "Test" in e})
        passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
        build_failed = any(e.get("Action") == "build-fail" for e in events) or (proc.returncode != 0 and not failed and not passed)
        if build_failed:
            state = "COMPILE_FAIL"
        elif proc.returncode != 0 and failed:
            state = "KILLED"
        elif proc.returncode == 0 and passed:
            state = "SURVIVED"
        else:
            state = "INVALID"
        expected_hit = expected_test is None or any(f == expected_test or f.startswith(expected_test + "/") for f in failed)
        if source.read_bytes() != original:
            raise RuntimeError(f"{name}: source changed during overlay run")
        row = {"mutant": name, "kind": kind, "package": pkg, "admits": admits, "run": run_index,
               "exit_code": proc.returncode, "result": state, "expected_test": expected_test,
               "expected_test_failed": expected_hit, "expectation": expectation,
               "named_failing_tests": failed[:12], "failing_count": len(failed), "command": command}
        results.append(row)
        print(f"[run{run_index}] {name}: {state} exit={proc.returncode} failing={len(failed)} first={failed[:3]}", flush=True)
        (out / f"results-run{run_index}.json").write_text(json.dumps(results, indent=2) + "\n")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True)
    parser.add_argument("--only")
    parser.add_argument("--runs", type=int, default=2)
    opts = parser.parse_args()
    out = Path(opts.output).resolve()
    out.mkdir(parents=True, exist_ok=True)
    only = set(opts.only.split(",")) if opts.only else None
    all_runs = [run(out, only, i + 1) for i in range(opts.runs)]
    rows = ["| Mutant | Kind | Admits | Expected test | Run1 | Run2 | Exit | Expectation |", "| --- | --- | --- | --- | --- | --- | ---: | --- |"]
    by_name = {}
    for rs in all_runs:
        for r in rs:
            by_name.setdefault(r["mutant"], []).append(r)
    bad = False
    for name, rs in by_name.items():
        states = [r["result"] for r in rs]
        exp = rs[0]["expectation"]
        ok = (exp == "killed" and all(s == "KILLED" for s in states) and all(r["expected_test_failed"] for r in rs)) or \
             (exp == "survive-control" and all(s == "SURVIVED" for s in states)) or \
             (exp in ("equivalent-expected", "unknown"))
        if not ok:
            bad = True
        tests = ", ".join(rs[0]["named_failing_tests"][:3]) or "none"
        rows.append(f'| {name} | {rs[0]["kind"]} | {rs[0]["admits"]} | {rs[0]["expected_test"] or "-"} ({tests}) | {states[0]} | {states[1] if len(states) > 1 else "-"} | {rs[0]["exit_code"]} | {exp}{"" if ok else " **MISMATCH**"} |')
    (out / "table.md").write_text("\n".join(rows) + "\n")
    print("\n".join(rows))
    return int(bad)


if __name__ == "__main__":
    sys.exit(main())
