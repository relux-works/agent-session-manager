package main

import (
	"fmt"
	"os"

	"github.com/relux-works/agent-session-manager/internal/canonicaljson"
)

const zeroDigest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"

func main() {
	cases := []struct {
		name  string
		input string
	}{
		{
			name:  "canonical-session",
			input: `{"schema":"urn:ax:schema:canonical-session","schema_version":"1.0.0","canonical_session_id":"` + zeroDigest + `"}`,
		},
		{
			name:  "terminal-backend-probe",
			input: `{"schema":"urn:ax:schema:terminal-backend-probe","schema_version":"1.0.0","probe_id":"` + zeroDigest + `"}`,
		},
		{
			name:  "clone-raw-object-manifest",
			input: `{"schema":"urn:ax:schema:clone-raw-object-manifest","schema_version":"1.0.0","raw_object_manifest_id":"` + zeroDigest + `"}`,
		},
		{
			name:  "supported-environment-tuples",
			input: `{"schema":"urn:ax:schema:supported-environment-tuples","schema_version":"1.0.0","registry_digest":"` + zeroDigest + `"}`,
		},
	}

	failed := false
	for _, test := range cases {
		_, field, err := canonicaljson.CalculateObjectIdentity([]byte(test.input))
		if err != nil {
			failed = true
			fmt.Printf("FAIL %s: %v\n", test.name, err)
			continue
		}
		fmt.Printf("PASS %s: omitted %s\n", test.name, field)
	}
	if failed {
		os.Exit(1)
	}
}
