# TASK-260830-236x9n Review Verdict

Verdict: **changes requested**. Route: `to-dev`.

Reviewed Change Request `CR-TASK-260830-236x9n-1` revision 1, base
`006ba4ebe1d59525f3ea266497a09848cf781c2c`, candidate tree
`5497c89063f0d0d76ee80ba8715cb81dffec97dd`.

## Blocking finding

`internal/canonicaljson.discoverSelfField` does not implement the
schema-defined omit-self rule. It counts every top-level property whose name is
in the global 18-name self-ID registry and rejects the object unless the count
is exactly one. The pinned specification instead assigns exactly one self field
*per schema*. A valid object may contain other registry names as ordinary
references.

This creates production-entry false refusals for normative v0.5.0 objects:

- Session Annotation has self `annotation_id` and referenced `profile_id`.
- Session Enrichment Job Request has self `job_request_id` and referenced
  `profile_id`.
- Session Enrichment Job Receipt has self `job_receipt_id` and referenced
  `job_request_id` plus `profile_id`.
- Session Directory Operation Receipt has self `directory_receipt_id` and
  referenced `plan_id`.

The task-scoped probe drove the exported production entry
`canonicaljson.CalculateObjectIdentity`. All four objects were refused with
`object contains N self-identity fields`, before the schema-defined self field
could be omitted. This violates the requirement to implement every omit-self
identity calculation and is the negative-evidence shape **a narrowed gate that
rejects members of the required class**. The existing test loops over one
synthetic self field at a time, so it cannot detect the collision.

Required rework:

1. Resolve the omit field from the validated `schema`/`schema_version` contract
   (or equivalent trusted schema metadata), not by globally counting property
   names and not from an arbitrary caller-selected field.
2. Permit other registered ID names when the selected schema defines them as
   references, while omitting exactly the schema's own self field.
3. Add production-entry calculate/verify fixtures for at least the four
   normative collision shapes above. Include a narrowing mutant or equivalent
   test that maps one schema to the wrong referenced ID and fails.
4. Correct the README claim that every object contains exactly one known
   top-level registry name; the normative rule is exactly one schema-defined
   self field.

## Validation evidence

- Candidate/worktree content comparison: 16 relevant paths matched candidate
  tree blobs exactly.
- `go test ./internal/canonicaljson -count=1 -v`: pass.
- `go test ./internal/canonicaljson -cover -count=1`: pass, 82.6%.
- `go run ./internal/traceability/cmd/tracecheck -section 1.6 -section 10.1
  -section 10.2 -section 10.3 -section 10.4`: pass.
- Default tracecheck: pass.
- `tracecheck -section 10.999`: expected refusal, exit 1.
- `go test ./... -v -count=1`: pass.
- `go test ./... -cover -count=1`: pass.
- `go vet ./...`, `go build ./...`, `go mod verify`, and changed-file
  `gofmt -d`: pass/clean.
- Reviewer production probe: expected-red, exit 1, reproducing all four false
  refusals.

No durable state is mutated by this package, so crash/recovery evidence for a
durable mutation is not applicable. The README correctly avoids advertising
doctor, migration publication, or runtime capability support.

## Dependency assessment

`github.com/gowebpki/jcs v1.0.1` is load-bearing in this candidate, not merely
convenient. Repository code delegates both canonicalization paths to
`jcs.Transform`; the dependency supplies ECMAScript-compatible number
serialization, string serialization, and UTF-16 property ordering. Removing it
requires a complete replacement canonical serializer and rerunning the RFC
8785 vectors. The production package dependency graph adds only `jcs`; the
`testify`/YAML entries visible in `go.sum` come from the dependency module graph
and are not compiled into the production package.

The dependency choice is therefore a separate owner architecture/supply-chain
decision. It does not change this revision's `changes requested` verdict,
which is required by the schema-directed identity defect above.
