package main

import (
	"fmt"
	"os"

	"github.com/relux-works/agent-session-manager/internal/canonicaljson"
)

const digest = "sha256:0000000000000000000000000000000000000000000000000000000000000000"

func main() {
	cases := []struct {
		name  string
		input string
	}{
		{
			name: "session-enrichment-job-request",
			input: `{"schema":"urn:ax:schema:session-enrichment-job-request",` +
				`"schema_version":"1.0.0","job_request_id":"` + digest + `",` +
				`"profile_id":"` + digest + `"}`,
		},
		{
			name: "session-annotation",
			input: `{"schema":"urn:ax:schema:session-annotation",` +
				`"schema_version":"1.0.0","annotation_id":"` + digest + `",` +
				`"profile_id":"` + digest + `"}`,
		},
		{
			name: "session-enrichment-job-receipt",
			input: `{"schema":"urn:ax:schema:session-enrichment-job-receipt",` +
				`"schema_version":"1.0.0","job_receipt_id":"` + digest + `",` +
				`"job_request_id":"` + digest + `","profile_id":"` + digest + `"}`,
		},
		{
			name: "session-directory-operation-receipt",
			input: `{"schema":"urn:ax:schema:session-directory-operation-receipt",` +
				`"schema_version":"1.0.0","directory_receipt_id":"` + digest + `",` +
				`"plan_id":"` + digest + `"}`,
		},
	}

	failed := false
	for _, test := range cases {
		got, field, err := canonicaljson.CalculateObjectIdentity([]byte(test.input))
		fmt.Printf("%s: digest=%q self_field=%q error=%v\n", test.name, got, field, err)
		if err != nil {
			failed = true
		}
	}
	if failed {
		os.Exit(1)
	}
}
