# TASK-260830-236x9n — JCS and identity implementation notes

## Normative inputs

- AX specification: `relux-works/agent-session-manager-spec@v0.5.0`, commit `28bf96d7dd7ebf3cd9e2ccd91d35b8660699dd5c`.
- Assigned scope: Sections 1.6, 10.1 through 10.4, and 17.3.
- JCS source: RFC 8785, especially Sections 3.1, 3.2.1 through 3.2.4 and Appendices B and G.

## Implementation boundary

1. `Canonicalize` is the RFC 8785 production entry. It accepts the JCS/I-JSON number surface, validates duplicate names, UTF-8, and surrogate pairing, and delegates the canonical byte transform to the RFC-listed Go implementation.
2. `CalculateObjectIdentity` is the AX logical-object production entry. Before hashing it rejects floating-point literals and integers outside `[-9007199254740991, 9007199254740991]`.
3. The identity entry discovers the self field from the exact Section 1.6 set. It requires exactly one known field and removes it without accepting a caller-selected field. This prevents an arbitrary omit choice, self inclusion, and digest cycles.
4. `VerifyObjectIdentity` requires the claimed self field to contain a valid SHA-256 identifier equal to the calculated omit-self digest.
5. `chunk_id` is intentionally absent from the omit-self set because Section 10.3 defines it as the digest of raw chunk bytes.

## Exact self-field set

`record_id`, `event_id`, `checkpoint_id`, `descriptor_id`, `manifest_id`, `plan_id`, `tombstone_id`, `ack_id`, `bundle_id`, `marker_id`, `observation_id`, `batch_id`, `lineage_link_id`, `annotation_id`, `profile_id`, `job_request_id`, `job_receipt_id`, and `directory_receipt_id`.

## Evidence plan

- RFC 8785 Section 3 primitive/string/sorting examples and all finite Appendix B number samples through the production `Canonicalize` entry.
- AX `JCS-UTF16-ORDER`, safe integer, and Blob Descriptor fixtures through production identity calculation.
- Stability under key reordering, whitespace, current self-ID value, and repeated calculation.
- Refusal of duplicate keys, malformed UTF-8/surrogates, unsafe/floating numbers in AX identity objects, absent/multiple self fields, raw `chunk_id`, malformed claims, and a self-included full-object digest.

The package is read-only and performs no durable mutation; crash recovery is therefore not applicable. Repeated calls are covered as deterministic/idempotent reads.
