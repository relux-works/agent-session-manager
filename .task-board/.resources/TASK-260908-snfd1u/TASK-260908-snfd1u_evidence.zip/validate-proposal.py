from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/Users/iv/Developer/ReluxWorks/agent-session-manager')
out=root/'.temp/TASK-260908-snfd1u'
p=out/'TASK-260908-snfd1u_proposal.md'
s=p.read_text()
words=len(s.split())
assert 1500<=words<=2200,words
assert s.count('```')%2==0
for token in ['PROPOSED','D1','D2','D3','D4','SSH_ORIGINAL_COMMAND','Tailscale','Configuration 4.0.0','initial lease','176/177','membership','UUIDv7','--to','external','TLS 1.3']:
 assert token in s,token
resources=re.findall(r'board-resource://([^/]+)/outcome/([^\)]+)',s)
assert len(resources)==4
for task,name in resources:
 assert (root/'.task-board/.resources'/task/name).is_file(),name
baseline=json.loads((out/'source-snapshot-01.json').read_text())
for story,b in baseline.items():
 w=root/'.temp'/story/'worktree'
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()
 status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=w,text=True)
 assert head==b['head'],(story,'HEAD changed')
 assert status==b['status'],(story,'status changed')
 paths=subprocess.check_output(['git','ls-files','-z','--cached','--others','--exclude-standard'],cwd=w).decode().split('\0')
 hashes={f:hashlib.sha256((w/f).read_bytes()).hexdigest() for f in paths if f and (w/f).is_file() and not f.startswith('.task-board/')}
 assert hashes==b['files'],(story,'bytes changed')
 print(f'{story}: {len(hashes)}/{len(hashes)} snapshotted files unchanged; HEAD={head}; HEAD..local-main={b["behind_local_main"]}')
 assert hashes['internal/specdoc/SPEC.md']=='562546d240f0fa3e71b47e6359a002f9892c0efd97e19eb55917527552ac484a'
print(f'Proposal: {words} words; four source-resource references exist; both specification pins match')
print('PASS: bounded document/reference/preservation checks. No product behavior or live platform conformance measured.')
