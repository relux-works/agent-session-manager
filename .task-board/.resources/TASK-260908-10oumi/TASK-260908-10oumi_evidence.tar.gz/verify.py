import copy,json,os,pathlib,subprocess
root=pathlib.Path.cwd(); out=pathlib.Path('/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/handoff-260908/TASK-260908-10oumi')
config=json.loads((root/'task-board.config.json').read_text())
def preflight(path,role,agent,workload):
 cmd=['task-board','q',f'project_config(view=spawn-preflight, role={role}, agent={agent}, workload_class={workload})']
 p=subprocess.run(cmd,env=dict(os.environ,TASK_BOARD_CONFIG=str(path)),capture_output=True,text=True)
 return p,json.loads(p.stdout)
def check(path,workload):
 role='reviewer' if workload=='review' else 'developer'
 p,data=preflight(path,role,'codex',workload)
 assert p.returncode==0,(p.returncode,p.stdout,p.stderr)
 assert data['providers']['allowed']==['codex'],'provider_admission'
 assert data['resolved_role_ceiling']['admitted_pairs']['models']==[{'id':'gpt-6-astra','efforts':['medium','high']}],'exact_pairs'
 efforts=['medium','high'] if workload in ['mechanical','documentation','operations'] else ['high','medium']
 expected=[{'runtime':'codex','model':'gpt-6-astra','reasoning_effort':effort} for effort in efforts]
 actual=[{k:r[k] for k in ['runtime','model','reasoning_effort']} for r in data['workload_class_recommendation']['recommendations']]
 assert actual==expected,'recommendations'
 return data
results={}
for workload in config['spawn']['workload_classes']:
 results[workload]=check(root/'task-board.config.json',workload)
 print(f'PASS preflight_{workload}: exit 0')
for agent in ['claude','muse','fable']:
 p,data=preflight(root/'task-board.config.json','reviewer',agent,'review')
 assert p.returncode==1 and 'agent_not_allowed_by_preferred_agentic_system' in str(data),(p.returncode,data)
 results[agent]={'exit_code':p.returncode,'result':data}
 print(f'PASS reject_{agent}: actual exit 1 (expected provider refusal)')
baseline=json.loads(subprocess.check_output(['git','show','HEAD:task-board.config.json'],text=True))
remaining=copy.deepcopy(config)
for obj in [baseline,remaining]:
 obj['spawn'].pop('preferred_agentic_system'); obj['spawn'].pop('workload_classes'); obj['spawn']['ceilings'].pop('codex')
assert baseline==remaining,'unrelated fields changed'
print('PASS preserve_unrelated_fields')
mutants=[('admit_astra_low',lambda c:c['spawn']['ceilings']['codex']['entries'].append({'criterion':'equal','model':'gpt-6-astra','reasoning_effort':'low'}),'exact_pairs'),('admit_claude',lambda c:c['spawn'].__setitem__('preferred_agentic_system',{'mixed':['codex','claude']}),'provider_admission')]
for name,mutate,failure in mutants:
 c=json.loads((root/'task-board.config.json').read_text());mutate(c);path=out/(name+'.json');path.write_text(json.dumps(c))
 try:check(path,'review')
 except AssertionError as e:
  assert str(e)==failure,str(e)
  print(f'KILLED {name}: preflight_review fails {failure}')
 else:raise AssertionError(f'SURVIVOR {name}')
(out/'preflights.json').write_text(json.dumps(results,indent=2)+'\n')
