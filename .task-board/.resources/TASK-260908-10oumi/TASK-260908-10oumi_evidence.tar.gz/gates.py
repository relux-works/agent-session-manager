import json,os,pathlib,subprocess,sys
out=pathlib.Path(__file__).parent
commands=json.loads(pathlib.Path('task-board.config.json').read_text())['spawn']['worktree_isolation']['validation']['commands']
for i in range(int(sys.argv[1]),int(sys.argv[2])):
 cmd=commands[i]
 with (out/f'gate-{i+1:02}.log').open('w') as f:
  p=subprocess.run(['zsh','-o','pipefail','-c',cmd],stdout=f,stderr=subprocess.STDOUT,timeout=540)
 with (out/'gate-results.jsonl').open('a') as f:f.write(json.dumps({'index':i+1,'command':cmd,'exit_code':p.returncode})+'\n')
 print(f'Gate {i+1}: exit {p.returncode}',flush=True)
 if p.returncode:sys.exit(p.returncode)
