#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-kkh1an-3 (RUN-260918-f6b44c).

Each row: apply the edits to one production file in an isolated copy,
run (a) the COMMITTED suite only (`go test -skip TestRV3`) and (b) the
reviewer witness (`go test -run <witness>`), restore the file, verdict
per run from the exit code plus a kill line. Raw per-plant logs with
subprocess exits are written to the out directory.
"""
import os, subprocess, sys, shutil, pathlib, tempfile, hashlib

REPO = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
PKG = "internal/terminstance"

ROWS = [
    dict(name="RV3-M1-auth-expiry-recheck-entry-instant", path="execute.go",
         edits=[("\tperformed := []terminalbackend.SideEffect(nil)\n\tfor _, effect := range effects {\n",
                 "\tperformed := []terminalbackend.SideEffect(nil)\n\tentryNow := engine.Now()\n\tfor _, effect := range effects {\n"),
                ("\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n",
                 "\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), entryNow); err != nil {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n")],
         witness="TestRV3W_M1_AuthExpiryRecheckedBeforeEachEffect",
         kind="NARROWING (recheck dropped on one axis: per-effect authorization EXPIRY is evaluated at the entry instant; the lease tuple recheck stays)"),
    dict(name="RV3-M2-evidence-bound-257", path="result.go",
         edits=[("\tif len(evidence) > 256 {\n", "\tif len(evidence) > 257 {\n")],
         witness="TestRV3W_M2_EvidenceBoundEdge",
         kind="NARROWING (bound widened by one: digest[0..256] admits exactly 257 on results and status reports)"),
    dict(name="RV3-M3-conditional-disposition-collapsed", path="execute.go",
         edits=[("\tif err := checkCapabilityConditional(operation, params, admitted); err != nil {\n\t\tfailure := err.(*Error)\n\t\treturn buildResult(context, source, source, nil, nil, DispositionFor(failure.Code, false)), failure\n",
                 "\tif err := checkCapabilityConditional(operation, params, admitted); err != nil {\n\t\tfailure := err.(*Error)\n\t\treturn buildResult(context, source, source, nil, nil, DispositionStatusFirst), failure\n")],
         witness="TestRV3W_M3_ConditionalCapabilityDisposition",
         kind="NARROWING (disposition mapping collapsed at one engine arm: the capability-conditional refusal reports status_first instead of the class-mapped required_operator_action)"),
    dict(name="RV3-M4-proof-kind-sibling-admitted", path="proof.go",
         edits=[("\tdefault:\n\t\treturn \"\", refuse(CodeProtocolError, \"provider proof vocabulary\")\n\t}\n}\n\n// RequiresProviderObservation",
                 "\tdefault:\n\t\tif value == \"provider_process_observation\" {\n\t\t\treturn ProofProviderQuiescence, nil\n\t\t}\n\t\treturn \"\", refuse(CodeProtocolError, \"provider proof vocabulary\")\n\t}\n}\n\n// RequiresProviderObservation")],
         witness="TestRV3W_M4_ProofKindSiblingNamesRefused",
         kind="NARROWING (closed-enum member admitted: the landed capability name provider_process_observation parses as a proof kind)"),
    dict(name="RV3-M6-remote-fence-ignores-live-source", path="fencing.go",
         edits=[("\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner {\n\t\treturn fenceLive(current, authErr)\n",
                 "\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner {\n\t\treturn terminalbackend.StateStaleFenced, true, nil\n")],
         witness="TestObserveFencingNonLiveSourcesLeaveState",
         kind="NARROWING (remote-winner fencing skips the live-source gate: absent/stopped/stale_fenced/unavailable fence under a remote winner)"),
    dict(name="RV3-M7-loop-deadline-skipped-after-commit", path="execute.go",
         edits=[("\tfor _, effect := range effects {\n\t\tif !engine.Now().Before(deadline) {\n",
                 "\tfor _, effect := range effects {\n\t\tif !committed && !engine.Now().Before(deadline) {\n")],
         witness="TestExecuteDeadlineNeverCancelsCommittedEffect",
         kind="NARROWING (recheck dropped: the in-loop deadline is not re-read once an effect committed, so a deadline arriving mid-operation no longer cancels the remaining waits)"),
    dict(name="RV3-M8-status-last-operation-empty-admitted", path="execute.go",
         edits=[("\tif observed.LastOperationID != nil {\n\t\tif _, err := scalar.ParseUUIDv7(*observed.LastOperationID); err != nil {\n",
                 "\tif observed.LastOperationID != nil && *observed.LastOperationID != \"\" {\n\t\tif _, err := scalar.ParseUUIDv7(*observed.LastOperationID); err != nil {\n")],
         witness="TestRV3W_M8_StatusLastOperationGrammar",
         kind="NARROWING (status report last_operation_id grammar admits exactly the empty string)"),
    dict(name="RV3-K-known-kill-control", path="auth.go",
         edits=[("\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 1, MaxLeaseEpoch)\n",
                 "\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 0, MaxLeaseEpoch)\n")],
         witness="TestParseAXAuthorizationEpochBound",
         kind="CONTROL (known-killed narrowing: proves the instrument reports kills)"),
    dict(name="RV3-C-comment-control", path="doc.go",
         edits=[("// Package terminstance executes the Terminal Instance lifecycle contract of\n",
                 "// Package terminstance executes the Terminal Instance lifecycle contract of (reviewer control)\n")],
         witness="TestRequiresProviderObservation",
         kind="CONTROL (harmless comment-only edit: must SURVIVE)"),
    dict(name="RV3-B-build-break-control", path="proof.go",
         edits=[("type ProviderProofKind string\n", "type ProviderProofKind string\nvar _ = undefinedReviewerSymbol\n")],
         witness="TestRequiresProviderObservation",
         kind="CONTROL (build break: must report ERROR, never a verdict)"),
]

def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()

def run(args, log):
    r = subprocess.run(args, cwd=REPO, capture_output=True, text=True, timeout=600)
    out = (r.stdout + r.stderr)
    log.write_text(f"# cmd: {' '.join(args)}\n# subprocess exit {r.returncode}\n{out}")
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "ERROR(build broke)"
    if r.returncode == 0:
        return "SURVIVED"
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED"
    return f"ERROR(exit {r.returncode}, no kill line)"

def main():
    summary = []
    for row in ROWS:
        target = REPO / PKG / row["path"]
        original = target.read_text()
        before = sha(target)
        patched = original
        ok = True
        for find, repl in row["edits"]:
            if patched.count(find) != 1:
                summary.append(f"ERROR: {row['name']}: anchor count {patched.count(find)} != 1")
                ok = False
                break
            patched = patched.replace(find, repl)
        if not ok:
            continue
        try:
            target.write_text(patched)
            (OUT / f"{row['name']}.diff").write_text(subprocess.run(["git", "diff", "--", f"{PKG}/{row['path']}"], cwd=REPO, capture_output=True, text=True).stdout)
            committed = run(["go", "test", f"./{PKG}/", "-skip", "TestRV3", "-count=1"], OUT / f"{row['name']}.committed.log")
            witness = run(["go", "test", f"./{PKG}/", "-run", row["witness"], "-count=1", "-v"], OUT / f"{row['name']}.witness.log")
        finally:
            target.write_text(original)
        after = sha(target)
        restored = "restored" if after == before else "RESTORE-FAILED"
        line = f"{row['name']}: committed-suite={committed} witness[{row['witness']}]={witness} ({restored}) :: {row['kind']}"
        print(line, flush=True)
        summary.append(line)
    (OUT / "SUMMARY.txt").write_text("\n".join(summary) + "\n")

if __name__ == "__main__":
    main()
