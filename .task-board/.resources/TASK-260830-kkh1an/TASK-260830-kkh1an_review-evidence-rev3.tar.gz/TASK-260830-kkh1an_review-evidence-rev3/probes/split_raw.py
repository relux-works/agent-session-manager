#!/usr/bin/env python3
"""Split an AX_MUTANT_VERBOSE=1 harness log into per-plant raw logs."""
import re, sys, pathlib
src = pathlib.Path(sys.argv[1]); out = pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
text = src.read_text()
n = 0
for m in re.finditer(r'--- raw: (\S+): exit (-?\d+) ---\n(.*?)\n--- end raw: \1 ---', text, re.S):
    name, code, body = m.group(1), m.group(2), m.group(3)
    (out / f"{name}.log").write_text(f"# plant {name}\n# subprocess exit {code}\n{body}\n")
    n += 1
print(f"split {n} plants into {out}")
