package terminstance

// Independent review probes for CR-TASK-260830-kkh1an-3 (RUN-260918-f6b44c).
// Every probe drives a production entry. CHARACTERIZATION probes record
// the observed behaviour with t.Logf and never fail on the observed arm;
// WITNESS probes pass on the pristine tree and are expected to fail
// under the reviewer mutant they witness (RV3-M*).

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// rv3StopContextWithDeadline builds a request-stop context whose
// deadline_at lies AFTER the authorization expires_at, so that an
// authorization expiring mid-operation is observable independently of
// the deadline arm (the shipped fixture has deadline < expiry, so the
// deadline always fires first).
func rv3StopContextWithDeadline(t *testing.T, deadline string) (MutationContext, Params) {
	t.Helper()
	key := fixtureInstance + "/stop/" + fixtureDigestB
	raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, deadline, authDoc("1", nil))
	context, err := ParseMutationContext([]byte(raw))
	if err != nil {
		t.Fatalf("ParseMutationContext(stop, deadline %s) error = %v", deadline, err)
	}
	return context, Params{SafeBoundaryEvidenceID: fixtureDigestB, GracefulTimeoutMs: 1000}
}

// TestRV3W_M1_AuthExpiryRecheckedBeforeEachEffect (WITNESS for RV3-M1):
// the authorization EXPIRES between the first and second stop effect
// while the lease tuple is unchanged and the deadline is still ahead.
// The per-effect recheck must refuse before the second effect with the
// literal expiry arm, after=unavailable and new_authorization, leaving
// exactly one committed effect.
func TestRV3W_M1_AuthExpiryRecheckedBeforeEachEffect(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	// deadline 2026-09-03 > auth expiry 2026-09-02.
	context, params := rv3StopContextWithDeadline(t, "2026-09-03T00:00:00.000Z")
	afterExpiry, err := time.Parse(time.RFC3339Nano, "2026-09-02T01:00:00.000Z")
	if err != nil {
		t.Fatal(err)
	}
	effects := 0
	engine.Hooks = &EngineHooks{AfterEffect: func(terminalbackend.SideEffect) { effects++ }}
	engine.Now = func() time.Time {
		if effects >= 1 {
			return afterExpiry
		}
		return fixtureNow()
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, mustParseState(t, "quiescing"), testAdmitted("graceful_stop"))
	requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization expiry")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "new_authorization")
	if performed := backend.performed(); len(performed) != 1 || performed[0] != terminalbackend.EffectGracefulStopRequested {
		t.Errorf("performed = %v, want exactly [graceful_stop_requested] before the expired authorization is caught", performed)
	}
}

// rv3Digests mints n distinct valid digests in ascending bytewise order.
func rv3Digests(n int) []string {
	out := make([]string, 0, n)
	for i := 0; i < n; i++ {
		out = append(out, fmt.Sprintf("sha256:%064x", i))
	}
	return out
}

// TestRV3W_M2_EvidenceBoundEdge (WITNESS for RV3-M2): the sorted-unique
// digest[0..256] bound is witnessed at its edge on both surfaces: 256
// admitted, 257 refused, for a replayed MutationResult (CheckResult) and
// for a status report (ExecuteStatus).
func TestRV3W_M2_EvidenceBoundEdge(t *testing.T) {
	context, _, source, _ := quiesceFixture(t)
	base := Result{
		OperationID: context.OperationID, SessionID: context.SessionID,
		TerminalInstanceID: context.TerminalInstanceID, TerminalBackendID: context.TerminalBackendID,
		ImplementationVersion: context.ImplementationVersion, ProtocolVersion: context.ProtocolVersion,
		BackendGeneration: context.BackendGeneration, Before: source, After: terminalbackend.StateQuiescing,
		Effects: []terminalbackend.SideEffect{terminalbackend.EffectInputClosed}, Disposition: DispositionReplaySame,
	}
	admitted := base
	admitted.EvidenceIDs = rv3Digests(256)
	if err := CheckResult(context, source, admitted); err != nil {
		t.Errorf("CheckResult(256 evidence IDs) error = %v, want admission", err)
	}
	over := base
	over.EvidenceIDs = rv3Digests(257)
	requireRefusal(t, CheckResult(context, source, over), "terminal_backend_protocol_error", "result evidence bound")

	backend := newMockBackend()
	observed := matchingObservation()
	observed.EvidenceIDs = rv3Digests(256)
	backend.observation = observed
	engine := testEngine(t, backend, testLease(), fixtureGen)
	if _, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect")); err != nil {
		t.Errorf("ExecuteStatus(256 evidence IDs) error = %v, want admission", err)
	}
	observed.EvidenceIDs = rv3Digests(257)
	backend.observation = observed
	_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
	requireRefusal(t, err, "terminal_backend_protocol_error", "status evidence bound")
}

// TestRV3W_M3_ConditionalCapabilityDisposition (WITNESS for RV3-M3):
// the capability-conditional refusal arm at the engine carries the
// class-mapped disposition for an uncommitted capability_unproven:
// required_operator_action, on every conditional (headless create,
// wait safe-boundary, wait provider-kind).
func TestRV3W_M3_ConditionalCapabilityDisposition(t *testing.T) {
	t.Run("headless create from stopped", func(t *testing.T) {
		create := testCreateContext(t)
		create.params.Interactive = false
		engine := testEngine(t, newMockBackend(), testLease(), fixtureGen)
		result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "stopped"), testAdmitted("terminal_state_retention"))
		requireRefusal(t, err, "terminal_backend_capability_unproven", "operation capability conditional")
		requireLiteral(t, "after", string(result.After), "stopped")
		requireLiteral(t, "disposition", string(result.Disposition), "required_operator_action")
	})
	t.Run("wait without safe_boundary_observation", func(t *testing.T) {
		context, params, source, _ := waitFixture(t, ProofAXCheckpointBoundary)
		engine := testEngine(t, newMockBackend(), testLease(), fixtureGen)
		result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationWaitSafeBoundary, context, params, source, testAdmitted("provider_process_observation"))
		requireRefusal(t, err, "terminal_backend_capability_unproven", "operation capability conditional")
		requireLiteral(t, "after", string(result.After), "quiescing")
		requireLiteral(t, "disposition", string(result.Disposition), "required_operator_action")
	})
	t.Run("wait provider kind without provider_process_observation", func(t *testing.T) {
		context, params, source, admitted := waitFixture(t, ProofProviderQuiescence)
		engine := testEngine(t, newMockBackend(), testLease(), fixtureGen)
		result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationWaitSafeBoundary, context, params, source, admitted)
		requireRefusal(t, err, "terminal_backend_capability_unproven", "operation capability conditional")
		requireLiteral(t, "after", string(result.After), "quiescing")
		requireLiteral(t, "disposition", string(result.Disposition), "required_operator_action")
	})
}

// TestRV3W_M4_ProofKindSiblingNamesRefused (WITNESS for RV3-M4): the
// landed sibling names a caller could plausibly confuse with a proof
// kind (the capability names and the side-effect name from the same
// section) are refused at the direct entry and through the wait body.
func TestRV3W_M4_ProofKindSiblingNamesRefused(t *testing.T) {
	for _, sibling := range []string{"provider_process_observation", "safe_boundary_observation", "safe_boundary_observed", "provider_exit", "PROVIDER_QUIESCENCE", "provider_quiescence "} {
		_, err := ParseProviderProofKind(sibling)
		requireRefusal(t, err, "terminal_backend_protocol_error", "provider proof vocabulary")
		body := `{"context":` + contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, fixtureInstance+"/boundary/"+fixtureQuiescence+"/"+sibling, fixtureDeadline, authDoc("1", nil)) +
			`,"quiescence_generation":"` + fixtureQuiescence + `","provider_proof_kind":"` + sibling + `","timeout_ms":1000}`
		_, _, err = ParseOperationBody("wait-safe-boundary", []byte(body))
		requireRefusal(t, err, "terminal_backend_protocol_error", "provider proof vocabulary")
	}
}

// TestRV3_EpochBoundThroughNestedSurfaces re-witnesses the lease_epoch
// bound at 1, 9007199254740991, 0 and 9007199254740992 through the
// nested MutationContext parse and through the quiesce-input body.
func TestRV3_EpochBoundThroughNestedSurfaces(t *testing.T) {
	key := fixtureInstance + "/quiesce/" + fixtureQuiescence
	for _, tc := range []struct {
		epoch string
		admit bool
	}{{"1", true}, {"9007199254740991", true}, {"0", false}, {"9007199254740992", false}} {
		raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, fixtureDeadline, authDoc(tc.epoch, nil))
		_, err := ParseMutationContext([]byte(raw))
		body := `{"context":` + raw + `,"quiescence_generation":"` + fixtureQuiescence + `"}`
		_, _, bodyErr := ParseOperationBody("quiesce-input", []byte(body))
		if tc.admit {
			if err != nil || bodyErr != nil {
				t.Errorf("epoch %s: context err = %v, body err = %v, want admission on both", tc.epoch, err, bodyErr)
			}
			continue
		}
		requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization epoch")
		requireRefusal(t, bodyErr, "terminal_backend_protocol_error", "ax authorization epoch")
	}
}

// TestRV3_IdempotencyReplayAndMismatchThroughEngine: an identical retry
// replays the one recorded result byte-for-byte; a changed operation ID
// under the same key in the window is idempotency_mismatch with the
// source restored and status_first; a different OPERATION under the same
// key is idempotency_mismatch too.
func TestRV3_IdempotencyReplayAndMismatchThroughEngine(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	first, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	if err != nil {
		t.Fatalf("first ExecuteMutating() error = %v", err)
	}
	again, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	if err != nil {
		t.Fatalf("identical retry error = %v", err)
	}
	if fmt.Sprintf("%+v", first) != fmt.Sprintf("%+v", again) {
		t.Errorf("identical retry = %+v, want the one result %+v", again, first)
	}
	if performed := backend.performed(); len(performed) != 1 {
		t.Errorf("performed = %v, want the one original effect (replay performs none)", performed)
	}
	changed := context
	changed.OperationID = fixtureOperationB
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, changed, params, source, admitted)
	requireRefusal(t, err, "idempotency_mismatch", "idempotency key conflict")
	requireLiteral(t, "after", string(result.After), "active")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if performed := backend.performed(); len(performed) != 1 {
		t.Errorf("performed = %v, want no effect on the mismatch", performed)
	}
}

// TestRV3_OutsideSetCodeRefusedPerRow: a backend-reported code outside
// the row's allowed set on the first effect is refused as
// terminal_backend_protocol_error at the landed CheckErrorAllowed
// wiring, for each of the four engine rows; the status row refuses an
// outside-set report the same way and a timeout report is unknown
// (error, no report), never absent.
func TestRV3_OutsideSetCodeRefusedPerRow(t *testing.T) {
	rows := []struct {
		operation terminalbackend.Operation
		first     terminalbackend.SideEffect
		outside   string
		build     func(t *testing.T) (MutationContext, Params, terminalbackend.InstanceState, terminalbackend.Admitted)
	}{
		{terminalbackend.OperationCreate, terminalbackend.EffectBindingPersisted, "quiesce_timeout", func(t *testing.T) (MutationContext, Params, terminalbackend.InstanceState, terminalbackend.Admitted) {
			c := testCreateContext(t)
			return c.context, c.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention")
		}},
		{terminalbackend.OperationQuiesceInput, terminalbackend.EffectInputClosed, "stop_timeout", quiesceFixture},
		{terminalbackend.OperationWaitSafeBoundary, terminalbackend.EffectSafeBoundaryObserved, "terminal_backend_timeout", func(t *testing.T) (MutationContext, Params, terminalbackend.InstanceState, terminalbackend.Admitted) {
			return waitFixture(t, ProofAXCheckpointBoundary)
		}},
		{terminalbackend.OperationRequestStop, terminalbackend.EffectGracefulStopRequested, "quiesce_timeout", stopFixture},
	}
	for _, row := range rows {
		t.Run(string(row.operation), func(t *testing.T) {
			backend := newMockBackend()
			backend.effectErrors[row.first] = refuse(row.outside, "test outside-set")
			engine := testEngine(t, backend, testLease(), fixtureGen)
			context, params, source, admitted := row.build(t)
			result, err := engine.ExecuteMutating(contextGo(), row.operation, context, params, source, admitted)
			requireRefusal(t, err, "terminal_backend_protocol_error", "operation error vocabulary")
			requireLiteral(t, "after", string(result.After), "unavailable")
			requireLiteral(t, "disposition", string(result.Disposition), "status_first")
		})
	}
	t.Run("status outside-set and timeout", func(t *testing.T) {
		backend := newMockBackend()
		backend.observeErr = refuse("terminal_backend_unauthorized", "test outside-set")
		engine := testEngine(t, backend, testLease(), fixtureGen)
		_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_protocol_error", "operation error vocabulary")
		backend.observeErr = refuse("terminal_backend_timeout", "test timeout")
		report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_timeout", "status observation unknown")
		if report.State != "" {
			t.Errorf("report.State = %q on a timed-out read, want no report (never absent)", report.State)
		}
		backend.observeErr = errors.New("read failed")
		report, err = engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_unavailable", "status observation unknown")
		if report.State != "" {
			t.Errorf("report.State = %q on a failed read, want no report (never absent)", report.State)
		}
	})
}

// TestRV3_KeyMaterialLiteral asserts the four key derivations as whole
// literal strings (not concatenations of the fixture constants).
func TestRV3_KeyMaterialLiteral(t *testing.T) {
	context := testContext(t)
	got, _ := KeySegments(terminalbackend.OperationQuiesceInput, context, testParams())
	requireLiteral(t, "quiesce", got, "0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1/quiesce/0198f4c8-8e50-7f66-8f70-ddddddddddd1")
	got, _ = KeySegments(terminalbackend.OperationWaitSafeBoundary, context, Params{QuiescenceGeneration: fixtureQuiescence, ProviderProofKind: ProofProviderProcessExit})
	requireLiteral(t, "wait", got, "0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1/boundary/0198f4c8-8e50-7f66-8f70-ddddddddddd1/provider_process_exit")
	got, _ = KeySegments(terminalbackend.OperationRequestStop, context, Params{SafeBoundaryEvidenceID: fixtureDigestB})
	requireLiteral(t, "stop", got, "0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb1/stop/sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb")
	got, _ = KeySegments(terminalbackend.OperationCreate, context, Params{BootstrapOperationID: fixtureBootstrap})
	requireLiteral(t, "create", got, "0198f4c8-8e50-7f66-8f70-1234567890ab/0198f4c8-8e50-7f66-8f70-eeeeeeeeeee1")
}

// TestRV3_LapsedGrantHidesStaleness (CHARACTERIZATION, F2 composition):
// a stale epoch-1 token under a VERIFIED epoch-2 winner whose local
// fencing grant has lapsed. The landed gate's expiry arm precedes the
// direction and tuple arms, so ObserveFencing sees a lapsed-grant
// refusal (not a park) and projects no transition, although the
// observation itself proves the incarnation stale. Recorded, not
// graded here.
func TestRV3_LapsedGrantHidesStaleness(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	for _, tc := range []struct {
		name string
		obs  fencing.Observation
	}{{"local winner", fencingObservation()}, {"remote winner", remoteWinnerObservation()}} {
		obs := tc.obs
		obs.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) // policy interval is 1h
		state, transitioned, err := ObserveFencing(terminalbackend.StateActive, presented, obs)
		reason, _, parked := fencing.ParkDetails(err)
		t.Logf("CHARACTERIZATION %s: state=%s transitioned=%v parked=%v reason=%q err=%v", tc.name, state, transitioned, parked, reason, err)
		if transitioned {
			t.Errorf("%s: transitioned under a lapsed grant (unexpected on the reviewed tree)", tc.name)
		}
	}
}

// TestRV3_WaitResumptionReissuesBoundary (CHARACTERIZATION, F1 bound):
// a wait-safe-boundary receipt without completion; status proves
// quiescing (source == target) so the retry re-performs
// safe_boundary_observed and records whatever proof the backend returns
// now — "identical retry returns the same proof" is delegated to the
// backend's key binding (stated bound).
func TestRV3_WaitResumptionReissuesBoundary(t *testing.T) {
	backend := newMockBackend()
	backend.evidence[terminalbackend.EffectSafeBoundaryObserved] = fixtureDigestC
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := waitFixture(t, ProofAXCheckpointBoundary)
	if _, _, err := engine.Store.Bind(context.IdempotencyKey, terminalbackend.OperationWaitSafeBoundary, context.OperationID); err != nil {
		t.Fatal(err)
	}
	observed := matchingObservation()
	observed.State = terminalbackend.StateQuiescing
	backend.observation = observed
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationWaitSafeBoundary, context, params, source, admitted)
	t.Logf("CHARACTERIZATION wait resume: err=%v after=%s effects=%v evidence=%v performed=%v", err, result.After, result.Effects, result.EvidenceIDs, backend.performed())
}

// TestRV3_PartialCreateProgressIsNotResumable (CHARACTERIZATION, F1
// bound): a create receipt without completion after binding_persisted
// committed; status reports the interim `creating` with identity match
// (a backend that persisted the binding but never started the wrapper).
// The retry refuses uncertain (creating != absent) — the partial
// progress is reachable only through the unavailable → terminate-stale
// path of the final leaf. Recorded, not graded here.
func TestRV3_PartialCreateProgressIsNotResumable(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	create := testCreateContext(t)
	if _, _, err := engine.Store.Bind(create.context.IdempotencyKey, terminalbackend.OperationCreate, create.context.OperationID); err != nil {
		t.Fatal(err)
	}
	observed := matchingObservation()
	observed.State = terminalbackend.StateCreating
	effect := terminalbackend.EffectBindingPersisted
	observed.LastEffect = &effect
	backend.observation = observed
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	t.Logf("CHARACTERIZATION partial create: err=%v after=%s disposition=%s performed=%v", err, result.After, result.Disposition, backend.performed())
	if err == nil {
		t.Error("partial create retry resumed (unexpected on the reviewed tree)")
	}
}

// TestRV3_TargetProvenRetryProjectsUnavailable (CHARACTERIZATION): after
// a successful status read proves the TARGET (quiescing), the same-key
// quiesce retry refuses with after=unavailable — the local observation
// regresses from the just-proven quiescing to unavailable. Recorded.
func TestRV3_TargetProvenRetryProjectsUnavailable(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	if _, _, err := engine.Store.Bind(context.IdempotencyKey, terminalbackend.OperationQuiesceInput, context.OperationID); err != nil {
		t.Fatal(err)
	}
	observed := matchingObservation()
	observed.State = terminalbackend.StateQuiescing
	backend.observation = observed
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	t.Logf("CHARACTERIZATION target proven: err=%v after=%s disposition=%s observeCalls=%d", err, result.After, result.Disposition, backend.observeCalls)
}

// TestRV3_FencingNoLocalTupleComparison pins the composition claim by
// source text: fencing.go never reads Winner.Epoch/Winner.LeaseID or the
// presented tuple outside the landed Authorize call.
func TestRV3_FencingNoLocalTupleComparison(t *testing.T) {
	src := codeLinesOnly(readProductionFile(t, "fencing.go"))
	for _, forbidden := range []string{"presented.Epoch", "presented.LeaseID", "Winner.Epoch", "Winner.LeaseID", "Grant.Token"} {
		if strings.Contains(src, forbidden) {
			t.Errorf("fencing.go references %q: a local tuple comparison would fork the landed gate", forbidden)
		}
	}
	if strings.Count(src, "fencing.Authorize(") != 2 {
		t.Errorf("fencing.go calls fencing.Authorize %d times, want exactly the two composed questions", strings.Count(src, "fencing.Authorize("))
	}
}

// TestRV3_RemoteWinnerLeaseSummaryHostIsTheOnlySwitch confirms the
// relative question changes only LocalHostID: the winner, grant, policy
// and clock are the observation's own (no fabricated grant).
func TestRV3_RemoteWinnerLeaseSummaryHostIsTheOnlySwitch(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	obs := remoteWinnerObservation()
	// Sanity: the direct question parks remote_owner.
	_, err := fencing.Authorize(fencing.OperationRestore, presented, obs)
	reason, _, parked := fencing.ParkDetails(err)
	if !parked || reason != fencing.ParkRemoteOwner {
		t.Fatalf("direct question = %v, want remote_owner park", err)
	}
	// The relative question with only the host switched parks stale_owner.
	relative := obs
	relative.LocalHostID = obs.Winner.HolderHostID
	_, err = fencing.Authorize(fencing.OperationRestore, presented, relative)
	reason, winner, parked := fencing.ParkDetails(err)
	if !parked || reason != fencing.ParkStaleOwner {
		t.Fatalf("relative question = %v, want stale_owner park", err)
	}
	requireLiteral(t, "winning lease", winner, "f47ac10b-58cc-4372-a567-0e02b2c3d479")
	// And the same relative question with a fabricated grant holder is not what the code does:
	_ = sessrepo.LeaseSummary{}
}

// readProductionFile reads one production source file of this package.
func readProductionFile(t *testing.T, name string) string {
	t.Helper()
	raw, err := os.ReadFile(name)
	if err != nil {
		t.Fatalf("read %s: %v", name, err)
	}
	return string(raw)
}

// codeLinesOnly drops full-line comments so a doc sentence naming a
// member is not mistaken for a code reference.
func codeLinesOnly(src string) string {
	var kept []string
	for _, line := range strings.Split(src, "\n") {
		if strings.HasPrefix(strings.TrimSpace(line), "//") {
			continue
		}
		kept = append(kept, line)
	}
	return strings.Join(kept, "\n")
}

// TestRV3W_M8_StatusLastOperationGrammar (WITNESS for RV3-M8): a status
// report whose last_operation_id is present but not a UUIDv7 (empty or
// garbage) is refused at the production status entry, never adopted.
func TestRV3W_M8_StatusLastOperationGrammar(t *testing.T) {
	for _, bad := range []string{"", "nope", "0198F4C8-8E50-7F66-8F70-CCCCCCCCCCC1"} {
		backend := newMockBackend()
		observed := matchingObservation()
		value := bad
		observed.LastOperationID = &value
		backend.observation = observed
		engine := testEngine(t, backend, testLease(), fixtureGen)
		_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_protocol_error", "status report operation")
	}
}

// TestRV3_NoGrantHidesStaleness (CHARACTERIZATION, F2 composition): the
// controller-restart member — the observation carries NO grant (grants
// are machine-local transient state, never persisted), the winner is
// verified at epoch 2, the presented token is epoch 1. The landed gate
// refuses "carries no grant" before its direction/tuple arms, so
// ObserveFencing projects no transition from every live state, under a
// local and a remote winner alike. A stale owner can never obtain a
// fresh grant (VerifyFencingToken refuses a stale epoch and a foreign
// holder), so this member is unreachable for the composed projection.
func TestRV3_NoGrantHidesStaleness(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	for _, tc := range []struct {
		name string
		obs  fencing.Observation
	}{{"local winner", fencingObservation()}, {"remote winner", remoteWinnerObservation()}} {
		for _, current := range []terminalbackend.InstanceState{terminalbackend.StateActive, terminalbackend.StateParked, terminalbackend.StateQuiescing} {
			obs := tc.obs
			obs.HasGrant = false
			obs.Grant = sessrepo.FencingGrant{}
			state, transitioned, err := ObserveFencing(current, presented, obs)
			reason, _, parked := fencing.ParkDetails(err)
			t.Logf("CHARACTERIZATION %s from %s: state=%s transitioned=%v parked=%v reason=%q err=%v", tc.name, current, state, transitioned, parked, reason, err)
			if transitioned {
				t.Errorf("%s from %s: transitioned without a grant (unexpected on the reviewed tree)", tc.name, current)
			}
		}
	}
}
