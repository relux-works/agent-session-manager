#!/bin/zsh
set -u
cd "$(dirname "$0")/../cand-h"
for p in 1 2; do
  echo "=== pass $p start $(date -u +%FT%TZ)"
  PYTHONDONTWRITEBYTECODE=1 AX_MUTANT_VERBOSE=1 python3 internal/terminstance/mutant_harness.py > ../logs/40-harness-pass$p-raw.log 2>&1
  echo "harness exit=$? pass=$p"
  grep -v '^--- raw\|^--- end raw' ../logs/40-harness-pass$p-raw.log | grep -E '^(ok|MISMATCH|ERROR):' > ../logs/40-harness-pass$p-verdicts.log
  python3 ../logs/split_raw.py ../logs/40-harness-pass$p-raw.log ../logs/mutants-pass$p
  echo "tree after pass $p: $(git write-tree)"
  echo "pycache: $(find . -name __pycache__ | wc -l)"
  echo "=== pass $p end $(date -u +%FT%TZ)"
done
