#!/usr/bin/env python3
"""Split the AX_MUTANT_VERBOSE=1 harness stream into one raw log per plant.

Input: the combined stdout of mutant_harness.py (verdict lines interleaved
with '--- raw: NAME: exit N ---' ... '--- end raw: NAME ---' blocks).
Output: <outdir>/<NAME>.log containing the exit line, the raw go test
output, and the verdict line; plus <outdir>/../<prefix>-verdicts.log.
"""
import re
import sys
from pathlib import Path

src = Path(sys.argv[1])
outdir = Path(sys.argv[2])
outdir.mkdir(parents=True, exist_ok=True)
lines = src.read_text().splitlines()
raw = {}
name = None
buf = []
verdicts = []
for line in lines:
    m = re.match(r"^--- raw: (\S+): exit (-?\d+) ---$", line)
    if m:
        name = m.group(1)
        buf = [line]
        continue
    if name is not None:
        buf.append(line)
        if line == f"--- end raw: {name} ---":
            raw[name] = "\n".join(buf)
            name = None
        continue
    if re.match(r"^(ok|MISMATCH|ERROR): ", line):
        verdicts.append(line)
        vn = line.split(": ", 2)[1]
        if vn in raw:
            (outdir / f"{vn}.log").write_text(raw[vn] + "\n" + line + "\n")
        else:
            (outdir / f"{vn}.log").write_text("(no raw block captured)\n" + line + "\n")
Path(sys.argv[3]).write_text("\n".join(verdicts) + "\n")
print(f"plants={len(raw)} verdicts={len(verdicts)} ok={sum(1 for v in verdicts if v.startswith('ok:'))}")
