#!/bin/zsh
# Usage: run_harness.sh <copy-dir> <pass-label> <logs-dir>
set -u
COPY="$1"; LABEL="$2"; LOGS="$3"
cd "$COPY" || exit 9
export PYTHONDONTWRITEBYTECODE=1 AX_MUTANT_VERBOSE=1
python3 internal/terminstance/mutant_harness.py > "$LOGS/40-harness-$LABEL-stream.log" 2>&1
echo "harness exit $?" >> "$LOGS/40-harness-$LABEL-stream.log"
python3 "$(dirname "$0")/split_raw.py" "$LOGS/40-harness-$LABEL-stream.log" "$LOGS/mutants-$LABEL" "$LOGS/40-harness-$LABEL-verdicts.log" >> "$LOGS/40-harness-$LABEL-stream.log" 2>&1
find "$COPY" -name '__pycache__' -o -name '*.pyc' | wc -l > "$LOGS/40-harness-$LABEL-pycache-count.txt"
echo "done $LABEL" >> "$LOGS/40-harness-$LABEL-stream.log"
