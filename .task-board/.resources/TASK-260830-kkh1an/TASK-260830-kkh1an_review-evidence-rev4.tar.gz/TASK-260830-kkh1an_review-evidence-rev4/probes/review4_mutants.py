#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-kkh1an-4 (independent review).

Each row: apply the edits to one production file in an isolated copy of the
exact candidate tree, run (a) the COMMITTED suite only (`go test -skip
TestRV4` over internal/terminstance and internal/fencing) and (b) the
reviewer witness (`go test -run <witness> -v`), restore the file, and read a
verdict per run from the subprocess exit code plus a kill line. Raw
per-plant logs with subprocess exits and the applied diff are written to
the out directory. PYTHONDONTWRITEBYTECODE=1 is required by the caller.

Usage: review4_mutants.py <copy-dir> <out-dir>
"""
import hashlib
import pathlib
import subprocess
import sys

REPO = pathlib.Path(sys.argv[1]).resolve()
OUT = pathlib.Path(sys.argv[2]).resolve()
OUT.mkdir(parents=True, exist_ok=True)
TI = "internal/terminstance"
FE = "internal/fencing"

ROWS = [
    dict(name="RV4-M1-expiry-recheck-frozen-at-third-position", path=f"{TI}/execute.go",
         edits=[("\tperformed := []terminalbackend.SideEffect(nil)\n\tfor _, effect := range effects {\n",
                 "\tperformed := []terminalbackend.SideEffect(nil)\n\tentryNow := engine.Now()\n\tfor _, effect := range effects {\n"),
                ("\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n",
                 "\t\tauthNow := engine.Now()\n\t\tif len(performed) >= 2 {\n\t\t\tauthNow = entryNow\n\t\t}\n\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), authNow); err != nil {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n")],
         witness="TestRV4W_ExpiryRecheckedBeforeThirdEffect",
         kind="NARROWING (recheck dropped at one position: the per-effect authorization EXPIRY is evaluated at the entry instant for the THIRD effect only; positions 1-2 and the tuple recheck stay)"),
    dict(name="RV4-M2-verdict-composition-no-grant-only", path=f"{TI}/fencing.go",
         edits=[("\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {\n",
                 "\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale && !observation.HasGrant {\n")],
         witness="TestRV3F3_GrantLessStaleFences",
         kind="NARROWING (composition admits exactly the no-grant member of the grant-less class: lapsed grant, no clock reading and unusable policy no longer fence)"),
    dict(name="RV4-M3-verdict-composition-local-winner-only", path=f"{TI}/fencing.go",
         edits=[("\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {\n",
                 "\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale && observation.Winner.HolderHostID == observation.LocalHostID {\n")],
         witness="TestRV3F3_GrantLessStaleFences",
         kind="NARROWING (composition fences grant-less stale tokens under a LOCAL winner only; the remote-winner members no longer fence)"),
    dict(name="RV4-M4-verdict-older-epoch-widened-by-one", path=f"{FE}/staleness.go",
         edits=[("\t\treturn presented.Epoch < observation.Winner.Epoch, true\n",
                 "\t\treturn presented.Epoch+1 < observation.Winner.Epoch, true\n")],
         witness="TestRV3F3_GrantLessStaleFences",
         kind="NARROWING (bound widened by one: a token exactly one epoch older than the winner is decided NOT stale; two or more epochs older still decides stale)"),
    dict(name="RV4-M5-authorization-kind-case-sibling-admitted", path=f"{TI}/auth.go",
         edits=[("\tdefault:\n\t\treturn \"\", refuse(CodeProtocolError, \"ax authorization kind\")\n\t}\n",
                 "\tdefault:\n\t\tif value == \"Control\" {\n\t\t\treturn AuthorizationControl, nil\n\t\t}\n\t\treturn \"\", refuse(CodeProtocolError, \"ax authorization kind\")\n\t}\n")],
         witness="TestRV4W_AuthorizationKindCaseSiblingRefused",
         kind="NARROWING (closed-enum member admitted: the case-variant spelling Control parses as control at the direct and the document entry)"),
    dict(name="RV4-M6-replay-checkresult-tolerates-stale-generation", path=f"{TI}/execute.go",
         edits=[("\t\tif err := CheckResult(context, source, result); err != nil {\n",
                 "\t\tif err := CheckResult(context, source, result); err != nil && ErrorCode(err) != CodeStaleGeneration {\n")],
         witness="TestRV4W_ReplayedImageGenerationBindingAtEngine",
         kind="NARROWING (rule pinned at the helper, not the entry: the ENGINE replay site returns a stored image whose backend_generation differs from the request as a successful replay; every other CheckResult refusal still refuses)"),
    dict(name="RV4-M6b-replay-checkresult-disposition-collapsed", path=f"{TI}/execute.go",
         edits=[("\t\t\treturn buildResult(context, source, terminalbackend.StateUnavailable, nil, nil, DispositionFor(failure.Code, true)), failure\n",
                 "\t\t\treturn buildResult(context, source, terminalbackend.StateUnavailable, nil, nil, DispositionReplaySame), failure\n")],
         witness="TestRV4W_ReplayedImageGenerationBindingAtEngine",
         kind="NARROWING (disposition mapping collapsed at one engine arm: a refused replayed image reports replay_same instead of the class-mapped status_first)"),
    dict(name="RV4-M7-loop-deadline-instant-admitted", path=f"{TI}/execute.go",
         edits=[("\t\tif !engine.Now().Before(deadline) {\n\t\t\tfailure := refuse(rowTimeoutCode(operation), \"operation deadline\")\n\t\t\tif committed {\n",
                 "\t\tif engine.Now().After(deadline) {\n\t\t\tfailure := refuse(rowTimeoutCode(operation), \"operation deadline\")\n\t\t\tif committed {\n")],
         witness="TestRV4W_LoopDeadlineInstantCancelsWaiting",
         kind="NARROWING (bound widened by one instant: the in-loop deadline check admits exactly the deadline instant between effects; the entry check is unchanged)"),
    dict(name="RV4-K-known-kill-control", path=f"{TI}/auth.go",
         edits=[("\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 1, MaxLeaseEpoch)\n",
                 "\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 0, MaxLeaseEpoch)\n")],
         witness="TestParseAXAuthorizationEpochBound",
         kind="CONTROL (known-killed narrowing: proves the instrument reports kills)"),
    dict(name="RV4-C-comment-control", path=f"{TI}/doc.go",
         edits=[("// Package terminstance executes the Terminal Instance lifecycle contract of\n",
                 "// Package terminstance executes the Terminal Instance lifecycle contract of (reviewer control)\n")],
         witness="TestRequiresProviderObservation",
         kind="CONTROL (harmless comment-only edit: must SURVIVE)"),
    dict(name="RV4-B-build-break-control", path=f"{TI}/proof.go",
         edits=[("type ProviderProofKind string\n", "type ProviderProofKind string\nvar _ = undefinedReviewerSymbol\n")],
         witness="TestRequiresProviderObservation",
         kind="CONTROL (build break: must report ERROR, never a verdict)"),
]


def sha(p):
    return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()


def run(args, log):
    r = subprocess.run(args, cwd=REPO, capture_output=True, text=True, timeout=600)
    out = r.stdout + r.stderr
    log.write_text(f"# cmd: {' '.join(args)}\n# subprocess exit {r.returncode}\n{out}")
    if "build failed" in out or "\n# " in out or out.startswith("# "):
        return "ERROR(build broke)"
    if r.returncode == 0:
        return "SURVIVED"
    if "--- FAIL" in out or "FAIL:" in out:
        return "KILLED"
    return f"ERROR(exit {r.returncode}, no kill line)"


def main():
    summary = []
    for row in ROWS:
        target = REPO / row["path"]
        original = target.read_text()
        before = sha(target)
        patched = original
        ok = True
        for find, repl in row["edits"]:
            if patched.count(find) != 1:
                summary.append(f"ERROR: {row['name']}: anchor count {patched.count(find)} != 1")
                ok = False
                break
            patched = patched.replace(find, repl)
        if not ok:
            print(summary[-1], flush=True)
            continue
        try:
            target.write_text(patched)
            diff = subprocess.run(["diff", "-u", "--label", "pristine", "--label", "mutant", "-", str(target)],
                                  input=original, cwd=REPO, capture_output=True, text=True).stdout
            (OUT / f"{row['name']}.diff").write_text(diff)
            committed = run(["go", "test", f"./{TI}/", f"./{FE}/", "-skip", "TestRV4", "-count=1"], OUT / f"{row['name']}.committed.log")
            witness = run(["go", "test", f"./{TI}/", "-run", row["witness"], "-count=1", "-v"], OUT / f"{row['name']}.witness.log")
        finally:
            target.write_text(original)
        after = sha(target)
        restored = "restored" if after == before else "RESTORE-FAILED"
        line = f"{row['name']}: committed-suite={committed} witness[{row['witness']}]={witness} ({restored}) :: {row['kind']}"
        print(line, flush=True)
        summary.append(line)
    (OUT / "SUMMARY.txt").write_text("\n".join(summary) + "\n")


if __name__ == "__main__":
    main()
