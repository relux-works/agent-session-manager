//go:build darwin || linux

package terminstance

// Reviewer real-kill probe (rev4): the LOST-RESULT seam of request-stop.
// The child runs the genuine production ExecuteMutating entry and SIGKILLs
// itself in the engine AfterEffect hook of the LAST stop effect
// (backend_store_closed), after every effect committed and before the
// completion image is durable. The parent proves: the receipt is durable,
// no completion exists; the same-key retry with status proving the TARGET
// (stopped, i.e. "closed") refuses uncertain with status_first and performs
// no effect ("then same-key retry only if not closed"); the same-key retry
// with status proving the SOURCE resumes under the same receipt, performs
// the three effects once and records exactly one completion.

import (
	"context"
	"os"
	"syscall"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

const rv4CrashChildEnv = "AX_TERMINSTANCE_RV4_CRASH_CHILD"

func TestRV4_RealKillAfterLastStopEffectBeforeCompletion(t *testing.T) {
	if os.Getenv(rv4CrashChildEnv) == "1" {
		rv4CrashChild(t)
		return
	}
	storeDir := t.TempDir()
	runCrashChildWithEnv(t, storeDir, "^TestRV4_RealKillAfterLastStopEffectBeforeCompletion$", rv4CrashChildEnv)

	reopened, err := OpenReceiptStore(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	context, params, source, admitted := stopFixture(t)
	if _, found, err := reopened.Lookup(context.IdempotencyKey); err != nil || !found {
		t.Fatalf("Lookup() after kill = (%v, %v), want the durable stop receipt", found, err)
	}
	if _, found, err := reopened.Completed(context.IdempotencyKey); err != nil || found {
		t.Fatalf("Completed() after kill = (%v, %v), want no completion (lost result)", found, err)
	}

	// Retry 1: status proves the target (stopped, closed) -> refuse uncertain, no effect.
	closedBackend := newMockBackend()
	observed := matchingObservation()
	observed.State = terminalbackend.StateStopped
	observed.WrapperPresent = false
	observed.Attachable = false
	closedBackend.observation = observed
	engine := &Engine{Store: reopened, Backend: closedBackend, CurrentLease: func() LeaseView { return testLease() }, CurrentGeneration: func() string { return fixtureGen }, Now: fixtureNow}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_unavailable", "idempotency result uncertain")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if len(closedBackend.performed()) != 0 {
		t.Errorf("performed on the closed retry = %v, want none", closedBackend.performed())
	}
	if closedBackend.observeCalls != 1 {
		t.Errorf("status reads on the closed retry = %d, want exactly one reconciliation read", closedBackend.observeCalls)
	}
	if _, found, err := reopened.Completed(context.IdempotencyKey); err != nil || found {
		t.Errorf("Completed() after the closed retry = (%v, %v), want still no completion", found, err)
	}

	// Retry 2: status proves the source (quiescing) -> resume under the same receipt.
	openBackend := newMockBackend()
	open := matchingObservation()
	open.State = terminalbackend.StateQuiescing
	openBackend.observation = open
	engine.Backend = openBackend
	result, err = engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	if err != nil {
		t.Fatalf("resumed stop error = %v", err)
	}
	requireLiteral(t, "after", string(result.After), "stopped")
	requireLiteral(t, "disposition", string(result.Disposition), "replay_same")
	performed := openBackend.performed()
	if len(performed) != 3 || performed[0] != terminalbackend.EffectGracefulStopRequested || performed[1] != terminalbackend.EffectProcessClosed || performed[2] != terminalbackend.EffectBackendStoreClosed {
		t.Errorf("performed on the resumed retry = %v, want the three stop effects once, in transition order", performed)
	}
	if _, found, err := reopened.Completed(context.IdempotencyKey); err != nil || !found {
		t.Errorf("Completed() after resume = (%v, %v), want the one recorded result", found, err)
	}
	if got := countExportedReceipts(t, reopened); got != 1 {
		t.Errorf("exported receipts = %d, want exactly one", got)
	}
	// Retry 3: identical retry replays the one result with no new effect.
	replay, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	if err != nil || replay.After != terminalbackend.StateStopped || len(openBackend.performed()) != 3 {
		t.Errorf("identical retry = (%+v, %v) with %d effects, want the replayed result and no new effect", replay, err, len(openBackend.performed()))
	}
}

func runCrashChildWithEnv(t *testing.T, storeDir, runFilter, flagEnv string) {
	t.Helper()
	os.Setenv(crashChildStore, storeDir)
	defer os.Unsetenv(crashChildStore)
	os.Setenv(flagEnv, "1")
	defer os.Unsetenv(flagEnv)
	runCrashChild(t, storeDir, "request-stop", runFilter)
}

func rv4CrashChild(t *testing.T) {
	t.Helper()
	store, err := OpenReceiptStore(os.Getenv(crashChildStore))
	if err != nil {
		t.Fatalf("child OpenReceiptStore() error = %v", err)
	}
	backend := newMockBackend()
	engine := &Engine{
		Store:             store,
		Backend:           backend,
		CurrentLease:      func() LeaseView { return testLease() },
		CurrentGeneration: func() string { return fixtureGen },
		Now:               fixtureNow,
		Hooks: &EngineHooks{AfterEffect: func(effect terminalbackend.SideEffect) {
			if effect != terminalbackend.EffectBackendStoreClosed {
				return
			}
			proc, err := os.FindProcess(os.Getpid())
			if err != nil {
				t.Fatalf("child find self: %v", err)
			}
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}},
	}
	context, params, source, admitted := stopFixture(t)
	_, _ = engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	t.Fatal("child ExecuteMutating() returned past SIGKILL")
}

var _ = context.Background
