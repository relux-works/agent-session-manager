package terminstance

// Reviewer probes for CR-TASK-260830-kkh1an-4 (independent review, rev4).
// Every probe drives a production entry (ObserveFencing, ExecuteMutating,
// ParseAuthorizationKind, fencing.StaleRelativeToWinner) and asserts the
// literal spec tokens. TestRV4W_* are WITNESSES for reviewer narrowing
// mutants (pass pristine, fail under the plant); TestRV4_* are census or
// characterization probes.

import (
	"encoding/json"
	"errors"
	"strings"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// ---------------------------------------------------------------------------
// F3 class census: grant axis x direction x tuple x source, my own loop.
// ---------------------------------------------------------------------------

type rv4GrantShape struct {
	name  string
	shape func(*fencing.Observation)
}

func rv4GrantShapes() []rv4GrantShape {
	return []rv4GrantShape{
		{"fresh_grant", func(*fencing.Observation) {}},
		{"no_grant", func(o *fencing.Observation) { o.HasGrant = false; o.Grant = sessrepo.FencingGrant{} }},
		{"lapsed_grant", func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }},
		{"no_clock", func(o *fencing.Observation) { o.Now = time.Time{} }},
		{"unusable_policy", func(o *fencing.Observation) { o.Policy = sessrepo.FencingPolicy{} }},
		// A grant present but carrying a foreign/garbage token: the gate
		// re-checks expiry only, so this behaves as a fresh grant.
		{"garbage_grant_token", func(o *fencing.Observation) {
			o.Grant.Token = sessrepo.FencingToken{Epoch: 9, LeaseID: "nope", HolderHostID: "nope"}
		}},
	}
}

// TestRV4_F3ClassCensus re-derives the producer's enumeration with an
// independent loop: every grant member x local/remote winner x
// older-epoch / same-epoch-loser token x every LIVE source must fence;
// every non-live source must not; the winning tuple and a future epoch
// must never fence under any grant member or direction.
func TestRV4_F3ClassCensus(t *testing.T) {
	stale := map[string]fencing.PresentedToken{
		"older_epoch":            {SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB},
		"same_epoch_loser":       {SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLeaseB},
		"older_epoch_same_lease": {SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLease},
	}
	notStale := map[string]fencing.PresentedToken{
		"winning_tuple": {SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLease},
		"future_epoch":  {SessionID: fixtureSessionA, Epoch: 3, LeaseID: fixtureLeaseB},
	}
	winners := map[string]func() fencing.Observation{"local": fencingObservation, "remote": remoteWinnerObservation}
	live := []terminalbackend.InstanceState{terminalbackend.StateCreating, terminalbackend.StateParked, terminalbackend.StateActive, terminalbackend.StateQuiescing}
	nonLive := []terminalbackend.InstanceState{terminalbackend.StateAbsent, terminalbackend.StateStopped, terminalbackend.StateStaleFenced, terminalbackend.StateUnavailable}
	fenced, kept := 0, 0
	for _, g := range rv4GrantShapes() {
		for wn, w := range winners {
			for tn, tok := range stale {
				for _, cur := range live {
					obs := w()
					g.shape(&obs)
					state, transitioned, err := ObserveFencing(cur, tok, obs)
					if err != nil || !transitioned || string(state) != "stale_fenced" {
						t.Errorf("%s/%s/%s/%s: got (%s,%v,%v), want stale_fenced", g.name, wn, tn, cur, state, transitioned, err)
					}
					fenced++
				}
				for _, cur := range nonLive {
					obs := w()
					g.shape(&obs)
					state, transitioned, err := ObserveFencing(cur, tok, obs)
					if err == nil || transitioned || state != cur {
						t.Errorf("%s/%s/%s/%s: got (%s,%v,%v), want no transition with an error", g.name, wn, tn, cur, state, transitioned, err)
					}
					kept++
				}
			}
			for tn, tok := range notStale {
				for _, cur := range append(append([]terminalbackend.InstanceState{}, live...), nonLive...) {
					obs := w()
					g.shape(&obs)
					state, transitioned, _ := ObserveFencing(cur, tok, obs)
					if transitioned || state != cur {
						t.Errorf("%s/%s/%s/%s: transitioned, want no transition for a decided-not-stale token", g.name, wn, tn, cur)
					}
					kept++
				}
			}
		}
	}
	t.Logf("census: %d fencing cells, %d keep cells", fenced, kept)
}

// ---------------------------------------------------------------------------
// Differential census: the verdict is the gate's own tuple fact.
// Over a small exhaustive alphabet of presented tokens and observation
// shapes, whenever the landed Authorize (restore, fresh grant, asked from
// the winner's own host) reaches its tuple arms, StaleRelativeToWinner
// over the SAME observation with ANY grant member agrees; whenever
// Authorize refuses or parks BEFORE the grant arms, the verdict is
// undecided.
// ---------------------------------------------------------------------------

type rv4ObsShape struct {
	name string
	mut  func(*fencing.Observation)
}

func rv4OwnershipShapes() []rv4ObsShape {
	return []rv4ObsShape{
		{"ok", func(*fencing.Observation) {}},
		{"no_winner", func(o *fencing.Observation) { o.HasWinner = false }},
		{"winner_epoch0", func(o *fencing.Observation) { o.Winner.Epoch = 0 }},
		{"winner_lease_bad", func(o *fencing.Observation) { o.Winner.LeaseID = "nope" }},
		{"winner_host_bad", func(o *fencing.Observation) { o.Winner.HolderHostID = "nope" }},
		{"unverified", func(o *fencing.Observation) { o.Verified = false }},
		{"ambiguous", func(o *fencing.Observation) { o.Ambiguous = true }},
		{"handoff_failed", func(o *fencing.Observation) { o.HandoffFailed = true }},
		{"obs_session_b", func(o *fencing.Observation) { o.SessionID = fixtureSessionB }},
	}
}

func TestRV4_VerdictIsTheGatesTupleFact(t *testing.T) {
	sessions := []string{fixtureSessionA, fixtureSessionB, "nope", ""}
	epochs := []uint64{0, 1, 2, 3}
	leases := []string{fixtureLease, fixtureLeaseB, "nope", ""}
	cells, decidedCells := 0, 0
	for _, s := range sessions {
		for _, e := range epochs {
			for _, l := range leases {
				presented := fencing.PresentedToken{SessionID: s, Epoch: e, LeaseID: l}
				for _, own := range rv4OwnershipShapes() {
					for _, g := range rv4GrantShapes() {
						for _, remote := range []bool{false, true} {
							cells++
							obs := fencingObservation()
							if remote {
								obs = remoteWinnerObservation()
							}
							own.mut(&obs)
							g.shape(&obs)
							stale, decided := fencing.StaleRelativeToWinner(presented, obs)
							// Reference: the same observation, fresh grant, asked from the winner's host.
							ref := obs
							fresh := fencingObservation()
							ref.HasGrant, ref.Grant, ref.Now, ref.Policy = true, fresh.Grant, fixtureNow(), fresh.Policy
							if ref.HasWinner {
								ref.LocalHostID = ref.Winner.HolderHostID
							}
							_, err := fencing.Authorize(fencing.OperationRestore, presented, ref)
							reason, _, parked := fencing.ParkDetails(err)
							wellFormedWinner := obs.HasWinner && obs.Winner.Epoch != 0 && obs.Winner.LeaseID != "nope" && obs.Winner.HolderHostID != "nope"
							ownershipPasses := wellFormedWinner && obs.Verified && !obs.Ambiguous && !obs.HandoffFailed
							futureEpoch := ownershipPasses && s == obs.SessionID && e > obs.Winner.Epoch
							reachedTuple := err == nil || (parked && reason == fencing.ParkStaleOwner) ||
								(parked && reason == fencing.ParkRestorePolicy && futureEpoch)
							if reachedTuple {
								decidedCells++
								if !decided {
									t.Errorf("%v/%s/%s/remote=%v: gate reached tuple arms but verdict undecided", presented, own.name, g.name, remote)
									continue
								}
								wantStale := parked && reason == fencing.ParkStaleOwner
								if stale != wantStale {
									t.Errorf("%v/%s/%s/remote=%v: verdict stale=%v, gate stale_owner=%v", presented, own.name, g.name, remote, stale, wantStale)
								}
							} else if decided {
								t.Errorf("%v/%s/%s/remote=%v: gate refused/parked before the tuple arms (%v) but verdict decided (stale=%v)", presented, own.name, g.name, remote, err, stale)
							}
						}
					}
				}
			}
		}
	}
	t.Logf("differential census: %d cells, %d decided", cells, decidedCells)
	if decidedCells == 0 {
		t.Fatal("instrument reached no decided cell; census is vacuous")
	}
}

// TestRV4_ObserveFencingMatchesIndependentOracle pins ObserveFencing over
// the same alphabet against an independent restatement of the rule
// written in this test (not the production constant): a LIVE source
// fences iff the presented token is well-formed, names the observation's
// session, the winner is established and well-formed, the observation is
// verified, unambiguous and not a failed handoff, and the tuple is older
// or a same-epoch loser. Everything else leaves the state.
func TestRV4_ObserveFencingMatchesIndependentOracle(t *testing.T) {
	isUUIDv4 := func(v string) bool { return v == fixtureLease || v == fixtureLeaseB }
	isUUIDv7 := func(v string) bool {
		return v == fixtureSessionA || v == fixtureSessionB || v == fixtureHost || v == "0198f4c8-8e50-7f66-8f70-aaaaaaaaaaa2"
	}
	oracle := func(p fencing.PresentedToken, o fencing.Observation) bool {
		if !isUUIDv7(p.SessionID) || p.Epoch == 0 || !isUUIDv4(p.LeaseID) || p.SessionID != o.SessionID {
			return false
		}
		if !o.HasWinner || o.Winner.Epoch == 0 || !isUUIDv4(o.Winner.LeaseID) || !isUUIDv7(o.Winner.HolderHostID) {
			return false
		}
		if !o.Verified || o.Ambiguous || o.HandoffFailed {
			return false
		}
		if p.Epoch < o.Winner.Epoch {
			return true
		}
		return p.Epoch == o.Winner.Epoch && p.LeaseID != o.Winner.LeaseID
	}
	sessions := []string{fixtureSessionA, fixtureSessionB, "nope"}
	epochs := []uint64{0, 1, 2, 3}
	leases := []string{fixtureLease, fixtureLeaseB, "nope"}
	all := []terminalbackend.InstanceState{terminalbackend.StateAbsent, terminalbackend.StateCreating, terminalbackend.StateParked, terminalbackend.StateActive, terminalbackend.StateQuiescing, terminalbackend.StateStopped, terminalbackend.StateStaleFenced, terminalbackend.StateUnavailable}
	liveSet := map[terminalbackend.InstanceState]bool{terminalbackend.StateCreating: true, terminalbackend.StateParked: true, terminalbackend.StateActive: true, terminalbackend.StateQuiescing: true}
	cells, fences := 0, 0
	for _, s := range sessions {
		for _, e := range epochs {
			for _, l := range leases {
				p := fencing.PresentedToken{SessionID: s, Epoch: e, LeaseID: l}
				for _, own := range rv4OwnershipShapes() {
					for _, g := range rv4GrantShapes() {
						for _, remote := range []bool{false, true} {
							for _, cur := range all {
								cells++
								o := fencingObservation()
								if remote {
									o = remoteWinnerObservation()
								}
								own.mut(&o)
								g.shape(&o)
								want := oracle(p, o) && liveSet[cur]
								state, transitioned, err := ObserveFencing(cur, p, o)
								if want {
									fences++
									if err != nil || !transitioned || state != terminalbackend.StateStaleFenced {
										t.Errorf("%v %s %s remote=%v %s: got (%s,%v,%v), oracle says fence", p, own.name, g.name, remote, cur, state, transitioned, err)
									}
								} else if transitioned || state != cur {
									t.Errorf("%v %s %s remote=%v %s: got (%s,%v,%v), oracle says keep", p, own.name, g.name, remote, cur, state, transitioned, err)
								}
							}
						}
					}
				}
			}
		}
	}
	t.Logf("oracle census: %d cells, %d fences", cells, fences)
	if fences == 0 {
		t.Fatal("oracle census reached no fencing cell; instrument is vacuous")
	}
}

// ---------------------------------------------------------------------------
// E3 class: the expiry axis at the THIRD position (request-stop has three
// effects; the committed witness pins position 2 only).
// ---------------------------------------------------------------------------

// TestRV4W_ExpiryRecheckedBeforeThirdEffect (WITNESS for RV4-M1): the
// authorization expires between the second and third stop effect while
// the tuple is unchanged and the deadline is still ahead. The recheck
// must refuse before the third effect with the literal expiry arm,
// after=unavailable, new_authorization and exactly two committed effects.
func TestRV4W_ExpiryRecheckedBeforeThirdEffect(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params := rv3StopContextWithDeadline(t, "2026-09-03T00:00:00.000Z")
	afterExpiry, err := time.Parse(time.RFC3339Nano, "2026-09-02T01:00:00.000Z")
	if err != nil {
		t.Fatal(err)
	}
	effects := 0
	engine.Hooks = &EngineHooks{AfterEffect: func(terminalbackend.SideEffect) { effects++ }}
	engine.Now = func() time.Time {
		if effects >= 2 {
			return afterExpiry
		}
		return fixtureNow()
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, mustParseState(t, "quiescing"), testAdmitted("graceful_stop"))
	requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization expiry")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "new_authorization")
	performed := backend.performed()
	if len(performed) != 2 || performed[0] != terminalbackend.EffectGracefulStopRequested || performed[1] != terminalbackend.EffectProcessClosed {
		t.Errorf("performed = %v, want exactly [graceful_stop_requested process_closed] before the expired authorization is caught", performed)
	}
	if _, found, err := engine.Store.Completed(context.IdempotencyKey); err != nil || found {
		t.Errorf("Completed(key) = (%v, %v), want no completion after the mid-operation expiry", found, err)
	}
}

// ---------------------------------------------------------------------------
// Replay seam: the stored image is validated at the ENGINE, not only by
// the CheckResult helper.
// ---------------------------------------------------------------------------

// TestRV4W_ReplayedImageGenerationBindingAtEngine (WITNESS for RV4-M6 and
// RV4-M6b): a completion recorded under generation-one replayed to an
// identical request whose validated binding generation is now
// generation-two must refuse with the landed stale-generation class
// (`terminal_backend_stale_generation` / `result generation binding`),
// after=unavailable and status_first, never hand back the stale image
// as a successful replay.
func TestRV4W_ReplayedImageGenerationBindingAtEngine(t *testing.T) {
	backend := newMockBackend()
	backend.evidence[terminalbackend.EffectInputClosed] = fixtureDigestB
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	if _, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted); err != nil {
		t.Fatalf("first quiesce error = %v", err)
	}
	// Same key, same operation ID, but the binding generation moved.
	key := fixtureInstance + "/quiesce/" + fixtureQuiescence
	raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, "generation-two", key, fixtureDeadline, authDoc("1", nil))
	moved, err := ParseMutationContext([]byte(raw))
	if err != nil {
		t.Fatalf("ParseMutationContext(generation-two) error = %v", err)
	}
	engine.CurrentGeneration = func() string { return "generation-two" }
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, moved, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_stale_generation", "result generation binding")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if performed := backend.performed(); len(performed) != 1 {
		t.Errorf("performed = %v, want no second effect on the refused replay", performed)
	}
}

// TestRV4_CorruptCompletionImageIsIntegrityFailure characterizes the
// unmarshal arm of the replay seam: a completion whose stored bytes are
// not a Result image refuses terminal_backend_integrity_failure /
// idempotency result image with after=unavailable and status_first.
func TestRV4_CorruptCompletionImageIsIntegrityFailure(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	if _, _, err := engine.Store.Bind(context.IdempotencyKey, terminalbackend.OperationQuiesceInput, context.OperationID); err != nil {
		t.Fatalf("Bind() error = %v", err)
	}
	if err := engine.Store.Complete(context.IdempotencyKey, []byte("{not json")); err != nil {
		t.Fatalf("Complete(corrupt) error = %v", err)
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_integrity_failure", "idempotency result image")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if len(backend.performed()) != 0 {
		t.Errorf("performed = %v, want no effect on a corrupt image", backend.performed())
	}
}

// ---------------------------------------------------------------------------
// In-loop deadline instant.
// ---------------------------------------------------------------------------

// TestRV4W_LoopDeadlineInstantCancelsWaiting (WITNESS for RV4-M7): the
// deadline instant itself, reached exactly between the first and second
// stop effect, cancels the remaining waits (the spec's "a deadline
// cancels waiting") with stop_timeout, after=unavailable (one effect is
// committed), status_first and exactly one committed effect.
func TestRV4W_LoopDeadlineInstantCancelsWaiting(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := stopFixture(t)
	deadline, err := context.Deadline.Time()
	if err != nil {
		t.Fatal(err)
	}
	effects := 0
	engine.Hooks = &EngineHooks{AfterEffect: func(terminalbackend.SideEffect) { effects++ }}
	engine.Now = func() time.Time {
		if effects >= 1 {
			return deadline
		}
		return fixtureNow()
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	requireRefusal(t, err, "stop_timeout", "operation deadline")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if performed := backend.performed(); len(performed) != 1 {
		t.Errorf("performed = %v, want exactly one committed effect at the deadline instant", performed)
	}
}

// ---------------------------------------------------------------------------
// Closed enum: case-variant sibling spellings.
// ---------------------------------------------------------------------------

// TestRV4W_AuthorizationKindCaseSiblingRefused (WITNESS for RV4-M5): the
// closed authorization_kind enum refuses case-variant and whitespace
// spellings of its members at the direct entry and through the document
// entry (nested AXAuthorization).
func TestRV4W_AuthorizationKindCaseSiblingRefused(t *testing.T) {
	for _, bad := range []string{"Control", "Create", "CONTROL", " control", "control ", "Force_Stale", "Restore"} {
		_, err := ParseAuthorizationKind(bad)
		requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization kind")
		encoded, _ := json.Marshal(bad)
		raw := authDoc("1", map[string]*string{"authorization_kind": strptr(string(encoded))})
		_, err = ParseAXAuthorization([]byte(raw))
		requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization kind")
	}
	// The same class on the two sibling enums.
	for _, bad := range []string{"Replay_Same", "Status_First", "NEW_AUTHORIZATION", " required_operator_action"} {
		_, err := ParseRetryDisposition(bad)
		requireRefusal(t, err, "terminal_backend_protocol_error", "retry disposition vocabulary")
	}
	for _, bad := range []string{"Provider_Quiescence", "Ax_Checkpoint_Boundary", "provider_process_exit "} {
		_, err := ParseProviderProofKind(bad)
		requireRefusal(t, err, "terminal_backend_protocol_error", "provider proof vocabulary")
	}
}

// ---------------------------------------------------------------------------
// Spec literal re-verification (independent of the package constants).
// ---------------------------------------------------------------------------

// TestRV4_SpecLiteralsAtEntries asserts the literal spec tokens at the
// production entries: the four dispositions, the four kinds, the three
// proof kinds, the eight states through the landed parser, the exact key
// material strings and the epoch bound edges (1, 9007199254740991 admitted;
// 0, 9007199254740992 refused) through ParseAXAuthorization AND through the
// nested MutationContext document and the quiesce-input body.
func TestRV4_SpecLiteralsAtEntries(t *testing.T) {
	for _, d := range []string{"replay_same", "status_first", "new_authorization", "required_operator_action"} {
		if got, err := ParseRetryDisposition(d); err != nil || string(got) != d {
			t.Errorf("ParseRetryDisposition(%q) = (%q, %v)", d, got, err)
		}
	}
	for _, k := range []string{"create", "control", "force_stale", "restore"} {
		if got, err := ParseAuthorizationKind(k); err != nil || string(got) != k {
			t.Errorf("ParseAuthorizationKind(%q) = (%q, %v)", k, got, err)
		}
	}
	for _, k := range []string{"provider_quiescence", "provider_process_exit", "ax_checkpoint_boundary"} {
		if got, err := ParseProviderProofKind(k); err != nil || string(got) != k {
			t.Errorf("ParseProviderProofKind(%q) = (%q, %v)", k, got, err)
		}
	}
	for _, s := range []string{"absent", "creating", "parked", "active", "quiescing", "stopped", "stale_fenced", "unavailable"} {
		if got, err := terminalbackend.ParseInstanceState(s); err != nil || string(got) != s {
			t.Errorf("ParseInstanceState(%q) = (%q, %v)", s, got, err)
		}
	}
	// Key material as whole literal strings.
	ctx := testContext(t)
	if key, _ := KeySegments(terminalbackend.OperationQuiesceInput, ctx, Params{QuiescenceGeneration: fixtureQuiescence}); key != fixtureInstance+"/quiesce/"+fixtureQuiescence {
		t.Errorf("quiesce key = %q", key)
	}
	if key, _ := KeySegments(terminalbackend.OperationWaitSafeBoundary, ctx, Params{QuiescenceGeneration: fixtureQuiescence, ProviderProofKind: "provider_process_exit", TimeoutMs: 1}); key != fixtureInstance+"/boundary/"+fixtureQuiescence+"/provider_process_exit" {
		t.Errorf("wait key = %q", key)
	}
	if key, _ := KeySegments(terminalbackend.OperationRequestStop, ctx, Params{SafeBoundaryEvidenceID: fixtureDigestB, GracefulTimeoutMs: 1}); key != fixtureInstance+"/stop/"+fixtureDigestB {
		t.Errorf("stop key = %q", key)
	}
	if key, _ := KeySegments(terminalbackend.OperationCreate, ctx, Params{BootstrapOperationID: fixtureBootstrap}); key != fixtureSessionA+"/"+fixtureBootstrap {
		t.Errorf("create key = %q", key)
	}
	// Epoch bound edges, direct and nested.
	for _, tc := range []struct {
		epoch string
		ok    bool
	}{{"1", true}, {"9007199254740991", true}, {"0", false}, {"9007199254740992", false}, {"1.0", false}, {"-1", false}} {
		_, err := ParseAXAuthorization([]byte(authDoc(tc.epoch, nil)))
		if (err == nil) != tc.ok {
			t.Errorf("ParseAXAuthorization(epoch %s) error = %v, want ok=%v", tc.epoch, err, tc.ok)
		}
		key := fixtureInstance + "/quiesce/" + fixtureQuiescence
		raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, fixtureDeadline, authDoc(tc.epoch, nil))
		_, err = ParseMutationContext([]byte(raw))
		if (err == nil) != tc.ok {
			t.Errorf("ParseMutationContext(nested epoch %s) error = %v, want ok=%v", tc.epoch, err, tc.ok)
		}
		body := `{"context":` + raw + `,"quiescence_generation":"` + fixtureQuiescence + `"}`
		_, _, err = ParseOperationBody("quiesce-input", []byte(body))
		if (err == nil) != tc.ok {
			t.Errorf("ParseOperationBody(quiesce nested epoch %s) error = %v, want ok=%v", tc.epoch, err, tc.ok)
		}
	}
	// Generation bound 0/256/257 in characters through the context document and the status body.
	for _, tc := range []struct {
		gen string
		ok  bool
	}{{strings.Repeat("g", 256), true}, {strings.Repeat("é", 256), true}, {strings.Repeat("g", 257), false}, {"", false}} {
		key := fixtureInstance + "/quiesce/" + fixtureQuiescence
		raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, tc.gen, key, fixtureDeadline, authDoc("1", nil))
		_, err := ParseMutationContext([]byte(raw))
		if (err == nil) != tc.ok {
			t.Errorf("ParseMutationContext(generation len %d) error = %v, want ok=%v", len([]rune(tc.gen)), err, tc.ok)
		}
		if !tc.ok {
			requireRefusal(t, err, "terminal_backend_stale_generation", "backend_generation bound")
		}
		_, err = ParseStatusBody([]byte(statusDoc(`"`+fixtureInstance+`"`, `"`+tc.gen+`"`)))
		if (err == nil) != tc.ok {
			t.Errorf("ParseStatusBody(generation len %d) error = %v, want ok=%v", len([]rune(tc.gen)), err, tc.ok)
		}
	}
}

// TestRV4_OutsideSetCodeRefusedPerRow re-verifies that a backend report
// outside the row's admitted set is refused as a protocol error on every
// engine row, and that status timeout / uncoded read failure return an
// error with no report (unknown, never absent).
func TestRV4_OutsideSetCodeRefusedPerRow(t *testing.T) {
	rows := []struct {
		op      terminalbackend.Operation
		fixture func(*testing.T) (MutationContext, Params, terminalbackend.InstanceState, terminalbackend.Admitted)
		outside string
	}{
		{terminalbackend.OperationQuiesceInput, quiesceFixture, "terminal_backend_unavailable"},
		{terminalbackend.OperationWaitSafeBoundary, func(t *testing.T) (MutationContext, Params, terminalbackend.InstanceState, terminalbackend.Admitted) {
			return waitFixture(t, ProofAXCheckpointBoundary)
		}, "stop_timeout"},
		{terminalbackend.OperationRequestStop, stopFixture, "quiesce_timeout"},
	}
	for _, row := range rows {
		t.Run(string(row.op), func(t *testing.T) {
			backend := newMockBackend()
			backend.effectHandler = func(terminalbackend.SideEffect) (string, error) { return "", refuse(row.outside, "backend says") }
			engine := testEngine(t, backend, testLease(), fixtureGen)
			ctx, params, source, admitted := row.fixture(t)
			result, err := engine.ExecuteMutating(contextGo(), row.op, ctx, params, source, admitted)
			requireRefusal(t, err, "terminal_backend_protocol_error", "operation error vocabulary")
			requireLiteral(t, "after", string(result.After), "unavailable")
			requireLiteral(t, "disposition", string(result.Disposition), "status_first")
		})
	}
	t.Run("status timeout is unknown", func(t *testing.T) {
		backend := newMockBackend()
		backend.observeErr = refuse("terminal_backend_timeout", "backend says")
		engine := testEngine(t, backend, testLease(), fixtureGen)
		report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_timeout", "status observation unknown")
		if report.State != "" {
			t.Errorf("report.State = %q, want no report", report.State)
		}
	})
	t.Run("status uncoded read failure is unknown", func(t *testing.T) {
		backend := newMockBackend()
		backend.observeErr = errors.New("socket reset")
		engine := testEngine(t, backend, testLease(), fixtureGen)
		report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_unavailable", "status observation unknown")
		if report.State != "" {
			t.Errorf("report.State = %q, want no report", report.State)
		}
	})
	t.Run("status outside-set code refused", func(t *testing.T) {
		backend := newMockBackend()
		backend.observeErr = refuse("idempotency_mismatch", "backend says")
		engine := testEngine(t, backend, testLease(), fixtureGen)
		_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
		requireRefusal(t, err, "terminal_backend_protocol_error", "operation error vocabulary")
	})
}

// TestRV4_IdempotencyReplayAndMismatchThroughEngine: identical retry
// replays byte-equal; a changed operation ID in-window is
// idempotency_mismatch with the source restored and status_first.
func TestRV4_IdempotencyReplayAndMismatchThroughEngine(t *testing.T) {
	backend := newMockBackend()
	backend.evidence[terminalbackend.EffectInputClosed] = fixtureDigestB
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	first, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	if err != nil {
		t.Fatalf("first error = %v", err)
	}
	second, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	if err != nil {
		t.Fatalf("replay error = %v", err)
	}
	a, _ := json.Marshal(first)
	b, _ := json.Marshal(second)
	if string(a) != string(b) {
		t.Errorf("replay differs:\n%s\n%s", a, b)
	}
	requireLiteral(t, "replay disposition", string(second.Disposition), "replay_same")
	if len(backend.performed()) != 1 {
		t.Errorf("performed = %v, want exactly one effect across the replay", backend.performed())
	}
	key := fixtureInstance + "/quiesce/" + fixtureQuiescence
	raw := contextDoc(fixtureOperationB, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, fixtureDeadline, authDoc("1", nil))
	changed, err := ParseMutationContext([]byte(raw))
	if err != nil {
		t.Fatal(err)
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, changed, params, source, admitted)
	requireRefusal(t, err, "idempotency_mismatch", "idempotency key conflict")
	requireLiteral(t, "after", string(result.After), "active")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
}
