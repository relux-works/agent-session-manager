//go:build darwin || linux

package terminstance

// Reviewer real-kill probes (RUN-260918-f6b44c). The child runs the
// genuine production ExecuteMutating entry and SIGKILLs itself at an
// ENGINE seam (not the store hook the producer uses): BeforeEffect of
// create's first effect, and AfterEffect of create's first effect.

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

const (
	rv3CrashEnv   = "AX_RV3_CRASH_CHILD"
	rv3CrashStore = "AX_RV3_CRASH_STORE"
	rv3CrashSeam  = "AX_RV3_CRASH_SEAM"
)

func rv3RunCrashChild(t *testing.T, storeDir, seam, runFilter string) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run="+runFilter, "-test.count=1")
	child.Env = append(os.Environ(), rv3CrashEnv+"=1", rv3CrashStore+"="+storeDir, rv3CrashSeam+"="+seam)
	runErr := child.Run()
	var exitErr *exec.ExitError
	if !errors.As(runErr, &exitErr) {
		t.Fatalf("child run = %v, want a signal-kill exit", runErr)
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok || !status.Signaled() || status.Signal() != syscall.SIGKILL {
		t.Fatalf("child status = %v, want killed by SIGKILL", exitErr)
	}
	t.Logf("child killed by SIGKILL at seam %s", seam)
}

func rv3CrashChild(t *testing.T) {
	t.Helper()
	store, err := OpenReceiptStore(os.Getenv(rv3CrashStore))
	if err != nil {
		t.Fatalf("child OpenReceiptStore() error = %v", err)
	}
	kill := func() {
		proc, err := os.FindProcess(os.Getpid())
		if err != nil {
			t.Fatalf("child find self: %v", err)
		}
		_ = proc.Signal(syscall.SIGKILL)
		select {}
	}
	backend := newMockBackend()
	engine := &Engine{
		Store:             store,
		Backend:           backend,
		CurrentLease:      func() LeaseView { return testLease() },
		CurrentGeneration: func() string { return fixtureGen },
		Now:               fixtureNow,
	}
	switch os.Getenv(rv3CrashSeam) {
	case "before-first-effect":
		engine.Hooks = &EngineHooks{BeforeEffect: func(terminalbackend.SideEffect) { kill() }}
	case "after-first-effect":
		engine.Hooks = &EngineHooks{AfterEffect: func(effect terminalbackend.SideEffect) {
			if effect == terminalbackend.EffectBindingPersisted {
				kill()
			}
		}}
	default:
		t.Fatalf("child seam = %q", os.Getenv(rv3CrashSeam))
	}
	create := testCreateContext(t)
	_, _ = engine.ExecuteMutating(context.Background(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	t.Fatal("child ExecuteMutating() returned past SIGKILL")
}

func rv3ReopenedEngine(t *testing.T, storeDir string) (*Engine, *mockBackend, *ReceiptStore) {
	t.Helper()
	reopened, err := OpenReceiptStore(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	backend := newMockBackend()
	return &Engine{
		Store:             reopened,
		Backend:           backend,
		CurrentLease:      func() LeaseView { return testLease() },
		CurrentGeneration: func() string { return fixtureGen },
		Now:               fixtureNow,
	}, backend, reopened
}

// TestRV3_RealKillBeforeFirstCreateEffectThenResume: SIGKILL at the
// engine BeforeEffect seam (receipt durable, no effect ran). The retry
// refuses uncertain without a status proof; status proves absence
// (canonical non-match form); the identical retry then completes with
// exactly one instance's effects, one completion and one receipt.
func TestRV3_RealKillBeforeFirstCreateEffectThenResume(t *testing.T) {
	if os.Getenv(rv3CrashEnv) == "1" {
		rv3CrashChild(t)
		return
	}
	storeDir := t.TempDir()
	if _, err := OpenReceiptStore(storeDir); err != nil {
		t.Fatal(err)
	}
	rv3RunCrashChild(t, storeDir, "before-first-effect", "^TestRV3_RealKillBeforeFirstCreateEffectThenResume$")
	engine, backend, store := rv3ReopenedEngine(t, storeDir)
	create := testCreateContext(t)
	if _, found, err := store.Lookup(create.context.IdempotencyKey); err != nil || !found {
		t.Fatalf("Lookup() after kill = (%v, %v), want the durable receipt", found, err)
	}
	if _, found, err := store.Completed(create.context.IdempotencyKey); err != nil || found {
		t.Fatalf("Completed() after kill = (%v, %v), want no completion", found, err)
	}
	source := mustParseState(t, "absent")
	admitted := testAdmitted("terminal_state_retention")
	// Same-key retry WITHOUT a status proof (backend read fails) refuses.
	backend.observeErr = errors.New("backend unreachable")
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, source, admitted)
	requireRefusal(t, err, "terminal_backend_unavailable", "idempotency result uncertain")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if len(backend.performed()) != 0 {
		t.Fatalf("performed = %v, want nothing without a status proof", backend.performed())
	}
	// Status proves absence; the same-key retry completes once.
	backend.observeErr = nil
	backend.observation = StatusObservation{
		State: terminalbackend.StateAbsent, IdentityMatch: false,
		SessionID: fixtureSessionA, InstanceID: fixtureInstance,
		BackendID: fixtureBackend, ImplVersion: fixtureImpl,
		ProtoVersion: fixtureProto, Generation: "generation-two",
	}
	resumed, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, source, admitted)
	if err != nil {
		t.Fatalf("same-key retry after kill+status error = %v", err)
	}
	requireLiteral(t, "after", string(resumed.After), "active")
	requireLiteral(t, "disposition", string(resumed.Disposition), "replay_same")
	performed := backend.performed()
	if len(performed) != 2 || performed[0] != terminalbackend.EffectBindingPersisted || performed[1] != terminalbackend.EffectWrapperStarted {
		t.Errorf("performed = %v, want exactly one instance's [binding_persisted wrapper_started]", performed)
	}
	if _, found, err := store.Completed(create.context.IdempotencyKey); err != nil || !found {
		t.Errorf("Completed() after resume = (%v, %v), want the one recorded result", found, err)
	}
	if got := countExportedReceipts(t, store); got != 1 {
		t.Errorf("exported receipts = %d, want exactly one", got)
	}
	// A further identical retry replays the one result without effects.
	replayed, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, source, admitted)
	if err != nil {
		t.Fatalf("replay after completion error = %v", err)
	}
	if replayed.After != resumed.After || len(backend.performed()) != 2 {
		t.Errorf("replay = %+v performed=%v, want the one result with no new effects", replayed, backend.performed())
	}
}

// TestRV3_RealKillAfterFirstCreateEffect (CHARACTERIZATION): SIGKILL
// after binding_persisted committed (receipt durable, one effect done,
// no completion). Two backends are then modeled: one that reports the
// instance absent (binding without wrapper is not an instance) — the
// retry resumes and re-performs both effects under the same receipt;
// and one that reports the interim `creating` — the retry refuses
// uncertain and the key stays parked on unavailable/status_first.
func TestRV3_RealKillAfterFirstCreateEffect(t *testing.T) {
	if os.Getenv(rv3CrashEnv) == "1" {
		rv3CrashChild(t)
		return
	}
	storeDir := t.TempDir()
	if _, err := OpenReceiptStore(storeDir); err != nil {
		t.Fatal(err)
	}
	rv3RunCrashChild(t, storeDir, "after-first-effect", "^TestRV3_RealKillAfterFirstCreateEffect$")
	engine, backend, store := rv3ReopenedEngine(t, storeDir)
	create := testCreateContext(t)
	if _, found, err := store.Lookup(create.context.IdempotencyKey); err != nil || !found {
		t.Fatalf("Lookup() after kill = (%v, %v), want the durable receipt", found, err)
	}
	if _, found, err := store.Completed(create.context.IdempotencyKey); err != nil || found {
		t.Fatalf("Completed() after kill = (%v, %v), want no completion", found, err)
	}
	source := mustParseState(t, "absent")
	admitted := testAdmitted("terminal_state_retention")
	creating := matchingObservation()
	creating.State = terminalbackend.StateCreating
	effect := terminalbackend.EffectBindingPersisted
	creating.LastEffect = &effect
	backend.observation = creating
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, source, admitted)
	t.Logf("CHARACTERIZATION backend reports creating: err=%v after=%s disposition=%s performed=%v", err, result.After, result.Disposition, backend.performed())
	backend.observation = StatusObservation{
		State: terminalbackend.StateAbsent, IdentityMatch: false,
		SessionID: fixtureSessionA, InstanceID: fixtureInstance,
		BackendID: fixtureBackend, ImplVersion: fixtureImpl,
		ProtoVersion: fixtureProto, Generation: "generation-two",
	}
	result, err = engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, source, admitted)
	t.Logf("CHARACTERIZATION backend reports absent: err=%v after=%s disposition=%s performed=%v receipts=%d", err, result.After, result.Disposition, backend.performed(), countExportedReceipts(t, store))
}
