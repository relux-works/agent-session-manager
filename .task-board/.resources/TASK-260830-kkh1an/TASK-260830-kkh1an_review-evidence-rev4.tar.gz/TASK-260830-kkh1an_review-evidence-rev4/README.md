# TASK-260830-kkh1an review evidence (rev4)

Independent review of CR-TASK-260830-kkh1an-4 (candidate tree
7d4619129f1e8583b5c0dc46525edcaed43f471c on base c61fc06ad8190a73c3005e137282829936dac970)
by RUN-260918-889432 (claude-opus-5 max). Verdict: ACCEPTED (no P1, no P2, four P3).

- `TASK-260830-kkh1an_review-verdict-rev4.md` — the verdict.
- `probes/zz_review4_probe_test.go` — 11 reviewer probes (F3 class census,
  31,104-cell oracle census, 6,912-cell gate-vs-verdict differential census,
  four witnesses `TestRV4W_*`, spec-literal / row-set / idempotency
  re-verifications, corrupt-image characterization). Drop into
  `internal/terminstance/` of an isolated copy; `go test ./internal/terminstance -run TestRV4 -v`.
- `probes/zz_review4_crash_unix_test.go` — real-SIGKILL probe at the
  lost-result seam of request-stop (after the last effect, before completion).
- `probes/zz_review3_crash_unix_test.go` — the rev3 reviewer's engine-seam
  real kills, re-run on this tree (attributed to RUN-260918-f6b44c).
- `probes/review4_mutants.py` — 7 reviewer narrowings + 3 controls; run with
  `PYTHONDONTWRITEBYTECODE=1 python3 review4_mutants.py <copy> <out>`.
- `probes/run_harness.sh`, `probes/split_raw.py` — driver for the shipped
  harness producing one raw log per plant.
- `logs/01-pkg-tests-v.log` four packages verbose; `02` fmt/vet/build;
  `04` `go test ./...`; `12` reviewer probes; `40-*` shipped harness passes
  1/2 (verdicts, streams) with `mutants-pass{1,2}/` raw per-plant logs;
  `50-*` + `rv4-mutants-pass{1,2}/` reviewer mutants (committed-suite and
  witness raw logs, diffs, SUMMARY.txt); `60-*` producer + rev3 real kills
  ×2; `61-*` reviewer real kill ×2; `70` race/cover/diff-check; `71`
  tracecheck/cataloggen; `80` hygiene; `81` producer archive audit; `82`
  ratio; `cand*.sha` tree listings proving copy restoration.
- `REVIEW-MANIFEST.txt` — sha256 of every file in this archive.
