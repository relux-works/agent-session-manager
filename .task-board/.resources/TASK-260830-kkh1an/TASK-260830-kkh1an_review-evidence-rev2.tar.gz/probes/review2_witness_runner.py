#!/usr/bin/env python3
"""Apply each RV2 mutant in the witness copy and run ONLY its witness
test: a PASS pristine + FAIL under mutant proves non-equivalence."""
import importlib.util, shutil, subprocess, sys, tempfile
from pathlib import Path
REPO = Path(sys.argv[1]).resolve(); OUT = Path(sys.argv[2]).resolve()
spec = importlib.util.spec_from_file_location("m", sys.argv[3]); mod = importlib.util.module_from_spec(spec)
sys.argv = [sys.argv[3], str(REPO), str(OUT)]
src = Path(sys.argv[0]).read_text().split("for m in M:")[0]
ns = {}; exec(src, ns)
WIT = {
 "RV2-M1-recheck-auth-third-effect": "TestRV2W_M1_",
 "RV2-M2-recheck-generation-third-effect": "TestRV2W_M2_",
 "RV2-M3-entry-deadline-instant": "TestRV2W_M3_M4_",
 "RV2-M4-status-deadline-instant": "TestRV2W_M3_M4_",
 "RV2-M5-committed-timeout-disposition": "TestRV2W_M5_",
 "RV2-M6-authkind-admits-attach": "TestRV2W_M6_",
 "RV2-M7-entry-generation-exempts-create": "TestRV2W_M7_",
 "RV2-M8-entry-auth-exempts-create": "TestRV2W_M8_",
 "RV2-M9-status-match-drops-implementation": "TestRV2W_M9_",
 "RV2-M10-headless-conditional-exempts-absent": "TestRV2W_M10_",
 "RV2-M15-session-scoped-adopts-foreign-session": "TestRV2W_M15_",
}
for m in ns["M"]:
    if m.name not in WIT: continue
    target = REPO / m.path; original = target.read_text()
    assert original.count(m.find) == 1, m.name
    with tempfile.TemporaryDirectory() as st:
        b = Path(st)/"b"; shutil.copy2(target, b)
        try:
            target.write_text(original.replace(m.find, m.replace))
            p = subprocess.run(["go","test","./internal/terminstance/","-run",WIT[m.name],"-count=1","-v"], cwd=REPO, capture_output=True, text=True, timeout=600)
        finally:
            shutil.copy2(b, target)
    out = p.stdout+p.stderr
    (OUT/f"{m.name}.log").write_text(f"--- witness {WIT[m.name]} under {m.name}: exit {p.returncode} ---\n{out}\n--- end ---\n")
    verdict = "WITNESS FAILS UNDER MUTANT (non-equivalent)" if p.returncode != 0 and "--- FAIL" in out else ("witness still passes (EQUIVALENT?)" if p.returncode == 0 else "ERROR")
    print(f"{m.name}: {verdict} exit={p.returncode}")
