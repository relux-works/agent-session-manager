#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-kkh1an-2 (RUN-260918-4f5cc1).

Killer: the WHOLE committed internal/terminstance suite (not a scoped
-run), so a SURVIVED verdict means no committed test observes the
narrowing. Each row is M (patch one production file in place), R (go
test ./internal/terminstance -count=1), V (KILLED iff the run fails with
a test failure line; SURVIVED iff exit 0; ERROR otherwise), restore.
Raw per-plant output with the subprocess exit is written by the caller.
"""
import os, shutil, subprocess, sys, tempfile
from dataclasses import dataclass
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
PACKAGE = "internal/terminstance"

@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    kind: str   # NARROWING / CONTROL
    note: str

M = [
    Mutant("RV2-M1-recheck-auth-third-effect", f"{PACKAGE}/execute.go",
        "\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n",
        "\t\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil && len(performed) < 2 {\n\t\t\tfailure := err.(*Error)\n\t\t\tafter := source\n",
        "NARROWING", "Per-effect auth recheck skipped exactly before the THIRD effect (request-stop's backend_store_closed); rechecks before effects 1 and 2 stay."),
    Mutant("RV2-M2-recheck-generation-third-effect", f"{PACKAGE}/execute.go",
        "\t\tif engine.CurrentGeneration() != context.BackendGeneration {\n\t\t\tfailure := refuse(CodeStaleGeneration, \"backend_generation stale\")\n\t\t\tafter := source\n",
        "\t\tif engine.CurrentGeneration() != context.BackendGeneration && len(performed) < 2 {\n\t\t\tfailure := refuse(CodeStaleGeneration, \"backend_generation stale\")\n\t\t\tafter := source\n",
        "NARROWING", "Per-effect generation recheck skipped exactly before the THIRD effect."),
    Mutant("RV2-M3-entry-deadline-instant", f"{PACKAGE}/execute.go",
        "\tif !engine.Now().Before(deadline) {\n\t\tfailure := refuse(rowTimeoutCode(operation), \"operation deadline\")\n\t\treturn buildResult(context, source, source, nil, nil, DispositionReplaySame), failure\n\t}\n",
        "\tif engine.Now().After(deadline) {\n\t\tfailure := refuse(rowTimeoutCode(operation), \"operation deadline\")\n\t\treturn buildResult(context, source, source, nil, nil, DispositionReplaySame), failure\n\t}\n",
        "NARROWING", "Entry deadline widened by one instant: now == deadline_at is admitted (bound edge)."),
    Mutant("RV2-M4-status-deadline-instant", f"{PACKAGE}/execute.go",
        "\tif !engine.Now().Before(deadline) {\n\t\treturn empty, refuse(CodeTimeout, \"operation deadline\")\n\t}\n",
        "\tif engine.Now().After(deadline) {\n\t\treturn empty, refuse(CodeTimeout, \"operation deadline\")\n\t}\n",
        "NARROWING", "Status deadline widened by one instant: now == deadline_at is admitted (bound edge)."),
    Mutant("RV2-M5-committed-timeout-disposition", f"{PACKAGE}/execute.go",
        "\t\t\tfailure := refuse(code, \"backend effect refused\")\n\t\t\treturn buildResult(context, source, after, performed, evidence, DispositionFor(code, committed)), failure\n",
        "\t\t\tfailure := refuse(code, \"backend effect refused\")\n\t\t\treturn buildResult(context, source, after, performed, evidence, DispositionFor(code, committed && code != CodeTimeout)), failure\n",
        "NARROWING", "Disposition mapping collapsed at the engine for exactly a COMMITTED terminal_backend_timeout (create's second effect): reports replay_same instead of status_first."),
    Mutant("RV2-M6-authkind-admits-attach", f"{PACKAGE}/auth.go",
        "\tdefault:\n\t\treturn \"\", refuse(CodeProtocolError, \"ax authorization kind\")\n\t}\n",
        "\tdefault:\n\t\tif value == \"attach\" {\n\t\t\treturn AuthorizationControl, nil\n\t\t}\n\t\treturn \"\", refuse(CodeProtocolError, \"ax authorization kind\")\n\t}\n",
        "NARROWING", "Closed AuthorizationKind admits exactly the landed 'attach' name (an AttachAuthorization kind, never an AXAuthorization kind) as control."),
    Mutant("RV2-M7-entry-generation-exempts-create", f"{PACKAGE}/execute.go",
        "\tif engine.CurrentGeneration() != context.BackendGeneration {\n\t\tfailure := refuse(CodeStaleGeneration, \"backend_generation stale\")\n\t\treturn buildResult(context, source, source, nil, nil, DispositionFor(failure.Code, false)), failure\n",
        "\tif engine.CurrentGeneration() != context.BackendGeneration && operation != terminalbackend.OperationCreate {\n\t\tfailure := refuse(CodeStaleGeneration, \"backend_generation stale\")\n\t\treturn buildResult(context, source, source, nil, nil, DispositionFor(failure.Code, false)), failure\n",
        "NARROWING", "Entry generation gate exempts exactly the create row."),
    Mutant("RV2-M8-entry-auth-exempts-create", f"{PACKAGE}/execute.go",
        "\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil {\n\t\tfailure := err.(*Error)\n\t\treturn buildResult(context, source, source, nil, nil, DispositionFor(failure.Code, false)), failure\n",
        "\tif err := CheckAuthorization(context.Authorization, kind, engine.CurrentLease(), engine.Now()); err != nil && operation != terminalbackend.OperationCreate {\n\t\tfailure := err.(*Error)\n\t\treturn buildResult(context, source, source, nil, nil, DispositionFor(failure.Code, false)), failure\n",
        "NARROWING", "Entry authorization gate exempts exactly the create row (a control/expired/foreign-lease authorization creates)."),
    Mutant("RV2-M9-status-match-drops-implementation", f"{PACKAGE}/execute.go",
        "\t\tobserved.ImplVersion == body.ImplementationVersion &&\n",
        "\t\ttrue &&\n",
        "NARROWING", "identity_match six-way conjunction loses exactly the implementation axis."),
    Mutant("RV2-M10-headless-conditional-exempts-absent", f"{PACKAGE}/execute.go",
        "\tif err := checkCapabilityConditional(operation, params, admitted); err != nil {\n",
        "\tif err := checkCapabilityConditional(operation, params, admitted); err != nil && !(operation == terminalbackend.OperationCreate && source == terminalbackend.StateAbsent) {\n",
        "NARROWING", "headless_creation conditional skipped exactly for a headless create from absent."),
    Mutant("RV2-M15-session-scoped-adopts-foreign-session", f"{PACKAGE}/execute.go",
        "\tif observed.SessionID != body.SessionID {\n\t\treturn false, nil\n\t}\n",
        "\tif observed.SessionID != body.SessionID && body.HasTerminalInstanceID {\n\t\treturn false, nil\n\t}\n",
        "NARROWING", "Session-scoped status lookup adopts a report for a DIFFERENT session (the session comparison is skipped exactly for the both-null lookup)."),
    Mutant("RV2-K-control-known-killed", f"{PACKAGE}/auth.go",
        "\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 1, MaxLeaseEpoch)\n",
        "\tleaseEpoch, ok := environ.CheckUint53Bounds(members[\"lease_epoch\"], 0, MaxLeaseEpoch)\n",
        "CONTROL", "Known-killed control (the producer's N-auth-epoch-low): must be KILLED by TestParseAXAuthorizationEpochBound, proving the plant reaches the compiler and the suite."),
    Mutant("RV2-B-control-build-break", f"{PACKAGE}/auth.go",
        "\tif auth.Kind != wantKind {\n",
        "\tif auth.Kind != wantKind { this does not compile\n",
        "CONTROL", "Build-break control: must report ERROR build broke, proving the patched file is what gets compiled."),
    Mutant("RV2-C-control", f"{PACKAGE}/doc.go",
        "// Package terminstance executes the Terminal Instance lifecycle contract of\n",
        "// Package terminstance executes (control) the Terminal Instance lifecycle contract of\n",
        "CONTROL", "Comment-only control: must SURVIVE."),
]

def run(m: Mutant) -> str:
    target = REPO / m.path
    original = target.read_text()
    n = original.count(m.find)
    if n != 1:
        return f"ERROR: {m.name}: anchors {n}, want 1"
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(m.find, m.replace))
            p = subprocess.run(["go", "test", f"./{PACKAGE}/", "-count=1"], cwd=REPO, capture_output=True, text=True, timeout=600)
        finally:
            shutil.copy2(backup, target)
    out = (p.stdout + p.stderr)
    (OUT / f"{m.name}.log").write_text(f"--- plant: {m.name} ({m.kind}) exit {p.returncode} ---\n{m.note}\n--- output ---\n{out}\n--- end ---\n")
    if "build failed" in out or out.startswith("# ") or "\n# " in out:
        return f"ERROR: {m.name}: build broke"
    if p.returncode == 0:
        v = "SURVIVED"
    elif "--- FAIL" in out or "FAIL:" in out:
        v = "KILLED"
    else:
        return f"ERROR: {m.name}: exit {p.returncode} no kill line"
    killers = sorted({l.split()[2] for l in out.splitlines() if l.startswith("--- FAIL: ")})
    return f"{m.name}: {v} [{m.kind}] exit={p.returncode} killers={killers} :: {m.note}"

for m in M:
    print(run(m), flush=True)
