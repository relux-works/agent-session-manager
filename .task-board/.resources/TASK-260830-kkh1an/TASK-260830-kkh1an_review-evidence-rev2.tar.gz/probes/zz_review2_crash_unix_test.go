//go:build darwin || linux

package terminstance

// Reviewer real-kill at the ENGINE seam (BeforeEffect of the first
// side effect, i.e. after the durable receipt, before wrapper/input
// work) — a different seam from the producer's store AfterCommit kill.
// Then the F1 witness with a real crash: status proves the source, the
// same-key retry still refuses forever.

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

const (
	rv2CrashEnv   = "AX_RV2_CRASH_CHILD"
	rv2CrashStore = "AX_RV2_CRASH_STORE"
)

func TestRV2_RealKillAtFirstEffectSeam(t *testing.T) {
	if os.Getenv(rv2CrashEnv) == "1" {
		store, err := OpenReceiptStore(os.Getenv(rv2CrashStore))
		if err != nil {
			t.Fatal(err)
		}
		backend := newMockBackend()
		engine := &Engine{
			Store: store, Backend: backend,
			CurrentLease:      func() LeaseView { return testLease() },
			CurrentGeneration: func() string { return fixtureGen },
			Now:               fixtureNow,
			Hooks: &EngineHooks{BeforeEffect: func(terminalbackend.SideEffect) {
				proc, _ := os.FindProcess(os.Getpid())
				_ = proc.Signal(syscall.SIGKILL)
				select {}
			}},
		}
		create := testCreateContext(t)
		_, _ = engine.ExecuteMutating(context.Background(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
		t.Fatal("child returned past SIGKILL")
		return
	}
	storeDir := t.TempDir()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestRV2_RealKillAtFirstEffectSeam$", "-test.count=1")
	child.Env = append(os.Environ(), rv2CrashEnv+"=1", rv2CrashStore+"="+storeDir)
	runErr := child.Run()
	var exitErr *exec.ExitError
	if !errors.As(runErr, &exitErr) {
		t.Fatalf("child run = %v, want a signal-kill exit", runErr)
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok || !status.Signaled() || status.Signal() != syscall.SIGKILL {
		t.Fatalf("child status = %v, want SIGKILL", exitErr)
	}
	t.Logf("child killed by SIGKILL at the engine BeforeEffect seam (create, first effect binding_persisted)")

	reopened, err := OpenReceiptStore(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	create := testCreateContext(t)
	receipt, found, err := reopened.Lookup(create.context.IdempotencyKey)
	if err != nil || !found {
		t.Fatalf("Lookup after kill = (%v, %v), want the durable create receipt", found, err)
	}
	if receipt.Operation != terminalbackend.OperationCreate || receipt.OperationID != fixtureOperation {
		t.Fatalf("receipt = %+v", receipt)
	}
	if _, found, err := reopened.Completed(create.context.IdempotencyKey); err != nil || found {
		t.Fatalf("Completed after kill = (%v, %v), want none", found, err)
	}
	// creating was never observable before the receipt: the receipt is
	// durable and no effect ran (the child died before the first one).
	backend := newMockBackend()
	engine := &Engine{Store: reopened, Backend: backend, CurrentLease: func() LeaseView { return testLease() }, CurrentGeneration: func() string { return fixtureGen }, Now: fixtureNow}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	requireRefusal(t, err, "terminal_backend_unavailable", "idempotency result uncertain")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
	if len(backend.performed()) != 0 {
		t.Fatalf("performed = %v on the uncertain retry", backend.performed())
	}
	// status proves absence (a successful status read is the only proof)
	backend.observation = StatusObservation{State: terminalbackend.StateAbsent, IdentityMatch: false, SessionID: fixtureSessionA, InstanceID: fixtureInstance, BackendID: fixtureBackend, ImplVersion: fixtureImpl, ProtoVersion: fixtureProto, Generation: "generation-two"}
	report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "absent"), testAdmitted("durable_disconnect"))
	if err != nil {
		t.Fatal(err)
	}
	requireLiteral(t, "status after kill", string(report.State), "absent")
	// F1 with a real crash: "Create is idempotent on (session_id,
	// bootstrap_operation_id) across controller crash ... Identical retry
	// returns the one result/instance." After status proved absence the
	// identical retry must proceed; the candidate refuses forever.
	result, err = engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	t.Logf("CHARACTERIZATION identical create retry after a real controller crash and a status read proving absence: err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	if err != nil {
		t.Errorf("identical create retry after crash+status still refuses: %v — the (session_id, bootstrap_operation_id) key can never produce the one result/instance", err)
	}
}
