package terminstance

// Reviewer probes for CR-TASK-260830-kkh1an-2 (RUN-260918-4f5cc1).
// Each probe drives the production entry and records what the candidate
// does. Probes marked CHARACTERIZATION are expected to FAIL on the
// candidate: the failure IS the finding; they pass only when the
// behaviour the pinned section requires is present.

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// ---------------------------------------------------------------------
// Probe 1 (CHARACTERIZATION): a receipt without its completion poisons
// the key forever. §4.C request-stop recovery column: "lost result
// requires status, then same-key retry only if not closed"; create:
// "identical retry replays it; uncertainty requires status"; §13.13
// safe_retry: "the same logical operation can continue ... after
// reconciling the uncertain external effect". After status proves the
// SOURCE state (nothing happened), the same-key retry must be able to
// proceed; the candidate refuses terminal_backend_unavailable forever.
// ---------------------------------------------------------------------

func TestRV2_UncertainKeyIsNeverRecoverableAfterStatus_Quiesce(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	// The crash seam: receipt durable, no completion (exactly what the
	// shipped real-kill test leaves behind).
	if _, _, err := engine.Store.Bind(context.IdempotencyKey, terminalbackend.OperationQuiesceInput, context.OperationID); err != nil {
		t.Fatal(err)
	}
	// Step 1: the identical retry refuses and routes to status (as pinned).
	_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_unavailable", "idempotency result uncertain")
	// Step 2: status proves the source state — the input was never closed.
	backend.observation = matchingObservation() // state active, matching tuple
	report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), source, testAdmitted("durable_disconnect"))
	if err != nil {
		t.Fatal(err)
	}
	requireLiteral(t, "status after crash", string(report.State), "active")
	// Step 3: the same-key retry after status. §4.C says it proceeds
	// ("then same-key retry"); the candidate refuses forever.
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	t.Logf("CHARACTERIZATION same-key retry after status proved source: err=%v after=%q disposition=%q performed=%v",
		err, result.After, result.Disposition, backend.performed())
	if err != nil {
		t.Errorf("same-key retry after a status read that proved the source state still refuses: %v (the key is poisoned; no production entry can ever complete this operation)", err)
	}
}

func TestRV2_UncertainKeyIsNeverRecoverableAfterStatus_StopNotClosed(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := stopFixture(t)
	if _, _, err := engine.Store.Bind(context.IdempotencyKey, terminalbackend.OperationRequestStop, context.OperationID); err != nil {
		t.Fatal(err)
	}
	_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_unavailable", "idempotency result uncertain")
	// status: still quiescing, wrapper present -> "not closed"
	observed := matchingObservation()
	observed.State = terminalbackend.StateQuiescing
	backend.observation = observed
	report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), source, testAdmitted("durable_disconnect"))
	if err != nil {
		t.Fatal(err)
	}
	requireLiteral(t, "status after lost result", string(report.State), "quiescing")
	// "then same-key retry only if not closed"
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	t.Logf("CHARACTERIZATION request-stop same-key retry after status=quiescing: err=%v after=%q disposition=%q performed=%v",
		err, result.After, result.Disposition, backend.performed())
	if err != nil {
		t.Errorf("request-stop same-key retry after status proved not-closed still refuses: %v", err)
	}
}

// The AfterCommit hook-error direction through the ENGINE: store.go
// documents "a hook error propagates to the caller but the receipt
// stands, so the identical retry replays it". Through ExecuteMutating
// the identical retry does not replay: it refuses uncertain.
func TestRV2_HookErrorThenIdenticalRetryDoesNotReplayThroughEngine(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	engine.Store.WithHooks(&StoreHooks{AfterCommit: func(string) error { return errTestHook }})
	context, params, source, admitted := quiesceFixture(t)
	first, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	t.Logf("first (hook error): err=%v after=%q disposition=%q", err, first.After, first.Disposition)
	engine.Store.WithHooks(nil)
	second, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	t.Logf("CHARACTERIZATION identical retry: err=%v after=%q disposition=%q performed=%v", err, second.After, second.Disposition, backend.performed())
	if err != nil {
		t.Errorf("identical retry after the hook-error commit refuses (%v); store.go says the identical retry replays it", err)
	}
}

// ---------------------------------------------------------------------
// Probe 2 (CHARACTERIZATION): ObserveFencing under a REMOTE winner at a
// higher epoch does not fence. §13.4: "If a higher or winning same-epoch
// lease is observed, the wrapper MUST block input, park or terminate its
// stale provider ... and return stale_owner". §13.3 step 15: the force
// lease "fences the prior owner logically". The prior owner is on
// another host: the landed Authorize parks remote_owner before the epoch
// arm, and ObserveFencing keys only on stale_owner.
// ---------------------------------------------------------------------

func remoteWinnerObservation() fencing.Observation {
	observation := fencingObservation()
	// The winner (epoch 2, lease A) is held by ANOTHER host; the local
	// host is fixtureHost and holds the stale epoch-1 lease B.
	observation.Winner = sessrepo.LeaseSummary{SessionID: fixtureSessionA, LeaseID: fixtureLease, Epoch: 2, HolderHostID: "0198f4c8-8e50-7f66-8f70-aaaaaaaaaaa2"}
	observation.Grant = sessrepo.FencingGrant{
		SessionID:   fixtureSessionA,
		Token:       sessrepo.FencingToken{Epoch: 1, LeaseID: fixtureLeaseB, HolderHostID: fixtureHost},
		ValidatedAt: fixtureNow(),
	}
	return observation
}

func TestRV2_StaleTokenUnderRemoteWinnerIsNotFenced(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	for _, current := range []terminalbackend.InstanceState{terminalbackend.StateActive, terminalbackend.StateParked, terminalbackend.StateQuiescing} {
		state, transitioned, err := ObserveFencing(current, presented, remoteWinnerObservation())
		reason, winner, parked := fencing.ParkDetails(err)
		t.Logf("CHARACTERIZATION current=%s presented=(1,%s) winner=(2,%s,remote host): state=%q transitioned=%v err=%v park=(%q,%q,%v)",
			current, fixtureLeaseB, fixtureLease, state, transitioned, err, reason, winner, parked)
		if !transitioned || state != terminalbackend.StateStaleFenced {
			t.Errorf("stale epoch-1 incarnation under a remote epoch-2 winner: state=%q transitioned=%v, want stale_fenced (the force takeover from another host is the primary fencing case)", state, transitioned)
		}
	}
}

func TestRV2_SameEpochLosingLeaseUnderRemoteWinnerIsNotFenced(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLeaseB}
	state, transitioned, err := ObserveFencing(terminalbackend.StateActive, presented, remoteWinnerObservation())
	reason, _, parked := fencing.ParkDetails(err)
	t.Logf("CHARACTERIZATION same-epoch losing lease under remote winner: state=%q transitioned=%v err=%v park=(%q,%v)", state, transitioned, err, reason, parked)
	if !transitioned || state != terminalbackend.StateStaleFenced {
		t.Errorf("same-epoch losing lease under a remote winner: state=%q, want stale_fenced", state)
	}
}

// Control for probe 2: the LOCAL-winner stale arms fence (as the
// committed tests pin) — the projection is incomplete, not absent.
func TestRV2_StaleTokenUnderLocalWinnerFences(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	state, transitioned, err := ObserveFencing(terminalbackend.StateActive, presented, fencingObservation())
	if err != nil || !transitioned || state != terminalbackend.StateStaleFenced {
		t.Fatalf("local-winner stale arm: state=%q transitioned=%v err=%v", state, transitioned, err)
	}
}

// ---------------------------------------------------------------------
// Probe 3 (characterization): holder_host_id is parsed and dropped.
// ---------------------------------------------------------------------

func TestRV2_HolderHostIDIsUnboundAtCheckAuthorization(t *testing.T) {
	raw := authDoc("1", map[string]*string{"holder_host_id": strptr(`"0198f4c8-8e50-7f66-8f70-aaaaaaaaaaa2"`)})
	auth, err := ParseAXAuthorization([]byte(raw))
	if err != nil {
		t.Fatal(err)
	}
	err = CheckAuthorization(auth, AuthorizationControl, testLease(), fixtureNow())
	t.Logf("CHARACTERIZATION authorization naming a foreign holder_host_id under the winning (epoch,lease): err=%v (LeaseView carries no holder; §4.C tuple is (epoch, lease_id), so this is a stated-scope observation, not a spec violation)", err)
}

// ---------------------------------------------------------------------
// Probe 4 (characterization): ObserveFencing fences from absent and
// stopped: an incarnation that does not exist becomes stale_fenced.
// ---------------------------------------------------------------------

func TestRV2_ObserveFencingFencesFromAbsentAndStopped(t *testing.T) {
	presented := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	for _, current := range []terminalbackend.InstanceState{terminalbackend.StateAbsent, terminalbackend.StateStopped, terminalbackend.StateCreating, terminalbackend.StateUnavailable} {
		state, transitioned, err := ObserveFencing(current, presented, fencingObservation())
		t.Logf("CHARACTERIZATION current=%s: state=%q transitioned=%v err=%v", current, state, transitioned, err)
	}
}

// ---------------------------------------------------------------------
// Probe 5 (characterization): a receipt-store failure BEFORE the link
// (nothing durable, nothing attempted) moves the observation to
// unavailable. §4.C: "An error before a side effect restores the source
// state." Over-strict direction.
// ---------------------------------------------------------------------

func TestRV2_PreLinkStoreFailureMovesToUnavailable(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	pending := filepath.Join(engine.Store.base, "pending")
	if err := os.Chmod(pending, 0o500); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Chmod(pending, 0o755) })
	context, params, source, admitted := quiesceFixture(t)
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	t.Logf("CHARACTERIZATION stage failure before any link: err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	if len(backend.performed()) != 0 {
		t.Fatalf("performed %v, want nothing", backend.performed())
	}
	_ = os.Chmod(pending, 0o755)
	if _, found, _ := engine.Store.Lookup(context.IdempotencyKey); found {
		t.Fatalf("a receipt was linked despite the read-only directory")
	}
	if result.After != source {
		t.Errorf("after=%q for an error before any receipt and any side effect, spec: restores the source state (%q)", result.After, source)
	}
}

// ---------------------------------------------------------------------
// Probe 6 (characterization): the replay is reachable only from the
// ORIGINAL source: an identical retry presented from the post-transition
// state refuses local_precondition_failed before the receipt is read.
// ---------------------------------------------------------------------

func TestRV2_ReplayRequiresOriginalSource(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	if _, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted); err != nil {
		t.Fatal(err)
	}
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, terminalbackend.StateQuiescing, admitted)
	t.Logf("CHARACTERIZATION identical retry from the post-transition source: err=%v after=%q disposition=%q", err, result.After, result.Disposition)
}

// ---------------------------------------------------------------------
// Probe 7: generation bound in the landed Provider Protocol 3 descriptor
// (cited landed by the producer): witness 0 / 256 / 257 myself.
// ---------------------------------------------------------------------

func TestRV2_DescriptorGenerationBoundLanded(t *testing.T) {
	for _, tc := range []struct {
		n    int
		want bool
	}{{0, false}, {1, true}, {256, true}, {257, false}} {
		_, err := terminalbackend.GenerationDigest(strings.Repeat("g", tc.n))
		if (err == nil) != tc.want {
			t.Errorf("GenerationDigest(len %d) err=%v want admit=%v", tc.n, err, tc.want)
		}
		if err != nil && ErrorCode(err) != "terminal_backend_stale_generation" {
			t.Errorf("GenerationDigest(len %d) code=%q", tc.n, ErrorCode(err))
		}
	}
	// multibyte: 256 runes of 2 bytes each = 512 bytes must admit (chars, not bytes)
	if _, err := terminalbackend.GenerationDigest(strings.Repeat("é", 256)); err != nil {
		t.Errorf("256 multibyte runes refused: %v", err)
	}
	// and the same corpus through the context document surface
	for _, tc := range []struct {
		n    int
		want bool
	}{{0, false}, {256, true}, {257, false}} {
		key := fixtureInstance + "/quiesce/" + fixtureQuiescence
		raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, strings.Repeat("é", tc.n), key, fixtureDeadline, authDoc("1", nil))
		_, err := ParseMutationContext([]byte(raw))
		if (err == nil) != tc.want {
			t.Errorf("ParseMutationContext(generation %d multibyte runes) err=%v want admit=%v", tc.n, err, tc.want)
		}
		if err != nil {
			requireRefusal(t, err, "terminal_backend_stale_generation", "backend_generation bound")
		}
		rawStatus := statusDoc(`"`+fixtureInstance+`"`, `"`+strings.Repeat("é", tc.n)+`"`)
		_, err = ParseStatusBody([]byte(rawStatus))
		if (err == nil) != tc.want {
			t.Errorf("ParseStatusBody(generation %d multibyte runes) err=%v want admit=%v", tc.n, err, tc.want)
		}
	}
}

// ---------------------------------------------------------------------
// Probe 8: the AXAuthorization epoch bound witnessed myself at the four
// values through the nested MutationContext surface as well.
// ---------------------------------------------------------------------

func TestRV2_EpochBoundThroughNestedContext(t *testing.T) {
	key := fixtureInstance + "/quiesce/" + fixtureQuiescence
	for _, tc := range []struct {
		epoch string
		want  bool
	}{{"1", true}, {"9007199254740991", true}, {"0", false}, {"9007199254740992", false}} {
		raw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, fixtureDeadline, authDoc(tc.epoch, nil))
		_, err := ParseMutationContext([]byte(raw))
		if (err == nil) != tc.want {
			t.Errorf("nested epoch %s: err=%v want admit=%v", tc.epoch, err, tc.want)
		}
		if err != nil {
			requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization epoch")
		}
	}
}

// ---------------------------------------------------------------------
// Probe 9: the retry disposition on EVERY engine result path parses as
// one of the four literal tokens (success, entry refusals, pre-commit,
// post-commit, replay, uncertain).
// ---------------------------------------------------------------------

func TestRV2_EveryResultCarriesExactlyOneLiteralDisposition(t *testing.T) {
	literal := map[string]bool{"replay_same": true, "status_first": true, "new_authorization": true, "required_operator_action": true}
	check := func(name string, result Result, err error) {
		t.Helper()
		if !literal[string(result.Disposition)] {
			t.Errorf("%s: disposition %q is not one of the four literals (err=%v)", name, result.Disposition, err)
		}
	}
	// success
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	context, params, source, admitted := quiesceFixture(t)
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("success", result, err)
	// replay
	result, err = engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("replay", result, err)
	// stale generation entry
	engineStale := testEngine(t, newMockBackend(), testLease(), "other")
	result, err = engineStale.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("stale entry", result, err)
	// uncertain
	engineU := testEngine(t, newMockBackend(), testLease(), fixtureGen)
	_, _, _ = engineU.Store.Bind(context.IdempotencyKey, terminalbackend.OperationQuiesceInput, context.OperationID)
	result, err = engineU.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("uncertain", result, err)
	// uncoded effect failure
	backendU := newMockBackend()
	backendU.effectErrors[terminalbackend.EffectInputClosed] = errors.New("boom")
	engineE := testEngine(t, backendU, testLease(), fixtureGen)
	result, err = engineE.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("uncoded", result, err)
	// deadline at entry
	engineD := testEngine(t, newMockBackend(), testLease(), fixtureGen)
	engineD.Now = fixturePastDeadline
	result, err = engineD.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	check("deadline", result, err)
}

// ---------------------------------------------------------------------
// Probe 10: the deadline INSTANT itself. The engine refuses at
// now == deadline (not Before). Recorded for the mutant plant RV2-M-deadline.
// ---------------------------------------------------------------------

func TestRV2_DeadlineInstantRefusesAtEntry(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	deadline, _ := time.Parse(time.RFC3339Nano, fixtureDeadline)
	engine.Now = func() time.Time { return deadline }
	context, params, source, admitted := quiesceFixture(t)
	_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_timeout", "operation deadline")
	backendS := newMockBackend()
	backendS.observation = matchingObservation()
	engineS := testEngine(t, backendS, testLease(), fixtureGen)
	engineS.Now = func() time.Time { return deadline }
	_, err = engineS.ExecuteStatus(contextGo(), exactStatusBody(t), source, testAdmitted("durable_disconnect"))
	requireRefusal(t, err, "terminal_backend_timeout", "operation deadline")
}

// ---------------------------------------------------------------------
// Probe 11: identity_match is a six-way conjunction: drift on EACH axis
// alone (instance, backend, implementation, protocol, generation) with
// the canonical absent form must read as a proven non-match, and a
// lying match on each axis must refuse. Recorded for the RV2-M-status-*
// plants.
// ---------------------------------------------------------------------

func TestRV2_StatusIdentityMatchEachAxis(t *testing.T) {
	axes := map[string]func(*StatusObservation){
		"instance":       func(o *StatusObservation) { o.InstanceID = "0198f4c8-8e50-7f66-8f70-bbbbbbbbbbb2" },
		"backend":        func(o *StatusObservation) { o.BackendID = "other.backend" },
		"implementation": func(o *StatusObservation) { o.ImplVersion = "1.2.4" },
		"protocol":       func(o *StatusObservation) { o.ProtoVersion = "1.0.1" },
		"generation":     func(o *StatusObservation) { o.Generation = "generation-two" },
	}
	for name, drift := range axes {
		t.Run(name+"/canonical non-match admits", func(t *testing.T) {
			backend := newMockBackend()
			observed := StatusObservation{State: terminalbackend.StateAbsent, IdentityMatch: false, SessionID: fixtureSessionA, InstanceID: fixtureInstance, BackendID: fixtureBackend, ImplVersion: fixtureImpl, ProtoVersion: fixtureProto, Generation: fixtureGen}
			drift(&observed)
			backend.observation = observed
			engine := testEngine(t, backend, testLease(), fixtureGen)
			report, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
			if err != nil {
				t.Fatalf("drift on %s with the canonical absent form: %v, want a proven non-match", name, err)
			}
			requireLiteral(t, "state", string(report.State), "absent")
		})
		t.Run(name+"/lying match refuses", func(t *testing.T) {
			backend := newMockBackend()
			observed := matchingObservation()
			drift(&observed)
			backend.observation = observed
			engine := testEngine(t, backend, testLease(), fixtureGen)
			_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
			requireRefusal(t, err, "terminal_backend_protocol_error", "status identity binding")
		})
	}
}
