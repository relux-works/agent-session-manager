package terminstance

// Delta witnesses for the RV2 reviewer mutants: each test PASSES on the
// pristine candidate and FAILS under its mutant, proving the survivor is
// non-equivalent (observable behaviour changes) and that no committed
// test covers the arm.

import (
	"strings"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// RV2-M1: lease rotates exactly before the THIRD stop effect.
func TestRV2W_M1_LeaseRotatesBeforeThirdEffect(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	calls := 0
	engine.CurrentLease = func() LeaseView {
		calls++
		if calls <= 3 { // entry, pre-effect 1, pre-effect 2
			return testLease()
		}
		return LeaseView{LeaseID: fixtureLease, Epoch: 2}
	}
	context, params, source, admitted := stopFixture(t)
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	t.Logf("err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization lease epoch")
	if len(backend.performed()) != 2 {
		t.Errorf("performed = %v, want exactly two effects before the rotated lease is caught", backend.performed())
	}
}

// RV2-M2: generation rotates exactly before the THIRD stop effect.
func TestRV2W_M2_GenerationRotatesBeforeThirdEffect(t *testing.T) {
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	calls := 0
	engine.CurrentGeneration = func() string {
		calls++
		if calls <= 3 {
			return fixtureGen
		}
		return "generation-two"
	}
	context, params, source, admitted := stopFixture(t)
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationRequestStop, context, params, source, admitted)
	t.Logf("err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	requireRefusal(t, err, "terminal_backend_stale_generation", "backend_generation stale")
	if len(backend.performed()) != 2 {
		t.Errorf("performed = %v, want exactly two effects", backend.performed())
	}
}

// RV2-M3 / RV2-M4: now == deadline_at refuses at both entries.
func TestRV2W_M3_M4_DeadlineInstant(t *testing.T) {
	deadline, _ := time.Parse(time.RFC3339Nano, fixtureDeadline)
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	engine.Now = func() time.Time { return deadline }
	context, params, source, admitted := quiesceFixture(t)
	_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationQuiesceInput, context, params, source, admitted)
	requireRefusal(t, err, "terminal_backend_timeout", "operation deadline")
	if len(backend.performed()) != 0 {
		t.Errorf("performed = %v at the deadline instant", backend.performed())
	}
	if _, found, _ := engine.Store.Lookup(context.IdempotencyKey); found {
		t.Error("a receipt was bound for a request whose deadline had already arrived (entry deadline admitted the instant)")
	}
	backendS := newMockBackend()
	backendS.observation = matchingObservation()
	engineS := testEngine(t, backendS, testLease(), fixtureGen)
	engineS.Now = func() time.Time { return deadline }
	_, err = engineS.ExecuteStatus(contextGo(), exactStatusBody(t), source, testAdmitted("durable_disconnect"))
	requireRefusal(t, err, "terminal_backend_timeout", "operation deadline")
}

// RV2-M5: create's SECOND effect (wrapper_started) reports
// terminal_backend_timeout after binding_persisted committed.
func TestRV2W_M5_CommittedTimeoutOnCreateSecondEffect(t *testing.T) {
	create := testCreateContext(t)
	backend := newMockBackend()
	backend.effectErrors[terminalbackend.EffectWrapperStarted] = refuse("terminal_backend_timeout", "test wrapper timeout")
	engine := testEngine(t, backend, testLease(), fixtureGen)
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	t.Logf("err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	requireRefusal(t, err, "terminal_backend_timeout", "backend effect refused")
	requireLiteral(t, "after", string(result.After), "unavailable")
	requireLiteral(t, "disposition", string(result.Disposition), "status_first")
}

// RV2-M6: authorization_kind "attach" is not an AXAuthorization kind.
func TestRV2W_M6_AttachKindRefused(t *testing.T) {
	raw := authDoc("1", map[string]*string{"authorization_kind": strptr(`"attach"`)})
	_, err := ParseAXAuthorization([]byte(raw))
	requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization kind")
	key := fixtureInstance + "/quiesce/" + fixtureQuiescence
	ctxRaw := contextDoc(fixtureOperation, fixtureSessionA, fixtureInstance, fixtureBackend, fixtureImpl, fixtureProto, fixtureGen, key, fixtureDeadline, raw)
	_, err = ParseMutationContext([]byte(ctxRaw))
	requireRefusal(t, err, "terminal_backend_protocol_error", "ax authorization kind")
}

// RV2-M7: create under a stale generation refuses at entry.
func TestRV2W_M7_CreateStaleGenerationRefuses(t *testing.T) {
	create := testCreateContext(t)
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), "generation-two")
	result, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	t.Logf("err=%v after=%q disposition=%q performed=%v", err, result.After, result.Disposition, backend.performed())
	requireRefusal(t, err, "terminal_backend_stale_generation", "backend_generation stale")
	if len(backend.performed()) != 0 {
		t.Errorf("performed = %v under a stale generation", backend.performed())
	}
	if _, found, _ := engine.Store.Lookup(create.context.IdempotencyKey); found {
		t.Error("a receipt was bound under a stale generation")
	}
}

// RV2-M8: create with a control-kind, an expired, and a foreign-lease
// authorization refuses at entry.
func TestRV2W_M8_CreateAuthorizationRefuses(t *testing.T) {
	t.Run("control kind presented as create", func(t *testing.T) {
		create := testCreateContext(t)
		create.context.Authorization = testAuth(t) // kind control
		backend := newMockBackend()
		engine := testEngine(t, backend, testLease(), fixtureGen)
		_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
		requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization kind binding")
		if len(backend.performed()) != 0 {
			t.Errorf("performed = %v with a control authorization", backend.performed())
		}
		if _, found, _ := engine.Store.Lookup(create.context.IdempotencyKey); found {
			t.Error("a receipt was bound for a create presented with a control authorization (the bootstrap key is now poisoned)")
		}
	})
	t.Run("expired", func(t *testing.T) {
		create := testCreateContext(t)
		backend := newMockBackend()
		engine := testEngine(t, backend, testLease(), fixtureGen)
		engine.Now = fixtureLater
		_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
		requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization expiry")
		if len(backend.performed()) != 0 {
			t.Errorf("performed = %v with an expired authorization", backend.performed())
		}
	})
	t.Run("foreign lease", func(t *testing.T) {
		create := testCreateContext(t)
		backend := newMockBackend()
		engine := testEngine(t, backend, LeaseView{LeaseID: fixtureLeaseB, Epoch: 1}, fixtureGen)
		_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
		requireRefusal(t, err, "terminal_backend_unauthorized", "ax authorization lease identity")
		if len(backend.performed()) != 0 {
			t.Errorf("performed = %v under a foreign winning lease", backend.performed())
		}
		if _, found, _ := engine.Store.Lookup(create.context.IdempotencyKey); found {
			t.Error("a receipt was bound for a create under a foreign winning lease (the bootstrap key is now poisoned)")
		}
	})
}

// RV2-M9: a lying match with only the implementation version drifted.
func TestRV2W_M9_LyingMatchOnImplementationAxis(t *testing.T) {
	backend := newMockBackend()
	observed := matchingObservation()
	observed.ImplVersion = "1.2.4"
	backend.observation = observed
	engine := testEngine(t, backend, testLease(), fixtureGen)
	_, err := engine.ExecuteStatus(contextGo(), exactStatusBody(t), mustParseState(t, "active"), testAdmitted("durable_disconnect"))
	requireRefusal(t, err, "terminal_backend_protocol_error", "status identity binding")
}

// RV2-M10: headless create from ABSENT without headless_creation.
func TestRV2W_M10_HeadlessCreateFromAbsentNeedsCapability(t *testing.T) {
	create := testCreateContext(t)
	create.params.Interactive = false
	backend := newMockBackend()
	engine := testEngine(t, backend, testLease(), fixtureGen)
	_, err := engine.ExecuteMutating(contextGo(), terminalbackend.OperationCreate, create.context, create.params, mustParseState(t, "absent"), testAdmitted("terminal_state_retention"))
	requireRefusal(t, err, "terminal_backend_capability_unproven", "operation capability conditional")
	if len(backend.performed()) != 0 {
		t.Errorf("performed = %v for a headless create without headless_creation", backend.performed())
	}
}

// RV2-M15: a session-scoped lookup whose backend reports ANOTHER
// session's instance with identity_match true must refuse, never adopt.
func TestRV2W_M15_SessionScopedForeignSessionRefuses(t *testing.T) {
	body, err := ParseStatusBody([]byte(statusDoc(`null`, `null`)))
	if err != nil {
		t.Fatal(err)
	}
	backend := newMockBackend()
	observed := matchingObservation()
	observed.SessionID = fixtureSessionB
	backend.observation = observed
	engine := testEngine(t, backend, testLease(), fixtureGen)
	report, err := engine.ExecuteStatus(contextGo(), body, mustParseState(t, "absent"), testAdmitted("durable_disconnect"))
	t.Logf("err=%v report=%+v", err, report)
	requireRefusal(t, err, "terminal_backend_protocol_error", "status identity binding")
}

var _ = strings.Repeat
