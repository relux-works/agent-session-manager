# TASK-260830-kkh1an review evidence (revision 2)

Reviewer RUN-260918-4f5cc1 (claude-opus-5 max). Task-scoped: every file
belongs to this review of CR-TASK-260830-kkh1an-2 (candidate tree
b605cc51c9dee44bc90f90d950892a58b09571ca, base c61fc06ad8190a73c3005e137282829936dac970).

- `TASK-260830-kkh1an_review-verdict-rev2.md`: the verdict (CHANGES REQUESTED).
- `probes/zz_review2_probe_test.go`, `probes/zz_review2_crash_unix_test.go`: reviewer probes (CHARACTERIZATION failures are the findings F1/F2/P3-1).
- `probes/zz_review2_witness_test.go`: delta witnesses (PASS pristine / FAIL under each reviewer mutant).
- `probes/review2_mutants.py`, `probes/review2_witness_runner.py`: reviewer mutant harness (whole-suite killer) and witness runner.
- `logs/01`: package suite verbose (exit 0, 168 PASS). `logs/02`: gofmt/vet/build/cross-OS. `logs/04`: `go test ./... -count=1` (40/40 ok).
- `logs/10`, `11`, `12`: probes / witnesses pristine / all RV2 tests pristine.
- `logs/40-harness-pass{1,2}.log` + `logs/mutants-pass{1,2}/`: the shipped harness rerun twice, 70 raw per-plant logs per pass, tree OID after each pass.
- `logs/50-rv2-mutants-pass{1,2}.log` + `logs/rv2-mutants-pass{1,2}/`: reviewer mutants twice (11 narrowing SURVIVED, K-control KILLED, B-control build broke, C-control SURVIVED), raw per-plant logs with exits.
- `logs/51-rv2-witness-under-mutant.log` + `logs/rv2-witness-under-mutant/`: each witness run under its mutant (all non-equivalent).
- `logs/60`: reviewer real-SIGKILL at the engine first-effect seam x2. `logs/70`: tree-exact checks (tracecheck, cataloggen -check, diff --check, producer crash test x2, race x4 packages, cover). `logs/80`: hygiene. `logs/82`: ratio re-derivation.
- `REVIEW-MANIFEST.txt`: sha256 of every file.

PYTHONDONTWRITEBYTECODE=1 throughout; no __pycache__.
