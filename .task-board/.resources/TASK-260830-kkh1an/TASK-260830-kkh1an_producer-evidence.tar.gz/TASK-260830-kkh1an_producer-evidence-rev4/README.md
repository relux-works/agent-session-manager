# TASK-260830-kkh1an producer evidence (rev4)

Rework of CR revision 3 (RUN-260918-f6b44c CHANGES REQUESTED, no P1):
P2 F3 (grant-less stale members) fixed by the landed
`fencing.StaleRelativeToWinner` verdict composed in `ObserveFencing`;
P2 E3 (expiry axis of the per-effect recheck) pinned by the committed
witness plus a tuple-keeping/expiry-dropping harness row; P3-1..P3-4
witnesses committed with mirror rows; P3-5 stated as a bound.

- `terminstance-test-v.log`: `go test ./internal/terminstance/
  -count=1 -v` (exit 0, 111 top-level PASS, 0 FAIL).
- `fencing-test-v.log`: `go test ./internal/fencing/ -count=1 -v`
  (exit 0, 47 top-level PASS, incl. the 5 verdict tests).
- `ratio-check.log`: 93/93 rows driven; every cited test present
  via `go test -list` and `--- PASS` (109 top-level: 107
  in-package + 1 fencing + 1 terminalbackend).
- `verdicts-pass{1,2}.txt`: harness verdict lists (identical).
- `blob-*.txt`: production blob sha before/after/across harness
  passes (identical; covers `internal/terminstance/*.go` and
  `internal/fencing/staleness.go`).
- `mutants/pass{1,2}/`: 116 per-plant raw logs each with
  subprocess exits (114 narrowing KILLED + 1 tightening KILLED +
  the SURVIVED control).
- `cmd/cmd01..30.log`: the 30 configured validation commands in
  order (`cmd05-r1..r4.log` are the 4 race chunks, summarized in
  `cmd05-summary.txt`; `cmd27b-windows-vet.log` is extra).
- `go-sha-*.txt`: `.go` tree sha before/after the race gate
  (identical).
- `MANIFEST.sha256`: sha256 of every file in this archive.

`PYTHONDONTWRITEBYTECODE=1` for every Python invocation; no
`__pycache__`, no foreign-task files.
