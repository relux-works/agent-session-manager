#!/usr/bin/env python3
"""Reviewer mutants for CR-BUG-260917-2fwf8e-2 (rev 2).
Usage: review_mutants_rev2.py <candidate-tree> <output-dir> [name-filter]
Each row: (name, file, [(old,new)...], command, claim). Every edit anchor must
occur exactly once or the row is NOT_APPLIED. The tree is copied once; each
mutant is applied to the copy and restored from the original bytes (hash
checked) after its run. Default command: the behavioral suites of the complete
importer set (fencing/..., terminstance, axpane, termbind).
"""
import hashlib, json, re, shutil, subprocess, sys
from pathlib import Path

src = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve(); out.mkdir(parents=True, exist_ok=True)
flt = sys.argv[3] if len(sys.argv) > 3 else ""
copy = out / "mutation-source"
if copy.exists():
    raise SystemExit("refusing to overwrite an existing mutation source")
shutil.copytree(src, copy, ignore=shutil.ignore_patterns("zz_review_*"))

IMPORTERS = ["go", "test", "./internal/fencing/...", "./internal/terminstance", "./internal/axpane", "./internal/termbind", "-count=1", "-v"]
FENCING_ONLY = ["go", "test", "./internal/fencing", "-count=1", "-v"]

DIRECTION_ARM = """\tif observation.Winner.HolderHostID != observation.LocalHostID {
		if launchClass(operation) {
			return LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)
		}
		return LeaseToken{}, refuse(ErrNotOwner, "session %s is owned by remote host %s", observation.SessionID, observation.Winner.HolderHostID)
	}
"""
DEFERRED_ARM = """\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrLeaseConflict, "fencing grant for session %s lapsed; revalidate the winning token", observation.SessionID)
	}
"""
POLICY_ARM = """\tif expiryErr != nil && !errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrInvalidArguments, "fencing observation for session %s carries an unusable refresh policy", observation.SessionID)
	}
"""
TUPLE_START = "\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n"
MINT = "\treturn mintLeaseToken(observation.SessionID, observation.Winner.Epoch, observation.Winner.LeaseID), nil\n}\n\n// validLeaseID"

OUTER_FALLBACK = """\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {
		return fenceLive(current, authErr)
	}
	return current, false, authErr
}

// observeRemoteWinner"""
INNER_FALLBACK = """\t// A lapsed grant can defer the relative question before its tuple arm;
	// the grant-independent verdict still fences a stale incarnation.
	if stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {
		return fenceLive(current, authErr)
	}
"""
RELATIVE_OP = "\t_, relativeErr := fencing.Authorize(fencing.OperationRestore, presented, relative)\n"

MUTANTS = [
    # --- rev1 survivors, re-planted on rev2 ---
    ("RM-A-restore-only-direction-first", "internal/fencing/gate.go",
     [(DIRECTION_ARM + DEFERRED_ARM,
       "\tif operation != OperationRestore && errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n" + DIRECTION_ARM + DEFERRED_ARM)],
     IMPORTERS, "narrowing (rev1 SURVIVED): restore keeps the fix, activation/input/mutation/checkpoint revert to expiry-first"),
    ("RM-H-nonlaunch-lapsed-lease-conflict", "internal/fencing/gate.go",
     [(DIRECTION_ARM,
       "\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n\t\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner, \"session %s is owned by remote host %s\", observation.SessionID, observation.Winner.HolderHostID)\n\t}\n")],
     IMPORTERS, "narrowing (rev1 SURVIVED): non-launch remote+lapsed reverts to lease_conflict"),
    ("RM-C-lapsed-refusal-only-for-winning-tuple", "internal/fencing/gate.go",
     [(DEFERRED_ARM,
       "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) && presented.Epoch == observation.Winner.Epoch && presented.LeaseID == observation.Winner.LeaseID {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n")],
     IMPORTERS, "narrowing (rev1 killed only by terminstance): local lapsed + stale token parks stale_owner instead of lease_conflict"),
    ("RM-C-fencing-only", "internal/fencing/gate.go",
     [(DEFERRED_ARM,
       "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) && presented.Epoch == observation.Winner.Epoch && presented.LeaseID == observation.Winner.LeaseID {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n")],
     FENCING_ONLY, "same plant as RM-C, killer mask = internal/fencing only (RM-C gap closure check)"),
    ("RM-B-direction-only-when-live", "internal/fencing/gate.go",
     [("\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
       "\tif observation.Winner.HolderHostID != observation.LocalHostID && expiryErr == nil {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner")],
     IMPORTERS, "narrowing: remote winner parks only under a live grant"),
    ("RM-D-policy-after-direction", "internal/fencing/gate.go",
     [(POLICY_ARM + DIRECTION_ARM, DIRECTION_ARM + POLICY_ARM)],
     IMPORTERS, "order: remote+unusable policy moves from invalid_arguments to remote_owner park"),
    ("RM-G-lapsed-remote-parks-restore-policy", "internal/fencing/gate.go",
     [("\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner",
       "\t\tif launchClass(operation) {\n\t\t\treason := ParkRemoteOwner\n\t\t\tif expiryErr != nil {\n\t\t\t\treason = ParkRestorePolicy\n\t\t\t}\n\t\t\treturn LeaseToken{}, park(reason, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner")],
     IMPORTERS, "narrowing: lapsed remote parks restore_policy, offer unreachable"),
    # --- new rev2 plants on the gate ---
    ("RM-E1-deferred-expiry-launch-only", "internal/fencing/gate.go",
     [(DEFERRED_ARM,
       "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) && launchClass(operation) {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n")],
     IMPORTERS, "narrowing: the deferred lapsed refusal fires for launch entries only; input/mutation/checkpoint MINT under a lapsed local grant"),
    ("RM-E2-deferred-expiry-after-tuple", "internal/fencing/gate.go",
     [(DEFERRED_ARM + TUPLE_START, TUPLE_START),
      (MINT, DEFERRED_ARM + MINT)],
     IMPORTERS, "order: lapsed refusal moved after the tuple arms; local lapsed + stale token becomes stale_owner"),
    ("RM-W1-direction-skipped-on-empty-localhost", "internal/fencing/gate.go",
     [("\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
       "\tif observation.LocalHostID != \"\" && observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner")],
     IMPORTERS, "narrowing: an empty LocalHostID is treated as the winner's own host (V14 class); live grant MINTS for a remote winner"),
    # --- terminstance composition plants ---
    ("RM-O1-outer-fallback-decided-only", "internal/terminstance/fencing.go",
     [(OUTER_FALLBACK, OUTER_FALLBACK.replace("if stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {", "if _, decided := fencing.StaleRelativeToWinner(presented, observation); decided {"))],
     IMPORTERS, "narrowing at the OUTER fallback (site whose harness row N-fencing-verdict-composition was re-anchored away): fences decided-not-stale grant-less tokens"),
    ("RM-O7-outer-fallback-stale-epoch-only", "internal/terminstance/fencing.go",
     [(OUTER_FALLBACK, OUTER_FALLBACK.replace("decided && stale {", "decided && stale && presented.Epoch < observation.Winner.Epoch {"))],
     IMPORTERS, "narrowing at the OUTER fallback: same-epoch losing lease no longer fences for grant-gated local/hard-refusal shapes"),
    ("RM-O2-inner-fallback-active-only", "internal/terminstance/fencing.go",
     [(INNER_FALLBACK, INNER_FALLBACK.replace("decided && stale {", "decided && stale && current == terminalbackend.StateActive {"))],
     IMPORTERS, "narrowing at the INNER fallback: only an active incarnation fences; parked/quiescing stale incarnations stay"),
    ("RM-O3-inner-fallback-stale-epoch-only", "internal/terminstance/fencing.go",
     [(INNER_FALLBACK, INNER_FALLBACK.replace("decided && stale {", "decided && stale && presented.Epoch < observation.Winner.Epoch {"))],
     IMPORTERS, "narrowing at the INNER fallback: the same-epoch losing lease no longer fences under a remote winner with a lapsed grant"),
    ("RM-O4-inner-fallback-deleted", "internal/terminstance/fencing.go",
     [(INNER_FALLBACK, INNER_FALLBACK.replace("decided && stale {", "decided && stale && false {"))],
     IMPORTERS, "arm-delete (composition control): the P1-1 fallback removed"),
    ("RM-O5-relative-question-through-mutation", "internal/terminstance/fencing.go",
     [(RELATIVE_OP, RELATIVE_OP.replace("OperationRestore", "OperationMutation"))],
     IMPORTERS, "the RETIRED row N-fencing-operation-remote re-planted: expected EQUIVALENT (SURVIVED) if the producer's retirement argument holds"),
    ("RM-O6-relative-question-dropped", "internal/terminstance/fencing.go",
     [("\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner {\n\t\treturn fenceLive(current, authErr)\n\t}\n",
       "\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner && false {\n\t\treturn fenceLive(current, authErr)\n\t}\n")],
     IMPORTERS, "arm-delete: the relative stale_owner park arm removed — is it still load-bearing next to the new fallback? (SURVIVED = redundant arm)"),
    # --- controls ---
    ("C-harmless-comment", "internal/fencing/gate.go",
     [("// Authorize is the fencing core: every activation-class action passes",
       "// Authorize is the fencing core: every activation-class action passes (reviewer control)")],
     IMPORTERS, "control: must SURVIVE"),
    ("C-not-applied", "internal/fencing/gate.go",
     [("this anchor does not occur in gate.go", "x")], IMPORTERS, "control: must be NOT_APPLIED"),
]

sel = [m for m in MUTANTS if flt in m[0]] if flt else MUTANTS
results = []

def run(name, cmd):
    log = out / (name + ".log")
    with log.open("w") as f:
        p = subprocess.run(cmd, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
    text = log.read_text()
    fails = re.findall(r"^\s*--- FAIL: ([^ ]+)", text, re.M)
    ran = re.findall(r"^=== RUN ", text, re.M) or re.findall(r"^(ok|FAIL)\s", text, re.M)
    cls = "COMPILE_OR_HARNESS_FAILURE" if not ran else ("SURVIVED" if p.returncode == 0 else ("KILLED" if fails else "COMPILE_OR_HARNESS_FAILURE"))
    return cls, p.returncode, fails

with (out / "control-before.log").open("w") as f:
    b = subprocess.run(IMPORTERS, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
results.append(dict(mutant="control-before", classification="CONTROL", exit=b.returncode))
print("control-before exit", b.returncode, flush=True)
if b.returncode:
    raise SystemExit("baseline failed")

for name, path, edits, cmd, claim in sel:
    target = copy / path
    original = target.read_bytes()
    text = original.decode()
    counts = [text.count(old) for old, _ in edits]
    if any(c != 1 for c in counts):
        results.append(dict(mutant=name, classification="NOT_APPLIED", counts=counts, claim=claim))
        print(name, "NOT_APPLIED", counts, flush=True)
        continue
    mutated = text
    for old, new in edits:
        mutated = mutated.replace(old, new)
    target.write_text(mutated)
    (out / (name + ".diff")).write_text("".join(__import__("difflib").unified_diff(text.splitlines(True), mutated.splitlines(True), path, path + " (mutant)")))
    try:
        cls, rc, fails = run(name, cmd)
    finally:
        target.write_bytes(original)
        assert hashlib.sha256(target.read_bytes()).hexdigest() == hashlib.sha256(original).hexdigest()
    top = sorted({f.split("/")[0] for f in fails})
    results.append(dict(mutant=name, classification=cls, exit=rc, failed_top=top, failed_count=len(fails), claim=claim, command=cmd))
    print(name, cls, rc, len(fails), ", ".join(top), flush=True)

with (out / "control-after.log").open("w") as f:
    a = subprocess.run(IMPORTERS, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
results.append(dict(mutant="control-after", classification="CONTROL", exit=a.returncode))
print("control-after exit", a.returncode, flush=True)
(out / "review-mutants.json").write_text(json.dumps(results, indent=2) + "\n")
