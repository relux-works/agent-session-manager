package terminstance

// Reviewer probe for CR-BUG-260917-2fwf8e-2 (rev 2): the composed
// ObserveFencing outcome for the NON-stale tokens (winning tuple and a
// future-epoch token) across every grant shape, winner direction and
// live source state. Report-only; runs unchanged on trunk 799c338 and
// on the candidate so the two logs diff outcome-by-outcome.

import (
	"errors"
	"fmt"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func review2Code(err error) string {
	if err == nil {
		return "nil"
	}
	code := "?"
	switch {
	case errors.Is(err, fencing.ErrInvalidArguments):
		code = "invalid_arguments"
	case errors.Is(err, fencing.ErrLeaseConflict):
		code = "lease_conflict"
	case errors.Is(err, fencing.ErrNotOwner):
		code = "not_owner"
	case errors.Is(err, fencing.ErrStaleOwner):
		code = "stale_owner"
	}
	if reason, _, parked := fencing.ParkDetails(err); parked {
		return fmt.Sprintf("PARK(%s,cause=%s)", reason, code)
	}
	return "REFUSE(" + code + ")"
}

func TestReview2NonStaleUnderWinnerByGrantShape(t *testing.T) {
	winning := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLease}
	future := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 3, LeaseID: fixtureLeaseB}
	shapes := []struct {
		name  string
		shape func(*fencing.Observation)
	}{
		{"live grant", func(o *fencing.Observation) {}},
		{"lapsed grant", func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }},
		{"no grant", func(o *fencing.Observation) { o.HasGrant = false }},
		{"no clock", func(o *fencing.Observation) { o.Now = time.Time{} }},
		{"unusable policy", func(o *fencing.Observation) { o.Policy.RefreshInterval = 0 }},
	}
	for _, winner := range []struct {
		name string
		obs  func() fencing.Observation
	}{{"remote winner", remoteWinnerObservation}, {"local winner", fencingObservation}} {
		for _, tok := range []struct {
			name string
			p    fencing.PresentedToken
		}{{"winning token", winning}, {"future epoch", future}} {
			for _, sh := range shapes {
				for _, current := range []terminalbackend.InstanceState{terminalbackend.StateActive, terminalbackend.StateParked, terminalbackend.StateQuiescing} {
					observation := winner.obs()
					sh.shape(&observation)
					state, transitioned, err := ObserveFencing(current, tok.p, observation)
					t.Logf("%s / %s / %s / from %s :: state=%s transitioned=%v err=%s", winner.name, tok.name, sh.name, current, state, transitioned, review2Code(err))
				}
			}
		}
	}
}
