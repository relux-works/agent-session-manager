package fencing

// Reviewer probes for CR-BUG-260917-2fwf8e-1 (rev 1). Isolated review
// copies only. Every vector is driven through the composed production
// entry Authorize (all five operations); the probe only REPORTS the
// outcome so the same file runs on trunk 799c338 and on the candidate.

import (
	"errors"
	"fmt"
	"sort"
	"testing"
	"time"
)

func reviewCode(err error) string {
	if err == nil {
		return "MINT"
	}
	code := "?"
	switch {
	case errors.Is(err, ErrInvalidArguments):
		code = "invalid_arguments"
	case errors.Is(err, ErrLeaseConflict):
		code = "lease_conflict"
	case errors.Is(err, ErrNotOwner):
		code = "not_owner"
	case errors.Is(err, ErrStaleOwner):
		code = "stale_owner"
	}
	if reason, winning, parked := ParkDetails(err); parked {
		return fmt.Sprintf("PARK(%s,cause=%s,winning=%s)", reason, code, winning)
	}
	return "REFUSE(" + code + ")"
}

func reviewLapse(o *Observation) {
	o.Now = fenceValidatedAt.Add(fencePolicy.RefreshInterval + time.Second)
}
func reviewRemote(o *Observation) { o.Winner.HolderHostID = fenceHostB }

// TestReviewVectorGrid prints one row per (vector, operation).
func TestReviewVectorGrid(t *testing.T) {
	type vector struct {
		name      string
		presented func() PresentedToken
		mutate    func(*Observation)
	}
	stale := func() PresentedToken { p := fencePresented(); p.Epoch = 1; p.LeaseID = fenceLeaseOld; return p }
	loser := func() PresentedToken { p := fencePresented(); p.LeaseID = fenceLeaseOld; return p }
	future := func() PresentedToken { p := fencePresented(); p.Epoch = 3; return p }
	vectors := []vector{
		{"V00 local winner, live grant (control)", fencePresented, func(o *Observation) {}},
		{"V01 PROBE10 remote winner, lapsed grant", fencePresented, func(o *Observation) { reviewRemote(o); reviewLapse(o) }},
		{"V02 remote winner, live grant", fencePresented, func(o *Observation) { reviewRemote(o) }},
		{"V03 local winner, lapsed grant", fencePresented, func(o *Observation) { reviewLapse(o) }},
		{"V04 remote winner, NO grant", fencePresented, func(o *Observation) { reviewRemote(o); o.HasGrant = false }},
		{"V05 remote winner, lapsed grant, no clock", fencePresented, func(o *Observation) { reviewRemote(o); o.Now = time.Time{} }},
		{"V06 remote winner, unusable policy", fencePresented, func(o *Observation) { reviewRemote(o); o.Policy.RefreshInterval = 0 }},
		{"V07 remote winner, lapsed grant, STALE epoch token", stale, func(o *Observation) { reviewRemote(o); reviewLapse(o) }},
		{"V08 remote winner, lapsed grant, same-epoch LOSING lease", loser, func(o *Observation) { reviewRemote(o); reviewLapse(o) }},
		{"V09 remote winner, lapsed grant, FUTURE epoch token", future, func(o *Observation) { reviewRemote(o); reviewLapse(o) }},
		{"V10 local winner, lapsed grant, STALE epoch token", stale, func(o *Observation) { reviewLapse(o) }},
		{"V11 remote winner, lapsed grant, unverified", fencePresented, func(o *Observation) { reviewRemote(o); reviewLapse(o); o.Verified = false }},
		{"V12 remote winner, lapsed grant, ambiguous", fencePresented, func(o *Observation) { reviewRemote(o); reviewLapse(o); o.Ambiguous = true }},
		{"V13 remote winner, lapsed grant, handoff failed", fencePresented, func(o *Observation) { reviewRemote(o); reviewLapse(o); o.HandoffFailed = true }},
		{"V14 remote winner, lapsed grant, empty LocalHostID", fencePresented, func(o *Observation) { reviewRemote(o); reviewLapse(o); o.LocalHostID = "" }},
		{"V15 remote winner, grant exactly at expiry edge (Now = ValidatedAt+Interval)", fencePresented, func(o *Observation) { reviewRemote(o); o.Now = fenceValidatedAt.Add(fencePolicy.RefreshInterval) }},
		{"V16 local winner, grant exactly at expiry edge", fencePresented, func(o *Observation) { o.Now = fenceValidatedAt.Add(fencePolicy.RefreshInterval) }},
	}
	ops := []Operation{OperationActivation, OperationRestore, OperationInput, OperationMutation, OperationCheckpoint}
	for _, v := range vectors {
		row := v.name + " ::"
		for _, op := range ops {
			observation := fenceObservation()
			v.mutate(&observation)
			_, err := Authorize(op, v.presented(), observation)
			row += fmt.Sprintf(" %s=%s", op, reviewCode(err))
		}
		t.Log(row)
	}
}

// TestReviewStaleRelativeToWinnerAgreement reports, for the remote
// winner + lapsed grant vectors, what the landed StaleRelativeToWinner
// verdict says next to what Authorize's tuple arms would say.
func TestReviewStaleRelativeToWinnerAgreement(t *testing.T) {
	tokens := map[string]PresentedToken{
		"winning": fencePresented(),
		"stale":   {SessionID: fenceSessionA, Epoch: 1, LeaseID: fenceLeaseOld},
		"loser":   {SessionID: fenceSessionA, Epoch: 2, LeaseID: fenceLeaseOld},
		"future":  {SessionID: fenceSessionA, Epoch: 3, LeaseID: fenceLeaseOld},
	}
	names := make([]string, 0, len(tokens))
	for n := range tokens {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		observation := fenceObservation()
		reviewRemote(&observation)
		reviewLapse(&observation)
		stale, decided := StaleRelativeToWinner(tokens[n], observation)
		_, direct := Authorize(OperationRestore, tokens[n], observation)
		relative := observation
		relative.LocalHostID = observation.Winner.HolderHostID
		_, rel := Authorize(OperationRestore, tokens[n], relative)
		t.Logf("token=%s stale=%v decided=%v direct=%s relative(from winner host)=%s", n, stale, decided, reviewCode(direct), reviewCode(rel))
	}
}
