package axpane

// Reviewer probe: probe 10's observation driven through the real Run
// entry (config, session load, ownership observation, decide, and the
// parked-event path). Report-only.

import (
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

func reviewRemoteTakeover(t *testing.T, world *runWorld) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        fixtureLeaseB,
			HolderHostID:   fixtureRemoteHost,
			IssuedByHostID: fixtureRemoteHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: seedDigest(0xC9),
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

func TestReviewRunProbe10ThroughRun(t *testing.T) {
	for _, mode := range []Mode{ModeRestore, ModeLaunch} {
		for _, interactive := range []bool{true, false} {
			world := buildRunWorld(t)
			reviewRemoteTakeover(t, world)
			request := runRequest(t, world)
			request.Mode = mode
			request.Observe.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour)
			request.RemoteInteractive = interactive
			before := eventCount(t, world.repo)
			outcome, err := Run(world.stores(), request)
			after := eventCount(t, world.repo)
			if err != nil {
				t.Logf("mode=%s interactive=%v :: Run() error=%v", mode, interactive, err)
				continue
			}
			t.Logf("mode=%s interactive=%v :: action=%s class=%s reason=%s winning=%s emitted=%v events %d->%d cause=%v", mode, interactive, outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.ParkReason, outcome.Decision.WinningLeaseID, outcome.Emitted, before, after, outcome.Decision.Cause)
		}
	}
}
