package terminstance

// Reviewer probes for CR-BUG-260917-2fwf8e-1 (rev 1): what the
// composed ObserveFencing entry does with a STALE incarnation under a
// remote winner when the local grant has lapsed (the §13.7 cold
// force-takeover prior owner). Report-only.

import (
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func TestReviewStaleUnderRemoteWinnerByGrantShape(t *testing.T) {
	stale := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	loser := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLeaseB}
	shapes := []struct {
		name  string
		shape func(*fencing.Observation)
	}{
		{"live grant", func(o *fencing.Observation) {}},
		{"lapsed grant", func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }},
		{"no grant", func(o *fencing.Observation) { o.HasGrant = false }},
		{"no clock", func(o *fencing.Observation) { o.Now = time.Time{} }},
		{"unusable policy", func(o *fencing.Observation) { o.Policy.RefreshInterval = 0 }},
	}
	for _, winner := range []struct {
		name string
		obs  func() fencing.Observation
	}{{"remote winner", remoteWinnerObservation}, {"local winner", fencingObservation}} {
		for _, tok := range []struct {
			name string
			p    fencing.PresentedToken
		}{{"stale epoch", stale}, {"losing lease", loser}} {
			for _, sh := range shapes {
				for _, current := range []terminalbackend.InstanceState{terminalbackend.StateActive, terminalbackend.StateParked, terminalbackend.StateQuiescing} {
					observation := winner.obs()
					sh.shape(&observation)
					state, transitioned, err := ObserveFencing(current, tok.p, observation)
					t.Logf("%s / %s / %s / from %s :: state=%s transitioned=%v err=%v", winner.name, tok.name, sh.name, current, state, transitioned, err)
				}
			}
		}
	}
}
