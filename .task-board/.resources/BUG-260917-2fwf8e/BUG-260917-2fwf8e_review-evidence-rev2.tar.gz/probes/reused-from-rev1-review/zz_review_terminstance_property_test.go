package terminstance

// Reviewer property test for CR-BUG-260917-2fwf8e-1: SPEC v0.7.0 §13.7
// ("The loser MUST stop accepting input when it learns the winner";
// "A stale after convergence") and §13.4 ("If a higher or winning
// same-epoch lease is observed, the wrapper MUST block input, park or
// terminate its stale provider"). The assertion is the landed
// TestRV3F3_GrantLessStaleFences ObserveFencing assertion WITHOUT the
// old-order precondition, so it measures the property, not the arm
// order: a stale incarnation under a remote winner reaches the literal
// stale_fenced whatever the grant shape.

import (
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func TestReviewStaleUnderRemoteWinnerLapsedGrantMustFence(t *testing.T) {
	stale := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}
	loser := fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLeaseB}
	for _, tok := range []struct {
		name string
		p    fencing.PresentedToken
	}{{"stale_epoch", stale}, {"losing_lease", loser}} {
		for _, current := range []terminalbackend.InstanceState{terminalbackend.StateActive, terminalbackend.StateParked, terminalbackend.StateQuiescing} {
			t.Run(tok.name+"/"+string(current), func(t *testing.T) {
				observation := remoteWinnerObservation()
				observation.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour)
				state, transitioned, err := ObserveFencing(current, tok.p, observation)
				if err != nil {
					t.Fatalf("ObserveFencing() error = %v, want the fencing transition", err)
				}
				if !transitioned {
					t.Fatal("ObserveFencing() transitioned = false, want stale_fenced")
				}
				if string(state) != "stale_fenced" {
					t.Fatalf("state = %s, want literal stale_fenced", state)
				}
			})
		}
	}
}
