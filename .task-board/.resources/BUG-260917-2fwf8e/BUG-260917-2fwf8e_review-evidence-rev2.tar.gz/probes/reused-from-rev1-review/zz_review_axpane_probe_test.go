package axpane

// Reviewer probes for CR-BUG-260917-2fwf8e-1 (rev 1): probe 10 of
// TASK-260830-1geqhj_review-evidence-rev1 reproduced verbatim at the
// composed Decide entry, plus the step-away vectors. Report-only.

import (
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
)

// TestReviewProbe10Verbatim is the archived probe body unchanged
// (buildDecideDeps/validInput/lapsedObservation are the landed
// fixtures the archived probe used).
func TestReviewProbe10Verbatim(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Observation = lapsedObservation(fixtureNow())
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision := Decide(input)
	t.Logf("PROBE10 remote interactive owner + expired grant: action=%s class=%s reason=%s winning=%s cause=%v", decision.Action, decision.Class, decision.ParkReason, decision.WinningLeaseID, decision.Cause)
}

func TestReviewDecideNeighbourGrid(t *testing.T) {
	type vec struct {
		name        string
		attach      bool
		interactive bool
		mode        Mode
		shape       func(*fencing.Observation)
	}
	lapse := func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }
	remote := func(o *fencing.Observation) { o.Winner.HolderHostID = fixtureRemoteHost }
	vectors := []vec{
		{"A restore, remote interactive, LIVE grant, attach admitted", true, true, ModeRestore, func(o *fencing.Observation) { remote(o) }},
		{"B restore, remote NON-interactive, lapsed grant", true, false, ModeRestore, func(o *fencing.Observation) { remote(o); lapse(o) }},
		{"C restore, LOCAL owner, lapsed grant", true, true, ModeRestore, func(o *fencing.Observation) { lapse(o) }},
		{"D restore, remote interactive, NO grant at all", true, true, ModeRestore, func(o *fencing.Observation) { remote(o); o.HasGrant = false }},
		{"E restore, remote interactive, lapsed grant, attach NOT admitted", false, true, ModeRestore, func(o *fencing.Observation) { remote(o); lapse(o) }},
		{"F launch, remote interactive, lapsed grant, attach admitted", true, true, ModeLaunch, func(o *fencing.Observation) { remote(o); lapse(o) }},
		{"G restore, remote interactive, lapsed grant, unverified", true, true, ModeRestore, func(o *fencing.Observation) { remote(o); lapse(o); o.Verified = false }},
		{"H restore, remote interactive, lapsed grant, no clock", true, true, ModeRestore, func(o *fencing.Observation) { remote(o); lapse(o); o.Now = time.Time{} }},
		{"I restore, remote interactive, unusable policy", true, true, ModeRestore, func(o *fencing.Observation) { remote(o); o.Policy.RefreshInterval = 0 }},
		{"J restore, local owner, live grant (control)", true, true, ModeRestore, func(o *fencing.Observation) {}},
	}
	for _, v := range vectors {
		t.Run(v.name, func(t *testing.T) {
			deps := buildDecideDeps(t, v.attach)
			input := validInput(t, deps)
			input.Mode = v.mode
			input.Observation = fixtureObservation(fixtureNow())
			v.shape(&input.Observation)
			input.RemoteInteractive = v.interactive
			decision := Decide(input)
			t.Logf("%s :: action=%s class=%s reason=%s winning=%s cause=%v", v.name, decision.Action, decision.Class, decision.ParkReason, decision.WinningLeaseID, decision.Cause)
		})
	}
}
