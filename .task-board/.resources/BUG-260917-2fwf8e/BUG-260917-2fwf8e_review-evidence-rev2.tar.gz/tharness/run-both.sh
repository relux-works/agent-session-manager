#!/bin/zsh
cd /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/trees/cand-tharness || exit 9
for N in 1 2; do
  echo "=== pass $N start $(date -u +%FT%TZ) load: $(uptime | sed 's/.*load averages: //')" > /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass$N.meta
  S=$(date +%s)
  PYTHONDONTWRITEBYTECODE=1 AX_MUTANT_VERBOSE=1 python3 internal/terminstance/mutant_harness.py > /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass$N.raw.log 2>&1
  echo "rc=$? elapsed=$(( $(date +%s) - S ))s end $(date -u +%FT%TZ)" >> /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass$N.meta
  grep -E '^(ok|MISMATCH|ERROR)' /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass$N.raw.log > /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass$N.verdicts.log
done
shasum -a 256 internal/terminstance/*.go > /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/after-blobs.sha256
echo DONE >> /Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260917-kf9g1h/worktree/.temp/BUG-260917-2fwf8e/review-rev2/tharness/pass2.meta
