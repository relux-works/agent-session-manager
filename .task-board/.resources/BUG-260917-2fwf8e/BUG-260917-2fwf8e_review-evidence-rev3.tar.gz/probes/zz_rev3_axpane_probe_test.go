package axpane

// Reviewer instruments for CR-BUG-260917-2fwf8e-3 (RUN-260921-a9f83c).
// Probe 10 is the verbatim body of TASK-260830-1geqhj review probe 10
// (zz_review_probe_test.go:451-460 in the rev1 review archive). The
// rest is a deterministic neighbour grid at the composed axpane.Decide
// entry and the real axpane.Run entry. Every row only LOGS its outcome:
// the grid is diffed between trunk and candidate, not asserted here.

import (
	"errors"
	"fmt"
	"sort"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

// PROBE 10 — remote interactive owner with a lapsed local grant:
// report which arm wins (fencing checks expiry before ownership
// direction, so this refuses instead of offering).
func TestReviewProbeRemoteInteractiveOwnerExpiredGrant(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Observation = lapsedObservation(fixtureNow())
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision := Decide(input)
	t.Logf("remote interactive owner + expired grant: action=%s class=%s reason=%s cause=%v", decision.Action, decision.Class, decision.ParkReason, decision.Cause)
}

func rev3Describe(decision Decision) string {
	return fmt.Sprintf("action=%s class=%s reason=%s winning=%s cause=%v", decision.Action, decision.Class, decision.ParkReason, decision.WinningLeaseID, decision.Cause)
}

// TestRev3DecideNeighbourGrid drives axpane.Decide over the neighbour
// vectors: mode × owner × grant shape × remote interactive × attach
// admitted. The ordering of rows is deterministic so the two trees diff.
func TestRev3DecideNeighbourGrid(t *testing.T) {
	type grantShape struct {
		name  string
		apply func(*fencing.Observation)
	}
	grants := []grantShape{
		{"live", func(*fencing.Observation) {}},
		{"lapsed", func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }},
		{"absent", func(o *fencing.Observation) { o.HasGrant = false }},
		{"noclock", func(o *fencing.Observation) { o.Now = time.Time{} }},
		{"badpolicy", func(o *fencing.Observation) { o.Policy.RefreshInterval = 0 }},
	}
	owners := []struct {
		name string
		host string
	}{{"local", fixtureLocalHost}, {"remote", fixtureRemoteHost}, {"emptyhost", ""}}
	modes := []struct {
		name string
		mode Mode
	}{{"restore", ModeRestore}, {"launch", ModeLaunch}}
	var rows []string
	for _, mode := range modes {
		for _, owner := range owners {
			for _, grant := range grants {
				for _, remoteInteractive := range []bool{true, false} {
					for _, attachAdmitted := range []bool{true, false} {
						deps := buildDecideDeps(t, attachAdmitted)
						input := validInput(t, deps)
						input.Mode = mode.mode
						input.Observation = fixtureObservation(fixtureNow())
						grant.apply(&input.Observation)
						if owner.name == "emptyhost" {
							input.Observation.LocalHostID = ""
							input.Observation.Winner.HolderHostID = fixtureRemoteHost
						} else {
							input.Observation.Winner.HolderHostID = owner.host
						}
						input.RemoteInteractive = remoteInteractive
						decision := Decide(input)
						rows = append(rows, fmt.Sprintf("GRID mode=%s owner=%s grant=%s remoteInteractive=%t attachAdmitted=%t => %s",
							mode.name, owner.name, grant.name, remoteInteractive, attachAdmitted, rev3Describe(decision)))
					}
				}
			}
		}
	}
	sort.Strings(rows)
	for _, row := range rows {
		t.Log(row)
	}
}

func rev3RemoteTakeover(t *testing.T, world *runWorld) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        fixtureLeaseB,
			HolderHostID:   fixtureRemoteHost,
			IssuedByHostID: fixtureRemoteHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: seedDigest(0xC9),
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

// TestRev3RunRemoteOwnerLapsedGrant drives the real Run entry: the
// durable chain is handed to a remote host, the local grant has
// lapsed, and the wrapper starts in restore and launch modes with an
// interactive and a non-interactive remote owner. Events before/after
// are counted so any authoring under the remote lease is visible.
func TestRev3RunRemoteOwnerLapsedGrant(t *testing.T) {
	for _, mode := range []struct {
		name string
		mode Mode
	}{{"restore", ModeRestore}, {"launch", ModeLaunch}} {
		for _, remoteInteractive := range []bool{true, false} {
			for _, grant := range []string{"live", "lapsed"} {
				name := fmt.Sprintf("%s/remoteInteractive=%t/grant=%s", mode.name, remoteInteractive, grant)
				t.Run(name, func(t *testing.T) {
					world := buildRunWorld(t)
					rev3RemoteTakeover(t, world)
					before, err := world.repo.ListEvents(fixtureSession)
					if err != nil {
						t.Fatal(err)
					}
					request := runRequest(t, world)
					request.Mode = mode.mode
					request.RemoteInteractive = remoteInteractive
					request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA}
					if grant == "lapsed" {
						request.Observe.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour)
					}
					outcome, err := Run(world.stores(), request)
					after, listErr := world.repo.ListEvents(fixtureSession)
					if listErr != nil {
						t.Fatal(listErr)
					}
					if err != nil {
						t.Logf("RUN %s => error=%v (events %d->%d)", name, err, len(before), len(after))
						return
					}
					t.Logf("RUN %s => %s emitted=%t events %d->%d", name, rev3Describe(outcome.Decision), outcome.Emitted, len(before), len(after))
					if outcome.Emitted && outcome.Event != nil {
						t.Logf("RUN %s authored event %s", name, outcome.Event.EventID)
					}
					_ = errors.Is
				})
			}
		}
	}
}
