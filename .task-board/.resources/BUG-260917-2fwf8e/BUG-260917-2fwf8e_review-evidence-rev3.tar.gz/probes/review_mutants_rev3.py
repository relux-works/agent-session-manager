#!/usr/bin/env python3
"""Reviewer plants for CR-BUG-260917-2fwf8e-3 (RUN-260921-a9f83c).

Runs on an isolated copy of the candidate tree (never the Story worktree).
Each plant: anchor must occur exactly once (else NOT_APPLIED), apply, run the
killer mask (the complete internal/fencing importer set) with -count=1,
classify from the real exit code and the parsed -json stream, write one raw
log + one unified diff per plant, restore the file from the pristine bytes and
verify the sha256. PYTHONDONTWRITEBYTECODE=1 is required by the caller.
"""
import difflib, hashlib, json, os, subprocess, sys, time

ROOT = sys.argv[1]           # isolated candidate copy (module root)
OUT = sys.argv[2]            # output dir for this pass
ONLY = sys.argv[3] if len(sys.argv) > 3 else ""
os.makedirs(OUT, exist_ok=True)
MASK = ["./internal/fencing", "./internal/terminstance", "./internal/axpane", "./internal/termbind"]

GATE = "internal/fencing/gate.go"
TERM = "internal/terminstance/fencing.go"
PANE = "internal/axpane/decide.go"

DIRECTION_ARM = """\tif observation.Winner.HolderHostID != observation.LocalHostID {
		if launchClass(operation) {
			return LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)
		}
		return LeaseToken{}, refuse(ErrNotOwner, "session %s is owned by remote host %s", observation.SessionID, observation.Winner.HolderHostID)
	}
"""
EXPIRY_ARM = """\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrLeaseConflict, "fencing grant for session %s lapsed; revalidate the winning token", observation.SessionID)
	}
"""
POLICY_ARM = """\tif expiryErr != nil && !errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrInvalidArguments, "fencing observation for session %s carries an unusable refresh policy", observation.SessionID)
	}
"""
EPOCH_ARMS_HEAD = "\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n"
MINT_LINE = "\treturn mintLeaseToken(observation.SessionID, observation.Winner.Epoch, observation.Winner.LeaseID), nil\n}\n"

INNER_FALLBACK = """\t// A lapsed grant can defer the relative question before its tuple arm;
	// the grant-independent verdict still fences a stale incarnation.
	if stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {
		return fenceLive(current, authErr)
	}
	return current, false, authErr
}
"""
RELATIVE_STALE_ARM = """\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner {
		return fenceLive(current, authErr)
	}
"""
OUTER_FALLBACK = """\tif stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {
		return fenceLive(current, authErr)
	}
	return current, false, authErr
}

// observeRemoteWinner"""
REMOTE_DISPATCH = """\tif parked && reason == fencing.ParkRemoteOwner {
		return observeRemoteWinner(current, presented, observation, authErr)
	}
"""
PANE_REMOTE = """\tif reason != fencing.ParkRemoteOwner {
		return parked(reason, winning, cause)
	}
	if !input.RemoteInteractive {
"""

PLANTS = [
    # --- controls ---
    ("C3-harmless-comment", GATE, "control-survive",
     "// Authorize is the fencing core: every activation-class action passes\n",
     "// Authorize is the fencing core: every activation-class action passes\n// (reviewer harmless control: comment only)\n",
     "SURVIVED"),
    ("C3-not-applied", GATE, "control-not-applied",
     "this anchor text does not occur anywhere in gate.go (reviewer NOT_APPLIED control)\n", "x\n", "NOT_APPLIED"),
    ("C3-swap-reproduced", GATE, "order (producer swap row re-planted)",
     DIRECTION_ARM + EXPIRY_ARM, EXPIRY_ARM + DIRECTION_ARM, "KILLED"),
    # --- narrowings on the candidate's arms in gate.go ---
    ("RM3-B-policy-arm-launch-only", GATE, "narrowing",
     "\tif expiryErr != nil && !errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n",
     "\tif expiryErr != nil && !errors.Is(expiryErr, sessrepo.ErrFencingExpired) && launchClass(operation) {\n", "KILLED"),
    ("RM3-C-direction-only-under-live-grant", GATE, "narrowing",
     "\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
     "\tif observation.Winner.HolderHostID != observation.LocalHostID && expiryErr == nil {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner", "KILLED"),
    ("RM3-D-nonlaunch-remote-lapsed-falls-to-lease-conflict", GATE, "narrowing",
     "\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
     "\tif observation.Winner.HolderHostID != observation.LocalHostID && (launchClass(operation) || expiryErr == nil) {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner", "KILLED"),
    ("RM3-E-lapsed-refusal-winning-tuple-only", GATE, "narrowing",
     "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n",
     "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) && presented.Epoch == observation.Winner.Epoch && presented.LeaseID == observation.Winner.LeaseID {\n", "KILLED"),
    ("RM3-F-lapsed-launch-parks-restore-policy", GATE, "narrowing (park vocabulary change)",
     EXPIRY_ARM,
     "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRestorePolicy, observation.Winner.LeaseID, ErrLeaseConflict)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n", "KILLED"),
    ("RM3-G-policy-arm-after-direction", GATE, "order",
     POLICY_ARM + DIRECTION_ARM, DIRECTION_ARM + POLICY_ARM, "KILLED"),
    ("RM3-H-lapsed-refusal-after-tuple-arms", GATE, "order",
     EXPIRY_ARM + EPOCH_ARMS_HEAD, EPOCH_ARMS_HEAD, "KILLED-stage1"),  # stage 2 below re-inserts before mint
    ("RM3-I-empty-localhost-treated-as-local", GATE, "narrowing (pre-existing, expected to survive)",
     "\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
     "\tif observation.LocalHostID != \"\" && observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner", "SURVIVED?"),
    ("RM3-P-lapsed-remote-parks-restore-policy", GATE, "narrowing (offer path removed under lapsed grant)",
     "\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n",
     "\t\tif launchClass(operation) {\n\t\t\tif expiryErr != nil {\n\t\t\t\treturn LeaseToken{}, park(ParkRestorePolicy, observation.Winner.LeaseID, ErrNotOwner)\n\t\t\t}\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n", "KILLED"),
    ("RM3-Q-lapsed-refusal-code-swap-not-owner", GATE, "code swap, same exit",
     "\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n",
     "\t\treturn LeaseToken{}, refuse(ErrNotOwner, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n", "KILLED"),
    # --- terminstance composition ---
    ("RM3-J-inner-fallback-deleted", TERM, "arm-delete (control)",
     INNER_FALLBACK, "\treturn current, false, authErr\n}\n", "KILLED"),
    ("RM3-K-inner-fallback-active-only", TERM, "narrowing",
     INNER_FALLBACK,
     INNER_FALLBACK.replace("decided && stale {", "decided && stale && current == terminalbackend.StateActive {"), "KILLED"),
    ("RM3-L-relative-stale-arm-deleted", TERM, "arm-delete (documented bound, expected to survive)",
     RELATIVE_STALE_ARM, "", "SURVIVED?"),
    ("RM3-M-outer-fallback-decided-only", TERM, "narrowing (producer's new row re-planted)",
     OUTER_FALLBACK, OUTER_FALLBACK.replace("if stale, decided := fencing.StaleRelativeToWinner(presented, observation); decided && stale {", "if _, decided := fencing.StaleRelativeToWinner(presented, observation); decided {"), "KILLED"),
    ("RM3-N-remote-dispatch-deleted", TERM, "arm-delete (structural redundancy probe)",
     REMOTE_DISPATCH, "", "SURVIVED?"),
    # --- axpane composition (untouched file; the composed offer path) ---
    ("RM3-O-wrapper-recheck-expiry-parks", PANE, "narrowing at the composed wrapper",
     PANE_REMOTE,
     "\tif reason != fencing.ParkRemoteOwner || input.Observation.Now.Sub(input.Observation.Grant.ValidatedAt) > input.Observation.Policy.RefreshInterval {\n\t\treturn parked(reason, winning, cause)\n\t}\n\tif !input.RemoteInteractive {\n", "KILLED"),
]

def sha(b): return hashlib.sha256(b).hexdigest()

def run_mask(logpath):
    t0 = time.time()
    with open(logpath, "w") as f:
        p = subprocess.run(["go", "test"] + MASK + ["-count=1", "-json"], cwd=ROOT, stdout=f, stderr=subprocess.STDOUT, timeout=900)
    elapsed = time.time() - t0
    fails, compile_fail = [], False
    with open(logpath) as f:
        for line in f:
            try:
                e = json.loads(line)
            except Exception:
                if "build failed" in line or "cannot use" in line or "undefined" in line or "syntax error" in line:
                    compile_fail = True
                continue
            if e.get("Action") == "fail" and e.get("Test"):
                fails.append(e["Test"])
            if e.get("Action") == "output" and ("[build failed]" in e.get("Output", "") or "# github.com" in e.get("Output", "")):
                compile_fail = True
    return p.returncode, elapsed, fails, compile_fail

results = []
for name, rel, kind, find, replace, expect in PLANTS:
    if ONLY and ONLY not in name:
        continue
    path = os.path.join(ROOT, rel)
    pristine = open(path, "rb").read()
    text = pristine.decode()
    count = text.count(find)
    row = {"plant": name, "file": rel, "kind": kind, "expect": expect, "anchor_count": count}
    if count != 1:
        row["classification"] = "NOT_APPLIED"
        results.append(row); print(json.dumps(row)); continue
    mutated = text.replace(find, replace)
    if name.startswith("RM3-H"):
        # stage 2: re-insert the lapsed refusal immediately before the mint line
        assert mutated.count(MINT_LINE) == 1
        mutated = mutated.replace(MINT_LINE, EXPIRY_ARM + MINT_LINE)
    with open(os.path.join(OUT, name + ".diff"), "w") as f:
        f.writelines(difflib.unified_diff(text.splitlines(True), mutated.splitlines(True), "a/" + rel, "b/" + rel))
    open(path, "w").write(mutated)
    try:
        rc, elapsed, fails, compile_fail = run_mask(os.path.join(OUT, name + ".log"))
    finally:
        open(path, "wb").write(pristine)
    restored = sha(open(path, "rb").read()) == sha(pristine)
    if compile_fail:
        cls = "COMPILE_FAIL"
    elif rc == 0:
        cls = "SURVIVED"
    else:
        cls = "KILLED"
    row.update({"classification": cls, "exit": rc, "elapsed_s": round(elapsed, 1), "failed_tests": sorted(set(fails)), "restored_ok": restored})
    results.append(row)
    print(json.dumps({k: row[k] for k in ("plant", "classification", "exit", "elapsed_s", "restored_ok")}), "fails=%d" % len(set(fails)), "top:", sorted(set(t.split("/")[0] for t in fails))[:6])
json.dump(results, open(os.path.join(OUT, "review-mutants.json"), "w"), indent=1)
