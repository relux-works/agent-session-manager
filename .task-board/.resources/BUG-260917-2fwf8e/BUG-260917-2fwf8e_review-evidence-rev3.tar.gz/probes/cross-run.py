import json, os, shutil, subprocess, sys
R = sys.argv[1]
PKGS = ["internal/fencing", "internal/terminstance", "internal/axpane", "internal/termbind"]
for name, prod, tests in [("candprod-trunktests", "cand", "trunk"), ("trunkprod-candtests", "trunk", "cand")]:
    d = os.path.join(R, "cross-" + name)
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(d)
    for f in ("go.mod", "go.sum"):
        shutil.copy(os.path.join(R, prod, f), d)
    shutil.copytree(os.path.join(R, prod, "internal"), os.path.join(d, "internal"), symlinks=True)
    for pkg in PKGS:
        target = os.path.join(d, pkg)
        for f in os.listdir(target):
            if f.endswith("_test.go"):
                os.remove(os.path.join(target, f))
        src = os.path.join(R, tests, pkg)
        for f in os.listdir(src):
            if f.endswith("_test.go"):
                shutil.copy(os.path.join(src, f), target)
    out = os.path.join(R, "pertest", name + ".jsonl")
    with open(out, "w") as fo, open(out.replace(".jsonl", ".stderr"), "w") as fe:
        rc = subprocess.run(["go", "test"] + ["./" + p for p in PKGS] + ["-count=1", "-json"], cwd=d, stdout=fo, stderr=fe).returncode
    print(name, "rc=%d" % rc)
    fails = []
    for line in open(out):
        try:
            e = json.loads(line)
        except Exception:
            continue
        if e.get("Action") == "fail" and e.get("Test"):
            fails.append((e["Package"].split("/")[-1], e["Test"]))
    print("  failing rows:", len(fails))
    for f in sorted(fails):
        print("   FAIL", f[0], f[1])
