package fencing

// Reviewer grid for CR-BUG-260917-2fwf8e-3 (RUN-260921-a9f83c): every
// presented-token class × grant shape × ownership direction, at all
// five production gate entries, plus the "relative" question from the
// winner's own host that terminstance.observeRemoteWinner asks. Rows are
// LOGGED, sorted, and diffed between trunk and candidate; no assertion
// here encodes either tree's behaviour.

import (
	"errors"
	"fmt"
	"sort"
	"testing"
	"time"
)

func rev3Outcome(token LeaseToken, err error) string {
	if err == nil {
		return fmt.Sprintf("MINT(sealed=%t)", token.seal != nil)
	}
	if reason, winning, parked := ParkDetails(err); parked {
		cause := "?"
		switch {
		case errors.Is(err, ErrNotOwner):
			cause = "not_owner"
		case errors.Is(err, ErrStaleOwner):
			cause = "stale_owner"
		case errors.Is(err, ErrLeaseConflict):
			cause = "lease_conflict"
		case errors.Is(err, ErrInvalidArguments):
			cause = "invalid_arguments"
		}
		return fmt.Sprintf("PARK(%s,winning=%s,cause=%s)", reason, winning, cause)
	}
	switch {
	case errors.Is(err, ErrNotOwner):
		return "REFUSE(not_owner)"
	case errors.Is(err, ErrStaleOwner):
		return "REFUSE(stale_owner)"
	case errors.Is(err, ErrLeaseConflict):
		return "REFUSE(lease_conflict)"
	case errors.Is(err, ErrInvalidArguments):
		return "REFUSE(invalid_arguments)"
	case errors.Is(err, ErrLocalPreconditionFailed):
		return "REFUSE(local_precondition_failed)"
	}
	return "REFUSE(?)" + err.Error()
}

func TestRev3AuthorizeGrid(t *testing.T) {
	tokens := []struct {
		name  string
		token PresentedToken
	}{
		{"winning", PresentedToken{SessionID: fenceSessionA, Epoch: 2, LeaseID: fenceLeaseA}},
		{"stale_epoch", PresentedToken{SessionID: fenceSessionA, Epoch: 1, LeaseID: fenceLeaseOld}},
		{"losing_lease", PresentedToken{SessionID: fenceSessionA, Epoch: 2, LeaseID: fenceLeaseOld}},
		{"future_epoch", PresentedToken{SessionID: fenceSessionA, Epoch: 3, LeaseID: fenceLeaseC}},
	}
	grants := []struct {
		name  string
		apply func(*Observation)
	}{
		{"live", func(*Observation) {}},
		{"edge_at_interval", func(o *Observation) { o.Now = fenceValidatedAt.Add(fencePolicy.RefreshInterval) }},
		{"lapsed_by_1s", func(o *Observation) { o.Now = fenceValidatedAt.Add(fencePolicy.RefreshInterval + time.Second) }},
		{"absent", func(o *Observation) { o.HasGrant = false }},
		{"noclock", func(o *Observation) { o.Now = time.Time{} }},
		{"badpolicy", func(o *Observation) { o.Policy.RefreshInterval = 0 }},
		{"badpolicy_and_lapsed", func(o *Observation) {
			o.Policy.RefreshInterval = 0
			o.Now = fenceValidatedAt.Add(2 * time.Hour)
		}},
	}
	owners := []struct {
		name  string
		apply func(*Observation)
	}{
		{"local", func(*Observation) {}},
		{"remote", func(o *Observation) { o.Winner.HolderHostID = fenceHostB }},
		{"empty_localhost", func(o *Observation) { o.LocalHostID = "" }},
		{"unverified_remote", func(o *Observation) { o.Winner.HolderHostID = fenceHostB; o.Verified = false }},
		{"ambiguous_remote", func(o *Observation) { o.Winner.HolderHostID = fenceHostB; o.Ambiguous = true }},
		{"handoff_failed_remote", func(o *Observation) { o.Winner.HolderHostID = fenceHostB; o.HandoffFailed = true }},
	}
	entries := fenceEntries()
	entryNames := make([]string, 0, len(entries))
	for name := range entries {
		entryNames = append(entryNames, name)
	}
	sort.Strings(entryNames)
	var rows []string
	for _, owner := range owners {
		for _, grant := range grants {
			for _, tk := range tokens {
				for _, entryName := range entryNames {
					observation := fenceObservation()
					owner.apply(&observation)
					grant.apply(&observation)
					token, err := entries[entryName].authorize(tk.token, observation)
					rows = append(rows, fmt.Sprintf("GRID owner=%s grant=%s token=%s entry=%s => %s", owner.name, grant.name, tk.name, entryName, rev3Outcome(token, err)))
				}
				// The relative question terminstance.observeRemoteWinner asks:
				// the same observation authorized from the winner's own host.
				observation := fenceObservation()
				owner.apply(&observation)
				grant.apply(&observation)
				observation.LocalHostID = observation.Winner.HolderHostID
				token, err := Authorize(OperationRestore, tk.token, observation)
				stale, decided := StaleRelativeToWinner(tk.token, observation)
				rows = append(rows, fmt.Sprintf("RELATIVE owner=%s grant=%s token=%s => %s | StaleRelativeToWinner stale=%t decided=%t", owner.name, grant.name, tk.name, rev3Outcome(token, err), stale, decided))
			}
		}
	}
	sort.Strings(rows)
	for _, row := range rows {
		t.Log(row)
	}
}
