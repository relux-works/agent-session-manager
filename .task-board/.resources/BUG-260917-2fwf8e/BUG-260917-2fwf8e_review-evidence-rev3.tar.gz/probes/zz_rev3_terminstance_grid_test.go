package terminstance

// Reviewer composition grid for CR-BUG-260917-2fwf8e-3 (RUN-260921-a9f83c):
// ObserveFencing over token class × grant shape × winner direction ×
// instance state. Rows are LOGGED and diffed between trunk and
// candidate. The second test asserts the SPEC §13.7/§13.4 property the
// rev1 review found regressed: a stale incarnation under a remote
// winner with a LAPSED local grant must still reach literal
// stale_fenced from every live state.

import (
	"errors"
	"fmt"
	"sort"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

func rev3Err(err error) string {
	if err == nil {
		return "nil"
	}
	if reason, _, parked := fencing.ParkDetails(err); parked {
		return "PARK(" + string(reason) + ")"
	}
	switch {
	case errors.Is(err, fencing.ErrNotOwner):
		return "REFUSE(not_owner)"
	case errors.Is(err, fencing.ErrStaleOwner):
		return "REFUSE(stale_owner)"
	case errors.Is(err, fencing.ErrLeaseConflict):
		return "REFUSE(lease_conflict)"
	case errors.Is(err, fencing.ErrInvalidArguments):
		return "REFUSE(invalid_arguments)"
	}
	return "ERR(" + err.Error() + ")"
}

func rev3Tokens() []struct {
	name  string
	token fencing.PresentedToken
} {
	return []struct {
		name  string
		token fencing.PresentedToken
	}{
		{"winning", fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLease}},
		{"stale_epoch", fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 1, LeaseID: fixtureLeaseB}},
		{"losing_lease", fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 2, LeaseID: fixtureLeaseB}},
		{"future_epoch", fencing.PresentedToken{SessionID: fixtureSessionA, Epoch: 3, LeaseID: fixtureLeaseB}},
	}
}

func rev3Grants() []struct {
	name  string
	apply func(*fencing.Observation)
} {
	return []struct {
		name  string
		apply func(*fencing.Observation)
	}{
		{"live", func(*fencing.Observation) {}},
		{"lapsed", func(o *fencing.Observation) { o.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour) }},
		{"absent", func(o *fencing.Observation) { o.HasGrant = false }},
		{"noclock", func(o *fencing.Observation) { o.Now = time.Time{} }},
		{"badpolicy", func(o *fencing.Observation) { o.Policy.RefreshInterval = 0 }},
	}
}

func TestRev3ObserveFencingGrid(t *testing.T) {
	winners := []struct {
		name  string
		build func() fencing.Observation
	}{
		{"local", fencingObservation},
		{"remote", remoteWinnerObservation},
	}
	states := []terminalbackend.InstanceState{
		terminalbackend.StateAbsent, terminalbackend.StateCreating, terminalbackend.StateParked,
		terminalbackend.StateActive, terminalbackend.StateQuiescing, terminalbackend.StateStopped,
		terminalbackend.StateStaleFenced, terminalbackend.StateUnavailable,
	}
	var rows []string
	for _, winner := range winners {
		for _, grant := range rev3Grants() {
			for _, tk := range rev3Tokens() {
				for _, state := range states {
					observation := winner.build()
					grant.apply(&observation)
					got, transitioned, err := ObserveFencing(state, tk.token, observation)
					rows = append(rows, fmt.Sprintf("OBS winner=%s grant=%s token=%s state=%s => state=%s transitioned=%t err=%s",
						winner.name, grant.name, tk.name, state, got, transitioned, rev3Err(err)))
				}
			}
		}
	}
	sort.Strings(rows)
	for _, row := range rows {
		t.Log(row)
	}
}

// TestRev3StaleUnderRemoteWinnerLapsedGrantFences is the §13.7 property:
// "its fencing token rejects the prior owner ... The loser MUST stop
// accepting input when it learns the winner" — a lapsed grant is exactly
// the partitioned prior owner's shape after a force takeover.
func TestRev3StaleUnderRemoteWinnerLapsedGrantFences(t *testing.T) {
	for _, tk := range rev3Tokens()[1:3] {
		for _, state := range []terminalbackend.InstanceState{terminalbackend.StateCreating, terminalbackend.StateParked, terminalbackend.StateActive, terminalbackend.StateQuiescing} {
			t.Run(tk.name+"/"+string(state), func(t *testing.T) {
				observation := remoteWinnerObservation()
				observation.Grant.ValidatedAt = fixtureNow().Add(-2 * time.Hour)
				got, transitioned, err := ObserveFencing(state, tk.token, observation)
				if err != nil || !transitioned || string(got) != "stale_fenced" {
					t.Fatalf("ObserveFencing(%s, %s, remote winner, lapsed grant) = (%s, %t, %v), want (stale_fenced, true, nil)", state, tk.name, got, transitioned, err)
				}
			})
		}
	}
}
