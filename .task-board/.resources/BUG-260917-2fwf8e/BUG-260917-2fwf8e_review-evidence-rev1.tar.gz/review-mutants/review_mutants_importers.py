#!/usr/bin/env python3
"""Reviewer mutants for CR-BUG-260917-2fwf8e-1 (rev 1).
Usage: review_mutants.py <candidate-tree> <output-dir> [name-filter]
Each row: (name, kind, file, [(old,new)...], command, claim). Every edit
anchor must occur exactly once or the row is NOT_APPLIED. The tree is
copied once; each mutant is applied to the copy and restored from the
original bytes after its run. Runs the behavioral suites of
internal/fencing, internal/terminstance and internal/axpane (the three
packages the CR touches) unless the row names a command.
"""
import hashlib, json, re, shutil, subprocess, sys
from pathlib import Path

src = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve(); out.mkdir(parents=True, exist_ok=True)
flt = sys.argv[3] if len(sys.argv) > 3 else ""
copy = out / "mutation-source"
if copy.exists():
    raise SystemExit("refusing to overwrite an existing mutation source")
shutil.copytree(src, copy, ignore=shutil.ignore_patterns("zz_review_*"))

THREE = ["go", "test", "./internal/fencing/...", "./internal/terminstance", "./internal/axpane", "./internal/termbind", "-count=1", "-v"]

DIRECTION_ARM = """\tif observation.Winner.HolderHostID != observation.LocalHostID {
		if launchClass(operation) {
			return LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)
		}
		return LeaseToken{}, refuse(ErrNotOwner, "session %s is owned by remote host %s", observation.SessionID, observation.Winner.HolderHostID)
	}
"""
DEFERRED_ARM = """\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrLeaseConflict, "fencing grant for session %s lapsed; revalidate the winning token", observation.SessionID)
	}
"""
POLICY_ARM = """\tif expiryErr != nil && !errors.Is(expiryErr, sessrepo.ErrFencingExpired) {
		return LeaseToken{}, refuse(ErrInvalidArguments, "fencing observation for session %s carries an unusable refresh policy", observation.SessionID)
	}
"""

MUTANTS = [
    # RM-A NARROWING: direction-before-expiry holds for OperationRestore only;
    # every other entry (activation, input, mutation, checkpoint) keeps the
    # OLD expiry-first order. Admits the reported class back to lease_conflict
    # on 4 of 5 entries. Claim under test: the gate.go doc comment states the
    # order for the whole gate; the shipped tests drive restore only.
    ("RM-A-restore-only-direction-first", "internal/fencing/gate.go",
     [(DIRECTION_ARM + DEFERRED_ARM,
       "\tif operation != OperationRestore && errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n" + DIRECTION_ARM + DEFERRED_ARM)],
     THREE, "narrowing: restore keeps the fix, activation/input/mutation/checkpoint revert to expiry-first"),
    # RM-H NARROWING: launch-class entries keep the fix; non-launch entries
    # (input, mutation, checkpoint) under a remote winner with a lapsed grant
    # refuse lease_conflict instead of not_owner.
    ("RM-H-nonlaunch-lapsed-lease-conflict", "internal/fencing/gate.go",
     [(DIRECTION_ARM,
       "\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) {\n\t\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner, \"session %s is owned by remote host %s\", observation.SessionID, observation.Winner.HolderHostID)\n\t}\n")],
     THREE, "narrowing: non-launch remote+lapsed reverts to lease_conflict"),
    # RM-B NARROWING: the direction arm fires only under a live grant; a
    # lapsed grant falls through to the deferred refusal (the reported class).
    ("RM-B-direction-only-when-live", "internal/fencing/gate.go",
     [("\tif observation.Winner.HolderHostID != observation.LocalHostID {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner",
       "\tif observation.Winner.HolderHostID != observation.LocalHostID && expiryErr == nil {\n\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner")],
     THREE, "narrowing: remote winner parks only under a live grant"),
    # RM-D ORDER: policy validity decided after direction: remote winner with
    # an unusable policy parks remote_owner instead of invalid_arguments.
    ("RM-D-policy-after-direction", "internal/fencing/gate.go",
     [(POLICY_ARM + DIRECTION_ARM, DIRECTION_ARM + POLICY_ARM)],
     THREE, "order: remote+unusable policy moves from invalid_arguments to remote_owner park"),
    # RM-G NARROWING: a remote winner under a lapsed grant parks with the
    # restore_policy reason instead of remote_owner (offer path unreachable).
    ("RM-G-lapsed-remote-parks-restore-policy", "internal/fencing/gate.go",
     [("\t\tif launchClass(operation) {\n\t\t\treturn LeaseToken{}, park(ParkRemoteOwner, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner",
       "\t\tif launchClass(operation) {\n\t\t\treason := ParkRemoteOwner\n\t\t\tif expiryErr != nil {\n\t\t\t\treason = ParkRestorePolicy\n\t\t\t}\n\t\t\treturn LeaseToken{}, park(reason, observation.Winner.LeaseID, ErrNotOwner)\n\t\t}\n\t\treturn LeaseToken{}, refuse(ErrNotOwner")],
     THREE, "narrowing: lapsed remote parks restore_policy, offer unreachable"),
    # RM-C NARROWING: the deferred lapsed refusal fires only for the exact
    # winning tuple; a lapsed grant with a stale/losing token falls to the
    # tuple arms (stale_owner park) instead of lease_conflict.
    ("RM-C-lapsed-refusal-only-for-winning-tuple", "internal/fencing/gate.go",
     [(DEFERRED_ARM,
       "\tif errors.Is(expiryErr, sessrepo.ErrFencingExpired) && presented.Epoch == observation.Winner.Epoch && presented.LeaseID == observation.Winner.LeaseID {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"fencing grant for session %s lapsed; revalidate the winning token\", observation.SessionID)\n\t}\n")],
     THREE, "narrowing: local lapsed grant with a stale token parks stale_owner instead of refusing lease_conflict"),
    # RM-T TERMINSTANCE: the remote-winner second question is dropped (always
    # 'leave state'): measures whether the composition still pins stale
    # fencing under a remote winner for the grant shapes that still fence.
    ("RM-T-remote-second-question-dropped", "internal/terminstance/fencing.go",
     [("\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner {\n\t\treturn fenceLive(current, authErr)\n\t}\n",
       "\tif relativeReason, _, relativeParked := fencing.ParkDetails(relativeErr); relativeParked && relativeReason == fencing.ParkStaleOwner && false {\n\t\treturn fenceLive(current, authErr)\n\t}\n")],
     THREE, "arm-delete (control for the composition): remote-winner stale fencing under a live grant"),
    # C-HARMLESS: comment-only edit; must SURVIVE.
    ("C-harmless-comment", "internal/fencing/gate.go",
     [("// Authorize is the fencing core: every activation-class action passes",
       "// Authorize is the fencing core: every activation-class action passes (reviewer control)")],
     THREE, "control: must SURVIVE"),
    # C-NOT-APPLIED: anchor absent; must report NOT_APPLIED.
    ("C-not-applied", "internal/fencing/gate.go",
     [("this anchor does not occur in gate.go", "x")], THREE, "control: must be NOT_APPLIED"),
]

sel = [m for m in MUTANTS if flt in m[0]] if flt else MUTANTS
results = []

def run(name, cmd):
    log = out / (name + ".log")
    with log.open("w") as f:
        p = subprocess.run(cmd, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
    text = log.read_text()
    fails = re.findall(r"^\s*--- FAIL: ([^ ]+)", text, re.M)
    ran = re.findall(r"^=== RUN ", text, re.M) or re.findall(r"^(ok|FAIL)\s", text, re.M)
    cls = "COMPILE_OR_HARNESS_FAILURE" if not ran else ("SURVIVED" if p.returncode == 0 else ("KILLED" if fails else "COMPILE_OR_HARNESS_FAILURE"))
    return cls, p.returncode, fails

with (out / "control-before.log").open("w") as f:
    b = subprocess.run(THREE, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
results.append(dict(mutant="control-before", classification="CONTROL", exit=b.returncode))
print("control-before exit", b.returncode, flush=True)
if b.returncode:
    raise SystemExit("baseline failed")

for name, path, edits, cmd, claim in sel:
    target = copy / path
    original = target.read_bytes()
    text = original.decode()
    counts = [text.count(old) for old, _ in edits]
    if any(c != 1 for c in counts):
        results.append(dict(mutant=name, classification="NOT_APPLIED", counts=counts, claim=claim))
        print(name, "NOT_APPLIED", counts, flush=True)
        continue
    mutated = text
    for old, new in edits:
        mutated = mutated.replace(old, new)
    target.write_text(mutated)
    try:
        cls, rc, fails = run(name, cmd)
    finally:
        target.write_bytes(original)
        assert hashlib.sha256(target.read_bytes()).hexdigest() == hashlib.sha256(original).hexdigest()
    top = sorted({f.split("/")[0] for f in fails})
    results.append(dict(mutant=name, classification=cls, exit=rc, failed_top=top, failed_count=len(fails), claim=claim, command=cmd))
    print(name, cls, rc, len(fails), ", ".join(top), flush=True)

with (out / "control-after.log").open("w") as f:
    a = subprocess.run(THREE, cwd=copy, stdout=f, stderr=subprocess.STDOUT, timeout=540)
results.append(dict(mutant="control-after", classification="CONTROL", exit=a.returncode))
print("control-after exit", a.returncode, flush=True)
(out / "review-mutants.json").write_text(json.dumps(results, indent=2) + "\n")
