#!/bin/zsh
# Full configured validation suite (commands 2-27 from task-board.config.json
# spawn.worktree_isolation.validation.commands) on the immutable candidate
# tree e1cf09a7, extracted probe-free. Commands 1, 28, 29, 30 need git and
# run separately against the live worktree (read-only).
set -u
T="$1"; L="$2"
cd "$T" || exit 99
export PYTHONDONTWRITEBYTECODE=1
run() { local n="$1"; shift; local start=$(date +%s); echo "[$(date -u +%FT%TZ)] START $n :: $*" >> "$L/suite-summary.log"; ( eval "$*" ) > "$L/cmd-$n.log" 2>&1; local rc=$?; local end=$(date +%s); echo "[$(date -u +%FT%TZ)] END $n rc=$rc elapsed=$((end-start))s load=$(uptime | sed 's/.*load averages: //')" >> "$L/suite-summary.log"; echo "$rc" > "$L/cmd-$n.rc"; }
run 02 'go build ./...'
run 03 'go vet ./...'
run 04 'go test ./... -count=1 -v'
run 05 'go test ./... -race -count=1 -timeout 25m'
run 06 'go test ./... -cover -count=1'
run 07 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUntrustedEnvelopes$ -fuzztime=100x -parallel=1'
run 08 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzClosedOperationBodies$ -fuzztime=100x -parallel=1'
run 09 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzNamespaceVocabulary$ -fuzztime=100x -parallel=1'
run 10 'go test ./internal/rpcwire -run=^$ -fuzz=^FuzzUnknownFields$ -fuzztime=100x -parallel=1'
run 11 'go test ./internal/scalar -run=^$ -fuzz=^FuzzScalarProductionEntries$ -fuzztime=100x -parallel=1'
run 12 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzCanonicalizeRoundTrip$ -fuzztime=100x -parallel=1'
run 13 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObjectIdentityRepresentationInvariant$ -fuzztime=100x -parallel=1'
run 14 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzClosedIdentityShapeRefusal$ -fuzztime=100x -parallel=1'
run 15 'go test ./internal/canonicaljson -run=^$ -fuzz=^FuzzObservationEventRefusal$ -fuzztime=100x -parallel=1'
run 16 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckArgv$ -fuzztime=100x -parallel=1'
run 17 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzCheckMemberPath$ -fuzztime=100x -parallel=1'
run 18 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzIsEnvName$ -fuzztime=100x -parallel=1'
run 19 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRedactCorpus$ -fuzztime=100x -parallel=1'
run 20 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzEscapeForTerminal$ -fuzztime=100x -parallel=1'
run 21 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzRenderForTerminal$ -fuzztime=100x -parallel=1'
run 22 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzGuardResolve$ -fuzztime=100x -parallel=1'
run 23 'go test ./internal/secconftest -run=^$ -fuzz=^FuzzDetectCaseCollision$ -fuzztime=100x -parallel=1'
run 24 'go run ./internal/traceability/cmd/tracecheck'
run 25 'go run ./internal/catalog/cmd/cataloggen -adopted -output internal/catalog/catalog_gen.go -check'
run 26 'GOOS=linux GOARCH=amd64 go build ./...'
run 27 'GOOS=windows GOARCH=amd64 go build ./...'
run W1 'GOOS=windows GOARCH=amd64 go vet ./...'
echo "SUITE-DONE" >> "$L/suite-summary.log"
