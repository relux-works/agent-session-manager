# BUG-260917-2fwf8e producer evidence — revision 3

This archive is the producer handoff evidence for the arm-ordering bug. It
contains only this task's results, conformance matrix, probe bodies/logs,
outcome-keyed before/after data, mutation harness output, and final validation
logs. The foreign review archive is not embedded; only the probe input and its
sanitized reproduction are represented.

The archive was assembled from the Story worktree at the absolute path
recorded by the parent run. `MANIFEST.txt` is generated after all other files
are present and has no self-entry. Mutation harnesses ran with
`PYTHONDONTWRITEBYTECODE=1`; no Python bytecode is included.

Passes:

- fencing: two full 37-row passes; the expiry-first swap is applied and killed
  in both.
- terminstance: two full 123-row passes; the outer-fallback row is applied and
  killed in both, while the harmless control survives.
- configured validation commands 1–30 plus Windows vet: all exit 0.

The board resource was read back after attachment and diffed against the two
source outcome files. The archive itself was also read back and its manifest
was checked before handoff.
