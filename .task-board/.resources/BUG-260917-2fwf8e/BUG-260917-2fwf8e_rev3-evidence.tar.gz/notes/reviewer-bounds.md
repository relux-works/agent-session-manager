# Measured reviewer bounds

## P3-1 relative arms

Reviewer plants RM-O5 (relative question through mutation) and RM-O6 (relative
`stale_owner` arm removed) both survived twice over the complete 1,103-row
importer set. The relative arm is retained for explicit composition, but the
measured load-bearing verdict for the remote-lapsed composition is the
grant-independent `StaleRelativeToWinner` fallback. This is a bound, not an
assertion that the relative arm independently carries the behavior.

## P3-3 ModeLaunch

`N-arm-order-expiry-before-direction` is intentionally masked to
`./internal/fencing`. The committed `axpane` test and importer-set reviewer
probe drive `ModeLaunch`; the swap row does not claim to kill that wrapper cell.
The conformance matrix names this as a BOUND owned by importer-set review
evidence.

## P3-5 empty LocalHostID

RM-W1 (`direction-skipped-on-empty-localhost`) survived twice on the candidate
and once on trunk over the importer set. It is a pre-existing fail-closed
direction gap owned by the Story's final leaf. V14 is named in the moved-vector
census; this bug does not widen to fix RM-W1.
