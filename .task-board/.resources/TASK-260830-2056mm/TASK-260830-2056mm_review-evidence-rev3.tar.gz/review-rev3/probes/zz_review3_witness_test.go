package termbind

// Reviewer witnesses for surviving mutants (RUN-260918-20eca1). Each PASSES
// on the pristine tree and must FAIL under the plant it witnesses; a
// witness that passes under the plant marks the plant equivalent.

import (
	"sort"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// noEvidenceVerifier is never invoked for a zero-evidence set; the landed
// admission still requires a verifier to be supplied.
func noEvidenceVerifier(string, []byte, []byte) error { return nil }

// zeroClaimUniverse builds a coherent manifest+probe pair with no capability
// claims and therefore no Capability Evidence: the probe's protocol is the
// caller's choice among the manifest's list.
func zeroClaimUniverse(t *testing.T, probeProtocol string) (manifestID, probeID string, universe mapUniverse, registry *terminalbackend.Registry, raw string) {
	t.Helper()
	generationDigest, err := terminalbackend.GenerationDigest(fixtureRawGen)
	if err != nil {
		t.Fatal(err)
	}
	manifest := map[string]any{
		"schema":                   terminalbackend.SchemaManifest,
		"schema_version":           "1.0.0",
		"manifest_id":              "",
		"terminal_backend_id":      terminalbackend.BuiltinTmux,
		"implementation_version":   fixtureImpl,
		"protocol_versions":        []any{"1.0.0", "1.1.0"},
		"platforms":                []any{"linux", "macos", "wsl2"},
		"implementation_kind":      "builtin_go",
		"executable_digest":        nil,
		"static_capability_claims": []any{},
		"conformance_fixture_id":   seedDigest(0xF1),
		"extensions":               map[string]any{},
	}
	manifest["manifest_id"] = omitSelfIdentity(t, manifest, "manifest_id")
	probe := map[string]any{
		"schema":                    terminalbackend.SchemaProbe,
		"schema_version":            "1.0.0",
		"probe_id":                  "",
		"terminal_backend_id":       terminalbackend.BuiltinTmux,
		"implementation_version":    fixtureImpl,
		"protocol_version":          probeProtocol,
		"implementation_kind":       "builtin_go",
		"executable_digest":         nil,
		"platform":                  "linux",
		"os_version":                "14.5",
		"availability":              "available",
		"backend_generation_digest": generationDigest,
		"capability_claims":         []any{},
		"evidence_ids":              []any{},
		"probed_at":                 "2026-01-15T12:00:00.000Z",
		"extensions":                map[string]any{},
	}
	probe["probe_id"] = omitSelfIdentity(t, probe, "probe_id")
	registry = testRegistry(t)
	manifestID = manifest["manifest_id"].(string)
	probeID = probe["probe_id"].(string)
	universe = mapUniverse{manifestID: mustJSON(t, manifest), probeID: mustJSON(t, probe)}
	if _, err := registry.AdmitProbe(mustJSON(t, manifest), mustJSON(t, probe), nil, fixtureRawGen, fixtureNow(), noEvidenceVerifier); err != nil {
		t.Fatalf("zero-claim universe does not self-admit: %v", err)
	}
	return manifestID, probeID, universe, registry, fixtureRawGen
}

// The event tuple says protocol 1.1.0; the resolved probe says 1.0.0; there
// is no Capability Evidence object to carry the protocol arm. The probe arm
// of checkEventBinding must refuse on its own.
func TestRV3W_ProbeProtocolArmWithoutEvidence(t *testing.T) {
	t.Parallel()
	manifestID, probeID, universe, registry, rawGeneration := zeroClaimUniverse(t, "1.0.0")
	ids := []string{manifestID, probeID}
	sort.Strings(ids)
	// Positive neighbour: the same universe under a 1.0.0 tuple resolves.
	if _, err := ResolveEvidence(ids, EventTuple{BackendID: terminalbackend.BuiltinTmux, ImplementationVersion: fixtureImpl, ProtocolVersion: "1.0.0"}, registry, universe, rawGeneration, fixtureNow(), noEvidenceVerifier); err != nil {
		t.Fatalf("zero-claim universe under its own tuple refused: %v", err)
	}
	_, err := ResolveEvidence(ids, EventTuple{BackendID: terminalbackend.BuiltinTmux, ImplementationVersion: fixtureImpl, ProtocolVersion: "1.1.0"}, registry, universe, rawGeneration, fixtureNow(), noEvidenceVerifier)
	if err == nil {
		t.Fatal("probe at 1.0.0 resolved under an event tuple at 1.1.0 with no evidence object to carry the protocol arm")
	}
	requireCode(t, err, "terminal_backend_manifest_probe_mismatch")
	requireDetail(t, err, "evidence binding")
}

// EmitResumed with a carried profile source and an unresolvable evidence
// set must refuse: resolution runs on every resumed path.
func TestRV3W_ResumedWithSourceStillResolves(t *testing.T) {
	t.Parallel()
	repository, _ := chainFixture(t)
	world := buildTmuxUniverse(t)
	facts := emitFacts(world)
	facts.EvidenceIDs = []string{seedDigest(0xEE), world.manifestID, world.probeID}
	sortStrings(facts.EvidenceIDs)
	before := len(mustListEvents(t, repository))
	_, _, _, err := EmitResumed(repository, emitParams(t, repository), seedDigest(0xC9), "yolo", seedDigest(0xCA), true, facts, emitAdmission(t, world))
	requireCode(t, err, "terminal_backend_manifest_probe_mismatch")
	if after := len(mustListEvents(t, repository)); after != before {
		t.Fatalf("resumed-with-source appended %d events with unresolvable evidence", after-before)
	}
}
