#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-2056mm-3 (RUN-260918-20eca1).

Each plant narrows a gate the shipped harness did not mutate, then runs the
WHOLE committed internal/termbind suite (not a scoped killer) in an isolated
copy. KILLED = the committed suite fails; SURVIVED = it passes. Every plant
writes a raw log with the subprocess exit code. Two controls: K (a real
kill through a producer gate, proves the runner can kill) and C (a
comment-only edit that must SURVIVE, proves the runner can report a
survivor). Files are restored from a byte copy after every row and the
restoration is verified by sha256.

Usage: PYTHONDONTWRITEBYTECODE=1 python3 review3_mutants.py <repo-copy> <log-dir> [--witness <witness_test_file>]
"""

import hashlib
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Plant:
    name: str
    path: str
    find: str
    replace: str
    kind: str
    note: str
    witness: str = ""  # -run pattern of the reviewer witness (run only when the suite survives)


PLANTS = [
    Plant(
        "RV3-K-control-kill",
        "internal/termbind/identity.go",
        '\tif schema != BindingSchema {\n',
        '\tif schema != BindingSchema && schema != "urn:ax:schema:session-event" {\n',
        "narrowing",
        "schema literal arm admits exactly the session-event schema (control kill: the committed wrong_schema subtest uses this literal)",
    ),
    Plant(
        "RV3-M1-schema-version",
        "internal/termbind/identity.go",
        '\tif version != BindingSchemaVersion {\n',
        '\tif version != BindingSchemaVersion && version != "2.0.0" {\n',
        "narrowing",
        "schema_version arm admits exactly 2.0.0 (member check dropped for one value)",
    ),
    Plant(
        "RV3-M2-native-513",
        "internal/termbind/identity.go",
        '\tif _, ok := environ.CheckStringBounds(members["native_reference"], 1, 512); !ok {\n',
        '\tif _, ok := environ.CheckStringBounds(members["native_reference"], 1, 513); !ok {\n',
        "narrowing",
        "native_reference bound widened by one (513 admitted)",
    ),
    Plant(
        "RV3-M3-major-prefix",
        "internal/termbind/identity.go",
        '\treturn strings.HasPrefix(version, "1.")\n',
        '\treturn strings.HasPrefix(version, "1")\n',
        "narrowing",
        "protocol major-1 selection widened to any major starting with the digit 1 (10, 11, 18446744073709551617 admitted)",
    ),
    Plant(
        "RV3-M4-probe-protocol-arm",
        "internal/termbind/resolve.go",
        '\tif probe.TerminalBackendID != tuple.BackendID || probe.ImplementationVersion != tuple.ImplementationVersion || probe.ProtocolVersion != tuple.ProtocolVersion {\n',
        '\tif probe.TerminalBackendID != tuple.BackendID || probe.ImplementationVersion != tuple.ImplementationVersion {\n',
        "narrowing",
        "checkEventBinding drops exactly the PROBE protocol-version arm (the shipped row N-resolve-binding drops the evidence arm); reachable with a zero-evidence universe",
        witness="TestRV3W_ProbeProtocolArmWithoutEvidence",
    ),
    Plant(
        "RV3-M5-evidence-identity-half",
        "internal/termbind/resolve.go",
        '\tfor _, object := range evidence {\n\t\tif !named[object.EvidenceID] {\n\t\t\treturn mismatchRefusal("evidence identity")\n\t\t}\n\t}\n\treturn nil\n}\n',
        '\tfor _, object := range evidence {\n\t\tif !named[object.EvidenceID] && object.EvidenceID == "" {\n\t\t\treturn mismatchRefusal("evidence identity")\n\t\t}\n\t}\n\treturn nil\n}\n',
        "narrowing",
        "checkResolvedIdentity narrows the evidence-object half to never fire for a real ID (manifest/probe halves intact)",
    ),
    Plant(
        "RV3-M6-probe-required",
        "internal/termbind/resolve.go",
        '\tif !manifestFound || !probeFound {\n',
        '\tif !manifestFound {\n',
        "narrowing",
        "the manifest+probe cardinality drops exactly the probe-required half",
    ),
    Plant(
        "RV3-M7-resumed-source-skips-resolution",
        "internal/termbind/emit.go",
        '\tresolved, err := ResolveEvidence(facts.EvidenceIDs, tupleFromFacts(facts), admission.Registry, admission.Universe, admission.RawGeneration, admission.Now, admission.Verify)\n\tif err != nil {\n\t\treturn empty, nil, ResolvedEvidence{}, err\n\t}\n\tpayload, err := axpane.ResumedPayload(',
        '\tvar resolved ResolvedEvidence\n\tif !hasSource {\n\t\tvar err error\n\t\tresolved, err = ResolveEvidence(facts.EvidenceIDs, tupleFromFacts(facts), admission.Registry, admission.Universe, admission.RawGeneration, admission.Now, admission.Verify)\n\t\tif err != nil {\n\t\t\treturn empty, nil, ResolvedEvidence{}, err\n\t\t}\n\t}\n\tpayload, err := axpane.ResumedPayload(',
        "narrowing",
        "EmitResumed skips evidence resolution exactly when a profile source is carried (the pre-append revalidation skipped on one path)",
        witness="TestRV3W_ResumedWithSourceStillResolves",
    ),
    Plant(
        "RV3-M8-attach-client-pid",
        "internal/termbind/attach.go",
        '\tif err := CheckInstanceIdentity(clientID); err != nil {\n\t\treturn empty, false, err\n\t}\n\tif !isAttachTransport(transport) {\n',
        '\tif err := CheckInstanceIdentity(clientID); err != nil && clientID != "12345" {\n\t\treturn empty, false, err\n\t}\n\tif !isAttachTransport(transport) {\n',
        "narrowing",
        "Attach admits exactly the PID form as client_id (instance axis intact)",
    ),
    Plant(
        "RV3-M9-recover-absent-without-window-anchor",
        "internal/termbind/recover.go",
        '\t\tif anchored && anchor.OperationID != request.BootstrapOperationID && request.WindowOpen {\n',
        '\t\tif anchored && anchor.OperationID != request.BootstrapOperationID && request.WindowOpen && anchor.OperationID != "0198f4c8-7d40-7e55-8e6f-1234567890ab" {\n',
        "narrowing",
        "the in-window changed-operation refusal is skipped exactly when the anchored operation is the fixture bootstrap ID",
    ),
    Plant(
        "RV3-C-control-survive",
        "internal/termbind/resolve.go",
        '// mismatchRefusal builds the Section 4.B evidence refusal: any failed\n',
        '// mismatchRefusal builds the Section 4.B evidence refusal (control): any failed\n',
        "control",
        "comment-only edit; must SURVIVE",
    ),
]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(repo: Path, logdir: Path, witness_file: Path | None, tag: str) -> int:
    failures = 0
    verdicts = []
    for plant in PLANTS:
        target = repo / plant.path
        original = target.read_bytes()
        original_sha = sha(target)
        text = original.decode()
        if text.count(plant.find) != 1:
            line = f"ERROR: {plant.name}: anchor count {text.count(plant.find)} != 1"
            print(line, flush=True)
            verdicts.append(line)
            failures += 1
            continue
        backup = logdir / f"{plant.name}.backup"
        shutil.copy2(target, backup)
        log = logdir / f"{plant.name}-{tag}.log"
        try:
            target.write_text(text.replace(plant.find, plant.replace))
            proc = subprocess.run(["go", "test", "./internal/termbind/", "-count=1"], cwd=repo, capture_output=True, text=True, timeout=600)
            out = proc.stdout + proc.stderr
            body = [f"=== plant {plant.name} ({plant.kind}) ===", plant.note, f"--- committed suite: exit {proc.returncode} ---", out]
            if "build failed" in out or out.startswith("# "):
                verdict = "ERROR-build"
            elif proc.returncode == 0:
                verdict = "SURVIVED"
            else:
                verdict = "KILLED"
            witness_verdict = ""
            if verdict == "SURVIVED" and plant.witness and witness_file is not None:
                dest = repo / "internal/termbind" / witness_file.name
                shutil.copy2(witness_file, dest)
                try:
                    wproc = subprocess.run(["go", "test", "./internal/termbind/", "-run", plant.witness, "-count=1", "-v"], cwd=repo, capture_output=True, text=True, timeout=600)
                finally:
                    dest.unlink()
                body += [f"--- witness {plant.witness} under the plant: exit {wproc.returncode} ---", wproc.stdout + wproc.stderr]
                witness_verdict = " witness=" + ("FAIL(non-equivalent)" if wproc.returncode != 0 else "PASS(equivalent?)")
        finally:
            shutil.copy2(backup, target)
        restored = sha(target) == original_sha
        body.append(f"--- restored: {restored} ---")
        log.write_text("\n".join(body))
        line = f"{plant.name}: {verdict}{witness_verdict} [{plant.kind}] exit={proc.returncode} :: {plant.note}"
        print(line, flush=True)
        verdicts.append(line)
        if not restored:
            failures += 1
    (logdir / f"verdicts-{tag}.txt").write_text("\n".join(verdicts) + "\n")
    return failures


if __name__ == "__main__":
    repo = Path(sys.argv[1]).resolve()
    logdir = Path(sys.argv[2]).resolve()
    logdir.mkdir(parents=True, exist_ok=True)
    witness = None
    if "--witness" in sys.argv:
        witness = Path(sys.argv[sys.argv.index("--witness") + 1]).resolve()
    tag = sys.argv[sys.argv.index("--tag") + 1] if "--tag" in sys.argv else "pass"
    sys.exit(1 if run(repo, logdir, witness, tag) else 0)
