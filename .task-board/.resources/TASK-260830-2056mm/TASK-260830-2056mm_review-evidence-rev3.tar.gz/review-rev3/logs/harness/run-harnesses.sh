#!/bin/zsh
set -u
cd "$(dirname "$0")/../../cand-h" || exit 9
export PYTHONDONTWRITEBYTECODE=1
export AX_MUTANT_VERBOSE=1
OUT=../logs/harness
echo "start $(date -u +%FT%TZ)" > $OUT/timing.log
for pass in 1 2; do
  ( time python3 internal/termbind/mutant_harness.py ) > $OUT/termbind-pass$pass-verbose.log 2>&1
  echo "termbind pass$pass exit=$? $(date -u +%FT%TZ)" >> $OUT/timing.log
  grep -E '^(ok|MISMATCH|ERROR)' $OUT/termbind-pass$pass-verbose.log > $OUT/termbind-pass$pass-verdicts.log
done
( time python3 internal/axpane/mutant_harness.py ) > $OUT/axpane-pass1-verbose.log 2>&1
echo "axpane pass1 exit=$? $(date -u +%FT%TZ)" >> $OUT/timing.log
grep -E '^(ok|MISMATCH|ERROR)' $OUT/axpane-pass1-verbose.log > $OUT/axpane-pass1-verdicts.log
( time python3 internal/terminstance/mutant_harness.py ) > $OUT/terminstance-pass1-verbose.log 2>&1
echo "terminstance pass1 exit=$? $(date -u +%FT%TZ)" >> $OUT/timing.log
grep -E '^(ok|MISMATCH|ERROR)' $OUT/terminstance-pass1-verbose.log > $OUT/terminstance-pass1-verdicts.log
echo "done $(date -u +%FT%TZ)" >> $OUT/timing.log
