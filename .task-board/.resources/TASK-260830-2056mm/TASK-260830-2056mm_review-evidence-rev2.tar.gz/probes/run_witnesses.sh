#!/bin/bash
set -u
cd "$(dirname "$0")"
for p in 1 2; do
  while read -r name witness; do
    PYTHONDONTWRITEBYTECODE=1 python3 run_witness_under_mutant.py cand-p "$name" "$witness" "$p"
  done <<'PAIRS'
RV2-M5-supersedes-any-string TestRV2W_SupersedesMustBeDigest
RV2-M9-recover-generation-bound-skipped TestRV2W_RecoverGenerationBoundBeforeStatusRead
RV2-M6-resolve-manifest-impl-arm TestRV2W_ManifestImplDriftCaughtByLandedAdmission
RV2-M3-binding-protocol-major-widen TestRV2_BindingProtocolVersionMajorOne
PAIRS
done
