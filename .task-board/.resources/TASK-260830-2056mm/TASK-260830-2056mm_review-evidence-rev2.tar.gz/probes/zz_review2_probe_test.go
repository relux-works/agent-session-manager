package termbind

// Reviewer probes for CR-TASK-260830-2056mm-2 (RUN-260918-acd5a8). These
// run only in the isolated review copy; every failing probe is a
// characterization of the candidate, graded in the verdict.

import (
	"bytes"
	"encoding/json"
	"fmt"
	"sort"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/axpane"
	"github.com/relux-works/agent-session-manager/internal/environ"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
	"github.com/relux-works/agent-session-manager/internal/terminstance"
)

// rawBindingWithExtensions builds the binding fixture bytes with the
// extensions member replaced by the literal JSON text given, and the
// binding_id recomputed the way the candidate's own bindingIdentity
// computes it (decode to map[string]any, marshal, JCS, sha256), so the
// self-ID check passes whenever the candidate launders the extension
// value the same way.
func rawBindingWithExtensions(t *testing.T, extensionsJSON string) []byte {
	t.Helper()
	base := bindingDoc(t, nil)
	var object map[string]json.RawMessage
	if err := json.Unmarshal(base, &object); err != nil {
		t.Fatal(err)
	}
	object["extensions"] = json.RawMessage(extensionsJSON)
	object["binding_id"] = json.RawMessage(`"sha256:0000000000000000000000000000000000000000000000000000000000000000"`)
	// Assemble deterministic text by hand so the extension literal is
	// preserved byte-for-byte (json.Marshal of RawMessage keeps it).
	raw, err := json.Marshal(object)
	if err != nil {
		t.Fatal(err)
	}
	recomputed, err := bindingIdentity(raw, "binding_id")
	if err != nil {
		t.Fatalf("bindingIdentity: %v", err)
	}
	raw = bytes.Replace(raw, []byte(`"sha256:0000000000000000000000000000000000000000000000000000000000000000"`), []byte(`"`+recomputed+`"`), 1)
	return raw
}

// Section 4.B: Terminal Instance Binding 1.0.0 extensions is the "exact
// empty object {}". A non-empty extensions object must refuse.
func TestRV2_BindingExtensionsMustBeEmptyObject(t *testing.T) {
	raw := rawBindingWithExtensions(t, `{"com.example.note":"y"}`)
	parsed, err := ParseTerminalBinding(raw)
	if err == nil {
		t.Fatalf("CHARACTERIZATION: non-empty extensions ADMITTED (spec 4.B: exact empty object {}); parsed=%+v", parsed)
	}
	t.Logf("refused as expected: %v", err)
}

// The AX number model: a JSON number anywhere in an identity document is
// NUM-UNSAFE (the landed terminalbackend.objectIdentity refuses every
// number before the JCS transform). The candidate's bindingIdentity has no
// such walk, so a number in an extension value is rounded/reformatted by
// the float64 round trip and the laundered digest is what gets compared.
func TestRV2_BindingIdentityLaundersNumbers(t *testing.T) {
	cases := []struct {
		name string
		ext  string
	}{
		{"float_1.0", `{"com.example.n":1.0}`},
		{"beyond_2p53", `{"com.example.n":9007199254740993}`},
		{"exponent", `{"com.example.n":1e2}`},
		{"negative_zero", `{"com.example.n":-0}`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			raw := rawBindingWithExtensions(t, tc.ext)
			parsed, err := ParseTerminalBinding(raw)
			if err == nil {
				t.Fatalf("CHARACTERIZATION: binding with number %s in extensions ADMITTED with laundered identity; parsed binding_id=%s", tc.ext, parsed.BindingID)
			}
			t.Logf("refused: %v", err)
		})
	}
}

// Nested duplicate members and lone surrogates inside extension values:
// the strict frame decoder guards the top level; does anything guard the
// nested value before the identity bytes are computed?
func TestRV2_BindingExtensionNestedShapes(t *testing.T) {
	cases := []struct {
		name string
		ext  string
	}{
		{"nested_duplicate_member", `{"com.example.o":{"a":"1","a":"2"}}`},
		{"lone_surrogate", `{"com.example.s":"\ud800"}`},
		{"invalid_utf8_escape_pair_order", `{"com.example.s":"\udc00\ud800"}`},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			raw := rawBindingWithExtensions(t, tc.ext)
			parsed, err := ParseTerminalBinding(raw)
			if err == nil {
				t.Fatalf("CHARACTERIZATION: binding with %s in extensions ADMITTED; binding_id=%s", tc.name, parsed.BindingID)
			}
			t.Logf("refused: %v", err)
		})
	}
}

// Section 4.B: protocol_version is "semver in Terminal Backend Protocol
// major 1, equal to the Probe". The landed probe/evidence parsers and
// CheckVersionTuple refuse a major other than 1; the Binding parser is the
// only new closed-object parser, so it must too.
func TestRV2_BindingProtocolVersionMajorOne(t *testing.T) {
	for _, version := range []string{"2.0.0", "0.9.0", "3.1.4"} {
		t.Run(version, func(t *testing.T) {
			raw := bindingDoc(t, func(object map[string]any) { object["protocol_version"] = version })
			parsed, err := ParseTerminalBinding(raw)
			if err == nil {
				t.Fatalf("CHARACTERIZATION: binding protocol_version %q ADMITTED (spec 4.B: major 1); parsed=%+v", version, parsed.ProtocolVersion)
			}
			t.Logf("refused: %v", err)
		})
	}
}

// Control: the landed CheckVersionTuple refuses the same versions, so the
// literal is not a reviewer invention.
func TestRV2_LandedTupleRefusesNonMajorOne(t *testing.T) {
	err := terminalbackend.CheckVersionTuple(terminalbackend.BuiltinTmux, fixtureImpl, "2.0.0", []string{"2.0.0"})
	if err == nil {
		t.Fatal("landed CheckVersionTuple admitted protocol 2.0.0")
	}
	t.Logf("landed refusal: %v", err)
}

// The landed terminstance parsers already refuse every non-UUIDv7
// terminal_instance_id with the pinned wire code
// terminal_backend_protocol_error. The termbind pre-scan therefore adds no
// refusal class; only the Go error TYPE differs, which is what the
// committed killers (requireCode's *terminalbackend.Error assertion) see.
func TestRV2_LandedBodyParsersAlreadyRefusePinnedCode(t *testing.T) {
	for _, forbidden := range forbiddenIdentities {
		t.Run("context/"+forbidden.form, func(t *testing.T) {
			_, err := terminstance.ParseMutationContext(mutationContextDoc(forbidden.value))
			if err == nil {
				t.Fatalf("landed ParseMutationContext admitted %q", forbidden.value)
			}
			code := terminstance.ErrorCode(err)
			if code != "terminal_backend_protocol_error" {
				t.Fatalf("landed code = %q (%T), want terminal_backend_protocol_error", code, err)
			}
			_, isTB := err.(*terminalbackend.Error)
			t.Logf("landed refusal type=%T code=%s isTerminalbackendError=%v", err, code, isTB)
		})
		t.Run("status/"+forbidden.form, func(t *testing.T) {
			_, err := terminstance.ParseStatusBody(statusBodyDoc(statusInstanceFragment(forbidden.value)))
			if err == nil {
				t.Fatalf("landed ParseStatusBody admitted %q", forbidden.value)
			}
			code := terminstance.ErrorCode(err)
			if code != "terminal_backend_protocol_error" {
				t.Fatalf("landed code = %q (%T), want terminal_backend_protocol_error", code, err)
			}
		})
	}
}

// Does the story-level identity gate (scalar.ParseUUIDv7) agree with the
// landed body authority (environ.CheckUUIDv7) on every member of a
// spelling corpus? A disagreement in either direction is a second model.
func TestRV2_IdentityGateAgreesWithLandedUUIDv7(t *testing.T) {
	corpus := []string{
		fixtureInstance,
		strings.ToUpper(fixtureInstance),
		"0198f4c9-1111-4aaa-8aaa-1234567890ab", // v4
		"0198f4c9-1111-7aaa-caaa-1234567890ab", // variant 110
		"0198f4c9-1111-7aaa-0aaa-1234567890ab", // variant 0
		"urn:uuid:" + fixtureInstance,
		"{" + fixtureInstance + "}",
		fixtureInstance + "\x00",
		" " + fixtureInstance,
		fixtureInstance[:35],
		fixtureInstance + "a",
		"0198f4c9-1111-7aaa-8aaa-1234567890AB",
		"0198f4c91111-7aaa-8aaa-1234567890ab",
		"00000000-0000-7000-8000-000000000000",
		"ffffffff-ffff-7fff-bfff-ffffffffffff",
	}
	disagreements := 0
	for _, value := range corpus {
		gate := CheckInstanceIdentity(value) == nil
		encoded, _ := json.Marshal(value)
		_, landed := environ.CheckUUIDv7(json.RawMessage(encoded))
		if gate != landed {
			disagreements++
			t.Errorf("DISAGREEMENT %q: CheckInstanceIdentity admits=%v environ.CheckUUIDv7 admits=%v", value, gate, landed)
		}
	}
	t.Logf("corpus=%d disagreements=%d", len(corpus), disagreements)
}

// Recovery characterizations: the found-binding arm's default case maps
// every state other than creating/unavailable to "the ONE child" with
// replay_same, including stopped and stale_fenced.
func TestRV2_RecoverCreateChildStatesCharacterization(t *testing.T) {
	for _, state := range []terminalbackend.InstanceState{terminalbackend.StateStopped, terminalbackend.StateStaleFenced, terminalbackend.StateQuiescing, terminalbackend.StateAbsent} {
		t.Run(string(state), func(t *testing.T) {
			store := openStoreForProbe(t)
			bindPair(t, store, fixtureSession, fixtureBootstrap, fixtureInstance)
			verdict, err := recoverWith(t, store, func(terminstance.StatusBody) (terminstance.StatusObservation, error) {
				return exactObservation(state, true), nil
			}, recoveryRequest(fixtureBootstrap, true))
			if err != nil {
				t.Fatalf("RecoverCreate(%s) error = %v", state, err)
			}
			t.Logf("state=%s outcome=%s retry=%s hasBinding=%v", state, verdict.Outcome, verdict.Retry, verdict.HasBinding)
		})
	}
}

func openStoreForProbe(t *testing.T) *axpane.Store {
	t.Helper()
	store, err := axpane.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	return store
}

// --- witnesses for the reviewer mutants that survived pass 1 ---

// RV2-M5 witness: a non-digest supersedes_binding_id must refuse.
func TestRV2W_SupersedesMustBeDigest(t *testing.T) {
	raw := bindingDoc(t, func(object map[string]any) { object["supersedes_binding_id"] = "not-a-digest" })
	if _, err := ParseTerminalBinding(raw); err == nil {
		t.Fatal("ParseTerminalBinding(supersedes not-a-digest) succeeded, want refusal")
	}
	// Positive neighbour: a digest supersedes admits.
	raw = bindingDoc(t, func(object map[string]any) { object["supersedes_binding_id"] = seedDigest(0x5D) })
	parsed, err := ParseTerminalBinding(raw)
	if err != nil {
		t.Fatalf("ParseTerminalBinding(supersedes digest) error = %v", err)
	}
	if !parsed.HasSupersedes || parsed.SupersedesBindingID != seedDigest(0x5D) {
		t.Fatalf("parsed supersedes = %+v", parsed)
	}
}

// RV2-M6 equivalence check: with the manifest implementation-version arm
// dropped from checkEventBinding, does the landed admission still refuse a
// manifest whose implementation version differs from the event tuple while
// the probe and evidence match the tuple? If it does, the arm is redundant
// and the surviving mutant is equivalent, not a hole.
func TestRV2W_ManifestImplDriftCaughtByLandedAdmission(t *testing.T) {
	world := buildTmuxUniverse(t)
	manifest := cloneDoc(world.manifest)
	manifest["implementation_version"] = "9.9.9"
	manifest["manifest_id"] = omitSelfIdentity(t, manifest, "manifest_id")
	driftedID := manifest["manifest_id"].(string)
	universe := universeMap(t, world)
	delete(universe, world.manifestID)
	universe[driftedID] = mustJSON(t, manifest)
	ids := []string{driftedID, world.probeID, world.evidenceID}
	sortStrings(ids)
	_, err := ResolveEvidence(ids, tmuxTuple(), world.registry, universe, world.rawGeneration, world.now, world.verify)
	if err == nil {
		t.Fatal("ResolveEvidence(manifest impl drift) succeeded, want refusal")
	}
	t.Logf("refusal: %v", err)
	// Direct landed check: AdmitProbe with the drifted manifest refuses on its own.
	if _, err := world.registry.AdmitProbe(mustJSON(t, manifest), mustJSON(t, world.probe), [][]byte{mustJSON(t, world.evidence)}, world.rawGeneration, world.now, world.verify); err == nil {
		t.Fatal("landed AdmitProbe admitted a manifest/probe implementation drift")
	} else {
		t.Logf("landed AdmitProbe refusal: %v", err)
	}
}

// RV2-M9 witness: a 257-character generation on a bound recovery request
// must refuse before the status read (the landed generation bound), never
// reach the backend.
func TestRV2W_RecoverGenerationBoundBeforeStatusRead(t *testing.T) {
	store := openStoreForProbe(t)
	bindPair(t, store, fixtureSession, fixtureBootstrap, fixtureInstance)
	request := recoveryRequest(fixtureBootstrap, true)
	request.Generation = strings.Repeat("g", 257)
	reads := 0
	verdict, err := recoverWith(t, store, func(terminstance.StatusBody) (terminstance.StatusObservation, error) {
		reads++
		return exactObservation(terminalbackend.StateActive, true), nil
	}, request)
	if err == nil {
		t.Fatalf("RecoverCreate(generation 257) succeeded with verdict %+v after %d status reads, want the generation bound refusal before any read", verdict, reads)
	}
	if reads != 0 {
		t.Fatalf("status read ran %d times before the bound refused", reads)
	}
	t.Logf("refusal: %v", err)
}

// --- composition and characterization probes ---

// Emission under a REMOTE winner: the presented token equals the winning
// tuple but the local host is not the holder. fencing.AuthorizeMutation
// must refuse and nothing may append. This is the "lease the local host
// does not hold" member the producer brief singled out; the committed
// TestEmitUnderLosingLeaseRefuses drives the losing-epoch member only.
func TestRV2_EmitUnderRemoteWinnerRefuses(t *testing.T) {
	repository, _ := chainFixture(t)
	world := buildTmuxUniverse(t)
	before := len(mustListEvents(t, repository))
	params := emitParams(t, repository)
	params.Observation.Winner.HolderHostID = fixtureRemoteHost
	params.Observation.Grant.Token.HolderHostID = fixtureRemoteHost
	_, _, _, err := EmitTerminalCreated(repository, params, emitFacts(world), emitAdmission(t, world))
	if err == nil {
		t.Fatal("EmitTerminalCreated(remote winner) succeeded, want refusal")
	}
	t.Logf("refusal: %v", err)
	if after := len(mustListEvents(t, repository)); after != before {
		t.Fatalf("chain grew from %d to %d under a remote winner", before, after)
	}
	// Unverified ownership is the second member.
	params = emitParams(t, repository)
	params.Observation.Verified = false
	if _, _, _, err := EmitTerminalCreated(repository, params, emitFacts(world), emitAdmission(t, world)); err == nil {
		t.Fatal("EmitTerminalCreated(unverified) succeeded, want refusal")
	}
	if after := len(mustListEvents(t, repository)); after != before {
		t.Fatalf("chain grew from %d to %d under unverified ownership", before, after)
	}
}

// CHARACTERIZATION: EmitResumed binds neither checkpoint_id to the chain
// nor the (profile, source) pair to the referenced checkpoint's closure.
// A never-published digest with a yolo profile appends, and the landed
// fold then reports that digest as the newest checkpoint.
func TestRV2_ResumedCheckpointNotBoundToChain(t *testing.T) {
	repository, _ := chainFixture(t)
	world := buildTmuxUniverse(t)
	hadNewest, _ := foldNewest(t, repository)
	if hadNewest {
		t.Fatal("fixture chain already folds a newest checkpoint")
	}
	fabricated := seedDigest(0xFA)
	_, raw, _, err := EmitResumed(repository, emitParams(t, repository), fabricated, "yolo", "", false, emitFacts(world), emitAdmission(t, world))
	if err != nil {
		t.Fatalf("EmitResumed(fabricated checkpoint, yolo) refused: %v", err)
	}
	hasNewest, newest := foldNewest(t, repository)
	t.Logf("CHARACTERIZATION: session.resumed appended with checkpoint_id=%s execution_profile=yolo (never published, closure unknown); fold now HasCheckpoint=%v Newest=%s; bytes=%d", fabricated, hasNewest, newest, len(raw))
	if !hasNewest || newest != fabricated {
		t.Fatalf("fold newest = %v/%s, expected the fabricated digest to become newest (characterization assumption)", hasNewest, newest)
	}
}

// Nil registry: does ResolveEvidence fail closed or panic?
func TestRV2_ResolveEvidenceNilRegistry(t *testing.T) {
	world := buildTmuxUniverse(t)
	defer func() {
		if recovered := recover(); recovered != nil {
			t.Fatalf("CHARACTERIZATION: ResolveEvidence(nil registry) PANICKED: %v", recovered)
		}
	}()
	_, err := ResolveEvidence(world.ids, tmuxTuple(), nil, universeMap(t, world), world.rawGeneration, world.now, world.verify)
	if err == nil {
		t.Fatal("ResolveEvidence(nil registry) succeeded")
	}
	t.Logf("nil registry refusal: %v", err)
}

// Append-boundary bounds of evidence_ids through the landed canonical
// owner (bypassing resolution, which no 256-object universe exists for):
// 256 admits, 257 refuses, at the exact append entry the emission uses.
func TestRV2_AppendBoundaryEvidenceBounds(t *testing.T) {
	for _, tc := range []struct {
		n    int
		want string
	}{{256, "admit"}, {257, "refuse"}, {1, "admit"}, {0, "refuse"}} {
		t.Run(fmt.Sprintf("%d_%s", tc.n, tc.want), func(t *testing.T) {
			repository, _ := chainFixture(t)
			world := buildTmuxUniverse(t)
			payload, err := axpane.TerminalCreatedPayload(emitFacts(world))
			if err != nil {
				t.Fatal(err)
			}
			ids := make([]string, 0, tc.n)
			for i := 0; i < tc.n; i++ {
				ids = append(ids, distinctDigest(i))
			}
			sort.Strings(ids)
			payload["evidence_ids"] = ids
			params := emitParams(t, repository)
			params.EventType = "terminal.created"
			params.SchemaVersion = "4.0.0"
			params.Payload = payload
			_, _, err = axpane.Emit(repository, params)
			switch tc.want {
			case "admit":
				if err != nil {
					t.Fatalf("Emit(%d evidence ids) refused: %v", tc.n, err)
				}
			case "refuse":
				if err == nil {
					t.Fatalf("Emit(%d evidence ids) admitted, want the 1..256 refusal", tc.n)
				}
				t.Logf("refusal: %v", err)
			}
		})
	}
}
