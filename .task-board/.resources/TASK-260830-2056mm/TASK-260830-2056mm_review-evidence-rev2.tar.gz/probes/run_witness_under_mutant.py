#!/usr/bin/env python3
"""Apply one reviewer mutant (from review2_mutants.py) to the probe copy,
run the named witness, restore, and print the outcome."""
import importlib.util, shutil, subprocess, sys, tempfile
from pathlib import Path
spec = importlib.util.spec_from_file_location("rv2", Path(__file__).resolve().parent / "review2_mutants.py")
rv2 = importlib.util.module_from_spec(spec); spec.loader.exec_module(rv2)
copy = Path(sys.argv[1]).resolve(); name = sys.argv[2]; witness = sys.argv[3]; passno = sys.argv[4]
mutant = next(m for m in rv2.MUTANTS if m.name == name)
target = copy / mutant.path
original = target.read_text()
assert original.count(mutant.find) == 1, "anchor"
with tempfile.TemporaryDirectory() as staging:
    backup = Path(staging) / "backup"; shutil.copy2(target, backup)
    try:
        target.write_text(original.replace(mutant.find, mutant.replace))
        run = subprocess.run(["go", "test", f"./{rv2.PKG}/", "-run", witness, "-count=1", "-v"], cwd=copy, capture_output=True, text=True, timeout=600)
    finally:
        shutil.copy2(backup, target)
out = (run.stdout + run.stderr)
log = Path(__file__).resolve().parent / "logs" / f"rv2-witness-pass{passno}"; log.mkdir(parents=True, exist_ok=True)
(log / f"{name}__{witness}.log").write_text(f"# {name} under {witness}: exit {run.returncode}\n{out}")
verdict = "WITNESS-FAILS(mutant caught)" if run.returncode != 0 else "WITNESS-PASSES(mutant not caught)"
print(f"{name} / {witness}: {verdict} [exit {run.returncode}]")
