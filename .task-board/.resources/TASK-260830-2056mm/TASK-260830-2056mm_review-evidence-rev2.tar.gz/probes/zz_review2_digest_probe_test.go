package traceability

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"testing"
)

// Reviewer re-derivation of reviewedOwnershipCanonicalSHA256 from the
// registry as it stands in the candidate tree.
func TestRV2_RederiveOwnershipDigest(t *testing.T) {
	raw, err := os.ReadFile("ownership.v0.7.0.json")
	if err != nil {
		t.Fatal(err)
	}
	registry, err := decodeOwnershipRegistry(raw)
	if err != nil {
		t.Fatal(err)
	}
	canonical, err := json.Marshal(registry)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(canonical)
	got := hex.EncodeToString(sum[:])
	t.Logf("DERIVED-DIGEST: %s (canonical bytes: %d) raw bytes: %d", got, len(canonical), len(raw))
	if got != reviewedOwnershipCanonicalSHA256 {
		t.Fatalf("derived %s != pinned %s", got, reviewedOwnershipCanonicalSHA256)
	}
}
