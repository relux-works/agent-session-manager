#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-2056mm-2 (RUN-260918-acd5a8).

Runs against the isolated copy given as argv[1] (default ./cand-m). Every
row mutates one production file in place, runs the WHOLE committed
internal/termbind suite (not only a named killer) so a survivor is a
survivor against everything the producer committed, restores the file
from a backup, and prints the verdict with the subprocess exit. Raw
per-plant output is written under logs/rv2-mutants-pass<N>/<row>.log.

Usage: PYTHONDONTWRITEBYTECODE=1 python3 review2_mutants.py <copy> <pass>
"""

import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    kind: str
    note: str


PKG = "internal/termbind"

MUTANTS = [
    Mutant(
        name="RV2-M3-binding-protocol-major-widen",
        path=f"{PKG}/identity.go",
        find='\tif !environ.CheckSemver(protocol) {\n\t\treturn empty, protocolRefusal("binding protocol version")\n\t}\n',
        replace='\tif !environ.CheckSemver(protocol) && protocol != "2.0.0" {\n\t\treturn empty, protocolRefusal("binding protocol version")\n\t}\n',
        kind="narrowing",
        note="Admits exactly protocol 2.0.0 past the semver arm. Equivalent to the shipped code (no major-1 arm exists), so SURVIVED is expected and is the finding, not the mutant.",
    ),
    Mutant(
        name="RV2-M4-native-ref-513",
        path=f"{PKG}/identity.go",
        find='\tif _, ok := environ.CheckStringBounds(members["native_reference"], 1, 512); !ok {\n',
        replace='\tif _, ok := environ.CheckStringBounds(members["native_reference"], 1, 513); !ok {\n',
        kind="narrowing (bound widened by one)",
        note="Admits exactly the 513-character native reference.",
    ),
    Mutant(
        name="RV2-M5-supersedes-any-string",
        path=f"{PKG}/identity.go",
        find='\t\tif _, err := scalar.ParseDigest(supersedes); err != nil {\n\t\t\treturn empty, protocolRefusal("binding supersedes")\n\t\t}\n',
        replace='\t\tif _, err := scalar.ParseDigest(supersedes); err != nil && supersedes != "not-a-digest" {\n\t\t\treturn empty, protocolRefusal("binding supersedes")\n\t\t}\n',
        kind="narrowing (member check dropped for one member)",
        note="Admits exactly one non-digest supersedes_binding_id value.",
    ),
    Mutant(
        name="RV2-M6-resolve-manifest-impl-arm",
        path=f"{PKG}/resolve.go",
        find="\tif manifest.TerminalBackendID != tuple.BackendID || manifest.ImplementationVersion != tuple.ImplementationVersion {\n",
        replace="\tif manifest.TerminalBackendID != tuple.BackendID {\n",
        kind="narrowing (member check dropped)",
        note="Drops the manifest implementation-version arm of the event binding; the landed admission may or may not catch the same member.",
    ),
    Mutant(
        name="RV2-M7-recover-absent-ignores-identity",
        path=f"{PKG}/recover.go",
        find="\t\tif report.IdentityMatch && report.State == terminalbackend.StateAbsent {\n",
        replace="\t\tif report.State == terminalbackend.StateAbsent {\n",
        kind="narrowing (member check dropped)",
        note="Claims absence from an absent report that names another session (identity match dropped on the unbound arm).",
    ),
    Mutant(
        name="RV2-M8-recover-unavailable-as-child",
        path=f"{PKG}/recover.go",
        find="\tcase terminalbackend.StateCreating, terminalbackend.StateUnavailable:\n",
        replace="\tcase terminalbackend.StateCreating:\n",
        kind="narrowing (one state admitted)",
        note="Reports a backend-unavailable observation as the ONE child with replay_same.",
    ),
    Mutant(
        name="RV2-M9-recover-generation-bound-skipped",
        path=f"{PKG}/recover.go",
        find="\tif _, err := terminalbackend.GenerationDigest(request.Generation); err != nil {\n\t\treturn empty, err\n\t}\n",
        replace="\tif _, err := terminalbackend.GenerationDigest(request.Generation); err != nil && len(request.Generation) != 257 {\n\t\treturn empty, err\n\t}\n",
        kind="narrowing (pre-read revalidation skipped for one member)",
        note="Skips the generation bound exactly for a 257-character generation before the status read.",
    ),
    Mutant(
        name="RV2-M10-attach-lookup-session-unbound",
        path=f"{PKG}/attach.go",
        find='\tif receipt.SessionID != sessionID {\n\t\treturn empty, false, errors.New("attach receipt names another session")\n\t}\n',
        replace='\tif receipt.SessionID != sessionID && sessionID != "0198f4c8-8e50-7f66-8f70-1234567890ab" {\n\t\treturn empty, false, errors.New("attach receipt names another session")\n\t}\n',
        kind="narrowing (one member admitted)",
        note="Lookup admits exactly one foreign session over a recorded receipt.",
    ),
    Mutant(
        name="RV2-M11-evidence-unsorted-first-pair",
        path=f"{PKG}/resolve.go",
        find="\t\tif index > 0 && id <= previous {\n",
        replace="\t\tif index > 1 && id <= previous {\n",
        kind="narrowing (unsorted array admitted at one position)",
        note="Admits an evidence_ids array whose only inversion is between the first two members (the shipped N-evidence-unsorted twin, replanted by the reviewer).",
    ),
    Mutant(
        name="RV2-K-known-kill",
        path=f"{PKG}/identity.go",
        find='\tif _, err := scalar.ParseUUIDv7(value); err != nil {\n\t\treturn &terminalbackend.Error{Code: terminalbackend.CodeProtocolError, Detail: "terminal instance identity"}\n\t}\n',
        replace='\tif _, err := scalar.ParseUUIDv7(value); err != nil && value != "12345" {\n\t\treturn &terminalbackend.Error{Code: terminalbackend.CodeProtocolError, Detail: "terminal instance identity"}\n\t}\n',
        kind="control (known kill, shipped N-identity-pid)",
        note="Harness control: must be KILLED.",
    ),
    Mutant(
        name="RV2-C-comment",
        path=f"{PKG}/doc.go",
        find="// Package termbind writes versioned terminal binding events, recovers\n",
        replace="// Package termbind writes versioned terminal binding events (reviewer control), recovers\n",
        kind="control (harmless)",
        note="Harness control: comment-only edit must SURVIVE.",
    ),
]


def main(argv):
    copy = Path(argv[0] if argv else "cand-m").resolve()
    pass_no = argv[1] if len(argv) > 1 else "1"
    logdir = Path(__file__).resolve().parent / "logs" / f"rv2-mutants-pass{pass_no}"
    logdir.mkdir(parents=True, exist_ok=True)
    failures = 0
    for mutant in MUTANTS:
        target = copy / mutant.path
        original = target.read_text()
        found = original.count(mutant.find)
        if found != 1:
            print(f"ERROR: {mutant.name}: anchors={found}, want 1", flush=True)
            failures += 1
            continue
        with tempfile.TemporaryDirectory() as staging:
            backup = Path(staging) / "backup"
            shutil.copy2(target, backup)
            try:
                target.write_text(original.replace(mutant.find, mutant.replace))
                run = subprocess.run(
                    ["go", "test", f"./{PKG}/", "-count=1"],
                    cwd=copy, capture_output=True, text=True, timeout=600,
                )
            finally:
                shutil.copy2(backup, target)
        output = (run.stdout + run.stderr).strip()
        (logdir / f"{mutant.name}.log").write_text(
            f"# {mutant.name} [{mutant.kind}] exit {run.returncode}\n# {mutant.note}\n# --- find ---\n{mutant.find}# --- replace ---\n{mutant.replace}# --- raw ---\n{output}\n")
        if "build failed" in output or output.startswith("# ") or "\n# " in output:
            verdict = "ERROR(build broke)"
        elif run.returncode == 0:
            verdict = "SURVIVED"
        elif "--- FAIL" in output or "FAIL:" in output:
            verdict = "KILLED"
        else:
            verdict = f"ERROR(exit {run.returncode}, no kill line)"
        killers = sorted({line.split()[2] for line in output.splitlines() if line.startswith("--- FAIL: ")})
        print(f"{mutant.name}: {verdict} [exit {run.returncode}] kind={mutant.kind} killers={','.join(killers) if killers else '-'} :: {mutant.note}", flush=True)
        if verdict.startswith("ERROR"):
            failures += 1
    after = subprocess.run(["go", "test", f"./{PKG}/", "-count=1"], cwd=copy, capture_output=True, text=True)
    print(f"post-run pristine suite exit {after.returncode}", flush=True)
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
