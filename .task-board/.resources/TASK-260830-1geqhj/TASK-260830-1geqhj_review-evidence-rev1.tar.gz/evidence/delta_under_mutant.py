import shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import review_mutants as rm
REPO = rm.REPO
for name, pattern in [("RM1-observe-error-ignored", "TestReviewDeltaRM1"), ("RM2-steps-3-4-swapped", "TestReviewDeltaRM2"), ("RM4-idempotency-dropped-in-restore", "TestReviewDeltaRM4")]:
    mutant = next(m for m in rm.MUTANTS if m.name == name)
    target = REPO / mutant.path
    original = target.read_text()
    assert original.count(mutant.find) == 1
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(rm.apply(mutant, original))
            run = subprocess.run(["go", "test", "./internal/axpane/", "-run", pattern, "-count=1", "-v"], cwd=REPO, capture_output=True, text=True, timeout=600)
        finally:
            shutil.copy2(backup, target)
    lines = [l for l in (run.stdout + run.stderr).splitlines() if "witness" in l or l.startswith("--- ") or l.startswith("ok") or l.startswith("FAIL")]
    print(f"=== under {name} (exit {run.returncode}) ===")
    print("\n".join(lines))
