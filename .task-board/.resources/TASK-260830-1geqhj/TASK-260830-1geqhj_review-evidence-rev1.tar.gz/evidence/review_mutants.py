#!/usr/bin/env python3
"""Reviewer narrowing mutants for CR-TASK-260830-1geqhj-1 (isolated copy only).

Each row: M (patch one production file in the isolated copy), R (run the
WHOLE behavioral suite of internal/axpane minus the reviewer probes),
V (KILLED iff a --- FAIL line appears with a non-zero exit; SURVIVED iff
exit 0; ERROR otherwise). Raw logs per plant are written next to this
script. Files are restored from backup after every row.
"""
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE / "cand"
PACKAGE = "internal/axpane"
LOGS = HERE / "logs" / "mutants"
LOGS.mkdir(parents=True, exist_ok=True)


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    expect: str
    note: str


MATERIALIZATION_BLOCK = (
    "\tif input.MaterializationRequired && (!input.JournalOK || input.Journal.Phase != matjournal.PhaseCommitted) {\n"
    "\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID,\n"
    "\t\t\terrMaterializationNotValid(input.Journal.Phase, input.JournalOK))\n"
    "\t}\n"
)

MUTANTS = [
    Mutant(
        name="RM1-observe-error-ignored",
        path=f"{PACKAGE}/run.go",
        find=(
            "\t\tobserved, err := ObserveOwnership(stores.Repo, request.SessionID, request.Observe)\n"
            "\t\tif err != nil {\n"
            "\t\t\treturn empty, err\n"
            "\t\t}\n"
        ),
        replace=(
            "\t\tobserved, err := ObserveOwnership(stores.Repo, request.SessionID, request.Observe)\n"
            "\t\tif err != nil {\n"
            "\t\t\tobserved = fencing.Observation{SessionID: request.SessionID}\n"
            "\t\t}\n"
        ),
        expect="KILLED",
        note="One gate result ignored: an ObserveOwnership failure is swallowed into an empty observation (parks instead of propagating).",
    ),
    Mutant(
        name="RM2-steps-3-4-swapped",
        path=f"{PACKAGE}/decide.go",
        find=MATERIALIZATION_BLOCK + "\tif input.CheckpointRequired {\n",
        replace="\tif input.CheckpointRequired {\n",
        expect="KILLED",
        note="After-restore order swapped at steps 3/4: materialization validity evaluated before ownership (a remote owner with a stale materialization parks restore_policy instead of offering attach/takeover). Second edit inserts the block before authorize.",
    ),
    Mutant(
        name="RM3-park-reason-collapsed",
        path=f"{PACKAGE}/decide.go",
        find="\tif reason != fencing.ParkRemoteOwner {\n\t\treturn parked(reason, winning, cause)\n\t}\n",
        replace="\tif reason != fencing.ParkRemoteOwner {\n\t\treturn parked(fencing.ParkRestorePolicy, winning, cause)\n\t}\n",
        expect="KILLED",
        note="Park reason collapsed to one value for every non-remote park.",
    ),
    Mutant(
        name="RM4-idempotency-dropped-in-restore",
        path=f"{PACKAGE}/decide.go",
        find="\tif input.ExistingBinding != nil && input.ExistingBinding.OperationID != input.BootstrapOperationID {\n",
        replace="\tif input.ExistingBinding != nil && input.ExistingBinding.OperationID != input.BootstrapOperationID && input.Mode == ModeLaunch {\n",
        expect="KILLED",
        note="Bootstrap-window mismatch check dropped for restore mode (the mirror of the producer's N-idempotency).",
    ),
    Mutant(
        name="RM5-attested-server-narrowed",
        path=f"{PACKAGE}/decide.go",
        find="\tif input.Realm.AttestedServer {\n",
        replace='\tif input.Realm.AttestedServer || input.Realm.ServerGeneration == "generation-alpha" {\n',
        expect="KILLED",
        note="The authorizing realm arm (not mutated by the producer) admits one generation string without an attested server.",
    ),
    Mutant(
        name="RM6-offer-emission-dropped",
        path=f"{PACKAGE}/run.go",
        find="\tcase ActionParked, ActionAttachRemote, ActionTakeoverOffer:\n\t\tif !observation.HasWinner {\n",
        replace="\tcase ActionParked, ActionAttachRemote:\n\t\tif !observation.HasWinner {\n",
        expect="KILLED",
        note="Takeover offers no longer author the parked event.",
    ),
    Mutant(
        name="RM7-successor-sequence",
        path=f"{PACKAGE}/run.go",
        find="\t\tif tail.LeaseID == observation.Winner.LeaseID {\n\t\t\tsequence = tail.LeaseSequence + 1\n\t\t}\n",
        replace="\t\tif tail.LeaseID == observation.Winner.LeaseID || true {\n\t\t\tsequence = tail.LeaseSequence + 1\n\t\t}\n",
        expect="KILLED",
        note="Successor-lease events no longer restart at sequence 1.",
    ),
    Mutant(
        name="RC-detail-string",
        path=f"{PACKAGE}/decide.go",
        find='\t\tDetail:   "launch under the winning lease",\n',
        replace='\t\tDetail:   "launch under the winning lease.",\n',
        expect="SURVIVED",
        note="Harmless control: a detail-string edit no test asserts must survive.",
    ),
]


def apply(mutant: Mutant, original: str) -> str:
    patched = original.replace(mutant.find, mutant.replace)
    if mutant.name == "RM2-steps-3-4-swapped":
        anchor = "\ttoken, err := authorize(input)\n"
        assert patched.count(anchor) == 1
        patched = patched.replace(anchor, MATERIALIZATION_BLOCK + anchor)
    return patched


def run_mutant(mutant: Mutant) -> str:
    target = REPO / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    if found != 1:
        return f"ERROR: {mutant.name}: patch anchors {found}, want 1"
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(apply(mutant, original))
            run = subprocess.run(
                ["go", "test", f"./{PACKAGE}/", "-skip", "TestReviewProbe", "-count=1"],
                cwd=REPO, capture_output=True, text=True, timeout=600,
            )
        finally:
            shutil.copy2(backup, target)
    output = (run.stdout + run.stderr).strip()
    (LOGS / f"{mutant.name}.log").write_text(f"exit={run.returncode}\n{output}\n")
    if "build failed" in output or "\n# " in output or output.startswith("# "):
        return f"ERROR: {mutant.name}: build broke under the patch [exit {run.returncode}]"
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant.name}: exit {run.returncode} with no kill line"
    killers = sorted({line.strip().split()[2] for line in output.splitlines() if line.strip().startswith("--- FAIL")})
    mark = "ok" if verdict == mutant.expect else "MISMATCH"
    return f"{mark}: {mutant.name}: {verdict} (want {mutant.expect}) [exit {run.returncode}] killers={killers} :: {mutant.note}"


def main(argv):
    selected = [m for m in MUTANTS if not argv or m.name in argv]
    failures = 0
    for mutant in selected:
        try:
            line = run_mutant(mutant)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {mutant.name}: killer timed out"
        print(line, flush=True)
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
