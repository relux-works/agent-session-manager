package axpane

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

// Delta witnesses for the surviving reviewer mutants: each logs the
// outcome so the same test run under the mutant shows the behavioral
// change the suite never observes.
func TestReviewDeltaRM2RemoteOwnerStaleMaterialization(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	input.MaterializationRequired = true
	input.JournalOK = true
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseStaging}
	decision := Decide(input)
	t.Logf("RM2 witness: remote interactive owner + staging materialization -> action=%s reason=%s", decision.Action, decision.ParkReason)
}

func TestReviewDeltaRM4RestoreChangedOperation(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.ExistingBinding = &Binding{SessionID: fixtureSession, OperationID: fixtureOtherOp, TerminalInstanceID: fixtureInstance, BindingDigest: seedDigest(0xB1), CreatedAt: fixtureCreatedAt}
	decision := Decide(input)
	t.Logf("RM4 witness: restore mode + changed bootstrap operation -> action=%s class=%s", decision.Action, decision.Class)
}

func TestReviewDeltaRM1ObserveFailure(t *testing.T) {
	world := buildRunWorld(t)
	root := t.TempDir()
	repository, err := sessrepo.Open(root)
	if err != nil {
		t.Fatal(err)
	}
	var record map[string]any
	if err := json.Unmarshal([]byte(sessionRecordFixture), &record); err != nil {
		t.Fatal(err)
	}
	reference, err := repository.CreateSession(identifyObject(t, record, "record_id"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := repository.CreateLease(fixtureSession, sessrepo.CreateLeaseInput{LeaseID: fixtureLeaseA, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt}); err != nil {
		t.Fatal(err)
	}
	appendChainEvent(t, repository, "session.created", 1, fixtureLeaseA, 1, reference.RecordID, map[string]any{
		"session_record_id": reference.RecordID, "bootstrap_operation_id": fixtureBootstrap, "first_checkpoint_operation_id": fixtureOtherOp,
	})
	world.repo = repository
	matches, _ := filepath.Glob(filepath.Join(root, "sessions", fixtureSession, "leases", "*"))
	t.Logf("lease blobs: %d", len(matches))
	for _, match := range matches {
		if err := os.WriteFile(match, []byte("{torn"), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	outcome, err := Run(world.stores(), runRequest(t, world))
	t.Logf("RM1 witness: Run with a torn lease blob -> action=%q emitted=%v err=%v", outcome.Decision.Action, outcome.Emitted, err)
}
