package axpane

// Reviewer probes for CR-TASK-260830-1geqhj-1 (rev 1). These live only
// in the isolated review copy; each probe asserts the SPEC-expected
// behavior so a RED probe is a finding, not a harness fault.

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/sessstate"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

type probeEvent struct {
	EventType     string `json:"event_type"`
	LeaseID       string `json:"lease_id"`
	LeaseEpoch    uint64 `json:"lease_epoch"`
	LeaseSequence uint64 `json:"lease_sequence"`
	CreatedBy     string `json:"created_by_host_id"`
	Payload       struct {
		Reason  string `json:"reason"`
		Winning string `json:"winning_lease_id"`
	} `json:"payload"`
}

func remoteTakeover(t *testing.T, world *runWorld) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        fixtureLeaseB,
			HolderHostID:   fixtureRemoteHost,
			IssuedByHostID: fixtureRemoteHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: seedDigest(0xC9),
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

// PROBE 1 — §5.2 "The winning owner MUST serialize state-changing
// events": a local wrapper that parks because a REMOTE host owns the
// session must not author into the chain under the remote host's
// lease. Expected: the parked event is not authored under lease B
// (held by fixtureRemoteHost) by fixtureLocalHost.
func TestReviewProbeRemoteOwnerParkedEventLease(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	outcome, err := Run(world.stores(), runRequest(t, world))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("action=%s emitted=%v", outcome.Decision.Action, outcome.Emitted)
	if !outcome.Emitted {
		t.Skip("no event authored")
	}
	stored, err := world.repo.GetEvent(fixtureSession, outcome.Event.EventID)
	if err != nil {
		t.Fatal(err)
	}
	var decoded probeEvent
	if err := json.Unmarshal(stored, &decoded); err != nil {
		t.Fatal(err)
	}
	t.Logf("parked event: type=%s lease_id=%s epoch=%d seq=%d created_by=%s payload=%+v",
		decoded.EventType, decoded.LeaseID, decoded.LeaseEpoch, decoded.LeaseSequence, decoded.CreatedBy, decoded.Payload)
	if decoded.LeaseID == fixtureLeaseB && decoded.CreatedBy == fixtureLocalHost {
		t.Errorf("FINDING: local host %s authored %s under lease %s epoch %d held by REMOTE host %s (owner-serialization violated)",
			fixtureLocalHost, decoded.EventType, decoded.LeaseID, decoded.LeaseEpoch, fixtureRemoteHost)
	}
	// The remote owner's own first event under lease B at sequence 1
	// now collides: two different events at one sequence under the
	// winning lease (§5.2 invalid_state_transition).
	head := outcome.Event.EventID
	_ = head
	events, err := world.repo.ListEvents(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	priorHead := events[len(events)-2].EventID
	value := map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureSession, "session_id": fixtureSession, "event_type": "session.idle", "created_by_host_id": fixtureRemoteHost,
		"lease_epoch": 2, "lease_id": fixtureLeaseB, "lease_sequence": 1, "predecessors": []string{priorHead},
		"created_at": fixtureCreatedAt, "payload": map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true}, "extensions": map[string]any{},
	}
	raw := identifyObject(t, value, "event_id")
	_, appendErr := world.repo.AppendEvent(fixtureSession, raw)
	t.Logf("owner's own (B, seq 1) event after the wrapper's parked event: err=%v", appendErr)
	if appendErr == nil {
		t.Logf("owner event appended (no local collision detected)")
	}
}

// PROBE 1b — unverified ownership with a remote holder parks
// restore_policy; the wrapper still authors under the remote lease.
func TestReviewProbeUnverifiedRemoteHolderParkedEventLease(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	request := runRequest(t, world)
	request.Observe.Verified = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("action=%s reason=%s emitted=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted)
	if !outcome.Emitted {
		return
	}
	stored, err := world.repo.GetEvent(fixtureSession, outcome.Event.EventID)
	if err != nil {
		t.Fatal(err)
	}
	var decoded probeEvent
	_ = json.Unmarshal(stored, &decoded)
	t.Logf("parked event: lease_id=%s epoch=%d seq=%d created_by=%s reason=%s", decoded.LeaseID, decoded.LeaseEpoch, decoded.LeaseSequence, decoded.CreatedBy, decoded.Payload.Reason)
	if decoded.LeaseID == fixtureLeaseB && decoded.CreatedBy == fixtureLocalHost {
		t.Errorf("FINDING: unverified local host authored session.parked under remote-held lease %s", decoded.LeaseID)
	}
}

// PROBE 2 — the event the wrapper authors must be one the landed state
// engine folds. Fixture chain state is creating; §5.7 has no
// creating -> parked edge.
func TestReviewProbeParkedEventFoldsInStateEngine(t *testing.T) {
	world := buildRunWorld(t)
	request := runRequest(t, world)
	request.Observe.Verified = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	if !outcome.Emitted {
		t.Fatal("expected an emitted parked event")
	}
	recordJSON, err := world.repo.GetRecord(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	record, err := sessstate.DecodeRecord(recordJSON)
	if err != nil {
		t.Fatal(err)
	}
	summaries, err := world.repo.ListEvents(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	var events []sessstate.Event
	for _, summary := range summaries {
		raw, err := world.repo.GetEvent(fixtureSession, summary.EventID)
		if err != nil {
			t.Fatal(err)
		}
		event, err := sessstate.DecodeEvent(raw)
		if err != nil {
			t.Fatal(err)
		}
		events = append(events, event)
	}
	projection, err := sessstate.Reduce(sessstate.Input{Record: record, Events: events, LocalHostID: fixtureLocalHost})
	t.Logf("sessstate.Reduce over chain with wrapper-authored session.parked: state=%q err=%v", projection.State, err)
	if err != nil {
		t.Errorf("FINDING: landed state engine refuses the chain the wrapper produced: %v", err)
	}
}

// PROBE 3 — §4.2 "A cached sentinel or prior managername observation
// MUST NOT authorize resume"; "Evidence MUST bind the exact tmux
// server generation, provider build, and macOS version". A background
// caller presenting only a boolean AttestedServer=true, with no
// credential_capable_execution_realm evidence in the admitted set and
// a smoke record that binds no server generation, must not launch.
func TestReviewProbeAttestedServerBooleanAuthorizes(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Realm.AttestedServer = true
	input.Smoke.Required = true
	input.Smoke.Record = smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple())
	target := smokeTarget()
	target.TmuxServerGeneration = "generation-STALE-pre-reboot"
	input.Smoke.Target = target
	decision := Decide(input)
	t.Logf("background+AttestedServer(bool)+smoke(no generation binding): action=%s class=%s admitted=%v", decision.Action, decision.Class, decision.Admitted.Capabilities)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: background caller launched on an unbound boolean; admitted set lacks credential_capable_execution_realm (%v)", decision.Admitted.Capabilities)
	}
	input.Smoke.Required = false
	decision = Decide(input)
	t.Logf("background+AttestedServer(bool), smoke not required: action=%s", decision.Action)
	if decision.Action == ActionLaunch && !decision.Admitted.Has("credential_capable_execution_realm") {
		t.Errorf("FINDING: background caller launched with no realm evidence at all")
	}
}

// PROBE 4 — §4.C create row: `headless_creation` when non-interactive.
// A backend whose probe says headless_creation=false (durable_disconnect
// still confers create) must not launch a non-interactive pane.
func TestReviewProbeNonInteractiveWithoutHeadlessCreation(t *testing.T) {
	world := buildRunWorld(t)
	universe := world.universe
	// flip the probed headless_creation claim to false and drop its evidence
	claims := universe.probe["capability_claims"].([]any)
	for _, raw := range claims {
		claim := raw.(map[string]any)
		if claim["capability"] == "headless_creation" {
			claim["value"] = false
		}
	}
	kept := universe.evidence[:0]
	for _, object := range universe.evidence {
		if object["capability"].(string) != "headless_creation" {
			kept = append(kept, object)
		}
	}
	universe.evidence = kept
	var ids []any
	for _, object := range universe.evidence {
		ids = append(ids, object["evidence_id"])
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i].(string) < ids[j].(string) })
	universe.probe["evidence_ids"] = ids
	universe.probe["probe_id"] = omitSelfIdentity(t, universe.probe, "probe_id")
	request := runRequest(t, world)
	request.Interactive = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("non-interactive create, headless_creation=false: action=%s class=%s admitted=%v", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Admitted.Capabilities)
	if outcome.Decision.Action == ActionLaunch {
		t.Errorf("FINDING: non-interactive launch admitted without headless_creation (admitted=%v)", outcome.Decision.Admitted.Capabilities)
	}
}

// PROBE 5 — §4.1 "changing the operation for a session still in the
// bootstrap window is idempotency_mismatch". Outside the window (first
// checkpoint published, successor lease with a checkpoint) a new
// bootstrap operation for a restore is legitimate.
func TestReviewProbeSecondBootstrapOperationAfterWindow(t *testing.T) {
	world := buildRunWorld(t)
	first, err := Run(world.stores(), runRequest(t, world))
	if err != nil || first.Decision.Action != ActionLaunch {
		t.Fatalf("first launch = (%v, %v)", first.Decision.Action, err)
	}
	// close the bootstrap window: successor lease (local holder) with the captured checkpoint
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	successor := "cccccccc-dddd-4eee-8fff-000000000001"
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        successor,
			HolderHostID:   fixtureLocalHost,
			IssuedByHostID: fixtureLocalHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: world.ckptID,
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: successor}
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = true
	request.CheckpointID = world.ckptID
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore with a new bootstrap operation after the window closed: action=%s class=%s detail=%s", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Detail)
	if outcome.Decision.Action == ActionRefused && outcome.Decision.Class == terminalbackend.CodeIdempotencyMismatch {
		t.Errorf("FINDING: post-window restore with a new bootstrap_operation_id refused idempotency_mismatch (store has no bootstrap-window notion; one binding per session forever)")
	}
}

// PROBE 6 — §13.11 step 5 "validate the newest checkpoint": the
// checkpoint admitted for resume must be the winning lease's
// checkpoint, not any caller-named valid checkpoint.
func TestReviewProbeCheckpointNotLeaseCheckpoint(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.Checkpoint = seedDigest(0xC9)
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("restore with caller checkpoint %s while lease checkpoint is %s: action=%s", deps.ckptID[:20], seedDigest(0xC9)[:20], decision.Action)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: resume admitted a checkpoint that is not the winning lease's checkpoint")
	}
}

// PROBE 6b — a valid checkpoint of ANOTHER session, named by the caller,
// is admitted for this session (no session_id binding in admitCheckpoint).
func TestReviewProbeForeignCheckpointAdmitted(t *testing.T) {
	deps := buildDecideDeps(t, true)
	// build a foreign session with its own chain and checkpoint
	repository, err := sessrepo.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	var record map[string]any
	if err := json.Unmarshal([]byte(sessionRecordFixture), &record); err != nil {
		t.Fatal(err)
	}
	record["subject_id"] = fixtureForeign
	record["session_id"] = fixtureForeign
	reference, err := repository.CreateSession(identifyObject(t, record, "record_id"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := repository.CreateLease(fixtureForeign, sessrepo.CreateLeaseInput{LeaseID: fixtureLeaseA, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt}); err != nil {
		t.Fatal(err)
	}
	value := map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureForeign, "session_id": fixtureForeign, "event_type": "session.created", "created_by_host_id": fixtureLocalHost,
		"lease_epoch": 1, "lease_id": fixtureLeaseA, "lease_sequence": 1, "predecessors": []string{reference.RecordID},
		"created_at": fixtureCreatedAt, "payload": map[string]any{"session_record_id": reference.RecordID, "bootstrap_operation_id": fixtureBootstrap, "first_checkpoint_operation_id": fixtureOtherOp}, "extensions": map[string]any{},
	}
	created, err := repository.AppendEvent(fixtureForeign, identifyObject(t, value, "event_id"))
	if err != nil {
		t.Fatal(err)
	}
	store, err := sessckptOpen(t)
	if err != nil {
		t.Fatal(err)
	}
	foreignID, foreignDoc := checkpointFixtureFor(t, repository, store, fixtureForeign, []string{created.EventID})
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.CheckpointRequired = true
	input.CheckpointDoc = foreignDoc
	input.CheckpointID = foreignID
	decision := Decide(input)
	t.Logf("restore of %s with a checkpoint of foreign session %s: action=%s", fixtureSession[len(fixtureSession)-4:], fixtureForeign[len(fixtureForeign)-4:], decision.Action)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: a checkpoint belonging to another session was admitted for resume")
	}
}

// PROBE 7 — materialization one generation behind: the required journal
// is committed but its source checkpoint is not the lease checkpoint.
func TestReviewProbeMaterializationOneGenerationBehind(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.MaterializationRequired = true
	input.JournalOK = true
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
	input.Observation.Winner.Checkpoint = deps.ckptID
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("committed journal sourced from %s while lease checkpoint is %s: action=%s", seedDigest(0xD2)[:20], deps.ckptID[:20], decision.Action)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: a materialization one checkpoint generation behind the lease was treated as valid")
	}
}

// PROBE 8 — §13.10 "derive the exact effective profile/source from
// [the checkpoint's] event-head closure": a resume from checkpoint C1
// (closure = [created]) with a later head-only profile.changed E2 must
// carry the closure pair (standard/null), not the head pair.
func TestReviewProbeResumeProfileUsesHeadNotClosure(t *testing.T) {
	deps := buildDecideDeps(t, true)
	changed := appendChainEvent(t, deps.repo, "profile.changed", 1, fixtureLeaseA, 2, deps.createdID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("resume from C1 (closure=[created]) with head-only E2=%s: action=%s profile=%+v", changed[:20], decision.Action, decision.Profile)
	if decision.Action == ActionLaunch && decision.Profile.HasSource && decision.Profile.Source == changed {
		t.Errorf("FINDING: resume carried the session-head pair (yolo/E2) instead of the checkpoint closure pair (standard/null)")
	}
}

// PROBE 9 — Emit under a losing lease: the wrapper's Emit (and
// sessrepo.AppendEvent behind it) accept an append under lease A epoch 1
// after lease B epoch 2 has won, as long as the chain tail is still at A.
func TestReviewProbeEmitUnderLosingLease(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	decision := Decision{Action: ActionParked, ParkReason: fencing.ParkStaleOwner, WinningLeaseID: fixtureLeaseB}
	_, _, err := EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 2,
		Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("EmitParked under losing lease A epoch 1 (winner B epoch 2, tail at A): err=%v", err)
	if err == nil {
		t.Errorf("FINDING: append under a losing lease was accepted (no winning-lease gate on Emit; sessrepo compares to the tail only)")
	}
	// after the owner appends under B, a losing append is refused by the landed owner
	value := map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureSession, "session_id": fixtureSession, "event_type": "session.idle", "created_by_host_id": fixtureRemoteHost,
		"lease_epoch": 2, "lease_id": fixtureLeaseB, "lease_sequence": 1, "predecessors": []string{world.headID},
		"created_at": fixtureCreatedAt, "payload": map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true}, "extensions": map[string]any{},
	}
	events, _ := world.repo.ListEvents(fixtureSession)
	value["predecessors"] = []string{events[len(events)-1].EventID}
	ownerRef, ownerErr := world.repo.AppendEvent(fixtureSession, identifyObject(t, value, "event_id"))
	t.Logf("owner append under B after the losing parked event: ref=%+v err=%v", ownerRef, ownerErr)
	_, _, err = EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{ownerRef.EventID}, CreatedAt: fixtureCreatedAt,
	})
	t.Logf("EmitParked under losing lease A after the tail moved to B: err=%v (expected ErrStaleLease refusal)", err)
	if err == nil {
		t.Errorf("landed owner accepted a stale-lease append")
	}
}

// PROBE 10 — remote interactive owner with a lapsed local grant:
// report which arm wins (fencing checks expiry before ownership
// direction, so this refuses instead of offering).
func TestReviewProbeRemoteInteractiveOwnerExpiredGrant(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Observation = lapsedObservation(fixtureNow())
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision := Decide(input)
	t.Logf("remote interactive owner + expired grant: action=%s class=%s reason=%s cause=%v", decision.Action, decision.Class, decision.ParkReason, decision.Cause)
}

// PROBE 11 — two conflicting arms both satisfiable: changed bootstrap
// operation AND invalid config; unverified AND remote owner.
func TestReviewProbeConflictingArms(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.ConfigErr = errFixtureConfig
	input.ExistingBinding = &Binding{SessionID: fixtureSession, OperationID: fixtureOtherOp, TerminalInstanceID: fixtureInstance, BindingDigest: seedDigest(0xB1), CreatedAt: fixtureCreatedAt}
	decision := Decide(input)
	t.Logf("invalid config + changed operation: action=%s class=%s", decision.Action, decision.Class)
	input = validInput(t, deps)
	input.Observation.Verified = false
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision = Decide(input)
	t.Logf("unverified + remote interactive owner: action=%s reason=%s winning=%s", decision.Action, decision.ParkReason, decision.WinningLeaseID)
}

// PROBE 12 — a capability row outside the closed §4.D set is refused
// by the landed parser before the wrapper decides.
func TestReviewProbeCapabilityOutsideClosedSet(t *testing.T) {
	deps := buildDecideDeps(t, true)
	claims := deps.universe.probe["capability_claims"].([]any)
	bogus := claimMap("headless_creation", "probed", true)
	bogus["capability"] = "teleport"
	deps.universe.probe["capability_claims"] = append(claims, bogus)
	deps.universe.probe["probe_id"] = omitSelfIdentity(t, deps.universe.probe, "probe_id")
	decision := Decide(validInput(t, deps))
	t.Logf("probe with capability 'teleport': action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action != ActionRefused {
		t.Errorf("capability outside the closed set was not refused")
	}
}

// PROBE 13 — descriptor whose backend generation differs from the host
// binding is refused (positive check of the §7.A composition).
func TestReviewProbeDescriptorGenerationDiffers(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.HostBinding.Generation = "generation-other"
	decision := Decide(input)
	t.Logf("descriptor generation != host binding generation: action=%s class=%s", decision.Action, decision.Class)
	if decision.Action != ActionRefused || decision.Class != terminalbackend.CodeStaleGeneration {
		t.Errorf("descriptor generation drift not refused stale_generation")
	}
}

// PROBE 14 — non-interactive remote owner: §4.2 step 5 says parked in
// all other cases; the wrapper labels it takeover_offer.
func TestReviewProbeNonInteractiveRemoteOwnerLabel(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = false
	decision := Decide(input)
	t.Logf("non-interactive remote owner in restore mode: action=%s reason=%s", decision.Action, decision.ParkReason)
	if decision.Action != ActionParked {
		t.Errorf("FINDING (label): non-interactive remote owner yields %s, spec step 5 = parked", decision.Action)
	}
}

// PROBE C1 — real SIGKILL BEFORE the no-replace commit (AfterStage):
// restart must prove absence, and the retry must install exactly one
// binding (never a second child).
func TestReviewProbeCrashBeforeCommit(t *testing.T) {
	if os.Getenv("AX_REVIEW_CRASH_STAGE") == "1" {
		store, err := Open(os.Getenv("AX_REVIEW_CRASH_STORE"))
		if err != nil {
			t.Fatal(err)
		}
		store.WithHooks(&Hooks{AfterStage: func(path string) error {
			proc, _ := os.FindProcess(os.Getpid())
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}})
		_, _, _ = store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
		t.Fatal("returned past SIGKILL")
		return
	}
	storeDir := t.TempDir()
	if _, err := Open(storeDir); err != nil {
		t.Fatal(err)
	}
	child := execSelf(t, "^TestReviewProbeCrashBeforeCommit$", "AX_REVIEW_CRASH_STAGE=1", "AX_REVIEW_CRASH_STORE="+storeDir)
	t.Logf("child exit: %v", child)
	store, err := Open(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	_, found, err := store.Status(fixtureSession)
	t.Logf("Status after kill-before-commit: found=%v err=%v", found, err)
	if err != nil || found {
		t.Errorf("expected proven absence after a pre-commit kill, got found=%v err=%v", found, err)
	}
	entries, _ := os.ReadDir(filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession))
	var names []string
	for _, entry := range entries {
		names = append(names, entry.Name())
	}
	t.Logf("session dir after kill-before-commit: %v", names)
	bound, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
	if err != nil || reattached {
		t.Errorf("retry after pre-commit kill = (%+v, reattached=%v, err=%v), want a fresh install", bound, reattached, err)
	}
	entries, _ = os.ReadDir(filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession))
	names = nil
	for _, entry := range entries {
		names = append(names, entry.Name())
	}
	t.Logf("session dir after retry: %v", names)
	count := 0
	for _, name := range names {
		if name == "binding.json" {
			count++
		}
	}
	if count != 1 {
		t.Errorf("binding count = %d, want exactly one", count)
	}
}

// PROBE C2 — identical retries reattach without a second write: inode
// and mtime census over the binding file.
func TestReviewProbeIdenticalRetryInodeCensus(t *testing.T) {
	store, err := Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	first, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
	if err != nil || reattached {
		t.Fatalf("first bind = (%+v, %v, %v)", first, reattached, err)
	}
	path := store.bindingPath(fixtureSession)
	before, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	beforeIno := before.Sys().(*syscall.Stat_t).Ino
	beforeBytes, _ := os.ReadFile(path)
	for round := 0; round < 3; round++ {
		other := bindCandidate()
		other.TerminalInstanceID = "0198f4c9-3333-7ccc-8ccc-1234567890ab" // different child facts on retry
		other.BindingDigest = BindingDigest(other)
		again, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, other)
		if err != nil || !reattached || again != first {
			t.Fatalf("retry %d = (%+v, %v, %v), want reattach to %+v", round, again, reattached, err, first)
		}
	}
	after, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	afterIno := after.Sys().(*syscall.Stat_t).Ino
	afterBytes, _ := os.ReadFile(path)
	t.Logf("inode before=%d after=%d mtime before=%v after=%v bytes-equal=%v", beforeIno, afterIno, before.ModTime(), after.ModTime(), string(beforeBytes) == string(afterBytes))
	if beforeIno != afterIno || !before.ModTime().Equal(after.ModTime()) || string(beforeBytes) != string(afterBytes) {
		t.Errorf("identical retry rewrote the binding")
	}
	entries, _ := os.ReadDir(filepath.Dir(path))
	if len(entries) != 1 {
		t.Errorf("session dir has %d entries, want 1 (no staging garbage)", len(entries))
	}
}

func sessckptOpen(t *testing.T) (*sessckpt.Store, error) {
	t.Helper()
	return sessckpt.Open(t.TempDir())
}

func checkpointFixtureFor(t *testing.T, repository *sessrepo.Repository, store *sessckpt.Store, sessionID string, heads []string) (string, []byte) {
	t.Helper()
	reference, raw, err := store.Capture(repository, sessckpt.Inputs{
		OperationID:         fixtureBootstrap,
		SessionID:           sessionID,
		SessionKind:         sessckpt.SessionKindDirect,
		LeaseEpoch:          1,
		LeaseID:             fixtureLeaseA,
		CreatorHostID:       fixtureLocalHost,
		WorkspaceManifestID: seedDigest(0xE1),
		ProviderManifestID:  seedDigest(0xE2),
		Boundary: sessckpt.SafeBoundary{
			ProviderID:          "codex",
			ProviderVersion:     "0.147.0",
			Evidence:            sessckpt.EvidenceAcceptedTest,
			InputBlocked:        true,
			ForegroundIdle:      true,
			BackgroundIdle:      true,
			OpenProcesses:       0,
			OpenDatabaseHandles: 0,
		},
		EventHeads: heads,
		CreatedAt:  fixtureCreatedAt,
		Extensions: map[string]string{},
	})
	if err != nil {
		t.Fatalf("Capture() error = %v", err)
	}
	return reference.CheckpointID, raw
}

// execSelf re-executes the test binary for one test with extra env and
// returns the run error (a SIGKILL exit is expected by the callers).
func execSelf(t *testing.T, pattern string, env ...string) error {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run="+pattern, "-test.count=1")
	child.Env = append(os.Environ(), env...)
	err := child.Run()
	var exitErr *exec.ExitError
	if !errors.As(err, &exitErr) {
		t.Fatalf("child run = %v, want a signal-kill exit", err)
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok || !status.Signaled() || status.Signal() != syscall.SIGKILL {
		t.Fatalf("child status = %v, want killed by SIGKILL", exitErr)
	}
	return err
}

// PROBE 15 — §2.4 "Losing-lease or ambiguous events MUST NOT change
// [the effective profile]": a profile.changed authored under the
// superseded lease A (epoch 1) after a local successor lease A2 (epoch 2)
// won is accepted by the chain (tail still at A) and then drives the
// launch profile.
func TestReviewProbeLosingLeaseProfileEventDrivesLaunch(t *testing.T) {
	world := buildRunWorld(t)
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	successor := "cccccccc-dddd-4eee-8fff-000000000002"
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{LeaseID: successor, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt},
		Reason:           "graceful_takeover",
		CheckpointID:     world.ckptID,
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
	// losing-lease profile change (lease A epoch 1) after A2 epoch 2 won
	changed := appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: successor}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("launch under A2 epoch 2 with a losing-lease (A, epoch 1) profile.changed %s in the chain: action=%s profile=%+v mapping=%q",
		changed[:20], outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Source == changed {
		t.Errorf("FINDING: a profile.changed authored under a losing lease became the launch profile source (yolo mapping %q)", outcome.Decision.Mapping)
	}
}
