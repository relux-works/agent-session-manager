#!/usr/bin/env python3
"""Reviewer mutants for CR-TASK-260830-1geqhj-2 (rev 2).

Each row mutates one production file in the isolated candidate copy,
runs the WHOLE committed axpane suite as the killer (not a scoped
-run mask), records the raw go test output under logs/mutants/, and
restores the file. KILLED iff the suite fails with a kill line;
SURVIVED iff exit 0; ERROR otherwise (build break, bad anchor).

Usage: PYTHONDONTWRITEBYTECODE=1 python3 review2_mutants.py <repo> <logdir> [names...]
"""

import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

PACKAGE = "internal/axpane"


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    expect: str
    note: str


MUTANTS = [
    Mutant(
        name="RV1-realm-binding-result-ignored",
        path=f"{PACKAGE}/decide.go",
        find="\tif err := checkRealmBinding(input, evidence); err != nil {\n\t\treturn realmFailure(input, err)\n\t}\n",
        replace="\t_ = checkRealmBinding(input, evidence)\n",
        expect="KILLED",
        note="Gate result ignored: the realm cross-bind runs but its verdict is dropped.",
    ),
    Mutant(
        name="RV2-steps-3-4-swapped",
        path=f"{PACKAGE}/decide.go",
        find=(
            "\ttoken, err := authorize(input)\n"
            "\tif err != nil {\n"
            "\t\tif fencing.IsParked(err) {\n"
            "\t\t\treason, winning, _ := fencing.ParkDetails(err)\n"
            "\t\t\treturn decideParked(input, admitted, reason, winning, err)\n"
            "\t\t}\n"
            "\t\treturn refused(fencingClass(err), \"fencing refused the wrapper\", err)\n"
            "\t}\n"
            "\n"
            "\tif input.MaterializationRequired {\n"
            "\t\tif err := checkMaterialization(input); err != nil {\n"
            "\t\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID, err)\n"
            "\t\t}\n"
            "\t}\n"
        ),
        replace=(
            "\tif input.MaterializationRequired {\n"
            "\t\tif err := checkMaterialization(input); err != nil {\n"
            "\t\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID, err)\n"
            "\t\t}\n"
            "\t}\n"
            "\ttoken, err := authorize(input)\n"
            "\tif err != nil {\n"
            "\t\tif fencing.IsParked(err) {\n"
            "\t\t\treason, winning, _ := fencing.ParkDetails(err)\n"
            "\t\t\treturn decideParked(input, admitted, reason, winning, err)\n"
            "\t\t}\n"
            "\t\treturn refused(fencingClass(err), \"fencing refused the wrapper\", err)\n"
            "\t}\n"
            "\n"
        ),
        expect="KILLED",
        note="After-restore order: materialization arm moved before the fencing authorize arm (rev1 RM2).",
    ),
    Mutant(
        name="RV3-park-reason-collapsed",
        path=f"{PACKAGE}/decide.go",
        find="func parked(reason fencing.ParkReason, winningLeaseID string, cause error) Decision {\n\treturn Decision{\n",
        replace="func parked(reason fencing.ParkReason, winningLeaseID string, cause error) Decision {\n\treason = fencing.ParkRestorePolicy\n\treturn Decision{\n",
        expect="KILLED",
        note="Park reason vocabulary collapsed to restore_policy for every park.",
    ),
    Mutant(
        name="RV4-window-check-dropped",
        path=f"{PACKAGE}/decide.go",
        find="\treturn observation.HasWinner && observation.Winner.HasCheckpoint\n",
        replace="\treturn observation.HasWinner\n",
        expect="KILLED",
        note="Bootstrap window predicate narrowed: closes on any winner, ignoring the checkpoint (in-window changed op admitted).",
    ),
    Mutant(
        name="RV5-observe-error-swallowed",
        path=f"{PACKAGE}/run.go",
        find="\t\tobserved, err := ObserveOwnership(stores.Repo, request.SessionID, request.Observe)\n\t\tif err != nil {\n\t\t\treturn empty, err\n\t\t}\n\t\tobservation = observed\n",
        replace="\t\tobserved, err := ObserveOwnership(stores.Repo, request.SessionID, request.Observe)\n\t\tif err == nil {\n\t\t\tobservation = observed\n\t\t}\n",
        expect="KILLED",
        note="rev1 RM1: a torn lease read becomes an empty observation (parks instead of erroring).",
    ),
    Mutant(
        name="RV6-idempotency-dropped-in-restore",
        path=f"{PACKAGE}/decide.go",
        find="\tif input.ExistingBinding != nil && input.ExistingBinding.OperationID != input.BootstrapOperationID && !bootstrapWindowClosed(input.Observation) {\n",
        replace="\tif input.Mode == ModeLaunch && input.ExistingBinding != nil && input.ExistingBinding.OperationID != input.BootstrapOperationID && !bootstrapWindowClosed(input.Observation) {\n",
        expect="KILLED",
        note="rev1 RM4: the in-window idempotency arm is skipped in restore mode.",
    ),
    Mutant(
        name="RV7-emit-losing-epoch-admitted",
        path=f"{PACKAGE}/events.go",
        find="\tif _, err := fencing.AuthorizeMutation(params.Presented, params.Observation); err != nil {\n",
        replace="\tif _, err := fencing.AuthorizeMutation(params.Presented, params.Observation); err != nil && !(params.Observation.HasWinner && params.Presented.Epoch < params.Observation.Winner.Epoch) {\n",
        expect="KILLED",
        note="Mutation gate narrowed: a presented epoch below the winner's is admitted to append (losing-lease arm).",
    ),
    Mutant(
        name="RV8-remote-host-check-dropped-in-run",
        path=f"{PACKAGE}/run.go",
        find="\t\tif observation.Winner.HolderHostID != observation.LocalHostID {\n",
        replace="\t\tif false && observation.Winner.HolderHostID != observation.LocalHostID {\n",
        expect="KILLED",
        note="Run's remote-holder pre-check dropped: does the composed mutation gate still stop a remote-lease append?",
    ),
    Mutant(
        name="RV9-checkpoint-lease-binding-only-with-winner-ckpt-in-restore",
        path=f"{PACKAGE}/decide.go",
        find="\tif input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint {\n\t\tif want != input.Observation.Winner.Checkpoint {\n",
        replace="\tif input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint && input.Mode == ModeLaunch {\n\t\tif want != input.Observation.Winner.Checkpoint {\n",
        expect="KILLED",
        note="Checkpoint lease binding narrowed to launch mode only (restore admits non-lease checkpoints).",
    ),
    Mutant(
        name="RV10-fencing-refusal-classifier-always-true",
        path=f"{PACKAGE}/run.go",
        find="\treturn errors.Is(err, fencing.ErrInvalidArguments) ||\n",
        replace="\treturn true || errors.Is(err, fencing.ErrInvalidArguments) ||\n",
        expect="KILLED",
        note="Emission error classifier collapsed: repository failures during emission read as fencing refusals.",
    ),
    Mutant(
        name="RV11-supersede-without-window-in-run",
        path=f"{PACKAGE}/run.go",
        find="\t\tif input.ExistingBinding != nil && input.ExistingBinding.OperationID != request.BootstrapOperationID {\n\t\t\tbound, err := paneStore.Supersede(",
        replace="\t\tif input.ExistingBinding != nil && input.ExistingBinding.OperationID != request.BootstrapOperationID && input.Mode == ModeRestore {\n\t\t\tbound, err := paneStore.Supersede(",
        expect="KILLED",
        note="Run's supersede path narrowed to restore mode: a post-window launch-mode changed op falls to Bind (idempotency_mismatch from the store).",
    ),
    Mutant(
        name="RC-control-comment",
        path=f"{PACKAGE}/decide.go",
        find="// Decide is the pure wrapper core: configuration, session, bootstrap\n",
        replace="// Decide is the pure wrapper core (reviewer control): configuration, session, bootstrap\n",
        expect="SURVIVED",
        note="Harmless control: comment-only edit must survive.",
    ),
]


def run_mutant(repo: Path, logdir: Path, mutant: Mutant) -> str:
    target = repo / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    if found != 1:
        return f"ERROR: {mutant.name}: patch anchors {found}, want 1"
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            run = subprocess.run(
                ["go", "test", f"./{PACKAGE}/", "-count=1"],
                cwd=repo, capture_output=True, text=True, timeout=900,
            )
        finally:
            shutil.copy2(backup, target)
    output = (run.stdout + run.stderr).strip()
    (logdir / f"{mutant.name}.log").write_text(f"exit {run.returncode}\n{output}\n")
    if "build failed" in output or "\n# " in output or output.startswith("# "):
        return f"ERROR: {mutant.name}: build broke under the patch [exit {run.returncode}]"
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant.name}: exit {run.returncode} with no kill line"
    killers = sorted({line.split()[2] for line in output.splitlines() if line.startswith("--- FAIL")})
    mark = "ok" if verdict == mutant.expect else "MISMATCH"
    return f"{mark}: {mutant.name}: {verdict} (want {mutant.expect}) killers={killers} :: {mutant.note} [exit {run.returncode}]"


def main(argv: list[str]) -> int:
    repo = Path(argv[0]).resolve()
    logdir = Path(argv[1]).resolve()
    logdir.mkdir(parents=True, exist_ok=True)
    names = argv[2:]
    selected = [m for m in MUTANTS if not names or m.name in names]
    failures = 0
    for mutant in selected:
        try:
            line = run_mutant(repo, logdir, mutant)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {mutant.name}: killer timed out"
        print(line, flush=True)
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
