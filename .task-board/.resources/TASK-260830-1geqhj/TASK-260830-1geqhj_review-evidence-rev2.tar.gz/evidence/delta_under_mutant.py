#!/usr/bin/env python3
"""Apply one reviewer mutant, run the named probe(s), restore. Prints raw output."""
import shutil, subprocess, sys, tempfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from review2_mutants import MUTANTS
repo = Path(sys.argv[1]).resolve(); name = sys.argv[2]; pattern = sys.argv[3]
mutant = next(m for m in MUTANTS if m.name == name)
target = repo / mutant.path
original = target.read_text()
assert original.count(mutant.find) == 1
with tempfile.TemporaryDirectory() as staging:
    backup = Path(staging) / "backup"; shutil.copy2(target, backup)
    try:
        target.write_text(original.replace(mutant.find, mutant.replace))
        run = subprocess.run(["go", "test", "./internal/axpane/", "-count=1", "-run", pattern, "-v"], cwd=repo, capture_output=True, text=True, timeout=600)
    finally:
        shutil.copy2(backup, target)
print(f"=== {name} :: -run {pattern} :: exit {run.returncode}")
for line in (run.stdout + run.stderr).splitlines():
    if line.startswith("=== RUN") or line.startswith("=== PAUSE") or line.startswith("=== CONT"):
        continue
    print(line)
