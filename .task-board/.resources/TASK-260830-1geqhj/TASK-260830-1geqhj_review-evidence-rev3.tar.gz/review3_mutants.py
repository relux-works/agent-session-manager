#!/usr/bin/env python3
"""Reviewer mutants for CR-TASK-260830-1geqhj-3 (rev 3).

Each row mutates one production file in the isolated candidate copy,
runs the WHOLE committed axpane suite as the killer (not a scoped
-run mask), records the raw go test output under <logdir>/, and
restores the file. KILLED iff the suite fails with a kill line;
SURVIVED iff exit 0; ERROR otherwise (build break, bad anchor).

Usage: PYTHONDONTWRITEBYTECODE=1 python3 review3_mutants.py <repo> <logdir> [names...]
"""

import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

PACKAGE = "internal/axpane"


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    expect: str
    note: str


MUTANTS = [
    Mutant(
        name="RV7-emit-losing-epoch-admitted",
        path=f"{PACKAGE}/events.go",
        find="\tif _, err := fencing.AuthorizeMutation(params.Presented, params.Observation); err != nil {\n",
        replace="\tif _, err := fencing.AuthorizeMutation(params.Presented, params.Observation); err != nil && !(params.Observation.HasWinner && params.Presented.Epoch < params.Observation.Winner.Epoch) {\n",
        expect="KILLED",
        note="P3-1 re-run: mutation gate narrowed so a presented epoch below the winner's appends (survived twice in rev2).",
    ),
    Mutant(
        name="RV11-supersede-restore-only-in-run",
        path=f"{PACKAGE}/run.go",
        find="\t\tif input.SessionBound {\n\t\t\tbound, err := paneStore.Supersede(",
        replace="\t\tif input.SessionBound && input.Mode == ModeRestore {\n\t\t\tbound, err := paneStore.Supersede(",
        expect="KILLED",
        note="P3-2 re-run: Run's post-window pair install narrowed to restore mode (launch-mode create-from-stopped falls to Bind).",
    ),
    Mutant(
        name="RV3-1-agreement-result-ignored",
        path=f"{PACKAGE}/decide.go",
        find="\tif !leaseCheckpointAgrees(input) {\n\t\treturn nil, errCheckpointLeaseDisagree()\n\t}\n",
        replace="\t_ = leaseCheckpointAgrees(input)\n",
        expect="KILLED",
        note="Gate result ignored: the lease/fold agreement runs on the checkpoint arm but its verdict is dropped.",
    ),
    Mutant(
        name="RV3-2-steps-3-4-swapped",
        path=f"{PACKAGE}/decide.go",
        find=(
            "\ttoken, err := authorize(input)\n"
            "\tif err != nil {\n"
            "\t\tif fencing.IsParked(err) {\n"
            "\t\t\treason, winning, _ := fencing.ParkDetails(err)\n"
            "\t\t\treturn decideParked(input, admitted, reason, winning, err)\n"
            "\t\t}\n"
            "\t\treturn refused(fencingClass(err), \"fencing refused the wrapper\", err)\n"
            "\t}\n"
            "\n"
            "\tif input.MaterializationRequired {\n"
            "\t\tif err := checkMaterialization(input); err != nil {\n"
            "\t\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID, err)\n"
            "\t\t}\n"
            "\t}\n"
        ),
        replace=(
            "\tif input.MaterializationRequired {\n"
            "\t\tif err := checkMaterialization(input); err != nil {\n"
            "\t\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID, err)\n"
            "\t\t}\n"
            "\t}\n"
            "\ttoken, err := authorize(input)\n"
            "\tif err != nil {\n"
            "\t\tif fencing.IsParked(err) {\n"
            "\t\t\treason, winning, _ := fencing.ParkDetails(err)\n"
            "\t\t\treturn decideParked(input, admitted, reason, winning, err)\n"
            "\t\t}\n"
            "\t\treturn refused(fencingClass(err), \"fencing refused the wrapper\", err)\n"
            "\t}\n"
            "\n"
        ),
        expect="KILLED",
        note="After-restore order: materialization arm moved before the fencing authorize arm (steps 3/4 swapped).",
    ),
    Mutant(
        name="RV3-3-park-reason-collapsed",
        path=f"{PACKAGE}/decide.go",
        find="func parked(reason fencing.ParkReason, winningLeaseID string, cause error) Decision {\n\treturn Decision{\n",
        replace="func parked(reason fencing.ParkReason, winningLeaseID string, cause error) Decision {\n\treason = fencing.ParkRestorePolicy\n\treturn Decision{\n",
        expect="KILLED",
        note="Park reason vocabulary collapsed to restore_policy for every park.",
    ),
    Mutant(
        name="RV3-4-window-check-dropped",
        path=f"{PACKAGE}/decide.go",
        find="\treturn input.HasNewestCheckpoint\n}\n",
        replace="\treturn true\n}\n",
        expect="KILLED",
        note="Bootstrap window predicate dropped: every session reads as post-window (delete-class, requested by the brief).",
    ),
    Mutant(
        name="RV3-4b-window-closes-on-lease-checkpoint",
        path=f"{PACKAGE}/decide.go",
        find="\treturn input.HasNewestCheckpoint\n}\n",
        replace="\treturn input.HasNewestCheckpoint || (input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint)\n}\n",
        expect="KILLED",
        note="Widening: the window also closes on the LEASE record's checkpoint while the fold names none (the rev2 keying regrown as an OR).",
    ),
    Mutant(
        name="RV3-5-realm-foreground-conditional-dropped",
        path=f"{PACKAGE}/decide.go",
        find="\tif input.Realm.Caller != CallerBackground && !input.Smoke.Required {\n\t\treturn nil\n\t}\n\tif !admitted.Has(credentialRealmCapability) {\n",
        replace="\tif input.Realm.Caller != CallerBackground {\n\t\treturn nil\n\t}\n\tif !admitted.Has(credentialRealmCapability) {\n",
        expect="KILLED",
        note="P3-4: the credential conditional narrowed back to background callers only.",
    ),
    Mutant(
        name="RV3-6-dead-realm-mapping-dropped",
        path=f"{PACKAGE}/decide.go",
        find="\t\tif realmErr := deadRealmRefusal(input, evidence, err); realmErr != nil {\n\t\t\treturn terminalbackend.Admitted{}, nil, realmErr\n\t\t}\n",
        replace="\t\t_ = deadRealmRefusal(input, evidence, err)\n",
        expect="KILLED",
        note="P3-6: the typed dead-realm refusal mapping result ignored (backend class surfaces).",
    ),
    Mutant(
        name="RV3-7-ckpt-store-guard-restore-only",
        path=f"{PACKAGE}/run.go",
        find="\tif known && observation.HasWinner && observation.Winner.HasCheckpoint && stores.Ckpt == nil {\n",
        replace="\tif known && observation.HasWinner && observation.Winner.HasCheckpoint && stores.Ckpt == nil && request.Mode == ModeRestore {\n",
        expect="KILLED",
        note="P2-2: the unknown-store guard narrowed to restore mode (launch mode falls back to the head).",
    ),
    Mutant(
        name="RV3-8-supersede-replace-over",
        path=f"{PACKAGE}/binding.go",
        find="\tif err := os.Link(stagedPath, target); err != nil {\n\t\tif errors.Is(err, os.ErrExist) {\n\t\t\t// A concurrent wrapper recorded this pair\n",
        replace="\tif err := os.Rename(stagedPath, target); err != nil {\n\t\tif errors.Is(err, os.ErrExist) {\n\t\t\t// A concurrent wrapper recorded this pair\n",
        expect="KILLED",
        note="P2-1: the pair-receipt commit becomes a replace-over rename (no-replace guard lost).",
    ),
    Mutant(
        name="RV3-9-lookup-operation-prefix",
        path=f"{PACKAGE}/binding.go",
        find="\tif binding.OperationID != operationID {\n\t\treturn empty, false, errors.New(\"bootstrap pair receipt names another operation\")\n\t}\n",
        replace="\tif binding.OperationID[:len(binding.OperationID)-1] != operationID[:len(operationID)-1] {\n\t\treturn empty, false, errors.New(\"bootstrap pair receipt names another operation\")\n\t}\n",
        expect="KILLED",
        note="Lookup's receipt-to-operation check narrowed to a prefix compare (same-prefix operations admitted).",
    ),
    Mutant(
        name="RV3-10-sessionbound-ignores-receipts",
        path=f"{PACKAGE}/binding.go",
        find="\tmatches, err := filepath.Glob(filepath.Join(store.receiptsDir(sessionID), \"*.json\"))\n\tif err != nil {\n\t\treturn false, err\n\t}\n\treturn len(matches) > 0, nil\n",
        replace="\treturn false, nil\n",
        expect="SURVIVED",
        note="Equivalence probe: receipts-only sessions cannot arise (the anchor is always installed first); a survival marks the scan unmeasured, not defective.",
    ),
    Mutant(
        name="RV3-11-fold-error-laundered-as-absence",
        path=f"{PACKAGE}/run.go",
        find="\t\thas, newest, err := LoadNewestCheckpoint(stores.Repo, request.SessionID)\n\t\tif err != nil {\n\t\t\treturn empty, err\n\t\t}\n",
        replace="\t\thas, newest, err := LoadNewestCheckpoint(stores.Repo, request.SessionID)\n\t\tif err != nil {\n\t\t\thas, newest = false, \"\"\n\t\t}\n",
        expect="KILLED",
        note="Absence vs failure: an unfolderable chain through Run becomes 'no checkpoint' instead of an error.",
    ),
    Mutant(
        name="RV3-12-profile-closure-from-required-not-winner",
        path=f"{PACKAGE}/run.go",
        find="\t\tif observation.HasWinner && observation.Winner.HasCheckpoint && stores.Ckpt != nil {\n\t\t\tdoc := input.CheckpointDoc\n",
        replace="\t\tif false && observation.HasWinner && observation.Winner.HasCheckpoint && stores.Ckpt != nil {\n\t\t\tdoc := input.CheckpointDoc\n",
        expect="KILLED",
        note="Run's winner-checkpoint closure branch disabled (falls to the required checkpoint's closure or the head): measures how the closure source is pinned.",
    ),
    Mutant(
        name="RC3-control-comment",
        path=f"{PACKAGE}/decide.go",
        find="// Decide is the pure wrapper core: configuration, session, bootstrap\n",
        replace="// Decide is the pure wrapper core (reviewer control): configuration, session, bootstrap\n",
        expect="SURVIVED",
        note="Harmless control: comment-only edit must survive.",
    ),
]


def run_mutant(repo: Path, logdir: Path, mutant: Mutant) -> str:
    target = repo / mutant.path
    original = target.read_text()
    found = original.count(mutant.find)
    if found != 1:
        return f"ERROR: {mutant.name}: patch anchors {found}, want 1"
    with tempfile.TemporaryDirectory() as staging:
        backup = Path(staging) / "backup"
        shutil.copy2(target, backup)
        try:
            target.write_text(original.replace(mutant.find, mutant.replace))
            run = subprocess.run(
                ["go", "test", f"./{PACKAGE}/", "-count=1"],
                cwd=repo, capture_output=True, text=True, timeout=900,
            )
        finally:
            shutil.copy2(backup, target)
    output = (run.stdout + run.stderr).strip()
    (logdir / f"{mutant.name}.log").write_text(f"exit {run.returncode}\n{output}\n")
    if "build failed" in output or "\n# " in output or output.startswith("# "):
        return f"ERROR: {mutant.name}: build broke under the patch [exit {run.returncode}]"
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant.name}: exit {run.returncode} with no kill line"
    killers = sorted({line.split()[2] for line in output.splitlines() if line.startswith("--- FAIL")})
    mark = "ok" if verdict == mutant.expect else "MISMATCH"
    return f"{mark}: {mutant.name}: {verdict} (want {mutant.expect}) killers={killers} :: {mutant.note} [exit {run.returncode}]"


def main(argv: list[str]) -> int:
    repo = Path(argv[0]).resolve()
    logdir = Path(argv[1]).resolve()
    logdir.mkdir(parents=True, exist_ok=True)
    names = argv[2:]
    selected = [m for m in MUTANTS if not names or m.name in names]
    failures = 0
    for mutant in selected:
        try:
            line = run_mutant(repo, logdir, mutant)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {mutant.name}: killer timed out"
        print(line, flush=True)
        if not line.startswith("ok:"):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
