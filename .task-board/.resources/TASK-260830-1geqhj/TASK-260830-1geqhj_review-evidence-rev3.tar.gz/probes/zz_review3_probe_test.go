package axpane

// Reviewer probes for CR-TASK-260830-1geqhj-3 (rev 3). These live only
// in the isolated review copy. Each probe asserts the SPEC-expected
// behavior so a RED probe is a finding, not a harness fault; probes
// that only characterize a boundary log it and say so.
//
// R3 = rework verification of the rev2 findings (P1-1, P2-1, P2-2,
// P3-x), each re-driven through a production entry with the rev3
// fixtures (chain-published checkpoints); N3 = new plants one step
// away from the reworked vectors.

import (
	"context"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/provhost"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

const (
	r3Successor = "cccccccc-dddd-4eee-8fff-000000000001"
	r3Op3       = "0198f4c8-7d40-7e55-8e6f-1234567890ad"
	r3Op4       = "0198f4c8-7d40-7e55-8e6f-1234567890ae"
	r3Inst2     = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
	r3Inst3     = "0198f4c9-3333-7ccc-8ccc-1234567890ab"
	r3Inst4     = "0198f4c9-4444-7ddd-8ddd-1234567890ab"
)

// r3Capture captures a checkpoint of the fixture session under an
// arbitrary owning (epoch, lease) tuple over the given heads.
func r3Capture(t *testing.T, repository *sessrepo.Repository, store *sessckpt.Store, operation string, epoch uint64, leaseID string, heads []string) (string, []byte) {
	t.Helper()
	reference, raw, err := store.Capture(repository, sessckpt.Inputs{
		OperationID:         operation,
		SessionID:           fixtureSession,
		SessionKind:         sessckpt.SessionKindDirect,
		LeaseEpoch:          epoch,
		LeaseID:             leaseID,
		CreatorHostID:       fixtureLocalHost,
		WorkspaceManifestID: seedDigest(0xE1),
		ProviderManifestID:  seedDigest(0xE2),
		Boundary: sessckpt.SafeBoundary{
			ProviderID: "codex", ProviderVersion: "0.147.0", Evidence: sessckpt.EvidenceAcceptedTest,
			InputBlocked: true, ForegroundIdle: true, BackgroundIdle: true, OpenProcesses: 0, OpenDatabaseHandles: 0,
		},
		EventHeads: heads,
		CreatedAt:  fixtureCreatedAt,
		Extensions: map[string]string{},
	})
	if err != nil {
		t.Fatalf("Capture(epoch %d) error = %v", epoch, err)
	}
	return reference.CheckpointID, raw
}

// r3PostTakeoverWorld builds the ordinary post-takeover story: the
// epoch-1 owner stops with checkpoint C0 (published on the chain), a
// LOCAL successor lease (2,S) is minted with handoff base C0, the
// successor owner resumes from C0, goes idle, and stops with a NEW
// checkpoint C1 published under (2,S). The lease record's checkpoint
// stays C0 forever (immutable record); the chain fold's newest is C1.
func r3PostTakeoverWorld(t *testing.T) (*runWorld, string, string) {
	t.Helper()
	world := buildRunWorld(t)
	c0 := world.ckptID
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, c0)
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, c0)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, r3Successor, 1, world.headID, map[string]any{
		"checkpoint_id": c0, "execution_profile": "standard", "profile_source_event_id": nil,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, r3Successor, 2, resumedID, map[string]any{
		"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true,
	})
	c1, _ := r3Capture(t, world.repo, world.ckpt, r3Op3, 2, r3Successor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, r3Successor, 3, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c1, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	return world, c0, c1
}

func r3RestoreRequest(t *testing.T, world *runWorld, op, instance string, epoch uint64, lease, ckpt string) Request {
	t.Helper()
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = op
	request.InstanceID = instance
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: epoch, LeaseID: lease}
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = true
	request.CheckpointID = ckpt
	return request
}

// ---------------------------------------------------------------
// P1-1 rework verification (window / admission / journal keyed on
// the chain fold, epoch-1 owner)
// ---------------------------------------------------------------

// R3-1: the ordinary same-host story restores with a new bootstrap
// operation through Run, and an identical retry of that operation
// reattaches to the one child.
func TestR3EpochOneOwnerRestoreLaunchesAndRetryReattaches(t *testing.T) {
	world := buildRunWorld(t)
	first, err := Run(world.stores(), runRequest(t, world))
	if err != nil || first.Decision.Action != ActionLaunch {
		t.Fatalf("first launch = (%v, %v)", first.Decision.Action, err)
	}
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("lease: epoch=%d HasCheckpoint=%v | fold: has=%v newest=%s", observation.Winner.Epoch, observation.Winner.HasCheckpoint, has, newest[:20])
	if observation.Winner.HasCheckpoint || !has || newest != world.ckptID {
		t.Fatalf("fixture does not reproduce the epoch-1 null-lease-checkpoint state")
	}
	world.mat = journalSourced(t, world.ckptID)
	restore := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 1, fixtureLeaseA, world.ckptID)
	outcome, err := Run(world.stores(), restore)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("epoch-1 owner post-checkpoint restore, new op: action=%s class=%q cause=%v", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionLaunch || outcome.Binding == nil || outcome.Binding.OperationID != fixtureOtherOp {
		t.Fatalf("FINDING: epoch-1 owner restore with a new operation did not launch with the op2 receipt: %+v", outcome.Binding)
	}
	retry := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst4, 1, fixtureLeaseA, world.ckptID)
	again, err := Run(world.stores(), retry)
	if err != nil {
		t.Fatalf("Run() retry error = %v", err)
	}
	t.Logf("identical retry of op2 with different child facts: action=%s instance=%s", again.Decision.Action, again.Binding.TerminalInstanceID)
	if again.Decision.Action != ActionReattach || again.Binding.TerminalInstanceID != outcome.Binding.TerminalInstanceID {
		t.Fatalf("FINDING: identical retry did not reattach to the one child")
	}
}

// R3-2: with the chain newest at C, a second attested checkpoint C2
// the chain never published parks at the "not newest" arm through
// Run, and no binding installs.
func TestR3UnpublishedCheckpointParksAtNewestArm(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	c2, _ := captureUnpublished(t, world.repo, world.ckpt, r3Op3, []string{world.headID})
	world.mat = journalSourced(t, world.ckptID)
	request := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 1, fixtureLeaseA, c2)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("chain newest=C, caller C2 unpublished: action=%s reason=%s cause=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionParked || outcome.Decision.ParkReason != fencing.ParkRestorePolicy {
		t.Fatalf("FINDING: unpublished checkpoint did not park")
	}
	if outcome.Decision.Cause == nil || !strings.Contains(outcome.Decision.Cause.Error(), "not the newest published checkpoint") {
		t.Fatalf("FINDING: parked at the wrong arm: %v", outcome.Decision.Cause)
	}
	if _, found, err := world.pane.Lookup(fixtureSession, fixtureOtherOp); err != nil || found {
		t.Fatalf("binding installed for a parked restore: found=%v err=%v", found, err)
	}
}

// R3-3: a committed journal sourced from a digest no lease and no
// event names parks at the stale-source arm through Run.
func TestR3UnnamedSourceJournalParks(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	world.mat = journalSourced(t, seedDigest(0xD2))
	request := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 1, fixtureLeaseA, world.ckptID)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("journal sourced from 0xD2, chain newest=C: action=%s cause=%v", outcome.Decision.Action, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionParked || outcome.Decision.Cause == nil || !strings.Contains(outcome.Decision.Cause.Error(), "superseded checkpoint") {
		t.Fatalf("FINDING: unnamed-source journal did not park at the stale-source arm")
	}
}

// N3-1 (one step past P1-1): the ordinary POST-TAKEOVER story. The
// successor lease's checkpoint is the handoff base C0 (immutable
// lease record); the successor owner then publishes C1. A restore
// on that owner with a journal sourced from C1 and checkpoint C1 is
// the after-restore step-3 positive: winning lease + valid required
// materialization. §5.3 fixes the lease checkpoint at the handoff
// base; §5.7/§13.11 step 5 validate the NEWEST checkpoint. The spec
// expects launch.
func TestN3PostTakeoverLifecycleRestoreLaunches(t *testing.T) {
	world, c0, c1 := r3PostTakeoverWorld(t)
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil {
		t.Fatalf("LoadNewestCheckpoint() error = %v (the post-takeover chain must fold)", err)
	}
	t.Logf("winner: epoch=%d lease=%s HasCheckpoint=%v Checkpoint=%s | fold newest: has=%v %s | C0=%s C1=%s",
		observation.Winner.Epoch, observation.Winner.LeaseID[:8], observation.Winner.HasCheckpoint, observation.Winner.Checkpoint[:20], has, newest[:20], c0[:20], c1[:20])
	if observation.Winner.Epoch != 2 || observation.Winner.Checkpoint != c0 || newest != c1 {
		t.Fatalf("fixture does not reproduce the post-takeover state")
	}
	world.mat = journalSourced(t, c1)
	request := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 2, r3Successor, c1)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("post-takeover restore (journal from C1, checkpoint C1, presented (2,S)): action=%s reason=%s cause=%v",
		outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("FINDING: the successor owner cannot restore after publishing its own checkpoint: action=%s cause=%v", outcome.Decision.Action, outcome.Decision.Cause)
	}
}

// N3-1b: the same through the pure core, with the Decide input built
// exactly as Run would build it.
func TestN3PostTakeoverLifecycleDecide(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: r3Successor}
	input.Observation.Winner.Epoch = 2
	input.Observation.Winner.LeaseID = r3Successor
	input.Observation.Winner.HasCheckpoint = true
	input.Observation.Winner.Checkpoint = seedDigest(0xC0) // handoff base C0
	input.Observation.Grant.Token = sessrepo.FencingToken{Epoch: 2, LeaseID: r3Successor, HolderHostID: fixtureLocalHost}
	input.HasNewestCheckpoint = true
	input.NewestCheckpointID = deps.ckptID // C1 published by the successor
	input.MaterializationRequired = true
	input.JournalOK = true
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: deps.ckptID, MaterializationID: fixtureMat}
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("Decide post-takeover (lease base C0 != fold newest C1): action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action != ActionLaunch {
		t.Fatalf("FINDING: Decide parks the successor owner after it published a newer checkpoint: %v", decision.Cause)
	}
}

// N3-2: in the post-takeover world, a caller that names the handoff
// base C0 (stale) instead of the newest C1 parks at the newest arm.
func TestN3PostTakeoverStaleBaseParks(t *testing.T) {
	world, c0, _ := r3PostTakeoverWorld(t)
	world.mat = journalSourced(t, c0)
	request := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 2, r3Successor, c0)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("post-takeover restore naming the stale base C0: action=%s cause=%v", outcome.Decision.Action, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionParked {
		t.Fatalf("FINDING: the stale handoff base was admitted for resume")
	}
}

// N3-3: launch mode with a successor lease carrying a checkpoint the
// chain never published: the lease/fold agreement is consulted only
// on the required-materialization/checkpoint arms. This probe
// characterizes the boundary (logs it) and asserts only that no
// unpublished checkpoint is admitted as a REQUIRED checkpoint.
func TestN3LaunchModeLeaseFoldDisagreementCharacterized(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, world.ckptID)
	has, _, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = r3Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: r3Successor}
	outcome, err := Run(world.stores(), request)
	t.Logf("launch mode, successor lease carries unpublished C, fold has=%v: action=%s class=%q err=%v", has, outcome.Decision.Action, outcome.Decision.Class, err)
	if err == nil && outcome.Decision.Action == ActionLaunch {
		t.Fatalf("FINDING-CANDIDATE: launch-mode changed op with an inconsistent lease/fold pair launched with binding %+v", outcome.Binding)
	}
	required := request
	required.CheckpointRequired = true
	required.CheckpointID = world.ckptID
	outcome, err = Run(world.stores(), required)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("same with the unpublished checkpoint REQUIRED: action=%s cause=%v", outcome.Decision.Action, outcome.Decision.Cause)
	if outcome.Decision.Action == ActionLaunch {
		t.Fatalf("FINDING: an unpublished checkpoint was admitted as a required checkpoint")
	}
}

// ---------------------------------------------------------------
// P2-1 rework verification (per-pair receipts survive supersession)
// ---------------------------------------------------------------

func r3Inode(t *testing.T, path string) (uint64, time.Time) {
	t.Helper()
	info, err := os.Stat(path)
	if err != nil {
		t.Fatalf("stat %s: %v", path, err)
	}
	stat, ok := info.Sys().(*syscall.Stat_t)
	if !ok {
		t.Fatal("no inode on this platform")
	}
	return stat.Ino, info.ModTime()
}

// R3-4: post-window op2 and op3 each launch their own child; an
// identical retry of op2 (different child facts) reattaches to op2's
// own child without rewriting its receipt; Status keeps the first
// anchor; every pair replays through Lookup.
func TestR3SupersededPairIdenticalRetryReattaches(t *testing.T) {
	world := buildRunWorld(t)
	first, err := Run(world.stores(), runRequest(t, world))
	if err != nil || first.Decision.Action != ActionLaunch {
		t.Fatalf("first launch = (%v, %v)", first.Decision.Action, err)
	}
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	world.mat = journalSourced(t, world.ckptID)
	run := func(op, instance string) Outcome {
		outcome, err := Run(world.stores(), r3RestoreRequest(t, world, op, instance, 1, fixtureLeaseA, world.ckptID))
		if err != nil {
			t.Fatalf("Run(%s) error = %v", op[len(op)-2:], err)
		}
		return outcome
	}
	second := run(fixtureOtherOp, r3Inst2)
	third := run(r3Op3, r3Inst3)
	t.Logf("op2: action=%s inst=%s | op3: action=%s inst=%s", second.Decision.Action, second.Binding.TerminalInstanceID[9:13], third.Decision.Action, third.Binding.TerminalInstanceID[9:13])
	if second.Decision.Action != ActionLaunch || third.Decision.Action != ActionLaunch {
		t.Fatalf("post-window launches did not both launch")
	}
	receipt := world.pane.receiptPath(fixtureSession, fixtureOtherOp)
	inoBefore, mtimeBefore := r3Inode(t, receipt)
	retry := run(fixtureOtherOp, r3Inst4)
	inoAfter, mtimeAfter := r3Inode(t, receipt)
	t.Logf("identical retry of op2 after op3: action=%s inst=%s receipt inode %d->%d mtime-equal=%v",
		retry.Decision.Action, retry.Binding.TerminalInstanceID[9:13], inoBefore, inoAfter, mtimeBefore.Equal(mtimeAfter))
	if retry.Decision.Action != ActionReattach || retry.Binding.TerminalInstanceID != second.Binding.TerminalInstanceID {
		t.Fatalf("FINDING: identical retry of a superseded pair launched a third child")
	}
	if inoBefore != inoAfter || !mtimeBefore.Equal(mtimeAfter) {
		t.Fatalf("FINDING: identical retry rewrote the pair receipt")
	}
	anchor, found, err := world.pane.Status(fixtureSession)
	if err != nil || !found || anchor.OperationID != fixtureBootstrap {
		t.Fatalf("Status() = (%+v, %v, %v), want the first anchor", anchor, found, err)
	}
	for _, want := range []*Binding{first.Binding, second.Binding, third.Binding} {
		got, found, err := world.pane.Lookup(fixtureSession, want.OperationID)
		if err != nil || !found || got != *want {
			t.Fatalf("Lookup(%s) = (%+v, %v, %v), want %+v", want.OperationID[len(want.OperationID)-2:], got, found, err, *want)
		}
	}
	entries, _ := os.ReadDir(world.pane.receiptsDir(fixtureSession))
	names := make([]string, 0, len(entries))
	for _, entry := range entries {
		names = append(names, entry.Name())
	}
	t.Logf("receipts dir: %v", names)
	if len(entries) != 3 {
		t.Fatalf("receipts = %d, want exactly 3", len(entries))
	}
}

// R3-5: Supersede is no-replace per pair: a same-pair Supersede with
// different child facts replays the recorded receipt (same inode,
// same bytes) instead of replacing it.
func TestR3SupersedeSamePairNoReplace(t *testing.T) {
	store := openPaneStore(t)
	if _, _, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate()); err != nil {
		t.Fatal(err)
	}
	second := bindCandidate()
	second.OperationID = fixtureOtherOp
	second.TerminalInstanceID = r3Inst2
	second.BindingDigest = BindingDigest(second)
	recorded, err := store.Supersede(fixtureSession, fixtureOtherOp, second)
	if err != nil {
		t.Fatal(err)
	}
	path := store.receiptPath(fixtureSession, fixtureOtherOp)
	inoBefore, _ := r3Inode(t, path)
	bytesBefore, _ := os.ReadFile(path)
	other := second
	other.TerminalInstanceID = r3Inst3
	other.BindingDigest = BindingDigest(other)
	replayed, err := store.Supersede(fixtureSession, fixtureOtherOp, other)
	if err != nil {
		t.Fatal(err)
	}
	inoAfter, _ := r3Inode(t, path)
	bytesAfter, _ := os.ReadFile(path)
	t.Logf("same-pair Supersede with different facts: replayed inst=%s recorded inst=%s inode %d->%d bytes-equal=%v",
		replayed.TerminalInstanceID[9:13], recorded.TerminalInstanceID[9:13], inoBefore, inoAfter, string(bytesBefore) == string(bytesAfter))
	if replayed != recorded || inoBefore != inoAfter || string(bytesBefore) != string(bytesAfter) {
		t.Fatalf("FINDING: same-pair Supersede replaced the recorded receipt")
	}
}

// R3-6: real SIGKILL at both Supersede seams through the genuine
// production entry. Kill after stage: no receipt, anchor intact,
// retry installs exactly one. Kill after install: the receipt is
// complete and the retry replays it (same inode).
func TestR3SupersedeRealKillSeams(t *testing.T) {
	if os.Getenv("AX_R3_SUPERSEDE_CHILD") != "" {
		store, err := Open(os.Getenv("AX_R3_SUPERSEDE_STORE"))
		if err != nil {
			t.Fatal(err)
		}
		kill := func(string) error {
			proc, _ := os.FindProcess(os.Getpid())
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}
		hooks := &Hooks{}
		if os.Getenv("AX_R3_SUPERSEDE_CHILD") == "stage" {
			hooks.AfterStage = kill
		} else {
			hooks.AfterInstall = kill
		}
		store.WithHooks(hooks)
		second := bindCandidate()
		second.OperationID = fixtureOtherOp
		second.TerminalInstanceID = r3Inst2
		second.BindingDigest = BindingDigest(second)
		_, _ = store.Supersede(fixtureSession, fixtureOtherOp, second)
		t.Fatal("child returned past SIGKILL")
		return
	}
	for _, seam := range []string{"stage", "install"} {
		t.Run(seam, func(t *testing.T) {
			root := t.TempDir()
			store, err := Open(root)
			if err != nil {
				t.Fatal(err)
			}
			first, _, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
			defer cancel()
			child := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestR3SupersedeRealKillSeams$", "-test.count=1")
			child.Env = append(os.Environ(), "AX_R3_SUPERSEDE_CHILD="+seam, "AX_R3_SUPERSEDE_STORE="+root)
			runErr := child.Run()
			var exitErr *exec.ExitError
			if !errors.As(runErr, &exitErr) {
				t.Fatalf("child run = %v, want a signal exit", runErr)
			}
			status, _ := exitErr.Sys().(syscall.WaitStatus)
			if !status.Signaled() || status.Signal() != syscall.SIGKILL {
				t.Fatalf("child status = %v, want SIGKILL", exitErr)
			}
			reopened, err := Open(root)
			if err != nil {
				t.Fatal(err)
			}
			got, found, err := reopened.Lookup(fixtureSession, fixtureOtherOp)
			anchor, anchorFound, anchorErr := reopened.Status(fixtureSession)
			entries, _ := filepath.Glob(filepath.Join(reopened.sessionDir(fixtureSession), "*"))
			receipts, _ := filepath.Glob(filepath.Join(reopened.receiptsDir(fixtureSession), "*"))
			t.Logf("kill-after-%s: Lookup(op2)=(found %v, err %v) Status=(op %s, found %v, err %v) session=%d entries receipts=%v",
				seam, found, err, anchor.OperationID[len(anchor.OperationID)-2:], anchorFound, anchorErr, len(entries), receipts)
			if anchorErr != nil || !anchorFound || anchor != first {
				t.Fatalf("anchor torn after kill-after-%s", seam)
			}
			if seam == "stage" && (err != nil || found) {
				t.Fatalf("kill-after-stage left a pair receipt: found=%v err=%v", found, err)
			}
			if seam == "install" && (err != nil || !found || got.TerminalInstanceID != r3Inst2) {
				t.Fatalf("kill-after-install lost the committed receipt: found=%v err=%v", found, err)
			}
			second := bindCandidate()
			second.OperationID = fixtureOtherOp
			second.TerminalInstanceID = r3Inst3
			second.BindingDigest = BindingDigest(second)
			replayed, err := reopened.Supersede(fixtureSession, fixtureOtherOp, second)
			if err != nil {
				t.Fatalf("retry Supersede error = %v", err)
			}
			if seam == "install" && replayed.TerminalInstanceID != r3Inst2 {
				t.Fatalf("retry after kill-after-install installed a second child %s", replayed.TerminalInstanceID)
			}
			if seam == "stage" && replayed.TerminalInstanceID != r3Inst3 {
				t.Fatalf("retry after kill-after-stage did not install fresh: %+v", replayed)
			}
			after, _ := filepath.Glob(filepath.Join(reopened.receiptsDir(fixtureSession), "*.json"))
			if len(after) != 2 {
				t.Fatalf("receipts after retry = %v, want op1 and op2", after)
			}
		})
	}
}

// ---------------------------------------------------------------
// P2-2 rework verification (absent checkpoint store is unknown)
// ---------------------------------------------------------------

// R3-7: with a FOLDABLE chain (the rev2 probe world did not fold), a
// winner carrying a checkpoint and no checkpoint store fails the run
// with no decision; with the store it launches with the closure
// pair; an epoch-1 winner without a checkpoint still launches with
// no store on a checkpoint-free path.
func TestR3NoCkptStoreIsUnknownNotNoClosure(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, world.ckptID)
	// A head-only authoritative profile change under the successor.
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, r3Successor, 1, world.headID, map[string]any{
		"checkpoint_id": world.ckptID, "execution_profile": "standard", "profile_source_event_id": nil,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	changed := appendChainEvent(t, world.repo, "profile.changed", 2, r3Successor, 2, resumedID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	if _, _, err := LoadNewestCheckpoint(world.repo, fixtureSession); err != nil {
		t.Fatalf("chain must fold: %v", err)
	}
	request := runRequest(t, world)
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = r3Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: r3Successor}
	stores := world.stores()
	stores.Ckpt = nil
	outcome, err := Run(stores, request)
	t.Logf("no Ckpt store, winner carries checkpoint, head-only profile.changed: action=%q err=%v", outcome.Decision.Action, err)
	if err == nil || outcome.Decision.Action != "" {
		t.Fatalf("FINDING: Run without a checkpoint store decided %q (profile %+v)", outcome.Decision.Action, outcome.Decision.Profile)
	}
	control, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("control Run() error = %v", err)
	}
	t.Logf("control with the store: action=%s profile=%+v (head change %s)", control.Decision.Action, control.Decision.Profile, changed[:20])
	if control.Decision.Action != ActionLaunch || control.Decision.Profile.Profile != "standard" || control.Decision.Profile.Source == changed {
		t.Fatalf("FINDING: control launch carried the head pair instead of the closure")
	}
	// Bound: epoch-1 winner (null checkpoint) with no store on a
	// checkpoint-free launch still launches.
	fresh := buildRunWorld(t)
	freshStores := fresh.stores()
	freshStores.Ckpt = nil
	plain, err := Run(freshStores, runRequest(t, fresh))
	t.Logf("epoch-1 winner, no store, launch: action=%s err=%v", plain.Decision.Action, err)
	if err != nil || plain.Decision.Action != ActionLaunch {
		t.Fatalf("over-refusal: a checkpoint-free launch failed without a store")
	}
}

// ---------------------------------------------------------------
// P3-4 / P3-5 / P3-6 one step away
// ---------------------------------------------------------------

// N3-4: a FOREGROUND caller on a credential-requiring path whose only
// realm row expired refuses the typed capability_unavailable (the
// P3-4 conditional composed with the P3-6 mapping).
func TestN3ForegroundExpiredRealmRowTyped(t *testing.T) {
	deps := buildDecideDeps(t, true)
	addRealmEvidence(t, deps.universe, seedDigest(0xB1), "codex", "0.147.0")
	deps.universe.now = deps.universe.now.AddDate(2, 0, 0)
	input := validInput(t, deps)
	input.Realm.Caller = CallerForeground
	input.Smoke.Required = true
	input.Smoke.Record = smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple())
	input.Smoke.Target = smokeTarget()
	decision := Decide(input)
	t.Logf("foreground + smoke required + expired realm row: action=%s class=%q typed=%v", decision.Action, decision.Class, decision.RealmFailure != nil)
	if decision.Action != ActionRefused || decision.Class != "capability_unavailable" || decision.RealmFailure == nil {
		t.Fatalf("FINDING: foreground credential path with a dead realm row is not the typed refusal")
	}
}

// N3-5 (bound of P3-6): a caller that needs NO realm row (foreground,
// no credentials) with an expired realm row submitted keeps the
// backend class — the mapping must not widen to every reconcile
// failure.
func TestN3DeadRealmRowWithoutNeedKeepsBackendClass(t *testing.T) {
	deps := buildDecideDeps(t, true)
	addRealmEvidence(t, deps.universe, seedDigest(0xB1), "codex", "0.147.0")
	deps.universe.now = deps.universe.now.AddDate(2, 0, 0)
	input := validInput(t, deps)
	decision := Decide(input)
	t.Logf("foreground, no credentials, expired realm row among expired evidence: action=%s class=%q", decision.Action, decision.Class)
	if decision.Action != ActionRefused || decision.Class == "capability_unavailable" {
		t.Fatalf("FINDING: the dead-realm mapping fired for a caller that needs no realm row (or admitted): %s %q", decision.Action, decision.Class)
	}
}

// N3-6: three realm objects, only the LAST binds this host+build and
// the first two are foreign: launch (order independence past two).
func TestN3RealmThreeObjectsLastBinds(t *testing.T) {
	deps := buildDecideDeps(t, true)
	addRealmEvidence(t, deps.universe, seedDigest(0xB2), "codex", "0.147.0")
	addSecondRealmEvidence(t, deps.universe, seedDigest(0xB3), "codex", "0.147.0")
	addSecondRealmEvidence(t, deps.universe, seedDigest(0xB1), "codex", "0.147.0")
	input := validInput(t, deps)
	input.Realm.Caller = CallerBackground
	decision := Decide(input)
	t.Logf("three realm objects, last binds: action=%s class=%q cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action != ActionLaunch {
		t.Fatalf("FINDING: order dependence with three objects")
	}
}

// ---------------------------------------------------------------
// Decision-table plants (brief item 3)
// ---------------------------------------------------------------

func TestN3DecisionPlants(t *testing.T) {
	t.Run("conflicting_arms_remote_owner_and_stale_journal", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.RemoteInteractive = true
		input.MaterializationRequired = true
		input.JournalOK = true
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = deps.ckptID
		input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
		decision := Decide(input)
		t.Logf("remote interactive owner + stale journal: action=%s reason=%s", decision.Action, decision.ParkReason)
		if decision.Action != ActionAttachRemote {
			t.Fatalf("expected attach_remote (fencing precedes materialization)")
		}
	})
	t.Run("interactive_remote_owner_expired_grant", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation = lapsedObservation(fixtureNow())
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.RemoteInteractive = true
		decision := Decide(input)
		t.Logf("interactive remote owner + lapsed grant: action=%s class=%q reason=%s (landed fencing order: grant expiry precedes direction)", decision.Action, decision.Class, decision.ParkReason)
		if decision.Action == ActionLaunch || decision.HasToken {
			t.Fatalf("launched under a lapsed grant with a remote owner")
		}
	})
	t.Run("materialization_one_generation_behind", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = deps.ckptID
		input.MaterializationRequired = true
		input.JournalOK = true
		input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xC0), MaterializationID: fixtureMat}
		decision := Decide(input)
		t.Logf("journal one generation behind the newest: action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
		if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRestorePolicy {
			t.Fatalf("stale materialization admitted")
		}
	})
	t.Run("profile_source_not_authoritative", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		changed := appendChainEvent(t, deps.repo, "profile.changed", 1, fixtureLeaseA, 2, deps.createdID, map[string]any{
			"from": "standard", "to": "yolo", "confirmed": true,
		})
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = deps.ckptID
		input.CheckpointRequired = true
		input.CheckpointDoc = deps.ckptDoc
		input.CheckpointID = deps.ckptID
		decision := Decide(input)
		t.Logf("head-only profile change outside the closure: action=%s profile=%+v (change %s)", decision.Action, decision.Profile, changed[:20])
		if decision.Action != ActionLaunch || decision.Profile.Source == changed || decision.Profile.Profile != "standard" {
			t.Fatalf("non-authoritative source became the launch profile")
		}
	})
	t.Run("descriptor_generation_differs", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		var document map[string]any
		_ = json.Unmarshal(input.Descriptor, &document)
		document["backend_generation"] = "generation-omega"
		input.Descriptor, _ = json.Marshal(document)
		decision := Decide(input)
		t.Logf("descriptor generation differs: action=%s class=%q", decision.Action, decision.Class)
		if decision.Action != ActionRefused || decision.Class != terminalbackend.CodeStaleGeneration {
			t.Fatalf("descriptor generation drift admitted")
		}
	})
	t.Run("capability_outside_closed_set", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		claims := deps.universe.probe["capability_claims"].([]any)
		claims = append(claims, map[string]any{
			"capability": "teleport", "origin": "probed", "value": true, "generation_variable": true,
			"dependent_operations": []any{"create"}, "evidence_requirements": []any{"conformance_fixture", "runtime_probe"},
		})
		deps.universe.probe["capability_claims"] = claims
		deps.universe.probe["probe_id"] = omitSelfIdentity(t, deps.universe.probe, "probe_id")
		input := validInput(t, deps)
		decision := Decide(input)
		t.Logf("capability outside the closed §4.D set: action=%s class=%q", decision.Action, decision.Class)
		if decision.Action != ActionRefused {
			t.Fatalf("unregistered capability admitted")
		}
	})
}

// ---------------------------------------------------------------
// Composition bypass plants (brief item 2)
// ---------------------------------------------------------------

func TestN3CompositionBypassPlants(t *testing.T) {
	t.Run("fencing_malformed_winner_holder", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation.Winner.HolderHostID = "not-a-host"
		input.Observation.LocalHostID = "not-a-host"
		decision := Decide(input)
		t.Logf("malformed winner holder equal to local: action=%s class=%q", decision.Action, decision.Class)
		if decision.Action != ActionRefused || decision.Class != ClassInvalidArguments {
			t.Fatalf("fencing grammar bypassed")
		}
	})
	t.Run("fencing_no_grant", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation.HasGrant = false
		decision := Decide(input)
		t.Logf("no fencing grant: action=%s class=%q", decision.Action, decision.Class)
		if decision.Action != ActionRefused {
			t.Fatalf("grantless activation admitted")
		}
	})
	t.Run("journal_committed_without_source", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = deps.ckptID
		input.MaterializationRequired = true
		input.JournalOK = true
		input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, MaterializationID: fixtureMat}
		decision := Decide(input)
		t.Logf("committed journal with an empty source: action=%s cause=%v", decision.Action, decision.Cause)
		if decision.Action != ActionParked {
			t.Fatalf("sourceless journal admitted")
		}
	})
	t.Run("checkpoint_newest_named_but_doc_differs", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		idleID := appendChainEvent(t, deps.repo, "session.idle", 1, fixtureLeaseA, 2, deps.createdID, map[string]any{
			"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true,
		})
		_, c2Doc := captureUnpublished(t, deps.repo, deps.ckpt, fixtureOtherOp, []string{idleID})
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = deps.ckptID
		input.CheckpointRequired = true
		input.CheckpointDoc = c2Doc // bytes of C2 presented under C's digest
		input.CheckpointID = deps.ckptID
		decision := Decide(input)
		t.Logf("newest digest named, other checkpoint's bytes: action=%s cause=%v", decision.Action, decision.Cause)
		if decision.Action != ActionParked {
			t.Fatalf("checkpoint identity bypassed")
		}
	})
	t.Run("profile_heads_unknown", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.ProfileHeads = []string{seedDigest(0xAB)}
		decision := Decide(input)
		t.Logf("closure heads naming no chain event: action=%s class=%q cause=%v", decision.Action, decision.Class, decision.Cause)
		if decision.Action == ActionLaunch {
			t.Fatalf("unknown closure heads admitted")
		}
	})
	t.Run("identity_record_for_another_session", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		record, err := provhost.CreateIdentity(provhost.IdentityParams{
			SessionID: fixtureForeign, ProviderID: "codex", ProviderVersion: "0.147.0",
			ProviderVersionRange: "opaque-range", NativeSessionID: "native-session-other",
			IdentityKind: "session_uuid", LogicalWorkspaceID: fixtureLocalHost,
			CreatedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt,
		})
		if err != nil {
			t.Fatal(err)
		}
		input.Provider.Identity = record
		decision := Decide(input)
		t.Logf("identity record minted for ANOTHER session (same provider/version): action=%s class=%q (characterization: session binding of the identity record)", decision.Action, decision.Class)
	})
	t.Run("realm_evidence_missing_smoke_result", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		addRealmEvidence(t, deps.universe, seedDigest(0xB1), "codex", "0.147.0")
		last := deps.universe.evidence[len(deps.universe.evidence)-1]
		last["provider_auth_smoke_result"] = nil
		input := validInput(t, deps)
		input.Realm.Caller = CallerBackground
		decision := Decide(input)
		t.Logf("realm row with a null smoke result (signature now stale too): action=%s class=%q", decision.Action, decision.Class)
		if decision.Action == ActionLaunch {
			t.Fatalf("sentinel-only realm evidence authorized")
		}
	})
	t.Run("entrypoint_uppercase_session", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Entrypoint = []string{"ax", "pane", strings.ToUpper(fixtureSession)}
		decision := Decide(input)
		t.Logf("entrypoint with an uppercase session spelling: action=%s class=%q", decision.Action, decision.Class)
		if decision.Action == ActionLaunch {
			t.Fatalf("non-canonical entrypoint admitted")
		}
	})
	t.Run("window_closed_by_caller_claim_only", func(t *testing.T) {
		// The window predicate must read the fold fact Run derives,
		// never a caller claim: through Run there is no claim to
		// plant, so this asserts Run's derivation refuses a changed op
		// on a bound session whose chain never published.
		world := buildRunWorld(t)
		if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
			t.Fatal(err)
		}
		request := runRequest(t, world)
		request.BootstrapOperationID = fixtureOtherOp
		outcome, err := Run(world.stores(), request)
		if err != nil {
			t.Fatal(err)
		}
		t.Logf("in-window changed op through Run: action=%s class=%q", outcome.Decision.Action, outcome.Decision.Class)
		if outcome.Decision.Action != ActionRefused || outcome.Decision.Class != terminalbackend.CodeIdempotencyMismatch {
			t.Fatalf("in-window changed op admitted through Run")
		}
	})
}

// ---------------------------------------------------------------
// Events (brief item 5)
// ---------------------------------------------------------------

// N3-7: a park with a local winner whose chain folds, emitted through
// Run, authors under the winner; then a direct Emit under the LOSING
// presented tuple (the stale lease) refuses at the mutation gate.
func TestN3EmitUnderLosingTupleRefusesAfterRunPark(t *testing.T) {
	world := buildRunWorld(t)
	appendChainEvent(t, world.repo, "session.failed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, seedDigest(0xC9))
	request := runRequest(t, world) // presented (1,A) — losing under (2,S)
	before := eventCount(t, world.repo)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatal(err)
	}
	after := eventCount(t, world.repo)
	t.Logf("losing presented (1,A) under local winner (2,S), failed chain: action=%s reason=%s emitted=%v events %d->%d", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted, before, after)
	if outcome.Decision.Action != ActionParked || outcome.Decision.ParkReason != fencing.ParkStaleOwner {
		t.Fatalf("expected parked stale_owner")
	}
	if outcome.Emitted {
		stored, _ := world.repo.GetEvent(fixtureSession, outcome.Event.EventID)
		var decoded struct {
			LeaseEpoch uint64 `json:"lease_epoch"`
			LeaseID    string `json:"lease_id"`
		}
		_ = json.Unmarshal(stored, &decoded)
		t.Logf("authored under (%d,%s)", decoded.LeaseEpoch, decoded.LeaseID[:8])
		if decoded.LeaseEpoch != 2 || decoded.LeaseID != r3Successor {
			t.Fatalf("FINDING: parked event authored under a non-winning lease")
		}
	}
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	_, tail, err := ChainTail(world.repo, fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = EmitParked(world.repo, outcome.Decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: tail.LeaseSequence + 1,
		Predecessors: []string{tail.EventID}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation,
	})
	t.Logf("direct Emit under the losing tuple (1,A): err=%v", err)
	if err == nil || !errors.Is(err, fencing.ErrStaleOwner) {
		t.Fatalf("FINDING: losing tuple appended or refused at the wrong arm: %v", err)
	}
}

// ---------------------------------------------------------------
// Hygiene: the ratio and the table
// ---------------------------------------------------------------

// N3-8: every named test in the TRACEABILITY acceptance table exists
// in the package (independent of the producer's completeness test).
func TestN3TraceabilityNamesExist(t *testing.T) {
	raw, err := os.ReadFile("TRACEABILITY.md")
	if err != nil {
		t.Fatal(err)
	}
	listed, err := exec.Command("go", "test", ".", "-list", ".", "-count=1").CombinedOutput()
	if err != nil {
		t.Fatal(err)
	}
	present := map[string]bool{}
	for _, line := range strings.Split(string(listed), "\n") {
		present[strings.TrimSpace(line)] = true
	}
	rows := 0
	missing := []string{}
	inTable := false
	for _, line := range strings.Split(string(raw), "\n") {
		if strings.HasPrefix(line, "| AC row |") {
			inTable = true
			continue
		}
		if inTable && !strings.HasPrefix(line, "|") {
			inTable = false
		}
		if !inTable || strings.HasPrefix(line, "| ---") {
			continue
		}
		rows++
		for _, field := range strings.Split(line, "`") {
			if strings.HasPrefix(field, "Test") {
				top := strings.SplitN(field, "/", 2)[0]
				if !present[top] {
					missing = append(missing, field)
				}
			}
		}
	}
	t.Logf("acceptance table rows=%d missing tests=%v", rows, missing)
	if rows != 43 || len(missing) != 0 {
		t.Fatalf("table rows=%d (want 43) missing=%v", rows, missing)
	}
}

// N3-9: in the post-takeover world where the successor owner changed
// the profile (authoritative, under (2,S)) and stopped with C1, a
// LAUNCH-mode start (create from stopped, no checkpoint required)
// launches — and Run derives the profile closure from the lease's
// handoff base C0, not from the newest checkpoint C1 whose closure
// carries the change (§13.10: derive the effective profile from the
// validated checkpoint's event-head closure).
func TestN3PostTakeoverLaunchModeProfileFromHandoffBase(t *testing.T) {
	world := buildRunWorld(t)
	c0 := world.ckptID
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, c0)
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, c0)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, r3Successor, 1, world.headID, map[string]any{
		"checkpoint_id": c0, "execution_profile": "standard", "profile_source_event_id": nil,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	changed := appendChainEvent(t, world.repo, "profile.changed", 2, r3Successor, 2, resumedID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, r3Successor, 3, changed, map[string]any{
		"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true,
	})
	c1, _ := r3Capture(t, world.repo, world.ckpt, r3Op3, 2, r3Successor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, r3Successor, 4, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c1, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil || !has || newest != c1 {
		t.Fatalf("fold = (%v, %s, %v), want C1", has, newest, err)
	}
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = r3Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: r3Successor}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("launch mode from stopped (newest C1, lease base C0, yolo change %s in C1's closure): action=%s profile=%+v",
		changed[:20], outcome.Decision.Action, outcome.Decision.Profile)
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("expected launch: %v", outcome.Decision.Cause)
	}
	if outcome.Decision.Profile.Profile != "yolo" || outcome.Decision.Profile.Source != changed {
		t.Fatalf("FINDING: launch carried the handoff base's closure profile %+v instead of the newest checkpoint's (yolo/%s)", outcome.Decision.Profile, changed[:20])
	}
}

// N3-10 (dangerous direction of N3-9): the epoch-1 owner set yolo
// before C0; the successor owner set the profile BACK to standard
// (authoritative, under (2,S)) and stopped with C1. A launch-mode
// start from stopped must carry standard; deriving from the handoff
// base C0 launches yolo — the codex bypass-approvals mapping — on a
// session whose authoritative profile is standard.
func TestN3PostTakeoverLaunchModeYoloFromStaleBase(t *testing.T) {
	world := buildRunWorld(t)
	toYolo := appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	c0, _ := r3Capture(t, world.repo, world.ckpt, r3Op4, 1, fixtureLeaseA, []string{toYolo})
	world.headID = publishCheckpoint(t, world.repo, toYolo, 3, c0)
	successorLease(t, world.repo, r3Successor, fixtureLocalHost, c0)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, r3Successor, 1, world.headID, map[string]any{
		"checkpoint_id": c0, "execution_profile": "yolo", "profile_source_event_id": toYolo,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	toStandard := appendChainEvent(t, world.repo, "profile.changed", 2, r3Successor, 2, resumedID, map[string]any{
		"from": "yolo", "to": "standard", "confirmed": true,
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, r3Successor, 3, toStandard, map[string]any{
		"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true,
	})
	c1, _ := r3Capture(t, world.repo, world.ckpt, r3Op3, 2, r3Successor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, r3Successor, 4, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c1, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = r3Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: r3Successor}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("launch from stopped, authoritative profile standard (C1 closure), lease base C0 closure yolo: action=%s profile=%+v mapping=%q",
		outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Profile == "yolo" {
		t.Fatalf("FINDING: launch carries yolo (%q) on a session whose authoritative profile is standard (%s)", outcome.Decision.Mapping, toStandard[:20])
	}
}

// N3-11: post-window, two wrappers race on the SAME new pair through
// Run: the loser must reattach to the winner's child (§4.1 "identical
// retry returns or reattaches to the one recorded wrapper/child"),
// not report a launch of a child it did not create.
func TestN3PostWindowSamePairRaceThroughRun(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	world.mat = journalSourced(t, world.ckptID)
	winner := bindCandidate()
	winner.OperationID = fixtureOtherOp
	winner.TerminalInstanceID = r3Inst3
	winner.BindingDigest = BindingDigest(winner)
	request := r3RestoreRequest(t, world, fixtureOtherOp, r3Inst2, 1, fixtureLeaseA, world.ckptID)
	request.Hooks = &Hooks{
		AfterStage: func(path string) error {
			inner, err := Open(world.paneRoot)
			if err != nil {
				return err
			}
			_, err = inner.Supersede(fixtureSession, fixtureOtherOp, winner)
			return err
		},
	}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("post-window same-pair race loser through Run: action=%s binding instance=%s (winner %s, loser's own %s)",
		outcome.Decision.Action, outcome.Binding.TerminalInstanceID[9:13], r3Inst3[9:13], r3Inst2[9:13])
	if outcome.Binding.TerminalInstanceID != winner.TerminalInstanceID {
		t.Fatalf("loser did not converge on the winner's receipt")
	}
	if outcome.Decision.Action != ActionReattach {
		t.Fatalf("FINDING: the race loser reports %q while holding the winner's child", outcome.Decision.Action)
	}
}
