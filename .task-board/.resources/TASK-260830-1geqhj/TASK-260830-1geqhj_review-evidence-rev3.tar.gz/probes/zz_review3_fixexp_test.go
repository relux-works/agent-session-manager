package axpane

// Reviewer EXPERIMENT for CR-TASK-260830-1geqhj-3: runs only in the
// scratch copy where leaseCheckpointAgrees is relaxed to "a successor
// lease implies a published newest" (the candidate fix). It shows
// what the rest of Run does once the strict equality no longer parks
// the post-takeover story: the resume profile closure is loaded from
// the LEASE's handoff base, not from the resumed newest checkpoint.

import (
	"testing"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

const (
	fxSuccessor = "cccccccc-dddd-4eee-8fff-000000000001"
	fxOp3       = "0198f4c8-7d40-7e55-8e6f-1234567890ad"
	fxInst2     = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
)

func fxCapture(t *testing.T, repository *sessrepo.Repository, store *sessckpt.Store, operation string, epoch uint64, leaseID string, heads []string) (string, []byte) {
	t.Helper()
	reference, raw, err := store.Capture(repository, sessckpt.Inputs{
		OperationID: operation, SessionID: fixtureSession, SessionKind: sessckpt.SessionKindDirect,
		LeaseEpoch: epoch, LeaseID: leaseID, CreatorHostID: fixtureLocalHost,
		WorkspaceManifestID: seedDigest(0xE1), ProviderManifestID: seedDigest(0xE2),
		Boundary: sessckpt.SafeBoundary{
			ProviderID: "codex", ProviderVersion: "0.147.0", Evidence: sessckpt.EvidenceAcceptedTest,
			InputBlocked: true, ForegroundIdle: true, BackgroundIdle: true, OpenProcesses: 0, OpenDatabaseHandles: 0,
		},
		EventHeads: heads, CreatedAt: fixtureCreatedAt, Extensions: map[string]string{},
	})
	if err != nil {
		t.Fatalf("Capture(epoch %d) error = %v", epoch, err)
	}
	return reference.CheckpointID, raw
}

// The successor owner changes the profile to yolo (authoritative,
// under (2,S)) and then stops with C1 whose closure contains that
// change. A restore from C1 must carry yolo with that source
// (§13.10: derive the effective profile from ITS event-head closure).
func TestFX_PostTakeoverProfileClosureSource(t *testing.T) {
	world := buildRunWorld(t)
	c0 := world.ckptID
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, c0)
	successorLease(t, world.repo, fxSuccessor, fixtureLocalHost, c0)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, fxSuccessor, 1, world.headID, map[string]any{
		"checkpoint_id": c0, "execution_profile": "standard", "profile_source_event_id": nil,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	changed := appendChainEvent(t, world.repo, "profile.changed", 2, fxSuccessor, 2, resumedID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, fxSuccessor, 3, changed, map[string]any{
		"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true,
	})
	c1, _ := fxCapture(t, world.repo, world.ckpt, fxOp3, 2, fxSuccessor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, fxSuccessor, 4, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c1, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil || !has || newest != c1 {
		t.Fatalf("fold = (%v, %s, %v), want C1", has, newest, err)
	}
	world.mat = journalSourced(t, c1)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = fxInst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: fxSuccessor}
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = true
	request.CheckpointID = c1
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("post-takeover restore from C1 under the relaxed agreement: action=%s cause=%v profile=%+v (yolo change event %s)",
		outcome.Decision.Action, outcome.Decision.Cause, outcome.Decision.Profile, changed[:20])
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("relaxed agreement still does not launch: %v", outcome.Decision.Cause)
	}
	if outcome.Decision.Profile.Profile != "yolo" || outcome.Decision.Profile.Source != changed {
		t.Fatalf("FINDING: the resume carried the handoff base's closure profile %+v instead of the resumed checkpoint's (yolo/%s)", outcome.Decision.Profile, changed[:20])
	}
}
