package axpane

// Delta witnesses for surviving reviewer mutants: run once on the
// pristine tree and once under the mutant; the logged outcome is the
// witness. Assertions are the SPEC-expected behavior.

import (
	"testing"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

// RV3-4b witness: successor lease carrying a checkpoint the chain never
// published, session bound in-window, changed operation.
func TestDX_WindowLeaseCheckpointNullFold(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	successorLease(t, world.repo, "cccccccc-dddd-4eee-8fff-000000000001", fixtureLocalHost, world.ckptID)
	request := runRequest(t, world)
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: "cccccccc-dddd-4eee-8fff-000000000001"}
	outcome, err := Run(world.stores(), request)
	t.Logf("successor lease with unpublished checkpoint, fold null, in-window changed op: action=%s class=%q err=%v", outcome.Decision.Action, outcome.Decision.Class, err)
	if err != nil || outcome.Decision.Action != ActionRefused || outcome.Decision.Class != terminalbackend.CodeIdempotencyMismatch {
		t.Fatalf("WITNESS: in-window changed op admitted on a null fold because the lease carries a checkpoint")
	}
}

// RV3-11 witness: a chain the landed reducer refuses (profile.changed
// under a successor lease while creating) reaches Run.
func TestDX_UnfolderableChainThroughRun(t *testing.T) {
	world := buildRunWorld(t)
	successorLease(t, world.repo, "cccccccc-dddd-4eee-8fff-000000000001", fixtureLocalHost, world.ckptID)
	appendChainEvent(t, world.repo, "profile.changed", 2, "cccccccc-dddd-4eee-8fff-000000000001", 1, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	if _, _, err := LoadNewestCheckpoint(world.repo, fixtureSession); err == nil {
		t.Fatalf("fixture chain unexpectedly folds")
	}
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: "cccccccc-dddd-4eee-8fff-000000000001"}
	outcome, err := Run(world.stores(), request)
	t.Logf("unfolderable chain through Run: action=%q err=%v", outcome.Decision.Action, err)
	if err == nil {
		t.Fatalf("WITNESS: Run decided %q over a chain the reducer refuses (profile %+v)", outcome.Decision.Action, outcome.Decision.Profile)
	}
}
