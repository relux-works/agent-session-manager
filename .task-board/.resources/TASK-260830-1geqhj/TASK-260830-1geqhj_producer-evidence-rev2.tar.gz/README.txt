TASK-260830-1geqhj rev2 producer evidence
Base: 888ae3dff6a55c29bfaf311957748d405ed1ab06
Date: 2026-09-17

Contents:
- logs/01-axpane.txt: go test ./internal/axpane/ -count=1
- logs/02-axpane-cover.txt + 02-cover-func.txt + cover.out + cover.html: coverage 79.3%
- logs/03-decide.txt: TestDecide|TestRealm|TestLaunch
- logs/04-bind.txt: TestBind|TestStatus|TestBinding
- logs/05-observe.txt: TestObserve|TestChainTail|TestLoad
- logs/06-run.txt: TestRun|TestStatusSession|TestLaunchCarries
- logs/07-events.txt: TestParked|TestTerminal|TestEmit|TestDescriptor|TestLosing|TestIsFencing
- logs/08-conformance.txt + 22-conformance.txt: 27 pinned clauses
- logs/09-vet.txt: go vet ./internal/axpane/ (clean)
- logs/10-gofmt.txt: gofmt -l (clean)
- logs/11-purego.txt: CGO_ENABLED=0
- logs/12-env.txt: AXT_* env
- logs/13-owners.txt: 8 owner packages
- logs/18-all.txt: go test ./... (all green)
- logs/19-vetall.txt: go vet ./... (clean)
- logs/20-mutants.txt + mutants.log: 36/36 (35 KILLED + control)
- logs/21-crash.txt: crash/hook/concurrent
- logs/23-spec-count.txt: SPEC MUST/SHALL count

RM killers (reviewer rev1 survivors, now killed):
- RM1 (swallowed ObserveOwnership): TestRunTornLeasePropagates
- RM2 (materialize/authorize swap): TestDecideRemoteOwnerPrecedesMaterialization
- RM4 (restore idempotency dropped): TestDecideRestoreChangedOperationRefuses
