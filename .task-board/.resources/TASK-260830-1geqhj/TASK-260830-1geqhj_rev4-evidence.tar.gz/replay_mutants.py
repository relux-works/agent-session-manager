"""Reviewer mutant replay for rev4: regenerate from THIS candidate, one exact patch each."""
import shlex
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

WORKTREE = Path("/Users/iv/Developer/cocoaskills/.temp/STORY-260916-vhwogf/worktree")
PY = WORKTREE / ".temp/venv-dev/bin/python"
ROOT = Path("/tmp/rev4-review/mut-replay")


@dataclass(frozen=True)
class Mutant:
    id: str
    file: str
    old: str
    new: str
    kill: str
    hold: str


T = "tests/test_sources_transport.py"
P = "tests/test_install_transport_providers.py"

MUTANTS = [
    Mutant(
        "M-R4a-remote-conflict",
        "src/csk/git_admission.py",
        '        if record.startswith("remote:"):\n            continue',
        '        if record.startswith("remote:"):\n            records.append("remote-relay")',
        f"{T} -k 'https_status_with_body and 503-text-fail'",
        f"{T} -k 'https_status_with_body and 503-bodiless-fail'",
    ),
    Mutant(
        "M-R4b-authfailed-dropped",
        "src/csk/git_admission.py",
        '    ) or record == ("fatal: authentication failed"):\n        return "auth-rejected"',
        '    ) or record == ("fatal: authentication failed"):\n        return None',
        f"{T} -k 'https_status_with_body and 401-bodiless-badcreds'",
        f"{T} -k 'https_status_with_body and 503-text-fail'",
    ),
    Mutant(
        "M-R4c-askpass-conflict",
        "src/csk/git_admission.py",
        '        if record.startswith("remote:"):\n'
        "            continue\n"
        "        evidence = _evidence_class(record)",
        '        if record.startswith("remote:"):\n'
        "            continue\n"
        '        if record.startswith("error: unable to read askpass response"):\n'
        '            records.append("askpass-conflict")\n'
        "        evidence = _evidence_class(record)",
        f"{T} -k 'https_status_with_body and 401-text-fail'",
        f"{T} -k 'https_status_with_body and 503-text-fail'",
    ),
    Mutant(
        "M-R4d-methods",
        "src/csk/git_admission.py",
        '        r"[a-z0-9._-]+@[a-z0-9][a-z0-9.-]*: permission denied "\n'
        '        r"\\([a-z0-9,-]+\\)\\.",',
        '        r"[a-z0-9._-]+@[a-z0-9][a-z0-9.-]*: permission denied "\n'
        '        r"\\((?:password|publickey(?:,[^)]*)?)\\)\\.",',
        f"'{T}::test_real_ssh_failure_falls_back"
        "[git@example.org: Permission denied (keyboard-interactive).-ssh-auth-rejected]'",
        f"'{T}::test_real_ssh_failure_falls_back"
        "[git@example.org: Permission denied (password).-ssh-auth-rejected]'"
        f" '{T}::test_real_ssh_failure_falls_back"
        "[git@example.org: Permission denied (publickey).-ssh-auth-rejected]'",
    ),
    Mutant(
        "M-R4d-signing",
        "src/csk/git_admission.py",
        '        if record.startswith("remote:"):\n'
        "            continue\n"
        "        evidence = _evidence_class(record)",
        '        if record.startswith("remote:"):\n'
        "            continue\n"
        '        if record.startswith("sign_and_send_pubkey:"):\n'
        '            records.append("signing-conflict")\n'
        "        evidence = _evidence_class(record)",
        f"{T}::test_non_evidence_beside_a_real_record_leaves_the_real_record_deciding"
        "[signing-rsa-refused]",
        f"{T}::test_non_evidence_beside_a_real_record_leaves_the_real_record_deciding"
        "[remote-forged-503]"
        f" {T}::test_non_evidence_beside_a_real_record_leaves_the_real_record_deciding"
        "[askpass-error]",
    ),
    Mutant(
        "M7-lane-and",
        "src/csk/build_repository_pipeline.py",
        "    if provenance.url_port is not None or provenance.alias_port is not None:",
        "    if provenance.url_port is not None and provenance.alias_port is not None:",
        f"{T} -k 'strict_refusals and 2222'",
        f"{T} -k 'strict_refusals and corp-mirror'",
    ),
    Mutant(
        "M10b-ref-ignored",
        "src/csk/git_admission.py",
        '    if re.fullmatch(r"fatal: couldn\'t find remote ref .+", record):\n'
        '        return "ref-moved"',
        '    if re.fullmatch(r"fatal: couldn\'t find remote ref .+", record):\n'
        "        return None",
        f"{T} -k 'hostile_suffix and release-401'",
        f"{T} -k 'hostile_suffix and (refused or 503 or verification or certificate)'",
    ),
]


def run(cmd, cwd):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=600)


def main(ids):
    failures = 0
    for m in MUTANTS:
        if ids and m.id not in ids:
            continue
        target = ROOT / m.id
        target.mkdir(parents=True, exist_ok=True)
        subprocess.run(
            ["rsync", "-a", "--delete", "--exclude", ".git", "--exclude", ".temp",
             "--exclude", "__pycache__", f"{WORKTREE}/", f"{target}/"],
            check=True, capture_output=True,
        )
        path = target / m.file
        text = path.read_text()
        count = text.count(m.old)
        if count != 1:
            print(f"{m.id}: PATCH TARGET {count}x (need 1); ABORT")
            failures += 1
            continue
        path.write_text(text.replace(m.old, m.new))
        print(f"===== {m.id} =====")
        diff = run(["diff", "-u", str(WORKTREE / m.file), str(path)], cwd=target)
        print(diff.stdout.strip()[:1500])
        proof = run(
            [str(PY), "-c", "import sys; sys.path.insert(0,'src');"
             "import csk.git_admission as g; print(g.__file__)"],
            cwd=target,
        )
        print("COPY-RUNS:", proof.stdout.strip())
        if str(target) not in proof.stdout:
            print(f"{m.id}: COPY-RUNS FAILED")
            failures += 1
            continue
        kill = run(
            [str(PY), "-m", "pytest", "-q", "--tb=line", "-p", "no:cacheprovider"]
            + shlex.split(m.kill),
            cwd=target,
        )
        tail = "\n".join(kill.stdout.strip().splitlines()[-3:])
        print(f"KILL exit={kill.returncode} (expect 1): {tail}")
        if kill.returncode != 1:
            print(f"{m.id}: KILL DID NOT DIE")
            failures += 1
            continue
        hold = run(
            [str(PY), "-m", "pytest", "-q", "--tb=line", "-p", "no:cacheprovider"]
            + shlex.split(m.hold),
            cwd=target,
        )
        tail = "\n".join(hold.stdout.strip().splitlines()[-3:])
        print(f"HOLD exit={hold.returncode} (expect 0): {tail}")
        if hold.returncode != 0:
            print(f"{m.id}: HOLD BROKE")
            failures += 1
    print("ALL OK" if failures == 0 else f"{failures} MISMATCHES")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
