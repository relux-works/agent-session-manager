"""Revision-3 reviewer attacks for TASK-260916-fsw7re (scratch, not shipped).

Every test drives a production entry point; loopback fixtures only, no
outbound network. Tests marked SPEC-MANDATED assert the specification's
required outcome and FAIL on the candidate where the behavior is broken.
Controls assert behavior that already holds (they pin the method).
"""
import http.server
import json
import os
import shutil
import socket
import ssl
import subprocess
import sys
import threading
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tests"))

import pytest

from conftest import make_config, make_project, stable_env, write_skillfile  # noqa: F401
from test_git_admission_ssh import (
    _fixture_repository as _ssh_fixture_repository,
)
from test_git_admission_ssh import (
    _identity as _ssh_identity,
)
from test_git_admission_ssh import (
    _known_hosts as _ssh_known_hosts,
)
from test_git_admission_ssh import (
    _tool as _ssh_tool,
)
from test_install import _stub_trusted_toolchain
from test_install_external_repository import (
    _external_repository,
    _git_tool,
    _skill_repository,
)
from test_install_transport_providers import (
    _policy,
    _rendered_errors,
    _run_install,
)
from test_sources_transport import (
    IDENTITY,
    _bare_repository,
    _failing_ssh_stub,
    _fake_http_tool,
    _observed_first_class,
    _v2_plan,
)

from csk import git_admission, installer
from csk.build_https import BuildHTTPSRule
from csk.build_ssh import BuildSSHRule
from csk.sources import repository_policy, transport

pytestmark = pytest.mark.skipif(
    os.name == "nt",
    reason="reviewer loopback/ssh stand-ins rely on POSIX exec semantics",
)

HTTPS_URL = "https://example.org/kit.git"
SSH_URL = "git@example.org:kit.git"


# --------------------------------------------------------------------------
# Loopback HTTPS fixture (real git + real curl records, no outbound traffic).
# --------------------------------------------------------------------------

_CERT_CACHE: dict[str, tuple[str, str]] = {}


def _cert_paths(tmp_path: Path) -> tuple[str, str]:
    key = os.fspath(tmp_path)
    cached = _CERT_CACHE.get(key)
    if cached is not None:
        return cached
    key_path = os.fspath(tmp_path / "rev3-key.pem")
    crt_path = os.path.join(os.fspath(tmp_path), "rev3-crt.pem")
    subprocess.run(
        [
            "openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
            "-keyout", key_path, "-out", crt_path, "-days", "1",
            "-subj", "/CN=127.0.0.1",
            "-addext", "subjectAltName=IP:127.0.0.1",
        ],
        check=True,
        capture_output=True,
    )
    _CERT_CACHE[key] = (key_path, crt_path)
    return key_path, crt_path


class _StatusServer:
    """One-shot loopback HTTPS server returning a fixed status/body/ctype."""

    def __init__(
        self,
        tmp_path: Path,
        *,
        status: int,
        body: bytes,
        content_type: str = "text/plain",
    ) -> None:
        self.status = status
        self.body = body
        self.content_type = content_type
        self.auth_seen: list[str | None] = []
        key_path, self.crt_path = _cert_paths(tmp_path)
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def _respond(self) -> None:
                outer.auth_seen.append(self.headers.get("Authorization"))
                self.send_response(outer.status)
                if outer.status == 401:
                    self.send_header("WWW-Authenticate", 'Basic realm="git"')
                self.send_header("Content-Type", outer.content_type)
                self.send_header("Content-Length", str(len(outer.body)))
                self.end_headers()
                try:
                    self.wfile.write(outer.body)
                except (BrokenPipeError, ConnectionResetError):
                    pass

            do_GET = _respond
            do_POST = _respond

            def log_message(self, *args: object) -> None:
                pass

        self._server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(self.crt_path, key_path)
        self._server.socket = context.wrap_socket(
            self._server.socket, server_side=True
        )
        self.port = self._server.server_address[1]
        self._thread = threading.Thread(
            target=self._server.serve_forever, daemon=True
        )
        self._thread.start()

    @property
    def url(self) -> str:
        return f"https://127.0.0.1:{self.port}/kit.git"

    def shutdown(self) -> None:
        self._server.shutdown()
        self._thread.join(timeout=10)


@pytest.fixture
def _ca_trust(monkeypatch: pytest.MonkeyPatch):
    """Trust the fixture CA for fetch children only (additive env change).

    The production clean environment is preserved bit-for-bit except for the
    added GIT_SSL_CAINFO entry; every config/HOME/XDG pin stays in force, so
    this fixture cannot mask ambient-config leakage, it only lets the TLS
    handshake with the loopback fixture succeed.
    """
    crt_holder: dict[str, str] = {}
    real_clean = git_admission._clean_git_environment

    def clean_with_ca(*args: object, **kwargs: object) -> dict[str, str]:
        environment = real_clean(*args, **kwargs)  # type: ignore[arg-type]
        assert crt_holder, "fixture CA not installed"
        environment["GIT_SSL_CAINFO"] = crt_holder["crt"]
        return environment

    monkeypatch.setattr(
        git_admission, "_clean_git_environment", clean_with_ca
    )
    return crt_holder


def _https_mirror_plan(first_url: str, second_url: str) -> repository_policy.ResolutionPlan:
    return _v2_plan(
        [
            {"url": first_url, "authentication": "first",
             "mirror_of": IDENTITY},
            {"url": second_url, "authentication": "second",
             "mirror_of": IDENTITY},
        ]
    )


# --------------------------------------------------------------------------
# R4-HTTPS: real git+curl records through production acquire_plan.
# --------------------------------------------------------------------------

def test_r4_https_503_bare_body_falls_back_control(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """CONTROL: a bodiless real 503 opens the alternate (already covered)."""
    server = _StatusServer(tmp_path, status=503, body=b"")
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.snapshot.commit == commit
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-503"
    finally:
        server.shutdown()


def test_r4_https_503_text_body_must_fall_back(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """SPEC-MANDATED: a real 503 with a text body opens the alternate."""
    server = _StatusServer(
        tmp_path, status=503,
        body=b"<html><body>Service Temporarily Unavailable</body></html>",
    )
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.snapshot.commit == commit
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-503"
    finally:
        server.shutdown()


def test_r4_https_502_text_body_must_fall_back(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """SPEC-MANDATED: a real 502 with a text body opens the alternate."""
    server = _StatusServer(tmp_path, status=502, body=b"Bad Gateway\n")
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-502"
    finally:
        server.shutdown()


def test_r4_https_403_text_body_must_fall_back(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """SPEC-MANDATED: a real 403 with a text body opens the alternate."""
    server = _StatusServer(tmp_path, status=403, body=b"forbidden by policy\n")
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-403"
    finally:
        server.shutdown()


def test_r4_https_403_json_body_falls_back_control(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """CONTROL: documents that the 403 outcome is server-body dependent."""
    server = _StatusServer(
        tmp_path, status=403, body=b'{"message":"Denied"}',
        content_type="application/json",
    )
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-403"
    finally:
        server.shutdown()


def test_r4_https_401_wrong_credentials_must_fall_back(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """SPEC-MANDATED: production broker + rejected creds opens the alternate.

    Real git, the production HTTPS broker material with wrong credentials,
    and a real loopback 401: git prints `fatal: Authentication failed`,
    which is an explicit authentication rejection and must allow fallback.
    """
    server = _StatusServer(
        tmp_path, status=401, body=b'{"message":"Bad credentials"}',
        content_type="application/json",
    )
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        first_tool = replace(
            _fake_http_tool(tmp_path / "tool", {}, allow_loopback_https=True),
            https_credentials=git_admission.OperatorHTTPSCredentials(
                scope=IDENTITY, host="127.0.0.1", source="env",
                username="rev3-bad-user", token_value="rev3-bad-token",
            ),
        )
        second_tool = _fake_http_tool(
            tmp_path / "tool2", {second_url: second_bare},
            allow_loopback_https=True,
        )

        def provider(endpoint: repository_policy.ResolvedEndpoint):
            return first_tool if endpoint.url == server.url else second_tool

        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit),
            tool_for_endpoint=provider,
        )
        assert server.auth_seen and any(
            value is not None for value in server.auth_seen
        ), "broker never presented credentials"
        assert result.snapshot.commit == commit
        assert result.attempt_count == 2
        assert result.attempts[0].classification in {
            "http-401", "auth-rejected", "ssh-auth-rejected", "auth-unavailable",
        }
    finally:
        server.shutdown()


def test_r4_https_401_failing_askpass_must_fall_back(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """SPEC-MANDATED: an unusable credential broker is auth-unavailable.

    The production anonymous lane points askpass at a program that yields no
    credential; git reports `error: unable to read askpass response` plus
    `could not read Username`. The method is unavailable, not forbidden.
    """
    server = _StatusServer(tmp_path, status=401, body=b"")
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        # _fake_http_tool ships askpass=exit-1, the same shape as the
        # production anonymous lane (askpass yields no credential).
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        assert tool.https_credentials is None
        result = transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit), tool
        )
        assert result.snapshot.commit == commit
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "auth-unavailable"
    finally:
        server.shutdown()


def test_r4_https_404_text_body_stays_fail_closed_control(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, _ca_trust, stable_env
) -> None:
    """CONTROL: a real 404 never opens the alternate, body or not."""
    server = _StatusServer(tmp_path, status=404, body=b"no such repository\n")
    _ca_trust["crt"] = server.crt_path
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        real_run = git_admission.subprocess.run
        fetches: list[object] = []

        def record(*args: object, **kwargs: object) -> object:
            command = args[0]
            assert isinstance(command, tuple)
            if "fetch" in command:
                fetches.append(command)
            return real_run(*args, **kwargs)

        monkeypatch.setattr(git_admission.subprocess, "run", record)
        with pytest.raises(git_admission.GitAdmissionError) as captured:
            transport.acquire_plan(
                plan, git_admission.LockedCommit("sha1", commit), tool
            )
        assert len(fetches) == 1
        observed = _observed_first_class(captured.value)
        assert observed is not None
        assert repository_policy.classify_failure(observed) == "forbidden"
    finally:
        server.shutdown()


def test_r4_https_refused_closed_port_falls_back_control(
    tmp_path: Path, stable_env
) -> None:
    """CONTROL: real refused connection opens the alternate (already covered)."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.bind(("127.0.0.1", 0))
    closed = probe.getsockname()[1]
    probe.close()
    second_bare, commit = _bare_repository(tmp_path / "second")
    second_url = "https://fixture.test/kit.git"
    plan = _https_mirror_plan(
        f"https://127.0.0.1:{closed}/kit.git", second_url
    )
    tool = _fake_http_tool(
        tmp_path / "tool", {second_url: second_bare},
        allow_loopback_https=True,
    )
    result = transport.acquire_plan(
        plan, git_admission.LockedCommit("sha1", commit), tool
    )
    assert result.snapshot.commit == commit
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "connection-refused"


# --------------------------------------------------------------------------
# R4-SSH: byte-exact ssh records through real git + production wrapper.
# --------------------------------------------------------------------------

def _ssh_fallback_result(
    tmp_path: Path, lines: list[str]
) -> transport.AcquisitionResult:
    """Run one SSH-first plan whose stand-in emits exactly ``lines``."""
    bare, commit = _ssh_fixture_repository(tmp_path / "fixture")
    ssh, _log = _failing_ssh_stub(tmp_path / "ssh", lines)
    creds = git_admission.OperatorSSHCredentials(
        identity=_ssh_identity(tmp_path / "operator"),
        known_hosts=_ssh_known_hosts(tmp_path / "operator"),
    )
    second = "https://example.org/kit.git"
    plan = _v2_plan(
        [
            {"url": "git@example.org:kit.git", "authentication": "first"},
            {"url": second, "authentication": "second"},
        ]
    )
    https = _fake_http_tool(tmp_path / "http", {second: bare})

    def provider(endpoint: repository_policy.ResolvedEndpoint):
        return _ssh_tool(ssh, creds) if endpoint.transport == "ssh" else https

    return transport.acquire_plan(
        plan, git_admission.LockedCommit("sha1", commit),
        tool_for_endpoint=provider,
    )


def test_r4_ssh_publickey_rejection_falls_back_control(
    tmp_path: Path, stable_env
) -> None:
    """CONTROL: the covered publickey shape opens the alternate."""
    result = _ssh_fallback_result(
        tmp_path, ["git@example.org: Permission denied (publickey)."]
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "ssh-auth-rejected"


def test_r4_ssh_password_only_rejection_must_fall_back(
    tmp_path: Path, stable_env
) -> None:
    """SPEC-MANDATED: a non-publickey method list is still auth rejection."""
    result = _ssh_fallback_result(
        tmp_path, ["git@example.org: Permission denied (password)."]
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "ssh-auth-rejected"


def test_r4_ssh_keyboard_interactive_rejection_must_fall_back(
    tmp_path: Path, stable_env
) -> None:
    """SPEC-MANDATED: keyboard-interactive-only rejection opens the alternate."""
    result = _ssh_fallback_result(
        tmp_path,
        ["git@example.org: Permission denied (keyboard-interactive)."],
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "ssh-auth-rejected"


def test_r4_ssh_hyphenated_user_rejection_must_fall_back(
    tmp_path: Path, stable_env
) -> None:
    """SPEC-MANDATED: mundane service-account usernames classify as auth."""
    result = _ssh_fallback_result(
        tmp_path, ["svc-deploy@example.org: Permission denied (publickey)."]
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "ssh-auth-rejected"


def test_r4_ssh_agent_signing_failure_must_fall_back(
    tmp_path: Path, stable_env
) -> None:
    """SPEC-MANDATED: client-side signing failure beside rejection is auth."""
    result = _ssh_fallback_result(
        tmp_path,
        [
            'sign_and_send_pubkey: signing failed for RSA "/tmp/operator-key"'
            " from agent: agent refused operation",
            "git@example.org: Permission denied (publickey).",
        ],
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification in {
        "ssh-auth-rejected", "auth-unavailable",
    }


def test_r4_ssh_timeout_on_explicit_port_falls_back(
    tmp_path: Path, stable_env
) -> None:
    """Timeout with a non-default port and footer opens the alternate."""
    result = _ssh_fallback_result(
        tmp_path,
        ["ssh: connect to host example.org port 2222: Operation timed out"],
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "timeout"


def test_r4_ssh_real_binary_refused_falls_back(
    tmp_path: Path, stable_env
) -> None:
    """CONTROL: the real ssh binary through the real wrapper falls back."""
    real_ssh = shutil.which("ssh")
    assert real_ssh is not None
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.bind(("127.0.0.1", 0))
    closed = probe.getsockname()[1]
    probe.close()
    bare, commit = _ssh_fixture_repository(tmp_path / "fixture")
    creds = git_admission.OperatorSSHCredentials(
        identity=_ssh_identity(tmp_path / "operator"),
        known_hosts=_ssh_known_hosts(tmp_path / "operator"),
    )
    first_url = f"ssh://git@127.0.0.1:{closed}/kit.git"
    second_url = "https://fixture.test/kit.git"
    plan = _v2_plan(
        [
            {"url": first_url, "authentication": "first",
             "mirror_of": IDENTITY},
            {"url": second_url, "authentication": "second",
             "mirror_of": IDENTITY},
        ]
    )
    ssh_tool = _ssh_tool(Path(real_ssh), creds)
    https_tool = _fake_http_tool(
        tmp_path / "http", {second_url: bare}, allow_loopback_https=True
    )

    def provider(endpoint: repository_policy.ResolvedEndpoint):
        return ssh_tool if endpoint.transport == "ssh" else https_tool

    result = transport.acquire_plan(
        plan, git_admission.LockedCommit("sha1", commit),
        tool_for_endpoint=provider,
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "connection-refused"


def test_r4_ssh_unprotected_key_warnings_must_fall_back(
    tmp_path: Path, stable_env
) -> None:
    """SPEC-MANDATED: real ssh client-side diagnostics must not suppress.

    Fully real path: no stand-in. The operator identity file is left
    group/world-readable, so the real ssh binary prints its UNPROTECTED
    PRIVATE KEY FILE warning block before the refused record; git appends
    its footer. The transport outcome is still a refused connection and
    the alternate must be attempted.
    """
    real_ssh = shutil.which("ssh")
    assert real_ssh is not None
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.bind(("127.0.0.1", 0))
    closed = probe.getsockname()[1]
    probe.close()
    identity = _ssh_identity(tmp_path / "operator")
    os.chmod(identity, 0o644)
    creds = git_admission.OperatorSSHCredentials(
        identity=identity,
        known_hosts=_ssh_known_hosts(tmp_path / "operator"),
    )
    bare, commit = _ssh_fixture_repository(tmp_path / "fixture")
    first_url = f"ssh://git@127.0.0.1:{closed}/kit.git"
    second_url = "https://fixture.test/kit.git"
    plan = _v2_plan(
        [
            {"url": first_url, "authentication": "first",
             "mirror_of": IDENTITY},
            {"url": second_url, "authentication": "second",
             "mirror_of": IDENTITY},
        ]
    )
    ssh_tool = _ssh_tool(Path(real_ssh), creds)
    https_tool = _fake_http_tool(
        tmp_path / "http", {second_url: bare}, allow_loopback_https=True
    )

    def provider(endpoint: repository_policy.ResolvedEndpoint):
        return ssh_tool if endpoint.transport == "ssh" else https_tool

    result = transport.acquire_plan(
        plan, git_admission.LockedCommit("sha1", commit),
        tool_for_endpoint=provider,
    )
    assert result.attempt_count == 2
    assert result.attempts[0].classification == "connection-refused"


def test_r4_ssh_host_key_stays_fail_closed_control(
    tmp_path: Path, stable_env
) -> None:
    """CONTROL: host-key evidence plus footer refuses the alternate."""
    bare, commit = _ssh_fixture_repository(tmp_path / "fixture")
    ssh, _log = _failing_ssh_stub(
        tmp_path / "ssh", ["Host key verification failed."]
    )
    creds = git_admission.OperatorSSHCredentials(
        identity=_ssh_identity(tmp_path / "operator"),
        known_hosts=_ssh_known_hosts(tmp_path / "operator"),
    )
    second = "https://example.org/kit.git"
    plan = _v2_plan(
        [
            {"url": "git@example.org:kit.git", "authentication": "first"},
            {"url": second, "authentication": "second"},
        ]
    )
    https = _fake_http_tool(tmp_path / "http", {second: bare})

    def provider(endpoint: repository_policy.ResolvedEndpoint):
        return _ssh_tool(ssh, creds) if endpoint.transport == "ssh" else https

    with pytest.raises(git_admission.GitAdmissionError) as captured:
        transport.acquire_plan(
            plan, git_admission.LockedCommit("sha1", commit),
            tool_for_endpoint=provider,
        )
    assert _observed_first_class(captured.value) == "host-key"


# --------------------------------------------------------------------------
# F1: per-endpoint provider admission through production installer.install.
# --------------------------------------------------------------------------

def _run_wide_ssh(tmp_path: Path) -> git_admission.OperatorSSHCredentials:
    return git_admission.OperatorSSHCredentials(
        identity=tmp_path / "rev3-operator-identity",
        known_hosts=tmp_path / "rev3-known-hosts",
    )


def _leak_sweep(result: object, secrets: list[str]) -> str:
    rendered = _rendered_errors(result) + "\n" + "\n".join(
        getattr(result, "messages", [])
    )
    for secret in secrets:
        assert secret not in rendered, f"leaked {secret!r} into {rendered!r}"
    return rendered


@pytest.mark.parametrize("order", ["https-first", "ssh-first"])
def test_f1_unknown_providers_refuse_both_directions(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env, order: str
) -> None:
    """Unknown names with no material never reach acquisition, either order."""
    first, second = (
        (HTTPS_URL, SSH_URL) if order == "https-first" else (SSH_URL, HTTPS_URL)
    )
    policy = _policy(
        [
            {"url": first, "authentication": "rev3-unknown-alpha"},
            {"url": second, "authentication": "rev3-unknown-beta"},
        ]
    )
    result, calls = _run_install(monkeypatch, tmp_path, policy)
    assert calls == [], f"unknown providers reached acquisition: {calls}"
    rendered = _leak_sweep(
        result, ["rev3-unknown-alpha", "rev3-unknown-beta"]
    )
    assert git_admission.IDENTITY_INVALID in rendered


def test_f1_unknown_ssh_name_uses_explicit_run_wide_selection(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """DOCUMENTED: an explicit run-wide SSH selection serves a named endpoint.

    Operator configuration has no name registry (scope-keyed rules plus one
    unnamed run-wide selection per transport), so a run-wide selection is the
    configured provider every SSH name resolves to. This pins the behavior
    rather than the refusal: the observed credentials must be exactly the
    run-wide selection, never anonymous or a substituted default.
    """
    run_wide = _run_wide_ssh(tmp_path)
    policy = _policy(
        [{"url": SSH_URL, "authentication": "rev3-named-ssh"}]
    )
    policy["repositories"][IDENTITY]["fallback"] = "none"
    _result, calls = _run_install(
        monkeypatch, tmp_path, policy, ssh_selected=run_wide
    )
    assert len(calls) == 1
    assert calls[0].transport == "ssh"
    assert calls[0].ssh_credentials == run_wide


def test_f1_unavailable_https_material_reaches_ssh_alternate(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """A missing HTTPS token env must not stop the SSH alternate."""
    run_wide = _run_wide_ssh(tmp_path)
    env_name = "CSK_REV3_MISSING_PROVIDER_TOKEN"
    monkeypatch.delenv(env_name, raising=False)
    policy = _policy(
        [
            {"url": HTTPS_URL, "authentication": "rev3-team-https"},
            {"url": SSH_URL, "authentication": "rev3-team-ssh"},
        ]
    )
    result, calls = _run_install(
        monkeypatch,
        tmp_path,
        policy,
        ssh_selected=run_wide,
        build_https=(BuildHTTPSRule(scope=IDENTITY, token_env=env_name),),
    )
    assert len(calls) == 1
    assert calls[0].transport == "ssh"
    assert calls[0].ssh_credentials == run_wide
    rendered = _leak_sweep(result, [env_name, "rev3-team-https"])
    assert "repository_endpoint_unavailable" in rendered


def test_f1_mismatched_transport_material_refuses(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """SSH-only material never serves a named HTTPS endpoint and vice versa."""
    run_wide_https = installer.OperatorHTTPSToken(
        username="token", token="rev3-synthetic-token"
    )
    policy = _policy([{"url": SSH_URL, "authentication": "rev3-team-ssh"}])
    policy["repositories"][IDENTITY]["fallback"] = "none"
    result, calls = _run_install(
        monkeypatch, tmp_path, policy, https_token=run_wide_https
    )
    assert calls == []
    rendered = _leak_sweep(
        result, ["rev3-synthetic-token", "rev3-team-ssh"]
    )
    assert git_admission.IDENTITY_INVALID in rendered


def test_f1_explicit_anonymous_split_by_transport(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """Anonymous HTTPS fetches; anonymous SSH opens the alternate."""
    run_wide_https = installer.OperatorHTTPSToken(
        username="token", token="rev3-synthetic-token"
    )
    policy = _policy(
        [
            {"url": SSH_URL, "authentication": "anonymous"},
            {"url": HTTPS_URL, "authentication": "rev3-team-https"},
        ]
    )
    result, calls = _run_install(
        monkeypatch, tmp_path, policy, https_token=run_wide_https
    )
    assert [call.transport for call in calls] == ["https"]
    assert calls[0].https_credentials is not None
    rendered = _leak_sweep(result, ["rev3-synthetic-token", "anonymous"])
    assert "repository_endpoint_unavailable" in rendered


def test_f1_mirror_second_endpoint_uses_mirror_host_material(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """A mirror alternate authenticates against the mirror host."""
    mirror_ssh = "ssh://git@rev3mirror.example.net/kit.git"
    policy = _policy(
        [
            {"url": HTTPS_URL, "authentication": "rev3-team-https"},
            {
                "url": mirror_ssh,
                "authentication": "rev3-team-ssh",
                "mirror_of": IDENTITY,
            },
        ],
        schema=2,
    )
    run_wide = _run_wide_ssh(tmp_path)
    run_wide_https = installer.OperatorHTTPSToken(
        username="token", token="rev3-synthetic-token"
    )
    _result, calls = _run_install(
        monkeypatch, tmp_path, policy,
        ssh_selected=run_wide, https_token=run_wide_https,
    )
    assert [call.transport for call in calls] == ["https", "ssh"]
    assert calls[0].https_credentials is not None
    assert calls[0].https_credentials.host == "example.org"
    assert calls[1].ssh_credentials == run_wide


# --------------------------------------------------------------------------
# Ambient-config isolation: discriminating tests (no outbound traffic).
# --------------------------------------------------------------------------

def test_r4_tls_self_signed_classifies_without_ca_override(
    tmp_path: Path, stable_env
) -> None:
    """CONTROL: untrusted loopback TLS fails closed with zero fallback."""
    server = _StatusServer(tmp_path, status=503, body=b"")
    try:
        # No CA trust installed: production env must reject the handshake.
        # The alternate is file-mapped so a buggy fallback succeeds loudly
        # instead of touching the real network.
        url = server.url
        second_bare, _commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _v2_plan(
            [
                {"url": url, "authentication": "first",
                 "mirror_of": IDENTITY},
                {"url": second_url,
                 "authentication": "second", "mirror_of": IDENTITY},
            ]
        )
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        with pytest.raises(git_admission.GitAdmissionError) as captured:
            transport.acquire_plan(plan, git_admission.LockedCommit(
                "sha1", "0" * 40), tool)
        observed = _observed_first_class(captured.value)
        print(f"self-signed classification: {observed!r}")
        assert observed is not None
        assert repository_policy.classify_failure(observed) == "forbidden"
    finally:
        server.shutdown()


def test_ambient_insteadof_rewrite_is_never_applied(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """A hostile insteadOf rewrite must not deflect the literal attempt.

    The declared URL points at a loopback TLS server with an untrusted
    certificate; the hostile rewrite points at a closed port. A literal
    attempt fails in TLS (fail-closed, first failure); a rewritten attempt
    would fail refused and, under availability-auth, open the alternate.
    """
    server = _StatusServer(tmp_path, status=503, body=b"")
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        probe.bind(("127.0.0.1", 0))
        closed = probe.getsockname()[1]
        probe.close()
        home = tmp_path / "hostile-home"
        (home / ".ssh").mkdir(parents=True)
        (home / ".ssh" / "config").write_text(
            "Host 127.0.0.1\n  HostName 127.0.0.2\n", encoding="utf-8"
        )
        (home / ".gitconfig").write_text(
            f'[url "https://127.0.0.1:{closed}/"]\n'
            f"\tinsteadOf = https://127.0.0.1:{server.port}/\n",
            encoding="utf-8",
        )
        monkeypatch.setenv("HOME", os.fspath(home))
        monkeypatch.setenv("XDG_CONFIG_HOME", os.fspath(home / ".config"))
        monkeypatch.setenv("GIT_CONFIG_GLOBAL", os.fspath(home / ".gitconfig"))
        # The alternate is file-mapped so a deflected (refused) attempt would
        # fall back loudly instead of touching the real network.
        second_bare, _commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _v2_plan(
            [
                {"url": server.url, "authentication": "first",
                 "mirror_of": IDENTITY},
                {"url": second_url,
                 "authentication": "second", "mirror_of": IDENTITY},
            ]
        )
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        with pytest.raises(git_admission.GitAdmissionError) as captured:
            transport.acquire_plan(
                plan, git_admission.LockedCommit("sha1", "0" * 40), tool
            )
        observed = _observed_first_class(captured.value)
        # Refused/availability here would prove the rewrite was applied.
        assert observed not in {
            "dns", "connection-refused", "timeout", "endpoint-unavailable",
            "http-502", "http-503", "http-504", "auth-unavailable",
            "auth-rejected", "ssh-auth-rejected",
        }, f"attempt was deflected from the literal URL: {observed!r}"
        # Fail-closed first failure (specific domain code), not exhaustion.
        assert not isinstance(captured.value, transport.TransportResolutionError)
        assert observed == "tls"
    finally:
        server.shutdown()


def test_ambient_ssh_config_never_reaches_real_ssh(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """Real ssh through the production wrapper ignores ~/.ssh/config.

    The hostile config remaps 127.0.0.1 to 127.0.0.2; the observed refused
    record must name the literal declared host (visible in the chained
    CalledProcessError stderr), proving -F empty-config won.
    """
    real_ssh = shutil.which("ssh")
    assert real_ssh is not None
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    probe.bind(("127.0.0.1", 0))
    closed = probe.getsockname()[1]
    probe.close()
    home = tmp_path / "hostile-home"
    (home / ".ssh").mkdir(parents=True)
    (home / ".ssh" / "config").write_text(
        "Host 127.0.0.1\n  HostName 127.0.0.2\n", encoding="utf-8"
    )
    monkeypatch.setenv("HOME", os.fspath(home))
    creds = git_admission.OperatorSSHCredentials(
        identity=_ssh_identity(tmp_path / "operator"),
        known_hosts=_ssh_known_hosts(tmp_path / "operator"),
    )
    first_url = f"ssh://git@127.0.0.1:{closed}/kit.git"
    plan = _v2_plan(
        [{"url": first_url, "authentication": "first",
          "mirror_of": IDENTITY}],
        fallback="none",
    )
    endpoint = plan.endpoints[0]
    connection = transport._connection_target(endpoint)
    source = git_admission.RepositorySource(
        git=endpoint.url, identity=endpoint.identity,
        transport=endpoint.transport,
    )
    tool = _ssh_tool(Path(real_ssh), creds)
    with pytest.raises(git_admission.GitAdmissionError) as captured:
        git_admission.acquire_network(
            source,
            git_admission.LockedCommit("sha1", "0" * 40),
            tool,
            connection=connection,
        )
    assert captured.value.failure_class == "connection-refused"
    chained = captured.value.__cause__
    assert isinstance(chained, subprocess.CalledProcessError)
    stderr = chained.stderr.decode("utf-8", "replace")
    assert "127.0.0.1" in stderr, stderr
    assert "127.0.0.2" not in stderr, stderr


# --------------------------------------------------------------------------
# R5: one absolute deadline across both real attempts (no supplied sleeps).
# --------------------------------------------------------------------------

def test_r5_blackhole_first_attempt_starves_the_second(
    tmp_path: Path, stable_env
) -> None:
    """A real 3s blackhole fetch leaves no budget for the alternate."""
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("127.0.0.1", 0))
    listener.listen(5)
    listener.settimeout(10.0)
    blackhole = listener.getsockname()[1]
    held: list[socket.socket] = []

    def hold() -> None:
        # Accept and HOLD every connection open without a byte of reply:
        # the fetch must die by the transport's own subprocess timeout.
        try:
            while True:
                try:
                    connection, _ = listener.accept()
                except socket.timeout:
                    continue
                except OSError:
                    return
                held.append(connection)
                connection.settimeout(10.0)
                try:
                    while connection.recv(65536):
                        pass
                except (OSError, socket.timeout):
                    pass
        except OSError:
            pass

    holder = threading.Thread(target=hold, daemon=True)
    holder.start()
    try:
        second_bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(
            f"https://127.0.0.1:{blackhole}/kit.git", second_url
        )
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: second_bare},
            allow_loopback_https=True,
        )
        import time

        started = time.monotonic()
        with pytest.raises(transport.TransportResolutionError) as captured:
            transport.acquire_plan(
                plan, git_admission.LockedCommit("sha1", commit), tool,
                limits=git_admission.Limits(timeout_seconds=3.0),
            )
        elapsed = time.monotonic() - started
        # Only the first attempt ran: the shared deadline starved the second.
        assert len(captured.value.attempts) == 1
        assert captured.value.attempts[0].classification == "timeout"
        assert elapsed < 6.0
    finally:
        listener.close()
        for connection in held:
            try:
                connection.close()
            except OSError:
                pass

