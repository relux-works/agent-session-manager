import os,subprocess,pathlib,json,tempfile
out=pathlib.Path(__file__).resolve().parent; root=out/'candidate'; env={k:v for k,v in os.environ.items() if not k.startswith('TASK_BOARD_') and k!='CODEX_MANAGED_PACKAGE_ROOT'}; env.update(GOWORK='off',GOFLAGS='')
# Real Go interprets the retained-count-token mutant as zero executions.
cmd=['go','test','-count=1','./internal/spawn/','-count=0','-v']; q=subprocess.run(cmd,cwd=root/'tools/board-cli',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120); (out/'zero-count-real-go.log').write_text('COMMAND '+repr(cmd)+'\n'+q.stdout+f'\nEXIT={q.returncode}\n'); print('zero count real go',q.returncode,'RUN count',q.stdout.count('=== RUN'))
# Drive the exact mutated target with real make and Go, not stub make.
m=root/'Makefile'; orig=m.read_bytes()
try:
 m.write_text(orig.decode().replace('go test -count=1 ./cmd/ -run','go test -count=0 ./cmd/ -run',1)); q=subprocess.run(['make','test-docs-guards'],cwd=root,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120); (out/'docs-zero-real-make.log').write_text(q.stdout+f'\nEXIT={q.returncode}\n'); print('docs zero real make',q.returncode,q.stdout.strip())
finally:m.write_bytes(orig)
# Exact CI broad shell body in a real Go fixture. Selector prints fixture package.
s=(root/'.github/workflows/ci.yml').read_text(); body=s.split('      - name: Test CLI\n        run: |\n',1)[1].split('        working-directory:',1)[0]; body='\n'.join(x[10:] for x in body.splitlines())
f=pathlib.Path(tempfile.mkdtemp(prefix='fixture-',dir=out)); (f/'scripts').mkdir(parents=True,exist_ok=True); (f/'go.mod').write_text('module example.com/reviewfixture\n\ngo 1.25.5\n'); (f/'scripts/cli-broad-packages.sh').write_text('#!/bin/sh\nprintf "%s\\n" example.com/reviewfixture\n')
(f/'root_test.go').write_text('package reviewfixture\nimport "testing"\nfunc TestExpected(t *testing.T) { t.Fatal("sentinel failing test must fail lane") }\n')
for name,code in [('control',body),('masked',body.replace('$pkgs -v','$pkgs -run TestNonexistentGuard -v')),('swallowed',body.replace('$pkgs -v','$pkgs -v || true'))]:
 q=subprocess.run(['sh','-c',code],cwd=f,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120); (out/(name+'-real-body.log')).write_text(code+'\n'+q.stdout+f'\nEXIT={q.returncode}\n'); print(name,q.returncode,q.stdout.strip())
