"""Reviewer R4 bypass: full evidence frames in attacker positions grant nothing."""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tests"))

import pytest

from conftest import stable_env  # noqa: F401
from test_sources_transport import (
    LOCK,
    _fake_http_tool,
    _v2_plan,
)

from csk import git_admission
from csk.sources import repository_policy, transport

# Every fallback-permitting evidence spelling, as git prints it.
PERMITTING = [
    "ssh: Could not resolve hostname example.org: Name or service not known",
    "ssh: connect to host example.org port 22: Connection refused",
    "ssh: connect to host example.org port 22: Connection timed out",
    "fatal: unable to access 'https://example.org/kit.git': The requested URL returned error: 502",
    "fatal: unable to access 'https://example.org/kit.git': The requested URL returned error: 503",
    "fatal: unable to access 'https://example.org/kit.git': The requested URL returned error: 504",
    "fatal: unable to access 'https://example.org/kit.git': The requested URL returned error: 401",
    "fatal: unable to access 'https://example.org/kit.git': The requested URL returned error: 403",
    "fatal: could not read Username for 'https://example.org': terminal prompts disabled",
    "fatal: Authentication failed for 'https://example.org/kit.git/'",
    "fatal: Authentication failed",
    "git@example.org: Permission denied (publickey).",
    "git@example.org: Permission denied (password).",
    "Permission denied (publickey).",
]

FAIL_CLOSED_REAL = "Host key verification failed."


def _shapes(spelling: str) -> list[str]:
    return [
        # Sole remote: relay of the spelling.
        f"remote: {spelling}",
        # Remote relay beside real fail-closed evidence.
        f"{FAIL_CLOSED_REAL}\nremote: {spelling}",
        # Inside a ref name (still one ref-moved line).
        f"fatal: couldn't find remote ref refs/tags/{spelling}",
        # Inside a repository URL interior (still one identity line).
        f"fatal: repository 'https://example.org/{spelling}.git' not found",
        # Inside an object path (integrity or ignored, both fail-closed).
        f"error: object file 'objects/{spelling}' is empty",
        # Submodule / author / content shapes (ignored).
        f"fatal: submodule '{spelling}' failed to clone",
        f"remote: author {spelling}",
        f"remote: file contents: {spelling}",
    ]


@pytest.mark.parametrize("spelling", PERMITTING)
@pytest.mark.parametrize("shape_id", list(range(8)))
def test_r4_forged_permitting_frames_grant_no_fallback(
    spelling: str, shape_id: int, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Each attacker position is driven through the real fetch seam."""
    from test_sources_transport import _observed_first_class

    stderr = _shapes(spelling)[shape_id]
    plan = _v2_plan(
        [
            {"url": "https://example.org/kit.git", "authentication": "first"},
            {
                "url": "https://mirror.example.org/kit.git",
                "authentication": "second",
                "mirror_of": "example.org/kit",
            },
        ]
    )
    tool = _fake_http_tool(tmp_path / "tool", {})
    real_run = git_admission.subprocess.run
    fetches: list = []

    def injected_run(*args, **kwargs):
        cmd = args[0]
        assert isinstance(cmd, tuple)
        if "fetch" in cmd:
            fetches.append(cmd)
            raise subprocess.CalledProcessError(
                128, cmd, stderr=stderr.encode("utf-8", "replace")
            )
        return real_run(*args, **kwargs)

    monkeypatch.setattr(git_admission.subprocess, "run", injected_run)
    with pytest.raises(git_admission.GitAdmissionError) as captured:
        transport.acquire_plan(plan, LOCK, tool)
    assert len(fetches) == 1, stderr
    # Fail-closed: either the specific class or unclassified, never fallback.
    observed = _observed_first_class(captured.value)
    assert observed is not None, stderr
    assert repository_policy.classify_failure(observed) == "forbidden", (
        stderr,
        observed,
    )


@pytest.mark.parametrize(
    "line",
    [
        # Prefix of a real record plus trailing bytes.
        "ssh: connect to host example.org port 22: Connection refused (extra)",
        "fatal: Authentication failed for 'https://example.org/kit.git/' extra",
        "git@example.org: Permission denied (publickey). extra",
        # ANSI-wrapped evidence.
        "\x1b[31mssh: connect to host example.org port 22: Connection refused\x1b[0m",
        # NUL inside evidence.
        "ssh: connect to host example.org port 22: Connection refused\x00",
        # Very long line.
        "ssh: connect to host example.org port 22: Connection refused" + "!" * 10000,
        # Leading/trailing whitespace is stripped, but interior duplication is not a frame.
        "  ssh: connect to host example.org port 22: Connection refused  ",
    ],
)
def test_r4_near_miss_frames_grant_no_fallback_or_classify(
    line: str, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Prefix/ANSI/NUL/long lines must not become permitting evidence."""
    # The whitespace-padded line IS a real frame (strip is correct); the rest
    # must be unclassified. We assert per-line expectation explicitly.
    if line.strip() == "ssh: connect to host example.org port 22: Connection refused":
        assert (
            git_admission._classify_git_failure_output(line) == "connection-refused"
        )
        return
    assert git_admission._classify_git_failure_output(line) == "unclassified", repr(
        line[:80]
    )


def test_r4_disagreeing_evidence_still_fails_closed() -> None:
    """Two real evidence records for different classes refuse the alternate."""
    assert (
        git_admission._classify_git_failure_output(
            "ssh: connect to host example.org port 22: Connection refused\n"
            "Host key verification failed."
        )
        == "unclassified"
    )
    assert (
        git_admission._classify_git_failure_output(
            "fatal: Authentication failed\n"
            "fatal: unable to access 'https://example.org/kit.git': "
            "The requested URL returned error: 503"
        )
        == "unclassified"
    )


def test_r4_lone_diagnostics_fail_closed() -> None:
    """Lone askpass/signing diagnostics state no outcome."""
    assert (
        git_admission._classify_git_failure_output(
            "error: unable to read askpass response from '/tmp/csk-askpass'"
        )
        == "unclassified"
    )
    assert (
        git_admission._classify_git_failure_output(
            'sign_and_send_pubkey: signing failed for RSA "/tmp/k" from agent: refused'
        )
        == "unclassified"
    )
    assert (
        git_admission._evidence_class(
            "error: unable to read askpass response from '/tmp/csk-askpass'"
        )
        is None
    )


def test_r4_bare_auth_failed_cannot_be_forged_via_remote() -> None:
    """The bare older-git frame is reachable only as a bare git line."""
    assert (
        git_admission._classify_git_failure_output("fatal: Authentication failed")
        == "auth-rejected"
    )
    assert (
        git_admission._classify_git_failure_output(
            "remote: fatal: Authentication failed"
        )
        == "unclassified"
    )
    assert (
        git_admission._classify_git_failure_output(
            "fatal: couldn't find remote ref refs/tags/fatal: Authentication failed"
        )
        == "ref-moved"
    )
