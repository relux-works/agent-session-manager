from pathlib import Path
import pytest
from csk.sources.selection import expand_collection, resolve_individual
from csk.sources.skillfile_v2 import CollectionSelector, IndividualSelector
from csk.sources.errors import SourceError

def drive(root, entry, directory='skill'):
    if entry == 'individual':
        return resolve_individual(root, IndividualSelector(name='review', from_alias='local', directory=directory))
    return expand_collection(root, CollectionSelector(from_alias='local', directory='.', include=(directory,), exclude=()))

@pytest.mark.parametrize('entry', ['individual', 'collection'])
def test_comment_only_description_refused(tmp_path, entry):
    member = tmp_path / 'skill'
    member.mkdir()
    (member / 'SKILL.md').write_text('---\nname: review\ndescription: # only a comment\n---\n')
    with pytest.raises(SourceError) as error:
        drive(tmp_path, entry)
    assert error.value.code == 'source_member_invalid'

@pytest.mark.parametrize('entry', ['individual', 'collection'])
def test_quoted_description_with_comment_accepted(tmp_path, entry):
    member = tmp_path / 'skill'
    member.mkdir()
    (member / 'SKILL.md').write_text('---\nname: review\ndescription: "A valid description" # comment\n---\n')
    drive(tmp_path, entry)

@pytest.mark.parametrize('entry', ['individual', 'collection'])
def test_explicit_managed_package_refused(tmp_path, entry):
    member = tmp_path / '.agents'
    member.mkdir()
    (member / 'SKILL.md').write_text('---\nname: review\ndescription: Generated output\n---\n')
    with pytest.raises(SourceError):
        drive(tmp_path, entry, '.agents')
