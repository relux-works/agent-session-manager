import os,pathlib,subprocess,time,json
out=pathlib.Path(__file__).resolve().parent; root=out/'candidate'
env={k:v for k,v in os.environ.items() if not k.startswith('TASK_BOARD_') and k!='CODEX_MANAGED_PACKAGE_ROOT'}; env['GOWORK']='off'
ci='.github/workflows/ci.yml'; mk='Makefile'; script='tools/board-cli/scripts/cli-broad-packages.sh'
mask='Test(GuardManifest|StandaloneGuard|TheSpawnGuard|Broad|CIDocs|DocsGuard|ExternalInput|ParseGuard|PartitionModule|StandaloneUnmasked|UnmaskedRuns|MakeLane|UncachedScan|DocsDelegation)'
cases=[
('echo-spawn',ci,'run: go test -count=1 ./internal/spawn/ -v','run: echo go test -count=1 ./internal/spawn/ -v'),
('zero-count-spawn',ci,'go test -count=1 ./internal/spawn/ -v','go test -count=1 ./internal/spawn/ -count=0 -v'),
('cached-extra-spawn',ci,'      - name: Test CLI','      - name: Extra spawn\n        run: go test ./internal/spawn/ -v\n        working-directory: tools/board-cli\n\n      - name: Test CLI'),
('masked-broad',ci,'go test -p 2 -timeout 90m $pkgs -v','go test -p 2 -timeout 90m $pkgs -run TestNonexistentGuard -v'),
('duplicate-broad-make',mk,'go test $$pkgs -v; }','go test $$pkgs -v; go test $$pkgs -v; }'),
('zero-count-docs',mk,"go test -count=1 ./cmd/ -run", "go test -count=0 ./cmd/ -run"),
('duplicate-spawn-kill',ci,'      - name: Test CLI','      - name: Extra spawn\n        run: go test -count=1 ./internal/spawn/ -v\n        working-directory: tools/board-cli\n\n      - name: Test CLI'),
('selector-omit-store-kill',script,'    print','    if ($0 == module "/internal/store") next\n    print'),
('ignore-output-kill',ci,'go test -p 2 -timeout 90m $pkgs -v','go test -p 2 -timeout 90m ./... -v'),
('echo-docs-kill',ci,'run: make test-docs-guards','run: echo make test-docs-guards'),
('empty-check-narrow-kill',ci,'[ -n "$pkgs" ] ||','[ -n "$pkgs" ] || true ||'),
('masked-spawn-kill',ci,'go test -count=1 ./internal/spawn/ -v','go test -count=1 ./internal/spawn/ -run TestNonexistentGuard -v'),
]
rows=[]
for name,path,old,new in cases:
 p=root/path; original=p.read_bytes(); text=original.decode(); assert old in text,name
 try:
  p.write_text(text.replace(old,new,1)); start=time.monotonic()
  proc=subprocess.run(['go','test','-count=1','./internal/ciguard/','-run',mask,'-v'],cwd=root/'tools/board-cli',env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180)
  row=dict(name=name,exit=proc.returncode,wall=round(time.monotonic()-start,3),failures=[x for x in proc.stdout.splitlines() if x.startswith('--- FAIL')],tests=sum(x.startswith('=== RUN   Test') for x in proc.stdout.splitlines()))
  (out/(name+'.log')).write_text(proc.stdout+'\n'+json.dumps(row)+'\n'); rows.append(row); print(json.dumps(row),flush=True)
 finally:p.write_bytes(original); assert p.read_bytes()==original
 (out/'attacks.json').write_text(json.dumps(rows,indent=2))
