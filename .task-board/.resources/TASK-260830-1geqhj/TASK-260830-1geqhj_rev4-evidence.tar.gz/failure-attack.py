import pathlib,os,subprocess,time,json
out=pathlib.Path(__file__).resolve().parent; root=out/'candidate'; p=root/'.github/workflows/ci.yml'; original=p.read_bytes(); env={k:v for k,v in os.environ.items() if not k.startswith('TASK_BOARD_') and k!='CODEX_MANAGED_PACKAGE_ROOT'}; env['GOWORK']='off'
mask='Test(GuardManifest|StandaloneGuard|TheSpawnGuard|Broad|CIDocs|DocsGuard|ExternalInput|ParseGuard|PartitionModule|StandaloneUnmasked|UnmaskedRuns|MakeLane|UncachedScan|DocsDelegation)'
try:
 p.write_text(original.decode().replace('go test -p 2 -timeout 90m $pkgs -v','go test -p 2 -timeout 90m $pkgs -v || true',1)); s=time.monotonic()
 q=subprocess.run(['go','test','-count=1','./internal/ciguard/','-run',mask,'-v'],cwd=root/'tools/board-cli',env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
 row=dict(name='swallowed-broad-failure',exit=q.returncode,wall=round(time.monotonic()-s,3),tests=sum(x.startswith('=== RUN   Test') for x in q.stdout.splitlines()),failures=[x for x in q.stdout.splitlines() if x.startswith('--- FAIL')]); (out/'swallowed-broad-failure.log').write_text(q.stdout+'\n'+json.dumps(row)+'\n'); print(row)
finally:p.write_bytes(original)
