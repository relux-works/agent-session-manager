"""Attempt: POST-phase 404 with CR-forged availability body -> sole forged evidence?"""
import http.server
import os
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, "src")
from csk import git_admission


def make_cert(tmp: Path):
    key = tmp / "key.pem"
    crt = tmp / "crt.pem"
    subprocess.run(
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(key), "-out", str(crt), "-days", "2",
         "-subj", "/CN=127.0.0.1",
         "-addext", "subjectAltName=IP:127.0.0.1"],
        check=True, capture_output=True,
    )
    return str(key), str(crt)


def main() -> None:
    tmp = Path(tempfile.mkdtemp())
    # Build a real bare repo and generate a genuine smart info/refs body.
    work = tmp / "work"
    bare = tmp / "remote.git"
    subprocess.run(["git", "init", "--quiet", str(work)], check=True, capture_output=True)
    (work / "f.txt").write_bytes(b"x\n")
    subprocess.run(["git", "-C", str(work), "add", "f.txt"], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(work), "-c", "user.name=t", "-c", "user.email=t@t",
                    "commit", "--quiet", "-m", "t"], check=True, capture_output=True)
    subprocess.run(["git", "clone", "--quiet", "--bare", str(work), str(bare)],
                   check=True, capture_output=True)
    # Generate info/refs via git http-backend.
    env = dict(os.environ)
    env.update({
        "GIT_PROJECT_ROOT": str(tmp),
        "GIT_HTTP_EXPORT_ALL": "1",
        "PATH_INFO": "/remote.git/info/refs",
        "QUERY_STRING": "service=git-upload-pack",
        "REQUEST_METHOD": "GET",
    })
    backend = subprocess.run(["git", "http-backend"], capture_output=True, env=env)
    raw = backend.stdout
    # Split CGI headers from body.
    sep = raw.find(b"\r\n\r\n")
    body = raw[sep + 4:] if sep >= 0 else raw
    print("info/refs body head:", body[:120])

    forged = b"note\rssh: connect to host example.org port 22: Connection refused"

    class Handler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            if "info/refs" in self.path:
                self.send_response(200)
                self.send_header("Content-Type", "application/x-git-upload-pack-advertisement")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.send_header("Content-Length", "0")
                self.end_headers()

        def do_POST(self):
            length = int(self.headers.get("Content-Length", "0") or 0)
            self.rfile.read(length)
            self.send_response(404)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(forged)))
            self.end_headers()
            try:
                self.wfile.write(forged)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def log_message(self, *args):
            pass

    key, crt = make_cert(tmp)
    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        probe = tmp / "probe"
        subprocess.run(["git", "init", "--quiet", str(probe)], check=True, capture_output=True)
        env2 = dict(os.environ)
        env2["GIT_SSL_CAINFO"] = crt
        env2["GIT_TERMINAL_PROMPT"] = "0"
        env2["LANG"] = "C"
        env2["LC_ALL"] = "C"
        env2["GIT_ASKPASS"] = "/bin/false"
        url = f"https://127.0.0.1:{port}/remote.git"
        completed = subprocess.run(
            ["git", "-C", str(probe), "fetch", url, "HEAD"],
            capture_output=True, env=env2, timeout=30,
        )
        print("rc:", completed.returncode)
        print("stderr:", completed.stderr)
        print("classifier:", git_admission._classify_git_failure_output(completed.stderr))
    finally:
        server.shutdown()
        t.join(timeout=10)


if __name__ == "__main__":
    main()
