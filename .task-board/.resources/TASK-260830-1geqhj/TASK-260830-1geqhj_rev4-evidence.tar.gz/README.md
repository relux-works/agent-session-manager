# TASK-260830-24z2b3 producer evidence (rev4)

Rework of review RUN-260917-62d051. Candidate on base 2fc6d50, left
UNCOMMITTED in .temp/STORY-260830-1cyj0q/worktree.

- cmd01.log … cmd27.log: the 27 configured validation commands, in order.
- pkg-test.log, pkg-cover.log, pkg-race.log: package suite (verbose, cover, race).
- mutants-run1.log, mutants-run2.log: full 65-row battery verdict lines, two runs.
- mutants/run1/, mutants/run2/: one raw go test log per plant per run with `# exit=`.
- rev3-probes.log: reviewer rev3 probe battery against the new tree (throwaway run).
- MANIFEST.sha256: sha256 of every file in this archive.
