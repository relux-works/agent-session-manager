# TASK-260830-24z2b3 Results — implement-clone-bundle-and-canonical-session-types (rev4)

Status: ready for review. Candidate left UNCOMMITTED in the Story
worktree (`task-board/story/STORY-260830-1cyj0q`) on base `2fc6d50`
(`origin/main` at handoff; refreshed from `888ae3d` via
`task-board worktree refresh-candidate`); no commit on the Story
branch. This is rework rev4 of review RUN-260917-62d051, which
routed rev3 CHANGES REQUESTED with one P1, three P2, and seven P3
findings (every rev2 finding verified fixed). Every finding is
answered below with the change, the test that fails without it,
and the evidence path.

## Start-of-run recovery note

When this run started, the worktree carried exactly the rev3
candidate and nothing else: `M LOGBOOK.md`, `M README.md`,
`?? internal/clonebundle/` (19 files + `testdata/mutant_harness.py`,
matching the 21-path rev3 tree). No dead-attempt changes were
present; verified with `git status` and `git diff` before the
refresh, and every pre-existing change matches this brief's scope.

The refresh replayed stale pre-v0.7.0 bytes into 30 trunk paths in
the working tree (catalog/specdoc/specpin/traceability/`.task-board`
reverted to v0.6.0 content, e.g. `catalog.Adopted = ReleaseV060`).
Repaired by restoring trunk content (`git checkout HEAD -- .`) and
re-applying the README section and LOGBOOK entry purely additively
on top of the new trunk bytes; `task-board.config.json` ends
byte-identical to HEAD. `git status` shows only candidate paths.
No `internal/traceability` edit (FINAL leaf carries bindings +
re-pin). `SPEC.v0.7.0.md` §1.6 and §13.14.1 verified byte-identical
to v0.6.0 (diff of the extracted sections, empty); authority cited
as v0.7.0 with the same heading numbers.

## Finding-by-finding table

| Finding | Change | Test that fails without it | Evidence |
|---|---|---|---|
| P1-c non-message payloads escape the number model + nested-duplicate rule at Build and Decode | `checkPayload` (`event.go`) runs `checkPayloadValues` — the shared value walker — over the whole payload for every kind, then decodes with `UseNumber` and converts to exact int64 (`convertPayloadNumbers`); host float64 never appears, so sealed bytes cannot round or collapse. Shape faults report as payload faults (`errPayloadShape`, `decode.go`) | `TestCanonicalEventPayloadValueModel`: build negatives (1.5, 2^53, 2^53+1, -(2^53), 2^60, 1e2, nested/array-nested duplicates across usage/tool_call/opaque_event/error), decode negatives, resealed-decode negatives, sealed-bytes exactness (2^53-1, -(2^53-1), nested), message regression, 300-deep bound | `pkg-test.log`, `mutants/run1/N-payload-number.log`, `mutants/run2/N-payload-number.log` |
| P2-α extension-value gate measured at 2 of 17 sites | `TestExtensionValueModelAtEverySite`: one value-fault row per admission site (16 decode sites + shared build helper), all injecting `{"com.example.n":1.5}`; the two payload-level rows pin the site detail (`message payload extensions`, `content block[0] extensions`) because the whole-payload gate also refuses there | Each of the 17 `N-ext-values-*` harness rows kills exactly its row | `pkg-test.log`, `mutants/run1/N-ext-values-*.log`, `mutants/run2/N-ext-values-*.log` (17 logs per run) |
| P2-β decode equal-key duplicate raw entry unmeasured | Decode `duplicate entries` row added to `TestRawManifestRefusals/decode` (code already refused) | `TestRawManifestRefusals/decode/duplicate_entries` | `mutants/run1/N-raw-order-decode.log`, `mutants/run2/N-raw-order-decode.log` |
| P2-γ duplicate plan keys defeat one-per-plan-candidate | `checkPlanItemMatch` (`capturebuild.go`) refuses duplicate plan keys outright | `TestCaptureManifestRefusals/build_plan_match` (plan `[a,a,token]` case, the P5c vector) | `mutants/run1/N-plan-keys-dup.log`, `mutants/run2/N-plan-keys-dup.log` |
| P3-a′ content `null` passes the XOR | XOR is a non-null test (`event.go`); null content and null descriptor both refuse as not-exclusive | `block null content`, `block null descriptor` rows in `TestCanonicalEventRefusals/build_envelope` | `pkg-test.log`, `mutants/run1/N-block-content-null.log`, `mutants/run2/N-block-content-null.log` |
| P3-b′ refusal detail misreports value faults | `captureitem.go`, `session.go`, `event.go` block site use `%s` with the fault like the other 13 sites | `TestExtensionValueModelAtEverySite/capture_item`, `/actor`, `/content_block` assert the fault text (`safe-integer` / site detail) | `pkg-test.log` |
| P3-c′ input_blocked arm unmeasured | `closed_store input_blocked false` row in `TestBoundaryRefusals/decode stable proof` | same row | `mutants/run1/N-proof-input-blocked.log`, `mutants/run2/N-proof-input-blocked.log` |
| P3-c′ -(2^53) arm unmeasured | `decode negative 2^53` row in `TestRawManifestRefusals/extension_values` | same row | `mutants/run1/N-ax-number-negative-edge.log`, `mutants/run2/N-ax-number-negative-edge.log` |
| P3-c′ Zp arm unmeasured | U+2029 row in the `TestIdentityRefusals/sanitizer` corpus | same corpus | `mutants/run1/N-sanitizer-zp.log`, `mutants/run2/N-sanitizer-zp.log` |
| P3-c′ payload top-level duplicate unmeasured | `payload top-level duplicate` row in `TestCanonicalEventRefusals/build_envelope` (pins `duplicate member`) | same row | `mutants/run1/N-payload-top-dup.log`, `mutants/run2/N-payload-top-dup.log` |
| P3-c′ decode external-null-parent unmeasured | `external null parent` row in `TestCanonicalSessionRefusals/decode` | same row | `mutants/run1/N-decode-external-null-parent.log`, `mutants/run2/N-decode-external-null-parent.log` |
| P3-d′ `EncodeNativeIdentity` rounds unsafe extensions | The exported entry validates extensions via `encodeExtensions` (`identity.go`); the "never admits what decoding refused" sentence is now true. The bad-extensions `IdentityDigest` row now fires at encode (`reverse-DNS`) | `TestEncodeNativeIdentityRefusals` (2^60 refuses, bad key refuses, valid round-trips) | `pkg-test.log`, `mutants/run1/N-encode-identity-extensions.log`, `mutants/run2/N-encode-identity-extensions.log` |
| P3-e′ `N-main-count` note over-claims | Split into per-site `N-main-count-build` + `N-main-count-decode`, each with its site's killer | `TestCanonicalSessionRefusals/build_actors/two_mains`, `/decode/two_mains` | both per-plant logs per run |
| P3-f′ dead code | Removed `sourceBasisObject`, `digestOrEmpty`, `digestOrEmptyDigest` (`boundary.go`; no callers) | `go vet`, suite | `cmd03.log`, `pkg-test.log` |
| P3-g′ census arms | Rows added: version≠1.0.0 at capture/session/event decode; entries/items/actors/raw_refs not-an-array; 65536 entries/items/raw_refs, 1024 actors, 128 reason-codes maxima; build byte_count/ordinal/offset/length uint53 overflows; invalid-UTF-8 sanitizer row. Stated as defense-in-depth in TRACEABILITY.md: descriptor member-parse arms (owner enforces first), total_bytes overflow (unreachable with real payloads), C1-beyond-U+0085 / fraction-subsumption / exact depth edge (informational) | the named rows in `TestRawManifestRefusals`, `TestCaptureManifestRefusals`, `TestCanonicalSessionRefusals`, `TestCanonicalEventRefusals`, `TestIdentityRefusals/sanitizer` | `pkg-test.log` |

Also: `doc.go` and `TRACEABILITY.md` authority moved to
`SPEC.v0.7.0.md`; the value-model bound restated (fact registry
stays sibling scope, the §1.6 value model is enforced here for
every payload member); the `C-doc-comment` control anchor follows
the authority line.

## AC coverage: 18 of 18 rows driven

See `TASK-260830-24z2b3_conformance-matrix.md` (rev4): every row
names its production call site and driving test. Strengthened rows
since rev3: 4 (Zp + invalid-UTF-8 sanitizer rows), 6 (decode item
rules + version/not-array/maxima rows), 7 (XOR null arms), 10
(duplicate plan keys), 12/13 (per-site extension rows,
input_blocked), 15 (encode-time extension validation), 16/17
(decode actor/event rows + payload value model), 18 (unchanged,
still linked).

## Validation reran in rev4 (this run, final tree)

- Commands 1-3 (`gofmt` check, `go build ./...`, `go vet ./...`):
  PASS (`cmd01.log`, `cmd02.log`, `cmd03.log`)
- Command 4 (`go test ./... -count=1 -v`): PASS, 16950 passes,
  no FAIL (`cmd04.log`)
- Command 5 (`go test ./... -race -count=1 -timeout 25m`): PASS,
  38 packages ok, zero `DATA RACE` lines
  (`ok internal/sessquery 390.722s`, `ok internal/clonebundle
  4.369s`) (`cmd05.log`)
- Command 6 (`go test ./... -cover -count=1`): PASS, 38 packages
  ok, clonebundle 86.8% statements (`cmd06.log`)
- Commands 7-20 (fuzz smokes, 14 targets): PASS
  (`cmd07.log` … `cmd20.log`)
- Commands 21-22 (`tracecheck`, `cataloggen -adopted -check`):
  PASS (`cmd21.log`, `cmd22.log`)
- Commands 23-24 (`GOOS=linux/windows` builds): PASS
  (`cmd23.log`, `cmd24.log`)
- Commands 25-27 (JSON validation, `task-board validate`,
  `git diff --check`): PASS (`cmd25.log`, `cmd26.log`, `cmd27.log`)
- Package suite: PASS (`pkg-test.log`), 86.8% statements
  (`pkg-cover.log`); package race PASS (`pkg-race.log`)
- Mutant harness: 64 KILLED + 1 SURVIVED control, full battery run
  twice with per-plant raw logs (`mutants/run1/*.log`,
  `mutants/run2/*.log`, `mutants-run1.log`, `mutants-run2.log`),
  `PYTHONDONTWRITEBYTECODE=1`, no `__pycache__`
- No `internal/traceability` edit; candidate paths only in
  `git status` (plus the untracked package dir, same as rev3)
- Reviewer-vector confirmation: the rev3 probe battery
  (`zz_rev3_probe_test.go.txt`) executed once against the new tree
  in a throwaway run (file removed afterwards; `rev3-probes.log`):
  all 28 N1 build vectors and all 7 N2 resealed-decode vectors
  REFUSE; P5c/P7d/P7e/P20c refuse; P2u now refuses (intended P3-d
  behavior change); safe edges and valid shapes still admit

## Bounds for siblings (not waived)

- Per-kind event payload fact registries: which facts a kind may
  carry (normalization sibling). The §1.6 value model on every
  payload member is enforced here, not bounded away.
- `maximal_safe` projection planning past
  `RefuseMaximalSafeUnlessComplete` (projection sibling).
- Target-branch (G2) admission past `RefuseUnstableForTarget`.
- Section 7.8 operation wiring (stays `sessadapter`).
- `-0`/`+n`/leading-zero literals admit by
  `canonicaljson.validateAXNumbers` parity (stated, not waived).
- `internal/traceability` bindings + re-pin (FINAL leaf).

## Attachments

- `TASK-260830-24z2b3_conformance-matrix.md` (rev4)
- `TASK-260830-24z2b3_producer-evidence.tar.gz` (rev4 logs:
  27-command suite, package suite, 2x64+1 mutant battery with
  per-plant logs, file manifest)
