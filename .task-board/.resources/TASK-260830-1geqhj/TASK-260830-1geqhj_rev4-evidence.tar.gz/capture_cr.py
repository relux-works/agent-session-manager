"""Capture raw git stderr for CR-in-body hostile payloads."""
import http.server
import os
import shutil
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, "src")
sys.path.insert(0, "tests")

from csk import git_admission


def make_cert(tmp: Path):
    key = tmp / "key.pem"
    crt = tmp / "crt.pem"
    subprocess.run(
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(key), "-out", str(crt), "-days", "2",
         "-subj", "/CN=127.0.0.1",
         "-addext", "subjectAltName=IP:127.0.0.1"],
        check=True, capture_output=True,
    )
    return str(key), str(crt)


class Handler(http.server.BaseHTTPRequestHandler):
    body = b""
    status = 503

    def _respond(self):
        self.send_response(type(self).status)
        self.send_header("Content-Type", "text/plain")
        self.send_header("Content-Length", str(len(type(self).body)))
        self.end_headers()
        try:
            self.wfile.write(type(self).body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    do_GET = _respond
    do_POST = _respond

    def log_message(self, *args):
        pass


def capture(body: bytes, status: int = 503) -> bytes:
    tmp = Path(tempfile.mkdtemp())
    key, crt = make_cert(tmp)
    Handler.body = body
    Handler.status = status
    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        work = tmp / "work"
        git = shutil.which("git")
        subprocess.run([git, "init", "--quiet", str(work)], check=True, capture_output=True)
        env = dict(os.environ)
        env["GIT_SSL_CAINFO"] = crt
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["LANG"] = "C"
        env["LC_ALL"] = "C"
        env["GIT_ASKPASS"] = "/bin/false"
        # Use a failing askpass shape? No, just run ls-remote to see body echo.
        url = f"https://127.0.0.1:{port}/kit.git"
        completed = subprocess.run(
            [git, "-C", str(work), "ls-remote", url],
            capture_output=True, env=env, timeout=30,
        )
        print(f"=== body={body!r} status={status} rc={completed.returncode} ===")
        print("STDERR bytes:", completed.stderr)
        print("STDERR repr lines:", completed.stderr.decode("utf-8", "replace").splitlines())
        print("classifier:", git_admission._classify_git_failure_output(completed.stderr))
        print()
        return completed.stderr
    finally:
        server.shutdown()
        t.join(timeout=10)


if __name__ == "__main__":
    # Baseline: plain text body
    capture(b"hello-world", 503)
    # Body containing a full evidence spelling (should be remote:-prefixed, ignored)
    capture(b"ssh: connect to host example.org port 22: Connection refused", 503)
    # Body with embedded CR + evidence spelling
    capture(b"foo\rssh: connect to host example.org port 22: Connection refused", 503)
    # Body with embedded LF + evidence spelling
    capture(b"foo\nssh: connect to host example.org port 22: Connection refused", 503)
    # Body with CR + bare auth-failed
    capture(b"foo\rFatal: Authentication failed", 503)
    # Body with CR + different class vs real (503 real, CR injects host-key)
    capture(b"foo\rHost key verification failed.", 503)
    # Fail-closed real (404) with CR-injected availability
    capture(b"foo\rssh: connect to host example.org port 22: Connection refused", 404)
