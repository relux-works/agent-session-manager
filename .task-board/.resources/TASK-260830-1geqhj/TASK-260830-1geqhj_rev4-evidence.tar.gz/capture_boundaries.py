"""Reviewer: CR and unicode line boundaries smuggle unprefixed evidence."""
import http.server
import os
import shutil
import ssl
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

sys.path.insert(0, "src")
sys.path.insert(0, "tests")

from csk import git_admission


def make_cert(tmp: Path):
    key = tmp / "key.pem"
    crt = tmp / "crt.pem"
    subprocess.run(
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(key), "-out", str(crt), "-days", "2",
         "-subj", "/CN=127.0.0.1",
         "-addext", "subjectAltName=IP:127.0.0.1"],
        check=True, capture_output=True,
    )
    return str(key), str(crt)


def capture_raw(body: bytes, status: int = 503) -> bytes:
    tmp = Path(tempfile.mkdtemp())
    key, crt = make_cert(tmp)

    class Handler(http.server.BaseHTTPRequestHandler):
        def _respond(self):
            self.send_response(status)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        do_GET = _respond
        do_POST = _respond

        def log_message(self, *args):
            pass

    server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    try:
        work = tmp / "work"
        git = shutil.which("git")
        subprocess.run([git, "init", "--quiet", str(work)], check=True, capture_output=True)
        env = dict(os.environ)
        env["GIT_SSL_CAINFO"] = crt
        env["GIT_TERMINAL_PROMPT"] = "0"
        env["LANG"] = "C"
        env["LC_ALL"] = "C"
        env["GIT_ASKPASS"] = "/bin/false"
        url = f"https://127.0.0.1:{port}/kit.git"
        completed = subprocess.run(
            [git, "-C", str(work), "ls-remote", url],
            capture_output=True, env=env, timeout=30,
        )
        return completed.stderr
    finally:
        server.shutdown()
        t.join(timeout=10)


CASES = [
    ("CR", b"foo\rHost key verification failed.", "unclassified?"),
    ("VT", b"foo\x0bHost key verification failed.", "unclassified?"),
    ("FF", b"foo\x0cHost key verification failed.", "unclassified?"),
    ("NEL", "foo\x85Host key verification failed.".encode("utf-8"), "unclassified?"),
    ("LS", "foo\u2028Host key verification failed.".encode("utf-8"), "unclassified?"),
    ("CRLF", b"foo\r\nHost key verification failed.", "http-503?"),
    ("NUL", b"foo\x00Host key verification failed.", "http-503?"),
    ("ANSI", b"foo\x1b[31mHost key verification failed.", "http-503?"),
]

for name, body, expect in CASES:
    raw = capture_raw(body, 503)
    cls = git_admission._classify_git_failure_output(raw)
    lines = raw.decode("utf-8", "replace").splitlines()
    print(f"{name}: classifier={cls} (expect {expect})")
    print(f"  raw={raw!r}")
    print(f"  splitlines={lines}")
    print()
