"""Reviewer R4: CR/VT smuggling suppresses mandated fallback via real server."""
import http.server
import os
import shutil
import socket
import ssl
import subprocess
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tests"))
sys.path.insert(0, str(Path.cwd() / "src"))

import pytest

from conftest import stable_env  # noqa: F401
from test_sources_transport import (
    _bare_repository,
    _fake_http_tool,
    _https_mirror_plan,
    _observed_first_class,
)

from csk import git_admission
from csk.build_repository import LockedCommit
from csk.sources import repository_policy, transport

pytestmark = pytest.mark.skipif(
    os.name == "nt",
    reason="reviewer loopback TLS fixture relies on POSIX exec semantics",
)


def _cert(tmp_path: Path):
    key = tmp_path / "key.pem"
    crt = tmp_path / "crt.pem"
    subprocess.run(
        ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
         "-keyout", str(key), "-out", str(crt), "-days", "2",
         "-subj", "/CN=127.0.0.1",
         "-addext", "subjectAltName=IP:127.0.0.1"],
        check=True, capture_output=True,
    )
    return str(key), str(crt)


class _Server:
    def __init__(self, key, crt, body: bytes, status: int):
        self.body = body
        self.status = status
        outer = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def _respond(self):
                self.send_response(outer.status)
                self.send_header("Content-Type", "text/plain")
                self.send_header("Content-Length", str(len(outer.body)))
                self.end_headers()
                try:
                    self.wfile.write(outer.body)
                except (BrokenPipeError, ConnectionResetError):
                    pass

            do_GET = _respond
            do_POST = _respond

            def log_message(self, *args):
                pass

        self._srv = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(crt, key)
        self._srv.socket = ctx.wrap_socket(self._srv.socket, server_side=True)
        self.port = self._srv.server_address[1]
        self._t = threading.Thread(target=self._srv.serve_forever, daemon=True)
        self._t.start()

    @property
    def url(self):
        return f"https://127.0.0.1:{self.port}/kit.git"

    def close(self):
        self._srv.shutdown()
        self._t.join(timeout=10)


@pytest.mark.parametrize(
    ("name", "body"),
    [
        ("cr-host-key", b"status-page\rHost key verification failed."),
        ("cr-refused", b"status-page\rssh: connect to host example.org port 22: Connection refused"),
        ("vt-host-key", b"status-page\x0bHost key verification failed."),
        ("ff-host-key", b"status-page\x0cHost key verification failed."),
    ],
)
def test_r4_cr_body_must_not_suppress_mandated_503_fallback(
    name: str, body: bytes, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A real 503 mandates fallback regardless of response-body bytes (spec 2)."""
    key, crt = _cert(tmp_path)
    real_clean = git_admission._clean_git_environment

    def clean_with_ca(*a, **k):
        env = real_clean(*a, **k)
        env["GIT_SSL_CAINFO"] = crt
        return env

    monkeypatch.setattr(git_admission, "_clean_git_environment", clean_with_ca)
    server = _Server(key, crt, body, 503)
    try:
        bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: bare}, allow_loopback_https=True
        )
        real_run = git_admission.subprocess.run
        fetches: list = []

        def record(*args, **kwargs):
            cmd = args[0]
            if isinstance(cmd, tuple) and "fetch" in cmd:
                fetches.append(cmd)
            return real_run(*args, **kwargs)

        monkeypatch.setattr(git_admission.subprocess, "run", record)
        result = transport.acquire_plan(plan, LockedCommit("sha1", commit), tool)
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-503"
        assert len(fetches) == 2
    finally:
        server.close()


def test_r4_crlf_body_keeps_fallback_control(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """CRLF bodies are safe because git re-prefixes each LF-separated line."""
    key, crt = _cert(tmp_path)
    real_clean = git_admission._clean_git_environment

    def clean_with_ca(*a, **k):
        env = real_clean(*a, **k)
        env["GIT_SSL_CAINFO"] = crt
        return env

    monkeypatch.setattr(git_admission, "_clean_git_environment", clean_with_ca)
    server = _Server(key, crt, b"status-page\r\nHost key verification failed.", 503)
    try:
        bare, commit = _bare_repository(tmp_path / "second")
        second_url = "https://fixture.test/kit.git"
        plan = _https_mirror_plan(server.url, second_url)
        tool = _fake_http_tool(
            tmp_path / "tool", {second_url: bare}, allow_loopback_https=True
        )
        result = transport.acquire_plan(plan, LockedCommit("sha1", commit), tool)
        assert result.attempt_count == 2
        assert result.attempts[0].classification == "http-503"
    finally:
        server.close()


def test_r4_sole_cr_forged_availability_classifies() -> None:
    """Attacker bytes alone can become the sole evidence record (mechanism)."""
    # No real transport record at all: a single remote: line with an
    # embedded CR splits into a prefixed fragment plus a bare evidence
    # frame. The classifier reports the attacker's class.
    assert (
        git_admission._classify_git_failure_output(
            b"remote: foo\rssh: connect to host example.org port 22: Connection refused"
        )
        == "connection-refused"
    )
    assert (
        git_admission._classify_git_failure_output(
            "remote: foo\rFatal: Authentication failed"
        )
        == "auth-rejected"
    )
