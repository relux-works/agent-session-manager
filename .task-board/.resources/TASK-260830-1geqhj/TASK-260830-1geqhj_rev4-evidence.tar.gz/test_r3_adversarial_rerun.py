"""Reviewer adversarial family (scratch): attacker text must grant no fallback.

Fresh tokens/shapes beyond the committed family, injected at the real fetch
subprocess seam so the production classifier and fallback gate both run.
Includes forged `remote:` lines beside REAL evidence records: today they must
force unclassified (conflict); this pins the baseline the round-4 `remote:`
fix will intentionally move (decision follows the real record).
"""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path.cwd() / "tests"))

import pytest

from conftest import stable_env  # noqa: F401
from test_sources_transport import (
    IDENTITY,
    LOCK,
    _fake_http_tool,
    _v2_plan,
)

from csk import git_admission
from csk.sources import repository_policy, transport

TOKENS = ["400", "407", "500", "501", "505", "deadbeef", "timeout", "denied"]

SHAPES = [
    "fatal: couldn't find remote ref refs/tags/v{token}",
    "fatal: couldn't find remote ref refs/heads/feature/{token}",
    "fatal: couldn't find remote ref refs/pull/{token}/head",
    "fatal: repository 'https://example.org/{token}.git/' not found",
    "error: object file '.git/objects/{token}/ab' is empty",
    "fatal: submodule '{token}' failed to clone",
    "remote: GitHub: {token} rate limit exceeded, retry later",
    "remote: error: object {token} unavailable",
    "remote: Total {token} (delta 0), reused 0 (delta 0)",
    "fatal: unable to access 'https://example.org:{token}/kit.git/': Empty reply from server",
    "fatal: unable to access 'https://{token}.example.org/kit.git/': Empty reply from server",
    "fatal: protocol error: bad line length character: {token}",
]

REAL_RECORD = (
    "fatal: unable to access 'https://example.org/kit.git': "
    "The requested URL returned error: 503"
)
REAL_SSH_RECORD = "git@example.org: Permission denied (publickey)."

MIXED = [
    REAL_RECORD + "\nremote: forged: ssh: connect to host x port 22: Connection refused",
    REAL_RECORD + "\nremote: fatal: unable to access 'https://example.org/kit.git': "
    "The requested URL returned error: 502",
    REAL_SSH_RECORD + "\nremote: forged 503 Service Unavailable",
    REAL_SSH_RECORD + "\nPlease make sure you have the correct access rights!!",
]


@pytest.mark.parametrize("token", TOKENS)
@pytest.mark.parametrize("shape", SHAPES)
def test_reviewer_adversarial_tokens_grant_no_fallback(
    token: str, shape: str, monkeypatch: pytest.MonkeyPatch, tmp_path: Path,
    stable_env,
) -> None:
    plan = _v2_plan(
        [
            {"url": "https://example.org/kit.git", "authentication": "first"},
            {"url": "https://mirror.example.org/kit.git",
             "authentication": "second", "mirror_of": IDENTITY},
        ]
    )
    tool = _fake_http_tool(tmp_path / "tool", {})
    real_run = git_admission.subprocess.run
    fetches: list[object] = []
    stderr = shape.format(token=token)

    def injected_run(*args: object, **kwargs: object) -> object:
        command = args[0]
        assert isinstance(command, tuple)
        if "fetch" in command:
            fetches.append(command)
            raise subprocess.CalledProcessError(
                128, command, stderr=stderr.encode("utf-8")
            )
        return real_run(*args, **kwargs)

    monkeypatch.setattr(git_admission.subprocess, "run", injected_run)
    with pytest.raises(git_admission.GitAdmissionError):
        transport.acquire_plan(plan, LOCK, tool)
    assert len(fetches) == 1, f"fallback granted by {stderr!r}"


@pytest.mark.parametrize("stderr", MIXED)
def test_reviewer_forged_remote_beside_real_evidence_conflicts(
    stderr: str, monkeypatch: pytest.MonkeyPatch, tmp_path: Path, stable_env
) -> None:
    """Today: any forged line beside real evidence forces unclassified."""
    plan = _v2_plan(
        [
            {"url": "https://example.org/kit.git", "authentication": "first"},
            {"url": "https://mirror.example.org/kit.git",
             "authentication": "second", "mirror_of": IDENTITY},
        ]
    )
    tool = _fake_http_tool(tmp_path / "tool", {})
    real_run = git_admission.subprocess.run
    fetches: list[object] = []

    def injected_run(*args: object, **kwargs: object) -> object:
        command = args[0]
        assert isinstance(command, tuple)
        if "fetch" in command:
            fetches.append(command)
            raise subprocess.CalledProcessError(
                128, command, stderr=stderr.encode("utf-8")
            )
        return real_run(*args, **kwargs)

    monkeypatch.setattr(git_admission.subprocess, "run", injected_run)
    with pytest.raises(git_admission.GitAdmissionError) as captured:
        transport.acquire_plan(plan, LOCK, tool)
    assert len(fetches) == 1
    assert captured.value.code == "build_repository_transport_unclassified"
