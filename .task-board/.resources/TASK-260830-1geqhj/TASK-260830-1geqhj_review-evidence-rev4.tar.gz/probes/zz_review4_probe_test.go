package axpane

// Reviewer probes for CR-TASK-260830-1geqhj-4 (RUN-260917-e644e0).
// Isolated copy only; never shipped. Every probe drives a production
// entry (Run, Decide, Store.*, Emit*) and logs the observed outcome.
// A probe whose Fatalf starts with FINDING: is a spec/contract
// defect; one starting with CHARACTERIZATION: documents an observed
// boundary without asserting it is wrong.

import (
	"context"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
)

const (
	r4Op5 = "0198f4c8-7d40-7e55-8e6f-1234567890af"
)

// r4TwoCheckpointsAfterTakeover extends the rev4 post-takeover world:
// after stopping with C1 the successor owner resumes from C1, changes
// the profile to yolo, idles, and stops with C2. Fold newest = C2;
// lease base stays C0; C1 is superseded.
func r4TwoCheckpointsAfterTakeover(t *testing.T) (*runWorld, string, string, string, string) {
	t.Helper()
	world, c0, c1 := rev4PostTakeoverWorld(t)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, rev4Successor, 4, world.headID, map[string]any{
		"checkpoint_id": c1, "execution_profile": "standard", "profile_source_event_id": nil,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	changed := appendChainEvent(t, world.repo, "profile.changed", 2, rev4Successor, 5, resumedID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, rev4Successor, 6, changed, map[string]any{
		"boundary_ref": "turn-3", "foreground_idle": true, "background_idle": true,
	})
	c2, _ := rev4Capture(t, world.repo, world.ckpt, r4Op5, 2, rev4Successor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, rev4Successor, 7, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c2, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	return world, c0, c1, c2, changed
}

// R4-1: one step past the reviewed vector. The successor owner
// published TWO checkpoints after the takeover. Restore from C2
// launches with C2's closure (yolo, sourced); restore from C1 (the
// owner's own but superseded checkpoint) parks at the newest arm;
// restore from the handoff base C0 parks.
func TestR4TwoCheckpointsAfterTakeover(t *testing.T) {
	world, c0, c1, c2, changed := r4TwoCheckpointsAfterTakeover(t)
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil || !has || newest != c2 {
		t.Fatalf("fold = (%v, %s, %v), want C2", has, newest, err)
	}
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	if observation.Winner.Checkpoint != c0 {
		t.Fatalf("lease base = %s, want C0 (immutable)", observation.Winner.Checkpoint)
	}
	world.mat = journalSourced(t, c2)
	outcome, err := Run(world.stores(), rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 2, rev4Successor, c2))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore C2 (newest): action=%s profile=%+v mapping=%q", outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("FINDING: restore from the newest C2 did not launch: %v", outcome.Decision.Cause)
	}
	if outcome.Decision.Profile.Profile != "yolo" || outcome.Decision.Profile.Source != changed {
		t.Fatalf("FINDING: launch profile %+v, want C2's closure (yolo/%s)", outcome.Decision.Profile, changed[:20])
	}
	// C1: the successor's own earlier checkpoint, now superseded by C2.
	world.mat = journalSourced(t, c1)
	middle, err := Run(world.stores(), rev4RestoreRequest(t, world, rev4Op3, rev4Inst3, 2, rev4Successor, c1))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore C1 (superseded): action=%s reason=%s cause=%v", middle.Decision.Action, middle.Decision.ParkReason, middle.Decision.Cause)
	if middle.Decision.Action != ActionParked || middle.Decision.ParkReason != fencing.ParkRestorePolicy {
		t.Fatalf("FINDING: a superseded checkpoint C1 was admitted for resume")
	}
	if _, found, _ := world.pane.Lookup(fixtureSession, rev4Op3); found {
		t.Fatalf("FINDING: parked restore installed a binding")
	}
	// C0: the handoff base.
	world.mat = journalSourced(t, c0)
	base, err := Run(world.stores(), rev4RestoreRequest(t, world, rev4Op4, rev4Inst4, 2, rev4Successor, c0))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore C0 (handoff base): action=%s cause=%v", base.Decision.Action, base.Decision.Cause)
	if base.Decision.Action != ActionParked {
		t.Fatalf("FINDING: the handoff base was admitted for resume")
	}
}

// R4-2: the successor null-fold arm through Run in RESTORE mode with
// no requirements at all (the shipped Run test is launch mode): the
// implication arm must own the decision on every launch-class path.
func TestR4SuccessorNullFoldRestoreModeNoRequirements(t *testing.T) {
	world := buildRunWorld(t)
	successorLease(t, world.repo, rev4Successor, fixtureLocalHost, world.ckptID)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore mode, successor lease, null fold, no requirements: action=%s reason=%s cause=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionParked || outcome.Decision.ParkReason != fencing.ParkRestorePolicy {
		t.Fatalf("FINDING: restore-mode successor null fold did not park restore_policy")
	}
	if outcome.Decision.Cause == nil || !strings.Contains(outcome.Decision.Cause.Error(), "carries a checkpoint and the chain publishes none") {
		t.Fatalf("FINDING: wrong arm: %v", outcome.Decision.Cause)
	}
	if outcome.Emitted {
		t.Logf("note: parked event emitted=%v (chain state creating cannot fold parked, so expected false)", outcome.Emitted)
	}
}

// R4-3: nothing else about the lease base is asserted. The successor
// lease names a base the chain NEVER published (an unpublished
// digest), while the fold's newest is C1. Per the rev4 brief the
// wrapper compares the base against nothing: restore from C1
// launches. (Binding the base to a published checkpoint is the
// takeover leaf's obligation — stated bound.)
func TestR4LeaseBaseNeverPublishedStillLaunchesFromNewest(t *testing.T) {
	world := buildRunWorld(t)
	c1 := world.ckptID
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, c1)
	successorLease(t, world.repo, rev4Successor, fixtureLocalHost, seedDigest(0xBB)) // base never on the chain
	world.mat = journalSourced(t, c1)
	outcome, err := Run(world.stores(), rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 2, rev4Successor, c1))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("successor base unpublished, fold newest C1, restore C1: action=%s cause=%v", outcome.Decision.Action, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("CHARACTERIZATION: the lease base is being compared against something: %v", outcome.Decision.Cause)
	}
}

// R4-4: a head-only profile change AFTER the newest checkpoint must
// not leak into the launch. Post-takeover world (C1 closure =
// standard), then profile.changed -> yolo appended after the
// checkpointed stop (inert for the fold). Launch mode (create from
// stopped) through Run: standard from C1's closure. Restore naming
// C1 through Run: standard. Decide with no heads supplied: what
// does the pure core do?
func TestR4HeadOnlyChangeAfterNewestNeverLaunches(t *testing.T) {
	world, _, c1 := rev4PostTakeoverWorld(t)
	headOnly := appendChainEvent(t, world.repo, "profile.changed", 2, rev4Successor, 4, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	has, newest, err := LoadNewestCheckpoint(world.repo, fixtureSession)
	if err != nil || !has || newest != c1 {
		t.Fatalf("fold = (%v, %s, %v), want C1 (profile.changed is inert)", has, newest, err)
	}
	record, events, err := LoadProfile(world.repo, fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	// Launch mode through Run.
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = rev4Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("launch from stopped with head-only yolo after C1: action=%s profile=%+v mapping=%q", outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Profile != "standard" {
		t.Fatalf("FINDING: head-only change became the launch profile through Run")
	}
	// Restore mode through Run naming C1.
	world.mat = journalSourced(t, c1)
	restore, err := Run(world.stores(), rev4RestoreRequest(t, world, rev4Op3, rev4Inst3, 2, rev4Successor, c1))
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("restore C1 with head-only yolo after C1: action=%s profile=%+v", restore.Decision.Action, restore.Decision.Profile)
	if restore.Decision.Action == ActionLaunch && restore.Decision.Profile.Profile != "standard" {
		t.Fatalf("FINDING: head-only change became the restore profile through Run")
	}
	// The pure core with the same world but NO ProfileHeads supplied
	// (an I/O-free caller that omits the closure) and no required
	// checkpoint: launch mode, fold has newest C1.
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.ProfileRecord = record
	input.ProfileEvents = events
	input.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	input.Observation.Winner.Epoch = 2
	input.Observation.Winner.LeaseID = rev4Successor
	input.Observation.Winner.HasCheckpoint = true
	input.Observation.Winner.Checkpoint = seedDigest(0xC0)
	input.Observation.Grant.Token = sessrepo.FencingToken{Epoch: 2, LeaseID: rev4Successor, HolderHostID: fixtureLocalHost}
	input.HasNewestCheckpoint = true
	input.NewestCheckpointID = c1
	input.ProfileHeads = nil
	decision := Decide(input)
	t.Logf("Decide with HasNewestCheckpoint=true and NO ProfileHeads: action=%s profile=%+v mapping=%q (head-only event %s)", decision.Action, decision.Profile, decision.Mapping, headOnly[:20])
	if decision.Action == ActionLaunch && decision.Profile.Profile == "yolo" {
		t.Fatalf("CHARACTERIZATION: the pure core derives the SESSION HEAD (yolo, mapping %q) when the fold has a newest checkpoint but the caller supplies no closure heads; Run is correct, Decide alone is not fail-closed", decision.Mapping)
	}
}

// R4-5: on reattach the outcome carries two terminal instance IDs:
// Binding (the recorded child) and Decision.Descriptor (built from
// the request's own instance before the decision). Characterize
// whether they agree.
func TestR4ReattachDescriptorNamesWhichInstance(t *testing.T) {
	world := buildRunWorld(t)
	first, _, err := world.pane.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
	if err != nil {
		t.Fatal(err)
	}
	request := runRequest(t, world)
	request.InstanceID = rev4Inst2 // a retry carrying different child facts
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("reattach: Binding.TerminalInstanceID=%s Descriptor.TerminalInstanceID=%s recorded=%s",
		outcome.Binding.TerminalInstanceID[9:13], outcome.Decision.Descriptor.TerminalInstanceID[9:13], first.TerminalInstanceID[9:13])
	if outcome.Decision.Action != ActionReattach {
		t.Fatalf("want reattach, got %s", outcome.Decision.Action)
	}
	if outcome.Decision.Descriptor.TerminalInstanceID != outcome.Binding.TerminalInstanceID {
		t.Fatalf("CHARACTERIZATION: reattach outcome carries Descriptor.terminal_instance_id=%s while Binding names the recorded child %s",
			outcome.Decision.Descriptor.TerminalInstanceID, outcome.Binding.TerminalInstanceID)
	}
}

// R4-6: P2-1 one step away. Post-window, a concurrent wrapper records
// a DIFFERENT pair (op3) between our stage and link: our op2 must
// still launch its own child (no replay), and both receipts exist.
func TestR4PostWindowDifferentPairRaceStillLaunches(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	world.mat = journalSourced(t, world.ckptID)
	other := bindCandidate()
	other.OperationID = rev4Op3
	other.TerminalInstanceID = rev4Inst3
	other.BindingDigest = BindingDigest(other)
	request := rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 1, fixtureLeaseA, world.ckptID)
	request.Hooks = &Hooks{
		AfterStage: func(path string) error {
			inner, err := Open(world.paneRoot)
			if err != nil {
				return err
			}
			_, _, err = inner.Supersede(fixtureSession, rev4Op3, other)
			return err
		},
	}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("different-pair race: action=%s binding op=%s instance=%s", outcome.Decision.Action, outcome.Binding.OperationID[32:], outcome.Binding.TerminalInstanceID[9:13])
	if outcome.Decision.Action != ActionLaunch || outcome.Binding.OperationID != fixtureOtherOp || outcome.Binding.TerminalInstanceID != rev4Inst2 {
		t.Fatalf("FINDING: a different-pair concurrent commit changed our own outcome")
	}
	for _, op := range []string{fixtureBootstrap, fixtureOtherOp, rev4Op3} {
		if _, found, err := world.pane.Lookup(fixtureSession, op); err != nil || !found {
			t.Fatalf("Lookup(%s) = (%v, %v), want every pair recorded", op[32:], found, err)
		}
	}
}

// R4-7: Supersede's own pre-install Lookup path (a concurrent commit
// between Run's Lookup and Supersede's Lookup) reports the replay.
func TestR4SupersedeFoundBeforeInstallReportsReplay(t *testing.T) {
	store := openPaneStore(t)
	if _, _, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate()); err != nil {
		t.Fatal(err)
	}
	winner := bindCandidate()
	winner.OperationID = fixtureOtherOp
	winner.TerminalInstanceID = rev4Inst3
	winner.BindingDigest = BindingDigest(winner)
	if _, replayed, err := store.Supersede(fixtureSession, fixtureOtherOp, winner); err != nil || replayed {
		t.Fatalf("first Supersede = (replayed %v, %v)", replayed, err)
	}
	loser := bindCandidate()
	loser.OperationID = fixtureOtherOp
	loser.TerminalInstanceID = rev4Inst2
	loser.BindingDigest = BindingDigest(loser)
	bound, replayed, err := store.Supersede(fixtureSession, fixtureOtherOp, loser)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("pre-install found path: replayed=%v instance=%s", replayed, bound.TerminalInstanceID[9:13])
	if !replayed || bound.TerminalInstanceID != winner.TerminalInstanceID {
		t.Fatalf("FINDING: the pre-install found path does not report replay / winner")
	}
}

// R4-8: remote-owned session whose newest checkpoint is absent from
// the LOCAL checkpoint store (replica lag). The decision would be
// attach_remote/takeover/parked(remote_owner); does Run reach it?
func TestR4RemoteOwnerNewestAbsentLocally(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	successorLease(t, world.repo, rev4Successor, fixtureRemoteHost, world.ckptID)
	stores := world.stores()
	empty, err := sessckpt.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	stores.Ckpt = empty
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	request.RemoteInteractive = true
	outcome, err := Run(stores, request)
	t.Logf("remote owner (2,S on remote host), newest absent locally: action=%q err=%v", outcome.Decision.Action, err)
	if err != nil {
		t.Fatalf("CHARACTERIZATION: a remote-owned session fails the run (no decision) when the newest checkpoint is absent from the local store; the launch path is unreachable for a remote winner, so the closure is never needed: %v", err)
	}
	if outcome.Decision.Action != ActionAttachRemote {
		t.Fatalf("want attach_remote, got %s", outcome.Decision.Action)
	}
}

// R4-8b: same with no checkpoint store bound at all.
func TestR4RemoteOwnerNoCkptStore(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	successorLease(t, world.repo, rev4Successor, fixtureRemoteHost, world.ckptID)
	stores := world.stores()
	stores.Ckpt = nil
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	request.RemoteInteractive = true
	outcome, err := Run(stores, request)
	t.Logf("remote owner, no checkpoint store: action=%q err=%v", outcome.Decision.Action, err)
	if err != nil {
		t.Fatalf("CHARACTERIZATION: remote-owned session with no local checkpoint store fails the run instead of offering attach: %v", err)
	}
}

// R4-9: EmitParked with a decision whose WinningLeaseID differs from
// the authoring lease in params: does the payload's winning_lease_id
// get bound to the authoring lease?
func TestR4EmitParkedWinningLeaseMismatch(t *testing.T) {
	repository, _ := chainFixture(t)
	// Move the chain to a state that folds parked: session.failed.
	events, err := repository.ListEvents(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	head := events[len(events)-1].EventID
	head = appendChainEvent(t, repository, "session.failed", 1, fixtureLeaseA, 2, head, map[string]any{
		"error_code": "provider_process_failed", "retryable": true, "operation_id": nil,
	})
	observation, err := ObserveOwnership(repository, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	decision := parked(fencing.ParkStaleOwner, fixtureLeaseB, errors.New("probe")) // payload names lease B
	_, raw, err := EmitParked(repository, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{head}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation,
	})
	t.Logf("EmitParked(payload winner=B, authoring lease=A): err=%v raw=%s", err, string(raw))
	if err == nil {
		t.Fatalf("CHARACTERIZATION: session.parked appended under lease A with payload winning_lease_id = lease B (no consistency check between decision.WinningLeaseID and the authoring lease)")
	}
}

// R4-10: Emit under a lease the local host does not hold: presented
// equals the winner tuple but the winner is remote -> refused.
func TestR4EmitUnderRemoteWinnerRefuses(t *testing.T) {
	repository, _ := chainFixture(t)
	events, _ := repository.ListEvents(fixtureSession)
	head := events[len(events)-1].EventID
	appendChainEvent(t, repository, "session.failed", 1, fixtureLeaseA, 2, head, map[string]any{
		"error_code": "provider_process_failed", "retryable": true, "operation_id": nil,
	})
	observe := runObserve(fixtureNow())
	observe.LocalHostID = fixtureRemoteHost // we are NOT the holder
	observation, err := ObserveOwnership(repository, fixtureSession, observe)
	if err != nil {
		t.Fatal(err)
	}
	before := eventCount(t, repository)
	decision := parked(fencing.ParkRemoteOwner, fixtureLeaseA, errors.New("probe"))
	_, _, err = EmitParked(repository, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureRemoteHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{head}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation,
	})
	t.Logf("Emit under a remote winner's tuple: err=%v events %d->%d", err, before, eventCount(t, repository))
	if err == nil || !errors.Is(err, fencing.ErrNotOwner) || eventCount(t, repository) != before {
		t.Fatalf("FINDING: emission under a remote winner's lease was not refused not_owner")
	}
}

// R4-11: descriptor admission is the last arm: a descriptor naming a
// different binding digest on an otherwise launching restore refuses
// (no launch), and the parked outcome for a stale journal never
// reaches descriptor admission (parks first).
func TestR4DescriptorDigestDriftRefuses(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	descriptor, err := BuildDescriptor(DescriptorParams{
		Binding: BindingRef{
			BindingDigest:         seedDigest(0xB2), // not the host binding's B1
			BackendID:             deps.universe.hostBinding().BackendID,
			ImplementationVersion: deps.universe.hostBinding().ImplementationVersion,
			ProtocolVersion:       deps.universe.hostBinding().ProtocolVersion,
			Generation:            deps.universe.hostBinding().Generation,
		},
		InstanceID: fixtureInstance, Interactive: true, Columns: 80, Rows: 24,
	})
	if err != nil {
		t.Fatal(err)
	}
	input.Descriptor = descriptor
	decision := Decide(input)
	t.Logf("descriptor binding digest drift: action=%s class=%q", decision.Action, decision.Class)
	if decision.Action != ActionRefused {
		t.Fatalf("FINDING: a descriptor with a foreign binding digest launched")
	}
}

// R4-12: decision-table plants of my own.
func TestR4DecisionPlants(t *testing.T) {
	t.Run("successor_null_fold_and_stale_journal_both_satisfiable", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
		input.Observation.Winner.Epoch = 2
		input.Observation.Winner.LeaseID = rev4Successor
		input.Observation.Winner.HasCheckpoint = true
		input.Observation.Winner.Checkpoint = seedDigest(0xC0)
		input.Observation.Grant.Token = sessrepo.FencingToken{Epoch: 2, LeaseID: rev4Successor, HolderHostID: fixtureLocalHost}
		input.MaterializationRequired = true
		input.JournalOK = true
		input.Journal = matjournal.Journal{Phase: matjournal.PhaseStaging, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
		decision := Decide(input)
		t.Logf("null fold + staging journal: action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
		if decision.Action != ActionParked || !strings.Contains(decision.Cause.Error(), "chain publishes none") {
			t.Fatalf("want the implication arm to own the decision")
		}
	})
	t.Run("remote_owner_unverified_parks_not_attach", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.Observation.Verified = false
		input.RemoteInteractive = true
		decision := Decide(input)
		t.Logf("remote interactive owner, unverified: action=%s reason=%s", decision.Action, decision.ParkReason)
		if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRestorePolicy {
			t.Fatalf("FINDING: an unverified observation offered %s", decision.Action)
		}
	})
	t.Run("remote_owner_ambiguous_parks_not_attach", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.Observation.Ambiguous = true
		input.RemoteInteractive = true
		decision := Decide(input)
		t.Logf("remote interactive owner, ambiguous: action=%s reason=%s", decision.Action, decision.ParkReason)
		if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRestorePolicy {
			t.Fatalf("FINDING: an ambiguous observation offered %s", decision.Action)
		}
	})
	t.Run("remote_owner_successor_null_fold_still_offers_attach", func(t *testing.T) {
		// The null-fold arm sits after fencing: a remote checkpoint-
		// carrying winner over a null local fold offers attach (no
		// local launch is possible either way).
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Observation.Winner.Epoch = 2
		input.Observation.Winner.LeaseID = rev4Successor
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.Observation.Winner.HasCheckpoint = true
		input.Observation.Winner.Checkpoint = seedDigest(0xC0)
		input.Observation.Grant.Token = sessrepo.FencingToken{Epoch: 2, LeaseID: rev4Successor, HolderHostID: fixtureRemoteHost}
		input.RemoteInteractive = true
		decision := Decide(input)
		t.Logf("remote successor, null local fold: action=%s reason=%s", decision.Action, decision.ParkReason)
		if decision.Action != ActionAttachRemote {
			t.Fatalf("want attach_remote (fencing precedes the implication arm), got %s cause=%v", decision.Action, decision.Cause)
		}
	})
	t.Run("restore_noninteractive_remote_owner_offers_attach_without_headless", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.Interactive = false
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.RemoteInteractive = true
		decision := Decide(input)
		t.Logf("restore, local non-interactive, remote interactive owner: action=%s", decision.Action)
		if decision.Action != ActionAttachRemote {
			t.Fatalf("want attach_remote, got %s cause=%v", decision.Action, decision.Cause)
		}
	})
	t.Run("required_checkpoint_in_launch_mode_gates_too", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = seedDigest(0xC9) // newest is something else
		input.CheckpointRequired = true
		input.CheckpointDoc = deps.ckptDoc
		input.CheckpointID = deps.ckptID
		decision := Decide(input)
		t.Logf("launch mode with a required non-newest checkpoint: action=%s cause=%v", decision.Action, decision.Cause)
		if decision.Action != ActionParked {
			t.Fatalf("FINDING: launch mode admitted a non-newest required checkpoint")
		}
	})
	t.Run("inconsistent_fold_has_but_empty_id", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		input.Mode = ModeRestore
		input.HasNewestCheckpoint = true
		input.NewestCheckpointID = ""
		input.MaterializationRequired = true
		input.JournalOK = true
		input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
		decision := Decide(input)
		t.Logf("has=true id=empty: action=%s cause=%v", decision.Action, decision.Cause)
		if decision.Action == ActionLaunch {
			t.Fatalf("FINDING: an inconsistent fold fact launched")
		}
	})
	t.Run("same_epoch_losing_lease_local_parks_stale_owner", func(t *testing.T) {
		deps := buildDecideDeps(t, true)
		input := validInput(t, deps)
		// Winner is (1, B) with B > A bytewise; presented (1, A).
		input.Observation.Winner.LeaseID = fixtureLeaseB
		input.Observation.Grant.Token = sessrepo.FencingToken{Epoch: 1, LeaseID: fixtureLeaseB, HolderHostID: fixtureLocalHost}
		decision := Decide(input)
		t.Logf("same-epoch loser: action=%s reason=%s winner=%s", decision.Action, decision.ParkReason, decision.WinningLeaseID[:8])
		if decision.Action != ActionParked || decision.ParkReason != fencing.ParkStaleOwner || decision.HasToken {
			t.Fatalf("FINDING: same-epoch loser did not park stale_owner without a token")
		}
	})
}

// R4-13: Bind anchor seam with a REAL SIGKILL between the anchor
// install and the pair-receipt install (AfterInstall on the anchor
// path): restart proves the anchor, Lookup proves the pair absent,
// and the identical retry converges to the one child; inode census
// shows no rewrite.
func TestR4BindAnchorSeamRealKill(t *testing.T) {
	if os.Getenv("R4_BIND_CHILD") == "1" {
		root := os.Getenv("R4_BIND_ROOT")
		store, err := Open(root)
		if err != nil {
			os.Exit(3)
		}
		store.WithHooks(&Hooks{AfterInstall: func(path string) error {
			// Only the anchor path passes binding.json here.
			if filepath.Base(path) == "binding.json" {
				_ = syscall.Kill(os.Getpid(), syscall.SIGKILL)
				select {}
			}
			return nil
		}})
		_, _, _ = store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
		os.Exit(4) // never reached
	}
	root := t.TempDir()
	cmd := exec_command(t, "-test.run=^TestR4BindAnchorSeamRealKill$")
	cmd.Env = append(os.Environ(), "R4_BIND_CHILD=1", "R4_BIND_ROOT="+root)
	err := cmd.Run()
	t.Logf("child exit: %v", err)
	if err == nil {
		t.Fatal("child was not killed")
	}
	store, err := Open(root)
	if err != nil {
		t.Fatal(err)
	}
	anchor, found, err := store.Status(fixtureSession)
	t.Logf("after kill: Status found=%v err=%v op=%s", found, err, anchor.OperationID[32:])
	if err != nil || !found {
		t.Fatalf("anchor not committed: found=%v err=%v", found, err)
	}
	_, pairFound, err := store.Lookup(fixtureSession, fixtureBootstrap)
	t.Logf("after kill: Lookup pair found=%v err=%v", pairFound, err)
	if err != nil || pairFound {
		t.Fatalf("expected the pair receipt ABSENT after the anchor-only commit")
	}
	bound, err2 := store.SessionBound(fixtureSession)
	t.Logf("after kill: SessionBound=%v err=%v", bound, err2)
	retry := bindCandidate()
	retry.TerminalInstanceID = rev4Inst2 // different child facts
	retry.BindingDigest = BindingDigest(retry)
	converged, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, retry)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("retry: reattached=%v instance=%s (anchor %s)", reattached, converged.TerminalInstanceID[9:13], anchor.TerminalInstanceID[9:13])
	if !reattached || converged.TerminalInstanceID != anchor.TerminalInstanceID {
		t.Fatalf("FINDING: retry after the anchor-seam crash did not converge to the one child")
	}
	// Inode census: a second identical retry rewrites nothing.
	pairPath := filepath.Join(root, "axpane", "bootstrap", fixtureSession, "receipts", fixtureBootstrap+".json")
	anchorPath := filepath.Join(root, "axpane", "bootstrap", fixtureSession, "binding.json")
	ino1, _ := r4Inode(t, pairPath)
	aino1, _ := r4Inode(t, anchorPath)
	if _, again, err := store.Bind(fixtureSession, fixtureBootstrap, retry); err != nil || !again {
		t.Fatalf("second retry = (%v, %v)", again, err)
	}
	ino2, _ := r4Inode(t, pairPath)
	aino2, _ := r4Inode(t, anchorPath)
	t.Logf("inodes pair %d->%d anchor %d->%d", ino1, ino2, aino1, aino2)
	if ino1 != ino2 || aino1 != aino2 {
		t.Fatalf("FINDING: identical retry rewrote a receipt")
	}
	entries, _ := os.ReadDir(filepath.Join(root, "axpane", "bootstrap", fixtureSession, "receipts"))
	if len(entries) != 1 {
		t.Fatalf("FINDING: %d receipts, want exactly one child", len(entries))
	}
}

// R4-14: Supersede pair seam with a REAL SIGKILL after the pair
// receipt link but before the anchor claim (post-window, session
// unbound anchor absent): restart shows the pair; retry converges
// the anchor; exactly one child.
func TestR4SupersedeAnchorClaimSeamRealKill(t *testing.T) {
	if os.Getenv("R4_SUP_CHILD") == "1" {
		root := os.Getenv("R4_SUP_ROOT")
		store, err := Open(root)
		if err != nil {
			os.Exit(3)
		}
		store.WithHooks(&Hooks{AfterInstall: func(path string) error {
			_ = syscall.Kill(os.Getpid(), syscall.SIGKILL)
			select {}
		}})
		candidate := bindCandidate()
		candidate.OperationID = fixtureOtherOp
		candidate.TerminalInstanceID = rev4Inst3
		candidate.BindingDigest = BindingDigest(candidate)
		_, _, _ = store.Supersede(fixtureSession, fixtureOtherOp, candidate)
		os.Exit(4)
	}
	root := t.TempDir()
	cmd := exec_command(t, "-test.run=^TestR4SupersedeAnchorClaimSeamRealKill$")
	cmd.Env = append(os.Environ(), "R4_SUP_CHILD=1", "R4_SUP_ROOT="+root)
	err := cmd.Run()
	t.Logf("child exit: %v", err)
	if err == nil {
		t.Fatal("child was not killed")
	}
	store, err := Open(root)
	if err != nil {
		t.Fatal(err)
	}
	_, anchorFound, err := store.Status(fixtureSession)
	t.Logf("after kill: anchor found=%v err=%v", anchorFound, err)
	pair, pairFound, err := store.Lookup(fixtureSession, fixtureOtherOp)
	t.Logf("after kill: pair found=%v err=%v", pairFound, err)
	if err != nil || !pairFound {
		t.Fatalf("pair receipt not committed after the link: found=%v err=%v", pairFound, err)
	}
	retry := bindCandidate()
	retry.OperationID = fixtureOtherOp
	retry.TerminalInstanceID = rev4Inst2
	retry.BindingDigest = BindingDigest(retry)
	bound, replayed, err := store.Supersede(fixtureSession, fixtureOtherOp, retry)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("retry: replayed=%v instance=%s (recorded %s)", replayed, bound.TerminalInstanceID[9:13], pair.TerminalInstanceID[9:13])
	if !replayed || bound.TerminalInstanceID != pair.TerminalInstanceID {
		t.Fatalf("FINDING: retry did not replay the recorded child")
	}
	anchor, anchorFound, err := store.Status(fixtureSession)
	if err != nil || !anchorFound || anchor.OperationID != fixtureOtherOp {
		t.Fatalf("FINDING: anchor did not converge on retry: found=%v err=%v op=%+v", anchorFound, err, anchor)
	}
}

func exec_command(t *testing.T, run string) *exec.Cmd {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	t.Cleanup(cancel)
	return exec.CommandContext(ctx, os.Args[0], run, "-test.count=1")
}

func r4Inode(t *testing.T, path string) (uint64, int64) {
	t.Helper()
	info, err := os.Stat(path)
	if err != nil {
		t.Fatalf("stat %s: %v", path, err)
	}
	stat := info.Sys().(*syscall.Stat_t)
	return stat.Ino, info.ModTime().UnixNano()
}

// R4-15: the identity session binding one step away: an identity
// record for THIS session but a different provider version refuses
// through the landed gate; an identity for THIS session with the
// right build launches.
func TestR4IdentitySessionBindingNeighbours(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	decision := Decide(input)
	if decision.Action != ActionLaunch {
		t.Fatalf("baseline should launch: %v", decision.Cause)
	}
	input.Provider.Build.ProviderVersion = "0.148.0"
	decision = Decide(input)
	t.Logf("identity 0.147.0 vs probed 0.148.0: action=%s class=%q cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action != ActionRefused {
		t.Fatalf("FINDING: version drift launched")
	}
}

// R4-16: the cached-sentinel rule is structural: a background caller
// with a PASSING smoke record, Smoke.Required=false, and no realm
// row refuses capability_unavailable. Also with a realm row bound
// to another provider build.
func TestR4BackgroundCallerCachedSmokeNeverAuthorizes(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Smoke = SmokeFacts{Required: false, Record: smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple()), Target: smokeTarget()}
	decision := Decide(input)
	t.Logf("background + cached passing smoke, no realm row: action=%s class=%q", decision.Action, decision.Class)
	if decision.Action != ActionRefused || decision.Class != "capability_unavailable" || decision.RealmFailure == nil {
		t.Fatalf("FINDING: cached smoke authorized a background caller")
	}
	deps2 := buildDecideDeps(t, true)
	addRealmEvidence(t, deps2.universe, seedDigest(0xB1), "codex", "0.146.0") // another build
	input2 := validInput(t, deps2)
	input2.Realm.Caller = CallerBackground
	decision2 := Decide(input2)
	t.Logf("background + realm row for another build: action=%s class=%q", decision2.Action, decision2.Class)
	if decision2.Action != ActionRefused || decision2.Class != "capability_unavailable" {
		t.Fatalf("FINDING: a realm row for another build authorized a background caller")
	}
}

// R4-17: window predicate vs. a REMOTE winner: this host bound the
// session (epoch-1 owner), a remote takeover happened whose base the
// local chain has not published (null local fold), and a changed op
// arrives. Which arm wins: idempotency_mismatch or remote park?
func TestR4RemoteTakeoverNullFoldChangedOp(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	successorLease(t, world.repo, rev4Successor, fixtureRemoteHost, world.ckptID)
	request := runRequest(t, world)
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = rev4Inst2
	request.RemoteInteractive = true
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("CHARACTERIZATION remote takeover, null local fold, changed op: action=%s class=%q reason=%s", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.ParkReason)
}

// R4-18: profile.changed under a LOSING lease after C1 (not
// authoritative) with the closure from C1: ignored both through Run
// and by the reducer.
func TestR4LosingLeaseProfileChangeAfterNewestIgnored(t *testing.T) {
	world, _, c1 := rev4PostTakeoverWorld(t)
	// A losing same-epoch lease (2, B) with B < S bytewise? fixtureLeaseB = bbbb... < cccc... = rev4Successor, so B loses.
	losing := appendChainEvent(t, world.repo, "profile.changed", 2, fixtureLeaseB, 1, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	_ = losing
	world.mat = journalSourced(t, c1)
	outcome, err := Run(world.stores(), rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 2, rev4Successor, c1))
	if err != nil {
		t.Logf("Run() error = %v (a losing-lease event may make the chain unfoldable; that is a fail-closed outcome)", err)
		return
	}
	t.Logf("losing-lease yolo after C1: action=%s profile=%+v", outcome.Decision.Action, outcome.Decision.Profile)
	if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Profile != "standard" {
		t.Fatalf("FINDING: a losing-lease change became the launch profile")
	}
}

// R4-19: after-restore step 3 both halves: winning lease but the
// journal is prepared (not committed) -> parked; committed journal but
// the presented token is the stale epoch-1 lease under a local
// successor -> parked stale_owner (fencing before materialization).
func TestR4AfterRestoreStepThreeBothHalves(t *testing.T) {
	world, _, c1 := rev4PostTakeoverWorld(t)
	world.mat = journalSourced(t, c1)
	stale, err := Run(world.stores(), rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 1, fixtureLeaseA, c1))
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("stale epoch-1 token under local successor, valid materialization: action=%s reason=%s", stale.Decision.Action, stale.Decision.ParkReason)
	if stale.Decision.Action != ActionParked || stale.Decision.ParkReason != fencing.ParkStaleOwner {
		t.Fatalf("FINDING: a stale token with a valid materialization did not park stale_owner")
	}
	// prepared journal (walk to prepared only)
	prepared, err := matjournal.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	request := []byte(`{"materialization_id":"` + fixtureMat + `","operation_id":"` + fixturePrepareOp + `","plan_id":"` + seedDigest(0xD1) + `"}`)
	if _, _, err := prepared.Create(matjournal.CreateInputs{
		MaterializationID: fixtureMat, PrepareOperationID: fixturePrepareOp, RequestBody: request, PlanID: seedDigest(0xD1), SourceCheckpointID: c1,
		Plan:         []matjournal.PlanAuthority{{ID: "workspace_relux", Kind: matjournal.PlanKindWorkspace, Platform: "linux", RootPath: "/home/ivan/work/relux"}},
		HostPlatform: "linux", Extensions: map[string]string{},
	}); err != nil {
		t.Fatal(err)
	}
	for _, phase := range []string{matjournal.PhaseValidating, matjournal.PhasePrepared} {
		if _, err := prepared.Transition(fixtureMat, phase, matjournal.TransitionOpts{}); err != nil {
			t.Fatal(err)
		}
	}
	world.mat = prepared
	half, err := Run(world.stores(), rev4RestoreRequest(t, world, fixtureOtherOp, rev4Inst2, 2, rev4Successor, c1))
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("winning lease, prepared (uncommitted) journal: action=%s reason=%s cause=%v", half.Decision.Action, half.Decision.ParkReason, half.Decision.Cause)
	if half.Decision.Action != ActionParked || half.Decision.ParkReason != fencing.ParkRestorePolicy {
		t.Fatalf("FINDING: an uncommitted journal resumed")
	}
	if _, found, _ := world.pane.Lookup(fixtureSession, fixtureOtherOp); found {
		t.Fatalf("FINDING: parked restore installed a binding")
	}
}

// R4-20: capability outside the closed §4.D set inside the PROBE
// (not the manifest) refuses before anything else.
func TestR4ProbeCapabilityOutsideClosedSet(t *testing.T) {
	deps := buildDecideDeps(t, true)
	claims := deps.universe.probe["capability_claims"].([]any)
	claims = append(claims, map[string]any{
		"capability": "teleport", "origin": "probed", "value": true, "generation_variable": true,
		"dependent_operations": []any{"create"}, "evidence_requirements": []any{"runtime_probe"},
	})
	deps.universe.probe["capability_claims"] = claims
	deps.universe.probe["probe_id"] = omitSelfIdentity(t, deps.universe.probe, "probe_id")
	input := validInput(t, deps)
	decision := Decide(input)
	t.Logf("probe carries an unregistered capability: action=%s class=%q", decision.Action, decision.Class)
	if decision.Action != ActionRefused {
		t.Fatalf("FINDING: an unregistered capability claim was admitted")
	}
}

// R4-21: terminal.created / session.resumed v4 payloads are appended
// through sessrepo.AppendEvent under the current lease; a v4
// resumed payload with a profile that is not the decision's pair
// refuses at ResumedPayload.
func TestR4ResumedPayloadRefusesNonPair(t *testing.T) {
	_, err := ResumedPayload(seedDigest(0xE0), "unrestricted", "", false, bindingFacts())
	t.Logf("ResumedPayload(profile=unrestricted): err=%v", err)
	if err == nil {
		t.Fatalf("FINDING: an unregistered profile value was accepted")
	}
	_, err = ResumedPayload(seedDigest(0xE0), "yolo", "not-a-digest", true, bindingFacts())
	if err == nil {
		t.Fatalf("FINDING: a non-digest profile source was accepted")
	}
}

// R4-22: reattach through Run when the recorded pair exists but the
// presented token is now stale (a takeover happened): the recorded
// pair must NOT reattach under a losing token.
func TestR4ReattachUnderStaleTokenParks(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	successorLease(t, world.repo, rev4Successor, fixtureLocalHost, world.ckptID)
	request := runRequest(t, world) // same pair, presented (1, A) is now stale
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("recorded pair + stale token after local takeover: action=%s reason=%s binding=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Binding != nil)
	if outcome.Decision.Action == ActionReattach || outcome.Binding != nil {
		t.Fatalf("FINDING: a stale token reattached to the recorded child")
	}
}
