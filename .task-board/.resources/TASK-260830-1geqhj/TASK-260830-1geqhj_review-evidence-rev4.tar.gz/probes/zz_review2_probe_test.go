package axpane

// Reviewer probes for CR-TASK-260830-1geqhj-2 (rev 2). These live only
// in the isolated review copy; each probe asserts the SPEC-expected
// behavior so a RED probe is a finding, not a harness fault. Probes
// prefixed R re-run the rev1 verdict vectors against the new tree;
// probes prefixed N are new plants one step away from those vectors.

import (
	"context"
	"crypto"
	"crypto/rand"
	"crypto/rsa"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"syscall"
	"testing"
	"time"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/matjournal"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
	"github.com/relux-works/agent-session-manager/internal/sessrepo"
	"github.com/relux-works/agent-session-manager/internal/sessstate"
	"github.com/relux-works/agent-session-manager/internal/terminalbackend"
)

type probeEvent struct {
	EventType     string `json:"event_type"`
	LeaseID       string `json:"lease_id"`
	LeaseEpoch    uint64 `json:"lease_epoch"`
	LeaseSequence uint64 `json:"lease_sequence"`
	CreatedBy     string `json:"created_by_host_id"`
	Payload       struct {
		Reason  string `json:"reason"`
		Winning string `json:"winning_lease_id"`
	} `json:"payload"`
}

const probeSuccessorLocal = "cccccccc-dddd-4eee-8fff-000000000001"

func remoteTakeover(t *testing.T, world *runWorld) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[0].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        fixtureLeaseB,
			HolderHostID:   fixtureRemoteHost,
			IssuedByHostID: fixtureRemoteHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: seedDigest(0xC9),
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

// localSuccessor installs a local successor lease (epoch 2) carrying
// the captured checkpoint: the bootstrap window is closed and the
// local host holds the winner.
func localSuccessor(t *testing.T, world *runWorld, leaseID string) {
	t.Helper()
	leases, err := world.repo.ListLeases(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := world.repo.CompareAndSwapLease(fixtureSession, sessrepo.LeaseExpectation{RecordID: leases[len(leases)-1].RecordID}, sessrepo.SuccessorLeaseInput{
		CreateLeaseInput: sessrepo.CreateLeaseInput{
			LeaseID:        leaseID,
			HolderHostID:   fixtureLocalHost,
			IssuedByHostID: fixtureLocalHost,
			CreatedAt:      fixtureCreatedAt,
		},
		Reason:       "graceful_takeover",
		CheckpointID: world.ckptID,
	}); err != nil {
		t.Fatalf("CompareAndSwapLease() error = %v", err)
	}
}

// probeJournalSourced creates a committed journal whose source checkpoint
// is the given digest, in its own store.
func probeJournalSourced(t *testing.T, source string) *matjournal.Store {
	t.Helper()
	store, err := matjournal.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	request := []byte(`{"materialization_id":"` + fixtureMat + `","operation_id":"` + fixturePrepareOp + `","plan_id":"` + seedDigest(0xD1) + `"}`)
	inputs := matjournal.CreateInputs{
		MaterializationID:  fixtureMat,
		PrepareOperationID: fixturePrepareOp,
		RequestBody:        request,
		PlanID:             seedDigest(0xD1),
		SourceCheckpointID: source,
		Plan: []matjournal.PlanAuthority{
			{ID: "workspace_relux", Kind: matjournal.PlanKindWorkspace, Platform: "linux", RootPath: "/home/ivan/work/relux"},
		},
		HostPlatform: "linux",
		Extensions:   map[string]string{},
	}
	if _, _, err := store.Create(inputs); err != nil {
		t.Fatalf("Create() error = %v", err)
	}
	for _, phase := range []string{matjournal.PhaseValidating, matjournal.PhasePrepared, matjournal.PhaseCommitting} {
		if _, err := store.Transition(fixtureMat, phase, matjournal.TransitionOpts{}); err != nil {
			t.Fatalf("Transition(%s) error = %v", phase, err)
		}
	}
	rollback := "/home/ivan/work/relux.prior"
	if _, err := store.UpdateAuthority(fixtureMat, "workspace_relux", matjournal.AuthorityState{
		RootPath: "/home/ivan/work/relux", CompletedSequences: []uint64{1}, RollbackRoot: &rollback, State: matjournal.AuthorityPrepared,
	}); err != nil {
		t.Fatal(err)
	}
	if _, err := store.UpdateAuthority(fixtureMat, "workspace_relux", matjournal.AuthorityState{
		RootPath: "/home/ivan/work/relux", CompletedSequences: []uint64{1}, State: matjournal.AuthorityCommitted,
	}); err != nil {
		t.Fatal(err)
	}
	if _, err := store.Transition(fixtureMat, matjournal.PhaseCommitted, matjournal.TransitionOpts{}); err != nil {
		t.Fatal(err)
	}
	return store
}

func loadProjection(t *testing.T, repository *sessrepo.Repository) (sessstate.Projection, error) {
	t.Helper()
	recordJSON, err := repository.GetRecord(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	record, err := sessstate.DecodeRecord(recordJSON)
	if err != nil {
		t.Fatal(err)
	}
	summaries, err := repository.ListEvents(fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	var events []sessstate.Event
	for _, summary := range summaries {
		raw, err := repository.GetEvent(fixtureSession, summary.EventID)
		if err != nil {
			t.Fatal(err)
		}
		event, err := sessstate.DecodeEvent(raw)
		if err != nil {
			t.Fatal(err)
		}
		events = append(events, event)
	}
	return sessstate.Reduce(sessstate.Input{Record: record, Events: events, LocalHostID: fixtureLocalHost})
}

func decodeStoredEvent(t *testing.T, repository *sessrepo.Repository, id string) probeEvent {
	t.Helper()
	stored, err := repository.GetEvent(fixtureSession, id)
	if err != nil {
		t.Fatal(err)
	}
	var decoded probeEvent
	if err := json.Unmarshal(stored, &decoded); err != nil {
		t.Fatal(err)
	}
	return decoded
}

// ---------------------------------------------------------------
// Rework verification: rev1 P1-1 (event authority)
// ---------------------------------------------------------------

// R1 (rev1 probe 1): a remote owner park must not author into the chain
// under the remote host's lease.
func TestR2ProbeRemoteOwnerParkNoRemoteLeaseEvent(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	before := eventCount(t, world.repo)
	for _, interactive := range []bool{false, true} {
		request := runRequest(t, world)
		request.RemoteInteractive = interactive
		outcome, err := Run(world.stores(), request)
		if err != nil {
			t.Fatalf("Run() error = %v", err)
		}
		t.Logf("remote winner (interactive=%v): action=%s reason=%s emitted=%v events before=%d after=%d",
			interactive, outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted, before, eventCount(t, world.repo))
		if outcome.Emitted || eventCount(t, world.repo) != before {
			t.Errorf("FINDING: remote park authored a chain event")
		}
	}
	// The owner's own first event at (B, seq 1) must still append cleanly.
	events, _ := world.repo.ListEvents(fixtureSession)
	value := map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureSession, "session_id": fixtureSession, "event_type": "session.idle", "created_by_host_id": fixtureRemoteHost,
		"lease_epoch": 2, "lease_id": fixtureLeaseB, "lease_sequence": 1, "predecessors": []string{events[len(events)-1].EventID},
		"created_at": fixtureCreatedAt, "payload": map[string]any{"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true}, "extensions": map[string]any{},
	}
	if _, err := world.repo.AppendEvent(fixtureSession, identifyObject(t, value, "event_id")); err != nil {
		t.Errorf("owner's own (B, seq 1) event refused after the local park: %v", err)
	}
}

// R1b (rev1 probe 1b): unverified ownership with a remote holder.
func TestR2ProbeUnverifiedRemoteHolderNoEvent(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	request := runRequest(t, world)
	request.Observe.Verified = false
	before := eventCount(t, world.repo)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("unverified+remote: action=%s reason=%s emitted=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted)
	if outcome.Emitted || eventCount(t, world.repo) != before {
		t.Errorf("FINDING: unverified remote park authored a chain event")
	}
}

// R2 (rev1 probe 2): a verified local park from a creating chain must
// not author an unfolderable session.parked; the chain must still fold.
func TestR2ProbeParkedFoldsInStateEngine(t *testing.T) {
	world := buildRunWorld(t)
	request := runRequest(t, world)
	request.Observe.Verified = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("unverified local (creating chain): action=%s reason=%s emitted=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted)
	projection, err := loadProjection(t, world.repo)
	t.Logf("sessstate.Reduce: state=%q err=%v", projection.State, err)
	if err != nil {
		t.Errorf("FINDING: landed state engine refuses the chain the wrapper produced: %v", err)
	}
}

// R9 (rev1 probe 9): Emit under a losing lease must refuse through the
// mutation gate even while the chain tail still sits on that lease.
func TestR2ProbeEmitUnderLosingLeaseRefuses(t *testing.T) {
	world := buildRunWorld(t)
	remoteTakeover(t, world)
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	decision := Decision{Action: ActionParked, ParkReason: fencing.ParkStaleOwner, WinningLeaseID: fixtureLeaseB}
	_, _, err = EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 2,
		Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation,
	})
	t.Logf("EmitParked under losing lease A (winner B remote, tail at A): err=%v", err)
	if err == nil {
		t.Errorf("FINDING: append under a losing lease was accepted")
	}
	// One step away: the presented token claims the winner tuple but the
	// authoring lease members name the losing lease.
	_, _, err = EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 2,
		Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: fixtureLeaseB},
		Observation: observation,
	})
	t.Logf("EmitParked authoring under A while presenting B: err=%v", err)
	if err == nil {
		t.Errorf("FINDING: authoring lease differs from presented tuple and was accepted")
	}
	// Two steps away: a local caller manufacturing the remote winner tuple
	// as its presented token (what Run does for local winners) must still
	// refuse because the holder is remote.
	_, _, err = EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 2, LeaseID: fixtureLeaseB, LeaseSequence: 1,
		Predecessors: []string{world.headID}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: fixtureLeaseB},
		Observation: observation,
	})
	t.Logf("EmitParked under remote-held B with a manufactured winner token: err=%v", err)
	if err == nil {
		t.Errorf("FINDING: local host authored under the remote-held winning lease")
	}
}

// R15 (rev1 probe 15): a losing-lease profile.changed must not drive the
// launch profile; and the same with a checkpoint-bearing local winner.
func TestR2ProbeLosingLeaseProfileEventIgnored(t *testing.T) {
	world := buildRunWorld(t)
	localSuccessor(t, world, probeSuccessorLocal)
	changed := appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("launch under A2 with losing-lease profile.changed %s: action=%s profile=%+v mapping=%q", changed[:20], outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action == ActionLaunch && (outcome.Decision.Profile.Source == changed || outcome.Decision.Profile.Profile != "standard") {
		t.Errorf("FINDING: losing-lease profile event drove the launch profile")
	}
}

// ---------------------------------------------------------------
// Rework verification: rev1 P1-2 (realm authorization)
// ---------------------------------------------------------------

// R3 (rev1 probe 3, adapted: the boolean is gone): a background caller
// with a cached passing smoke record and no admitted realm row must not
// launch; with the row but a stale generation must not launch; with the
// row and a live generation but a smoke target bound to a stale
// generation must not launch.
func TestR2ProbeBackgroundCachedSmokeNeverAuthorizes(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Smoke.Required = true
	input.Smoke.Record = smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple())
	input.Smoke.Target = smokeTarget()
	decision := Decide(input)
	t.Logf("background + cached passing smoke, no realm row: action=%s class=%s admitted=%v", decision.Action, decision.Class, decision.Admitted.Capabilities)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: background caller launched on a cached smoke record without the admitted realm row")
	}
	input.Smoke.Required = false
	decision = Decide(input)
	t.Logf("background, smoke not required, no realm row: action=%s class=%s", decision.Action, decision.Class)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: background caller launched with no realm evidence at all")
	}

	deps = buildDecideDeps(t, true)
	addRealmEvidence(t, deps.universe, seedDigest(0xB1), "codex", "0.147.0")
	input = validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Realm.ServerGeneration = "generation-STALE-pre-reboot"
	decision = Decide(input)
	t.Logf("background + admitted realm row + stale typed generation: action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: stale server generation launched")
	}

	input = validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Smoke.Required = true
	input.Smoke.Record = smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple())
	target := smokeTarget()
	target.TmuxServerGeneration = "generation-STALE-pre-reboot"
	input.Smoke.Target = target
	decision = Decide(input)
	t.Logf("background + admitted realm row + smoke target stale generation: action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: smoke bound to a stale generation launched")
	}

	// Expired realm evidence: move the admission instant past expires_at.
	input = validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Backend.Now = time.Date(2027, time.July, 1, 0, 0, 0, 0, time.UTC)
	decision = Decide(input)
	t.Logf("background + realm row expired at admission instant: action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: expired realm evidence launched")
	}

	// Reboot: the AX-known raw generation moved; the evidence and probe
	// digest bind the old one.
	input = validInput(t, deps)
	input.Realm.Caller = CallerBackground
	input.Backend.RawGeneration = "generation-after-reboot"
	input.Realm.ServerGeneration = "generation-after-reboot"
	decision = Decide(input)
	t.Logf("background + realm row from before reboot (raw generation moved): action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: pre-reboot realm evidence launched after the generation moved")
	}
}

// N4: the credential-requiring path for a FOREGROUND caller. §4.C create
// row: `credential_capable_execution_realm` when provider credentials are
// required. Report whether a cached smoke record plus caller-supplied
// target claims launch without the admitted row.
func TestN2ProbeForegroundCredentialPathWithoutRealmRow(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Realm.Caller = CallerForeground
	input.Smoke.Required = true
	input.Smoke.Record = smokeRecord(t, "pass", "A", passingSmokeChecks(), smokeTuple())
	input.Smoke.Target = smokeTarget()
	decision := Decide(input)
	t.Logf("foreground + credentials required + cached passing smoke, no realm row: action=%s class=%s admitted=%v", decision.Action, decision.Class, decision.Admitted.Capabilities)
	if decision.Action == ActionLaunch {
		t.Logf("OBSERVATION: foreground credential-requiring launch is authorized by the smoke record plus caller-supplied Target claims, not by the admitted §4.D row")
	}
}

// N5: two admitted realm evidence objects, the first bound to another
// host binding, the second bound to this host: report the outcome.
func TestN2ProbeRealmEvidenceOrder(t *testing.T) {
	deps := buildDecideDeps(t, true)
	addRealmEvidence(t, deps.universe, seedDigest(0xB2), "codex", "0.147.0")
	// Second realm object for the real binding, signed by the same key.
	universe := deps.universe
	first := universe.evidence[len(universe.evidence)-1]
	object := map[string]any{}
	for key, value := range first {
		object[key] = value
	}
	object["terminal_binding_id"] = seedDigest(0xB1)
	object["attestation_signature"] = ""
	object["evidence_id"] = ""
	message := evidenceMessage(t, object)
	digest := sha256.Sum256(message)
	signature, err := rsa.SignPKCS1v15(rand.Reader, universe.key, crypto.SHA256, digest[:])
	if err != nil {
		t.Fatal(err)
	}
	object["attestation_signature"] = "rsa-sha256:" + base64.StdEncoding.EncodeToString(signature)
	object["evidence_id"] = omitSelfIdentity(t, object, "evidence_id")
	universe.evidence = append(universe.evidence, object)
	var ids []any
	for _, existing := range universe.evidence {
		ids = append(ids, existing["evidence_id"])
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i].(string) < ids[j].(string) })
	universe.probe["evidence_ids"] = ids
	universe.probe["probe_id"] = omitSelfIdentity(t, universe.probe, "probe_id")
	input := validInput(t, deps)
	input.Realm.Caller = CallerBackground
	decision := Decide(input)
	t.Logf("two realm objects (first 0xB2 foreign, second 0xB1 this host): action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
	// Swap order: this host's object first.
	universe.evidence[len(universe.evidence)-2], universe.evidence[len(universe.evidence)-1] = universe.evidence[len(universe.evidence)-1], universe.evidence[len(universe.evidence)-2]
	input = validInput(t, deps)
	input.Realm.Caller = CallerBackground
	decision = Decide(input)
	t.Logf("two realm objects (first 0xB1 this host, second 0xB2 foreign): action=%s class=%s cause=%v", decision.Action, decision.Class, decision.Cause)
}

// ---------------------------------------------------------------
// Rework verification: rev1 P1-3 (bootstrap window)
// ---------------------------------------------------------------

// R5 (rev1 probe 5): after the window closes, a restore with a new
// bootstrap operation launches — with the required materialization
// sourced from the winner's checkpoint (the producer's own test drops
// the materialization requirement).
func TestR2ProbePostWindowRestoreWithSourcedJournal(t *testing.T) {
	world := buildRunWorld(t)
	first, err := Run(world.stores(), runRequest(t, world))
	if err != nil || first.Decision.Action != ActionLaunch {
		t.Fatalf("first launch = (%v, %v)", first.Decision.Action, err)
	}
	localSuccessor(t, world, probeSuccessorLocal)
	world.mat = probeJournalSourced(t, world.ckptID)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = true
	request.CheckpointID = world.ckptID
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("post-window restore, new op, journal sourced from lease checkpoint: action=%s class=%s detail=%s cause=%v", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Detail, outcome.Decision.Cause)
	if outcome.Decision.Action != ActionLaunch {
		t.Errorf("FINDING: post-window restore with a new operation did not launch")
	}
	if outcome.Binding == nil || outcome.Binding.OperationID != fixtureOtherOp {
		t.Errorf("binding = %+v, want op2", outcome.Binding)
	}
	// In-window (fresh world, no checkpoint on the winner): changed op refuses.
	fresh := buildRunWorld(t)
	if _, err := Run(fresh.stores(), runRequest(t, fresh)); err != nil {
		t.Fatal(err)
	}
	request = runRequest(t, fresh)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	outcome, err = Run(fresh.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("in-window restore with changed op: action=%s class=%s", outcome.Decision.Action, outcome.Decision.Class)
	if outcome.Decision.Action != ActionRefused || outcome.Decision.Class != terminalbackend.CodeIdempotencyMismatch {
		t.Errorf("FINDING: in-window changed operation did not refuse idempotency_mismatch")
	}
}

// N3: post-window supersession and the identical-retry contract of
// §4.1: "An identical retry returns or reattaches to the one recorded
// wrapper/child". After op2 superseded op1 and op3 superseded op2, an
// identical retry of op2 must not start a second child for (session,
// op2).
func TestN2ProbeSupersededPairIdenticalRetry(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	localSuccessor(t, world, probeSuccessorLocal)
	run := func(op, instance string) Outcome {
		request := runRequest(t, world)
		request.Mode = ModeRestore
		request.BootstrapOperationID = op
		request.InstanceID = instance
		request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
		request.CheckpointRequired = true
		request.CheckpointID = world.ckptID
		outcome, err := Run(world.stores(), request)
		if err != nil {
			t.Fatalf("Run(%s) error = %v", op, err)
		}
		return outcome
	}
	op3 := "0198f4c8-7d40-7e55-8e6f-1234567890ad"
	second := run(fixtureOtherOp, "0198f4c9-2222-7bbb-8bbb-1234567890ab")
	t.Logf("op2 post-window: action=%s binding=%+v", second.Decision.Action, second.Binding)
	third := run(op3, "0198f4c9-3333-7ccc-8ccc-1234567890ab")
	t.Logf("op3 post-window: action=%s binding=%+v", third.Decision.Action, third.Binding)
	retry := run(fixtureOtherOp, "0198f4c9-4444-7ddd-8ddd-1234567890ab")
	t.Logf("identical retry of op2 after op3 superseded: action=%s binding=%+v", retry.Decision.Action, retry.Binding)
	if retry.Decision.Action == ActionLaunch {
		t.Errorf("FINDING: identical retry of (session, op2) launched a second child (instance %s) instead of reattaching to %s; the superseded receipt is gone", retry.Binding.TerminalInstanceID, second.Binding.TerminalInstanceID)
	}
	proven, found, err := world.pane.Status(fixtureSession)
	t.Logf("Status after three post-window operations: found=%v op=%s instance=%s err=%v", found, proven.OperationID, proven.TerminalInstanceID, err)
}

// N8/N9: conflicting arms around the window: a REMOTE winner closes the
// window (checkpoint) with a changed local op -> park, not mismatch; a
// remote winner in-window with a changed op -> which arm wins?
func TestN2ProbeWindowVsRemoteOwner(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.ExistingBinding = &Binding{SessionID: fixtureSession, OperationID: fixtureOtherOp, TerminalInstanceID: fixtureInstance, BindingDigest: seedDigest(0xB1), CreatedAt: fixtureCreatedAt}
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.Observation.Winner.Checkpoint = seedDigest(0xC9)
	input.Observation.Winner.HasCheckpoint = true
	input.RemoteInteractive = false
	decision := Decide(input)
	t.Logf("remote winner with checkpoint (window closed) + changed local op: action=%s reason=%s class=%s", decision.Action, decision.ParkReason, decision.Class)
	if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRemoteOwner {
		t.Errorf("post-window remote owner with a changed op did not park remote_owner")
	}
	input = validInput(t, deps)
	input.ExistingBinding = &Binding{SessionID: fixtureSession, OperationID: fixtureOtherOp, TerminalInstanceID: fixtureInstance, BindingDigest: seedDigest(0xB1), CreatedAt: fixtureCreatedAt}
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	decision = Decide(input)
	t.Logf("remote winner in-window + changed local op: action=%s reason=%s class=%s (documented precedence: idempotency before fencing)", decision.Action, decision.ParkReason, decision.Class)
}

// ---------------------------------------------------------------
// Rework verification: rev1 P1-4 (checkpoint admission) and one step away
// ---------------------------------------------------------------

// R6/R6b: non-lease checkpoint and foreign checkpoint park.
func TestR2ProbeCheckpointAdmissionBound(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.Checkpoint = seedDigest(0xC9)
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("caller checkpoint != lease checkpoint: action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: non-lease checkpoint admitted")
	}
	// Foreign session checkpoint with the winner carrying THAT digest
	// (a lease pointing at a foreign checkpoint): must still park on
	// the session binding.
	repository, err := sessrepo.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	var record map[string]any
	if err := json.Unmarshal([]byte(sessionRecordFixture), &record); err != nil {
		t.Fatal(err)
	}
	record["subject_id"] = fixtureForeign
	record["session_id"] = fixtureForeign
	reference, err := repository.CreateSession(identifyObject(t, record, "record_id"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err := repository.CreateLease(fixtureForeign, sessrepo.CreateLeaseInput{LeaseID: fixtureLeaseA, HolderHostID: fixtureLocalHost, IssuedByHostID: fixtureLocalHost, CreatedAt: fixtureCreatedAt}); err != nil {
		t.Fatal(err)
	}
	value := map[string]any{
		"schema": "urn:ax:schema:session-event", "schema_version": "1.0.0", "event_id": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
		"subject_id": fixtureForeign, "session_id": fixtureForeign, "event_type": "session.created", "created_by_host_id": fixtureLocalHost,
		"lease_epoch": 1, "lease_id": fixtureLeaseA, "lease_sequence": 1, "predecessors": []string{reference.RecordID},
		"created_at": fixtureCreatedAt, "payload": map[string]any{"session_record_id": reference.RecordID, "bootstrap_operation_id": fixtureBootstrap, "first_checkpoint_operation_id": fixtureOtherOp}, "extensions": map[string]any{},
	}
	created, err := repository.AppendEvent(fixtureForeign, identifyObject(t, value, "event_id"))
	if err != nil {
		t.Fatal(err)
	}
	store, err := sessckpt.Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	foreignID, foreignDoc := checkpointFixtureForRework(t, repository, store, fixtureForeign, []string{created.EventID})
	input = validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.Checkpoint = foreignID
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = foreignDoc
	input.CheckpointID = foreignID
	decision = Decide(input)
	t.Logf("foreign checkpoint that the lease itself names: action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: foreign-session checkpoint admitted when the lease names it")
	}
}

// N1: one step away from P1-4. The winning lease carries NO checkpoint
// (the epoch-1 bootstrap window; §13.10: "If the epoch-1 winning lease
// has a null checkpoint, resume is not an ordinary resume"; §13.1: a
// checkpoint record may exist in the store before it is authoritative).
// A caller naming a self-consistent checkpoint of this session must not
// be admitted for an ordinary resume, and a committed journal sourced
// from an arbitrary checkpoint must not be "valid".
func TestN2ProbeNullLeaseCheckpointAdmitsCallerCheckpoint(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	if input.Observation.Winner.HasCheckpoint {
		t.Fatal("fixture winner unexpectedly carries a checkpoint")
	}
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("restore, winner checkpoint=null, caller checkpoint %s of this session: action=%s reason=%s cause=%v", deps.ckptID[:20], decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: a checkpoint the winning lease does not carry was admitted for resume (lease checkpoint is null)")
	}
	input = validInput(t, deps)
	input.Mode = ModeRestore
	input.MaterializationRequired = true
	input.JournalOK = true
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
	decision = Decide(input)
	t.Logf("restore, winner checkpoint=null, committed journal sourced from %s: action=%s reason=%s cause=%v", seedDigest(0xD2)[:20], decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: a committed journal sourced from a checkpoint the lease does not carry was treated as valid (lease checkpoint is null)")
	}
	// Through Run: the runWorld winner (epoch 1) carries no checkpoint
	// while the store holds a captured checkpoint of this session.
	world := buildRunWorld(t)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.CheckpointRequired = true
	request.CheckpointID = world.ckptID
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("Run restore with null-checkpoint epoch-1 winner, stored checkpoint + journal sourced from 0xD2: action=%s reason=%s binding=%+v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Binding)
	if outcome.Decision.Action == ActionLaunch {
		t.Errorf("FINDING: Run launched an ordinary resume from a non-authoritative checkpoint inside the bootstrap window")
	}
}

// R7: materialization one generation behind the lease checkpoint.
func TestR2ProbeMaterializationOneGenerationBehind(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.MaterializationRequired = true
	input.JournalOK = true
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: seedDigest(0xD2), MaterializationID: fixtureMat}
	input.Observation.Winner.Checkpoint = deps.ckptID
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("committed journal one generation behind: action=%s reason=%s cause=%v", decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: stale materialization treated as valid")
	}
	// One step away: journal sourced from the lease checkpoint but the
	// journal is only prepared.
	input.Journal = matjournal.Journal{Phase: matjournal.PhasePrepared, SourceCheckpointID: deps.ckptID, MaterializationID: fixtureMat}
	decision = Decide(input)
	t.Logf("prepared journal sourced from the lease checkpoint: action=%s reason=%s", decision.Action, decision.ParkReason)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: prepared (uncommitted) journal treated as valid")
	}
	// And the positive: committed + sourced from the lease checkpoint launches.
	input.Journal = matjournal.Journal{Phase: matjournal.PhaseCommitted, SourceCheckpointID: deps.ckptID, MaterializationID: fixtureMat}
	decision = Decide(input)
	t.Logf("committed journal sourced from the lease checkpoint: action=%s cause=%v", decision.Action, decision.Cause)
	if decision.Action != ActionLaunch {
		t.Errorf("valid materialization did not launch")
	}
}

// R8: resume profile from the checkpoint closure, not the head.
func TestR2ProbeResumeProfileUsesClosure(t *testing.T) {
	deps := buildDecideDeps(t, true)
	changed := appendChainEvent(t, deps.repo, "profile.changed", 1, fixtureLeaseA, 2, deps.createdID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	input := validInput(t, deps)
	input.Mode = ModeRestore
	input.Observation.Winner.Checkpoint = deps.ckptID
	input.Observation.Winner.HasCheckpoint = true
	input.CheckpointRequired = true
	input.CheckpointDoc = deps.ckptDoc
	input.CheckpointID = deps.ckptID
	decision := Decide(input)
	t.Logf("resume from C1 (closure=[created]) with head-only E2=%s: action=%s profile=%+v", changed[:20], decision.Action, decision.Profile)
	if decision.Action == ActionLaunch && (decision.Profile.HasSource || decision.Profile.Profile != "standard") {
		t.Errorf("FINDING: resume carried the head pair instead of the closure pair")
	}
	// One step away: Run in restore mode where the caller supplies a
	// checkpoint store but the WINNER's checkpoint is what carries the
	// closure; a head-only profile.changed after the checkpoint.
	world := buildRunWorld(t)
	localSuccessor(t, world, probeSuccessorLocal)
	changed = appendChainEvent(t, world.repo, "profile.changed", 2, probeSuccessorLocal, 1, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	request.CheckpointRequired = true
	request.CheckpointID = world.ckptID
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("Run restore from lease checkpoint with an authoritative head-only profile.changed %s under the winner: action=%s profile=%+v", changed[:20], outcome.Decision.Action, outcome.Decision.Profile)
	if outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Source == changed {
		t.Errorf("FINDING: head-only profile event outside the checkpoint closure drove the resume profile")
	}
	// Launch mode (create) with the same chain: report which pair the
	// fresh activation carries (§5.2: first launch = record and null;
	// otherwise the effective profile at the referenced checkpoint).
	request = runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	outcome, err = Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("Run launch-mode create from stopped with a winner checkpoint and a head-only profile.changed: action=%s profile=%+v", outcome.Decision.Action, outcome.Decision.Profile)
}

// ---------------------------------------------------------------
// Rework verification: P2-3 / P2-4 / labels
// ---------------------------------------------------------------

// R4: non-interactive create without headless_creation through Run.
func TestR2ProbeNonInteractiveWithoutHeadless(t *testing.T) {
	world := buildRunWorld(t)
	universe := world.universe
	claims := universe.probe["capability_claims"].([]any)
	for _, raw := range claims {
		claim := raw.(map[string]any)
		if claim["capability"] == "headless_creation" {
			claim["value"] = false
		}
	}
	kept := universe.evidence[:0]
	for _, object := range universe.evidence {
		if object["capability"].(string) != "headless_creation" {
			kept = append(kept, object)
		}
	}
	universe.evidence = kept
	var ids []any
	for _, object := range universe.evidence {
		ids = append(ids, object["evidence_id"])
	}
	sort.Slice(ids, func(i, j int) bool { return ids[i].(string) < ids[j].(string) })
	universe.probe["evidence_ids"] = ids
	universe.probe["probe_id"] = omitSelfIdentity(t, universe.probe, "probe_id")
	request := runRequest(t, world)
	request.Interactive = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("non-interactive create, headless=false: action=%s class=%s admitted=%v", outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Admitted.Capabilities)
	if outcome.Decision.Action == ActionLaunch {
		t.Errorf("FINDING: non-interactive launch without headless_creation")
	}
	// One step away: interactive create on the same backend launches.
	request = runRequest(t, world)
	request.Interactive = true
	outcome, err = Run(world.stores(), request)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("interactive create, headless=false: action=%s", outcome.Decision.Action)
	// And a non-interactive RESTORE has no headless conditional (§4.C restore row).
	if _, found, _ := world.pane.Status(fixtureSession); found {
		t.Logf("binding present after interactive launch: %v", found)
	}
}

// R14: non-interactive remote owner label.
func TestR2ProbeRemoteOwnerLabels(t *testing.T) {
	deps := buildDecideDeps(t, true)
	for _, mode := range []Mode{ModeLaunch, ModeRestore} {
		input := validInput(t, deps)
		input.Mode = mode
		input.Observation.Winner.HolderHostID = fixtureRemoteHost
		input.RemoteInteractive = false
		decision := Decide(input)
		t.Logf("mode=%s non-interactive remote owner: action=%s reason=%s", mode, decision.Action, decision.ParkReason)
		if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRemoteOwner {
			t.Errorf("FINDING (label): non-interactive remote owner yields %s", decision.Action)
		}
		input.RemoteInteractive = true
		decision = Decide(input)
		t.Logf("mode=%s interactive remote owner, attach admitted: action=%s", mode, decision.Action)
		if decision.Action != ActionAttachRemote {
			t.Errorf("interactive remote owner with attach admitted did not offer attach_remote")
		}
	}
	noAttach := buildDecideDeps(t, false)
	input := validInput(t, noAttach)
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision := Decide(input)
	t.Logf("interactive remote owner, attach NOT admitted: action=%s", decision.Action)
	if decision.Action != ActionTakeoverOffer {
		t.Errorf("interactive remote owner without attach did not offer takeover")
	}
}

// R10/R11/R12/R13: conflicting arms and closed-set/descriptor checks.
func TestR2ProbeConflictingArmsAndClosedSets(t *testing.T) {
	deps := buildDecideDeps(t, true)
	input := validInput(t, deps)
	input.Observation = lapsedObservation(fixtureNow())
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision := Decide(input)
	t.Logf("remote interactive owner + expired local grant: action=%s class=%s reason=%s cause=%v (landed fencing order, rev1 P3-3)", decision.Action, decision.Class, decision.ParkReason, decision.Cause)

	input = validInput(t, deps)
	input.ConfigErr = errFixtureConfig
	input.ExistingBinding = &Binding{SessionID: fixtureSession, OperationID: fixtureOtherOp, TerminalInstanceID: fixtureInstance, BindingDigest: seedDigest(0xB1), CreatedAt: fixtureCreatedAt}
	decision = Decide(input)
	t.Logf("invalid config + changed op: action=%s class=%s", decision.Action, decision.Class)
	if decision.Class != ClassInvalidConfig {
		t.Errorf("config arm did not win")
	}
	input = validInput(t, deps)
	input.Observation.Verified = false
	input.Observation.Winner.HolderHostID = fixtureRemoteHost
	input.RemoteInteractive = true
	decision = Decide(input)
	t.Logf("unverified + remote interactive: action=%s reason=%s", decision.Action, decision.ParkReason)
	if decision.Action != ActionParked || decision.ParkReason != fencing.ParkRestorePolicy {
		t.Errorf("unverified remote owner offered instead of parking restore_policy")
	}

	deps = buildDecideDeps(t, true)
	claims := deps.universe.probe["capability_claims"].([]any)
	bogus := claimMap("headless_creation", "probed", true)
	bogus["capability"] = "teleport"
	deps.universe.probe["capability_claims"] = append(claims, bogus)
	deps.universe.probe["probe_id"] = omitSelfIdentity(t, deps.universe.probe, "probe_id")
	decision = Decide(validInput(t, deps))
	t.Logf("probe with capability 'teleport': action=%s class=%s", decision.Action, decision.Class)
	if decision.Action != ActionRefused {
		t.Errorf("capability outside the closed set not refused")
	}

	deps = buildDecideDeps(t, true)
	input = validInput(t, deps)
	input.HostBinding.Generation = "generation-other"
	decision = Decide(input)
	t.Logf("descriptor generation != host binding generation: action=%s class=%s", decision.Action, decision.Class)
	if decision.Action != ActionRefused || decision.Class != terminalbackend.CodeStaleGeneration {
		t.Errorf("descriptor generation drift not refused stale_generation")
	}
}

// N6: stale local presented token under a LOCAL checkpoint-bearing winner
// with a foldable (failed) chain: report whether the wrapper authors
// session.parked(stale_owner) under the winner's lease with a
// manufactured presented token, and whether the chain folds after.
func TestN2ProbeStaleLocalPresentedAuthorsUnderWinner(t *testing.T) {
	world := buildRunWorld(t)
	localSuccessor(t, world, probeSuccessorLocal)
	failed := appendChainEvent(t, world.repo, "session.failed", 2, probeSuccessorLocal, 1, world.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	_ = failed
	request := runRequest(t, world)
	request.Presented = fixturePresented() // epoch 1, lease A: stale
	before := eventCount(t, world.repo)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("stale presented (A, epoch 1) under local winner (A2, epoch 2), failed chain: action=%s reason=%s emitted=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted)
	if outcome.Emitted {
		decoded := decodeStoredEvent(t, world.repo, outcome.Event.EventID)
		t.Logf("authored event: lease=%s epoch=%d seq=%d created_by=%s reason=%s winning=%s", decoded.LeaseID, decoded.LeaseEpoch, decoded.LeaseSequence, decoded.CreatedBy, decoded.Payload.Reason, decoded.Payload.Winning)
		if decoded.LeaseID != probeSuccessorLocal || decoded.LeaseEpoch != 2 {
			t.Errorf("FINDING: parked event authored under a lease other than the locally held winner")
		}
	}
	projection, err := loadProjection(t, world.repo)
	t.Logf("chain after park: state=%q err=%v events %d -> %d", projection.State, err, before, eventCount(t, world.repo))
	if err != nil {
		t.Errorf("FINDING: chain no longer folds after the wrapper's park: %v", err)
	}
	// Second park on the same chain (already parked): must not
	// manufacture an invalid transition.
	outcome, err = Run(world.stores(), request)
	if err != nil {
		t.Fatal(err)
	}
	projection, err = loadProjection(t, world.repo)
	t.Logf("second park: emitted=%v state=%q err=%v", outcome.Emitted, projection.State, err)
	if err != nil {
		t.Errorf("FINDING: a second park breaks the chain: %v", err)
	}
}

// ---------------------------------------------------------------
// Durable bootstrap: crash seams, inode census, supersede seams
// ---------------------------------------------------------------

func execSelf(t *testing.T, pattern string, env ...string) error {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 60*time.Second)
	defer cancel()
	child := exec.CommandContext(ctx, os.Args[0], "-test.run="+pattern, "-test.count=1")
	child.Env = append(os.Environ(), env...)
	err := child.Run()
	var exitErr *exec.ExitError
	if !errors.As(err, &exitErr) {
		t.Fatalf("child run = %v, want a signal-kill exit", err)
	}
	status, ok := exitErr.Sys().(syscall.WaitStatus)
	if !ok || !status.Signaled() || status.Signal() != syscall.SIGKILL {
		t.Fatalf("child status = %v, want killed by SIGKILL", exitErr)
	}
	return err
}

func dirNames(t *testing.T, dir string) []string {
	t.Helper()
	entries, _ := os.ReadDir(dir)
	var names []string
	for _, entry := range entries {
		names = append(names, entry.Name())
	}
	return names
}

// C1: real SIGKILL before the no-replace commit (AfterStage).
func TestR2ProbeCrashBeforeCommit(t *testing.T) {
	if os.Getenv("AX_REVIEW2_CRASH") == "stage" {
		store, err := Open(os.Getenv("AX_REVIEW2_STORE"))
		if err != nil {
			t.Fatal(err)
		}
		store.WithHooks(&Hooks{AfterStage: func(path string) error {
			proc, _ := os.FindProcess(os.Getpid())
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}})
		_, _, _ = store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
		t.Fatal("returned past SIGKILL")
		return
	}
	storeDir := t.TempDir()
	if _, err := Open(storeDir); err != nil {
		t.Fatal(err)
	}
	child := execSelf(t, "^TestR2ProbeCrashBeforeCommit$", "AX_REVIEW2_CRASH=stage", "AX_REVIEW2_STORE="+storeDir)
	t.Logf("child exit: %v", child)
	store, err := Open(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	_, found, err := store.Status(fixtureSession)
	t.Logf("Status after kill-before-commit: found=%v err=%v dir=%v", found, err, dirNames(t, filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession)))
	if err != nil || found {
		t.Errorf("expected proven absence after a pre-commit kill")
	}
	bound, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
	if err != nil || reattached {
		t.Errorf("retry after pre-commit kill = (%+v, reattached=%v, err=%v), want a fresh install", bound, reattached, err)
	}
	names := dirNames(t, filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession))
	t.Logf("session dir after retry: %v (stale staging is swept only after 1 minute by design)", names)
	count := 0
	for _, name := range names {
		if name == "binding.json" {
			count++
		}
	}
	if count != 1 {
		t.Errorf("binding count = %d, want exactly one", count)
	}
}

// C1b: real SIGKILL after the commit (AfterInstall) during Bind.
func TestR2ProbeCrashAfterCommit(t *testing.T) {
	if os.Getenv("AX_REVIEW2_CRASH") == "install" {
		store, err := Open(os.Getenv("AX_REVIEW2_STORE"))
		if err != nil {
			t.Fatal(err)
		}
		store.WithHooks(&Hooks{AfterInstall: func(path string) error {
			proc, _ := os.FindProcess(os.Getpid())
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}})
		_, _, _ = store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
		t.Fatal("returned past SIGKILL")
		return
	}
	storeDir := t.TempDir()
	if _, err := Open(storeDir); err != nil {
		t.Fatal(err)
	}
	_ = execSelf(t, "^TestR2ProbeCrashAfterCommit$", "AX_REVIEW2_CRASH=install", "AX_REVIEW2_STORE="+storeDir)
	store, err := Open(storeDir)
	if err != nil {
		t.Fatal(err)
	}
	proven, found, err := store.Status(fixtureSession)
	t.Logf("Status after kill-after-commit: found=%v instance=%s err=%v dir=%v", found, proven.TerminalInstanceID, err, dirNames(t, filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession)))
	if err != nil || !found {
		t.Errorf("expected the committed binding after a post-commit kill")
	}
	other := bindCandidate()
	other.TerminalInstanceID = "0198f4c9-3333-7ccc-8ccc-1234567890ab"
	other.BindingDigest = BindingDigest(other)
	again, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, other)
	if err != nil || !reattached || again.TerminalInstanceID != proven.TerminalInstanceID {
		t.Errorf("retry after post-commit kill = (%+v, %v, %v), want reattach to the one child", again, reattached, err)
	}
}

// C2: identical retries reattach without a second write.
func TestR2ProbeIdenticalRetryInodeCensus(t *testing.T) {
	store, err := Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	first, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate())
	if err != nil || reattached {
		t.Fatalf("first bind = (%+v, %v, %v)", first, reattached, err)
	}
	path := store.bindingPath(fixtureSession)
	before, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	beforeIno := before.Sys().(*syscall.Stat_t).Ino
	beforeBytes, _ := os.ReadFile(path)
	for round := 0; round < 3; round++ {
		other := bindCandidate()
		other.TerminalInstanceID = "0198f4c9-3333-7ccc-8ccc-1234567890ab"
		other.BindingDigest = BindingDigest(other)
		again, reattached, err := store.Bind(fixtureSession, fixtureBootstrap, other)
		if err != nil || !reattached || again != first {
			t.Fatalf("retry %d = (%+v, %v, %v), want reattach to %+v", round, again, reattached, err, first)
		}
	}
	after, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	afterIno := after.Sys().(*syscall.Stat_t).Ino
	afterBytes, _ := os.ReadFile(path)
	t.Logf("inode before=%d after=%d mtime equal=%v bytes-equal=%v entries=%d", beforeIno, afterIno, before.ModTime().Equal(after.ModTime()), string(beforeBytes) == string(afterBytes), len(dirNames(t, filepath.Dir(path))))
	if beforeIno != afterIno || !before.ModTime().Equal(after.ModTime()) || string(beforeBytes) != string(afterBytes) {
		t.Errorf("identical retry rewrote the binding")
	}
}

// C3: crash seams of Supersede (the new post-window write): kill after
// stage leaves the OLD binding; kill after rename leaves the NEW binding.
func TestR2ProbeSupersedeCrashSeams(t *testing.T) {
	mode := os.Getenv("AX_REVIEW2_SUPERSEDE")
	if mode == "stage" || mode == "install" {
		store, err := Open(os.Getenv("AX_REVIEW2_STORE"))
		if err != nil {
			t.Fatal(err)
		}
		kill := func(path string) error {
			proc, _ := os.FindProcess(os.Getpid())
			_ = proc.Signal(syscall.SIGKILL)
			select {}
		}
		if mode == "stage" {
			store.WithHooks(&Hooks{AfterStage: kill})
		} else {
			store.WithHooks(&Hooks{AfterInstall: kill})
		}
		candidate := bindCandidate()
		candidate.OperationID = fixtureOtherOp
		candidate.TerminalInstanceID = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
		candidate.BindingDigest = BindingDigest(candidate)
		_, _, _ = store.Supersede(fixtureSession, fixtureOtherOp, candidate)
		t.Fatal("returned past SIGKILL")
		return
	}
	for _, seam := range []string{"stage", "install"} {
		storeDir := t.TempDir()
		store, err := Open(storeDir)
		if err != nil {
			t.Fatal(err)
		}
		if _, _, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate()); err != nil {
			t.Fatal(err)
		}
		_ = execSelf(t, "^TestR2ProbeSupersedeCrashSeams$", "AX_REVIEW2_SUPERSEDE="+seam, "AX_REVIEW2_STORE="+storeDir)
		store, err = Open(storeDir)
		if err != nil {
			t.Fatal(err)
		}
		proven, found, err := store.Status(fixtureSession)
		names := dirNames(t, filepath.Join(storeDir, "axpane", "bootstrap", fixtureSession))
		t.Logf("supersede kill-after-%s: found=%v op=%s instance=%s err=%v dir=%v", seam, found, proven.OperationID, proven.TerminalInstanceID, err, names)
		if err != nil || !found {
			t.Errorf("seam %s: expected a complete binding, got found=%v err=%v", seam, found, err)
			continue
		}
		wantOp := fixtureBootstrap
		if seam == "install" {
			wantOp = fixtureOtherOp
		}
		if proven.OperationID != wantOp {
			t.Errorf("seam %s: binding op = %s, want %s", seam, proven.OperationID, wantOp)
		}
	}
}

// N10: two post-window wrappers with different operations: both
// supersede (rename-over has no no-replace guard). Report.
func TestN2ProbePostWindowConcurrentDifferentOps(t *testing.T) {
	store, err := Open(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := store.Bind(fixtureSession, fixtureBootstrap, bindCandidate()); err != nil {
		t.Fatal(err)
	}
	op3 := "0198f4c8-7d40-7e55-8e6f-1234567890ad"
	a := bindCandidate()
	a.OperationID = fixtureOtherOp
	a.TerminalInstanceID = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
	a.BindingDigest = BindingDigest(a)
	b := bindCandidate()
	b.OperationID = op3
	b.TerminalInstanceID = "0198f4c9-3333-7ccc-8ccc-1234567890ab"
	b.BindingDigest = BindingDigest(b)
	boundA, _, errA := store.Supersede(fixtureSession, fixtureOtherOp, a)
	boundB, _, errB := store.Supersede(fixtureSession, op3, b)
	t.Logf("supersede op2: op=%s err=%v; supersede op3: op=%s err=%v", boundA.OperationID, errA, boundB.OperationID, errB)
	proven, _, _ := store.Status(fixtureSession)
	t.Logf("Status: op=%s instance=%s — the op2 child is no longer identifiable through the binding", proven.OperationID, proven.TerminalInstanceID)
}

// N6b: same-epoch losing presented lease under a LOCAL winner with a
// foldable (failed) chain: the wrapper parks stale_owner and authors
// session.parked under the winner it holds; the chain must still fold
// after one and after two parks.
func TestN2ProbeStaleLocalPresentedSameEpoch(t *testing.T) {
	world := buildRunWorld(t)
	appendChainEvent(t, world.repo, "session.failed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	request := runRequest(t, world)
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: "ffffffff-eeee-4ddd-8ccc-bbbbbbbbbbbb"}
	before := eventCount(t, world.repo)
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("losing presented lease under local winner A, failed chain: action=%s reason=%s emitted=%v", outcome.Decision.Action, outcome.Decision.ParkReason, outcome.Emitted)
	if outcome.Emitted {
		decoded := decodeStoredEvent(t, world.repo, outcome.Event.EventID)
		t.Logf("authored event: lease=%s epoch=%d seq=%d created_by=%s reason=%s winning=%s", decoded.LeaseID, decoded.LeaseEpoch, decoded.LeaseSequence, decoded.CreatedBy, decoded.Payload.Reason, decoded.Payload.Winning)
		if decoded.LeaseID != fixtureLeaseA || decoded.Payload.Reason != "stale_owner" {
			t.Errorf("FINDING: parked event not authored under the held winner with the stale_owner reason")
		}
	}
	projection, err := loadProjection(t, world.repo)
	t.Logf("chain after park: state=%q err=%v events %d -> %d", projection.State, err, before, eventCount(t, world.repo))
	if err != nil {
		t.Errorf("FINDING: chain no longer folds after the wrapper's park: %v", err)
	}
	outcome, err = Run(world.stores(), request)
	if err != nil {
		t.Fatal(err)
	}
	projection, err = loadProjection(t, world.repo)
	t.Logf("second park: emitted=%v state=%q err=%v events=%d", outcome.Emitted, projection.State, err, eventCount(t, world.repo))
	if err != nil {
		t.Errorf("FINDING: a second park breaks the chain: %v", err)
	}
}

// R9b: the mutation gate itself, reached with a FOLDABLE chain: a
// losing presented tuple (epoch 1, lease A) under a remote winner
// (epoch 2, lease B) must refuse at AuthorizeMutation, not at the fold
// pre-check. The producer's TestEmitUnderLosingLeaseRefuses uses the
// creating chain and refuses at the fold check instead.
func TestR2ProbeLosingLeaseReachesMutationGate(t *testing.T) {
	world := buildRunWorld(t)
	failedID := appendChainEvent(t, world.repo, "session.failed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	foldable, err := canAuthorParked(world.repo, fixtureSession)
	if err != nil || !foldable {
		t.Fatalf("chain not foldable: %v %v", foldable, err)
	}
	remoteTakeover(t, world)
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	decision := Decision{Action: ActionParked, ParkReason: fencing.ParkStaleOwner, WinningLeaseID: fixtureLeaseB}
	_, _, err = EmitParked(world.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{failedID}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation,
	})
	t.Logf("foldable chain, losing presented (1,A) under remote winner (2,B): err=%v", err)
	if err == nil {
		t.Errorf("FINDING: losing-lease append accepted")
	}
	// Local successor case: winner (2, A2) local; presented (1, A) losing.
	world2 := buildRunWorld(t)
	failed2 := appendChainEvent(t, world2.repo, "session.failed", 1, fixtureLeaseA, 2, world2.headID, map[string]any{
		"error_code": "bootstrap_probe", "retryable": false, "operation_id": nil,
	})
	localSuccessor(t, world2, probeSuccessorLocal)
	observation2, err := ObserveOwnership(world2.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = EmitParked(world2.repo, decision, EmitParams{
		SessionID: fixtureSession, CreatedByHost: fixtureLocalHost,
		LeaseEpoch: 1, LeaseID: fixtureLeaseA, LeaseSequence: 3,
		Predecessors: []string{failed2}, CreatedAt: fixtureCreatedAt,
		Presented:   fencing.PresentedToken{SessionID: fixtureSession, Epoch: 1, LeaseID: fixtureLeaseA},
		Observation: observation2,
	})
	t.Logf("foldable chain, losing presented (1,A) under LOCAL winner (2,A2): err=%v", err)
	if err == nil {
		t.Errorf("FINDING: losing-lease append accepted under a local successor")
	}
}

// N11: create-from-stopped through Run: launch mode, post-window
// (winner carries a checkpoint), changed bootstrap operation. §4.C:
// create is allowed from stopped; the rework brief: "allow create from
// stopped". Must launch with a superseded binding.
func TestN2ProbeCreateFromStoppedPostWindow(t *testing.T) {
	world := buildRunWorld(t)
	if _, err := Run(world.stores(), runRequest(t, world)); err != nil {
		t.Fatal(err)
	}
	localSuccessor(t, world, probeSuccessorLocal)
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	outcome, err := Run(world.stores(), request)
	t.Logf("launch-mode post-window changed op through Run: action=%s class=%s binding=%+v err=%v", outcome.Decision.Action, outcome.Decision.Class, outcome.Binding, err)
	if err != nil || outcome.Decision.Action != ActionLaunch || outcome.Binding == nil || outcome.Binding.OperationID != fixtureOtherOp {
		t.Errorf("FINDING: create from stopped (post-window, launch mode) did not launch with a superseded binding")
	}
}

// N12: Run with no checkpoint store while the winner carries a
// checkpoint: does the profile silently fall back to the session head?
func TestN2ProbeNoCkptStoreProfileFallsBackToHead(t *testing.T) {
	world := buildRunWorld(t)
	localSuccessor(t, world, probeSuccessorLocal)
	changed := appendChainEvent(t, world.repo, "profile.changed", 2, probeSuccessorLocal, 1, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	request := runRequest(t, world)
	request.Mode = ModeLaunch
	request.BootstrapOperationID = fixtureOtherOp
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: probeSuccessorLocal}
	stores := world.stores()
	stores.Ckpt = nil
	outcome, err := Run(stores, request)
	t.Logf("no Ckpt store, winner carries checkpoint, head-only profile.changed %s: action=%s profile=%+v err=%v", changed[:20], outcome.Decision.Action, outcome.Decision.Profile, err)
	if err == nil && outcome.Decision.Action == ActionLaunch && outcome.Decision.Profile.Source == changed {
		t.Logf("OBSERVATION: without a checkpoint store the launch profile silently comes from the session head, not the winner's checkpoint closure")
	}
}

// N13: the epoch-1 owner. Lease records are immutable and only a
// successor lease (CompareAndSwapLease) carries a checkpoint, so the
// winning lease of a session that never changed hands has a null
// checkpoint forever, however many checkpoints the chain published. The
// wrapper keys the bootstrap window, the checkpoint binding and the
// journal binding on Winner.HasCheckpoint/Winner.Checkpoint. Build the
// ordinary same-host story — created, idle, stopped with a checkpoint —
// and drive a post-checkpoint restore with a new bootstrap operation.
func TestN2ProbeEpochOneOwnerAfterCheckpoint(t *testing.T) {
	world := buildRunWorld(t)
	// Bind op1 during the bootstrap window (the create).
	first, err := Run(world.stores(), runRequest(t, world))
	if err != nil || first.Decision.Action != ActionLaunch {
		t.Fatalf("first launch = (%v, %v)", first.Decision.Action, err)
	}
	// The owner reaches a boundary and stops with the checkpoint: the
	// first checkpoint is published (§13.1 step 7 closes the window).
	idleID := appendChainEvent(t, world.repo, "session.idle", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"boundary_ref": "turn-1", "foreground_idle": true, "background_idle": true,
	})
	stoppedID := appendChainEvent(t, world.repo, "session.stopped", 1, fixtureLeaseA, 3, idleID, map[string]any{
		"graceful": true, "checkpoint_id": world.ckptID, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	_ = stoppedID
	projection, err := loadProjection(t, world.repo)
	if err != nil {
		t.Fatal(err)
	}
	observation, err := ObserveOwnership(world.repo, fixtureSession, runObserve(fixtureNow()))
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("landed state engine: state=%s HasCheckpoint=%v newest=%s | winning lease: epoch=%d HasCheckpoint=%v", projection.State, projection.HasCheckpoint, projection.Newest.ID[:20], observation.Winner.Epoch, observation.Winner.HasCheckpoint)
	// Post-checkpoint restore on the same host with a NEW bootstrap
	// operation, journal sourced from the published checkpoint.
	world.mat = probeJournalSourced(t, world.ckptID)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = "0198f4c9-2222-7bbb-8bbb-1234567890ab"
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = true
	request.CheckpointID = world.ckptID
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("epoch-1 owner, stopped with checkpoint %s, restore with new op: action=%s class=%s detail=%q", world.ckptID[:20], outcome.Decision.Action, outcome.Decision.Class, outcome.Decision.Detail)
	if outcome.Decision.Action == ActionRefused && outcome.Decision.Class == terminalbackend.CodeIdempotencyMismatch {
		t.Errorf("FINDING: the bootstrap window never closes for an epoch-1 owner (the lease record cannot carry a checkpoint); the post-checkpoint restore is refused idempotency_mismatch on the creating host")
	}
	// Same state, the newest checkpoint is C (in the chain); a second
	// self-consistent checkpoint C2 of this session that the chain never
	// published is admitted by Decide because the lease checkpoint is null.
	c2ID, c2Doc := captureWithOperation(t, world.repo, world.ckpt, fixtureOtherOp, []string{idleID})
	if c2ID == world.ckptID {
		t.Fatal("fixture produced the same checkpoint")
	}
	record, events, err := LoadProfile(world.repo, fixtureSession)
	if err != nil {
		t.Fatal(err)
	}
	deps := &decideDeps{universe: world.universe, repo: world.repo}
	input := validInput(t, deps)
	input.Observation = observation
	input.ProfileRecord = record
	input.ProfileEvents = events
	input.Mode = ModeRestore
	input.CheckpointRequired = true
	input.CheckpointDoc = c2Doc
	input.CheckpointID = c2ID
	decision := Decide(input)
	t.Logf("epoch-1 owner, chain newest=%s, caller names unpublished C2=%s: action=%s reason=%s cause=%v", world.ckptID[:20], c2ID[:20], decision.Action, decision.ParkReason, decision.Cause)
	if decision.Action == ActionLaunch {
		t.Errorf("FINDING: an unpublished checkpoint (not the chain's newest) is admitted for the epoch-1 owner because the lease checkpoint is null")
	}
}

func captureWithOperation(t *testing.T, repository *sessrepo.Repository, store *sessckpt.Store, operation string, heads []string) (string, []byte) {
	t.Helper()
	reference, raw, err := store.Capture(repository, sessckpt.Inputs{
		OperationID:         operation,
		SessionID:           fixtureSession,
		SessionKind:         sessckpt.SessionKindDirect,
		LeaseEpoch:          1,
		LeaseID:             fixtureLeaseA,
		CreatorHostID:       fixtureLocalHost,
		WorkspaceManifestID: seedDigest(0xE1),
		ProviderManifestID:  seedDigest(0xE2),
		Boundary: sessckpt.SafeBoundary{
			ProviderID: "codex", ProviderVersion: "0.147.0", Evidence: sessckpt.EvidenceAcceptedTest,
			InputBlocked: true, ForegroundIdle: true, BackgroundIdle: true, OpenProcesses: 0, OpenDatabaseHandles: 0,
		},
		EventHeads: heads,
		CreatedAt:  fixtureCreatedAt,
		Extensions: map[string]string{},
	})
	if err != nil {
		t.Fatalf("Capture() error = %v", err)
	}
	return reference.CheckpointID, raw
}
