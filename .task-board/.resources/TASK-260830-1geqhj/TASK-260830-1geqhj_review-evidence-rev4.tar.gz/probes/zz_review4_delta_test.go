package axpane

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/relux-works/agent-session-manager/internal/fencing"
	"github.com/relux-works/agent-session-manager/internal/sessckpt"
)

// DX4-1: delta witness for RV4-6. The yolo->standard post-takeover
// world (C0 closure yolo, successor set standard before C1), then a
// RESTORE with the journal required (sourced from C1) and NO required
// checkpoint. Pristine: standard from C1's closure (the fold newest).
// Under a mutant that reads Winner.Checkpoint on this path: yolo with
// the bypass mapping.
func TestDX4_JournalOnlyRestoreClosureSource(t *testing.T) {
	world := buildRunWorld(t)
	toYolo := appendChainEvent(t, world.repo, "profile.changed", 1, fixtureLeaseA, 2, world.headID, map[string]any{
		"from": "standard", "to": "yolo", "confirmed": true,
	})
	c0, _ := rev4Capture(t, world.repo, world.ckpt, rev4Op4, 1, fixtureLeaseA, []string{toYolo})
	world.headID = publishCheckpoint(t, world.repo, toYolo, 3, c0)
	successorLease(t, world.repo, rev4Successor, fixtureLocalHost, c0)
	resumedID := appendChainEvent(t, world.repo, "session.resumed", 2, rev4Successor, 1, world.headID, map[string]any{
		"checkpoint_id": c0, "execution_profile": "yolo", "profile_source_event_id": toYolo,
		"terminal_backend": "tmux", "native_session_id": "native-session-alpha",
	})
	toStandard := appendChainEvent(t, world.repo, "profile.changed", 2, rev4Successor, 2, resumedID, map[string]any{
		"from": "yolo", "to": "standard", "confirmed": true,
	})
	idleID := appendChainEvent(t, world.repo, "session.idle", 2, rev4Successor, 3, toStandard, map[string]any{
		"boundary_ref": "turn-2", "foreground_idle": true, "background_idle": true,
	})
	c1, _ := rev4Capture(t, world.repo, world.ckpt, rev4Op3, 2, rev4Successor, []string{idleID})
	world.headID = appendChainEvent(t, world.repo, "session.stopped", 2, rev4Successor, 4, idleID, map[string]any{
		"graceful": true, "checkpoint_id": c1, "resumable": true, "closure_kind": "checkpointed", "process_closed": true, "store_closed": true,
	})
	world.mat = journalSourced(t, c1)
	request := runRequest(t, world)
	request.Mode = ModeRestore
	request.BootstrapOperationID = fixtureOtherOp
	request.InstanceID = rev4Inst2
	request.Presented = fencing.PresentedToken{SessionID: fixtureSession, Epoch: 2, LeaseID: rev4Successor}
	request.MaterializationRequired = true
	request.MaterializationID = fixtureMat
	request.CheckpointRequired = false
	outcome, err := Run(world.stores(), request)
	if err != nil {
		t.Fatalf("Run() error = %v", err)
	}
	t.Logf("journal-only restore under successor (base C0 closure yolo, newest C1 closure standard): action=%s profile=%+v mapping=%q",
		outcome.Decision.Action, outcome.Decision.Profile, outcome.Decision.Mapping)
	if outcome.Decision.Action != ActionLaunch {
		t.Fatalf("want launch: %v", outcome.Decision.Cause)
	}
	if outcome.Decision.Profile.Profile != "standard" || outcome.Decision.Profile.Source != toStandard {
		t.Fatalf("WITNESS: journal-only restore carries %+v mapping %q instead of the newest checkpoint's closure (standard/%s)", outcome.Decision.Profile, outcome.Decision.Mapping, toStandard[:20])
	}
}

// DX4-2: delta witness for RV4-12. The stored checkpoint blob is
// corrupted in place (a read that fails attestation, NOT ENOENT).
// Pristine: Run fails with the load error, no decision (unknown is
// not absence). Under a mutant laundering any error as absence:
// restore parks "none is admitted" (wrong fact) and launch-mode
// fails "newest absent from the store" (wrong fact).
func TestDX4_CorruptCheckpointBlobIsNotAbsence(t *testing.T) {
	world := buildRunWorld(t)
	world.headID = publishCheckpoint(t, world.repo, world.headID, 2, world.ckptID)
	world.mat = journalSourced(t, world.ckptID)
	// Corrupt the blob: flip bytes so attestation fails.
	ckptRoot := t.TempDir()
	corrupt, err := sessckpt.Open(ckptRoot)
	if err != nil {
		t.Fatal(err)
	}
	raw, err := world.ckpt.Get(world.ckptID)
	if err != nil {
		t.Fatal(err)
	}
	hex := strings.TrimPrefix(world.ckptID, "sha256:")
	if err := os.WriteFile(filepath.Join(ckptRoot, "checkpoints", hex+".json"), append([]byte("{\"corrupt\":1,"), raw[1:]...), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := corrupt.Get(world.ckptID); err == nil || os.IsNotExist(err) {
		t.Fatalf("corrupt blob Get() = %v, want a non-ENOENT failure", err)
	}
	stores := world.stores()
	stores.Ckpt = corrupt
	for _, mode := range []Mode{ModeRestore, ModeLaunch} {
		request := runRequest(t, world)
		request.Mode = mode
		if mode == ModeRestore {
			request.MaterializationRequired = true
			request.MaterializationID = fixtureMat
			request.CheckpointRequired = true
			request.CheckpointID = world.ckptID
		}
		outcome, err := Run(stores, request)
		t.Logf("%s over a corrupt checkpoint blob: action=%q cause=%v err=%v", mode, outcome.Decision.Action, outcome.Decision.Cause, err)
		if err == nil {
			t.Fatalf("WITNESS(%s): a checkpoint-store read failure produced a decision (%q, cause %v) instead of the load error", mode, outcome.Decision.Action, outcome.Decision.Cause)
		}
		if strings.Contains(err.Error(), "absent") {
			t.Fatalf("WITNESS(%s): a read failure was reported as absence: %v", mode, err)
		}
	}
}
