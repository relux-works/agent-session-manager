#!/usr/bin/env python3
"""Reviewer mutants for CR-TASK-260830-1geqhj-4 (RUN-260917-e644e0).

Runs against an isolated copy of the exact candidate tree (argv[1] =
repo root). The killer is the WHOLE committed internal/axpane suite,
so a kill means a shipped test fails; the raw go test output and the
subprocess exit are written per plant to <logdir>/<name>.log. Each
production file is restored from a byte backup after every row and
the blob OIDs are printed at the end.

Usage: PYTHONDONTWRITEBYTECODE=1 python3 review4_mutants.py <repo> <logdir> [names...]
"""
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

PACKAGE = "internal/axpane"


@dataclass(frozen=True)
class Mutant:
    name: str
    path: str
    find: str
    replace: str
    expect: str
    note: str


MUTANTS = [
    Mutant(
        name="RV4-1-identity-session-result-ignored",
        path="decide.go",
        find="\tif err := checkIdentitySession(facts.Identity, sessionID); err != nil {\n\t\treturn err\n\t}\n",
        replace="\t_ = checkIdentitySession(facts.Identity, sessionID)\n",
        expect="KILLED",
        note="Gate result ignored (P3-7 fix): the identity session binding is evaluated and discarded.",
    ),
    Mutant(
        name="RV4-2-nullfold-arm-before-fencing",
        path="decide.go",
        find="\ttoken, err := authorize(input)\n\tif err != nil {\n",
        replace="\tif input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint && !input.HasNewestCheckpoint {\n\t\treturn parked(fencing.ParkRestorePolicy, input.Observation.Winner.LeaseID, errSuccessorNullFold())\n\t}\n\ttoken, err := authorize(input)\n\tif err != nil {\n",
        expect="KILLED",
        note="After-restore order: the successor implication arm is evaluated BEFORE fencing (steps 3/4 swapped for the new arm): a REMOTE checkpoint-carrying winner over a null local fold parks restore_policy instead of offering attach/takeover.",
    ),
    Mutant(
        name="RV4-3-park-reason-failed-handoff-collapsed",
        path="decide.go",
        find="\tif reason != fencing.ParkRemoteOwner {\n\t\treturn parked(reason, winning, cause)\n\t}\n",
        replace="\tif reason != fencing.ParkRemoteOwner {\n\t\tif reason == fencing.ParkFailedHandoff {\n\t\t\treason = fencing.ParkRestorePolicy\n\t\t}\n\t\treturn parked(reason, winning, cause)\n\t}\n",
        expect="KILLED",
        note="Park reason vocabulary collapsed for exactly one member: failed_handoff reported as restore_policy.",
    ),
    Mutant(
        name="RV4-4-window-check-dropped",
        path="decide.go",
        find="func bootstrapWindowClosed(input Input) bool {\n\treturn input.HasNewestCheckpoint\n}\n",
        replace="func bootstrapWindowClosed(input Input) bool {\n\treturn true\n}\n",
        expect="KILLED",
        note="Bootstrap window check dropped: every changed operation is post-window.",
    ),
    Mutant(
        name="RV4-5-nullfold-arm-admits-epoch-2",
        path="decide.go",
        find="\tif input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint && !input.HasNewestCheckpoint {\n",
        replace="\tif input.Observation.HasWinner && input.Observation.Winner.HasCheckpoint && !input.HasNewestCheckpoint && input.Observation.Winner.Epoch != 2 {\n",
        expect="KILLED",
        note="Narrowing on a dimension other than mode: the implication arm admits exactly the epoch-2 successor over a null fold.",
    ),
    Mutant(
        name="RV4-6-closure-from-lease-base-restore-without-required-ckpt",
        path="run.go",
        find="\t\t\tif input.HasNewestCheckpoint && stores.Ckpt != nil {\n\t\t\t\tloaded, err := LoadCheckpoint(stores.Ckpt, input.NewestCheckpointID)\n",
        replace="\t\t\tif input.HasNewestCheckpoint && stores.Ckpt != nil {\n\t\t\t\tsource := input.NewestCheckpointID\n\t\t\t\tif request.Mode == ModeRestore && observation.Winner.HasCheckpoint {\n\t\t\t\t\tsource = observation.Winner.Checkpoint\n\t\t\t\t}\n\t\t\t\tloaded, err := LoadCheckpoint(stores.Ckpt, source)\n",
        expect="KILLED",
        note="Closure source regresses to the lease handoff base on exactly the restore-mode path with NO required checkpoint (journal-only restore) under a successor lease.",
    ),
    Mutant(
        name="RV4-7-replay-flip-requires-equal-instance",
        path="run.go",
        find="\t\t\tif replayed {\n",
        replace="\t\t\tif replayed && bound.TerminalInstanceID == candidate.TerminalInstanceID {\n",
        expect="KILLED",
        note="P2-1 flip narrowed to a condition never true in a real race (the winner's instance differs): the loser keeps launch.",
    ),
    Mutant(
        name="RV4-8-supersede-found-path-no-replay-signal",
        path="binding.go",
        find="\treplayed := found\n",
        replace="\treplayed := false\n",
        expect="KILLED",
        note="Supersede's pre-install Lookup-found path reports a fresh install instead of the replay.",
    ),
    Mutant(
        name="RV4-9-decide-required-doc-closure-disabled",
        path="decide.go",
        find="\tif len(heads) == 0 && input.CheckpointRequired && len(input.CheckpointDoc) > 0 {\n",
        replace="\tif len(heads) == 0 && input.CheckpointRequired && len(input.CheckpointDoc) > 0 && input.Mode == ModeLaunch {\n",
        expect="KILLED",
        note="Decide's own closure fallback from the required checkpoint disabled on restore: session head derived.",
    ),
    Mutant(
        name="RV4-10-remote-noninteractive-offers-takeover",
        path="decide.go",
        find="\tif !input.RemoteInteractive {\n\t\treturn parked(reason, winning, cause)\n\t}\n",
        replace="\tif !input.RemoteInteractive && input.Mode == ModeRestore {\n\t\treturn parked(reason, winning, cause)\n\t}\n",
        expect="KILLED",
        note="Step-5 park narrowed: a non-interactive remote owner in launch mode offers takeover instead of parking.",
    ),
    Mutant(
        name="RV4-11-bind-race-flip-restore-only",
        path="run.go",
        find="\t\tif reattached {\n",
        replace="\t\tif reattached && request.Mode == ModeRestore {\n",
        expect="KILLED",
        note="In-window Bind race flip narrowed to restore mode: a launch-mode race loser keeps launch.",
    ),
    Mutant(
        name="RV4-12-loadcheckpoint-launders-any-error-as-absence",
        path="gates.go",
        find="\t\tif os.IsNotExist(err) {\n\t\t\treturn nil, nil\n\t\t}\n\t\treturn nil, err\n",
        replace="\t\t_ = os.IsNotExist(err)\n\t\treturn nil, nil\n",
        expect="EQUIVALENCE-PROBE",
        note="Absence-vs-failure at the checkpoint load: any store error becomes absence (parks 'none is admitted' / fails 'newest absent'); declared equivalence probe — both directions fail closed, the delta is the message and the class of fact reported.",
    ),
    Mutant(
        name="RV4-13-emit-parked-winner-unbound",
        path="events.go",
        find="\tpayload, err := ParkedPayload(decision.ParkReason, decision.WinningLeaseID)\n",
        replace="\tpayload, err := ParkedPayload(decision.ParkReason, params.LeaseID)\n",
        expect="EQUIVALENCE-PROBE",
        note="Payload winner taken from the authoring lease instead of the decision: through Run both are the observation winner, so a SURVIVAL here shows no test distinguishes the decision's winner from the authoring lease (the R4-9 probe class).",
    ),
    Mutant(
        name="RC4-control-comment",
        path="decide.go",
        find="// Decide is the pure wrapper core: configuration, session, bootstrap\n",
        replace="// Decide is the pure wrapper core (reviewer control): configuration, session, bootstrap\n",
        expect="SURVIVED",
        note="Harmless control: a comment-only edit must survive.",
    ),
]


def run_mutant(repo: Path, logdir: Path, mutant: Mutant) -> str:
    target = repo / PACKAGE / mutant.path
    original = target.read_bytes()
    text = original.decode()
    found = text.count(mutant.find)
    if found != 1:
        return f"ERROR: {mutant.name}: patch anchors {found}, want 1"
    log = logdir / f"{mutant.name}.log"
    try:
        target.write_text(text.replace(mutant.find, mutant.replace))
        run = subprocess.run(
            ["go", "test", f"./{PACKAGE}/", "-count=1"],
            cwd=repo, capture_output=True, text=True, timeout=600,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
    finally:
        target.write_bytes(original)
    output = (run.stdout + run.stderr).strip()
    log.write_text(f"# mutant: {mutant.name}\n# note: {mutant.note}\n# exit={run.returncode}\n{output}\n")
    if "build failed" in output or output.startswith("# ") or "\n# " in output:
        return f"ERROR: {mutant.name}: build broke under the patch [exit {run.returncode}]"
    if run.returncode == 0:
        verdict = "SURVIVED"
    elif "--- FAIL" in output or "FAIL:" in output:
        verdict = "KILLED"
    else:
        return f"ERROR: {mutant.name}: exit {run.returncode} with no kill line"
    killers = sorted({line.split()[2] for line in output.splitlines() if line.startswith("--- FAIL")})
    if mutant.expect == "EQUIVALENCE-PROBE":
        mark = "probe"
    else:
        mark = "ok" if verdict == mutant.expect else "MISMATCH"
    return f"{mark}: {mutant.name}: {verdict} (want {mutant.expect}) killers={killers} [exit {run.returncode}] :: {mutant.note}"


def main(argv):
    repo = Path(argv[0]).resolve()
    logdir = Path(argv[1]).resolve()
    logdir.mkdir(parents=True, exist_ok=True)
    names = argv[2:]
    selected = [m for m in MUTANTS if not names or m.name in names]
    failures = 0
    for mutant in selected:
        try:
            line = run_mutant(repo, logdir, mutant)
        except subprocess.TimeoutExpired:
            line = f"ERROR: {mutant.name}: killer timed out"
        print(line, flush=True)
        if line.startswith(("MISMATCH", "ERROR")):
            failures += 1
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
