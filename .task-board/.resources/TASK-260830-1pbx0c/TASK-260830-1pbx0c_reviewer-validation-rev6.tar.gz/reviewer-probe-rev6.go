package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	"github.com/relux-works/agent-session-manager/internal/scalar"
)

func main() {
	failures := 0
	fail := func(format string, args ...any) {
		failures++
		fmt.Printf("FAIL: "+format+"\n", args...)
	}

	reserved := []string{"CON", "PRN", "AUX", "NUL"}
	for _, prefix := range []string{"COM", "LPT"} {
		for digit := byte('1'); digit <= '9'; digit++ {
			reserved = append(reserved, prefix+string(digit))
		}
	}
	for _, name := range reserved {
		for _, component := range []string{name, strings.ToLower(name) + ".txt", name + ".tar.gz"} {
			for _, value := range []string{`C:\unsafe\` + component, `\\server\share\` + component} {
				if _, err := scalar.ParseAbsolutePath(scalar.PlatformWindows, value); err == nil {
					fail("ParseAbsolutePath admitted reserved component %q", value)
				}
				encoded, err := json.Marshal(value)
				if err != nil {
					fail("json.Marshal(%q): %v", value, err)
				} else if _, err := scalar.DecodeAbsolutePathJSON(scalar.PlatformWindows, encoded); err == nil {
					fail("DecodeAbsolutePathJSON admitted reserved component %q", value)
				}
			}
		}
	}

	for _, component := range []string{`star*.json`, `q?b`, `less<than`, `greater>than`, `stream:name`, `double"quote`, `pipe|name`} {
		for _, value := range []string{`C:\unsafe\` + component, `\\server\share\` + component} {
			if _, err := scalar.ParseAbsolutePath(scalar.PlatformWindows, value); err == nil {
				fail("ParseAbsolutePath admitted reserved punctuation %q", value)
			}
		}
	}

	for _, component := range []string{"CONSOLE", "xCON", "con-file.txt", "COM0", "COM10", "COM1x", "LPT0", "LPT10", "file.CON", ".CON"} {
		value := `C:\safe\` + component
		if _, err := scalar.ParseAbsolutePath(scalar.PlatformWindows, value); err != nil {
			fail("ParseAbsolutePath falsely refused ordinary component %q: %v", value, err)
		}
	}

	const posix = `/srv/CON/con.txt/COM1/star*.json/q?b/a:b/less<than/greater>than/double"quote/pipe|name`
	if got, err := scalar.ParseAbsolutePath(scalar.PlatformLinux, posix); err != nil || got.String() != posix {
		fail("POSIX compatibility = %q, %v", got.String(), err)
	}

	for _, value := range []string{
		"1990-12-31T23:59:60.000Z",
		"1990-12-31t23:59:60.000z",
		"1990-12-31T23:59:60.1234567890+00:00",
	} {
		parsed, err := scalar.ParseTimestamp(value)
		if err != nil || parsed.String() != value {
			fail("ParseTimestamp refused published leap second %q: %v", value, err)
		}
		var fromJSON scalar.Timestamp
		if err := json.Unmarshal([]byte(`"`+value+`"`), &fromJSON); err != nil || fromJSON.String() != value {
			fail("Timestamp JSON refused %q: %v", value, err)
		}
		var fromText scalar.Timestamp
		if err := fromText.UnmarshalText([]byte(value)); err != nil || fromText.String() != value {
			fail("Timestamp text refused %q: %v", value, err)
		}
	}
	for _, value := range []string{
		"1990-12-31T23:58:60.000Z",
		"1990-12-30T23:59:60.000Z",
		"2026-12-31T23:59:60.000Z",
	} {
		if _, err := scalar.ParseTimestamp(value); err == nil {
			fail("ParseTimestamp admitted fabricated leap second %q", value)
		}
	}

	if failures > 0 {
		fmt.Printf("reviewer probe: %d failure(s)\n", failures)
		os.Exit(1)
	}
	fmt.Printf("reviewer probe: PASS (%d DOS names x bare/lowercase-extension/multi-extension x drive/UNC; punctuation, false-positive, POSIX, and leap-second boundaries)\n", len(reserved))
}
