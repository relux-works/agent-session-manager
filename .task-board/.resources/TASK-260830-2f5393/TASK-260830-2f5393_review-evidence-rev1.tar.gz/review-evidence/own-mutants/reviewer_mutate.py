#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants on arms the producer battery did not mutate."""
import hashlib, json, re, subprocess, sys
from pathlib import Path
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
src = Path("/tmp/review-2f5393/own/src")
f = src / "internal/sessrepo/lease_store.go"
base = f.read_text()
assert hashlib.sha256(base.encode()).hexdigest() == "bdb89cb607268d1d06ac2eb235f4e1a22017d3da61899203be26d15153cac6c8", "final source drifted"
results = []
def run(name, old, new, pattern, note):
    orig = f.read_text()
    if orig.count(old) != 1:
        results.append({"mutant": name, "classification": "NOT_APPLIED", "count": orig.count(old), "note": note})
        print(name, "NOT_APPLIED", orig.count(old), flush=True); return
    f.write_text(orig.replace(old, new))
    for attempt in (1, 2):
        log = out / f"{name}.attempt{attempt}.log"
        cmd = ["go", "test", "./internal/sessrepo", "-run", pattern, "-count=1", "-v"]
        with log.open("w") as lh:
            p = subprocess.run(cmd, cwd=src, stdout=lh, stderr=subprocess.STDOUT, timeout=180)
        text = log.read_text()
        fails = re.findall(r"^\s*--- FAIL: ([^ ]+)", text, re.M)
        ran = re.findall(r"^=== RUN ", text, re.M)
        cls = "COMPILE_OR_HARNESS_FAILURE" if not ran else ("SURVIVED" if p.returncode == 0 else ("KILLED" if fails else "COMPILE_OR_HARNESS_FAILURE"))
        results.append({"mutant": name, "attempt": attempt, "classification": cls, "exit": p.returncode, "failed": fails, "note": note, "command": cmd})
        print(name, f"attempt{attempt}", cls, p.returncode, ",".join(fails), flush=True)
    f.write_text(orig)
    assert f.read_text() == orig
run("R-expiry-boundary", "if now.Sub(grant.ValidatedAt) > policy.RefreshInterval {",
    "if now.Sub(grant.ValidatedAt) >= policy.RefreshInterval {",
    r"^TestCheckFencingExpiry$", "off-by-one at boundary: boundary grant must stay current")
run("R-cas-epoch-skip", "candidate, digest, err := mintLeaseRecord(view.record.sessionID, head.Epoch+1,",
    "candidate, digest, err := mintLeaseRecord(view.record.sessionID, head.Epoch+2,",
    r"^TestCompareAndSwapPersistsSuccessor$|^TestEpochMonotonicityAcrossSuccessors$",
    "epoch derivation head+1 weakened to head+2: successor must land at head+1")
run("R-fence-lease-prefix", "if token.LeaseID != winner.LeaseID {",
    'if token.LeaseID != winner.LeaseID && !strings.HasPrefix(token.LeaseID, winner.LeaseID[:8]) {',
    r"^TestVerifyFencingTokenRefusals$", "tie-break weakened to 8-char prefix: same-prefix loser admits")
run("R-fence-holder-prefix", "if token.HolderHostID != winner.HolderHostID {",
    'if token.HolderHostID != winner.HolderHostID && !strings.HasPrefix(token.HolderHostID, winner.HolderHostID[:8]) {',
    r"^TestVerifyFencingTokenRefusals$", "holder binding weakened to 8-char prefix: same-prefix non-holder admits")
run("C-harmless-comment-own", "// CompareLeaseTuple orders two stored lease summaries by the Section 5.3",
    "// CompareLeaseTuple orders two stored lease summaries by the Section 5.3\n// reviewer control: comment only, no behavior change.",
    r"^TestCompareLeaseTupleOrdersByGreatestTuple$", "applied harmless control must SURVIVE")
with (out / "control-after.log").open("w") as lh:
    p = subprocess.run(["go", "test", "./internal/sessrepo", "-count=1"], cwd=src, stdout=lh, stderr=subprocess.STDOUT, timeout=300)
results.append({"mutant": "control-after", "classification": "CONTROL", "exit": p.returncode})
(out / "reviewer-mutants.json").write_text(json.dumps(results, indent=2) + "\n")
bad = [r for r in results if r["mutant"].startswith("R-") and not (r.get("attempt") == 2 and r["classification"] == "KILLED") and "attempt" in r]
# require both attempts KILLED for each R mutant
from collections import defaultdict
by = defaultdict(list)
for r in results:
    if r["mutant"].startswith("R-"): by[r["mutant"]].append(r["classification"])
ok = all(v == ["KILLED", "KILLED"] for v in by.values())
ctrl = [r for r in results if r["mutant"] == "C-harmless-comment-own"]
ok = ok and any(r["classification"] == "SURVIVED" for r in ctrl) and p.returncode == 0
sys.exit(0 if ok else 1)
