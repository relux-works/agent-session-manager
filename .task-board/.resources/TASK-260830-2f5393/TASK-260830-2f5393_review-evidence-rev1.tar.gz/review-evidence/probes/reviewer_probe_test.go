package sessrepo

import (
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// Reviewer-owned behavioral probes through the production entries.
// Each probe drives CreateLease / CompareAndSwapLease / VerifyFencingToken /
// WinningLease / ListLeases / GetLease directly.

func reviewerProbeSetup(t *testing.T) (*Repository, string) {
	t.Helper()
	repository := openTestRepository(t)
	createTestSession(t, repository)
	return repository, testSessionID
}

func reviewerSuccessor(token, holder string) SuccessorLeaseInput {
	return SuccessorLeaseInput{
		CreateLeaseInput: CreateLeaseInput{LeaseID: token, HolderHostID: holder, IssuedByHostID: holder, CreatedAt: testLeaseAt},
		Reason:           "graceful_takeover",
		CheckpointID:     zeroDigest,
	}
}

// Second epoch-1 create (epoch equal to current) must refuse lease_exists.
func TestReviewerSecondCreateAtSameEpochRefuses(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	first := mustCreateLease(t, repository, session, createLeaseFixture())
	second := createLeaseFixture()
	second.LeaseID = testLeaseIDB
	_, err := repository.CreateLease(session, second)
	mustErrorIs(t, err, ErrLeaseExists, "CreateLease(same epoch)")
	if w, _ := repository.WinningLease(session); w.RecordID != first.RecordID {
		t.Fatalf("winner moved: %+v", w)
	}
}

// CAS always lands at head+1: three successions pin 2,3,4; no +2 gap mintable.
func TestReviewerCASEpochDerivationIsHeadPlusOne(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	head := mustCreateLease(t, repository, session, createLeaseFixture())
	for i, token := range []string{testLeaseIDB, testLeaseIDC, "dddddddd-eeee-4fff-8000-222222222222"} {
		head = mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: head.RecordID}, reviewerSuccessor(token, testHostIDB))
		if head.Epoch != uint64(i+2) {
			t.Fatalf("successor epoch = %d, want %d", head.Epoch, i+2)
		}
	}
}

// Sequential race on the same basis: first wins; second with differing bytes
// is stale (superseded basis), never a second epoch-2 head.
func TestReviewerSequentialRaceOnSameBasis(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	first := mustCreateLease(t, repository, session, createLeaseFixture())
	winner := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, reviewerSuccessor(testLeaseIDB, testHostIDB))
	loserInput := reviewerSuccessor("eeeeeeee-ffff-4aaa-8000-333333333333", testHostID)
	_, err := repository.CompareAndSwapLease(session, LeaseExpectation{RecordID: first.RecordID}, loserInput)
	mustErrorIs(t, err, ErrStaleLeaseEpoch, "CAS(loser of race)")
	if w, _ := repository.WinningLease(session); w.RecordID != winner.RecordID {
		t.Fatalf("race moved winner to %+v, want %+v", w, winner)
	}
	leases, _ := repository.ListLeases(session)
	if len(leases) != 2 {
		t.Fatalf("race persisted %d leases, want 2", len(leases))
	}
}

// Byte-identical replay of a committed CAS returns the same ref and adds no blob.
func TestReviewerReplayAddsNoBlob(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	first := mustCreateLease(t, repository, session, createLeaseFixture())
	input := reviewerSuccessor(testLeaseIDB, testHostIDB)
	second := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, input)
	dir := filepath.Join(repository.root, session, "leases")
	before, err := os.ReadDir(dir)
	if err != nil {
		t.Fatalf("ReadDir: %v", err)
	}
	beforeNames := map[string]int64{}
	for _, e := range before {
		info, _ := e.Info()
		beforeNames[e.Name()] = info.Size()
	}
	replayed := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, input)
	if replayed != second {
		t.Fatalf("replay ref = %+v, want %+v", replayed, second)
	}
	after, err := os.ReadDir(dir)
	if err != nil {
		t.Fatalf("ReadDir: %v", err)
	}
	if len(after) != len(before) {
		t.Fatalf("replay changed blob count %d -> %d", len(before), len(after))
	}
	for _, e := range after {
		info, _ := e.Info()
		if beforeNames[e.Name()] != info.Size() {
			t.Fatalf("blob %s changed", e.Name())
		}
	}
}

// Replay of an old successor after the head advanced past it still answers
// the persisted successor (re-mint against pre-commit basis hits).
func TestReviewerReplayAfterHeadAdvanced(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	first := mustCreateLease(t, repository, session, createLeaseFixture())
	input := reviewerSuccessor(testLeaseIDB, testHostIDB)
	second := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, input)
	thirdInput := reviewerSuccessor(testLeaseIDC, testHostIDB)
	third := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: second.RecordID}, thirdInput)
	replayed := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, input)
	if replayed != second {
		t.Fatalf("old replay ref = %+v, want %+v", replayed, second)
	}
	if w, _ := repository.WinningLease(session); w.RecordID != third.RecordID {
		t.Fatalf("old replay moved winner to %+v", w)
	}
}

// Holder is host-UUIDv7 only: same host from another input verifies; the
// stored record carries no pid/start/boot field.
func TestReviewerHolderIsHostOnly(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	ref := mustCreateLease(t, repository, session, createLeaseFixture())
	if err := repository.VerifyFencingToken(session, FencingToken{Epoch: 1, LeaseID: ref.LeaseID, HolderHostID: ref.HolderHostID}); err != nil {
		t.Fatalf("same-host re-presentation error = %v", err)
	}
	raw := mustGetLease(t, repository, session, ref.RecordID)
	var object map[string]any
	if err := json.Unmarshal(raw, &object); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	for _, key := range []string{"pid", "process_id", "start_time", "boot_id", "holder_token", "process_token"} {
		if _, ok := object[key]; ok {
			t.Fatalf("record carries process binding %q", key)
		}
	}
	if object["holder_host_id"] != testHostID {
		t.Fatalf("holder = %v", object["holder_host_id"])
	}
}

// Older-epoch token after a newer lease is stale; tampered same-epoch lease
// with valid UUID grammar loses the tie (conflict); tampered version nibble
// fails grammar (invalid).
func TestReviewerFencingTokenTamper(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	first := mustCreateLease(t, repository, session, createLeaseFixture())
	second := mustCompareAndSwap(t, repository, session, LeaseExpectation{RecordID: first.RecordID}, reviewerSuccessor(testLeaseIDB, testHostIDB))
	mustErrorIs(t, repository.VerifyFencingToken(session, FencingToken{Epoch: 1, LeaseID: testLeaseID, HolderHostID: testHostID}), ErrStaleLeaseEpoch, "old epoch")
	_ = second
	tampered := "cbbbbbbb-cccc-4ddd-8eee-ffffffffffff" // valid v4, loses to winner b...
	mustErrorIs(t, repository.VerifyFencingToken(session, FencingToken{Epoch: 2, LeaseID: tampered, HolderHostID: testHostIDB}), ErrLeaseConflict, "tampered byte")
	badVersion := "bbbbbbbb-cccc-5ddd-8eee-ffffffffffff" // version 5, not v4
	mustErrorIs(t, repository.VerifyFencingToken(session, FencingToken{Epoch: 2, LeaseID: badVersion, HolderHostID: testHostIDB}), ErrInvalidLease, "bad version")
}

// Split brain: two epoch-2 blobs from partitioned writers union to one
// winner by tuple; the loser is preserved, never applied.
func TestReviewerSplitBrainUnionElectsGreaterLease(t *testing.T) {
	repoA := openTestRepository(t)
	createTestSession(t, repoA)
	firstA := mustCreateLease(t, repoA, testSessionID, createLeaseFixture())
	secondA := mustCompareAndSwap(t, repoA, testSessionID, LeaseExpectation{RecordID: firstA.RecordID}, reviewerSuccessor(testLeaseIDB, testHostIDB))
	repoB := openTestRepository(t)
	createTestSession(t, repoB)
	firstB := mustCreateLease(t, repoB, testSessionID, createLeaseFixture())
	if firstB.RecordID != firstA.RecordID {
		t.Fatalf("epoch-1 bases diverge: %s vs %s", firstA.RecordID, firstB.RecordID)
	}
	secondB := mustCompareAndSwap(t, repoB, testSessionID, LeaseExpectation{RecordID: firstB.RecordID}, reviewerSuccessor(testLeaseIDC, testHostID))
	dirA := filepath.Join(repoA.root, testSessionID, "leases")
	dirB := filepath.Join(repoB.root, testSessionID, "leases")
	blobB, err := os.ReadFile(filepath.Join(dirB, blobFileName(secondB.RecordID)))
	if err != nil {
		t.Fatalf("read partition-B blob: %v", err)
	}
	if err := os.WriteFile(filepath.Join(dirA, blobFileName(secondB.RecordID)), blobB, 0o600); err != nil {
		t.Fatalf("union blob: %v", err)
	}
	leases, err := repoA.ListLeases(testSessionID)
	if err != nil {
		t.Fatalf("ListLeases(union) error = %v", err)
	}
	if len(leases) != 3 {
		t.Fatalf("union holds %d leases, want 3 (epochs 1,2,2)", len(leases))
	}
	winner, err := repoA.WinningLease(testSessionID)
	if err != nil {
		t.Fatalf("WinningLease(union) error = %v", err)
	}
	// c... > b... bytewise, so the partition-B lease wins.
	if winner.RecordID != secondB.RecordID {
		t.Fatalf("union winner = %+v, want partition-B %+v", winner, secondB)
	}
	_ = secondA
	if err := repoA.VerifyFencingToken(testSessionID, FencingToken{Epoch: 2, LeaseID: testLeaseIDB, HolderHostID: testHostIDB}); err == nil {
		t.Fatal("losing partition-A token verified after union")
	}
}

// Tampered final blob refuses corruption through both funnels.
func TestReviewerTamperedBlobRefuses(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	ref := mustCreateLease(t, repository, session, createLeaseFixture())
	path := filepath.Join(repository.root, session, "leases", blobFileName(ref.RecordID))
	blob, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read: %v", err)
	}
	blob[len(blob)-3] ^= 0x01
	if err := os.WriteFile(path, blob, 0o600); err != nil {
		t.Fatalf("tamper: %v", err)
	}
	if _, err := repository.ListLeases(session); !errors.Is(err, ErrChainCorrupt) {
		t.Fatalf("ListLeases(tampered) error = %v, want chain corruption", err)
	}
	if _, err := repository.GetLease(session, ref.RecordID); !errors.Is(err, ErrChainCorrupt) {
		t.Fatalf("GetLease(tampered) error = %v, want chain corruption", err)
	}
}

// AfterLeaseStage fault leaving a staged-but-unrenamed file: restart
// recovery ignores the temp and the retry lands the exact epoch.
func TestReviewerStagedButUnrenamedRecovers(t *testing.T) {
	repository, session := reviewerProbeSetup(t)
	repository.AfterLeaseStage = func() error {
		return errors.New("injected stage fault")
	}
	_, err := repository.CreateLease(session, createLeaseFixture())
	if err == nil {
		t.Fatal("CreateLease(injected stage fault) succeeded")
	}
	repository.AfterLeaseStage = nil
	dir := filepath.Join(repository.root, session, "leases")
	entries, readErr := os.ReadDir(dir)
	if readErr != nil {
		if !os.IsNotExist(readErr) {
			t.Fatalf("ReadDir: %v", readErr)
		}
	} else {
		for _, e := range entries {
			if !strings.HasPrefix(e.Name(), ".") {
				t.Fatalf("fault left final %s", e.Name())
			}
		}
	}
	ref := mustCreateLease(t, repository, session, createLeaseFixture())
	if ref.Epoch != 1 {
		t.Fatalf("retry epoch = %d", ref.Epoch)
	}
}
