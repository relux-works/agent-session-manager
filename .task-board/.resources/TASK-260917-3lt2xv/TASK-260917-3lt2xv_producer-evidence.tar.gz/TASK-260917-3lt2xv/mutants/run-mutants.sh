#!/bin/bash
# Narrowing-mutant battery for TASK-260917-3lt2xv.
# Each plant weakens one adopted-mode gate in
# internal/catalog/cmd/cataloggen/main.go to admit exactly one member of the
# class the gate must reject; the named committed test must then FAIL
# (KILLED). A harmless comment plant must leave the suite green (SURVIVED).
# Every plant runs the full package behavioral suite through the production
# run() entry. Raw per-plant logs land in logs/<plant>.log.
set -u
cd "$(dirname "$0")/../../.." || exit 1
# In the Story worktree this script lives at .temp/TASK-260917-3lt2xv/mutants/.

TARGET=internal/catalog/cmd/cataloggen/main.go
OUT=.temp/TASK-260917-3lt2xv/mutants
LOGDIR="$OUT/logs"
PKG=./internal/catalog/cmd/cataloggen/

mkdir -p "$LOGDIR"
BACKUP="$OUT/main.go.pristine"
cp "$TARGET" "$BACKUP"
EXPECTED_SHA=$(sha256sum "$TARGET" | awk '{print $1}')

restore() {
  cp "$BACKUP" "$TARGET"
}
trap restore EXIT

echo "plant|expect|result|exit|test_exit" > "$OUT/summary.tsv"

apply() { # $1=plant $2=old $3=new $4=expect(KILLED|SURVIVED)
  local plant="$1" old="$2" new="$3" expect="$4"
  restore
  python3 - "$TARGET" "$old" "$new" <<'EOF'
import sys
path, old, new = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(path, encoding='utf-8').read()
assert s.count(old) == 1, "anchor count=%d" % s.count(old)
open(path, 'w', encoding='utf-8').write(s.replace(old, new))
EOF
  if [ $? -ne 0 ]; then
    echo "PLANT $plant NOT_APPLIED (anchor failed)"
    echo "$plant|$expect|NOT_APPLIED|-|-" >> "$OUT/summary.tsv"
    return
  fi
  gofmt -l "$TARGET" > "$LOGDIR/$plant.fmt" 2>&1
  go test "$PKG" -count=1 -v > "$LOGDIR/$plant.log" 2>&1
  local exit=$?
  local result="SURVIVED"
  if [ $exit -ne 0 ] && grep -q "^--- FAIL\|^FAIL" "$LOGDIR/$plant.log"; then
    result="KILLED"
  fi
  echo "PLANT $plant expect=$expect result=$result exit=$exit"
  echo "$plant|$expect|$result|$exit|$exit" >> "$OUT/summary.tsv"
}

# Baseline: pristine tree must be green.
go test "$PKG" -count=1 > "$LOGDIR/baseline.log" 2>&1
echo "baseline exit=$? (see logs/baseline.log)"

# N1: mixed-flag gate admits -metadata mixing only.
apply N1-mixed-metadata \
  'if explicitMetadata || explicitContracts {' \
  'if explicitContracts {' \
  KILLED

# N2: mixed-flag gate admits -contracts mixing only.
apply N2-mixed-contracts \
  'if explicitMetadata || explicitContracts {' \
  'if explicitMetadata {' \
  KILLED

# N3: adopted metadata read admits exactly the missing-file member.
apply N3-missing-metadata \
  'metadata, err := os.ReadFile(metadataPath)
	if err != nil {' \
  'metadata, err := os.ReadFile(metadataPath)
	if err != nil && !os.IsNotExist(err) {' \
  KILLED

# N4: adopted lock read admits exactly the missing-file member.
apply N4-missing-lock \
  'contracts, err := os.ReadFile(contractsPath)
	if err != nil {' \
  'contracts, err := os.ReadFile(contractsPath)
	if err != nil && !os.IsNotExist(err) {' \
  KILLED

# N5: lock-release gate admits exactly v0.5.0 locks.
apply N5-lock-release \
  'if lock.Source.Release != string(catalog.Adopted) {' \
  'if lock.Source.Release != "v0.5.0" {' \
  KILLED

# N6: adopted metadata derivation pinned to v0.5.0 (byte-identity claim).
apply N6-derive-metadata \
  '"catalog."+string(catalog.Adopted)+".json"' \
  '"catalog.v0.5.0.json"' \
  KILLED

# N7: stale-output gate compares length only (same-length stale admitted).
apply N7-stale-length \
  'if !bytes.Equal(existing, content) {' \
  'if len(existing) != len(content) {' \
  KILLED

# N8: adopted -output requirement admits missing output without -check.
apply N8-output-required \
  'if output == "" {
		return fmt.Errorf("-output is required with -adopted")' \
  'if output == "" && check {
		return fmt.Errorf("-output is required with -adopted")' \
  KILLED

# C0: harmless control — comment only, suite must stay green.
apply C0-harmless \
  'package main' \
  'package main

// mutant-control: harmless comment plant' \
  SURVIVED

restore
trap - EXIT
ACTUAL_SHA=$(sha256sum "$TARGET" | awk '{print $1}')
if [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then
  echo "FATAL: $TARGET not restored (want $EXPECTED_SHA got $ACTUAL_SHA)"
  exit 1
fi
echo "restored $TARGET sha=$ACTUAL_SHA"
cat "$OUT/summary.tsv"
# Verdict: every plant must match its expectation.
FAIL=0
while IFS='|' read -r plant expect result exit _; do
  [ "$plant" = "plant" ] && continue
  if [ "$expect" != "$result" ]; then echo "MISMATCH $plant expect=$expect result=$result"; FAIL=1; fi
done < "$OUT/summary.tsv"
[ $FAIL -eq 0 ] && echo "BATTERY VERDICT: ALL PLANTS BEHAVE AS EXPECTED" || echo "BATTERY VERDICT: MISMATCH PRESENT"
exit $FAIL
