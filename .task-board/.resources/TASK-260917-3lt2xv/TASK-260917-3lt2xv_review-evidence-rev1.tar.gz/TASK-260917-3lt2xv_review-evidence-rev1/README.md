# Review evidence — TASK-260917-3lt2xv rev1 (ACCEPT)

- `TASK-260917-3lt2xv_review-verdict-rev1.md`: the verdict (also attached as its own board resource).
- `logs/`: reviewer-captured raw logs. `cmd-N.log` = validation command N rerun on the exact tree (N=1-4,6-26; no cmd-5: full -race accepted from producer evidence, scoped -race rerun green). `producer-rerun.log` = producer battery rerun console. `rerun-twice.log` + `rerun-*` = each of the 8 producer KILLED rerun twice (16/16 exit 1). `own-*` = three own narrowing mutants + control. `probe-mixed-check-{pristine,mutant}.log` = R-C behavioral pair. `divergence.log`, `forward-fake.log` = pin-divergence RED and declaration-following proof.
- `producer-logs/` + `producer-summary.tsv`: per-plant raw logs and summary from the producer-harness rerun in the isolated copy (8 KILLED, 1 SURVIVED control).
- All destructive probes ran in isolated copies; the live worktree was not mutated by this review.
