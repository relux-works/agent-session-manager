#!/bin/bash
# N2 rerun with the corrected killer pattern (quote-layer message).
set -u
TREE=/tmp/mut-10k118/treeC OUT=/tmp/mut-10k118/newtests PRISTINE=/tmp/mut-10k118/treeC0
export PYTHONDONTWRITEBYTECODE=1
cd "$TREE"
# prove pristine baseline first
for f in internal/traceability/ownership.v0.7.0.json README.md internal/traceability/traceability.go; do cmp -s "$PRISTINE/$f" "$f" || { echo "NOT-PRISTINE: $f"; exit 2; }; done
echo "baseline pristine: yes"
python3 - <<'PYEOF'
import json, collections
p = 'internal/traceability/ownership.v0.7.0.json'
d = json.load(open(p), object_pairs_hook=collections.OrderedDict)
n=0
for g in d["ownership"]:
  for c in g.get("clauses",[]):
    if c["id"]=="6.2#1":
      assert c["line"]==2512, c["line"]
      c["line"]=2433; n+=1
assert n==1
json.dump(d, open(p, 'w'), indent=2)
open(p, 'a').write('\n')
PYEOF
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N2-rerun-named.log" 2>&1; e1=$?
go test ./internal/traceability/ -count=1 >"$OUT/N2-rerun-suite.log" 2>&1; e2=$?
grep -E 'excerpt does not begin at line 2433' "$OUT/N2-rerun-named.log" && msg=1 || msg=0
echo "N2-rerun: named exit=$e1 suite exit=$e2 killer-pattern=$msg"
cp "$PRISTINE/internal/traceability/ownership.v0.7.0.json" internal/traceability/ownership.v0.7.0.json
cmp -s "$PRISTINE/internal/traceability/ownership.v0.7.0.json" internal/traceability/ownership.v0.7.0.json && echo "restored clean" || echo "RESTORE-DIRTY"
[ $e1 -ne 0 ] && [ $msg -eq 1 ] && [ $e2 -ne 0 ] && echo "N2 RERUN: KILLED" || echo "N2 RERUN: NOT-KILLED"
