#!/bin/bash
# Narrowing-mutant harness for TASK-260917-10k118's two verification tests.
# Each plant admits exactly one member of the class the test must reject;
# the named test must FAIL while the control plants SURVIVE. Runs on the
# scratch tree $TREE (never the live worktree); every plant is restored and
# the restoration is proved with cmp against the pristine copy afterwards.
# Usage: TREE=/tmp/mut-10k118/treeC OUT=/tmp/mut-10k118/newtests bash mutate-10k118.sh
set -u
TREE="${TREE:?set TREE to the scratch tree}"
OUT="${OUT:?set OUT to the log dir}"
PRISTINE="${PRISTINE:-/tmp/mut-10k118/treeC0}"
export PYTHONDONTWRITEBYTECODE=1
mkdir -p "$OUT"
cd "$TREE" || exit 1

REG=internal/traceability/ownership.v0.7.0.json
README=README.md
PINGO=internal/traceability/traceability.go

pass=0; fail=0
report() { # id verdict detail
  printf '%-4s %-9s %s\n' "$1" "$2" "$3" | tee -a "$OUT/summary.log"
  if [ "$2" = KILLED ] || [ "$2" = SURVIVED ]; then pass=$((pass+1)); else fail=$((fail+1)); fi
}
restore() {
  cp "$PRISTINE/$REG" "$REG"
  cp "$PRISTINE/$README" "$README"
  cp "$PRISTINE/$PINGO" "$PINGO"
}

# plant_json <id> <python-body> : rewrite $REG through the parsed-JSON round-trip.
plant_json() {
  python3 - "$2" <<'EOF'
import json, collections, sys
p = 'internal/traceability/ownership.v0.7.0.json'
d = json.load(open(p), object_pairs_hook=collections.OrderedDict)
body = sys.argv[1]
ns = {'d': d, 'collections': collections, 'json': json}
exec(body, ns)
json.dump(d, open(p, 'w'), indent=2)
open(p, 'a').write('\n')
EOF
}

fails_with() { # logfile pattern
  grep -q -- '--- FAIL' "$1" && grep -q -F -- "$2" "$1"
}

echo "=== baseline ===" | tee "$OUT/summary.log"
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 >>"$OUT/baseline.log" 2>&1
echo "baseline rederive exit=$?" | tee -a "$OUT/summary.log"
go test ./internal/traceability/cmd/tracecheck/ -run 'TestREADMEMeasuredCoverageMatchesTracecheckReport' -count=1 >>"$OUT/baseline.log" 2>&1
echo "baseline readme exit=$?" | tee -a "$OUT/summary.log"

# --- N1: drop exactly one carried binding (section:6.2) ---
plant_json 'N1' '
gs=[g for g in d["ownership"] if not (g["kind"]=="section_binding" and g["keys"]==["section:6.2"])]
assert len(gs)==len(d["ownership"])-1
d["ownership"]=gs'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N1-named.log" 2>&1; e1=$?
go test ./internal/traceability/ -count=1 >"$OUT/N1-suite.log" 2>&1; e2=$?
if [ $e1 -ne 0 ] && fails_with "$OUT/N1-named.log" 'drops 1 carried bindings: ["section:6.2"]' && [ $e2 -ne 0 ]; then
  report N1 KILLED "missing binding named; named exit=$e1 suite exit=$e2"
else
  report N1 NOT-KILLED "named exit=$e1 suite exit=$e2"
fi
restore

# --- N2: leave one clause line unshifted (6.2#1 back to its v0.6.0 line) ---
plant_json 'N2' '
n=0
for g in d["ownership"]:
  for c in g.get("clauses",[]):
    if c["id"]=="6.2#1":
      assert c["line"]==2512, c["line"]
      c["line"]=2433; n+=1
assert n==1
d["ownership"]=d["ownership"]'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N2-named.log" 2>&1; e1=$?
go test ./internal/traceability/ -count=1 >"$OUT/N2-suite.log" 2>&1; e2=$?
# Killer pattern corrected after the first pass: the verbatim-quote layer
# (measuredClauseLines) fires before the shifted-ness assert, naming the
# unshifted line as a quote failure. See N2-rerun-named.log.
if [ $e1 -ne 0 ] && fails_with "$OUT/N2-named.log" 'excerpt does not begin at line 2433' && [ $e2 -ne 0 ]; then
  report N2 KILLED "unshifted line named; named exit=$e1 suite exit=$e2"
else
  report N2 NOT-KILLED "named exit=$e1 suite exit=$e2"
fi
restore

# --- N3: self-mint one binding (section:9.9) ---
plant_json 'N3' '
d["ownership"].append(collections.OrderedDict([
 ("kind","section_binding"),("keys",["section:9.9"]),
 ("production",collections.OrderedDict([("path","internal/catalog/catalog.go"),("declaration","ForRelease")])),
 ("acceptance_cases",["catalog-v070-exact"]),("coverage","unevidenced"),
 ("gap","ForRelease only returns the reviewed typed catalog rows that reference 9.9; no clause of 9.9 is enumerated against an acceptance case.")]))'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N3-named.log" 2>&1; e1=$?
go test ./internal/traceability/ -count=1 >"$OUT/N3-suite.log" 2>&1; e2=$?
if [ $e1 -ne 0 ] && fails_with "$OUT/N3-named.log" 'section:9.9" is not carried and not a reviewed addition' && [ $e2 -ne 0 ]; then
  report N3 KILLED "self-minted binding named; named exit=$e1 suite exit=$e2"
else
  report N3 NOT-KILLED "named exit=$e1 suite exit=$e2"
fi
restore

# --- N4: drop exactly one carried acceptance case ---
plant_json 'N4' '
cs=[c for c in d["acceptance_cases"] if c["id"]!="config-versioned-readers"]
assert len(cs)==len(d["acceptance_cases"])-1
d["acceptance_cases"]=cs'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N4-named.log" 2>&1; e1=$?
if [ $e1 -ne 0 ] && fails_with "$OUT/N4-named.log" 'drops carried acceptance case "config-versioned-readers"'; then
  report N4 KILLED "dropped case named; named exit=$e1"
else
  report N4 NOT-KILLED "named exit=$e1"
fi
restore

# --- N5: drift exactly one carried gap ---
plant_json 'N5' '
n=0
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:6.1"]:
    g["gap"]=g["gap"]+" (drift)"; n+=1
assert n==1'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 -v >"$OUT/N5-named.log" 2>&1; e1=$?
if [ $e1 -ne 0 ] && fails_with "$OUT/N5-named.log" 'section:6.1" gap changed without a reviewed rewording'; then
  report N5 KILLED "drifted gap named; named exit=$e1"
else
  report N5 NOT-KILLED "named exit=$e1"
fi
restore

# --- C0: harmless control — identical round-trip, no semantic change ---
plant_json 'C0' 'pass'
go test ./internal/traceability/ -run 'TestV070RegistryRederivesFromTrunkV060Registry' -count=1 >"$OUT/C0-named.log" 2>&1; e1=$?
if [ $e1 -eq 0 ]; then
  report C0 SURVIVED "identical round-trip green as designed; named exit=$e1"
else
  report C0 UNEXPECTED "identical round-trip reddened the test; named exit=$e1"
fi
restore

# --- R1: one fenced figure drifts (bindings=68 -> 67, prose untouched) ---
python3 - <<'EOF'
p='README.md'; s=open(p).read()
old='section coverage: bindings=68 full=2'
assert s.count(old)==1
open(p,'w').write(s.replace(old,'section coverage: bindings=67 full=2'))
EOF
go test ./internal/traceability/cmd/tracecheck/ -run 'TestREADMEMeasuredCoverageMatchesTracecheckReport' -count=1 -v >"$OUT/R1-named.log" 2>&1; e1=$?
go test ./internal/traceability/cmd/tracecheck/ -count=1 >"$OUT/R1-suite.log" 2>&1; e2=$?
blast=$(grep -c -- '--- FAIL' "$OUT/R1-suite.log" || true)
if [ $e1 -ne 0 ] && fails_with "$OUT/R1-named.log" 'fenced coverage line' && [ "$blast" = 1 ]; then
  report R1 KILLED "fenced drift named; blast radius exactly 1 FAIL line; suite exit=$e2"
else
  report R1 NOT-KILLED "named exit=$e1 blast=$blast suite exit=$e2"
fi
restore

# --- R2: one prose figure drifts (569 -> 568, fence untouched) ---
python3 - <<'EOF'
p='README.md'; s=open(p).read()
old='discharge 49 of the 569 normative clauses'
assert s.count(old)==1
open(p,'w').write(s.replace(old,'discharge 49 of the 568 normative clauses'))
EOF
go test ./internal/traceability/cmd/tracecheck/ -run 'TestREADMEMeasuredCoverageMatchesTracecheckReport' -count=1 -v >"$OUT/R2-named.log" 2>&1; e1=$?
go test ./internal/traceability/cmd/tracecheck/ -count=1 >"$OUT/R2-suite.log" 2>&1; e2=$?
blast=$(grep -c -- '--- FAIL' "$OUT/R2-suite.log" || true)
if [ $e1 -ne 0 ] && fails_with "$OUT/R2-named.log" 'publishes 568' && [ "$blast" = 1 ]; then
  report R2 KILLED "prose drift named; blast radius exactly 1 FAIL line; suite exit=$e2"
else
  report R2 NOT-KILLED "named exit=$e1 blast=$blast suite exit=$e2"
fi
restore

# --- R3: token-preserving — README fully intact, one binding removed and the
# digest re-pinned so production stays green but prints a new report ---
plant_json 'R3' '
gs=[g for g in d["ownership"] if not (g["kind"]=="section_binding" and g["keys"]==["section:10.1"])]
assert len(gs)==len(d["ownership"])-1
d["ownership"]=gs'
python3 /tmp/evn9r71p/ownership-digest.py "$REG" > "$OUT/R3-digest.txt"
NEWDIGEST=$(cat "$OUT/R3-digest.txt")
python3 - "$NEWDIGEST" <<'EOF'
import sys
p='internal/traceability/traceability.go'; s=open(p).read()
old='reviewedOwnershipCanonicalSHA256 = "c4cd46bf71f164ad53dfe00ddd2e64e0b439e1c2684138fbcfe208f7e53473f6"'
assert s.count(old)==1
open(p,'w').write(s.replace(old,'reviewedOwnershipCanonicalSHA256 = "%s"' % sys.argv[1]))
EOF
echo "R3 re-pinned digest: $NEWDIGEST" | tee -a "$OUT/summary.log"
go run ./internal/traceability/cmd/tracecheck >"$OUT/R3-report.txt" 2>&1; e0=$?
go test ./internal/traceability/cmd/tracecheck/ -run 'TestREADMEMeasuredCoverageMatchesTracecheckReport' -count=1 -v >"$OUT/R3-named.log" 2>&1; e1=$?
go test ./internal/traceability/ -count=1 >"$OUT/R3-libsuite.log" 2>&1; e2=$?
go test ./internal/traceability/cmd/tracecheck/ -count=1 >"$OUT/R3-cmdsuite.log" 2>&1; e3=$?
if [ $e0 -eq 0 ] && [ $e1 -ne 0 ] && fails_with "$OUT/R3-named.log" 'fenced coverage line' && [ $e2 -ne 0 ] && [ $e3 -ne 0 ]; then
  report R3 KILLED "production green with new report; pin+suites fail; tool=$e0 named=$e1 lib=$e2 cmd=$e3"
else
  report R3 NOT-KILLED "tool=$e0 named=$e1 lib=$e2 cmd=$e3"
fi
restore

# --- C0R: harmless control — same figure, different case ---
python3 - <<'EOF'
p='README.md'; s=open(p).read()
old='Sixty-eight section bindings discharge'
assert s.count(old)==1
open(p,'w').write(s.replace(old,'SIXTY-EIGHT section bindings discharge'))
EOF
go test ./internal/traceability/cmd/tracecheck/ -run 'TestREADMEMeasuredCoverageMatchesTracecheckReport' -count=1 >"$OUT/C0R-named.log" 2>&1; e1=$?
go test ./internal/traceability/cmd/tracecheck/ -count=1 >"$OUT/C0R-suite.log" 2>&1; e2=$?
if [ $e1 -eq 0 ] && [ $e2 -eq 0 ]; then
  report C0R SURVIVED "case-only edit green; named=$e1 suite=$e2"
else
  report C0R UNEXPECTED "case-only edit reddened; named=$e1 suite=$e2"
fi
restore

echo "---- restore proof ----" | tee -a "$OUT/summary.log"
for f in "$REG" "$README" "$PINGO"; do
  if cmp -s "$PRISTINE/$f" "$f"; then echo "restored clean: $f" | tee -a "$OUT/summary.log"; else echo "RESTORE-DIRTY: $f" | tee -a "$OUT/summary.log"; fi
done
find "$TREE" -name '__pycache__' -o -name '*.pyc' | tee -a "$OUT/summary.log"
echo "---- summary: pass=$pass fail=$fail ----" | tee -a "$OUT/summary.log"
[ "$fail" = 0 ]
