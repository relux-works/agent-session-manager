#!/usr/bin/env python3
"""Binding-by-binding carry audit: trunk v0.6.0 registry -> shipped v0.7.0 registry.
Usage: audit_carry.py <v060.json> <v070.json>
Fails (exit 1) on any unexpected difference. Intended differences, asserted explicitly:
- 3 new section bindings: 13.1, 13.10, 14.1 (with Story-owner gaps)
- Launch Plan request contract key added to the contract group
- fixture group gains ax-launch-plan-request-v1 pin
- 5 gap rewordings to Story owners (5.1, 7.3, 7.4, 7.5, appendix-d)
- clause line re-measurement (lines may differ; excerpts/ids/cases must not)
- unowned 11.10.5 gap reworded to Disclosure owner
- acceptance cases: +3 new v070 cases; catalog-v060-exact repointed; assigned-section-binding rename
"""
import json, sys

V060, V070 = sys.argv[1], sys.argv[2]
old = json.load(open(V060))
new = json.load(open(V070))
failures = []
def fail(msg):
    failures.append(msg)
    print("FAIL:", msg)

# --- sources ---
assert old['source']['release'] == 'v0.6.0', old['source']
assert new['source']['release'] == 'v0.7.0', new['source']
assert new['source']['commit'] == '32b3f2ba7c377248a53cd42389abbd2f1c321834'
assert new['source']['document_sha256'] == 'c6b2fe64ee79ed697a96ed27a1679c80b8ee1eba137feb99e7738b4da289ddcf'

def bindings(d):
    out = {}
    for g in d['ownership']:
        if g['kind'] == 'section_binding':
            assert len(g['keys']) == 1, g['keys']
            out[g['keys'][0]] = g
    return out

ob, nb = bindings(old), bindings(new)
print(f"bindings: v060={len(ob)} v070={len(nb)}")
missing = sorted(set(ob) - set(nb))
added = sorted(set(nb) - set(ob))
if missing:
    fail(f"bindings missing from v0.7.0: {missing}")
print("added bindings:", added)
assert added == ['section:13.1', 'section:13.10', 'section:14.1'], added

# New bindings must name implementing EPIC stories (Pending implementation owner: STORY-...)
for key in added:
    g = nb[key]
    assert 'Pending implementation owner: STORY-' in g.get('gap', ''), (key, g.get('gap'))
    print(f"  {key}: production={g['production']['path']}:{g['production']['declaration']} cases={g['acceptance_cases']}")

# Carried bindings: only clause lines + 5 known gaps may differ
KNOWN_GAP_UPDATES = {'section:5.1', 'section:7.3', 'section:7.4', 'section:7.5', 'section:appendix-d'}
unexpected = 0
remeasured_sections = []
for key in sorted(set(ob) & set(nb)):
    o, n = dict(ob[key]), dict(nb[key])
    oclauses = o.pop('clauses', [])
    nclauses = n.pop('clauses', [])
    ogap = o.pop('gap', '')
    ngap = n.pop('gap', '')
    if o != n:
        fail(f"{key}: non-clause/gap diff: {json.dumps(o)[:300]} VS {json.dumps(n)[:300]}")
        unexpected += 1
        continue
    if ogap != ngap:
        if key not in KNOWN_GAP_UPDATES:
            fail(f"{key}: unexpected gap change")
            unexpected += 1
        elif key == 'section:appendix-d':
            if 'pending STORY-260916-vucwn0' not in ngap:
                fail(f"{key}: gap update lacks vucwn0 split attribution: {ngap[:160]}")
                unexpected += 1
        elif 'Pending implementation owner: STORY-' not in ngap:
            fail(f"{key}: gap update lacks Story owner: {ngap[:120]}")
            unexpected += 1
    # clause correspondence: same ids in order, same excerpts, same cases; lines recorded
    oids = [(c['id'], c['excerpt'], tuple(c['acceptance_cases'])) for c in oclauses]
    nids = [(c['id'], c['excerpt'], tuple(c['acceptance_cases'])) for c in nclauses]
    if oids != nids:
        fail(f"{key}: clause id/excerpt/case drift")
        unexpected += 1
        continue
    if oclauses:
        shifts = sorted({nc['line'] - oc['line'] for oc, nc in zip(oclauses, nclauses)})
        remeasured_sections.append((key, len(oclauses), shifts))
        for oc, nc in zip(oclauses, nclauses):
            if nc['line'] == oc['line']:
                fail(f"{key}: clause {nc['id']} unshifted at line {nc['line']}")
                unexpected += 1
print(f"carried bindings clean: {len(set(ob)&set(nb)) - unexpected}/{len(set(ob)&set(nb))}")
print("remeasured sections (key, nclauses, shifts):")
for key, n, shifts in remeasured_sections:
    print(f"  {key}: n={n} shifts={shifts}")

# --- acceptance cases ---
ocases = {c['id']: c for c in old['acceptance_cases']}
ncases = {c['id']: c for c in new['acceptance_cases']}
print(f"cases: v060={len(ocases)} v070={len(ncases)}")
missing_cases = sorted(set(ocases) - set(ncases))
added_cases = sorted(set(ncases) - set(ocases))
if missing_cases:
    fail(f"cases missing from v0.7.0: {missing_cases}")
print("added cases:", added_cases)
assert len(added_cases) == 3, added_cases
for cid in sorted(set(ocases) & set(ncases)):
    if ocases[cid] != ncases[cid]:
        # Intended: catalog-v060-exact repoint + assigned-section-binding rename only
        print(f"  carried case changed: {cid}")
        print(f"    old: {json.dumps(ocases[cid])[:400]}")
        print(f"    new: {json.dumps(ncases[cid])[:400]}")

# --- contract group ---
def contract_keys(d):
    for g in d['ownership']:
        if g['kind'] == 'contract':
            return g['keys']
    raise AssertionError("no contract group")
okeys, nkeys = contract_keys(old), contract_keys(new)
print(f"contract keys: v060={len(okeys)} v070={len(nkeys)}")
removed = [k for k in okeys if k not in nkeys]
gained = [k for k in nkeys if k not in okeys]
if removed:
    fail(f"contract keys removed: {removed}")
print("gained contract keys:", gained)
assert gained == ['Launch Plan request [urn:ax:schema:launch-plan-request]'], gained

# --- fixture group ---
def fixture_keys(d):
    for g in d['ownership']:
        if g['kind'] == 'fixture':
            return g['keys']
    raise AssertionError("no fixture group")
ofx, nfx = fixture_keys(old), fixture_keys(new)
print(f"fixture keys: v060={len(ofx)} v070={len(nfx)}")
print("gained fixture keys:", [k for k in nfx if k not in ofx])
if [k for k in ofx if k not in nfx]:
    fail("fixture keys removed")

# --- unowned ---
ou = [e['key'] for e in old['unowned_sections']]
nu = [e['key'] for e in new['unowned_sections']]
print(f"unowned: v060={ou}")
print(f"unowned: v070={nu}")
if ou != nu:
    fail("unowned key set/order changed")
for oe, ne in zip(old['unowned_sections'], new['unowned_sections']):
    if oe != ne:
        print(f"  unowned changed: {oe['key']}")
        if oe['key'] == 'section:11.10.5' and 'Disclosure owner: TASK-260830-2x16gz' in ne['gap']:
            print("    (intended P3 rewording)")
        else:
            fail(f"unowned {oe['key']} unexpected change")

print("FAILURES:", len(failures))
sys.exit(1 if failures else 0)
