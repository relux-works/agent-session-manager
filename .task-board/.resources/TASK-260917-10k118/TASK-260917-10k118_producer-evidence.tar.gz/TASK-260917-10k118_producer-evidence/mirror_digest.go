// Independent canonical-digest mirror for the v0.7.0 ownership registry.
// Written from the production struct contract in internal/traceability/traceability.go
// (field order, json tags, omitempty set) without copying its declarations:
// it must agree with both the pinned constant and the production VerifyRepository
// computation, which fails closed on any mismatch.
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
)

type ref struct {
	Path  string `json:"path"`
	Decl  string `json:"declaration"`
}

type src struct {
	Repo   string `json:"repository"`
	Rel    string `json:"release"`
	Commit string `json:"commit"`
	Doc    string `json:"document_path"`
	Digest string `json:"document_sha256"`
}

type acase struct {
	ID    string `json:"id"`
	Prod  ref    `json:"production"`
	Tests []ref  `json:"tests"`
}

type clause struct {
	ID    string   `json:"id"`
	Line  int      `json:"line"`
	Quote string   `json:"excerpt"`
	Cases []string `json:"acceptance_cases"`
}

type group struct {
	Kind  string   `json:"kind"`
	Keys  []string `json:"keys"`
	Prod  ref      `json:"production"`
	Cases []string `json:"acceptance_cases"`
	Cov   string   `json:"coverage,omitempty"`
	Gap   string   `json:"gap,omitempty"`
	Dis   []clause `json:"clauses,omitempty"`
}

type unowned struct {
	Key  string `json:"key"`
	Gap  string `json:"gap"`
	Evid string `json:"evidence"`
}

type registry struct {
	Format   string   `json:"format"`
	Version  int      `json:"format_version"`
	Source   src      `json:"source"`
	Cases    []acase  `json:"acceptance_cases"`
	Groups   []group  `json:"ownership"`
	Unowned  []unowned `json:"unowned_sections"`
}

func main() {
	raw, err := os.ReadFile(os.Args[1])
	if err != nil {
		panic(err)
	}
	var reg registry
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.DisallowUnknownFields()
	if err := dec.Decode(&reg); err != nil {
		panic(err)
	}
	canonical, err := json.Marshal(reg)
	if err != nil {
		panic(err)
	}
	sum := sha256.Sum256(canonical)
	fmt.Println(hex.EncodeToString(sum[:]))
}
