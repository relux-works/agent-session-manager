#!/usr/bin/env python3
"""Independent §1.5 table extractor: SPEC.v0.7.0.md contract table vs v0.7.0.lock.json.
Asserts: same row count, order-identical (name, urn), version-set-identical per row.
Reports version ORDER differences separately (lock normalizes to increasing)."""
import json, re, sys

SPEC, LOCK = sys.argv[1], sys.argv[2]
lines = open(SPEC).read().splitlines()
start = next(i for i, l in enumerate(lines) if l.startswith('### 1.5 '))
rows = []
for l in lines[start:]:
    if not l.startswith('|'):
        if rows:
            break
        continue
    rows.append(l)
assert rows[0].startswith('| Contract |'), rows[0]
assert rows[1].startswith('| ---'), rows[1]
spec_rows = []
for r in rows[2:]:
    cells = [c.strip() for c in r.strip().strip('|').split('|')]
    assert len(cells) == 3, r
    name, urn_cell, ver_cell = cells
    urn = re.sub(r'</?code>', '', urn_cell)
    versions = re.findall(r'<code>([0-9]+\.[0-9]+\.[0-9]+)</code>', ver_cell)
    assert versions, r
    spec_rows.append((name, urn, versions))

lock = json.load(open(LOCK))
lock_rows = [(c['name'], c['id'], c['versions']) for c in lock['contracts']]
print(f"spec rows: {len(spec_rows)}, lock rows: {len(lock_rows)}")
assert len(spec_rows) == len(lock_rows) == 64, (len(spec_rows), len(lock_rows))

fails = 0
for i, (s, l) in enumerate(zip(spec_rows, lock_rows)):
    if s[0] != l[0] or s[1] != l[1]:
        print(f"ROW {i} ORDER/META MISMATCH:\n  spec: {s[0]} {s[1]}\n  lock: {l[0]} {l[1]}")
        fails += 1
    if sorted(s[2]) != sorted(l[2]):
        print(f"ROW {i} VERSION-SET MISMATCH {s[0]}:\n  spec: {s[2]}\n  lock: {l[2]}")
        fails += 1
    elif s[2] != l[2]:
        print(f"ROW {i} order-normalized {s[0]}: spec={s[2]} lock={l[2]}")
# Launch Plan position: between Session record and Session event
names = [r[0] for r in lock_rows]
lp = names.index('Launch Plan request')
assert names[lp-1] == 'Session record' and names[lp+1] == 'Session event', names[lp-1:lp+2]
print(f"Launch Plan request at lock index {lp}, between Session record and Session event")
print("FAILURES:", fails)
sys.exit(1 if fails else 0)
