#!/bin/bash
# Reviewer mutation battery for CR-TASK-260917-10k118-1 (RUN-260917-fa6096).
# Runs on an isolated copy of the candidate tree ($TREE); pristine copy is
# $PRISTINE. Every plant is restored from the pristine copy and proved with cmp.
set -u
TREE="${TREE:?}"; PRISTINE="${PRISTINE:?}"; OUT="${OUT:?}"
export PYTHONDONTWRITEBYTECODE=1
export GOFLAGS=-count=1
mkdir -p "$OUT"; cd "$TREE" || exit 1
DIG=/tmp/rev-10k118/harness/ownership_digest.py
REG=internal/traceability/ownership.v0.7.0.json
TR=internal/traceability/traceability.go
CIG=internal/cigate/contracts.go
PIN=internal/specpin/pin.go
SD=internal/specdoc/specdoc.go
GEN=internal/cataloggen/generate.go
README=README.md
SUMMARY="$OUT/summary.log"; : > "$SUMMARY"
report(){ printf '%-5s %-10s %s\n' "$1" "$2" "$3" | tee -a "$SUMMARY"; }
restore(){ for f in "$REG" "$TR" "$CIG" "$PIN" "$SD" "$GEN" "$README"; do cp "$PRISTINE/$f" "$f"; done; rm -f internal/cigate/zz_reviewer_probe_test.go; for f in "$REG" "$TR" "$CIG" "$PIN" "$SD" "$GEN" "$README"; do cmp -s "$PRISTINE/$f" "$f" || echo "RESTORE-DIRTY $f" | tee -a "$SUMMARY"; done; }
repin(){ # re-pin reviewedOwnershipCanonicalSHA256 to the current registry bytes
  local nd; nd=$(python3 "$DIG" "$REG")
  python3 - "$nd" <<'PY'
import sys,re
p='internal/traceability/traceability.go'; s=open(p).read()
n=len(re.findall(r'reviewedOwnershipCanonicalSHA256 = "[0-9a-f]{64}"',s)); assert n==1,n
s=re.sub(r'reviewedOwnershipCanonicalSHA256 = "[0-9a-f]{64}"','reviewedOwnershipCanonicalSHA256 = "%s"'%sys.argv[1],s)
open(p,'w').write(s)
PY
  echo "$nd"
}
plant_json(){ python3 - "$1" <<'PY'
import json,collections,sys
p='internal/traceability/ownership.v0.7.0.json'
d=json.load(open(p),object_pairs_hook=collections.OrderedDict)
exec(sys.argv[1],{'d':d,'collections':collections,'json':json})
json.dump(d,open(p,'w'),indent=2); open(p,'a').write('\n')
PY
}
run_named(){ # id pkg pattern -> exit; log $OUT/$id-named.log
  go test "./$2" -run "$3" -v > "$OUT/$1-named.log" 2>&1; echo $?; }
run_suite(){ go test "./$2" > "$OUT/$1-suite.log" 2>&1; echo $?; }
tracecheck(){ local id="$1"; shift; go run ./internal/traceability/cmd/tracecheck "$@" > "$OUT/$id-tracecheck.log" 2>&1; echo $?; }

echo "=== baseline ===" | tee -a "$SUMMARY"
b1=$(run_suite base internal/traceability); b2=$(run_suite base2 internal/traceability/cmd/tracecheck); b3=$(go run ./internal/traceability/cmd/tracecheck >"$OUT/base-tracecheck.log" 2>&1; echo $?)
echo "baseline: traceability=$b1 tracecheck-suite=$b2 tracecheck-tool=$b3" | tee -a "$SUMMARY"

# ---------- J: registry plants through the production entry (digest re-pinned so the semantic gate is measured) ----------
# J1 production declaration absent (section:6.2)
plant_json '
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:6.2"]:
    prev=g["production"]["declaration"]; g["production"]["declaration"]="NoSuchReviewerDeclaration"; g["gap"]=g["gap"].replace(prev,"NoSuchReviewerDeclaration")'
nd=$(repin); e0=$(tracecheck J1); 
if [ "$e0" -ne 0 ] && grep -q 'declaration "NoSuchReviewerDeclaration" is absent' "$OUT/J1-tracecheck.log"; then report J1 REFUSED "production absent declaration refused by tracecheck (digest re-pinned $nd); exit=$e0"; elif [ "$e0" -ne 0 ]; then report J1 REFUSED-OTHER "exit=$e0: $(grep -o 'traceability check failed: .*' "$OUT/J1-tracecheck.log" | head -1 | cut -c1-160)"; else report J1 ADMITTED "exit=$e0"; fi
restore
# J2 coverage claimed (full, clauses enumerated) with the acceptance link detached (section:6.2)
plant_json '
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:6.2"]:
    g["acceptance_cases"]=[]
    for c in g.get("clauses",[]): c["acceptance_cases"]=[]'
nd=$(repin); e0=$(tracecheck J2)
if [ "$e0" -ne 0 ]; then report J2 REFUSED "evidenced claim without acceptance owner refused (digest re-pinned); exit=$e0: $(grep -o 'traceability check failed: .*' "$OUT/J2-tracecheck.log" | head -1 | cut -c1-160)"; else report J2 ADMITTED "exit=$e0"; fi
restore
# J3 owner is a Task, not a Story (section:13.10 gap) — production cannot know board identity; the named tests must
plant_json '
n=0
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:13.10"]:
    assert "Pending implementation owner: STORY-260916-3aukw3" in g["gap"]; g["gap"]=g["gap"].replace("Pending implementation owner: STORY-260916-3aukw3","Pending implementation owner: TASK-260916-3aukw3"); n+=1
assert n==1'
nd=$(repin); e0=$(tracecheck J3); e1=$(run_named J3a internal/traceability 'TestAdoptedSectionsHavePendingOwnersAndRefuseRuntimeAdmission'); e2=$(run_named J3b internal/traceability 'TestV070RegistryRederivesFromTrunkV060Registry')
report J3 "tool=$e0" "Task-not-Story owner: tracecheck exit=$e0 (production bound: board identity not validated); TestAdoptedSections...=$e1 TestV070RegistryRederives...=$e2 (both must be 1)"
restore
# J4 clause line moved by one (6.2#1 2512 -> 2513)
plant_json '
n=0
for g in d["ownership"]:
  for c in g.get("clauses",[]):
    if c["id"]=="6.2#1": assert c["line"]==2512; c["line"]=2513; n+=1
assert n==1'
nd=$(repin); e0=$(tracecheck J4)
if [ "$e0" -ne 0 ]; then report J4 REFUSED "clause line +1 refused (digest re-pinned); exit=$e0: $(grep -o 'traceability check failed: .*' "$OUT/J4-tracecheck.log" | head -1 | cut -c1-160)"; else report J4 ADMITTED "exit=$e0"; fi
restore
# J5 adopted section dodged into the unowned disclosure (section:13.10 removed, disclosed unowned)
plant_json '
gs=[g for g in d["ownership"] if not (g["kind"]=="section_binding" and g["keys"]==["section:13.10"])]
assert len(gs)==len(d["ownership"])-1; d["ownership"]=gs
d["unowned_sections"].append(collections.OrderedDict([("key","section:13.10"),("gap","Section 13.10 resume/fork environment drift is not implemented in this repository; disclosed unowned by the reviewer plant."),("evidence","reviewer plant")]))'
nd=$(repin); e0=$(tracecheck J5); e1=$(run_named J5a internal/traceability 'TestV070RegistryRederivesFromTrunkV060Registry'); e2=$(run_named J5b internal/traceability 'TestAdoptedSectionsHavePendingOwnersAndRefuseRuntimeAdmission')
report J5 "tool=$e0" "adopted 13.10 dodged to unowned: tracecheck exit=$e0; rederivation test=$e1 adopted-owners test=$e2 (both must be 1): $(grep -o 'traceability check failed: .*' "$OUT/J5-tracecheck.log" | head -1 | cut -c1-140)"
restore

# ---------- C: production code narrowing mutants ----------
# C1 legacy projection loop skips v0.5.0
python3 - <<'PY'
p='internal/traceability/traceability.go'; s=open(p).read()
old='''		{specpin.ReleaseV060, catalog.ReleaseV060},
		{specpin.ReleaseV050, catalog.ReleaseV050},
	} {'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''		{specpin.ReleaseV060, catalog.ReleaseV060},
	} {'''))
PY
e0=$(tracecheck C1); e1=$(run_suite C1 internal/traceability); e2=$(run_suite C1b internal/traceability/cmd/tracecheck); e3=$(run_suite C1c internal/catalog)
if [ "$e1" -ne 0 ] || [ "$e2" -ne 0 ]; then report C1 KILLED "legacy loop skipping v0.5.0: tool=$e0 traceability=$e1 tracecheck=$e2 catalog=$e3"; else report C1 SURVIVED "legacy loop skipping v0.5.0: tool=$e0 traceability=$e1 tracecheck=$e2 catalog=$e3 (unobservable: both operands are compiled-in artifacts)"; fi
restore
# C2 assigned-scope admission admits exactly section:13.10
python3 - <<'PY'
p='internal/traceability/traceability.go'; s=open(p).read()
old='''			measured := coverage[key]
			if measured.Level != coverageFull {'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''			measured := coverage[key]
			if measured.Level != coverageFull && key != "section:13.10" {'''))
PY
e0=$(tracecheck C2 -section 13.10); e1=$(run_named C2 internal/traceability 'TestAdoptedSectionsHavePendingOwnersAndRefuseRuntimeAdmission'); e2=$(run_suite C2b internal/traceability); e3=$(run_suite C2c internal/traceability/cmd/tracecheck)
if [ "$e0" -eq 0 ] && [ "$e1" -ne 0 ] && grep -q 'FAIL: TestAdoptedSectionsHavePendingOwnersAndRefuseRuntimeAdmission/13.10' "$OUT/C2-named.log"; then report C2 KILLED "admission narrowed to admit 13.10: tracecheck -section 13.10 exit=$e0 (admitted, narrowing live); named=$e1 suite=$e2 cmd=$e3"; else report C2 NOT-KILLED "tool=$e0 named=$e1 suite=$e2 cmd=$e3"; fi
restore
# C3 cigate historical root compared by prefix
python3 - <<'PY'
p='internal/cigate/contracts.go'; s=open(p).read()
old='	if pinHistorical != catalogHistorical {'
assert s.count(old)==1; s=s.replace(old,'	if !strings.HasPrefix(catalogHistorical, pinHistorical) {')
s=s.replace('import (\n','import (\n\t"strings"\n',1); open(p,'w').write(s)
PY
gofmt -w internal/cigate/contracts.go
e1=$(run_suite C3 internal/cigate)
cat > internal/cigate/zz_reviewer_probe_test.go <<'GO'
package cigate
import "testing"
func TestReviewerProbePrefixHistoricalRoot(t *testing.T) {
	if _, err := checkReleaseRoots("v0.7.0", "v0.4.3", "v0.7.0", "v0.4.30"); err == nil {
		t.Fatalf("checkReleaseRoots admitted a same-prefix historical root drift")
	}
}
GO
e2=$(run_named C3p internal/cigate 'TestReviewerProbePrefixHistoricalRoot')
if [ "$e1" -ne 0 ]; then report C3 KILLED "historical root by prefix: cigate suite=$e1"; else report C3 SURVIVED "historical root by prefix: shipped cigate suite=$e1 (no same-prefix row); reviewer probe row v0.4.30=$e2 (1 = would kill)"; fi
restore
e2b=$(cat > internal/cigate/zz_reviewer_probe_test.go <<'GO'
package cigate
import "testing"
func TestReviewerProbePrefixHistoricalRoot(t *testing.T) {
	if _, err := checkReleaseRoots("v0.7.0", "v0.4.3", "v0.7.0", "v0.4.30"); err == nil {
		t.Fatalf("checkReleaseRoots admitted a same-prefix historical root drift")
	}
}
GO
run_named C3q internal/cigate 'TestReviewerProbePrefixHistoricalRoot'); echo "C3 probe on pristine cigate: exit=$e2b (must be 0)" | tee -a "$SUMMARY"; restore
# C4 pin: 64-row check narrowed to a floor (admits a 65-row lock) — structural layer behind the digest
python3 - <<'PY'
p='internal/specpin/pin.go'; s=open(p).read()
old='''	if len(manifest.Contracts) != 64 {
		return mismatch("contract registry has %d rows, want 64", len(manifest.Contracts))'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''	if len(manifest.Contracts) < 64 {
		return mismatch("contract registry has %d rows, want 64", len(manifest.Contracts))'''))
PY
e1=$(run_suite C4 internal/specpin); e2=$(run_suite C4b internal/cataloggen)
if [ "$e1" -ne 0 ] || [ "$e2" -ne 0 ]; then report C4 KILLED "validateV070 row floor: specpin=$e1 cataloggen=$e2"; else report C4 SURVIVED "validateV070 row floor: specpin=$e1 cataloggen=$e2 (structural layer shielded by ManifestSHA256V070; no test asserts the structural message)"; fi
restore
# C5 pin: ContractsForRelease(v0.7.0) admits a v0.6.0 manifest
python3 - <<'PY'
p='internal/specpin/pin.go'; s=open(p).read()
old='''	case ReleaseV070:
		if manifest.Source.Release != ReleaseV070 {'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''	case ReleaseV070:
		if manifest.Source.Release != ReleaseV070 && manifest.Source.Release != ReleaseV060 {'''))
PY
e1=$(run_named C5 internal/specpin 'TestStalePinsCannotAuthorizeV070'); e2=$(run_suite C5b internal/specpin)
if [ "$e1" -ne 0 ]; then report C5 KILLED "stale v0.6.0 manifest authorizing v0.7.0: TestStalePinsCannotAuthorizeV070=$e1 suite=$e2"; else report C5 SURVIVED "named=$e1 suite=$e2"; fi
restore
# C6 specdoc: ParseV070 also admits the v0.6.0 digest
python3 - <<'PY'
p='internal/specdoc/specdoc.go'; s=open(p).read()
old='''	if got := hex.EncodeToString(digest[:]); got != specpin.DocumentSHA256V070 {
		return nil, fmt.Errorf("%w: SHA-256 is %s, want %s", ErrDocumentMismatch, got, specpin.DocumentSHA256V070)'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''	if got := hex.EncodeToString(digest[:]); got != specpin.DocumentSHA256V070 && got != specpin.DocumentSHA256V060 {
		return nil, fmt.Errorf("%w: SHA-256 is %s, want %s", ErrDocumentMismatch, got, specpin.DocumentSHA256V070)'''))
PY
e1=$(run_named C6 internal/specdoc 'TestParseV070RefusesEveryNonAdoptedDocument'); e2=$(run_suite C6b internal/specdoc)
if [ "$e1" -ne 0 ]; then report C6 KILLED "ParseV070 admitting the v0.6.0 document: named=$e1 suite=$e2"; else report C6 SURVIVED "named=$e1 suite=$e2"; fi
restore
# C7 cataloggen: Generate falls back to the v0.6.0 verifier
python3 - <<'PY'
p='internal/cataloggen/generate.go'; s=open(p).read()
old='''	manifest, err := specpin.VerifyV070(contractLock)
	if err != nil {
		return nil, invalid("verify normative lock: %v", err)
	}'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''	manifest, err := specpin.VerifyV070(contractLock)
	if err != nil {
		manifest, err = specpin.VerifyV060(contractLock)
	}
	if err != nil {
		return nil, invalid("verify normative lock: %v", err)
	}'''))
PY
e1=$(run_named C7 internal/cataloggen 'TestGenerateRefusesStaleV060Authority'); e2=$(run_suite C7b internal/cataloggen); e3=$(run_suite C7c internal/catalog/cmd/cataloggen)
if [ "$e1" -ne 0 ]; then report C7 KILLED "Generate v0.6.0 fallback: named=$e1 suite=$e2 cmd=$e3"; else report C7 SURVIVED "named=$e1 suite=$e2 cmd=$e3"; fi
restore
# C8 traceability: resolveAssignedSections keeps the v0.6.0 inventory (identifier-equal inventories: expected equivalent)
python3 - <<'PY'
p='internal/traceability/traceability.go'; s=open(p).read()
old='''			for _, identifier := range []string{start, end} {
				if !specpin.IsSectionV070(identifier) {'''
assert s.count(old)==1; open(p,'w').write(s.replace(old,'''			for _, identifier := range []string{start, end} {
				if !specpin.IsSectionV060(identifier) {'''))
PY
e1=$(run_suite C8 internal/traceability); e2=$(run_suite C8b internal/traceability/cmd/tracecheck)
report C8 "$( [ "$e1" -ne 0 ] || [ "$e2" -ne 0 ] && echo KILLED || echo SURVIVED)" "IsSectionV060 in resolveAssignedSections: traceability=$e1 tracecheck=$e2 (inventories identifier-equal: equivalent mutant expected)"
restore
# CTL harmless control: operand swap in cigate current-root comparison
python3 - <<'PY'
p='internal/cigate/contracts.go'; s=open(p).read()
old='	if pinCurrent != catalogCurrent {'
assert s.count(old)==1; open(p,'w').write(s.replace(old,'	if catalogCurrent != pinCurrent {'))
PY
e1=$(run_suite CTL internal/cigate)
if [ "$e1" -eq 0 ]; then report CTL SURVIVED "harmless operand swap green as designed: cigate=$e1"; else report CTL UNEXPECTED "cigate=$e1"; fi
restore

# ---------- N/R: the two new verification tests (producer's plants re-run; each KILLED twice) ----------
named_twice(){ # id pkg pattern needle
  local a b; a=$(run_named "$1" "$2" "$3"); b=$(go test "./$2" -run "$3" -v > "$OUT/$1-named-rerun.log" 2>&1; echo $?)
  if [ "$a" -ne 0 ] && [ "$b" -ne 0 ] && grep -q -F -- "$4" "$OUT/$1-named.log" && grep -q -F -- "$4" "$OUT/$1-named-rerun.log"; then echo KILLED; else echo "NOT-KILLED(a=$a,b=$b)"; fi; }
plant_json 'gs=[g for g in d["ownership"] if not (g["kind"]=="section_binding" and g["keys"]==["section:6.2"])]; assert len(gs)==len(d["ownership"])-1; d["ownership"]=gs'
report N1 "$(named_twice N1 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'drops 1 carried bindings: ["section:6.2"]')" "drop one carried binding (x2)"; restore
plant_json '
n=0
for g in d["ownership"]:
  for c in g.get("clauses",[]):
    if c["id"]=="6.2#1": assert c["line"]==2512; c["line"]=2433; n+=1
assert n==1'
report N2 "$(named_twice N2 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'excerpt does not begin at line 2433')" "one clause left at its v0.6.0 line (x2)"; restore
plant_json '
d["ownership"].append(collections.OrderedDict([("kind","section_binding"),("keys",["section:9.9"]),("production",collections.OrderedDict([("path","internal/catalog/catalog.go"),("declaration","ForRelease")])),("acceptance_cases",["catalog-v070-exact"]),("coverage","unevidenced"),("gap","ForRelease only returns the reviewed typed catalog rows that reference 9.9; no clause of 9.9 is enumerated against an acceptance case.")]))'
report N3 "$(named_twice N3 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'section:9.9" is not carried and not a reviewed addition')" "self-minted binding (x2)"; restore
plant_json 'cs=[c for c in d["acceptance_cases"] if c["id"]!="config-versioned-readers"]; assert len(cs)==len(d["acceptance_cases"])-1; d["acceptance_cases"]=cs'
report N4 "$(named_twice N4 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'drops carried acceptance case "config-versioned-readers"')" "drop one carried case (x2)"; restore
plant_json '
n=0
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:6.1"]: g["gap"]=g["gap"]+" (drift)"; n+=1
assert n==1'
report N5 "$(named_twice N5 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'section:6.1" gap changed without a reviewed rewording')" "drift one carried gap (x2)"; restore
# N6 (reviewer): a carried binding's production owner moved to another existing declaration (self-minted re-attribution)
plant_json '
n=0
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:6.2"]: g["production"]["declaration"]="ForRelease"; g["production"]["path"]="internal/catalog/catalog.go"; n+=1
assert n==1'
report N6 "$(named_twice N6 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'production moved from')" "carried binding re-attributed to an existing declaration (x2)"; restore
# N7 (reviewer): a new binding claims partial coverage with a fabricated clause (must fail on the story-stub rule)
plant_json '
n=0
for g in d["ownership"]:
  if g["kind"]=="section_binding" and g["keys"]==["section:13.10"]:
    g["coverage"]="sliver"; g["clauses"]=[collections.OrderedDict([("id","13.10#1"),("line",1),("excerpt","x"),("acceptance_cases",["catalog-v070-exact"])])]; n+=1
assert n==1'
report N7 "$(named_twice N7 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry 'claims sliver coverage, want unevidenced')" "new binding claiming coverage (x2)"; restore
# C0 identical round-trip control
plant_json 'pass'
e1=$(run_named C0 internal/traceability TestV070RegistryRederivesFromTrunkV060Registry); [ "$e1" -eq 0 ] && report C0 SURVIVED "identical JSON round-trip green" || report C0 UNEXPECTED "exit=$e1"; restore
# R1 fenced figure drift
python3 - <<'PY'
p='README.md'; s=open(p).read(); old='section coverage: bindings=68 full=2'; assert s.count(old)==1; open(p,'w').write(s.replace(old,'section coverage: bindings=67 full=2'))
PY
report R1 "$(named_twice R1 internal/traceability/cmd/tracecheck TestREADMEMeasuredCoverageMatchesTracecheckReport 'fenced coverage line')" "fenced figure drift (x2)"; restore
# R2 prose figure drift
python3 - <<'PY'
p='README.md'; s=open(p).read(); old='discharge 49 of the 569 normative clauses'; assert s.count(old)==1; open(p,'w').write(s.replace(old,'discharge 49 of the 568 normative clauses'))
PY
report R2 "$(named_twice R2 internal/traceability/cmd/tracecheck TestREADMEMeasuredCoverageMatchesTracecheckReport 'publishes 568')" "prose figure drift (x2)"; restore
# R2b (reviewer) prose word drift: "Two bindings are full" -> "Three bindings are full"
python3 - <<'PY'
p='README.md'; s=open(p).read(); old='Two bindings are `full`'; assert s.count(old)==1; open(p,'w').write(s.replace(old,'Three bindings are `full`'))
PY
report R2b "$(named_twice R2b internal/traceability/cmd/tracecheck TestREADMEMeasuredCoverageMatchesTracecheckReport 'want exactly 1')" "spelled figure drift (x2)"; restore
# R3 token-preserving: README intact, one binding removed, digest re-pinned so production prints a new report
plant_json 'gs=[g for g in d["ownership"] if not (g["kind"]=="section_binding" and g["keys"]==["section:10.1"])]; assert len(gs)==len(d["ownership"])-1; d["ownership"]=gs'
nd=$(repin); e0=$(tracecheck R3)
v=$(named_twice R3 internal/traceability/cmd/tracecheck TestREADMEMeasuredCoverageMatchesTracecheckReport 'fenced coverage line'); e2=$(run_suite R3b internal/traceability); e3=$(run_suite R3c internal/traceability/cmd/tracecheck)
report R3 "$v" "README intact, binding removed, digest re-pinned $nd: tool exit=$e0 (green, prints $(sed -n 2p "$OUT/R3-tracecheck.log" | cut -c1-60)); lib suite=$e2 cmd suite=$e3"; restore
# C0R case-only control
python3 - <<'PY'
p='README.md'; s=open(p).read(); old='Sixty-eight section bindings discharge'; assert s.count(old)==1; open(p,'w').write(s.replace(old,'SIXTY-EIGHT section bindings discharge'))
PY
e1=$(run_named C0R internal/traceability/cmd/tracecheck TestREADMEMeasuredCoverageMatchesTracecheckReport); [ "$e1" -eq 0 ] && report C0R SURVIVED "case-only figure edit green" || report C0R UNEXPECTED "exit=$e1"; restore

echo "=== restore proof ===" | tee -a "$SUMMARY"
cd "$TREE" && git status --short | tee -a "$SUMMARY"
find "$TREE" -name '__pycache__' -o -name '*.pyc' | tee -a "$SUMMARY"
echo "=== done ===" | tee -a "$SUMMARY"
