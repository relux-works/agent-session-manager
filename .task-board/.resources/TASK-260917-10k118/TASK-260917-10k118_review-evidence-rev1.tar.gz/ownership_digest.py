#!/usr/bin/env python3
"""Independent mirror of traceability's canonical ownership projection digest
(json.Marshal of the decoded Go struct: field order per struct, omitempty on
coverage/gap/clauses, Go HTML escaping, nil-vs-empty slices preserved)."""
import json,hashlib,collections,sys
def digest(raw):
    d=json.loads(raw,object_pairs_hook=collections.OrderedDict)
    def enc(o):
        s=json.dumps(o,separators=(",",":"),ensure_ascii=False)
        return s.replace("<","\\u003c").replace(">","\\u003e").replace("&","\\u0026")
    def ref(r): return collections.OrderedDict([("path",r.get("path","")),("declaration",r.get("declaration",""))])
    out=collections.OrderedDict()
    out["format"]=d.get("format",""); out["format_version"]=d.get("format_version",0)
    src=d.get("source",{})
    out["source"]=collections.OrderedDict([("repository",src.get("repository","")),("release",src.get("release","")),("commit",src.get("commit","")),("document_path",src.get("document_path","")),("document_sha256",src.get("document_sha256",""))])
    ac=None
    if d.get("acceptance_cases") is not None:
        ac=[collections.OrderedDict([("id",c.get("id","")),("production",ref(c.get("production",{}))),("tests",None if c.get("tests") is None else [ref(t) for t in c["tests"]])]) for c in d["acceptance_cases"]]
    out["acceptance_cases"]=ac
    own=None
    if d.get("ownership") is not None:
        own=[]
        for g in d["ownership"]:
            o=collections.OrderedDict([("kind",g.get("kind","")),("keys",g.get("keys")),("production",ref(g.get("production",{}))),("acceptance_cases",g.get("acceptance_cases"))])
            if g.get("coverage"): o["coverage"]=g["coverage"]
            if g.get("gap"): o["gap"]=g["gap"]
            if g.get("clauses"):
                o["clauses"]=[collections.OrderedDict([("id",c.get("id","")),("line",c.get("line",0)),("excerpt",c.get("excerpt","")),("acceptance_cases",c.get("acceptance_cases"))]) for c in g["clauses"]]
            own.append(o)
    out["ownership"]=own
    un=None
    if d.get("unowned_sections") is not None:
        un=[collections.OrderedDict([("key",u.get("key","")),("gap",u.get("gap","")),("evidence",u.get("evidence",""))]) for u in d["unowned_sections"]]
    out["unowned_sections"]=un
    return hashlib.sha256(enc(out).encode("utf-8")).hexdigest()
if __name__=="__main__":
    print(digest(open(sys.argv[1],"rb").read()))
