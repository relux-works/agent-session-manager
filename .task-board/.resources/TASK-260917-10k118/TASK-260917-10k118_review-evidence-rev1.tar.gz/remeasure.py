import re,json,sys,collections
KW=re.compile(r"\b(MUST NOT|MUST|SHALL NOT|SHALL|REQUIRED)\b")
ATX=re.compile(r"^(#{1,6})\s+(.*)$")
NUM=re.compile(r"^([0-9]+(?:\.[0-9A-Z]+)*|[A-Z](?:\.[0-9]+)+)\.?\s")
APX=re.compile(r"^Appendix\s+([A-Z])\.")
def norm(s): return " ".join(s.split())
class Doc:
    def __init__(self,path):
        self.lines=open(path,encoding="utf-8").read().replace("\r\n","\n").split("\n")
        self.sec=[""]*(len(self.lines)+1); cur=""
        for i,l in enumerate(self.lines):
            m=ATX.match(l)
            if m:
                t=m.group(2)
                a=APX.match(t); n=NUM.match(t)
                if a: cur=a.group(1)
                elif n: cur=n.group(1)
            self.sec[i+1]=cur
        # normalized text with hard boundaries -> build per-line normalized string list
        self.hard=[False]*(len(self.lines)+1)
        for n in range(1,len(self.lines)):
            a,b=self.lines[n-1],self.lines[n]
            if a.strip()=="" or b.strip()=="": self.hard[n]=True
            elif a.strip().startswith("|") and b.strip().startswith("|"): self.hard[n]=True
    def inventory(self,ident):
        pre=ident+"."; out=[]
        for ln in range(1,len(self.lines)+1):
            o=self.sec[ln]
            if not o or (o!=ident and not o.startswith(pre)): continue
            if KW.search(self.lines[ln-1]): out.append((f"{ident}#{len(out)+1}",ln,self.lines[ln-1].strip()))
        return out
    def quote_begins_at(self,excerpt,line):
        # normalized excerpt must begin on `line` and not cross a hard boundary
        needle=norm(excerpt)
        if not needle: return False
        # build text from line forward until a hard boundary, normalized
        buf=[]; ln=line
        # the excerpt must START on this line: the first non-space token of the match must be on `line`
        # approach: concatenate lines from `line` until hard boundary (blank line / table row boundary)
        while ln<=len(self.lines):
            buf.append(self.lines[ln-1])
            if self.hard[ln]: break
            ln+=1
        text=norm(" ".join(buf))
        # the excerpt begins at `line` if the needle occurs in text at an index that lies within the first line's normalized span
        first=norm(self.lines[line-1])
        idx=text.find(needle)
        while idx>=0:
            if idx<len(first) or (idx==len(first) and False):
                return True
            idx=text.find(needle,idx+1)
        return False
def sec_key_to_ident(key):
    k=key[len("section:"):]
    if k.startswith("appendix-"): return k[len("appendix-"):].upper()
    return k
def audit(regpath,docpath,tag):
    reg=json.load(open(regpath))
    doc=Doc(docpath)
    bad=0; total=0; shifts=collections.Counter()
    for g in reg["ownership"]:
        if g["kind"]!="section_binding": continue
        key=g["keys"][0]; ident=sec_key_to_ident(key)
        inv={c[0]:(c[1],c[2]) for c in doc.inventory(ident)}
        for c in g.get("clauses") or []:
            total+=1
            if c["id"] not in inv: print(f"[{tag}] {key} {c['id']}: not in inventory"); bad+=1; continue
            ln,text=inv[c["id"]]
            if ln!=c["line"]: print(f"[{tag}] {key} {c['id']}: declared line {c['line']} measured {ln}"); bad+=1
            if not doc.quote_begins_at(c["excerpt"],c["line"]): print(f"[{tag}] {key} {c['id']}: excerpt does not begin at {c['line']}"); bad+=1
    return total,bad
t7,b7=audit("internal/traceability/ownership.v0.7.0.json","internal/specdoc/SPEC.v0.7.0.md","v0.7.0")
t6,b6=audit("/tmp/rev-10k118/trunk-ownership.v0.6.0.json","internal/specdoc/SPEC.v0.6.0.md","v0.6.0 trunk")
print(f"v0.7.0: {t7} clauses checked, {b7} failures; v0.6.0 trunk: {t6} clauses checked, {b6} failures")
# line shifts between registries
r6=json.load(open("/tmp/rev-10k118/trunk-ownership.v0.6.0.json")); r7=json.load(open("internal/traceability/ownership.v0.7.0.json"))
b6m={g["keys"][0]:g for g in r6["ownership"] if g["kind"]=="section_binding"}
b7m={g["keys"][0]:g for g in r7["ownership"] if g["kind"]=="section_binding"}
shifts=collections.Counter(); unshifted=0
for k,g in b6m.items():
    n=b7m.get(k)
    if n is None: print("MISSING in v0.7.0:",k); continue
    for a,b in zip(g.get("clauses") or [], n.get("clauses") or []):
        shifts[b["line"]-a["line"]]+=1
        if b["line"]==a["line"]: unshifted+=1
print("line shifts (delta:count):",dict(shifts),"unshifted:",unshifted)
