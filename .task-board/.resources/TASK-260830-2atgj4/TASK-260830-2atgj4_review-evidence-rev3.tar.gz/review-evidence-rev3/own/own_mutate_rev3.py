#!/usr/bin/env python3
"""Reviewer-owned narrowing plants for TASK-260830-2atgj4 rev3 (claude-opus-5 reviewer).
Runs against an isolated copy of the candidate tree; never touches the Story worktree.
Usage: PYTHONDONTWRITEBYTECODE=1 python3 own_mutate_rev3.py <worktree-root> <evidence-dir>
Each plant keeps the gate present and admits exactly one member of the class it must
reject (or consults exactly one forbidden clock signal); the named property must fail.
"""
import hashlib, json, re, shutil, subprocess, sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=True)
copy = output / "mutation-source-own"
if copy.exists():
    raise SystemExit("refusing to overwrite an existing mutation source")
copy.mkdir()
shutil.copytree(root / "internal", copy / "internal")
for name in ("go.mod", "go.sum", "README.md", "LOGBOOK.md"):
    shutil.copy2(root / name, copy / name)
results = []

def cmd(package, pattern):
    return ["go", "test", "./internal/" + package, "-run", pattern, "-count=1", "-v"]

# (name, file, [(old, new)], command, narrowing bound)
MUTANTS = [
    ("R3-P1-loser-order-epoch-only", "internal/sessstate/sessstate.go",
     [("\tsort.Slice(losing, func(i, j int) bool { return Compare(losing[i], losing[j]) < 0 })",
       "\tsort.Slice(losing, func(i, j int) bool { return losing[i].Epoch < losing[j].Epoch })")],
     cmd("sessstate", r"^TestOwnershipUnionOrderIndependent$"),
     "Loser evidence ordered by epoch only: two same-epoch losers report in ARRIVAL order (insertion sort is stable), so exactly that class becomes permutation-dependent while every other multiset stays canonical."),
    ("R3-P1-partition-second-half-dropped", "internal/sessstate/sessstate.go",
     [("\tlosing := make([]LeaseHead, 0, len(union))\n\tfor _, lease := range union {\n\t\tif Compare(lease, winner) < 0 {",
       "\tlosing := make([]LeaseHead, 0, len(union))\n\tfor index, lease := range union {\n\t\tif index == len(union)-1 && len(union) == 3 && Compare(lease, winner) < 0 && lease.Epoch == winner.Epoch {\n\t\t\tcontinue\n\t\t}\n\t\tif Compare(lease, winner) < 0 {")],
     cmd("sessstate", r"^TestOwnershipUnionPartitionStable$"),
     "A same-epoch loser that arrives LAST in a 3-entry union (the reconnect tail) loses its evidence; the ordered 2-partition concatenations must observe it."),
    ("R3-P2-loser-same-id-lower-epoch-dropped", "internal/sessstate/sessstate.go",
     [("\t\tif Compare(lease, winner) < 0 {\n\t\t\tlosing = append(losing, lease)",
       "\t\tif Compare(lease, winner) < 0 && lease.LeaseID != winner.LeaseID {\n\t\t\tlosing = append(losing, lease)")],
     cmd("sessstate", r"^TestOwnershipLoserHistoryPreserved$"),
     "A lower-epoch loser carrying the winner's own lease ID is dropped from the preserved evidence; every other loser still reports."),
    ("R3-P2-store-epoch1-hidden-in-long-chain", "internal/sessrepo/lease_store.go",
     [("\t\tif summary.RecordID != expected {\n\t\t\treturn nil, fmt.Errorf(\"lease %s attests %s\", name, summary.RecordID)\n\t\t}\n\t\tstored = append(stored, summary)",
       "\t\tif summary.RecordID != expected {\n\t\t\treturn nil, fmt.Errorf(\"lease %s attests %s\", name, summary.RecordID)\n\t\t}\n\t\tif summary.Epoch == 1 && len(entries) >= 4 {\n\t\t\tcontinue\n\t\t}\n\t\tstored = append(stored, summary)")],
     cmd("sessrepo", r"^TestOwnershipStoreSingleAuthorityPerEpoch$"),
     "The store hides the epoch-1 loser from ListLeases/WinningLease once the chain holds four or more leases; shorter chains list every lease."),
    ("R3-P3-store-skips-2020-created-at", "internal/sessrepo/lease_store.go",
     [("\t\tsummary, err := decodeStoredLease(sessionID, blob)\n\t\tif err != nil {\n\t\t\treturn nil, fmt.Errorf(\"lease %s: %v\", name, err)\n\t\t}",
       "\t\tsummary, err := decodeStoredLease(sessionID, blob)\n\t\tif err != nil {\n\t\t\treturn nil, fmt.Errorf(\"lease %s: %v\", name, err)\n\t\t}\n\t\tif bytes.Contains(blob, []byte(`\"created_at\":\"2020-`)) {\n\t\t\tcontinue\n\t\t}")],
     cmd("sessrepo", r"^TestOwnershipStoreClockNonAuthority$"),
     "The store consults created_at: a lease stamped in 2020 is not loaded, so only the backwards clock shift changes authority."),
    ("R3-P3-gate-refuses-input-in-2027", "internal/fencing/gate.go",
     [("\tif observation.Now.IsZero() {",
       "\tif observation.Now.IsZero() || (observation.Now.Year() == 2027 && operation == OperationInput) {")],
     cmd("fencing", r"^TestOwnershipGateClockNonAuthority$"),
     "The gate consults the absolute clock: input is refused when the wall clock reads 2027, so only the +365d translation of the input entry changes its verdict."),
    ("R3-P4-gate-admits-future-epoch-9", "internal/fencing/gate.go",
     [("\tif !epochsEqual {\n\t\tif presented.Epoch < observation.Winner.Epoch {",
       "\tif !epochsEqual && presented.Epoch != 9 {\n\t\tif presented.Epoch < observation.Winner.Epoch {")],
     cmd("fencing", r"^TestOwnershipGateSingleAuthorizedOwner$"),
     "A presenter at future epoch 9 skips the epoch arm and, carrying the winner's lease ID, is minted a token: two presenters authorize on the local host."),
    ("C-harmless-comment", "internal/fencing/gate.go",
     [("\tepochsEqual := presented.Epoch == observation.Winner.Epoch",
       "\t// reviewer control: comment only, no behavior change\n\tepochsEqual := presented.Epoch == observation.Winner.Epoch")],
     cmd("fencing", r"^TestOwnershipGateSingleAuthorizedOwner$"),
     "Applied harmless control: must SURVIVE."),
    ("C-not-applied", "internal/fencing/gate.go",
     [("TOKEN_THAT_IS_NOT_PRESENT_R3", "x")],
     cmd("fencing", r"^TestOwnershipGateSingleAuthorizedOwner$"),
     "Application control: must be NOT_APPLIED."),
]

def classify(name, command, bound):
    log = output / (name + ".log")
    with log.open("w") as fh:
        p = subprocess.run(command, cwd=copy, stdout=fh, stderr=subprocess.STDOUT, timeout=600)
    text = log.read_text()
    failures = re.findall(r"^\s*--- FAIL: ([^ ]+)", text, re.M)
    ran = re.findall(r"^=== RUN ", text, re.M)
    cls = "COMPILE_OR_HARNESS_FAILURE" if not ran else ("SURVIVED" if p.returncode == 0 else ("KILLED" if failures else "COMPILE_OR_HARNESS_FAILURE"))
    results.append(dict(mutant=name, classification=cls, exit=p.returncode, failed_tests=failures, bound=bound, command=command))
    print(name, cls, p.returncode, ", ".join(failures), flush=True)

for name, path, edits, command, bound in MUTANTS:
    source = copy / path
    original = source.read_text()
    if any(original.count(old) != 1 for old, _ in edits):
        results.append(dict(mutant=name, classification="NOT_APPLIED", counts=[original.count(o) for o, _ in edits], bound=bound))
        print(name, "NOT_APPLIED", [original.count(o) for o, _ in edits], flush=True)
        continue
    changed = original
    for old, new in edits:
        changed = changed.replace(old, new)
    source.write_text(changed)
    try:
        classify(name, command, bound)
    finally:
        source.write_text(original)
        assert hashlib.sha256(source.read_bytes()).hexdigest() == hashlib.sha256(original.encode()).hexdigest()

with (output / "control-after.log").open("w") as fh:
    after = subprocess.run(["go", "test", "./internal/sessstate", "./internal/sessrepo", "./internal/fencing", "-run", "^TestOwnership", "-count=1"], cwd=copy, stdout=fh, stderr=subprocess.STDOUT, timeout=600)
results.append(dict(mutant="control-after", classification="CONTROL", exit=after.returncode))
print("control-after CONTROL", after.returncode, flush=True)
(output / "own-mutants.json").write_text(json.dumps(results, indent=2) + "\n")
bad = [r for r in results if r["mutant"].startswith("R3-") and r["classification"] != "KILLED"]
ctl = [r for r in results if r["mutant"] == "C-harmless-comment" and r["classification"] != "SURVIVED"]
raise SystemExit(1 if bad or ctl or after.returncode else 0)
