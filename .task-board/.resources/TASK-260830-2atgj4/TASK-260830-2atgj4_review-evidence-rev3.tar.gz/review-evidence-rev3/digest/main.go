// Independent recomputation of the ownership registry projection digest:
// the struct shapes are copied verbatim from internal/traceability/traceability.go
// (ownershipRegistry and its members) so json.Marshal yields the same projection.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
)

type ownershipRegistry struct {
	Format          string           `json:"format"`
	FormatVersion   int              `json:"format_version"`
	Source          registrySource   `json:"source"`
	AcceptanceCases []acceptanceCase `json:"acceptance_cases"`
	Ownership       []ownershipGroup `json:"ownership"`
	UnownedSections []unownedSection `json:"unowned_sections"`
}
type unownedSection struct {
	Key      string `json:"key"`
	Gap      string `json:"gap"`
	Evidence string `json:"evidence"`
}
type registrySource struct {
	Repository     string `json:"repository"`
	Release        string `json:"release"`
	Commit         string `json:"commit"`
	DocumentPath   string `json:"document_path"`
	DocumentSHA256 string `json:"document_sha256"`
}
type acceptanceCase struct {
	ID         string          `json:"id"`
	Production codeReference   `json:"production"`
	Tests      []codeReference `json:"tests"`
}
type ownershipGroup struct {
	Kind            string             `json:"kind"`
	Keys            []string           `json:"keys"`
	Production      codeReference      `json:"production"`
	AcceptanceCases []string           `json:"acceptance_cases"`
	Coverage        string             `json:"coverage,omitempty"`
	Gap             string             `json:"gap,omitempty"`
	Clauses         []dischargedClause `json:"clauses,omitempty"`
}
type dischargedClause struct {
	ID              string   `json:"id"`
	Line            int      `json:"line"`
	Excerpt         string   `json:"excerpt"`
	AcceptanceCases []string `json:"acceptance_cases"`
}
type codeReference struct {
	Path        string `json:"path"`
	Declaration string `json:"declaration"`
}

func main() {
	for _, p := range os.Args[1:] {
		raw, err := os.ReadFile(p)
		if err != nil {
			panic(err)
		}
		var reg ownershipRegistry
		if err := json.Unmarshal(raw, &reg); err != nil {
			panic(err)
		}
		canonical, err := json.Marshal(reg)
		if err != nil {
			panic(err)
		}
		d := sha256.Sum256(canonical)
		fmt.Printf("%s  %s (acceptance=%d ownership=%d unowned=%d)\n", hex.EncodeToString(d[:]), p, len(reg.AcceptanceCases), len(reg.Ownership), len(reg.UnownedSections))
	}
}
