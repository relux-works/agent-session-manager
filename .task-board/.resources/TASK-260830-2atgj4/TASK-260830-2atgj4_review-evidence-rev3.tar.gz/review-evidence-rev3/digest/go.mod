module digestprobe

go 1.22
