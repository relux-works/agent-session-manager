#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants for TASK-260830-2atgj4 rev2.

Isolated tree copies only; never touches the live Story worktree.
Each R-mutant weakens exactly one gate to admit a single member of the
rejected class (or consult one forbidden clock signal in one epoch
condition). The C-mutant is an applied harmless control (must SURVIVE).
"""
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

root = Path("/Users/iv/Developer/ReluxWorks/agent-session-manager/.temp/STORY-260830-1oqfec/worktree")
output = Path("/tmp/review-2atgj4/own")
output.mkdir(parents=True, exist_ok=True)

MUTANTS = [
    ("R1-tiebreak-epoch1", "internal/sessstate/sessstate.go",
     [("\tcase a.LeaseID < b.LeaseID:\n\t\treturn -1",
       "\tcase a.LeaseID < b.LeaseID:\n\t\tif a.Epoch == 1 {\n\t\t\treturn 1\n\t\t}\n\t\treturn -1"),
      ("\tcase a.LeaseID > b.LeaseID:\n\t\treturn 1",
       "\tcase a.LeaseID > b.LeaseID:\n\t\tif a.Epoch == 1 {\n\t\t\treturn -1\n\t\t}\n\t\treturn 1")],
     ["go", "test", "./internal/sessstate", "-run", r"^TestOwnershipWinnerIsTupleMaximum$", "-count=1", "-v"],
     "Invert the lease_id tie-break only at epoch 1; other epochs keep the landed order."),
    ("R2-drop-last-loser", "internal/sessstate/sessstate.go",
     [("\t\tif Compare(lease, winner) < 0 {",
       "\t\tif Compare(lease, winner) < 0 && lease != union[len(union)-1] {")],
     ["go", "test", "./internal/sessstate", "-run", r"^TestOwnershipLoserHistoryPreserved$", "-count=1", "-v"],
     "Drop a losing lease only when it is the last union entry; all other losers still report."),
    ("R3-gate-clock-tie", "internal/fencing/gate.go",
     [("\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n\tif !epochsEqual {",
       "\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n\tif epochsEqual && observation.Now.Year() == 2027 {\n\t\treturn LeaseToken{}, refuse(ErrLeaseConflict, \"reviewer plant: tie path consults absolute year\")\n\t}\n\tif !epochsEqual {")],
     ["go", "test", "./internal/fencing", "-run", r"^TestOwnershipGateClockNonAuthority$", "-count=1", "-v"],
     "Consult the wall-clock year only on the epoch-tie path; a 2027 translation refuses where others authorize."),
    ("R4-gate-epoch1-second-owner", "internal/fencing/gate.go",
     [("\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n\tif !epochsEqual {",
       "\tepochsEqual := presented.Epoch == observation.Winner.Epoch\n\tif presented.Epoch == 1 && !epochsEqual {\n\t\treturn mintLeaseToken(observation.SessionID, presented.Epoch, presented.LeaseID), nil\n\t}\n\tif !epochsEqual {")],
     ["go", "test", "./internal/fencing", "-run", r"^TestOwnershipGateSingleAuthorizedOwner$", "-count=1", "-v"],
     "Admit a second authoritative owner only for epoch 1; the stale epoch-1 presenter authorizes."),
    ("C-harmless-comment", "internal/sessstate/sessstate.go",
     [("\t// First pass: validate every union entry and select the greatest",
       "\t// First pass: validate every union entry and select the greatest\n\t// reviewer control: comment only, no behavior change.")],
     ["go", "test", "./internal/sessstate", "-run", r"^TestOwnershipUnionOrderIndependent$", "-count=1", "-v"],
     "Applied control: behavior-preserving plant survives through the same instrument."),
]

results = []
for name, rel, edits, command, bound in MUTANTS:
    copy = output / ("src-" + name)
    if copy.exists():
        shutil.rmtree(copy)
    copy.mkdir(parents=True)
    shutil.copytree(root / "internal", copy / "internal")
    for extra in ("go.mod", "go.sum"):
        shutil.copy2(root / extra, copy / extra)
    target = copy / rel
    text = target.read_text()
    applied = True
    for old, new in edits:
        if text.count(old) != 1:
            print(f"{name}: anchor {old[:60]!r} found {text.count(old)} times -> NOT_APPLIED")
            applied = False
            break
        text = text.replace(old, new)
    if not applied:
        results.append(dict(mutant=name, classification="NOT_APPLIED", exit=None,
                            failed_tests=[], bound=bound, command=command))
        continue
    target.write_text(text)
    log = output / (name + ".log")
    with log.open("w") as fh:
        proc = subprocess.run(command, cwd=copy, stdout=fh, stderr=subprocess.STDOUT, timeout=300)
    body = log.read_text()
    failures = re.findall(r"^\s*--- FAIL: ([^ ]+)", body, re.M)
    ran = re.findall(r"^=== RUN ", body, re.M)
    if not ran:
        classification = "COMPILE_OR_HARNESS_FAILURE"
    elif proc.returncode == 0:
        classification = "SURVIVED"
    elif failures:
        classification = "KILLED"
    else:
        classification = "COMPILE_OR_HARNESS_FAILURE"
    results.append(dict(mutant=name, classification=classification, exit=proc.returncode,
                        failed_tests=failures, bound=bound, command=command))
    print(name, classification, proc.returncode, ", ".join(failures), flush=True)

(output / "own-mutants.json").write_text(json.dumps(results, indent=2))
print("wrote", output / "own-mutants.json")
