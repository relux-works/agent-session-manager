package sessprofile

// Reviewer-owned independent probes for TASK-260830-3uzfyn rev1.
// Lives only in the isolated review copy; never in the worktree.

import (
	"errors"
	"testing"
)

// Changed envelope members refuse as no-op, never append a distinct
// event: replay requires the identical to/lease/author/instant.
func TestReviewerChangedEnvelopeRefusesAndAppendsNothing(t *testing.T) {
	repository := openTestRepository(t)
	createTestSession(t, repository, testSessionID, "payments-api", ProfileStandard)
	transactor := &Transactor{Repo: repository}
	if _, err := transactor.SetProfile(validSetProfileRequest()); err != nil {
		t.Fatalf("SetProfile error = %v", err)
	}
	changed := []SetProfileRequest{}
	instant := validSetProfileRequest()
	instant.CreatedAt = "2026-08-19T04:09:00.000Z"
	changed = append(changed, instant)
	author := validSetProfileRequest()
	author.CreatedByHostID = testHostIDB
	changed = append(changed, author)
	for _, request := range changed {
		if _, err := transactor.SetProfile(request); !errors.Is(err, ErrProfileUnchanged) {
			t.Fatalf("SetProfile(changed envelope) error = %v, want unchanged", err)
		}
	}
	indexed, err := repository.ListEvents(testSessionID)
	if err != nil {
		t.Fatalf("ListEvents error = %v", err)
	}
	if len(indexed) != 1 {
		t.Fatalf("chain holds %d events after refused retries, want 1", len(indexed))
	}
}

// Fencing precedes replay: a greater-epoch acting lease refuses even
// when the rest of the envelope matches the committed change.
func TestReviewerFencingPrecedesReplay(t *testing.T) {
	repository := openTestRepository(t)
	createTestSession(t, repository, testSessionID, "payments-api", ProfileStandard)
	transactor := &Transactor{Repo: repository}
	if _, err := transactor.SetProfile(validSetProfileRequest()); err != nil {
		t.Fatalf("SetProfile error = %v", err)
	}
	request := validSetProfileRequest()
	request.LeaseEpoch = 2
	if _, err := transactor.SetProfile(request); !errors.Is(err, ErrDivergentLease) {
		t.Fatalf("SetProfile(greater epoch replay) error = %v, want divergent lease", err)
	}
	indexed, err := repository.ListEvents(testSessionID)
	if err != nil {
		t.Fatalf("ListEvents error = %v", err)
	}
	if len(indexed) != 1 {
		t.Fatalf("chain holds %d events after fenced retry, want 1", len(indexed))
	}
}
