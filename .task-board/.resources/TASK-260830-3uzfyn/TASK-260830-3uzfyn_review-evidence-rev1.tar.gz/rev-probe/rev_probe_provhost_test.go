package provhost

// Reviewer-owned independent mapping probes for TASK-260830-3uzfyn rev1.
// Lives only in the isolated review copy; never in the worktree.

import (
	"strings"
	"testing"
)

// Pi one patch off the pinned 0.73.1 (reviewer-chosen 0.73.2,
// distinct from the producer's 0.74.0) refuses
// profile_mapping_unavailable with exit 6 and full details.
func TestReviewerPiPatchOffRefuses(t *testing.T) {
	_, err := ResolveMapping("pi", ProfileYOLO, resolveTuple("pi", "0.73.2"))
	if failureCode(t, err) != "profile_mapping_unavailable" {
		t.Fatalf("ResolveMapping(pi 0.73.2) code = %v, want profile_mapping_unavailable", err)
	}
	if failureExit(t, err) != 6 {
		t.Fatalf("ResolveMapping(pi 0.73.2) exit = %d, want 6", failureExit(t, err))
	}
	obj := failureObject(t, err)
	for _, key := range []string{"provider_id", "provider_version", "profile"} {
		if _, ok := obj.Detail(key); !ok {
			t.Fatalf("refusal misses detail %q (%v)", key, err)
		}
	}
	if _, err := ResolveMapping("pi", ProfileStandard, resolveTuple("pi", "0.73.1")); err != nil {
		t.Fatalf("ResolveMapping(pi pinned) error = %v", err)
	}
}

// A base argv that already contains the exact required flag refuses;
// a foreign provider's flag refuses; yolo appends exactly once.
func TestReviewerBaseCarryingFlagRefuses(t *testing.T) {
	tuple := resolveTuple("codex", "0.147.0")
	resolved, err := ResolveMapping("codex", ProfileYOLO, tuple)
	if err != nil {
		t.Fatalf("ResolveMapping error = %v", err)
	}
	base := []string{"codex", "exec", "--dangerously-bypass-approvals-and-sandbox"}
	if _, err := ProjectLaunchArgv(base, "codex", ProfileYOLO, resolved); failureCode(t, err) != "invalid_config" {
		t.Fatalf("ProjectLaunchArgv(duplicate) code = %v, want invalid_config", err)
	}
	foreign := []string{"codex", "exec", "--dangerously-skip-permissions"}
	if _, err := ProjectLaunchArgv(foreign, "codex", ProfileYOLO, resolved); failureCode(t, err) != "invalid_config" {
		t.Fatalf("ProjectLaunchArgv(foreign flag) code = %v, want invalid_config", err)
	}
	clean := []string{"codex", "exec"}
	projected, err := ProjectLaunchArgv(clean, "codex", ProfileYOLO, resolved)
	if err != nil {
		t.Fatalf("ProjectLaunchArgv error = %v", err)
	}
	if len(projected) != 3 || projected[2] != "--dangerously-bypass-approvals-and-sandbox" {
		t.Fatalf("projected = %q, want exactly one appended flag", projected)
	}
}

// One past every Section 5.1 bound refuses: 129 elements, a 4097-byte
// element, and a 65537-byte total (reviewer-built vectors).
func TestReviewerArgvBoundsPlusOneRefuse(t *testing.T) {
	tuple := resolveTuple("muse", "0.1.0")
	resolved, err := ResolveMapping("muse", ProfileStandard, tuple)
	if err != nil {
		t.Fatalf("ResolveMapping error = %v", err)
	}
	big := []string{"muse"}
	for i := 0; i < 128; i++ {
		big = append(big, "w")
	}
	if _, err := ProjectLaunchArgv(big, "muse", ProfileStandard, resolved); failureCode(t, err) != "invalid_config" {
		t.Fatalf("ProjectLaunchArgv(129 elements) code = %v, want invalid_config", err)
	}
	wide := []string{"muse", strings.Repeat("x", 4097)}
	if _, err := ProjectLaunchArgv(wide, "muse", ProfileStandard, resolved); failureCode(t, err) != "invalid_config" {
		t.Fatalf("ProjectLaunchArgv(4097-byte element) code = %v, want invalid_config", err)
	}
	total := []string{"muse", strings.Repeat("y", 40000), strings.Repeat("z", 25537)}
	if _, err := ProjectLaunchArgv(total, "muse", ProfileStandard, resolved); failureCode(t, err) != "invalid_config" {
		t.Fatalf("ProjectLaunchArgv(65537-byte total) code = %v, want invalid_config", err)
	}
}
