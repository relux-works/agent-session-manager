#!/usr/bin/env python3
"""Reviewer-owned narrowing mutants for TASK-260830-3uzfyn rev1.

Attacks four gate arms the producer battery did not mutate. Each plant keeps
its gate present and weakens it to admit exactly one member of the rejected
class; a named behavioral test must fail. Runs in an isolated copy; never
touches the managed Story checkout. Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 rev_mutants.py /absolute/evidence/dir
"""
import hashlib
import re
import shutil
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[5]
# file lives in .temp/TASK-260830-3uzfyn/, repo root is 2 levels up from .temp
# resolve robustly: walk up until go.mod is found
proc = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                        capture_output=True, text=True, timeout=30)
assert proc.returncode == 0, "must run from inside the Story worktree"
root = Path(proc.stdout.strip())
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=True)
copy = output / "mutation-source"
if copy.exists():
    raise SystemExit("refusing to overwrite an existing mutation source")
copy.mkdir()
shutil.copytree(root / "internal", copy / "internal")
for name in ("go.mod", "go.sum"):
    shutil.copy2(root / name, copy / name)

PLANTS = [
    {
        "name": "R-closure-limit-plus-one",
        "file": "internal/sessprofile/profile.go",
        "old": "limit = position[id] + 1",
        "new": "limit = position[id] + 2",
        "bound": "Widen the checkpoint closure validation limit by exactly one event: the single post-closure corrupt event enters validation and checkChain refuses its repeated sequence, so DeriveForHeads errors where it must succeed.",
        "cmd": ["go", "test", "./internal/sessprofile", "-run",
                r"^TestDeriveForHeadsIgnoresPostClosureCorruption$",
                "-count=1", "-v"],
    },
    {
        "name": "R-first-seq-admits-2",
        "file": "internal/sessprofile/profile.go",
        "old": ("if event.Sequence != 1 {\n"
                '\t\t\t\treturn nil, refuse(ErrInvalidTransition, "first event %s must open its lease at sequence 1", event.ID)'),
        "new": ("if event.Sequence != 1 && event.Sequence != 2 {\n"
                '\t\t\t\treturn nil, refuse(ErrInvalidTransition, "first event %s must open its lease at sequence 1", event.ID)'),
        "bound": "Admit exactly the sequence-2 lease opener past the first-event gate (an arm the producer battery never mutated); the sequence-is-not-1 refusal disappears. NOTE: the brief-suggested compareLease '<=' variant is vacuous here: it sits inside an outer 'a.Epoch != b.Epoch' guard, so '<=' is behavior-identical to '<' and correctly SURVIVES; this plant attacks the order gate observably instead.",
        "cmd": ["go", "test", "./internal/sessprofile", "-run",
                r"^TestDeriveRefusesFirstEventViolations$", "-count=1", "-v"],
    },
    {
        "name": "R-pi-equivalence-dropped",
        "file": "internal/provhost/profile_resolve.go",
        "old": 'Equivalent: providerID == "pi",',
        "new": "Equivalent: false,",
        "bound": "Drop exactly the Pi both-profiles equivalence disclosure; the mapping still resolves.",
        "cmd": ["go", "test", "./internal/provhost", "-run",
                r"^TestResolveMappingTable$", "-count=1", "-v"],
    },
    {
        "name": "R-mint-confirm-from-standard",
        "file": "internal/sessprofile/mint.go",
        "old": "if params.To == ProfileYOLO && !params.Confirmed {",
        "new": 'if params.To == ProfileYOLO && !params.Confirmed && params.From != ProfileStandard {',
        "bound": "Skip confirmation for exactly the from-value the refusal test drives (standard->yolo unconfirmed). NOTE: the brief-suggested from-is-yolo variant is unobservable: the earlier from==to arm still refuses yolo->yolo, so the suite would stay green; this plant targets the tested member instead.",
        "cmd": ["go", "test", "./internal/sessprofile", "-run",
                r"^TestMintChangeEventRefusals$", "-count=1", "-v"],
    },
    {
        "name": "R-harmless-comment",
        "file": "internal/sessprofile/profile.go",
        "old": "// compareLease orders two lease heads by the Section 5.3 tuple",
        "new": "// compareLease orders two lease heads by the Section 5.3 tuple\n// reviewer control: comment only, no behavior change.",
        "bound": "Applied control: behavior-preserving plant survives through the same instrument.",
        "cmd": ["go", "test", "./internal/sessprofile", "./internal/provhost",
                "-count=1", "-v"],
    },
]

results = []
for plant in PLANTS:
    path = copy / plant["file"]
    original = path.read_text()
    assert original.count(plant["old"]) == 1, (
        f'{plant["name"]}: anchor count {original.count(plant["old"])}')
    path.write_text(original.replace(plant["old"], plant["new"]))
    try:
        with (output / (plant["name"] + ".log")).open("w") as log:
            proc = subprocess.run(plant["cmd"], cwd=copy, stdout=log,
                                 stderr=subprocess.STDOUT, timeout=300)
        text = (output / (plant["name"] + ".log")).read_text()
        failures = re.findall(r"^\s*--- FAIL: ([^ ]+)", text, re.M)
        ran = re.findall(r"^=== RUN ", text, re.M)
        if not ran:
            cls = "COMPILE_OR_HARNESS_FAILURE"
        elif proc.returncode == 0:
            cls = "SURVIVED"
        else:
            cls = "KILLED" if failures else "COMPILE_OR_HARNESS_FAILURE"
        results.append({"mutant": plant["name"], "classification": cls,
                        "exit": proc.returncode, "failed_tests": failures,
                        "bound": plant["bound"], "command": plant["cmd"]})
        print(plant["name"], cls, proc.returncode, ", ".join(failures),
              flush=True)
    finally:
        path.write_text(original)
        assert (hashlib.sha256(path.read_bytes()).digest()
                == hashlib.sha256(original.encode()).digest())

import json
(output / "rev-mutants.json").write_text(json.dumps(results, indent=2) + "\n")
killed = sum(1 for r in results if r["classification"] == "KILLED")
print(f"narrowing killed: {killed}/4, control: "
      f"{[r['classification'] for r in results if 'harmless' in r['mutant']]}")
