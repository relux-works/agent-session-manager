#!/usr/bin/env python3
"""Reviewer-owned witness-instrument attacks for TASK-260830-3uzfyn rev1.

Three attacks on the provhost derived-arm witness instrument for the new
profile-mapping arms (profile_resolve.go). Each must turn the suite RED.
Isolated copy; never touches the managed Story checkout. Usage:
  PYTHONDONTWRITEBYTECODE=1 python3 rev_witness.py /absolute/evidence/dir
"""
import hashlib
import json
import re
import shutil
import subprocess
import sys
from pathlib import Path

proc = subprocess.run(["git", "rev-parse", "--show-toplevel"],
                      capture_output=True, text=True, timeout=30)
assert proc.returncode == 0
root = Path(proc.stdout.strip())
output = Path(sys.argv[1]).resolve()
output.mkdir(parents=True, exist_ok=True)
copy = output / "mutation-source"
if copy.exists():
    raise SystemExit("refusing to overwrite an existing mutation source")
copy.mkdir()
shutil.copytree(root / "internal", copy / "internal")
for name in ("go.mod", "go.sum"):
    shutil.copy2(root / name, copy / name)

WITNESS_RUN = (r"TestDerivedRefusalArmsAreAllWitnessed|"
               r"TestWitnessedArmsAreAllDerived|"
               r"TestEveryArmWitnessRefusesAtTheProductionEntry|"
               r"TestResolveMapping")

ATTACKS = [
    {
        "name": "W-swap-adjacent-details",
        "file": "internal/provhost/profile_resolve.go",
        "edits": [
            ('failInvalid("mapping tuple names another provider")',
             'failInvalid("mapping profile is not standard or yolo")'),
            ('failInvalid("mapping profile is not standard or yolo")',
             'failInvalid("mapping tuple names another provider")'),
        ],
        "bound": "Swap the detail strings of two adjacent failInvalid arms sharing the invalid_config code; each witness then observes the other's detail.",
    },
    {
        "name": "W-one-token-swallow",
        "file": "internal/provhost/profile_resolve.go",
        "edits": [
            ("if _, ok := profileYOLOMapping[providerID]; !ok {",
             "if _, ok := profileYOLOMapping[providerID]; ok {"),
        ],
        "bound": "Swallow the single '!' token: known providers refuse, qwen-shaped unknowns pass the row arm.",
    },
    {
        "name": "W-delete-pi-pin",
        "file": "internal/provhost/profile_resolve.go",
        "edits": [
            ('\tif providerID == "pi" && tuple.ProviderVersion != piPinnedVersion {\n'
             '\t\tfailure, err := failMappingUnavailable("mapping pins pi to probed 0.73.1", providerID, tuple.ProviderVersion, profile)\n'
             '\t\tif err != nil {\n'
             '\t\t\treturn empty, err\n'
             '\t\t}\n'
             '\t\treturn empty, failure\n'
             '\t}\n', ""),
        ],
        "bound": "Delete the Pi exact-version pin arm; unpinned Pi versions resolve and its witness orphans.",
    },
]

results = []
for attack in ATTACKS:
    path = copy / attack["file"]
    original = path.read_text()
    text = original
    # apply sequentially against evolving text for the swap pair
    first_old, first_new = attack["edits"][0]
    assert text.count(first_old) == 1, f'{attack["name"]}: anchor0 разбор'
    if len(attack["edits"]) == 2:
        second_old, second_new = attack["edits"][1]
        assert first_old != second_old
        token = "@@REVIEWER-SWAP-TOKEN@@"
        text = text.replace(first_old, token)
        assert text.count(second_old) == 1, f'{attack["name"]}: anchor1 разбор'
        text = text.replace(second_old, second_new)
        text = text.replace(token, first_new)
    else:
        text = text.replace(first_old, first_new)
    path.write_text(text)
    cmd = ["go", "test", "./internal/provhost", "-run", WITNESS_RUN,
           "-count=1", "-v"]
    try:
        with (output / (attack["name"] + ".log")).open("w") as log:
            proc = subprocess.run(cmd, cwd=copy, stdout=log,
                                  stderr=subprocess.STDOUT, timeout=300)
        body = (output / (attack["name"] + ".log")).read_text()
        failures = re.findall(r"^\s*--- FAIL: ([^ ]+)", body, re.M)
        ran = re.findall(r"^=== RUN ", body, re.M)
        red = proc.returncode != 0 and bool(failures)
        results.append({"attack": attack["name"],
                        "classification": "RED" if red else
                        ("NO-RUN" if not ran else "STAYED-GREEN"),
                        "exit": proc.returncode, "failed_tests": failures,
                        "bound": attack["bound"], "command": cmd})
        print(attack["name"], results[-1]["classification"], proc.returncode,
              ", ".join(failures), flush=True)
    finally:
        path.write_text(original)
        assert (hashlib.sha256(path.read_bytes()).digest()
                == hashlib.sha256(original.encode()).digest())

(output / "rev-witness.json").write_text(json.dumps(results, indent=2) + "\n")
