from pathlib import Path
p = Path('internal/clonereconcile/property_test.go').read_text()
assert 'for n := 0; n <= 3; n++ {' in p
assert 'for n := 4; n <= 6; n++ {' in p
assert 'for mix := 0; mix < 55; mix++ {' in p
assert 'nonNominalOutcomes[cell%len(nonNominalOutcomes)]' in p
missing = []
for n in range(4, 7):
    vectors = [tuple([c] * n) for c in range(5)]
    vectors += [tuple((mix + 3 * i) % 5 for i in range(n)) for mix in range(55)]
    actual, expected = len(set(vectors)), 5 ** n
    print(f'N={n}: unique capture vectors {actual}/{expected}; read-back outcomes per run 2/9')
    if actual != expected:
        missing.append(n)
assert not missing, f'incomplete N values: {missing}'
