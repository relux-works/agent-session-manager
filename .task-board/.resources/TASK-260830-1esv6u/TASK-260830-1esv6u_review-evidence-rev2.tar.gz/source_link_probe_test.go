package clonereconcile_test

import (
    "testing"
    "github.com/relux-works/agent-session-manager/internal/clonefidelity"
    clonereconcile "github.com/relux-works/agent-session-manager/internal/clonereconcile"
)

func TestReviewerSourceEvidenceMustFollowCandidateChain(t *testing.T) {
    docs := sealSharedWorldDocs(t)
    for _, mode := range []string{"swap", "double-count"} {
        t.Run(mode, func(t *testing.T) {
            input := assembleWorld(t, docs, worldSpec{items: []worldItem{
                {key: "cand-0", disposition: "exact"},
                {key: "cand-1", disposition: "exact"},
            }})
            raw0, raw1 := input.Tier1[0].Raw, input.Tier1[1].Raw
            if mode == "swap" {
                input.Fidelity.Rows[0].SourceEvidenceIDs = []string{raw1}
                input.Fidelity.Rows[1].SourceEvidenceIDs = []string{raw0}
            } else {
                input.Fidelity.Rows[0].SourceEvidenceIDs = []string{raw0}
                input.Fidelity.Rows[1].SourceEvidenceIDs = []string{raw0}
            }
            reportBytes, err := clonefidelity.BuildFidelityReport(input.Fidelity)
            if err != nil { t.Fatalf("owner build: %v", err) }
            report, err := clonefidelity.DecodeFidelityReport(reportBytes)
            if err != nil { t.Fatalf("owner decode: %v", err) }
            input.Validation.ExpectedFidelityReportID = report.ReportID.String()
            _, err = clonereconcile.Reconcile(input)
            if err == nil { t.Fatalf("Reconcile admitted %s source evidence despite candidate/raw chain mismatch", mode) }
        })
    }
}
