import json
from pathlib import Path
r = json.loads(Path('internal/traceability/ownership.v0.7.0.json').read_text())
ids = ['story-260830-2ya5le-fidelity-report', 'story-260830-1jmmqn-projection-plan', 'story-260830-3n78rv-projection-planning', 'story-260830-2zboyz-readback-validation', 'story-260830-1esv6u-reconciliation']
missing = []
for case in ids:
    groups = [g for g in r['ownership'] if case in g.get('acceptance_cases', [])]
    edges = [(g.get('keys'), c.get('id')) for g in r['ownership'] for c in g.get('clauses', []) if case in c.get('acceptance_cases', [])]
    print(case, f'binding_groups={len(groups)} clause_edges={len(edges)}')
    if not edges:
        missing.append(case)
assert not missing, f'missing decoded clause edges: {missing}'
